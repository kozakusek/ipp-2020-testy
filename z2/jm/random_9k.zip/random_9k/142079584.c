#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 142079584
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 16, 8, 19);
assert( board != NULL );


assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board116581713 = gamma_board(board);
assert( board116581713 != NULL );
assert( strcmp(board116581713, 
"............\n"
"............\n"
"............\n"
"............\n"
"............\n"
".......1....\n"
"............\n"
"............\n"
".1..........\n"
"............\n"
"............\n"
"............\n"
"............\n"
"............\n"
"............\n"
"............\n") == 0);
free(board116581713);
board116581713 = NULL;
assert( gamma_busy_fields(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_move(board, 5, 0, 1) == 1 );
assert( gamma_move(board, 6, 2, 9) == 1 );
assert( gamma_move(board, 6, 8, 8) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 9) == 1 );
assert( gamma_move(board, 7, 5, 8) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 10, 11) == 1 );
assert( gamma_move(board, 8, 10, 5) == 1 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_free_fields(board, 1) == 178 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 2, 9, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 2 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 5, 8, 10) == 1 );
assert( gamma_move(board, 5, 11, 0) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 3) == 1 );
assert( gamma_move(board, 7, 10, 9) == 1 );
assert( gamma_move(board, 7, 10, 6) == 1 );
assert( gamma_move(board, 8, 0, 15) == 1 );
assert( gamma_move(board, 8, 3, 3) == 1 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_move(board, 2, 6, 15) == 1 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_move(board, 4, 2, 4) == 1 );
assert( gamma_move(board, 5, 8, 0) == 1 );
assert( gamma_move(board, 5, 4, 4) == 1 );
assert( gamma_move(board, 6, 11, 9) == 1 );
assert( gamma_move(board, 6, 5, 15) == 1 );
assert( gamma_move(board, 7, 12, 9) == 0 );
assert( gamma_move(board, 8, 7, 7) == 1 );
assert( gamma_busy_fields(board, 8) == 5 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 4, 13, 10) == 0 );
assert( gamma_move(board, 4, 7, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 5, 6, 11) == 1 );
assert( gamma_move(board, 6, 9, 1) == 1 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 7, 11, 15) == 1 );
assert( gamma_move(board, 8, 10, 9) == 0 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 3, 9, 13) == 1 );
assert( gamma_move(board, 4, 4, 15) == 1 );
assert( gamma_move(board, 5, 11, 1) == 1 );
assert( gamma_move(board, 5, 9, 4) == 1 );
assert( gamma_move(board, 6, 11, 0) == 0 );
assert( gamma_move(board, 8, 9, 5) == 1 );
assert( gamma_move(board, 8, 0, 2) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 11, 3) == 1 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 2, 3, 15) == 1 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_golden_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_move(board, 5, 6, 13) == 1 );
assert( gamma_golden_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 6, 10, 2) == 1 );
assert( gamma_move(board, 6, 1, 14) == 1 );
assert( gamma_move(board, 7, 14, 8) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_move(board, 5, 8, 4) == 1 );
assert( gamma_move(board, 5, 11, 15) == 0 );
assert( gamma_free_fields(board, 5) == 131 );
assert( gamma_golden_move(board, 5, 15, 0) == 0 );
assert( gamma_move(board, 7, 8, 4) == 0 );
assert( gamma_move(board, 7, 0, 11) == 1 );
assert( gamma_move(board, 1, 4, 5) == 1 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 4, 3, 14) == 1 );
assert( gamma_move(board, 5, 14, 8) == 0 );
assert( gamma_move(board, 5, 1, 2) == 1 );


char* board889532145 = gamma_board(board);
assert( board889532145 != NULL );
assert( strcmp(board889532145, 
"8..2462....7\n"
".6.4........\n"
"......5..3..\n"
"...........3\n"
"7.3..253..8.\n"
"....1..15...\n"
"..62...7.376\n"
".2.3.7..6...\n"
".1.31.28.2..\n"
"..........7.\n"
"45..142..88.\n"
"..4.5...55..\n"
"..18644....1\n"
"85...1....6.\n"
"51.......6.5\n"
".......45..5\n") == 0);
free(board889532145);
board889532145 = NULL;
assert( gamma_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 7, 8, 10) == 0 );
assert( gamma_move(board, 8, 3, 0) == 1 );
assert( gamma_move(board, 8, 7, 11) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_free_fields(board, 2) == 124 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 4, 12, 10) == 0 );
assert( gamma_move(board, 4, 3, 13) == 1 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_golden_move(board, 5, 5, 5) == 1 );
assert( gamma_move(board, 6, 1, 8) == 0 );
assert( gamma_move(board, 6, 3, 1) == 1 );
assert( gamma_move(board, 7, 0, 10) == 1 );
assert( gamma_move(board, 8, 3, 3) == 0 );
assert( gamma_move(board, 8, 8, 1) == 1 );
assert( gamma_free_fields(board, 8) == 119 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_free_fields(board, 1) == 118 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_free_fields(board, 4) == 117 );
assert( gamma_move(board, 5, 8, 10) == 0 );
assert( gamma_move(board, 5, 0, 8) == 1 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 6, 0, 12) == 1 );
assert( gamma_move(board, 7, 4, 6) == 1 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 8, 15) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_move(board, 5, 10, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_move(board, 6, 1, 10) == 1 );
assert( gamma_move(board, 6, 8, 15) == 0 );
assert( gamma_move(board, 7, 0, 11) == 0 );
assert( gamma_move(board, 7, 5, 2) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 11) == 0 );
assert( gamma_move(board, 8, 2, 5) == 1 );
assert( gamma_free_fields(board, 8) == 109 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_golden_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 11, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_move(board, 5, 1, 15) == 1 );
assert( gamma_move(board, 6, 12, 7) == 0 );
assert( gamma_move(board, 7, 0, 9) == 1 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 8, 12, 3) == 0 );
assert( gamma_move(board, 8, 8, 5) == 1 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_golden_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 6, 0, 6) == 1 );
assert( gamma_move(board, 6, 1, 11) == 1 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_move(board, 7, 6, 6) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 6, 8) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 4, 8, 9) == 1 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_golden_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 6, 3, 12) == 1 );
assert( gamma_move(board, 7, 1, 7) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_move(board, 8, 11, 8) == 1 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_move(board, 1, 10, 12) == 1 );
assert( gamma_free_fields(board, 1) == 92 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_free_fields(board, 4) == 90 );
assert( gamma_move(board, 5, 8, 11) == 1 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 5, 14) == 1 );
assert( gamma_move(board, 7, 6, 7) == 0 );
assert( gamma_move(board, 8, 14, 10) == 0 );
assert( gamma_move(board, 8, 7, 12) == 1 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_move(board, 6, 12, 5) == 0 );
assert( gamma_move(board, 7, 2, 14) == 1 );
assert( gamma_move(board, 8, 2, 9) == 0 );
assert( gamma_move(board, 8, 11, 3) == 0 );
assert( gamma_free_fields(board, 8) == 84 );
assert( gamma_move(board, 1, 11, 11) == 1 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 15 );


char* board580616565 = gamma_board(board);
assert( board580616565 != NULL );
assert( strcmp(board580616565, 
"85.2462.2..7\n"
".674273.....\n"
"...4..5..3.3\n"
"6..6..384.13\n"
"763..2535.81\n"
"76..1..15...\n"
"7262...74376\n"
"5243273.6118\n"
".1331.28.2..\n"
"6...7.7...72\n"
"458.152.888.\n"
"314.5...55..\n"
"..18644....1\n"
"85...12...6.\n"
"51.6....86.5\n"
"2..8...45.55\n") == 0);
free(board580616565);
board580616565 = NULL;
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 3, 10) == 1 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 7, 2, 0) == 1 );
assert( gamma_move(board, 8, 5, 7) == 1 );
assert( gamma_move(board, 8, 6, 13) == 0 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 1, 9, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_golden_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 10, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 5, 8, 9) == 0 );
assert( gamma_move(board, 6, 14, 7) == 0 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_golden_move(board, 7, 15, 3) == 0 );
assert( gamma_move(board, 8, 0, 8) == 0 );
assert( gamma_move(board, 8, 11, 4) == 1 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_golden_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 5, 11, 5) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 6, 5, 0) == 1 );
assert( gamma_free_fields(board, 6) == 71 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 11, 9) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 4) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_move(board, 4, 10, 14) == 1 );


char* board926048094 = gamma_board(board);
assert( board926048094 != NULL );
assert( strcmp(board926048094, 
"85.2462.2..7\n"
"4674273...4.\n"
"...4..5..3.3\n"
"6..6..384.13\n"
"763..2535.81\n"
"76351..151..\n"
"7262...74376\n"
"5243273.6118\n"
".1331828.2..\n"
"6.1.7.7...72\n"
"458.152.1885\n"
"314.5...55.8\n"
"..18644...31\n"
"854..12...6.\n"
"51.6.2..86.5\n"
"2.78.6.45.55\n") == 0);
free(board926048094);
board926048094 = NULL;
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 7, 14, 7) == 0 );
assert( gamma_free_fields(board, 7) == 69 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 3, 3) == 0 );
assert( gamma_free_fields(board, 8) == 69 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_free_fields(board, 2) == 69 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 3, 7, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 6, 14, 9) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_golden_move(board, 7, 11, 8) == 1 );
assert( gamma_move(board, 8, 10, 11) == 0 );
assert( gamma_move(board, 8, 11, 0) == 0 );
assert( gamma_busy_fields(board, 8) == 13 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 5, 11, 7) == 1 );
assert( gamma_move(board, 6, 14, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 11, 12) == 0 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_move(board, 8, 10, 5) == 0 );
assert( gamma_free_fields(board, 8) == 65 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_free_fields(board, 1) == 65 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 5, 0, 11) == 0 );
assert( gamma_move(board, 5, 8, 3) == 1 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_move(board, 7, 4, 6) == 0 );
assert( gamma_free_fields(board, 7) == 63 );
assert( gamma_golden_move(board, 7, 4, 9) == 0 );
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_golden_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_golden_possible(board, 5) == 0 );


char* board876810823 = gamma_board(board);
assert( board876810823 != NULL );
assert( strcmp(board876810823, 
"85.2462.2..7\n"
"4674273...4.\n"
"...4..5..3.3\n"
"6..6..384.13\n"
"763..2535.81\n"
"76351..151..\n"
"7262...74376\n"
"5243273.6117\n"
".1331828.2.5\n"
"6.1.7.7..272\n"
"458.152.1885\n"
"314.5...55.8\n"
"..1864435.31\n"
"2544.123..6.\n"
"51.6.2..86.5\n"
"2.78.6.45.55\n") == 0);
free(board876810823);
board876810823 = NULL;
assert( gamma_move(board, 6, 10, 4) == 1 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_move(board, 7, 8, 9) == 0 );
assert( gamma_move(board, 8, 10, 5) == 0 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_free_fields(board, 1) == 62 );


char* board257054221 = gamma_board(board);
assert( board257054221 != NULL );
assert( strcmp(board257054221, 
"85.2462.2..7\n"
"4674273...4.\n"
"...4..5..3.3\n"
"6..6..384.13\n"
"763..2535.81\n"
"76351..151..\n"
"7262...74376\n"
"5243273.6117\n"
".1331828.2.5\n"
"6.1.7.7..272\n"
"458.152.1885\n"
"314.5...5568\n"
"..1864435.31\n"
"2544.123..6.\n"
"51.6.2..86.5\n"
"2.78.6.45.55\n") == 0);
free(board257054221);
board257054221 = NULL;
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_move(board, 7, 13, 7) == 0 );
assert( gamma_move(board, 7, 4, 15) == 0 );
assert( gamma_move(board, 8, 9, 6) == 0 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 6, 3, 5) == 1 );
assert( gamma_move(board, 7, 12, 5) == 0 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 5, 9, 14) == 1 );
assert( gamma_move(board, 6, 5, 3) == 0 );


char* board586993096 = gamma_board(board);
assert( board586993096 != NULL );
assert( strcmp(board586993096, 
"85.2462.2..7\n"
"4674273..54.\n"
"...4..5..3.3\n"
"6..6..384.13\n"
"763..2535.81\n"
"76351..1514.\n"
"7262...74376\n"
"5243273.6117\n"
".1331828.2.5\n"
"6.1.7.7..272\n"
"4586152.1885\n"
"314.5...5568\n"
"..1864435.31\n"
"2544.123..6.\n"
"51.6.26.86.5\n"
"2.78.6.45.55\n") == 0);
free(board586993096);
board586993096 = NULL;
assert( gamma_move(board, 8, 3, 1) == 0 );
assert( gamma_free_fields(board, 8) == 58 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 18 );


char* board636506773 = gamma_board(board);
assert( board636506773 != NULL );
assert( strcmp(board636506773, 
"85.2462.2..7\n"
"4674273..54.\n"
"...4..5..3.3\n"
"6..6..384.13\n"
"763..2535.81\n"
"76351..1514.\n"
"7262...74376\n"
"5243273.6117\n"
".1331828.2.5\n"
"6.1.7.7..272\n"
"4586152.1885\n"
"314.5..15568\n"
"..1864435.31\n"
"2544.123..6.\n"
"51.6.26.86.5\n"
"2.78.6.45.55\n") == 0);
free(board636506773);
board636506773 = NULL;
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 4, 11, 15) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_free_fields(board, 5) == 56 );


char* board357448550 = gamma_board(board);
assert( board357448550 != NULL );
assert( strcmp(board357448550, 
"85.2462.2..7\n"
"4674273..54.\n"
"...4..5..3.3\n"
"6..62.384.13\n"
"763..2535.81\n"
"76351..1514.\n"
"7262...74376\n"
"5243273.6117\n"
".1331828.2.5\n"
"6.1.7.7..272\n"
"4586152.1885\n"
"314.5..15568\n"
"..1864435.31\n"
"2544.123..6.\n"
"51.6.26.86.5\n"
"2.78.6.45.55\n") == 0);
free(board357448550);
board357448550 = NULL;
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_move(board, 7, 10, 15) == 1 );
assert( gamma_move(board, 7, 2, 10) == 0 );
assert( gamma_move(board, 8, 1, 7) == 0 );
assert( gamma_move(board, 8, 0, 8) == 0 );
assert( gamma_golden_move(board, 8, 7, 5) == 0 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 2, 8, 14) == 1 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 5, 0, 11) == 0 );
assert( gamma_move(board, 6, 4, 5) == 0 );
assert( gamma_move(board, 7, 13, 1) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_free_fields(board, 2) == 51 );
assert( gamma_move(board, 3, 7, 15) == 1 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_free_fields(board, 4) == 49 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_move(board, 8, 4, 3) == 0 );
assert( gamma_move(board, 8, 6, 0) == 1 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );


char* board188412868 = gamma_board(board);
assert( board188412868 != NULL );
assert( strcmp(board188412868, 
"85.246232.77\n"
"4674273.2543\n"
"...4..5..3.3\n"
"6..62.384.13\n"
"7631.2535.81\n"
"76351..1514.\n"
"7262...74376\n"
"5243273.6117\n"
".1331828.2.5\n"
"6.1.7.7.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"..1864435.31\n"
"2544.123..6.\n"
"51.6.26.86.5\n"
"2.78.6845.55\n") == 0);
free(board188412868);
board188412868 = NULL;
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 4, 7, 15) == 0 );


char* board208112442 = gamma_board(board);
assert( board208112442 != NULL );
assert( strcmp(board208112442, 
"85.246232.77\n"
"4674273.2543\n"
"...4..5..3.3\n"
"6..62.384.13\n"
"7631.2535.81\n"
"76351..1514.\n"
"7262...74376\n"
"5243273.6117\n"
".1331828.2.5\n"
"6.1.7.7.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"..1864435.31\n"
"2544.123..6.\n"
"51.6.26.86.5\n"
"2.78.6845.55\n") == 0);
free(board208112442);
board208112442 = NULL;
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 7, 4, 5) == 0 );
assert( gamma_move(board, 8, 11, 0) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_golden_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_move(board, 5, 6, 11) == 0 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 7, 11, 15) == 0 );
assert( gamma_move(board, 7, 9, 13) == 0 );
assert( gamma_move(board, 8, 0, 11) == 0 );
assert( gamma_free_fields(board, 8) == 48 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_free_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_move(board, 6, 2, 1) == 1 );
assert( gamma_move(board, 6, 5, 15) == 0 );
assert( gamma_free_fields(board, 6) == 45 );


char* board210467794 = gamma_board(board);
assert( board210467794 != NULL );
assert( strcmp(board210467794, 
"85.246232.77\n"
"4674273.2543\n"
"...4..5..3.3\n"
"6..62.384.13\n"
"7631.2535.81\n"
"76351.11514.\n"
"7262...74376\n"
"5243273.6117\n"
".1331828.2.5\n"
"6.127.7.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"..1864435.31\n"
"2544.123..6.\n"
"5166.26.86.5\n"
"2.78.6845.55\n") == 0);
free(board210467794);
board210467794 = NULL;
assert( gamma_move(board, 7, 8, 7) == 1 );
assert( gamma_move(board, 8, 8, 6) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_free_fields(board, 4) == 44 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_move(board, 6, 15, 9) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_move(board, 8, 8, 0) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 8, 10) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 6, 15, 2) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 13, 10) == 0 );
assert( gamma_golden_move(board, 7, 5, 2) == 0 );
assert( gamma_move(board, 8, 11, 4) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );
assert( gamma_move(board, 6, 13, 7) == 0 );
assert( gamma_move(board, 6, 1, 10) == 0 );
assert( gamma_busy_fields(board, 6) == 19 );
assert( gamma_move(board, 7, 10, 5) == 0 );
assert( gamma_move(board, 7, 4, 12) == 0 );
assert( gamma_free_fields(board, 8) == 42 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );


char* board595366693 = gamma_board(board);
assert( board595366693 != NULL );
assert( strcmp(board595366693, 
"85.246232.77\n"
"4674273.2543\n"
"...4..5..3.3\n"
"6..62.384.13\n"
"7631.2535.81\n"
"76351.11514.\n"
"7262...74376\n"
"5243273.6117\n"
".133182872.5\n"
"6.127.7.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"..1864435.31\n"
"2544.123..6.\n"
"5166.2648625\n"
"2.78.6845.55\n") == 0);
free(board595366693);
board595366693 = NULL;
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 6, 12, 1) == 0 );
assert( gamma_move(board, 6, 3, 13) == 0 );
assert( gamma_move(board, 7, 12, 2) == 0 );
assert( gamma_move(board, 8, 4, 5) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_golden_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 5, 10, 14) == 0 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 8, 3, 1) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );


char* board743529581 = gamma_board(board);
assert( board743529581 != NULL );
assert( strcmp(board743529581, 
"85.246232.77\n"
"4674273.2543\n"
"...4..5..3.3\n"
"6..62.384.13\n"
"7631.2535.81\n"
"76351.11514.\n"
"7262...74376\n"
"5243273.6117\n"
".133182872.5\n"
"6.127.7.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"..1864435.31\n"
"2544.123..6.\n"
"5166.2648625\n"
"2.78.6845.55\n") == 0);
free(board743529581);
board743529581 = NULL;
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_free_fields(board, 5) == 42 );
assert( gamma_move(board, 6, 13, 5) == 0 );
assert( gamma_golden_move(board, 6, 0, 7) == 0 );
assert( gamma_move(board, 7, 12, 2) == 0 );
assert( gamma_move(board, 7, 5, 6) == 1 );
assert( gamma_move(board, 8, 3, 1) == 0 );
assert( gamma_move(board, 8, 0, 5) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_move(board, 4, 5, 9) == 1 );


char* board139785855 = gamma_board(board);
assert( board139785855 != NULL );
assert( strcmp(board139785855, 
"85.246232.77\n"
"4674273.2543\n"
"...4..5..3.3\n"
"6..62.384.13\n"
"7631.2535.81\n"
"76351.11514.\n"
"7262.4.74376\n"
"5243273.6117\n"
".13318287235\n"
"6.12777.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"..1864435.31\n"
"2544.123..6.\n"
"5166.2648625\n"
"2.78.6845.55\n") == 0);
free(board139785855);
board139785855 = NULL;
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_free_fields(board, 5) == 39 );


char* board424444663 = gamma_board(board);
assert( board424444663 != NULL );
assert( strcmp(board424444663, 
"85.246232.77\n"
"4674273.2543\n"
"...4..5..3.3\n"
"6..62.384.13\n"
"7631.2535.81\n"
"76351.11514.\n"
"7262.4.74376\n"
"5243273.6117\n"
".13318287235\n"
"6.12777.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"..1864435.31\n"
"2544.123..6.\n"
"5166.2648625\n"
"2.78.6845.55\n") == 0);
free(board424444663);
board424444663 = NULL;
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 19 );
assert( gamma_move(board, 7, 10, 5) == 0 );
assert( gamma_move(board, 7, 5, 12) == 1 );
assert( gamma_move(board, 8, 3, 0) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 3, 2, 15) == 1 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 5, 10, 15) == 0 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 7, 9, 6) == 0 );
assert( gamma_move(board, 8, 13, 10) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 5, 1, 15) == 0 );
assert( gamma_move(board, 5, 3, 1) == 0 );
assert( gamma_move(board, 6, 12, 2) == 0 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_move(board, 7, 0, 12) == 0 );
assert( gamma_golden_move(board, 7, 10, 8) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_free_fields(board, 2) == 11 );
assert( gamma_move(board, 5, 3, 1) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 6, 8, 9) == 0 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 10, 11) == 0 );
assert( gamma_move(board, 8, 9, 14) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_golden_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 5, 10, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_golden_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 7, 4, 5) == 0 );
assert( gamma_move(board, 7, 8, 9) == 0 );
assert( gamma_move(board, 8, 5, 7) == 0 );
assert( gamma_move(board, 8, 1, 11) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );


char* board373115207 = gamma_board(board);
assert( board373115207 != NULL );
assert( strcmp(board373115207, 
"853246232.77\n"
"4674273.2543\n"
"..14..5..3.3\n"
"6..627384.13\n"
"7631.2535.81\n"
"76351.11514.\n"
"7262.4.74376\n"
"5243273.6117\n"
".13318287235\n"
"6.12777.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"..1864435.31\n"
"2544.123..6.\n"
"5166.2648625\n"
"2.78.6845.55\n") == 0);
free(board373115207);
board373115207 = NULL;
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 7, 6, 1) == 0 );
assert( gamma_move(board, 8, 2, 9) == 0 );
assert( gamma_move(board, 8, 5, 6) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 15, 9) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 8) == 0 );
assert( gamma_move(board, 5, 0, 3) == 1 );
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_move(board, 6, 1, 1) == 0 );
assert( gamma_move(board, 7, 5, 7) == 0 );
assert( gamma_move(board, 7, 9, 11) == 1 );
assert( gamma_move(board, 8, 6, 1) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_golden_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board541711409 = gamma_board(board);
assert( board541711409 != NULL );
assert( strcmp(board541711409, 
"853246232.77\n"
"4674273.2543\n"
"..14..5..3.3\n"
"6..627384.13\n"
"7631.2535781\n"
"76351.11514.\n"
"7262.4.74376\n"
"5243273.6117\n"
"413318287235\n"
"6.12777.4272\n"
"4586152.1885\n"
"314.5.315568\n"
"5.1864435.31\n"
"2544.123..6.\n"
"5166.2648625\n"
"2.78.6845.55\n") == 0);
free(board541711409);
board541711409 = NULL;
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 19 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_move(board, 8, 9, 4) == 0 );
assert( gamma_move(board, 8, 9, 4) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 2, 4) == 0 );
assert( gamma_move(board, 7, 0, 10) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );


gamma_delete(board);

    return 0;
}
