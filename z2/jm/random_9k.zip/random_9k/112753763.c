#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 112753763
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 12, 9, 17);
assert( board != NULL );


assert( gamma_move(board, 1, 11, 5) == 1 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_move(board, 3, 10, 0) == 1 );


char* board862267974 = gamma_board(board);
assert( board862267974 != NULL );
assert( strcmp(board862267974, 
"..............\n"
"..............\n"
"..............\n"
"..............\n"
"..2...........\n"
"..............\n"
"...........1..\n"
"..............\n"
"..............\n"
"..............\n"
"..............\n"
"..........3...\n") == 0);
free(board862267974);
board862267974 = NULL;
assert( gamma_move(board, 4, 1, 3) == 1 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_move(board, 5, 2, 3) == 1 );
assert( gamma_move(board, 6, 7, 5) == 1 );
assert( gamma_move(board, 7, 8, 7) == 1 );
assert( gamma_move(board, 7, 2, 7) == 0 );
assert( gamma_move(board, 8, 9, 6) == 1 );
assert( gamma_move(board, 9, 2, 5) == 1 );
assert( gamma_move(board, 9, 2, 0) == 1 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_move(board, 5, 7, 3) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 6) == 1 );
assert( gamma_move(board, 6, 3, 6) == 1 );
assert( gamma_move(board, 7, 7, 6) == 1 );
assert( gamma_move(board, 8, 1, 0) == 1 );
assert( gamma_golden_move(board, 8, 7, 8) == 0 );
assert( gamma_move(board, 9, 9, 6) == 0 );
assert( gamma_move(board, 9, 6, 6) == 1 );
assert( gamma_free_fields(board, 9) == 147 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 9) == 1 );


char* board133340870 = gamma_board(board);
assert( board133340870 != NULL );
assert( strcmp(board133340870, 
"..............\n"
"..............\n"
".35.....2.....\n"
"4.........1...\n"
"..2.....7.....\n"
"6..6..97.8....\n"
"..9....6...1..\n"
"..3....2......\n"
".45....5......\n"
"..............\n"
"..............\n"
".89......23...\n") == 0);
free(board133340870);
board133340870 = NULL;
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 5, 11, 10) == 1 );
assert( gamma_free_fields(board, 5) == 143 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_move(board, 7, 10, 0) == 0 );
assert( gamma_move(board, 7, 10, 8) == 0 );
assert( gamma_move(board, 8, 2, 8) == 1 );
assert( gamma_move(board, 8, 6, 6) == 0 );
assert( gamma_busy_fields(board, 8) == 3 );
assert( gamma_move(board, 9, 0, 13) == 0 );
assert( gamma_move(board, 9, 4, 6) == 1 );
assert( gamma_move(board, 1, 11, 1) == 1 );


char* board472274590 = gamma_board(board);
assert( board472274590 != NULL );
assert( strcmp(board472274590, 
"..............\n"
"...........5..\n"
".35.....2.....\n"
"4.8.......1...\n"
"..2.....7.....\n"
"6..69.97.8....\n"
"..9....6...1..\n"
"..3....2......\n"
".45....5......\n"
"..............\n"
"...........1..\n"
".89......23...\n") == 0);
free(board472274590);
board472274590 = NULL;
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 5, 4, 13) == 0 );
assert( gamma_move(board, 5, 10, 7) == 1 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_move(board, 7, 7, 4) == 0 );
assert( gamma_move(board, 7, 6, 1) == 1 );
assert( gamma_move(board, 8, 11, 4) == 1 );
assert( gamma_move(board, 8, 10, 7) == 0 );
assert( gamma_free_fields(board, 8) == 133 );
assert( gamma_move(board, 9, 11, 10) == 0 );
assert( gamma_move(board, 9, 9, 6) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_golden_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_free_fields(board, 2) == 132 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 4, 13, 11) == 1 );
assert( gamma_move(board, 5, 9, 11) == 1 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_free_fields(board, 5) == 127 );
assert( gamma_move(board, 6, 7, 7) == 1 );
assert( gamma_move(board, 6, 7, 7) == 0 );
assert( gamma_move(board, 7, 10, 8) == 0 );


char* board744528067 = gamma_board(board);
assert( board744528067 != NULL );
assert( strcmp(board744528067, 
"....1....5...4\n"
"4..........5..\n"
".35.....2.....\n"
"428.......1...\n"
"..2....67.5...\n"
"6..69.97.8....\n"
".59.43.6...1..\n"
"..3....2...8..\n"
"345....5......\n"
"......4.......\n"
"......7....1..\n"
".89......23...\n") == 0);
free(board744528067);
board744528067 = NULL;
assert( gamma_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 8, 3, 5) == 1 );
assert( gamma_move(board, 9, 2, 9) == 0 );
assert( gamma_free_fields(board, 9) == 125 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 13, 5) == 1 );
assert( gamma_move(board, 4, 7, 10) == 1 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_move(board, 5, 3, 11) == 1 );
assert( gamma_move(board, 5, 11, 2) == 1 );
assert( gamma_move(board, 6, 8, 8) == 1 );
assert( gamma_move(board, 6, 1, 1) == 1 );
assert( gamma_move(board, 7, 0, 9) == 1 );
assert( gamma_move(board, 8, 3, 4) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 10, 9) == 1 );
assert( gamma_move(board, 9, 6, 5) == 1 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_move(board, 5, 11, 8) == 0 );
assert( gamma_move(board, 5, 5, 8) == 1 );
assert( gamma_move(board, 6, 1, 12) == 0 );
assert( gamma_move(board, 7, 0, 4) == 1 );
assert( gamma_move(board, 7, 7, 7) == 0 );


char* board891387702 = gamma_board(board);
assert( board891387702 != NULL );
assert( strcmp(board891387702, 
"...51....5...4\n"
"4......4...5..\n"
"735.....2.9...\n"
"428..5..6.13..\n"
"..2....67.5...\n"
"64.69.97.8....\n"
".5984396...1.3\n"
"7.38...2...8..\n"
"345....5......\n"
"......4....5..\n"
".6....7....1..\n"
".89......23...\n") == 0);
free(board891387702);
board891387702 = NULL;
assert( gamma_move(board, 8, 3, 8) == 1 );
assert( gamma_move(board, 8, 6, 8) == 1 );
assert( gamma_move(board, 9, 2, 5) == 0 );
assert( gamma_move(board, 9, 12, 10) == 1 );
assert( gamma_move(board, 1, 4, 9) == 1 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 0) == 1 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 5, 2, 10) == 1 );
assert( gamma_busy_fields(board, 5) == 11 );
assert( gamma_free_fields(board, 5) == 104 );
assert( gamma_golden_move(board, 5, 10, 12) == 0 );
assert( gamma_move(board, 6, 7, 1) == 1 );
assert( gamma_move(board, 6, 10, 1) == 1 );
assert( gamma_move(board, 7, 10, 4) == 1 );


char* board381021965 = gamma_board(board);
assert( board381021965 != NULL );
assert( strcmp(board381021965, 
".4.51....5...4\n"
"4.5....4...59.\n"
"735.1...2.9...\n"
"4288.58.6.13..\n"
"..2....67.5...\n"
"64.69.97.8....\n"
".5984396...1.3\n"
"7.38...2..78..\n"
"345....5......\n"
"......4....5..\n"
".6....76..61..\n"
".89......23.4.\n") == 0);
free(board381021965);
board381021965 = NULL;
assert( gamma_move(board, 8, 3, 5) == 0 );
assert( gamma_move(board, 8, 5, 8) == 0 );
assert( gamma_move(board, 9, 2, 1) == 1 );
assert( gamma_move(board, 9, 9, 10) == 1 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 9, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 6, 1, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_busy_fields(board, 7) == 7 );


char* board450554179 = gamma_board(board);
assert( board450554179 != NULL );
assert( strcmp(board450554179, 
".4.51....5...4\n"
"4.5....4.9.59.\n"
"735.1...2.9...\n"
"4288.58.6.13..\n"
"..2....67.5...\n"
"64.69.97.8....\n"
".5984396...1.3\n"
"7.38...2..78..\n"
"345....5......\n"
"......4....5..\n"
".69...76..61..\n"
"789......23.4.\n") == 0);
free(board450554179);
board450554179 = NULL;
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_move(board, 8, 12, 11) == 1 );
assert( gamma_move(board, 9, 11, 2) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 4, 7, 0) == 1 );
assert( gamma_move(board, 4, 8, 3) == 1 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_move(board, 6, 9, 7) == 1 );
assert( gamma_move(board, 7, 12, 9) == 1 );
assert( gamma_move(board, 8, 1, 8) == 0 );
assert( gamma_move(board, 9, 10, 1) == 0 );
assert( gamma_move(board, 1, 13, 2) == 1 );


char* board503616200 = gamma_board(board);
assert( board503616200 != NULL );
assert( strcmp(board503616200, 
".4.51....5..84\n"
"4.5....4.9.59.\n"
"735.1...2.9.7.\n"
"4288.58.6.13..\n"
"..2....6765...\n"
"64.69.97.8....\n"
".5984396...1.3\n"
"7.38...2..78..\n"
"345....54.....\n"
"..2...4....5.1\n"
".69...76..61..\n"
"789....4.23.4.\n") == 0);
free(board503616200);
board503616200 = NULL;
assert( gamma_move(board, 2, 3, 0) == 1 );
assert( gamma_golden_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_free_fields(board, 3) == 89 );
assert( gamma_move(board, 4, 11, 0) == 1 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_move(board, 6, 11, 10) == 0 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_move(board, 7, 7, 3) == 0 );
assert( gamma_move(board, 8, 12, 8) == 1 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 1, 6, 9) == 1 );


char* board197882976 = gamma_board(board);
assert( board197882976 != NULL );
assert( strcmp(board197882976, 
".4.51....5..84\n"
"4.5....4.9.59.\n"
"735.1.1.2.9.7.\n"
"4288.58.6.138.\n"
"..2....6765...\n"
"64.69.97.8....\n"
".5984396...1.3\n"
"7.38...2..78..\n"
"345....54.....\n"
"..2...4.3..5.1\n"
".69...76..61..\n"
"7892...4.2344.\n") == 0);
free(board197882976);
board197882976 = NULL;
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_golden_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 6, 11, 2) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 7, 10, 8) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 11) == 0 );
assert( gamma_move(board, 9, 6, 5) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_golden_move(board, 9, 9, 4) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_free_fields(board, 1) == 86 );
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_golden_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 5, 7, 11) == 1 );
assert( gamma_move(board, 6, 3, 12) == 0 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_busy_fields(board, 7) == 8 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 4, 6) == 0 );
assert( gamma_move(board, 9, 12, 11) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 10, 10) == 1 );


char* board510497990 = gamma_board(board);
assert( board510497990 != NULL );
assert( strcmp(board510497990, 
"34.51.25.5..84\n"
"4.5....4.9259.\n"
"735.1.1.2.9.7.\n"
"4288.58.6.138.\n"
"..2....6765...\n"
"64.69.97.8....\n"
".5984396...1.3\n"
"7.38...2..78..\n"
"345....54.....\n"
"..2...4.3..5.1\n"
".69...76..61..\n"
"7892...4.2344.\n") == 0);
free(board510497990);
board510497990 = NULL;
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 5, 6, 4) == 1 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_move(board, 7, 9, 9) == 1 );
assert( gamma_move(board, 8, 9, 11) == 0 );
assert( gamma_move(board, 8, 11, 3) == 1 );
assert( gamma_free_fields(board, 8) == 78 );
assert( gamma_move(board, 9, 4, 5) == 0 );
assert( gamma_move(board, 9, 2, 2) == 0 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 9 );


char* board844707341 = gamma_board(board);
assert( board844707341 != NULL );
assert( strcmp(board844707341, 
"34.51.25.5..84\n"
"4.5.1..4.9259.\n"
"735.1.1.279.7.\n"
"4288.58.6.138.\n"
"..2....6765...\n"
"64.69.97.8....\n"
".5984396...1.3\n"
"7.38..52..78..\n"
"345...454..8..\n"
"..2...4.3..5.1\n"
".69...76..61..\n"
"7892...4.2344.\n") == 0);
free(board844707341);
board844707341 = NULL;
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 12, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_move(board, 4, 8, 4) == 1 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 9, 11) == 0 );
assert( gamma_free_fields(board, 6) == 75 );
assert( gamma_move(board, 8, 3, 6) == 0 );
assert( gamma_busy_fields(board, 8) == 11 );
assert( gamma_move(board, 9, 11, 11) == 1 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 8, 10) == 1 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_move(board, 8, 11, 5) == 0 );
assert( gamma_busy_fields(board, 8) == 11 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 0, 2) == 1 );
assert( gamma_move(board, 9, 6, 6) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 6, 10) == 1 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_golden_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 6, 9, 4) == 1 );
assert( gamma_golden_move(board, 6, 5, 6) == 0 );
assert( gamma_move(board, 7, 7, 11) == 0 );
assert( gamma_move(board, 7, 1, 5) == 0 );
assert( gamma_free_fields(board, 7) == 69 );
assert( gamma_move(board, 8, 7, 11) == 0 );
assert( gamma_move(board, 8, 10, 1) == 0 );
assert( gamma_golden_move(board, 8, 2, 8) == 0 );
assert( gamma_move(board, 9, 13, 6) == 1 );
assert( gamma_move(board, 9, 5, 5) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 3, 10) == 1 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 7, 3, 10) == 0 );
assert( gamma_move(board, 7, 2, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 8, 11, 10) == 0 );
assert( gamma_move(board, 8, 1, 11) == 0 );
assert( gamma_move(board, 9, 0, 5) == 1 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_golden_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 5, 4, 2) == 1 );
assert( gamma_move(board, 6, 13, 4) == 1 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_golden_move(board, 6, 4, 10) == 1 );


char* board748607891 = gamma_board(board);
assert( board748607891 != NULL );
assert( strcmp(board748607891, 
"34351.25.5.984\n"
"4.546.4469259.\n"
"735.1.1.279.7.\n"
"4288.58.6.138.\n"
"..2....6765...\n"
"64.69.97.8...9\n"
"95984396...1.3\n"
"7.38..52467836\n"
"3455..454..8..\n"
"9.2.5.4.3..5.1\n"
".69...76..61..\n"
"7892...4.2344.\n") == 0);
free(board748607891);
board748607891 = NULL;
assert( gamma_move(board, 7, 1, 13) == 0 );
assert( gamma_move(board, 8, 0, 4) == 0 );
assert( gamma_move(board, 9, 13, 7) == 1 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 5, 1) == 1 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 5, 10, 2) == 1 );
assert( gamma_move(board, 6, 9, 7) == 0 );
assert( gamma_move(board, 7, 4, 4) == 1 );


char* board922775252 = gamma_board(board);
assert( board922775252 != NULL );
assert( strcmp(board922775252, 
"34351.25.5.984\n"
"4.546.4469259.\n"
"735.1.1.279.7.\n"
"4288.58.6.138.\n"
"..2....6765..9\n"
"64.69.97.8...9\n"
"95984396...1.3\n"
"7.387.52467836\n"
"3455..454..8..\n"
"9.2.5.4.3.55.1\n"
".69..176..61..\n"
"7892...4.2344.\n") == 0);
free(board922775252);
board922775252 = NULL;
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_move(board, 9, 1, 4) == 1 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_free_fields(board, 1) == 57 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_free_fields(board, 3) == 56 );
assert( gamma_golden_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 4, 9, 3) == 1 );
assert( gamma_move(board, 5, 8, 11) == 1 );
assert( gamma_move(board, 6, 5, 12) == 0 );
assert( gamma_move(board, 7, 2, 4) == 0 );
assert( gamma_move(board, 7, 12, 1) == 1 );
assert( gamma_move(board, 8, 3, 12) == 0 );
assert( gamma_move(board, 8, 4, 3) == 1 );
assert( gamma_move(board, 9, 10, 7) == 0 );
assert( gamma_move(board, 9, 11, 0) == 0 );
assert( gamma_move(board, 1, 5, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 12, 6) == 1 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_golden_move(board, 5, 8, 12) == 0 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_move(board, 6, 6, 7) == 1 );
assert( gamma_move(board, 7, 7, 4) == 0 );
assert( gamma_move(board, 9, 0, 5) == 0 );
assert( gamma_move(board, 9, 4, 5) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 1) == 1 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_golden_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 7, 6, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 8, 13, 2) == 0 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 3, 6) == 0 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_free_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );


char* board813783850 = gamma_board(board);
assert( board813783850 != NULL );
assert( strcmp(board813783850, 
"34351.2555.984\n"
"4.54614469259.\n"
"735.131.279.7.\n"
"4288.58.6.138.\n"
".12...66765..9\n"
"64.69.97.8..49\n"
"95984396...1.3\n"
"79387.52467836\n"
"34558.4544.8..\n"
"9.2.5.4.3.55.1\n"
".69..1761.6173\n"
"7892..24.2344.\n") == 0);
free(board813783850);
board813783850 = NULL;
assert( gamma_move(board, 4, 13, 8) == 1 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_move(board, 7, 6, 1) == 0 );
assert( gamma_free_fields(board, 7) == 44 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 9, 8) == 1 );
assert( gamma_move(board, 9, 8, 5) == 1 );
assert( gamma_busy_fields(board, 9) == 16 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_golden_move(board, 1, 2, 8) == 1 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 6, 3, 10) == 0 );
assert( gamma_move(board, 7, 2, 12) == 0 );
assert( gamma_move(board, 7, 1, 1) == 0 );


char* board413704155 = gamma_board(board);
assert( board413704155 != NULL );
assert( strcmp(board413704155, 
"34351.2555.984\n"
"4.54614469259.\n"
"735.131.279.7.\n"
"4218.58.681384\n"
".12.5.66765..9\n"
"64.69.97.8..49\n"
"959843969..1.3\n"
"79387.52467836\n"
"34558.4544.8..\n"
"9.2.5.4.3355.1\n"
".69..1761.6173\n"
"7892..24.2344.\n") == 0);
free(board413704155);
board413704155 = NULL;
assert( gamma_move(board, 8, 0, 2) == 0 );
assert( gamma_move(board, 9, 13, 6) == 0 );
assert( gamma_move(board, 9, 10, 1) == 0 );


char* board919373675 = gamma_board(board);
assert( board919373675 != NULL );
assert( strcmp(board919373675, 
"34351.2555.984\n"
"4.54614469259.\n"
"735.131.279.7.\n"
"4218.58.681384\n"
".12.5.66765..9\n"
"64.69.97.8..49\n"
"959843969..1.3\n"
"79387.52467836\n"
"34558.4544.8..\n"
"9.2.5.4.3355.1\n"
".69..1761.6173\n"
"7892..24.2344.\n") == 0);
free(board919373675);
board919373675 = NULL;
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 13) == 0 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_free_fields(board, 6) == 41 );
assert( gamma_golden_move(board, 6, 4, 4) == 0 );
assert( gamma_move(board, 7, 6, 6) == 0 );
assert( gamma_move(board, 7, 7, 2) == 1 );
assert( gamma_move(board, 8, 1, 0) == 0 );
assert( gamma_move(board, 8, 4, 4) == 0 );
assert( gamma_move(board, 9, 9, 3) == 0 );
assert( gamma_move(board, 9, 3, 7) == 1 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 10 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 6, 4, 5) == 0 );
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_move(board, 7, 9, 4) == 0 );
assert( gamma_move(board, 7, 12, 3) == 1 );
assert( gamma_move(board, 8, 1, 4) == 0 );
assert( gamma_move(board, 9, 0, 4) == 0 );
assert( gamma_move(board, 9, 6, 1) == 0 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 5, 10, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 11, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 13 );
assert( gamma_free_fields(board, 7) == 34 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 7, 0) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_free_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_free_fields(board, 4) == 34 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 5, 1, 2) == 1 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 7, 9, 11) == 0 );
assert( gamma_move(board, 7, 5, 11) == 1 );
assert( gamma_move(board, 8, 5, 8) == 0 );
assert( gamma_move(board, 8, 6, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_free_fields(board, 8) == 32 );
assert( gamma_move(board, 9, 6, 5) == 0 );
assert( gamma_move(board, 9, 6, 1) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_free_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 12, 7) == 1 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_free_fields(board, 4) == 31 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_free_fields(board, 5) == 31 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_move(board, 7, 12, 6) == 0 );
assert( gamma_move(board, 8, 9, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 5, 11) == 0 );
assert( gamma_move(board, 9, 13, 1) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 5, 8, 2) == 0 );
assert( gamma_move(board, 5, 1, 10) == 1 );
assert( gamma_free_fields(board, 5) == 30 );
assert( gamma_move(board, 7, 1, 4) == 0 );
assert( gamma_golden_move(board, 7, 10, 5) == 0 );
assert( gamma_move(board, 8, 9, 3) == 0 );
assert( gamma_move(board, 9, 5, 12) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 10 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 4, 11, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_move(board, 8, 12, 2) == 1 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 2, 13, 0) == 1 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_move(board, 6, 11, 10) == 0 );
assert( gamma_move(board, 6, 13, 6) == 0 );
assert( gamma_move(board, 7, 4, 11) == 0 );
assert( gamma_move(board, 7, 5, 0) == 1 );
assert( gamma_golden_move(board, 7, 6, 1) == 0 );
assert( gamma_move(board, 8, 6, 5) == 0 );
assert( gamma_move(board, 8, 8, 5) == 0 );
assert( gamma_move(board, 9, 12, 5) == 1 );
assert( gamma_move(board, 9, 5, 4) == 1 );
assert( gamma_busy_fields(board, 9) == 19 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_golden_move(board, 6, 8, 6) == 0 );


char* board171484814 = gamma_board(board);
assert( board171484814 != NULL );
assert( strcmp(board171484814, 
"3435172555.984\n"
"4554614469259.\n"
"735.131127947.\n"
"4218.58.681384\n"
".1295.66765.49\n"
"64.69.97.8..49\n"
"9598439693.193\n"
"79387952467836\n"
"34558.4544587.\n"
"952.5.47335581\n"
".69..1761.6173\n"
"78923724.23442\n") == 0);
free(board171484814);
board171484814 = NULL;
assert( gamma_move(board, 7, 2, 5) == 0 );
assert( gamma_move(board, 8, 10, 7) == 0 );
assert( gamma_free_fields(board, 8) == 24 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 7, 8) == 1 );
assert( gamma_move(board, 9, 2, 11) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 4, 8) == 1 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_free_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 5, 6, 11) == 0 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 6, 0, 8) == 0 );
assert( gamma_move(board, 6, 3, 2) == 1 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_move(board, 7, 3, 8) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 6, 11) == 0 );
assert( gamma_move(board, 9, 0, 2) == 0 );
assert( gamma_free_fields(board, 9) == 8 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_free_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );


char* board557486842 = gamma_board(board);
assert( board557486842 != NULL );
assert( strcmp(board557486842, 
"3435172555.984\n"
"4554614469259.\n"
"735.131127947.\n"
"42181589681384\n"
".1295.66765.49\n"
"64.69.97.8..49\n"
"9598439693.193\n"
"79387952467836\n"
"34558.4544587.\n"
"95265.47335581\n"
".69..1761.6173\n"
"78923724.23442\n") == 0);
free(board557486842);
board557486842 = NULL;
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 4, 3) == 0 );


char* board387514057 = gamma_board(board);
assert( board387514057 != NULL );
assert( strcmp(board387514057, 
"3435172555.984\n"
"4554614469259.\n"
"735.131127947.\n"
"42181589681384\n"
".1295.66765.49\n"
"64.69.97.8..49\n"
"9598439693.193\n"
"79387952467836\n"
"34558.4544587.\n"
"95265.47335581\n"
".69..1761.6173\n"
"78923724.23442\n") == 0);
free(board387514057);
board387514057 = NULL;
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 8, 9, 3) == 0 );
assert( gamma_move(board, 9, 10, 4) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 5, 6, 5) == 0 );
assert( gamma_move(board, 5, 3, 1) == 1 );


char* board867498546 = gamma_board(board);
assert( board867498546 != NULL );
assert( strcmp(board867498546, 
"3435172555.984\n"
"4554614469259.\n"
"735.131127947.\n"
"42181589681384\n"
".1295.66765.49\n"
"64.69.97.8..49\n"
"9598439693.193\n"
"79387952467836\n"
"34558.4544587.\n"
"95265.47335581\n"
".695.1761.6173\n"
"78923724.23442\n") == 0);
free(board867498546);
board867498546 = NULL;
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 7, 3, 0) == 0 );


char* board951394592 = gamma_board(board);
assert( board951394592 != NULL );
assert( strcmp(board951394592, 
"3435172555.984\n"
"4554614469259.\n"
"735.131127947.\n"
"42181589681384\n"
".1295.66765.49\n"
"64.69.97.8..49\n"
"9598439693.193\n"
"79387952467836\n"
"34558.4544587.\n"
"95265.47335581\n"
".695.1761.6173\n"
"78923724.23442\n") == 0);
free(board951394592);
board951394592 = NULL;
assert( gamma_move(board, 8, 2, 5) == 0 );
assert( gamma_move(board, 9, 12, 2) == 0 );
assert( gamma_move(board, 9, 4, 10) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );


char* board956836320 = gamma_board(board);
assert( board956836320 != NULL );
assert( strcmp(board956836320, 
"3435172555.984\n"
"4554614469259.\n"
"735.131127947.\n"
"42181589681384\n"
".1295.66765.49\n"
"64.69.97.8..49\n"
"9598439693.193\n"
"79387952467836\n"
"34558.4544587.\n"
"95265.47335581\n"
".695.1761.6173\n"
"78923724.23442\n") == 0);
free(board956836320);
board956836320 = NULL;
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


gamma_delete(board);

    return 0;
}
