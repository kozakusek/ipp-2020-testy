#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 134779418
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(16, 18, 4, 23);
assert( board != NULL );


assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_free_fields(board, 4) == 284 );
assert( gamma_golden_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_move(board, 2, 14, 6) == 1 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 3, 13, 11) == 1 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 4, 5, 7) == 1 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 1, 3, 16) == 1 );
assert( gamma_move(board, 2, 8, 15) == 1 );
assert( gamma_move(board, 2, 7, 17) == 1 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 4, 9, 3) == 1 );
assert( gamma_move(board, 4, 1, 16) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 2, 17, 6) == 0 );
assert( gamma_move(board, 3, 11, 0) == 1 );
assert( gamma_free_fields(board, 3) == 268 );
assert( gamma_move(board, 4, 3, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 6 );
assert( gamma_move(board, 1, 10, 7) == 1 );
assert( gamma_move(board, 3, 8, 14) == 1 );
assert( gamma_move(board, 4, 12, 13) == 1 );
assert( gamma_move(board, 4, 7, 4) == 1 );
assert( gamma_move(board, 1, 12, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 10) == 1 );
assert( gamma_move(board, 2, 6, 17) == 1 );
assert( gamma_move(board, 3, 11, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_move(board, 1, 16, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 16) == 1 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 4, 10, 14) == 1 );


char* board100162405 = gamma_board(board);
assert( board100162405 != NULL );
assert( strcmp(board100162405, 
"......22........\n"
".4.1..3.........\n"
"........2.......\n"
"........3.4..1..\n"
"............4...\n"
"......3.........\n"
".............3..\n"
"...............2\n"
"...3...1........\n"
"...4............\n"
".....4....1.....\n"
"....3.........2.\n"
"....4.4....4....\n"
".......4...41...\n"
".........4......\n"
"1...........1...\n"
"........2..32...\n"
"..4..3.....3....\n") == 0);
free(board100162405);
board100162405 = NULL;
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_move(board, 1, 3, 16) == 0 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_free_fields(board, 1) == 252 );
assert( gamma_move(board, 2, 5, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 15, 4) == 1 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 1, 9, 13) == 1 );
assert( gamma_move(board, 1, 15, 15) == 1 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 14) == 1 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 4, 15, 10) == 0 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_free_fields(board, 2) == 243 );
assert( gamma_move(board, 3, 15, 12) == 1 );
assert( gamma_golden_move(board, 3, 15, 8) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_free_fields(board, 4) == 242 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 15) == 1 );
assert( gamma_move(board, 3, 11, 6) == 1 );
assert( gamma_free_fields(board, 3) == 238 );
assert( gamma_free_fields(board, 4) == 238 );
assert( gamma_move(board, 1, 14, 10) == 1 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 16, 4) == 0 );
assert( gamma_move(board, 3, 5, 16) == 1 );
assert( gamma_move(board, 4, 13, 14) == 0 );
assert( gamma_move(board, 4, 12, 3) == 1 );
assert( gamma_move(board, 1, 1, 5) == 1 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 14, 5) == 1 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 14, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 3, 9, 4) == 1 );
assert( gamma_move(board, 4, 1, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 4, 10, 17) == 1 );
assert( gamma_move(board, 1, 3, 4) == 1 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_move(board, 2, 5, 15) == 1 );
assert( gamma_free_fields(board, 2) == 217 );
assert( gamma_move(board, 3, 4, 17) == 1 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 1, 13, 5) == 1 );
assert( gamma_move(board, 1, 11, 16) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 3, 12, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_golden_move(board, 3, 14, 10) == 1 );
assert( gamma_move(board, 4, 7, 10) == 1 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_free_fields(board, 4) == 208 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_golden_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_free_fields(board, 2) == 206 );
assert( gamma_golden_move(board, 2, 0, 10) == 0 );


char* board797749650 = gamma_board(board);
assert( board797749650 != NULL );
assert( strcmp(board797749650, 
"....3.22..4.....\n"
".4.1.33....1....\n"
".....2..2.....21\n"
"........3.4.31..\n"
".........1..4...\n"
"...2..3........3\n"
"........4....31.\n"
".21....42.....32\n"
"...3...1...3....\n"
"...4.....3.1....\n"
"..1..4....1.3...\n"
"....3.2.2..3..2.\n"
".1..4.4....4.14.\n"
"...11..423241..3\n"
"1....2...4..4...\n"
"1..41.4.23..1...\n"
".3.....22..32...\n"
".44..3....13....\n") == 0);
free(board797749650);
board797749650 = NULL;
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 23 );


char* board407708646 = gamma_board(board);
assert( board407708646 != NULL );
assert( strcmp(board407708646, 
"....3.22..4.....\n"
".4.1.33....1....\n"
".....2..2.....21\n"
"........3.4.31..\n"
".........1..4...\n"
"...2..3........3\n"
"........4....31.\n"
".21....42.....32\n"
"...3...1...3....\n"
"...4.....3.1....\n"
"..1..4....1.3...\n"
"....3.2.2..3..2.\n"
".1..4.4....4.14.\n"
"...11..423241..3\n"
"1....2...4..4...\n"
"1..41.4.23..1...\n"
".3.....22..32...\n"
"344..3....13....\n") == 0);
free(board407708646);
board407708646 = NULL;
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 1, 3, 15) == 1 );
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_free_fields(board, 2) == 201 );
assert( gamma_move(board, 3, 9, 16) == 1 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 1, 10, 9) == 1 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_golden_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 14, 0) == 1 );


char* board740645202 = gamma_board(board);
assert( board740645202 != NULL );
assert( strcmp(board740645202, 
"....3.22..4.....\n"
".4.1.33..3.1....\n"
"...1.2..2.....21\n"
"....2...3.4.31..\n"
"......1..1..4...\n"
"...2..3........3\n"
"...4....4....31.\n"
".21....42.....32\n"
"...3...1..13....\n"
"...4.....3.1....\n"
"..1..4....1.3...\n"
"....3.2.2.23..2.\n"
".1..4.4....4.14.\n"
"...11..423241..3\n"
"1....2...4..4...\n"
"1..41.4.23..1...\n"
".3.....22..32...\n"
"344..34...13..3.\n") == 0);
free(board740645202);
board740645202 = NULL;
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_move(board, 4, 12, 9) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 4, 10, 5) == 1 );
assert( gamma_move(board, 4, 10, 12) == 1 );
assert( gamma_golden_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 1, 12, 5) == 1 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_move(board, 2, 2, 15) == 1 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 17, 12) == 0 );


char* board707569784 = gamma_board(board);
assert( board707569784 != NULL );
assert( strcmp(board707569784, 
"....3.22..4.....\n"
".4.1.33..3.1....\n"
"..21.2..2.....21\n"
"....2...3.4.31..\n"
".1.1..1..1..4...\n"
"...2..3...4....3\n"
"...4....4....31.\n"
".21....42.....32\n"
"...3...1..1342..\n"
"...4.....3.1....\n"
"..1..4....133...\n"
"..1.3.2.2.23..2.\n"
".1..4.4...44114.\n"
"...14..423241..3\n"
"1...42...4..4...\n"
"1..41.4.23..1...\n"
".33....22..32...\n"
"344..34...13..3.\n") == 0);
free(board707569784);
board707569784 = NULL;
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 4, 12, 8) == 1 );
assert( gamma_move(board, 1, 7, 13) == 1 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 4, 6, 7) == 1 );
assert( gamma_move(board, 1, 16, 2) == 0 );
assert( gamma_free_fields(board, 1) == 180 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 2, 12, 15) == 1 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 1, 16, 14) == 0 );
assert( gamma_move(board, 1, 4, 9) == 1 );
assert( gamma_move(board, 2, 5, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_free_fields(board, 1) == 64 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 16, 7) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 4, 13, 8) == 1 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 4, 10, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_free_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 1, 14, 17) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 14, 7) == 1 );
assert( gamma_free_fields(board, 2) == 56 );
assert( gamma_move(board, 3, 12, 11) == 1 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 1, 8, 10) == 0 );
assert( gamma_move(board, 2, 4, 17) == 0 );
assert( gamma_move(board, 2, 10, 17) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 10, 11) == 1 );
assert( gamma_move(board, 4, 11, 13) == 1 );
assert( gamma_busy_fields(board, 4) == 34 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_move(board, 2, 17, 11) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 4, 5, 10) == 0 );


char* board368236424 = gamma_board(board);
assert( board368236424 != NULL );
assert( strcmp(board368236424, 
"....3.22..4.....\n"
".4.1.33..3.1....\n"
"..21.2..2...2.21\n"
"....2...3.4.31..\n"
".131..11.1.44...\n"
"...2..3...4....3\n"
"...4....4.4.331.\n"
".21....42.....32\n"
"2..31..1..1342..\n"
"...4.2...3.144..\n"
"..1..44...133.2.\n"
"..1.3.2.2.23..2.\n"
".1..4.4.2.44114.\n"
"4..14..423241..3\n"
"1...422..44.4...\n"
"1..41.4.23..1...\n"
".33....223.32...\n"
"344..34...13..3.\n") == 0);
free(board368236424);
board368236424 = NULL;
assert( gamma_move(board, 1, 3, 17) == 1 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 2, 15, 14) == 0 );
assert( gamma_move(board, 3, 11, 16) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 2, 17, 12) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 3, 12, 12) == 1 );
assert( gamma_move(board, 4, 16, 7) == 0 );
assert( gamma_golden_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_golden_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 7) == 1 );
assert( gamma_move(board, 1, 16, 14) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 4, 14, 16) == 0 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 1, 2, 17) == 1 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 12, 6) == 1 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_golden_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_free_fields(board, 3) == 54 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 17, 0) == 0 );


char* board646446895 = gamma_board(board);
assert( board646446895 != NULL );
assert( strcmp(board646446895, 
"..113.22..4.....\n"
".4.1.33..3.1....\n"
"..21.2..2...2.21\n"
"....2...3.4.31..\n"
".131..11.1.44...\n"
"...2..3...4.3..3\n"
"..44....4.4.331.\n"
".21....42.....32\n"
"2..31..1.31342..\n"
"...4.2...3.144..\n"
"..1..444..13342.\n"
"..1.3.2.2.231.2.\n"
".1..424.2244114.\n"
"4..14..423241..3\n"
"1..1422..44.4...\n"
"1..41.4.23..1...\n"
".33.1..223.32...\n"
"344..34...13..3.\n") == 0);
free(board646446895);
board646446895 = NULL;
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 2, 16, 15) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_free_fields(board, 2) == 54 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_free_fields(board, 3) == 54 );
assert( gamma_move(board, 4, 11, 11) == 1 );
assert( gamma_free_fields(board, 4) == 55 );
assert( gamma_golden_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 15) == 1 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_move(board, 4, 10, 15) == 1 );
assert( gamma_golden_move(board, 4, 7, 14) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 16, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_golden_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );


char* board167314765 = gamma_board(board);
assert( board167314765 != NULL );
assert( strcmp(board167314765, 
"..113.22..4.....\n"
".4.1.33..3.1....\n"
"..21.23.2.4.2.21\n"
"....2...3.4.31..\n"
".131..11.1.44...\n"
"...2..3...4.3..3\n"
"..44....4.44331.\n"
".21....42.....32\n"
"2..311.1.31342..\n"
"...4.2...3.144..\n"
"..1..4444.13342.\n"
"..1.3.2.2.231.2.\n"
".1..424.2244114.\n"
"4..14..423241..3\n"
"1..1422..44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34...13..3.\n") == 0);
free(board167314765);
board167314765 = NULL;
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 15, 0) == 1 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 9, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 36 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_free_fields(board, 4) == 56 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 3, 4, 17) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 4, 2, 16) == 1 );
assert( gamma_move(board, 1, 16, 12) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 16, 8) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 1, 9, 14) == 1 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 4, 9, 12) == 1 );
assert( gamma_move(board, 4, 6, 13) == 0 );


char* board361681450 = gamma_board(board);
assert( board361681450 != NULL );
assert( strcmp(board361681450, 
"..113.22..4.....\n"
".441.33..3.1....\n"
"..21.23.2.4.2.21\n"
"....2...314.31..\n"
".131..11.1.44...\n"
"...2..3..44.3..3\n"
"..44....4.44331.\n"
".21....42.....32\n"
"2..311.1.31342..\n"
"...4.2...3.144..\n"
"..1..4444313342.\n"
"..1.3.2.2.231.2.\n"
".1..424.2244114.\n"
"4..14..423241..3\n"
"1..1422..44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34...13..33\n") == 0);
free(board361681450);
board361681450 = NULL;
assert( gamma_move(board, 1, 14, 15) == 0 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_move(board, 2, 16, 13) == 0 );
assert( gamma_free_fields(board, 2) == 50 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 3, 17) == 0 );


char* board840291196 = gamma_board(board);
assert( board840291196 != NULL );
assert( strcmp(board840291196, 
"..113.22..4.....\n"
".441.33..3.1....\n"
"..21.23.2.4.2.21\n"
"....2...314.31..\n"
".131..11.1.44...\n"
"...2..3..44.3..3\n"
"..44....4.44331.\n"
".21....42.....32\n"
"2..311.1.31342..\n"
"...4.2...31144..\n"
"..1..4444313342.\n"
"..1.3.2.2.231.2.\n"
".1..424.2244114.\n"
"4..14..423241..3\n"
"1..1422..44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34...13..33\n") == 0);
free(board840291196);
board840291196 = NULL;
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 13) == 0 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_move(board, 1, 14, 15) == 0 );
assert( gamma_move(board, 2, 14, 14) == 1 );
assert( gamma_move(board, 2, 8, 16) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 10) == 1 );


char* board888171861 = gamma_board(board);
assert( board888171861 != NULL );
assert( strcmp(board888171861, 
"..113.22..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"....2...3143312.\n"
".131..11.1.44...\n"
"...2..3..44.3..3\n"
"..44....4.44331.\n"
".21....423....32\n"
"2..311.1.31342..\n"
"...4.2.1.31144..\n"
"..1..4444313342.\n"
"..1.3.2.2.231.2.\n"
".1..424.2244114.\n"
"4..14..423241..3\n"
"1..1422..44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.13..33\n") == 0);
free(board888171861);
board888171861 = NULL;
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 4, 8, 11) == 0 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_free_fields(board, 1) == 136 );


char* board646203228 = gamma_board(board);
assert( board646203228 != NULL );
assert( strcmp(board646203228, 
"..113.22..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"....2...3143312.\n"
".131..11.1.44...\n"
"...2..3..44.3..3\n"
"..44....4.44331.\n"
".21....423....32\n"
"2..311.1.31342..\n"
"...4.2.1.31144..\n"
"..1..4444313342.\n"
"..1.3.2.2.231.2.\n"
".1..424.2244114.\n"
"4..14..423241..3\n"
"1..1422..44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.13..33\n") == 0);
free(board646203228);
board646203228 = NULL;
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 10, 13) == 1 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_golden_move(board, 2, 14, 13) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 2, 14) == 1 );
assert( gamma_move(board, 2, 15, 15) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 5, 17) == 1 );
assert( gamma_move(board, 4, 8, 13) == 1 );
assert( gamma_free_fields(board, 4) == 130 );
assert( gamma_golden_move(board, 1, 7, 13) == 0 );


char* board560590081 = gamma_board(board);
assert( board560590081 != NULL );
assert( strcmp(board560590081, 
"..113322..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.3..3\n"
"..44....4.44331.\n"
".21....423....32\n"
"2..311.1.31342..\n"
"..44.2.1.31144..\n"
"..1..4444313342.\n"
"..1.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..1422..44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.13..33\n") == 0);
free(board560590081);
board560590081 = NULL;
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 16, 14) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board380110259 = gamma_board(board);
assert( board380110259 != NULL );
assert( strcmp(board380110259, 
"..113322..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.3..3\n"
"..44....4.44331.\n"
".21....423....32\n"
"2..311.1.31342..\n"
"..44.2.1.31144..\n"
"..1..4444313342.\n"
"..1.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..1422..44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.13..33\n") == 0);
free(board380110259);
board380110259 = NULL;
assert( gamma_move(board, 2, 16, 12) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 11, 11) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 4, 7, 3) == 1 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_free_fields(board, 2) == 47 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 3, 15, 7) == 1 );
assert( gamma_move(board, 4, 15, 11) == 1 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_free_fields(board, 1) == 127 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 6, 11) == 1 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 0) == 1 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_free_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_move(board, 1, 15, 9) == 1 );
assert( gamma_free_fields(board, 1) == 58 );


char* board156118067 = gamma_board(board);
assert( board156118067 != NULL );
assert( strcmp(board156118067, 
"..113322..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.3..3\n"
"..44.13.4.443314\n"
".21....423....32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..1..44443133423\n"
"..1.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..14224.44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.133.33\n") == 0);
free(board156118067);
board156118067 = NULL;
assert( gamma_move(board, 2, 1, 1) == 0 );


char* board337746216 = gamma_board(board);
assert( board337746216 != NULL );
assert( strcmp(board337746216, 
"..113322..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.3..3\n"
"..44.13.4.443314\n"
".21....423....32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..1..44443133423\n"
"..1.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..14224.44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.133.33\n") == 0);
free(board337746216);
board337746216 = NULL;
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );


char* board288064922 = gamma_board(board);
assert( board288064922 != NULL );
assert( strcmp(board288064922, 
"..113322..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.3..3\n"
"..44.13.4.443314\n"
".21....423....32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..1..44443133423\n"
"..1.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..14224.44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.133.33\n") == 0);
free(board288064922);
board288064922 = NULL;
assert( gamma_move(board, 1, 1, 6) == 1 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 2, 9, 16) == 0 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_free_fields(board, 2) == 43 );


char* board761084953 = gamma_board(board);
assert( board761084953 != NULL );
assert( strcmp(board761084953, 
"..113322..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.3..3\n"
"..44.13.4.443314\n"
".21....423....32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..1..44443133423\n"
".11.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..14224.44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.133.33\n") == 0);
free(board761084953);
board761084953 = NULL;
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_golden_move(board, 1, 15, 14) == 0 );


char* board243626840 = gamma_board(board);
assert( board243626840 != NULL );
assert( strcmp(board243626840, 
"..113322..4.....\n"
".441.33.23.1....\n"
"..21.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.3..3\n"
"..44.13.4.443314\n"
".21....423....32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..1..44443133423\n"
".11.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..14224.44.4...\n"
"1.341.4.23..1...\n"
".33.1..223.32...\n"
"344..34.2.133.33\n") == 0);
free(board243626840);
board243626840 = NULL;
assert( gamma_move(board, 2, 2, 16) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 1, 13, 12) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_free_fields(board, 4) == 49 );
assert( gamma_golden_move(board, 4, 12, 12) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_free_fields(board, 3) == 49 );
assert( gamma_move(board, 4, 2, 17) == 0 );
assert( gamma_move(board, 2, 1, 15) == 1 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );


char* board406392895 = gamma_board(board);
assert( board406392895 != NULL );
assert( strcmp(board406392895, 
"..113322..4.....\n"
".441.33.23.1....\n"
".221.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....423....32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..1..44443133423\n"
".11.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..14224.44.4...\n"
"1.34144.23..1...\n"
".33.1..223.32...\n"
"344..34.2.133.33\n") == 0);
free(board406392895);
board406392895 = NULL;
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );


char* board592175065 = gamma_board(board);
assert( board592175065 != NULL );
assert( strcmp(board592175065, 
"..113322..4.....\n"
".441.33.23.1....\n"
".221.23.2.4.2.21\n"
"..2.2...3143312.\n"
".131..1141444...\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....423....32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..1..44443133423\n"
".11.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..14224.44.4...\n"
"1.34144.23..1...\n"
".33.1..223.32...\n"
"344..34.2.133.33\n") == 0);
free(board592175065);
board592175065 = NULL;
assert( gamma_move(board, 2, 7, 17) == 0 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 2, 15, 14) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 4, 6, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 1, 10, 1) == 1 );


char* board766535649 = gamma_board(board);
assert( board766535649 != NULL );
assert( strcmp(board766535649, 
"..113322..4.....\n"
".441.33.23.1....\n"
".221.23.2.4.2.21\n"
"..2.2...31433122\n"
".131..1141444...\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..1..44443133423\n"
".11.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"1..14224.44.4...\n"
"1.34144.23..1...\n"
".33.1.4223132...\n"
"344..34.2.133.33\n") == 0);
free(board766535649);
board766535649 = NULL;
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 4, 8, 15) == 0 );
assert( gamma_move(board, 4, 3, 7) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 4, 14, 15) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 52 );
assert( gamma_move(board, 1, 1, 15) == 0 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_free_fields(board, 3) == 46 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 4, 7, 0) == 1 );
assert( gamma_move(board, 1, 13, 15) == 1 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 45 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_free_fields(board, 3) == 45 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 4, 4, 13) == 1 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_free_fields(board, 2) == 38 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 3, 10, 16) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 2, 17, 12) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_free_fields(board, 2) == 38 );
assert( gamma_move(board, 3, 16, 12) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_golden_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 38 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_move(board, 4, 9, 15) == 1 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );


char* board512761739 = gamma_board(board);
assert( board512761739 != NULL );
assert( strcmp(board512761739, 
"..113322..4.....\n"
".441.33.2331....\n"
".221.23.244.2121\n"
".22.2.3.31433122\n"
".1314.1141444...\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.31342.1\n"
"..44.2.1.31144..\n"
"..14.44443133423\n"
".11.3.2.2.231.2.\n"
".1.1424.2244114.\n"
"4..14..423241..3\n"
"11.14224.44.4...\n"
"1.34144.23411...\n"
".33.134223132...\n"
"344..3442.133.33\n") == 0);
free(board512761739);
board512761739 = NULL;
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 3, 15, 15) == 0 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 4, 15, 5) == 1 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 45 );
assert( gamma_move(board, 4, 16, 4) == 0 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 1, 15, 17) == 0 );
assert( gamma_move(board, 2, 14, 9) == 1 );
assert( gamma_move(board, 3, 12, 12) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 4, 3, 17) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_free_fields(board, 1) == 45 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 16, 15) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 1, 17, 11) == 0 );
assert( gamma_move(board, 1, 4, 15) == 1 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 8, 17) == 0 );
assert( gamma_busy_fields(board, 4) == 56 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_golden_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 11, 11) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_free_fields(board, 2) == 36 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 57 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 1, 12, 16) == 1 );
assert( gamma_busy_fields(board, 2) == 40 );
assert( gamma_free_fields(board, 3) == 39 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 16) == 1 );
assert( gamma_golden_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_move(board, 2, 15, 17) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_free_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 1, 6, 15) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_golden_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 12, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 58 );


char* board875850578 = gamma_board(board);
assert( board875850578 != NULL );
assert( strcmp(board875850578, 
"..113322..4.....\n"
"4441.33.23311...\n"
".221123.244.2121\n"
".22.2.3.31433122\n"
".1314.1141444...\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.3134221\n"
"2.44.2.1431144..\n"
"..14.44443133423\n"
".11.3.2.2.231.2.\n"
".1.1424.22441144\n"
"4..14..423241..3\n"
"11.14224.44.4...\n"
"1.34144.23411...\n"
".33.134223132...\n"
"344..3442.133.33\n") == 0);
free(board875850578);
board875850578 = NULL;
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 14, 16) == 1 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_free_fields(board, 3) == 39 );
assert( gamma_golden_move(board, 3, 4, 12) == 0 );


char* board588020204 = gamma_board(board);
assert( board588020204 != NULL );
assert( strcmp(board588020204, 
"..113322..4.....\n"
"4441.33.23311.2.\n"
".221123.244.2121\n"
".22.2.3.31433122\n"
".1314.1141444...\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.3134221\n"
"2.44.2.1431144..\n"
"..14.44443133423\n"
".11.3.2.2.231.2.\n"
".1.1424.22441144\n"
"4..14..423241..3\n"
"11.14224.44.4...\n"
"1.34144.23411...\n"
".33.134223132...\n"
"344..3442.133.33\n") == 0);
free(board588020204);
board588020204 = NULL;
assert( gamma_move(board, 4, 13, 14) == 0 );
assert( gamma_free_fields(board, 4) == 44 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_move(board, 1, 3, 6) == 1 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_free_fields(board, 1) == 93 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_move(board, 3, 5, 14) == 1 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 1, 9, 0) == 1 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );


char* board242972442 = gamma_board(board);
assert( board242972442 != NULL );
assert( strcmp(board242972442, 
"..113322..4.....\n"
"4441.33.23311.2.\n"
".221123.244.2121\n"
".22.233.31433122\n"
".1314.1141444...\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.3134221\n"
"2.44.2.1431144..\n"
"..14.44443133423\n"
".1113.2.2.231.2.\n"
".1.1424.22441144\n"
"4..14..423241..3\n"
"11.14224.44.4...\n"
"1334144.23411...\n"
".33.134223132...\n"
"344..34421133.33\n") == 0);
free(board242972442);
board242972442 = NULL;
assert( gamma_move(board, 4, 13, 13) == 1 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_free_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 12, 5) == 0 );


char* board869831595 = gamma_board(board);
assert( board869831595 != NULL );
assert( strcmp(board869831595, 
"..113322..4.....\n"
"4441.33.23311.2.\n"
".221123.244.2121\n"
".22.233.31433122\n"
".1314.11414444..\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.3134221\n"
"2.44.2.1431144..\n"
"..14.44443133423\n"
".1113.2.2.231.2.\n"
".1.1424122441144\n"
"4..14..423241..3\n"
"11.14224.44.4...\n"
"1334144.23411...\n"
".33.134223132...\n"
"344..34421133.33\n") == 0);
free(board869831595);
board869831595 = NULL;
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );


char* board628399145 = gamma_board(board);
assert( board628399145 != NULL );
assert( strcmp(board628399145, 
"..113322..4.....\n"
"4441.33.23311.2.\n"
".221123.244.2121\n"
".22.233.31433122\n"
".1314.11414444..\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.3134221\n"
"2.44.2.1431144..\n"
"..14.44443133423\n"
".1113.2.2.231.2.\n"
".1.1424122441144\n"
"4..14..423241..3\n"
"11.14224.44.4...\n"
"1334144.23411...\n"
".33.134223132...\n"
"344..34421133.33\n") == 0);
free(board628399145);
board628399145 = NULL;
assert( gamma_move(board, 4, 15, 2) == 0 );
assert( gamma_move(board, 4, 14, 4) == 1 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 17, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 1, 15) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 4, 14, 8) == 1 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_free_fields(board, 1) == 40 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board718560847 = gamma_board(board);
assert( board718560847 != NULL );
assert( strcmp(board718560847, 
"..113322..4.....\n"
"4441.33.23311.2.\n"
".221123.244.2121\n"
".22.233.31433122\n"
".1314.11414444..\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.3134221\n"
"2.44.2.14311444.\n"
"..14.44443133423\n"
".1113.2.2.231.2.\n"
".1.1424122441144\n"
"4..14..423241.43\n"
"11.14224.44.4...\n"
"1334144.23411...\n"
".33.134223132...\n"
"344..34421133.33\n") == 0);
free(board718560847);
board718560847 = NULL;
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 4, 2, 2) == 0 );
assert( gamma_move(board, 1, 17, 13) == 0 );
assert( gamma_move(board, 2, 1, 17) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 16, 7) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 1, 13, 13) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 4, 15, 2) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 1, 13, 14) == 0 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 4, 17, 13) == 0 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 2, 8, 15) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_free_fields(board, 3) == 35 );
assert( gamma_move(board, 4, 17, 12) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );


char* board174906801 = gamma_board(board);
assert( board174906801 != NULL );
assert( strcmp(board174906801, 
"..113322..4.....\n"
"4441.33.23311.2.\n"
".221123.244.2121\n"
".22.233.31433122\n"
".1314.11414444..\n"
"...2..3..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.3134221\n"
"2.44.2.14311444.\n"
"..14.44443133423\n"
".1113.2.2.231.2.\n"
".1.1424122441144\n"
"4..14..423241.43\n"
"11.14224.44.4...\n"
"1334144.23411...\n"
".33.134223132...\n"
"344..34421133.33\n") == 0);
free(board174906801);
board174906801 = NULL;
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 3, 7, 15) == 1 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 11, 3) == 1 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 3, 16, 13) == 0 );
assert( gamma_move(board, 3, 15, 13) == 1 );
assert( gamma_move(board, 4, 0, 6) == 1 );
assert( gamma_move(board, 4, 5, 12) == 1 );


char* board123057122 = gamma_board(board);
assert( board123057122 != NULL );
assert( strcmp(board123057122, 
"..113322..4.....\n"
"4441.33.23311.2.\n"
".2211233244.2121\n"
".22.233.31433122\n"
".1314.11414444.3\n"
"...2.43..44.31.3\n"
"..44.13.4.443314\n"
".21....4234...32\n"
"2..311.1.3134221\n"
"2.44.2.14311444.\n"
"..14.44443133423\n"
"41113.2.22231.2.\n"
".1.1424122441144\n"
"4..14..423241.43\n"
"11.14224.4444...\n"
"1334144.23411...\n"
".33.134223132...\n"
"344..34421133.33\n") == 0);
free(board123057122);
board123057122 = NULL;
assert( gamma_move(board, 1, 17, 15) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_move(board, 2, 14, 16) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 7, 6) == 0 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 13, 13) == 0 );
assert( gamma_free_fields(board, 2) == 81 );
assert( gamma_move(board, 3, 8, 17) == 0 );
assert( gamma_move(board, 3, 5, 17) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 4, 12, 13) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_free_fields(board, 1) == 80 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 7, 5) == 1 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 16, 7) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_golden_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 15) == 0 );
assert( gamma_move(board, 2, 11, 17) == 1 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_free_fields(board, 1) == 79 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_golden_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 3, 15, 12) == 0 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_free_fields(board, 4) == 42 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_free_fields(board, 3) == 32 );
assert( gamma_move(board, 4, 15, 4) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_golden_move(board, 4, 17, 6) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 4, 16, 7) == 0 );
assert( gamma_free_fields(board, 4) == 77 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 53 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 9, 16) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 1, 13, 4) == 1 );


char* board507042626 = gamma_board(board);
assert( board507042626 != NULL );
assert( strcmp(board507042626, 
"..113322..42....\n"
"4441.33.23311.2.\n"
".2211233244.2121\n"
".22.233.31433122\n"
"11314.11414444.3\n"
"...2.43.444.31.3\n"
"..44.1334.443314\n"
".21....4234...32\n"
"2..31111.3134221\n"
"2.44.2.14311444.\n"
"..14.44443133423\n"
"41113.2.22231.2.\n"
".1.1424222441144\n"
"4..14..423241143\n"
"11.14224.4444...\n"
"1334144.23411...\n"
".33.134223132...\n"
"344..34421133.33\n") == 0);
free(board507042626);
board507042626 = NULL;
assert( gamma_move(board, 2, 17, 13) == 0 );
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 4, 14, 9) == 0 );


char* board938666406 = gamma_board(board);
assert( board938666406 != NULL );
assert( strcmp(board938666406, 
"..113322..42....\n"
"4441.33.23311.2.\n"
".2211233244.2121\n"
".22.233.31433122\n"
"11314.11414444.3\n"
"...2.43.444.31.3\n"
"..44.1334.443314\n"
".21....4234...32\n"
"2..31111.3134221\n"
"2.44.2.14311444.\n"
"..14.44443133423\n"
"41113.2.22231.2.\n"
".1.1424222441144\n"
"4..14..423241143\n"
"11.1422424444...\n"
"1334144.23411...\n"
".33.134223132...\n"
"344..34421133.33\n") == 0);
free(board938666406);
board938666406 = NULL;
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_move(board, 2, 4, 16) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 14, 3) == 1 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 16, 15) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_golden_move(board, 2, 11, 11) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 7, 12) == 1 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_busy_fields(board, 2) == 47 );
assert( gamma_free_fields(board, 2) == 28 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 4, 4, 12) == 1 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_move(board, 1, 16, 13) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 68 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board800862336 = gamma_board(board);
assert( board800862336 != NULL );
assert( strcmp(board800862336, 
"..113322..42....\n"
"4441233.23311.2.\n"
"22211233244.2121\n"
"122.233.31433122\n"
"11314.11414444.3\n"
"...24434444.31.3\n"
"..44.1334.443314\n"
".21....4234...32\n"
"2..31111.3134221\n"
"2.44.2.14311444.\n"
"..14.44443133423\n"
"41113.2.22231.2.\n"
".1.1424222441144\n"
"4..14..423241143\n"
"11.1422424444.4.\n"
"1334144.23411...\n"
".333134223132...\n"
"344..34421133.33\n") == 0);
free(board800862336);
board800862336 = NULL;
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_free_fields(board, 4) == 66 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_golden_move(board, 1, 13, 12) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 4, 16, 7) == 0 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 17, 0) == 0 );


gamma_delete(board);

    return 0;
}
