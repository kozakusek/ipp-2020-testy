#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 105875188
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 16, 8, 17);
assert( board != NULL );


assert( gamma_move(board, 1, 9, 2) == 1 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 3, 7, 12) == 1 );
assert( gamma_move(board, 4, 7, 6) == 1 );
assert( gamma_move(board, 5, 12, 9) == 0 );
assert( gamma_move(board, 6, 12, 0) == 0 );
assert( gamma_move(board, 6, 6, 8) == 1 );
assert( gamma_move(board, 7, 11, 10) == 1 );
assert( gamma_move(board, 8, 5, 3) == 1 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 3 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_free_fields(board, 2) == 181 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 4, 10, 15) == 1 );
assert( gamma_move(board, 5, 15, 3) == 0 );
assert( gamma_move(board, 5, 8, 7) == 1 );
assert( gamma_move(board, 7, 0, 3) == 1 );
assert( gamma_move(board, 8, 4, 8) == 1 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 3, 7) == 1 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 4, 11, 11) == 1 );
assert( gamma_move(board, 5, 7, 2) == 1 );
assert( gamma_free_fields(board, 5) == 168 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 10) == 1 );
assert( gamma_move(board, 7, 4, 13) == 1 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_free_fields(board, 8) == 166 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_move(board, 3, 9, 0) == 1 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_move(board, 6, 9, 10) == 1 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 8, 2, 11) == 1 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_move(board, 1, 8, 2) == 1 );
assert( gamma_move(board, 2, 11, 15) == 1 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 4, 5, 12) == 1 );
assert( gamma_move(board, 5, 11, 9) == 1 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 6, 5, 10) == 0 );
assert( gamma_move(board, 6, 3, 0) == 1 );
assert( gamma_free_fields(board, 6) == 148 );
assert( gamma_move(board, 7, 6, 8) == 0 );
assert( gamma_golden_move(board, 7, 11, 5) == 0 );
assert( gamma_move(board, 8, 9, 3) == 1 );
assert( gamma_move(board, 8, 11, 14) == 1 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 10, 7) == 1 );
assert( gamma_move(board, 2, 10, 12) == 1 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 4, 2, 4) == 1 );
assert( gamma_move(board, 5, 6, 15) == 1 );
assert( gamma_move(board, 6, 10, 3) == 1 );
assert( gamma_move(board, 6, 7, 13) == 1 );
assert( gamma_move(board, 7, 10, 1) == 1 );
assert( gamma_free_fields(board, 7) == 136 );
assert( gamma_move(board, 8, 15, 7) == 0 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_free_fields(board, 1) == 135 );
assert( gamma_move(board, 2, 11, 12) == 1 );


char* board793278195 = gamma_board(board);
assert( board793278195 != NULL );
assert( strcmp(board793278195, 
"......5...42\n"
".......2...8\n"
"....7..6..2.\n"
".....4.3..22\n"
"..8..2..4..4\n"
".....2..66.7\n"
".......1.4.5\n"
".5..8.6...1.\n"
"...2....5.1.\n"
"1.....34..3.\n"
".....2.3....\n"
"..431.......\n"
"71...8...86.\n"
".4...4.511..\n"
"....4.231.71\n"
"...6.3...3..\n") == 0);
free(board793278195);
board793278195 = NULL;
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 9, 7) == 1 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_move(board, 6, 13, 11) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_free_fields(board, 6) == 131 );
assert( gamma_move(board, 7, 7, 11) == 1 );
assert( gamma_move(board, 7, 10, 8) == 0 );
assert( gamma_move(board, 8, 7, 1) == 0 );
assert( gamma_free_fields(board, 8) == 130 );


char* board275243543 = gamma_board(board);
assert( board275243543 != NULL );
assert( strcmp(board275243543, 
"......5...42\n"
".......2...8\n"
"....7..6..2.\n"
".....4.3..22\n"
"..8..2.74..4\n"
".....2..66.7\n"
".......1.4.5\n"
".5..8.6...1.\n"
"...2....551.\n"
"1.....34..3.\n"
"..4..2.3....\n"
"..431.......\n"
"71...8...86.\n"
".4...4.511..\n"
".5..4.231.71\n"
"...6.3...3..\n") == 0);
free(board275243543);
board275243543 = NULL;
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 10, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 15, 1) == 0 );
assert( gamma_move(board, 6, 9, 5) == 1 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_move(board, 7, 2, 4) == 0 );
assert( gamma_move(board, 7, 10, 15) == 0 );
assert( gamma_move(board, 8, 3, 7) == 0 );
assert( gamma_golden_move(board, 8, 1, 10) == 0 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_move(board, 5, 2, 12) == 1 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_move(board, 7, 4, 2) == 1 );
assert( gamma_move(board, 7, 8, 12) == 1 );


char* board645135257 = gamma_board(board);
assert( board645135257 != NULL );
assert( strcmp(board645135257, 
"......5...42\n"
".......2...8\n"
"....7..6..2.\n"
"..5..4.37.22\n"
"..8..2.74..4\n"
"..6..2..66.7\n"
".......1.425\n"
".5..8.6...1.\n"
"...2....551.\n"
"1.....34..3.\n"
".54..2.3.6..\n"
"..431..3....\n"
"71...8...86.\n"
".43.74.511..\n"
"15..4.231.71\n"
"...6.3...3..\n") == 0);
free(board645135257);
board645135257 = NULL;
assert( gamma_move(board, 8, 15, 1) == 0 );
assert( gamma_move(board, 8, 6, 9) == 1 );


char* board706538437 = gamma_board(board);
assert( board706538437 != NULL );
assert( strcmp(board706538437, 
"......5...42\n"
".......2...8\n"
"....7..6..2.\n"
"..5..4.37.22\n"
"..8..2.74..4\n"
"..6..2..66.7\n"
"......81.425\n"
".5..8.6...1.\n"
"...2....551.\n"
"1.....34..3.\n"
".54..2.3.6..\n"
"..431..3....\n"
"71...8...86.\n"
".43.74.511..\n"
"15..4.231.71\n"
"...6.3...3..\n") == 0);
free(board706538437);
board706538437 = NULL;
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 15, 8) == 0 );
assert( gamma_free_fields(board, 3) == 119 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_golden_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 6, 14, 6) == 0 );
assert( gamma_move(board, 6, 8, 10) == 0 );
assert( gamma_move(board, 8, 13, 11) == 0 );
assert( gamma_free_fields(board, 8) == 118 );
assert( gamma_golden_move(board, 8, 10, 11) == 0 );


char* board456291790 = gamma_board(board);
assert( board456291790 != NULL );
assert( strcmp(board456291790, 
"......5...42\n"
".......2...8\n"
"....7..6..2.\n"
"..5..4.37.22\n"
"..8..2.74..4\n"
"..6..2..66.7\n"
"......81.425\n"
".5..8.6...1.\n"
"...2....551.\n"
"1.....34..3.\n"
".54..2.3.6..\n"
"..431..3....\n"
"71...8...86.\n"
".43.74.511..\n"
"15..4.231.71\n"
"5..6.3...3..\n") == 0);
free(board456291790);
board456291790 = NULL;
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 1, 3, 14) == 1 );
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 6, 12) == 1 );
assert( gamma_move(board, 5, 7, 0) == 1 );
assert( gamma_move(board, 6, 14, 9) == 0 );
assert( gamma_move(board, 6, 5, 5) == 0 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_move(board, 7, 11, 3) == 1 );
assert( gamma_move(board, 8, 3, 8) == 1 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_free_fields(board, 2) == 112 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 11) == 0 );
assert( gamma_move(board, 4, 8, 9) == 1 );
assert( gamma_move(board, 5, 9, 13) == 1 );
assert( gamma_move(board, 5, 5, 10) == 0 );
assert( gamma_move(board, 6, 8, 2) == 0 );
assert( gamma_move(board, 6, 8, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 8 );
assert( gamma_free_fields(board, 6) == 110 );
assert( gamma_free_fields(board, 7) == 110 );
assert( gamma_move(board, 8, 7, 0) == 0 );
assert( gamma_move(board, 1, 9, 1) == 1 );
assert( gamma_move(board, 2, 8, 15) == 1 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_move(board, 6, 15, 0) == 0 );
assert( gamma_free_fields(board, 6) == 108 );
assert( gamma_move(board, 7, 3, 10) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 8, 10) == 0 );
assert( gamma_golden_move(board, 8, 15, 2) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_free_fields(board, 1) == 107 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 7, 2, 1) == 1 );
assert( gamma_move(board, 8, 1, 11) == 1 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_move(board, 2, 11, 11) == 0 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_move(board, 7, 6, 9) == 0 );
assert( gamma_move(board, 7, 10, 12) == 0 );
assert( gamma_move(board, 8, 8, 9) == 0 );
assert( gamma_move(board, 8, 7, 2) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 10, 14) == 1 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 6, 11) == 0 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 7, 7, 7) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 6, 8) == 0 );
assert( gamma_move(board, 8, 5, 8) == 1 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_move(board, 4, 5, 6) == 1 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_move(board, 7, 6, 4) == 0 );
assert( gamma_move(board, 8, 13, 1) == 0 );
assert( gamma_move(board, 8, 9, 11) == 1 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 1, 11, 14) == 0 );
assert( gamma_golden_move(board, 1, 15, 11) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 7, 8) == 1 );
assert( gamma_move(board, 4, 10, 10) == 1 );


char* board734918115 = gamma_board(board);
assert( board734918115 != NULL );
assert( strcmp(board734918115, 
"......5.2.42\n"
"...1...2..28\n"
"....7..6.52.\n"
"..5..4437.22\n"
".88..22748.4\n"
"..67.2..6647\n"
"......814425\n"
".5.88863..1.\n"
"...2...7551.\n"
"1....434..3.\n"
".54..2.3.612\n"
"..431.33....\n"
"711..8.3.867\n"
"243.74.511..\n"
"157.4.231171\n"
"5..6.3.5.3..\n") == 0);
free(board734918115);
board734918115 = NULL;
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 6, 5, 4) == 1 );
assert( gamma_move(board, 6, 11, 4) == 1 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 7, 11, 12) == 0 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 8, 8, 11) == 0 );


char* board641677051 = gamma_board(board);
assert( board641677051 != NULL );
assert( strcmp(board641677051, 
"......5.2.42\n"
"...1...2..28\n"
"....7..6.52.\n"
"..5..4437.22\n"
".88..22748.4\n"
"..67.2..6647\n"
"......814425\n"
".5.88863..1.\n"
"...2...7551.\n"
"1....434..3.\n"
".54..2.3.612\n"
"..431633...6\n"
"711..8.3.867\n"
"243.74.511..\n"
"157.4.231171\n"
"5..6.3.5.3..\n") == 0);
free(board641677051);
board641677051 = NULL;
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_free_fields(board, 1) == 90 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 4, 10, 4) == 1 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 4, 14) == 1 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 7, 15, 5) == 0 );
assert( gamma_move(board, 8, 11, 9) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );


char* board597683893 = gamma_board(board);
assert( board597683893 != NULL );
assert( strcmp(board597683893, 
"......5.2.42\n"
"...15..2..28\n"
"....7..6.52.\n"
"..5..4437.22\n"
"288..22748.4\n"
"..67.2..6647\n"
"......814425\n"
".5.88863..1.\n"
"..22...7551.\n"
"1....434..3.\n"
".54..2.3.612\n"
"..431633..46\n"
"711..8.3.867\n"
"243.74.511..\n"
"157.4.231171\n"
"5.36.3.5.3..\n") == 0);
free(board597683893);
board597683893 = NULL;
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 5, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 15, 4) == 0 );
assert( gamma_free_fields(board, 5) == 85 );
assert( gamma_golden_move(board, 5, 11, 1) == 1 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 3, 11) == 1 );
assert( gamma_move(board, 7, 12, 4) == 0 );
assert( gamma_move(board, 7, 5, 8) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 15, 1) == 0 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_golden_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_move(board, 8, 4, 5) == 1 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 5, 1, 4) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_move(board, 6, 15, 7) == 0 );
assert( gamma_move(board, 7, 12, 4) == 0 );
assert( gamma_move(board, 7, 1, 5) == 0 );
assert( gamma_move(board, 8, 0, 7) == 1 );


char* board266818352 = gamma_board(board);
assert( board266818352 != NULL );
assert( strcmp(board266818352, 
"......5.2.42\n"
"...15..2..28\n"
"....7..6.52.\n"
"..5..4437.22\n"
"2886.22748.4\n"
"1.67.2..6647\n"
"....2.814425\n"
".5.88863..1.\n"
"8.22...7551.\n"
"1....434..3.\n"
".54.82.3.612\n"
".5431633..46\n"
"711..8.3.867\n"
"243.74.511..\n"
"157.4.231175\n"
"5.36.3.5.3..\n") == 0);
free(board266818352);
board266818352 = NULL;
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 4, 10, 11) == 1 );
assert( gamma_move(board, 5, 15, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_move(board, 6, 8, 14) == 1 );
assert( gamma_move(board, 6, 6, 15) == 0 );
assert( gamma_move(board, 7, 10, 14) == 0 );
assert( gamma_move(board, 7, 10, 1) == 0 );
assert( gamma_move(board, 8, 13, 5) == 0 );
assert( gamma_move(board, 8, 11, 9) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_free_fields(board, 2) == 75 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 3, 6) == 1 );
assert( gamma_golden_move(board, 6, 10, 3) == 0 );
assert( gamma_move(board, 7, 4, 0) == 1 );
assert( gamma_move(board, 8, 9, 9) == 0 );
assert( gamma_move(board, 8, 3, 6) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 6, 13) == 1 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 5, 5, 11) == 0 );
assert( gamma_move(board, 5, 4, 14) == 0 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 6, 10, 14) == 0 );
assert( gamma_move(board, 7, 12, 1) == 0 );
assert( gamma_move(board, 7, 1, 15) == 1 );
assert( gamma_move(board, 8, 3, 4) == 0 );
assert( gamma_move(board, 8, 4, 0) == 0 );
assert( gamma_free_fields(board, 8) == 71 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_free_fields(board, 2) == 70 );


char* board445584407 = gamma_board(board);
assert( board445584407 != NULL );
assert( strcmp(board445584407, 
".7....5.2.42\n"
"...15..26.28\n"
"....7.36.52.\n"
"..5..4437.22\n"
"2886.2274844\n"
"1.67.2..6647\n"
"....2.814425\n"
".5.88863..1.\n"
"8.22...7551.\n"
"1.26.434..3.\n"
".54.82.3.612\n"
".5431633..46\n"
"7114.8.3.867\n"
"243.74.511..\n"
"15714.231175\n"
"5.3673.5.3..\n") == 0);
free(board445584407);
board445584407 = NULL;
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 6, 1, 5) == 0 );
assert( gamma_move(board, 7, 6, 4) == 0 );
assert( gamma_golden_move(board, 7, 15, 10) == 0 );
assert( gamma_move(board, 8, 6, 1) == 0 );
assert( gamma_free_fields(board, 8) == 69 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 14, 2) == 0 );
assert( gamma_move(board, 5, 14, 2) == 0 );
assert( gamma_move(board, 6, 14, 5) == 0 );
assert( gamma_move(board, 6, 5, 10) == 0 );
assert( gamma_move(board, 7, 8, 11) == 0 );
assert( gamma_move(board, 8, 15, 2) == 0 );
assert( gamma_move(board, 8, 5, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_golden_move(board, 2, 11, 10) == 1 );
assert( gamma_move(board, 3, 2, 6) == 0 );


char* board578433217 = gamma_board(board);
assert( board578433217 != NULL );
assert( strcmp(board578433217, 
".7....5.2.42\n"
"...15..26.28\n"
"....7.36.52.\n"
"..5..4437.22\n"
"2886.2274844\n"
"1.67.2..6642\n"
"....2.814425\n"
".5.88863..1.\n"
"8.22...7551.\n"
"1.26.434..3.\n"
".54.82.3.612\n"
".5431633..46\n"
"7114.8.3.867\n"
"243.74.511..\n"
"15714.231175\n"
"533673.5.3..\n") == 0);
free(board578433217);
board578433217 = NULL;
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 5, 2, 14) == 1 );
assert( gamma_move(board, 5, 1, 14) == 1 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 7, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_move(board, 7, 12, 4) == 0 );
assert( gamma_move(board, 7, 11, 1) == 0 );
assert( gamma_free_fields(board, 7) == 67 );
assert( gamma_move(board, 8, 3, 9) == 1 );
assert( gamma_free_fields(board, 8) == 66 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 9, 6) == 1 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 15, 2) == 0 );
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_move(board, 5, 1, 11) == 0 );
assert( gamma_move(board, 5, 1, 7) == 1 );
assert( gamma_move(board, 6, 5, 13) == 1 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_move(board, 8, 4, 0) == 0 );
assert( gamma_busy_fields(board, 8) == 13 );
assert( gamma_move(board, 1, 9, 1) == 0 );


char* board128621186 = gamma_board(board);
assert( board128621186 != NULL );
assert( strcmp(board128621186, 
".7....5.2.42\n"
"45515..26.28\n"
"....7636.52.\n"
"..5..4437.22\n"
"2886.2274844\n"
"1.67.2..6642\n"
"...82.814425\n"
".5.88863..1.\n"
"8522...7551.\n"
"1.26.434.13.\n"
".54.82.3.612\n"
".5431633..46\n"
"7114.8.3.867\n"
"243.74.511..\n"
"15714.231175\n"
"533673.5.3..\n") == 0);
free(board128621186);
board128621186 = NULL;
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_golden_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 5, 7, 13) == 0 );
assert( gamma_move(board, 6, 9, 7) == 0 );
assert( gamma_free_fields(board, 6) == 62 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_move(board, 7, 0, 11) == 0 );
assert( gamma_move(board, 7, 5, 12) == 0 );
assert( gamma_free_fields(board, 7) == 62 );
assert( gamma_move(board, 8, 12, 3) == 0 );
assert( gamma_move(board, 8, 3, 6) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_golden_move(board, 4, 10, 5) == 1 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 6, 8, 9) == 0 );
assert( gamma_move(board, 7, 10, 6) == 0 );
assert( gamma_move(board, 8, 7, 11) == 0 );
assert( gamma_move(board, 8, 0, 14) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 11, 2) == 1 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_free_fields(board, 4) == 61 );
assert( gamma_free_fields(board, 5) == 61 );
assert( gamma_move(board, 7, 5, 14) == 1 );
assert( gamma_move(board, 8, 13, 3) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 2, 9, 8) == 1 );
assert( gamma_golden_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 4, 9, 14) == 1 );
assert( gamma_move(board, 5, 0, 11) == 0 );
assert( gamma_move(board, 5, 8, 5) == 1 );
assert( gamma_busy_fields(board, 5) == 19 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 8) == 1 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_move(board, 8, 5, 6) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );


char* board972957411 = gamma_board(board);
assert( board972957411 != NULL );
assert( strcmp(board972957411, 
".7....5.2.42\n"
"455157.26428\n"
"1...7636.52.\n"
"..5..4437.22\n"
"2886.2274844\n"
"1.67.2..6642\n"
"...82.814425\n"
"75.88863.21.\n"
"8522...7551.\n"
"1.26.434.13.\n"
".54.82.35642\n"
".5431633..46\n"
"7114.8.3.867\n"
"243.74.511.2\n"
"15714.231175\n"
"533673.5.3..\n") == 0);
free(board972957411);
board972957411 = NULL;
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_move(board, 7, 10, 11) == 0 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 8, 8) == 1 );
assert( gamma_move(board, 8, 1, 8) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 4, 11, 13) == 1 );
assert( gamma_golden_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 19 );
assert( gamma_move(board, 7, 10, 6) == 0 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 8, 12, 0) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_golden_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 11, 7) == 1 );
assert( gamma_move(board, 5, 8, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 19 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 6, 5, 7) == 1 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_move(board, 8, 15, 3) == 0 );
assert( gamma_golden_move(board, 8, 13, 0) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board653595292 = gamma_board(board);
assert( board653595292 != NULL );
assert( strcmp(board653595292, 
".7....5.2.42\n"
"455157.26428\n"
"1.2.7636.524\n"
".35..4437.22\n"
"2886.2274844\n"
"1.67.2..6642\n"
"...82.814425\n"
"75.88863821.\n"
"8522.6.75514\n"
"1.26.434.13.\n"
".54.82.35642\n"
".5431133..46\n"
"7114.8.3.867\n"
"243.74.511.2\n"
"15714.231175\n"
"533673.5.3..\n") == 0);
free(board653595292);
board653595292 = NULL;
assert( gamma_move(board, 7, 5, 15) == 1 );
assert( gamma_move(board, 7, 9, 9) == 0 );
assert( gamma_move(board, 8, 6, 4) == 0 );
assert( gamma_move(board, 1, 11, 15) == 0 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 6, 10, 15) == 0 );
assert( gamma_move(board, 6, 1, 12) == 0 );
assert( gamma_move(board, 7, 2, 12) == 0 );
assert( gamma_free_fields(board, 7) == 48 );
assert( gamma_move(board, 8, 0, 11) == 0 );
assert( gamma_move(board, 8, 9, 9) == 0 );
assert( gamma_busy_fields(board, 8) == 14 );
assert( gamma_move(board, 1, 7, 15) == 1 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_free_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 5, 1, 7) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 7, 1, 1) == 0 );


char* board759411839 = gamma_board(board);
assert( board759411839 != NULL );
assert( strcmp(board759411839, 
".7...7512.42\n"
"455157.26428\n"
"1.2.7636.524\n"
".35..4437.22\n"
"2886.2274844\n"
"1.67.23.6642\n"
"...82.814425\n"
"75.88863821.\n"
"8522.6.75514\n"
"1.26.434.13.\n"
".54.82.35642\n"
".5431133..46\n"
"7114.8.3.867\n"
"243.74.511.2\n"
"15714.231175\n"
"533673.5.3..\n") == 0);
free(board759411839);
board759411839 = NULL;
assert( gamma_move(board, 8, 5, 2) == 0 );
assert( gamma_move(board, 8, 8, 8) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 3, 10, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_free_fields(board, 6) == 45 );
assert( gamma_move(board, 7, 6, 9) == 0 );
assert( gamma_move(board, 7, 0, 13) == 0 );
assert( gamma_move(board, 8, 0, 15) == 1 );


char* board920533410 = gamma_board(board);
assert( board920533410 != NULL );
assert( strcmp(board920533410, 
"87...7512.42\n"
"455157.26428\n"
"1.2.7636.524\n"
".35..4437.22\n"
"2886.2274844\n"
"1.67.23.6642\n"
"...82.814425\n"
"75.88863821.\n"
"8522.6.75514\n"
"1.26.434.13.\n"
".54.82.35642\n"
".5431133..46\n"
"7114.8.3.867\n"
"243.74.51132\n"
"15714.231175\n"
"533673.5.3..\n") == 0);
free(board920533410);
board920533410 = NULL;
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 11, 6) == 1 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_free_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 5, 0, 9) == 1 );
assert( gamma_free_fields(board, 5) == 41 );
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 10) == 1 );
assert( gamma_move(board, 7, 6, 6) == 0 );
assert( gamma_move(board, 8, 10, 4) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 7, 3, 4) == 0 );
assert( gamma_move(board, 7, 6, 11) == 0 );
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_free_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 5, 6, 0) == 1 );
assert( gamma_move(board, 7, 13, 3) == 0 );
assert( gamma_free_fields(board, 7) == 38 );
assert( gamma_free_fields(board, 8) == 38 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 6, 6, 9) == 0 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 7, 1, 5) == 0 );
assert( gamma_move(board, 8, 2, 11) == 0 );
assert( gamma_move(board, 8, 3, 5) == 1 );
assert( gamma_busy_fields(board, 8) == 16 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 3, 12) == 1 );
assert( gamma_move(board, 4, 11, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_move(board, 6, 8, 15) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 3, 8) == 0 );
assert( gamma_free_fields(board, 7) == 36 );
assert( gamma_move(board, 8, 8, 10) == 0 );
assert( gamma_move(board, 8, 6, 1) == 0 );
assert( gamma_golden_move(board, 8, 14, 9) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_free_fields(board, 6) == 34 );
assert( gamma_move(board, 7, 13, 8) == 0 );
assert( gamma_move(board, 8, 4, 0) == 0 );
assert( gamma_move(board, 8, 0, 1) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_free_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );


char* board539075140 = gamma_board(board);
assert( board539075140 != NULL );
assert( strcmp(board539075140, 
"87...7512.42\n"
"455157326428\n"
"112.7636.524\n"
".353.4437.22\n"
"2886.2274844\n"
"1767.23.6642\n"
"5..82.814425\n"
"75288863821.\n"
"8522.6.75514\n"
"1.26.4344133\n"
".54882.35642\n"
".5431133..46\n"
"7114.8.3.867\n"
"243.74.51132\n"
"15714.231175\n"
"53367355.3..\n") == 0);
free(board539075140);
board539075140 = NULL;
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_move(board, 6, 11, 8) == 1 );
assert( gamma_move(board, 7, 7, 4) == 0 );
assert( gamma_free_fields(board, 7) == 33 );
assert( gamma_move(board, 8, 9, 5) == 0 );
assert( gamma_move(board, 8, 1, 4) == 0 );


gamma_delete(board);

    return 0;
}
