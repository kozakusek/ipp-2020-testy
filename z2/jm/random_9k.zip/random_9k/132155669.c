#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 132155669
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 16, 7, 21);
assert( board != NULL );


assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_free_fields(board, 3) == 221 );
assert( gamma_move(board, 4, 8, 2) == 1 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 5, 4, 1) == 1 );
assert( gamma_move(board, 5, 7, 8) == 1 );
assert( gamma_move(board, 6, 13, 1) == 1 );
assert( gamma_move(board, 6, 5, 0) == 1 );
assert( gamma_move(board, 7, 7, 15) == 1 );
assert( gamma_move(board, 7, 1, 14) == 1 );
assert( gamma_move(board, 1, 6, 7) == 1 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 2, 7, 12) == 1 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_move(board, 3, 10, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 3 );
assert( gamma_free_fields(board, 3) == 208 );
assert( gamma_golden_move(board, 3, 10, 10) == 0 );


char* board663372448 = gamma_board(board);
assert( board663372448 != NULL );
assert( strcmp(board663372448, 
".......7......\n"
".7............\n"
"..............\n"
".......2......\n"
"..3...........\n"
"..............\n"
"..............\n"
".......5..3...\n"
".....21...4...\n"
"..............\n"
"..............\n"
"....1....2....\n"
"......3.......\n"
"........4.....\n"
"....5........6\n"
".....6........\n") == 0);
free(board663372448);
board663372448 = NULL;
assert( gamma_move(board, 4, 9, 8) == 1 );
assert( gamma_move(board, 5, 5, 9) == 1 );
assert( gamma_move(board, 5, 12, 13) == 1 );
assert( gamma_move(board, 6, 6, 4) == 1 );
assert( gamma_move(board, 6, 8, 3) == 1 );
assert( gamma_move(board, 7, 10, 11) == 1 );
assert( gamma_move(board, 1, 12, 1) == 1 );
assert( gamma_move(board, 1, 5, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 8, 1) == 1 );


char* board739326401 = gamma_board(board);
assert( board739326401 != NULL );
assert( strcmp(board739326401, 
".....1.7......\n"
".7............\n"
"............5.\n"
".......2......\n"
"..3.......7...\n"
"..............\n"
".....5........\n"
"2......5.43...\n"
".....21...4...\n"
"..............\n"
"..............\n"
"....1.6..2....\n"
"......3.6.....\n"
"........4.....\n"
"....5...5...16\n"
".....6........\n") == 0);
free(board739326401);
board739326401 = NULL;
assert( gamma_move(board, 6, 7, 7) == 1 );
assert( gamma_move(board, 7, 10, 4) == 1 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_move(board, 2, 13, 2) == 1 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 3, 1, 10) == 1 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 4, 10, 0) == 1 );
assert( gamma_move(board, 5, 3, 11) == 1 );
assert( gamma_move(board, 6, 11, 7) == 1 );
assert( gamma_move(board, 6, 4, 9) == 1 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_free_fields(board, 7) == 187 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_golden_move(board, 1, 3, 3) == 1 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 3, 10, 15) == 1 );
assert( gamma_free_fields(board, 3) == 183 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 10) == 1 );
assert( gamma_move(board, 4, 8, 9) == 1 );
assert( gamma_move(board, 5, 9, 7) == 1 );
assert( gamma_move(board, 6, 0, 11) == 1 );
assert( gamma_move(board, 7, 3, 0) == 1 );
assert( gamma_move(board, 1, 13, 9) == 1 );
assert( gamma_move(board, 2, 2, 14) == 1 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_golden_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 3, 14, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 5, 4, 0) == 1 );
assert( gamma_move(board, 5, 11, 13) == 1 );
assert( gamma_move(board, 6, 0, 13) == 1 );
assert( gamma_move(board, 6, 5, 1) == 1 );
assert( gamma_move(board, 7, 15, 1) == 0 );
assert( gamma_move(board, 7, 13, 3) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 15, 2) == 0 );


char* board187495770 = gamma_board(board);
assert( board187495770 != NULL );
assert( strcmp(board187495770, 
".....1.7..3...\n"
".72...........\n"
"6..1.......55.\n"
"...2...2......\n"
"6.35......7...\n"
".3..........4.\n"
"....65..4....1\n"
"2......5.43...\n"
".....216.546..\n"
"...........2..\n"
"..............\n"
"....1.6..27...\n"
"..21..3.6....7\n"
"...1....4.4..2\n"
"....56..53..16\n"
"...756....4...\n") == 0);
free(board187495770);
board187495770 = NULL;
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_free_fields(board, 2) == 167 );
assert( gamma_move(board, 3, 13, 6) == 1 );
assert( gamma_move(board, 3, 9, 0) == 1 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_move(board, 5, 2, 2) == 1 );
assert( gamma_busy_fields(board, 5) == 10 );
assert( gamma_move(board, 6, 12, 3) == 1 );
assert( gamma_move(board, 7, 4, 13) == 1 );
assert( gamma_move(board, 7, 6, 8) == 1 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 2, 2, 15) == 1 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 0, 4) == 1 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 6, 5, 15) == 0 );
assert( gamma_move(board, 7, 9, 12) == 1 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 1, 11, 12) == 1 );
assert( gamma_free_fields(board, 1) == 155 );
assert( gamma_move(board, 2, 11, 9) == 1 );
assert( gamma_move(board, 2, 13, 10) == 1 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 6) == 1 );
assert( gamma_move(board, 6, 1, 2) == 1 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 7, 6, 13) == 1 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 15, 11) == 0 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_free_fields(board, 3) == 148 );
assert( gamma_golden_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 5, 8, 4) == 1 );
assert( gamma_move(board, 5, 7, 6) == 1 );
assert( gamma_move(board, 6, 13, 5) == 1 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_move(board, 7, 14, 8) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_move(board, 7, 6, 11) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 1, 12, 2) == 1 );
assert( gamma_free_fields(board, 2) == 142 );


char* board500801843 = gamma_board(board);
assert( board500801843 != NULL );
assert( strcmp(board500801843, 
"..2..1.7..3...\n"
".72...........\n"
"6..17.7....55.\n"
"...2...2.7.1..\n"
"6.35......7...\n"
".3..........42\n"
".2..65.34..2.1\n"
"2.....75.433..\n"
"4....216.546.4\n"
"....2..5..52.3\n"
".............6\n"
"5...1.6.527...\n"
"..21..3.6...67\n"
".651....4.4.12\n"
"3...56..53..16\n"
"..4756...34...\n") == 0);
free(board500801843);
board500801843 = NULL;
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 5, 8, 15) == 1 );
assert( gamma_free_fields(board, 5) == 139 );
assert( gamma_move(board, 6, 5, 5) == 1 );
assert( gamma_free_fields(board, 6) == 138 );
assert( gamma_move(board, 7, 4, 8) == 1 );
assert( gamma_move(board, 7, 3, 15) == 1 );
assert( gamma_move(board, 1, 5, 6) == 1 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 1) == 1 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 4, 7, 3) == 1 );
assert( gamma_move(board, 4, 12, 6) == 1 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 6, 13, 8) == 1 );
assert( gamma_move(board, 6, 11, 6) == 0 );
assert( gamma_move(board, 7, 5, 9) == 0 );
assert( gamma_move(board, 7, 12, 1) == 0 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_golden_move(board, 2, 13, 3) == 1 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_golden_move(board, 3, 9, 13) == 0 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 3, 10, 10) == 1 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_free_fields(board, 4) == 126 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 5, 11, 0) == 1 );
assert( gamma_golden_move(board, 5, 4, 6) == 1 );
assert( gamma_move(board, 6, 12, 5) == 1 );
assert( gamma_move(board, 7, 15, 9) == 0 );
assert( gamma_move(board, 7, 10, 8) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_golden_move(board, 2, 2, 2) == 0 );
assert( gamma_move(board, 4, 2, 6) == 1 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_golden_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 5, 15, 1) == 0 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 6, 9, 12) == 0 );
assert( gamma_move(board, 7, 10, 7) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 13, 10) == 0 );
assert( gamma_move(board, 5, 3, 5) == 1 );
assert( gamma_move(board, 5, 9, 11) == 1 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 6, 6) == 1 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_free_fields(board, 6) == 116 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 2, 11, 11) == 1 );
assert( gamma_free_fields(board, 2) == 115 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_free_fields(board, 4) == 115 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_move(board, 6, 14, 8) == 0 );
assert( gamma_move(board, 6, 8, 6) == 1 );
assert( gamma_move(board, 7, 2, 4) == 1 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 6, 0) == 1 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board377399877 = gamma_board(board);
assert( board377399877 != NULL );
assert( strcmp(board377399877, 
"..27.1.75.3...\n"
".72...........\n"
"6..17.7....55.\n"
"...22..2.7.1..\n"
"6.351...4572..\n"
".3........3.42\n"
".2..65.34.32.1\n"
"2...7.75.433.6\n"
"4....216.546.4\n"
"..4.51656.5243\n"
"...5.62.3..466\n"
"537.1.6.527.1.\n"
"..21..346...62\n"
".651...24.4.12\n"
"3...56..53.316\n"
"5147563..345..\n") == 0);
free(board377399877);
board377399877 = NULL;
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_move(board, 5, 12, 15) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 7, 13, 8) == 0 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 4, 9, 6) == 1 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 5, 4, 13) == 0 );
assert( gamma_move(board, 5, 1, 7) == 1 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 8, 2) == 0 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 4, 12, 8) == 1 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_move(board, 5, 9, 12) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 6, 7, 0) == 1 );


char* board410155802 = gamma_board(board);
assert( board410155802 != NULL );
assert( strcmp(board410155802, 
"..27.1.75.3.5.\n"
".72...........\n"
"6..17.7....55.\n"
"...22..2.7.1..\n"
"6.351...4572..\n"
".3.....1..3.42\n"
".2..65.34232.1\n"
"2...7.75.43346\n"
"45...2164546.4\n"
"..4.5165645243\n"
"..45.62.3..466\n"
"537.1.6.527.1.\n"
"..21..346...62\n"
".651...24.4.12\n"
"35.156..53.316\n"
"51475636.345..\n") == 0);
free(board410155802);
board410155802 = NULL;
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_free_fields(board, 3) == 98 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_free_fields(board, 4) == 98 );
assert( gamma_move(board, 5, 11, 6) == 0 );
assert( gamma_move(board, 5, 9, 11) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 6, 4, 5) == 1 );
assert( gamma_move(board, 6, 4, 10) == 1 );
assert( gamma_move(board, 7, 13, 8) == 0 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 4) == 1 );


char* board710872532 = gamma_board(board);
assert( board710872532 != NULL );
assert( strcmp(board710872532, 
"..27.1.75.3.5.\n"
".72...........\n"
"6..17.7....552\n"
"...22..2.7.11.\n"
"6.351...4572..\n"
".3..6..12.3.42\n"
".2..65.34232.1\n"
"2...7.75.43346\n"
"45...2164546.4\n"
"..4.5165645243\n"
"..45662.3..466\n"
"537.1.64527.1.\n"
"..21..346...62\n"
".651...24.4.12\n"
"35.156..53.316\n"
"51475636.345..\n") == 0);
free(board710872532);
board710872532 = NULL;
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 12, 7) == 1 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_move(board, 4, 15, 1) == 0 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 6, 8, 14) == 1 );
assert( gamma_move(board, 7, 10, 3) == 1 );
assert( gamma_move(board, 7, 9, 9) == 0 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 4, 3) == 1 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 6, 11, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 22 );
assert( gamma_free_fields(board, 6) == 88 );
assert( gamma_move(board, 7, 14, 7) == 0 );
assert( gamma_move(board, 7, 10, 12) == 1 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 2, 12, 12) == 0 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 5, 3, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 6, 6, 4) == 0 );
assert( gamma_move(board, 7, 10, 12) == 0 );
assert( gamma_move(board, 7, 13, 15) == 1 );
assert( gamma_free_fields(board, 7) == 84 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_move(board, 1, 5, 12) == 1 );


char* board171363816 = gamma_board(board);
assert( board171363816 != NULL );
assert( strcmp(board171363816, 
"..27.1.75.3.57\n"
".72.....6.....\n"
"6..17.7....552\n"
"...221.2.7711.\n"
"6.351...4572..\n"
".3..6..12.3.42\n"
".21.65134232.1\n"
"2...7.75.43346\n"
"45...216454624\n"
"..4.5165645243\n"
"..4566213..466\n"
"537.1.64527.1.\n"
"..213.346.7.62\n"
".651...24.4.12\n"
"35.156.353.316\n"
"51475636.345..\n") == 0);
free(board171363816);
board171363816 = NULL;
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 2) == 1 );
assert( gamma_golden_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 7) == 0 );
assert( gamma_golden_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 6, 2, 0) == 0 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_golden_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 7, 2, 6) == 0 );
assert( gamma_free_fields(board, 7) == 78 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 4, 4, 15) == 1 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 15, 6) == 0 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 7, 3, 11) == 0 );
assert( gamma_move(board, 7, 9, 11) == 0 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_move(board, 5, 12, 10) == 0 );
assert( gamma_golden_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 6, 0, 8) == 0 );
assert( gamma_move(board, 7, 6, 8) == 0 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_free_fields(board, 1) == 75 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 6) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 11, 6) == 0 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );


char* board574080591 = gamma_board(board);
assert( board574080591 != NULL );
assert( strcmp(board574080591, 
"..2741.75.3.57\n"
"472.....6.....\n"
"6..17.7....552\n"
"...221.2.7711.\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"2...7.75243346\n"
"45...216454624\n"
".44.5165645243\n"
"..45662132.466\n"
"53731.64527.1.\n"
"..213.346.7.62\n"
".651...2474.12\n"
"35.156.353.316\n"
"51475636.345..\n") == 0);
free(board574080591);
board574080591 = NULL;
assert( gamma_move(board, 6, 10, 5) == 1 );
assert( gamma_move(board, 7, 5, 0) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_golden_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 15, 11) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 6, 15, 9) == 0 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_move(board, 7, 14, 12) == 0 );
assert( gamma_move(board, 7, 13, 6) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 6, 14, 6) == 0 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 7, 12, 0) == 1 );
assert( gamma_move(board, 7, 1, 7) == 0 );
assert( gamma_move(board, 1, 6, 12) == 1 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_free_fields(board, 1) == 68 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );


char* board430255835 = gamma_board(board);
assert( board430255835 != NULL );
assert( strcmp(board430255835, 
"..2741.75.3.57\n"
"472.....6.....\n"
"6..17.7....552\n"
"...22112.7711.\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"2...7.75243346\n"
"45...216454624\n"
".44.5165645243\n"
"3.456621326466\n"
"53731.64527.1.\n"
"1.213.34627.62\n"
".651...2474.12\n"
"35.156.353.316\n"
"5147563613457.\n") == 0);
free(board430255835);
board430255835 = NULL;
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 5, 9, 14) == 0 );
assert( gamma_move(board, 5, 9, 12) == 0 );
assert( gamma_move(board, 6, 15, 0) == 0 );
assert( gamma_move(board, 6, 13, 4) == 1 );
assert( gamma_free_fields(board, 6) == 66 );
assert( gamma_move(board, 7, 6, 0) == 0 );
assert( gamma_move(board, 7, 3, 0) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_free_fields(board, 1) == 66 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 6, 1, 8) == 1 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_move(board, 7, 4, 9) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 12, 12) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 13, 12) == 1 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_move(board, 7, 6, 0) == 0 );
assert( gamma_move(board, 1, 12, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_golden_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 6, 14, 4) == 0 );
assert( gamma_move(board, 7, 2, 7) == 1 );
assert( gamma_move(board, 7, 7, 10) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_free_fields(board, 1) == 63 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_golden_move(board, 5, 15, 13) == 0 );
assert( gamma_move(board, 6, 13, 8) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );


char* board508128876 = gamma_board(board);
assert( board508128876 != NULL );
assert( strcmp(board508128876, 
"..2741.75.3.57\n"
"472.....6.....\n"
"6..17.7....552\n"
"...22112.77113\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"26..7.75243346\n"
"457..216454624\n"
".44.5165645243\n"
"3.456621326466\n"
"53731.64527.16\n"
"1.213.34627.62\n"
".651...2474.12\n"
"35.156.353.316\n"
"5147563613457.\n") == 0);
free(board508128876);
board508128876 = NULL;
assert( gamma_move(board, 7, 13, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 18 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 6, 11, 6) == 0 );
assert( gamma_move(board, 6, 11, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 18 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 11, 15) == 1 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 4, 15, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_golden_move(board, 4, 8, 1) == 1 );
assert( gamma_move(board, 5, 13, 13) == 0 );
assert( gamma_move(board, 6, 2, 0) == 0 );
assert( gamma_move(board, 7, 11, 3) == 1 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 14, 11) == 0 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 15, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 7, 14, 3) == 0 );
assert( gamma_free_fields(board, 7) == 60 );


char* board224248730 = gamma_board(board);
assert( board224248730 != NULL );
assert( strcmp(board224248730, 
"..2741.75.3157\n"
"472.....6.....\n"
"6..17.7....552\n"
"2..22112.77113\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"26..7.75243346\n"
"457..216454624\n"
".44.5165645243\n"
"3.456621326466\n"
"53731.64527.16\n"
"1.213.34627762\n"
".651...2474.12\n"
"35.156.343.316\n"
"5147563613457.\n") == 0);
free(board224248730);
board224248730 = NULL;
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );


char* board468838381 = gamma_board(board);
assert( board468838381 != NULL );
assert( strcmp(board468838381, 
"..2741.75.3157\n"
"472.....6.....\n"
"6..17.7....552\n"
"2..22112.77113\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"26..7.75243346\n"
"457..216454624\n"
".44.5165645243\n"
"3.456621326466\n"
"53731.64527.16\n"
"1.213.34627762\n"
".651...2474.12\n"
"35.156.343.316\n"
"5147563613457.\n") == 0);
free(board468838381);
board468838381 = NULL;
assert( gamma_move(board, 6, 12, 7) == 0 );
assert( gamma_move(board, 6, 8, 8) == 0 );
assert( gamma_move(board, 7, 14, 13) == 0 );
assert( gamma_move(board, 7, 10, 12) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_move(board, 4, 8, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 7, 2, 4) == 0 );
assert( gamma_move(board, 7, 6, 12) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );


char* board343722918 = gamma_board(board);
assert( board343722918 != NULL );
assert( strcmp(board343722918, 
"..2741.75.3157\n"
"472.....6.....\n"
"6.317.7....552\n"
"2..22112.77113\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"26..7.75243346\n"
"457..216454624\n"
".44.5165645243\n"
"3.456621326466\n"
"53731.64527.16\n"
"1.213.34627762\n"
".651...2474.12\n"
"35.156.343.316\n"
"5147563613457.\n") == 0);
free(board343722918);
board343722918 = NULL;
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_free_fields(board, 5) == 59 );
assert( gamma_move(board, 7, 1, 15) == 1 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_golden_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 5, 2, 12) == 1 );
assert( gamma_busy_fields(board, 5) == 23 );


char* board912688939 = gamma_board(board);
assert( board912688939 != NULL );
assert( strcmp(board912688939, 
".72741.75.3157\n"
"472.....6.....\n"
"6.317.7....552\n"
"2.522112.77113\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"26..7.75243346\n"
"457..216454624\n"
".44.5165645243\n"
"3.456621326466\n"
"53731.64527.16\n"
"1.213.34627762\n"
".651...2474.12\n"
"35.156.343.316\n"
"5147563613457.\n") == 0);
free(board912688939);
board912688939 = NULL;
assert( gamma_move(board, 6, 14, 9) == 0 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_move(board, 6, 4, 11) == 0 );
assert( gamma_move(board, 7, 12, 10) == 0 );
assert( gamma_move(board, 7, 1, 5) == 1 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_free_fields(board, 3) == 56 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );


char* board183607900 = gamma_board(board);
assert( board183607900 != NULL );
assert( strcmp(board183607900, 
".72741.75.3157\n"
"472.....6.....\n"
"6.317.7....552\n"
"2.522112.77113\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"26..7.75243346\n"
"457..216454624\n"
".44.5165645243\n"
"37456621326466\n"
"53731.64527.16\n"
"1.213.34627762\n"
".651...2474.12\n"
"35.156.343.316\n"
"5147563613457.\n") == 0);
free(board183607900);
board183607900 = NULL;
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 5, 1, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_free_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 21 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 4, 4, 14) == 1 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_move(board, 6, 0, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_free_fields(board, 6) == 55 );
assert( gamma_move(board, 7, 13, 10) == 0 );
assert( gamma_move(board, 7, 9, 12) == 0 );
assert( gamma_busy_fields(board, 7) == 21 );
assert( gamma_free_fields(board, 7) == 55 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 0, 6) == 1 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_move(board, 7, 10, 14) == 1 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 5, 13, 8) == 0 );
assert( gamma_move(board, 6, 11, 13) == 0 );
assert( gamma_free_fields(board, 6) == 53 );
assert( gamma_move(board, 7, 13, 9) == 0 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_free_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_golden_move(board, 2, 15, 13) == 0 );
assert( gamma_move(board, 4, 8, 11) == 0 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 6, 10, 7) == 0 );
assert( gamma_move(board, 6, 13, 0) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_free_fields(board, 3) == 51 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 6, 10, 6) == 0 );
assert( gamma_move(board, 6, 11, 11) == 0 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 3, 14, 12) == 0 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 6, 14, 9) == 0 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 4, 2, 2) == 0 );
assert( gamma_move(board, 5, 12, 10) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_move(board, 7, 14, 12) == 0 );
assert( gamma_move(board, 7, 8, 6) == 0 );
assert( gamma_free_fields(board, 7) == 51 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_free_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 9, 8) == 0 );


char* board584382874 = gamma_board(board);
assert( board584382874 != NULL );
assert( strcmp(board584382874, 
".72741.75.3157\n"
"472.4...6.7...\n"
"6.317.7....552\n"
"2.522112.77113\n"
"6.351...4572..\n"
"43..6..12.3.42\n"
".21.65134232.1\n"
"26..7.75243346\n"
"457..216454624\n"
"344.5165645243\n"
"37456621326466\n"
"53731.64527.16\n"
"1.213.34627762\n"
".651.1.2474.12\n"
"35.156.343.316\n"
"51475636134576\n") == 0);
free(board584382874);
board584382874 = NULL;
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 3, 6) == 1 );
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_free_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 4, 13, 10) == 0 );
assert( gamma_move(board, 4, 3, 15) == 0 );
assert( gamma_move(board, 5, 14, 3) == 0 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_move(board, 6, 13, 11) == 1 );
assert( gamma_move(board, 7, 0, 14) == 0 );
assert( gamma_busy_fields(board, 7) == 22 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_free_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 10, 3) == 0 );
assert( gamma_golden_move(board, 6, 5, 11) == 0 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_free_fields(board, 7) == 49 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_golden_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 6, 4, 15) == 0 );
assert( gamma_move(board, 7, 10, 6) == 0 );
assert( gamma_move(board, 7, 12, 6) == 0 );
assert( gamma_busy_fields(board, 7) == 22 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 7, 2, 4) == 0 );
assert( gamma_move(board, 7, 4, 14) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 1, 13, 12) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_move(board, 5, 15, 9) == 0 );
assert( gamma_golden_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_golden_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_free_fields(board, 4) == 48 );
assert( gamma_move(board, 5, 9, 12) == 0 );
assert( gamma_move(board, 5, 13, 13) == 0 );
assert( gamma_move(board, 6, 2, 0) == 0 );
assert( gamma_move(board, 6, 8, 4) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_move(board, 7, 5, 13) == 1 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 2, 4, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 7, 4, 11) == 0 );
assert( gamma_free_fields(board, 7) == 46 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 6, 13, 7) == 0 );
assert( gamma_move(board, 7, 11, 12) == 0 );
assert( gamma_move(board, 7, 8, 12) == 1 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 4, 12, 9) == 1 );
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 5, 4, 15) == 0 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );


gamma_delete(board);

    return 0;
}
