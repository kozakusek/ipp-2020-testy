#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 108012298
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(7, 16, 8, 8);
assert( board != NULL );


assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_move(board, 3, 6, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 5, 1, 3) == 1 );
assert( gamma_move(board, 6, 1, 5) == 1 );
assert( gamma_move(board, 7, 3, 4) == 1 );
assert( gamma_move(board, 7, 1, 13) == 1 );
assert( gamma_golden_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 8, 3, 11) == 1 );
assert( gamma_move(board, 8, 6, 2) == 1 );
assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_move(board, 4, 5, 0) == 1 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_move(board, 6, 8, 2) == 0 );
assert( gamma_move(board, 6, 2, 6) == 1 );
assert( gamma_free_fields(board, 6) == 98 );
assert( gamma_move(board, 7, 3, 1) == 1 );
assert( gamma_move(board, 7, 0, 1) == 1 );
assert( gamma_free_fields(board, 8) == 96 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 6, 2, 5) == 1 );
assert( gamma_move(board, 7, 15, 1) == 0 );
assert( gamma_move(board, 7, 2, 14) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 2, 4) == 1 );
assert( gamma_move(board, 8, 4, 2) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 5, 6, 8) == 1 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 7, 2, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 5 );
assert( gamma_move(board, 8, 4, 4) == 1 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 2, 5, 15) == 1 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 4, 3, 12) == 1 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 6, 0, 0) == 1 );
assert( gamma_move(board, 6, 3, 14) == 1 );
assert( gamma_move(board, 7, 2, 13) == 1 );
assert( gamma_move(board, 8, 3, 5) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 5, 5, 5) == 1 );
assert( gamma_move(board, 6, 14, 5) == 0 );
assert( gamma_move(board, 7, 1, 4) == 1 );
assert( gamma_move(board, 7, 4, 12) == 1 );
assert( gamma_move(board, 8, 2, 8) == 1 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 5, 6, 12) == 1 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 6 );
assert( gamma_move(board, 6, 3, 11) == 0 );
assert( gamma_move(board, 6, 1, 13) == 0 );


char* board239892243 = gamma_board(board);
assert( board239892243 != NULL );
assert( strcmp(board239892243, 
".....2.\n"
"..763..\n"
".77....\n"
"...47.5\n"
".428.1.\n"
".......\n"
".......\n"
"3.8...5\n"
".14....\n"
".56....\n"
".668.5.\n"
".7878.1\n"
".5.5...\n"
".4..4.8\n"
"7..7...\n"
"623..43\n") == 0);
free(board239892243);
board239892243 = NULL;
assert( gamma_move(board, 7, 0, 15) == 1 );
assert( gamma_golden_move(board, 7, 14, 4) == 0 );
assert( gamma_move(board, 8, 7, 0) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_move(board, 5, 4, 5) == 1 );
assert( gamma_move(board, 6, 3, 10) == 1 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_golden_move(board, 6, 5, 3) == 0 );
assert( gamma_move(board, 8, 2, 0) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 4, 3, 9) == 1 );
assert( gamma_move(board, 5, 2, 3) == 1 );
assert( gamma_free_fields(board, 5) == 64 );
assert( gamma_move(board, 6, 0, 7) == 1 );
assert( gamma_move(board, 6, 0, 13) == 1 );
assert( gamma_free_fields(board, 6) == 62 );
assert( gamma_move(board, 7, 2, 12) == 1 );
assert( gamma_move(board, 7, 6, 10) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 3, 8) == 1 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_busy_fields(board, 5) == 8 );
assert( gamma_move(board, 6, 11, 0) == 0 );
assert( gamma_move(board, 7, 6, 5) == 1 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 8, 1, 0) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 6, 11) == 1 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_golden_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 6, 0, 4) == 1 );
assert( gamma_free_fields(board, 6) == 55 );
assert( gamma_move(board, 7, 5, 6) == 0 );
assert( gamma_move(board, 8, 13, 6) == 0 );
assert( gamma_move(board, 8, 6, 1) == 1 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_move(board, 5, 6, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_free_fields(board, 6) == 53 );


char* board961377663 = gamma_board(board);
assert( board961377663 != NULL );
assert( strcmp(board961377663, 
"7....2.\n"
"..763..\n"
"677....\n"
"..747.5\n"
".428.13\n"
"...6..2\n"
"...4...\n"
"3.81..5\n"
"614....\n"
".56..3.\n"
".668557\n"
"67878.1\n"
".555..3\n"
"44..4.8\n"
"7..7.48\n"
"623..43\n") == 0);
free(board961377663);
board961377663 = NULL;
assert( gamma_move(board, 7, 1, 12) == 1 );
assert( gamma_golden_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 8, 14, 5) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 3, 1, 14) == 1 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_golden_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_move(board, 4, 5, 14) == 0 );


char* board384050512 = gamma_board(board);
assert( board384050512 != NULL );
assert( strcmp(board384050512, 
"7....2.\n"
".3763..\n"
"677....\n"
".7747.5\n"
".428.13\n"
"...6..2\n"
"...4...\n"
"3.81.45\n"
"614....\n"
".56..3.\n"
".668557\n"
"67878.1\n"
".555..3\n"
"44..4.8\n"
"7..7.48\n"
"623..43\n") == 0);
free(board384050512);
board384050512 = NULL;
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 8 );
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_move(board, 7, 2, 5) == 0 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_move(board, 8, 12, 5) == 0 );
assert( gamma_move(board, 8, 5, 14) == 1 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_golden_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_move(board, 8, 13, 5) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );


char* board395166164 = gamma_board(board);
assert( board395166164 != NULL );
assert( strcmp(board395166164, 
"7....2.\n"
".37638.\n"
"677....\n"
".7747.5\n"
".428.13\n"
"...6..2\n"
"...4...\n"
"3.81.45\n"
"614....\n"
".56..3.\n"
".668557\n"
"67878.1\n"
".555..3\n"
"44..4.8\n"
"7..7.48\n"
"623..43\n") == 0);
free(board395166164);
board395166164 = NULL;
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 3, 15) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_free_fields(board, 2) == 48 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 12 );
assert( gamma_move(board, 8, 15, 6) == 0 );
assert( gamma_move(board, 8, 1, 11) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 6, 11, 4) == 0 );
assert( gamma_move(board, 7, 2, 8) == 0 );
assert( gamma_move(board, 8, 6, 15) == 1 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 4, 2) == 0 );


char* board632199349 = gamma_board(board);
assert( board632199349 != NULL );
assert( strcmp(board632199349, 
"7..2.28\n"
".37638.\n"
"677....\n"
".7747.5\n"
".428.13\n"
"...6..2\n"
"...4...\n"
"3.81.45\n"
"614....\n"
".56..3.\n"
".668557\n"
"67878.1\n"
".555..3\n"
"442.4.8\n"
"7..7.48\n"
"623..43\n") == 0);
free(board632199349);
board632199349 = NULL;
assert( gamma_move(board, 8, 12, 0) == 0 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_free_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 3, 0) == 1 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 8, 12, 5) == 0 );
assert( gamma_move(board, 8, 2, 6) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 6 );
assert( gamma_golden_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_move(board, 5, 4, 11) == 1 );


char* board874675550 = gamma_board(board);
assert( board874675550 != NULL );
assert( strcmp(board874675550, 
"7..2.28\n"
".37638.\n"
"677....\n"
".7747.5\n"
".428513\n"
"...6..2\n"
"...4.1.\n"
"3.81.45\n"
"614....\n"
".56..3.\n"
".668557\n"
"67878.1\n"
".555..3\n"
"442.4.8\n"
"7..7.48\n"
"6235.43\n") == 0);
free(board874675550);
board874675550 = NULL;
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_golden_move(board, 6, 12, 4) == 0 );
assert( gamma_move(board, 7, 3, 5) == 0 );
assert( gamma_move(board, 8, 14, 0) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_move(board, 5, 0, 5) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 12 );
assert( gamma_move(board, 8, 11, 0) == 0 );


char* board629833245 = gamma_board(board);
assert( board629833245 != NULL );
assert( strcmp(board629833245, 
"7..2.28\n"
".37638.\n"
"677....\n"
".7747.5\n"
".428513\n"
"...6..2\n"
"...4.1.\n"
"3.81.45\n"
"614....\n"
".56..3.\n"
"5668557\n"
"67878.1\n"
".555..3\n"
"442.4.8\n"
"7..7.48\n"
"6235.43\n") == 0);
free(board629833245);
board629833245 = NULL;
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 1, 5, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board685945293 = gamma_board(board);
assert( board685945293 != NULL );
assert( strcmp(board685945293, 
"7..2.28\n"
".37638.\n"
"677..1.\n"
".7747.5\n"
".428513\n"
"...6..2\n"
"...4.1.\n"
"3.81.45\n"
"614....\n"
".56..31\n"
"5668557\n"
"67878.1\n"
".555..3\n"
"442.4.8\n"
"7..7.48\n"
"6235.43\n") == 0);
free(board685945293);
board685945293 = NULL;
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );


char* board201891453 = gamma_board(board);
assert( board201891453 != NULL );
assert( strcmp(board201891453, 
"7..2.28\n"
".37638.\n"
"677..1.\n"
".7747.5\n"
".428513\n"
"...6..2\n"
"...4.1.\n"
"3.81.45\n"
"614....\n"
".56..31\n"
"5668557\n"
"67878.1\n"
".555..3\n"
"442.4.8\n"
"7..7.48\n"
"6235.43\n") == 0);
free(board201891453);
board201891453 = NULL;
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 14, 0) == 0 );
assert( gamma_move(board, 8, 5, 9) == 0 );
assert( gamma_move(board, 8, 2, 0) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 5, 13, 6) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 9 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_move(board, 8, 4, 12) == 0 );


char* board188378450 = gamma_board(board);
assert( board188378450 != NULL );
assert( strcmp(board188378450, 
"7..2.28\n"
".37638.\n"
"677..1.\n"
".7747.5\n"
".428513\n"
"...6..2\n"
"...4.1.\n"
"3.81.45\n"
"614....\n"
".56..31\n"
"5668557\n"
"67878.1\n"
".555..3\n"
"442.4.8\n"
"7..7.48\n"
"6235.43\n") == 0);
free(board188378450);
board188378450 = NULL;
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );


char* board543055517 = gamma_board(board);
assert( board543055517 != NULL );
assert( strcmp(board543055517, 
"7..2.28\n"
".37638.\n"
"677..1.\n"
".7747.5\n"
".428513\n"
"...6..2\n"
"...4.1.\n"
"3.81.45\n"
"614....\n"
".56..31\n"
"5668557\n"
"67878.1\n"
".555..3\n"
"442.4.8\n"
"7..7.48\n"
"6235.43\n") == 0);
free(board543055517);
board543055517 = NULL;
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_free_fields(board, 3) == 9 );
assert( gamma_move(board, 5, 3, 10) == 0 );
assert( gamma_move(board, 5, 5, 12) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 13, 4) == 0 );
assert( gamma_move(board, 8, 15, 1) == 0 );
assert( gamma_free_fields(board, 8) == 7 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_golden_move(board, 5, 15, 3) == 0 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 7, 1, 4) == 0 );


char* board877216666 = gamma_board(board);
assert( board877216666 != NULL );
assert( strcmp(board877216666, 
"73.2.28\n"
".37638.\n"
"677..1.\n"
".774755\n"
".428513\n"
"...6..2\n"
"...4.11\n"
"3.81.45\n"
"614....\n"
".56.231\n"
"5668557\n"
"67878.1\n"
".555..3\n"
"442.4.8\n"
"7..7.48\n"
"6235.43\n") == 0);
free(board877216666);
board877216666 = NULL;
assert( gamma_move(board, 8, 0, 2) == 0 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 6, 5, 2) == 1 );
assert( gamma_move(board, 7, 13, 6) == 0 );
assert( gamma_move(board, 8, 7, 3) == 0 );
assert( gamma_move(board, 8, 6, 7) == 0 );
assert( gamma_busy_fields(board, 8) == 9 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_move(board, 4, 4, 9) == 1 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_move(board, 8, 7, 4) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_golden_move(board, 8, 0, 5) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_free_fields(board, 1) == 9 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_free_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 8, 0, 9) == 0 );
assert( gamma_move(board, 8, 3, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 9 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_free_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_free_fields(board, 5) == 9 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 7, 10, 4) == 0 );
assert( gamma_move(board, 7, 2, 1) == 1 );
assert( gamma_busy_fields(board, 7) == 13 );
assert( gamma_golden_move(board, 7, 15, 3) == 0 );
assert( gamma_move(board, 8, 3, 4) == 0 );


gamma_delete(board);

    return 0;
}
