#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 120009691
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(20, 8, 6, 31);
assert( board != NULL );


assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 2, 14, 5) == 1 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 4, 4, 17) == 0 );


char* board134595789 = gamma_board(board);
assert( board134595789 != NULL );
assert( strcmp(board134595789, 
"....................\n"
"....................\n"
".....3........2.....\n"
"....1...............\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n") == 0);
free(board134595789);
board134595789 = NULL;
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 6, 2, 2) == 1 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 10, 7) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_free_fields(board, 2) == 154 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 18, 4) == 1 );
assert( gamma_move(board, 4, 10, 3) == 1 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 5, 7, 3) == 1 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_free_fields(board, 1) == 150 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 14, 3) == 1 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 4, 1, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 3 );


char* board763984327 = gamma_board(board);
assert( board763984327 != NULL );
assert( strcmp(board763984327, 
"..........1.........\n"
"....................\n"
".2...3........2.....\n"
"....1....2........4.\n"
".......5..4...3.....\n"
"..6.................\n"
".4..................\n"
".....5..............\n") == 0);
free(board763984327);
board763984327 = NULL;
assert( gamma_move(board, 6, 7, 2) == 1 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 3, 1, 18) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 3 );
assert( gamma_move(board, 4, 5, 6) == 1 );
assert( gamma_move(board, 4, 14, 6) == 1 );
assert( gamma_golden_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 5, 1, 4) == 1 );
assert( gamma_move(board, 5, 10, 5) == 1 );
assert( gamma_move(board, 6, 5, 15) == 0 );
assert( gamma_move(board, 6, 15, 6) == 1 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 13, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_busy_fields(board, 3) == 3 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_move(board, 5, 9, 2) == 1 );
assert( gamma_free_fields(board, 5) == 135 );
assert( gamma_move(board, 6, 0, 3) == 1 );


char* board212074474 = gamma_board(board);
assert( board212074474 != NULL );
assert( strcmp(board212074474, 
"..........1.........\n"
".3...4........46....\n"
".2...3....5..22.....\n"
"45..1....2........4.\n"
"6......5..4...3.....\n"
".26....6.5..........\n"
".4...4..............\n"
".....5..............\n") == 0);
free(board212074474);
board212074474 = NULL;
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 3 );
assert( gamma_move(board, 2, 2, 17) == 0 );


char* board340670097 = gamma_board(board);
assert( board340670097 != NULL );
assert( strcmp(board340670097, 
"..........1.........\n"
".3...4........46....\n"
".2.1.3....5..22.....\n"
"45..1....2........4.\n"
"6......5..4...3.....\n"
".26....6.5..........\n"
".4...4..............\n"
".....5..............\n") == 0);
free(board340670097);
board340670097 = NULL;
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 2, 1) == 1 );
assert( gamma_free_fields(board, 5) == 130 );
assert( gamma_move(board, 6, 4, 6) == 1 );
assert( gamma_move(board, 6, 3, 4) == 1 );
assert( gamma_golden_move(board, 6, 4, 18) == 0 );
assert( gamma_move(board, 1, 6, 17) == 0 );
assert( gamma_free_fields(board, 1) == 128 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 4, 12, 4) == 1 );
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_move(board, 6, 3, 17) == 0 );
assert( gamma_free_fields(board, 6) == 124 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_free_fields(board, 3) == 122 );


char* board350580629 = gamma_board(board);
assert( board350580629 != NULL );
assert( strcmp(board350580629, 
"..........1.........\n"
".3..645....1..46....\n"
".231.3....5..22.....\n"
"45.61....2..4.....4.\n"
"6..2...5..4...3.....\n"
".26....6.5..........\n"
".45..4.3............\n"
"4....5.1............\n") == 0);
free(board350580629);
board350580629 = NULL;
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 1) == 1 );
assert( gamma_move(board, 6, 12, 6) == 1 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_free_fields(board, 2) == 119 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 3, 15, 5) == 1 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 4, 13, 2) == 1 );
assert( gamma_move(board, 5, 13, 7) == 1 );
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_move(board, 6, 9, 1) == 1 );
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 19, 4) == 1 );
assert( gamma_move(board, 2, 13, 4) == 1 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_move(board, 3, 19, 0) == 1 );
assert( gamma_move(board, 4, 14, 1) == 1 );
assert( gamma_move(board, 5, 0, 18) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_free_fields(board, 6) == 107 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board116931575 = gamma_board(board);
assert( board116931575 != NULL );
assert( strcmp(board116931575, 
".......3..1..5......\n"
".31.645....16.46....\n"
".231.3....5.3223....\n"
"45561....2..42....42\n"
"6..2...5..4...3.....\n"
".26....6.5...4......\n"
"545..463.6....4.....\n"
"4....5.1...........3\n") == 0);
free(board116931575);
board116931575 = NULL;
assert( gamma_move(board, 1, 18, 3) == 1 );
assert( gamma_free_fields(board, 1) == 106 );
assert( gamma_move(board, 2, 1, 18) == 0 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 4, 3, 6) == 1 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 5, 10, 1) == 1 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_move(board, 6, 4, 17) == 0 );
assert( gamma_move(board, 6, 13, 6) == 1 );
assert( gamma_move(board, 2, 11, 3) == 1 );
assert( gamma_free_fields(board, 2) == 101 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 4, 14, 7) == 1 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 6, 18) == 0 );
assert( gamma_move(board, 6, 13, 0) == 1 );
assert( gamma_move(board, 6, 11, 7) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 1, 0, 0) == 0 );


char* board499500575 = gamma_board(board);
assert( board499500575 != NULL );
assert( strcmp(board499500575, 
".......3..16.54.....\n"
".314645....16646....\n"
".231.3....5.3223....\n"
"45561....21.42....42\n"
"63.2...5..42..3...1.\n"
".26....6.52..4......\n"
"545..463.65...4.....\n"
"4....5.1.....6.....3\n") == 0);
free(board499500575);
board499500575 = NULL;
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 6, 1, 15) == 0 );
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_move(board, 1, 15, 7) == 1 );


char* board769988070 = gamma_board(board);
assert( board769988070 != NULL );
assert( strcmp(board769988070, 
".......3..16.541....\n"
".314645....16646....\n"
".231.3....5.3223....\n"
"45561....21.42....42\n"
"63.2...5..42..3...1.\n"
".26....6.52..4......\n"
"545..463.65...4.....\n"
"4....5.1.....6.....3\n") == 0);
free(board769988070);
board769988070 = NULL;
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_free_fields(board, 2) == 93 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 7) == 0 );
assert( gamma_move(board, 5, 19, 7) == 1 );
assert( gamma_golden_move(board, 5, 1, 7) == 0 );
assert( gamma_move(board, 6, 5, 18) == 0 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 14, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 2, 2) == 0 );
assert( gamma_free_fields(board, 4) == 91 );
assert( gamma_move(board, 5, 4, 15) == 0 );
assert( gamma_move(board, 5, 9, 5) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_move(board, 1, 7, 18) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 18) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 7, 5) == 1 );
assert( gamma_move(board, 5, 12, 0) == 1 );
assert( gamma_move(board, 6, 8, 4) == 1 );
assert( gamma_move(board, 6, 4, 0) == 1 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 2, 18, 6) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 3, 15) == 0 );
assert( gamma_move(board, 4, 17, 4) == 1 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 1, 19) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 5, 7, 17) == 0 );
assert( gamma_move(board, 5, 12, 3) == 1 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_move(board, 1, 16, 4) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 18, 1) == 1 );
assert( gamma_move(board, 3, 6, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_move(board, 5, 6, 6) == 0 );
assert( gamma_move(board, 5, 17, 5) == 1 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 6, 11, 0) == 1 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 2, 7, 17) == 0 );
assert( gamma_move(board, 3, 1, 16) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 6, 4, 7) == 1 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 1, 3, 16) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 16, 1) == 1 );
assert( gamma_move(board, 5, 3, 7) == 1 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_move(board, 6, 9, 7) == 1 );
assert( gamma_busy_fields(board, 6) == 17 );


char* board480097855 = gamma_board(board);
assert( board480097855 != NULL );
assert( strcmp(board480097855, 
"...56.23.616.541...5\n"
".314645....16646..2.\n"
".231.3.5.55.3223.5..\n"
"45561.2.621.42..1442\n"
"63.2..35..425.3...1.\n"
".26....6352..42.....\n"
"545..463.65...4.5.2.\n"
"4...6531...656.....3\n") == 0);
free(board480097855);
board480097855 = NULL;
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 2, 19) == 0 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 4, 9, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 4, 3) == 1 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 12, 1) == 1 );
assert( gamma_free_fields(board, 6) == 68 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_free_fields(board, 1) == 68 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_move(board, 3, 6, 16) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 5, 7, 7) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 6, 6, 10) == 0 );
assert( gamma_move(board, 1, 6, 19) == 0 );
assert( gamma_move(board, 1, 18, 4) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 16, 0) == 1 );
assert( gamma_free_fields(board, 2) == 66 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 15, 3) == 1 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board406520295 = gamma_board(board);
assert( board406520295 != NULL );
assert( strcmp(board406520295, 
"...56.23.616.541...5\n"
".314645...216646..2.\n"
".231.3.5.55.3223.5..\n"
"45561.2.621.42..1442\n"
"63.25.35..425.33..1.\n"
".26....6352..42.....\n"
"545..463365.6.4.5.2.\n"
"4...6531.4.656..2..3\n") == 0);
free(board406520295);
board406520295 = NULL;
assert( gamma_move(board, 4, 16, 1) == 0 );
assert( gamma_move(board, 4, 13, 3) == 1 );


char* board594810880 = gamma_board(board);
assert( board594810880 != NULL );
assert( strcmp(board594810880, 
"...56.23.616.541...5\n"
".314645...216646..2.\n"
".231.3.5.55.3223.5..\n"
"45561.2.621.42..1442\n"
"63.25.35..425433..1.\n"
".26....6352..42.....\n"
"545..463365.6.4.5.2.\n"
"4...6531.4.656..2..3\n") == 0);
free(board594810880);
board594810880 = NULL;
assert( gamma_move(board, 1, 6, 17) == 0 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 5, 1, 13) == 0 );
assert( gamma_move(board, 5, 5, 4) == 1 );
assert( gamma_move(board, 6, 16, 6) == 1 );
assert( gamma_move(board, 6, 8, 2) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 5, 18) == 0 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 4, 6, 19) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );


char* board568820826 = gamma_board(board);
assert( board568820826 != NULL );
assert( strcmp(board568820826, 
"...56.23.616.541...5\n"
".314645...2166466.2.\n"
".231.3.5255.3223.5..\n"
"4556152.621.42..1442\n"
"63.25.35..425433..1.\n"
".26....6352..42.....\n"
"545..463365.6.4.5.2.\n"
"4...6531.4.656..2..3\n") == 0);
free(board568820826);
board568820826 = NULL;
assert( gamma_move(board, 6, 5, 5) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 19 );
assert( gamma_move(board, 1, 1, 17) == 0 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 2, 17) == 0 );
assert( gamma_move(board, 5, 7, 16) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 0) == 1 );
assert( gamma_move(board, 1, 2, 18) == 0 );
assert( gamma_free_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 4, 14, 4) == 1 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 6, 6, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 1, 4, 1) == 1 );


char* board684148580 = gamma_board(board);
assert( board684148580 != NULL );
assert( strcmp(board684148580, 
"...56.23.616.541...5\n"
".314645...2166466.2.\n"
".231.3.5255.3223.5..\n"
"4556152.621.424.1442\n"
"63.25.351.425433..1.\n"
".26....6352..42.....\n"
"545.1463365.6.4.5.2.\n"
"4.6.6531.42656..2..3\n") == 0);
free(board684148580);
board684148580 = NULL;
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );


char* board694398642 = gamma_board(board);
assert( board694398642 != NULL );
assert( strcmp(board694398642, 
"...56.23.616.541...5\n"
".314645...2166466.2.\n"
".231.3.5255.3223.5..\n"
"4556152.6214424.1442\n"
"63.25.351.425433..1.\n"
".26....6352..42.....\n"
"545.1463365.6.4.5.2.\n"
"4.6.6531.42656..2..3\n") == 0);
free(board694398642);
board694398642 = NULL;
assert( gamma_move(board, 2, 18, 3) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_free_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 5, 5, 18) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_move(board, 6, 9, 2) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_golden_move(board, 1, 3, 6) == 1 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 5, 19, 0) == 0 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 16, 5) == 1 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 17) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_move(board, 6, 1, 17) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_move(board, 1, 2, 18) == 0 );
assert( gamma_move(board, 1, 15, 2) == 1 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_move(board, 3, 18, 3) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 7, 18) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 6, 6, 17) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );


char* board127739798 = gamma_board(board);
assert( board127739798 != NULL );
assert( strcmp(board127739798, 
"...56.23.616.541...5\n"
".311645...2166466.2.\n"
"2231.3.5255.322335..\n"
"4556152.6214424.1442\n"
"63.25.351.425433..1.\n"
".26..4.6352..421....\n"
"54511463365.6.4.5.2.\n"
"4.6.6531.42656..2..3\n") == 0);
free(board127739798);
board127739798 = NULL;
assert( gamma_move(board, 2, 1, 19) == 0 );
assert( gamma_move(board, 2, 17, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 15, 4) == 1 );
assert( gamma_move(board, 4, 0, 0) == 0 );
assert( gamma_free_fields(board, 4) == 48 );
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 5, 11) == 0 );
assert( gamma_move(board, 6, 2, 19) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 5, 19) == 0 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_golden_move(board, 5, 2, 15) == 0 );
assert( gamma_move(board, 6, 2, 16) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 4, 3, 19) == 0 );
assert( gamma_move(board, 4, 18, 4) == 0 );
assert( gamma_move(board, 6, 11, 5) == 1 );
assert( gamma_move(board, 1, 2, 18) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 4, 7, 17) == 0 );
assert( gamma_golden_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 6, 18, 1) == 0 );
assert( gamma_move(board, 1, 2, 19) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 16, 7) == 1 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 6, 10, 3) == 0 );
assert( gamma_move(board, 1, 6, 19) == 0 );
assert( gamma_golden_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 2, 2, 18) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_golden_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 6, 0, 1) == 0 );


char* board568557286 = gamma_board(board);
assert( board568557286 != NULL );
assert( strcmp(board568557286, 
"...56.23.616.5415..5\n"
".311645...2166466.2.\n"
"2231.3.52556322335..\n"
"4556152.621442441442\n"
"63.251351.425433..1.\n"
"326..4.6352..421....\n"
"54511463365.6.4.5.2.\n"
"426.6531.42656..22.3\n") == 0);
free(board568557286);
board568557286 = NULL;
assert( gamma_move(board, 1, 7, 18) == 0 );
assert( gamma_move(board, 1, 17, 2) == 1 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 3, 17) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 1, 5, 18) == 0 );
assert( gamma_move(board, 2, 1, 17) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_golden_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 6, 2, 16) == 0 );
assert( gamma_move(board, 1, 6, 19) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 18, 7) == 1 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board140545828 = gamma_board(board);
assert( board140545828 != NULL );
assert( strcmp(board140545828, 
"...56.23.616.5415.25\n"
".311645...2166466.2.\n"
"2231.3.52556322335..\n"
"4556152.621442441442\n"
"63.251351.425433..1.\n"
"326..4.6352..421.1..\n"
"54511463365.6.4.5.2.\n"
"426.6531.42656..22.3\n") == 0);
free(board140545828);
board140545828 = NULL;
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 5, 2, 16) == 0 );
assert( gamma_move(board, 6, 1, 15) == 0 );
assert( gamma_move(board, 6, 11, 3) == 0 );


char* board566693924 = gamma_board(board);
assert( board566693924 != NULL );
assert( strcmp(board566693924, 
"...56.23.616.5415.25\n"
".311645...2166466.2.\n"
"2231.3.52556322335..\n"
"4556152.621442441442\n"
"63.251351.425433..1.\n"
"326..4.6352..421.1..\n"
"54511463365.6.4.5.2.\n"
"426.6531.42656..22.3\n") == 0);
free(board566693924);
board566693924 = NULL;
assert( gamma_move(board, 1, 16, 2) == 1 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_free_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 18, 1) == 0 );
assert( gamma_free_fields(board, 4) == 40 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_move(board, 6, 12, 7) == 1 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_move(board, 2, 18, 7) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_move(board, 6, 18, 2) == 1 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 16, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_free_fields(board, 2) == 37 );


char* board421985097 = gamma_board(board);
assert( board421985097 != NULL );
assert( strcmp(board421985097, 
"...56.23.61665415.25\n"
".311645...2166466.2.\n"
"2231.3.52556322335..\n"
"4556152.621442441442\n"
"63.251351.425433..1.\n"
"3264.4.6352..421116.\n"
"54511463365.6.4.5.2.\n"
"426.6531.42656..22.3\n") == 0);
free(board421985097);
board421985097 = NULL;
assert( gamma_move(board, 3, 19, 3) == 1 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );


char* board906088724 = gamma_board(board);
assert( board906088724 != NULL );
assert( strcmp(board906088724, 
"...56.23.61665415.25\n"
".311645...2166466.2.\n"
"2231.3.52556322335..\n"
"4556152.621442441442\n"
"63.251351.425433..13\n"
"3264.4.6352..421116.\n"
"54511463365.6.4.5.2.\n"
"426.6531.42656..22.3\n") == 0);
free(board906088724);
board906088724 = NULL;
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 5, 7, 17) == 0 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 6, 1, 11) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 5, 19) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 4, 19, 2) == 1 );
assert( gamma_free_fields(board, 4) == 34 );
assert( gamma_move(board, 5, 3, 17) == 0 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 19, 4) == 0 );


char* board587566696 = gamma_board(board);
assert( board587566696 != NULL );
assert( strcmp(board587566696, 
"...56.23.61665415.25\n"
".311645...2166466.2.\n"
"2231.3.52556322335..\n"
"4556152.621442441442\n"
"63.251351.425433..13\n"
"3264.4.63521.4211164\n"
"54511463365.6.4.5.2.\n"
"426.6531.42656..22.3\n") == 0);
free(board587566696);
board587566696 = NULL;
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_move(board, 4, 18, 3) == 0 );
assert( gamma_move(board, 5, 1, 11) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 6, 14, 4) == 0 );


char* board639879672 = gamma_board(board);
assert( board639879672 != NULL );
assert( strcmp(board639879672, 
"...56.23.61665415.25\n"
".311645...2166466.2.\n"
"2231.3.52556322335..\n"
"4556152.621442441442\n"
"63.251351.425433..13\n"
"3264.4.63521.4211164\n"
"54511463365.6.4.5.2.\n"
"426.6531.42656..22.3\n") == 0);
free(board639879672);
board639879672 = NULL;
assert( gamma_move(board, 1, 5, 18) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 13, 1) == 1 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_free_fields(board, 4) == 32 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_move(board, 1, 5, 19) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );


char* board941123038 = gamma_board(board);
assert( board941123038 != NULL );
assert( strcmp(board941123038, 
"...56.23.61665415.25\n"
".311645...2166466.2.\n"
"2231.3.52556322335..\n"
"4556152.621442441442\n"
"63.251351.425433..13\n"
"3264.4263521.4211164\n"
"54511463365.634.5.2.\n"
"426.6531.42656..22.3\n") == 0);
free(board941123038);
board941123038 = NULL;
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_free_fields(board, 4) == 31 );
assert( gamma_move(board, 5, 0, 18) == 0 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_move(board, 6, 11, 1) == 1 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_free_fields(board, 1) == 30 );
assert( gamma_move(board, 2, 19, 3) == 0 );


gamma_delete(board);

    return 0;
}
