#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 136234389
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(2, 89, 5, 43);
assert( board != NULL );


assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_move(board, 1, 1, 67) == 1 );
assert( gamma_move(board, 2, 20, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 0 );
assert( gamma_move(board, 3, 56, 1) == 0 );
assert( gamma_move(board, 4, 0, 46) == 1 );
assert( gamma_move(board, 5, 0, 37) == 1 );
assert( gamma_move(board, 1, 54, 0) == 0 );
assert( gamma_free_fields(board, 1) == 175 );
assert( gamma_move(board, 2, 0, 53) == 1 );
assert( gamma_move(board, 2, 1, 50) == 1 );
assert( gamma_golden_move(board, 2, 46, 0) == 0 );
assert( gamma_move(board, 3, 87, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 0 );
assert( gamma_free_fields(board, 3) == 173 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board574915886 = gamma_board(board);
assert( board574915886 != NULL );
assert( strcmp(board574915886, 
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
".2\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"5.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n") == 0);
free(board574915886);
board574915886 = NULL;
assert( gamma_move(board, 4, 39, 1) == 0 );
assert( gamma_move(board, 4, 0, 73) == 1 );
assert( gamma_move(board, 5, 1, 70) == 1 );
assert( gamma_move(board, 1, 0, 82) == 1 );
assert( gamma_free_fields(board, 1) == 170 );
assert( gamma_move(board, 2, 1, 76) == 1 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 38, 1) == 0 );
assert( gamma_move(board, 4, 1, 8) == 1 );
assert( gamma_move(board, 1, 1, 24) == 1 );
assert( gamma_move(board, 1, 0, 35) == 1 );
assert( gamma_move(board, 2, 77, 1) == 0 );
assert( gamma_move(board, 3, 86, 0) == 0 );
assert( gamma_move(board, 4, 0, 26) == 1 );
assert( gamma_move(board, 4, 0, 68) == 1 );
assert( gamma_move(board, 5, 1, 11) == 1 );
assert( gamma_move(board, 1, 0, 74) == 1 );
assert( gamma_move(board, 1, 1, 70) == 0 );
assert( gamma_move(board, 2, 44, 1) == 0 );
assert( gamma_move(board, 3, 20, 1) == 0 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_move(board, 5, 72, 0) == 0 );
assert( gamma_move(board, 5, 0, 78) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 21, 0) == 0 );
assert( gamma_move(board, 2, 23, 1) == 0 );
assert( gamma_move(board, 2, 0, 68) == 0 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_busy_fields(board, 3) == 1 );
assert( gamma_move(board, 4, 39, 1) == 0 );
assert( gamma_move(board, 4, 1, 36) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 69) == 1 );
assert( gamma_move(board, 5, 1, 31) == 1 );
assert( gamma_golden_move(board, 5, 1, 1) == 1 );
assert( gamma_move(board, 1, 52, 0) == 0 );
assert( gamma_move(board, 1, 1, 79) == 1 );
assert( gamma_move(board, 2, 1, 49) == 1 );
assert( gamma_free_fields(board, 2) == 154 );
assert( gamma_move(board, 3, 1, 20) == 1 );
assert( gamma_move(board, 5, 1, 77) == 1 );
assert( gamma_move(board, 5, 1, 10) == 1 );


char* board598352326 = gamma_board(board);
assert( board598352326 != NULL );
assert( strcmp(board598352326, 
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"..\n"
".1\n"
"5.\n"
".5\n"
".2\n"
"..\n"
"1.\n"
"4.\n"
"..\n"
"..\n"
".5\n"
"5.\n"
"4.\n"
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
".2\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"5.\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"..\n"
".5\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
".5\n"
"..\n"
".4\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
".5\n"
"..\n") == 0);
free(board598352326);
board598352326 = NULL;
assert( gamma_move(board, 1, 1, 80) == 1 );
assert( gamma_move(board, 1, 0, 85) == 1 );
assert( gamma_move(board, 2, 0, 54) == 1 );
assert( gamma_move(board, 2, 0, 31) == 1 );
assert( gamma_move(board, 3, 52, 0) == 0 );
assert( gamma_move(board, 4, 55, 0) == 0 );
assert( gamma_move(board, 4, 1, 40) == 1 );
assert( gamma_move(board, 5, 87, 0) == 0 );
assert( gamma_move(board, 1, 30, 0) == 0 );
assert( gamma_move(board, 1, 0, 71) == 1 );
assert( gamma_move(board, 2, 88, 1) == 0 );
assert( gamma_free_fields(board, 2) == 145 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 0, 29) == 1 );
assert( gamma_move(board, 4, 41, 0) == 0 );
assert( gamma_move(board, 4, 1, 59) == 1 );


char* board707386428 = gamma_board(board);
assert( board707386428 != NULL );
assert( strcmp(board707386428, 
"..\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"5.\n"
".5\n"
".2\n"
"..\n"
"1.\n"
"4.\n"
"..\n"
"1.\n"
".5\n"
"5.\n"
"4.\n"
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
"..\n"
".2\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"5.\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"25\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"4.\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
".5\n"
"..\n"
".4\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
".5\n"
"..\n") == 0);
free(board707386428);
board707386428 = NULL;
assert( gamma_move(board, 5, 1, 9) == 1 );
assert( gamma_move(board, 5, 0, 52) == 1 );
assert( gamma_move(board, 1, 0, 35) == 0 );
assert( gamma_move(board, 1, 1, 54) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 1, 70) == 0 );
assert( gamma_move(board, 2, 0, 76) == 1 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 4, 0, 86) == 1 );
assert( gamma_move(board, 5, 58, 1) == 0 );
assert( gamma_move(board, 5, 1, 68) == 1 );


char* board722358414 = gamma_board(board);
assert( board722358414 != NULL );
assert( strcmp(board722358414, 
"..\n"
"..\n"
"4.\n"
"1.\n"
"..\n"
"..\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"5.\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"4.\n"
"..\n"
"1.\n"
".5\n"
"5.\n"
"45\n"
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"21\n"
"2.\n"
"5.\n"
"..\n"
".2\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"5.\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"25\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"4.\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
"35\n"
".5\n"
".4\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
".5\n"
"..\n") == 0);
free(board722358414);
board722358414 = NULL;
assert( gamma_move(board, 1, 1, 88) == 1 );
assert( gamma_move(board, 2, 44, 0) == 0 );
assert( gamma_move(board, 3, 87, 1) == 0 );
assert( gamma_move(board, 3, 1, 72) == 1 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_move(board, 4, 24, 0) == 0 );
assert( gamma_move(board, 5, 0, 8) == 1 );
assert( gamma_move(board, 5, 0, 47) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 41, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_move(board, 3, 22, 1) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 4, 1, 52) == 1 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 17, 1) == 0 );
assert( gamma_move(board, 5, 0, 7) == 1 );
assert( gamma_free_fields(board, 5) == 129 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 56, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 64, 1) == 0 );
assert( gamma_move(board, 2, 1, 67) == 0 );
assert( gamma_move(board, 3, 51, 0) == 0 );
assert( gamma_free_fields(board, 3) == 129 );
assert( gamma_move(board, 4, 0, 70) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 73) == 1 );
assert( gamma_move(board, 5, 1, 35) == 1 );
assert( gamma_move(board, 1, 55, 1) == 0 );
assert( gamma_move(board, 1, 0, 85) == 0 );
assert( gamma_move(board, 2, 30, 1) == 0 );
assert( gamma_move(board, 2, 0, 65) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 3, 0, 47) == 0 );
assert( gamma_move(board, 4, 45, 1) == 0 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 5, 0, 54) == 0 );
assert( gamma_golden_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 2, 1, 42) == 1 );
assert( gamma_move(board, 4, 32, 0) == 0 );
assert( gamma_move(board, 4, 1, 27) == 1 );


char* board318106804 = gamma_board(board);
assert( board318106804 != NULL );
assert( strcmp(board318106804, 
".1\n"
"..\n"
"4.\n"
"1.\n"
"..\n"
"..\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"5.\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
".1\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"5.\n"
"4.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
".4\n"
"..\n"
"..\n"
"5.\n"
".4\n"
"15\n"
"..\n"
"..\n"
"..\n"
"25\n"
"..\n"
"3.\n"
"..\n"
".4\n"
"4.\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
"35\n"
".5\n"
"54\n"
"5.\n"
"..\n"
"44\n"
"1.\n"
"..\n"
"..\n"
".5\n"
"..\n") == 0);
free(board318106804);
board318106804 = NULL;
assert( gamma_move(board, 5, 37, 1) == 0 );
assert( gamma_move(board, 5, 1, 37) == 1 );


char* board758307621 = gamma_board(board);
assert( board758307621 != NULL );
assert( strcmp(board758307621, 
".1\n"
"..\n"
"4.\n"
"1.\n"
"..\n"
"..\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"5.\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
".1\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"5.\n"
"4.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
".4\n"
"..\n"
"..\n"
"55\n"
".4\n"
"15\n"
"..\n"
"..\n"
"..\n"
"25\n"
"..\n"
"3.\n"
"..\n"
".4\n"
"4.\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
"35\n"
".5\n"
"54\n"
"5.\n"
"..\n"
"44\n"
"1.\n"
"..\n"
"..\n"
".5\n"
"..\n") == 0);
free(board758307621);
board758307621 = NULL;
assert( gamma_move(board, 1, 53, 1) == 0 );
assert( gamma_move(board, 1, 1, 65) == 1 );
assert( gamma_move(board, 2, 59, 0) == 0 );
assert( gamma_move(board, 2, 0, 78) == 0 );
assert( gamma_move(board, 3, 34, 0) == 0 );
assert( gamma_free_fields(board, 3) == 120 );
assert( gamma_move(board, 4, 1, 59) == 0 );
assert( gamma_move(board, 5, 0, 68) == 0 );
assert( gamma_move(board, 1, 0, 83) == 1 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_move(board, 2, 0, 63) == 1 );
assert( gamma_move(board, 3, 69, 1) == 0 );
assert( gamma_move(board, 4, 21, 1) == 0 );
assert( gamma_golden_move(board, 4, 72, 1) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_free_fields(board, 5) == 118 );
assert( gamma_move(board, 1, 50, 0) == 0 );
assert( gamma_move(board, 2, 1, 26) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 1, 47) == 1 );
assert( gamma_move(board, 4, 48, 1) == 0 );
assert( gamma_move(board, 4, 1, 42) == 0 );
assert( gamma_move(board, 5, 22, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );


char* board629613195 = gamma_board(board);
assert( board629613195 != NULL );
assert( strcmp(board629613195, 
".1\n"
"..\n"
"4.\n"
"1.\n"
"..\n"
"1.\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"5.\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
".1\n"
"..\n"
"21\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
".4\n"
"..\n"
"..\n"
"55\n"
".4\n"
"15\n"
"..\n"
"..\n"
"..\n"
"25\n"
"..\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
".5\n"
"35\n"
".5\n"
"54\n"
"5.\n"
"..\n"
"44\n"
"1.\n"
"..\n"
"..\n"
".5\n"
"..\n") == 0);
free(board629613195);
board629613195 = NULL;
assert( gamma_move(board, 4, 63, 1) == 0 );
assert( gamma_move(board, 5, 0, 52) == 0 );
assert( gamma_move(board, 1, 60, 0) == 0 );
assert( gamma_move(board, 2, 1, 79) == 0 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_free_fields(board, 2) == 114 );
assert( gamma_move(board, 3, 1, 37) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 0, 67) == 1 );
assert( gamma_move(board, 5, 56, 0) == 0 );
assert( gamma_move(board, 5, 0, 84) == 1 );
assert( gamma_move(board, 1, 60, 0) == 0 );
assert( gamma_move(board, 1, 1, 43) == 1 );
assert( gamma_move(board, 2, 1, 22) == 1 );
assert( gamma_move(board, 2, 0, 16) == 1 );


char* board620597851 = gamma_board(board);
assert( board620597851 != NULL );
assert( strcmp(board620597851, 
".1\n"
"..\n"
"4.\n"
"1.\n"
"5.\n"
"1.\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"5.\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
"..\n"
".1\n"
".2\n"
"..\n"
".4\n"
"..\n"
"..\n"
"55\n"
".4\n"
"15\n"
"..\n"
"..\n"
"..\n"
"25\n"
"..\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"..\n"
".2\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
"..\n"
"44\n"
"1.\n"
"..\n"
"..\n"
".5\n"
"..\n") == 0);
free(board620597851);
board620597851 = NULL;
assert( gamma_move(board, 3, 58, 1) == 0 );
assert( gamma_move(board, 5, 1, 44) == 1 );
assert( gamma_golden_move(board, 5, 49, 1) == 0 );
assert( gamma_move(board, 1, 0, 31) == 0 );
assert( gamma_move(board, 1, 1, 18) == 1 );
assert( gamma_move(board, 2, 60, 0) == 0 );
assert( gamma_move(board, 2, 0, 87) == 1 );
assert( gamma_move(board, 3, 27, 0) == 0 );
assert( gamma_move(board, 3, 1, 16) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 70) == 0 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_free_fields(board, 4) == 105 );
assert( gamma_move(board, 5, 1, 56) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 1, 85) == 1 );
assert( gamma_move(board, 1, 0, 74) == 0 );
assert( gamma_move(board, 2, 48, 0) == 0 );
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 62, 1) == 0 );
assert( gamma_move(board, 4, 0, 32) == 1 );
assert( gamma_move(board, 5, 87, 1) == 0 );
assert( gamma_move(board, 5, 0, 32) == 0 );


char* board457991904 = gamma_board(board);
assert( board457991904 != NULL );
assert( strcmp(board457991904, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"5.\n"
"1.\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"5.\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
".5\n"
"..\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
".5\n"
".1\n"
".2\n"
"..\n"
".4\n"
"..\n"
"..\n"
"55\n"
".4\n"
"15\n"
"..\n"
"..\n"
"4.\n"
"25\n"
"..\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"..\n"
".2\n"
"..\n"
".3\n"
"..\n"
".1\n"
"..\n"
"23\n"
"..\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
"..\n"
"..\n"
".5\n"
"..\n") == 0);
free(board457991904);
board457991904 = NULL;
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 44, 0) == 0 );
assert( gamma_move(board, 4, 86, 1) == 0 );
assert( gamma_move(board, 5, 0, 76) == 0 );
assert( gamma_move(board, 1, 1, 84) == 1 );
assert( gamma_move(board, 2, 66, 0) == 0 );
assert( gamma_move(board, 2, 1, 78) == 1 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 71, 1) == 0 );
assert( gamma_move(board, 4, 0, 74) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 47, 1) == 0 );
assert( gamma_move(board, 5, 1, 78) == 0 );
assert( gamma_move(board, 1, 75, 1) == 0 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board432872497 = gamma_board(board);
assert( board432872497 != NULL );
assert( strcmp(board432872497, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
".5\n"
"..\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
".5\n"
".1\n"
".2\n"
"..\n"
".4\n"
"..\n"
"..\n"
"55\n"
".4\n"
"15\n"
"..\n"
"..\n"
"4.\n"
"25\n"
"..\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"..\n"
".2\n"
"..\n"
".3\n"
"..\n"
".1\n"
"..\n"
"23\n"
"..\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
"..\n"
"..\n"
".5\n"
"2.\n") == 0);
free(board432872497);
board432872497 = NULL;
assert( gamma_move(board, 3, 49, 0) == 0 );


char* board704312292 = gamma_board(board);
assert( board704312292 != NULL );
assert( strcmp(board704312292, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"1.\n"
"..\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
".5\n"
"..\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
".5\n"
".1\n"
".2\n"
"..\n"
".4\n"
"..\n"
"..\n"
"55\n"
".4\n"
"15\n"
"..\n"
"..\n"
"4.\n"
"25\n"
"..\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"..\n"
".2\n"
"..\n"
".3\n"
"..\n"
".1\n"
"..\n"
"23\n"
"..\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
"..\n"
"..\n"
".5\n"
"2.\n") == 0);
free(board704312292);
board704312292 = NULL;
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 25, 1) == 0 );
assert( gamma_move(board, 1, 0, 34) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 3, 57, 1) == 0 );
assert( gamma_move(board, 3, 1, 81) == 1 );
assert( gamma_move(board, 4, 44, 0) == 0 );
assert( gamma_move(board, 5, 0, 55) == 1 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 1, 43, 0) == 0 );
assert( gamma_move(board, 1, 0, 23) == 1 );
assert( gamma_move(board, 2, 57, 1) == 0 );
assert( gamma_move(board, 3, 51, 1) == 0 );
assert( gamma_move(board, 4, 19, 0) == 0 );
assert( gamma_move(board, 4, 0, 15) == 1 );
assert( gamma_move(board, 5, 0, 64) == 1 );
assert( gamma_move(board, 1, 38, 0) == 0 );
assert( gamma_move(board, 1, 0, 67) == 0 );
assert( gamma_free_fields(board, 1) == 91 );
assert( gamma_move(board, 2, 60, 0) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 4, 38, 1) == 0 );
assert( gamma_move(board, 4, 0, 18) == 1 );
assert( gamma_move(board, 5, 29, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 0, 56) == 1 );
assert( gamma_free_fields(board, 1) == 89 );
assert( gamma_move(board, 2, 0, 40) == 1 );
assert( gamma_move(board, 2, 1, 21) == 1 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 0, 44) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 88, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_free_fields(board, 4) == 86 );
assert( gamma_move(board, 5, 62, 1) == 0 );


char* board665466305 = gamma_board(board);
assert( board665466305 != NULL );
assert( strcmp(board665466305, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"1.\n"
".3\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
"35\n"
".1\n"
".2\n"
"..\n"
"24\n"
"..\n"
"..\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"..\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"..\n"
"41\n"
"..\n"
"23\n"
"4.\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"..\n"
".5\n"
"2.\n") == 0);
free(board665466305);
board665466305 = NULL;
assert( gamma_move(board, 1, 41, 1) == 0 );
assert( gamma_move(board, 2, 0, 38) == 1 );
assert( gamma_move(board, 2, 0, 19) == 1 );
assert( gamma_move(board, 3, 75, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 57) == 1 );
assert( gamma_move(board, 5, 1, 82) == 1 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 3, 0, 30) == 1 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 4, 1, 60) == 1 );


char* board716156729 = gamma_board(board);
assert( board716156729 != NULL );
assert( strcmp(board716156729, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
".3\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
".4\n"
".4\n"
"..\n"
".4\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
"35\n"
".1\n"
".2\n"
"..\n"
"24\n"
"..\n"
"2.\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"3.\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"4.\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"..\n"
"25\n"
"2.\n") == 0);
free(board716156729);
board716156729 = NULL;
assert( gamma_move(board, 5, 28, 1) == 0 );
assert( gamma_move(board, 5, 1, 20) == 0 );
assert( gamma_move(board, 1, 28, 1) == 0 );


char* board480130117 = gamma_board(board);
assert( board480130117 != NULL );
assert( strcmp(board480130117, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
".3\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
".4\n"
".4\n"
"..\n"
".4\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
"35\n"
".1\n"
".2\n"
"..\n"
"24\n"
"..\n"
"2.\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"3.\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"4.\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"..\n"
"25\n"
"2.\n") == 0);
free(board480130117);
board480130117 = NULL;
assert( gamma_move(board, 2, 48, 0) == 0 );
assert( gamma_move(board, 2, 0, 64) == 0 );
assert( gamma_move(board, 3, 41, 1) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 0, 26) == 0 );
assert( gamma_move(board, 4, 0, 19) == 0 );
assert( gamma_move(board, 5, 1, 73) == 0 );
assert( gamma_move(board, 1, 24, 0) == 0 );
assert( gamma_move(board, 1, 1, 59) == 0 );


char* board897704781 = gamma_board(board);
assert( board897704781 != NULL );
assert( strcmp(board897704781, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
".3\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
".4\n"
".4\n"
"..\n"
".4\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
"..\n"
"35\n"
".1\n"
".2\n"
"..\n"
"24\n"
"..\n"
"2.\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"3.\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"4.\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"..\n"
"25\n"
"2.\n") == 0);
free(board897704781);
board897704781 = NULL;
assert( gamma_move(board, 2, 1, 45) == 1 );
assert( gamma_move(board, 2, 1, 41) == 1 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board403835666 = gamma_board(board);
assert( board403835666 != NULL );
assert( strcmp(board403835666, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
".3\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
".4\n"
".4\n"
"..\n"
".4\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
".2\n"
"35\n"
".1\n"
".2\n"
".2\n"
"24\n"
"..\n"
"2.\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"3.\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"..\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"4.\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"..\n"
"25\n"
"2.\n") == 0);
free(board403835666);
board403835666 = NULL;
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 1, 79) == 0 );
assert( gamma_move(board, 4, 0, 25) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 20, 0) == 0 );
assert( gamma_move(board, 5, 1, 84) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_free_fields(board, 1) == 76 );
assert( gamma_move(board, 2, 25, 1) == 0 );
assert( gamma_move(board, 3, 27, 0) == 0 );
assert( gamma_move(board, 4, 39, 0) == 0 );
assert( gamma_move(board, 4, 1, 58) == 1 );
assert( gamma_move(board, 5, 66, 1) == 0 );


char* board533166735 = gamma_board(board);
assert( board533166735 != NULL );
assert( strcmp(board533166735, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
".3\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"..\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
".4\n"
".4\n"
".4\n"
".4\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
".2\n"
"35\n"
".1\n"
".2\n"
".2\n"
"24\n"
"..\n"
"2.\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"3.\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"4.\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"4.\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"..\n"
"25\n"
"2.\n") == 0);
free(board533166735);
board533166735 = NULL;
assert( gamma_move(board, 1, 57, 0) == 0 );
assert( gamma_move(board, 2, 58, 0) == 0 );
assert( gamma_move(board, 2, 0, 47) == 0 );
assert( gamma_free_fields(board, 2) == 75 );
assert( gamma_move(board, 3, 57, 0) == 0 );
assert( gamma_move(board, 4, 0, 75) == 1 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 24 );
assert( gamma_move(board, 1, 49, 0) == 0 );
assert( gamma_move(board, 1, 1, 82) == 0 );
assert( gamma_move(board, 2, 25, 1) == 0 );
assert( gamma_move(board, 2, 1, 81) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 5, 1, 45) == 0 );
assert( gamma_move(board, 2, 86, 1) == 0 );
assert( gamma_move(board, 2, 1, 76) == 0 );
assert( gamma_move(board, 3, 77, 0) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 0, 60) == 1 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_move(board, 5, 32, 1) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 33, 0) == 0 );
assert( gamma_move(board, 3, 22, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board883945571 = gamma_board(board);
assert( board883945571 != NULL );
assert( strcmp(board883945571, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
".3\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"4.\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
"44\n"
".4\n"
".4\n"
".4\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
".2\n"
"35\n"
".1\n"
".2\n"
".2\n"
"24\n"
"..\n"
"2.\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"3.\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"4.\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"4.\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"3.\n"
"25\n"
"2.\n") == 0);
free(board883945571);
board883945571 = NULL;
assert( gamma_move(board, 4, 33, 0) == 0 );
assert( gamma_move(board, 4, 0, 57) == 1 );


char* board916878616 = gamma_board(board);
assert( board916878616 != NULL );
assert( strcmp(board916878616, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
".3\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"4.\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
"44\n"
".4\n"
".4\n"
"44\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
".2\n"
"35\n"
".1\n"
".2\n"
".2\n"
"24\n"
"..\n"
"2.\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"3.\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"4.\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"4.\n"
"..\n"
"..\n"
".1\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"3.\n"
"25\n"
"2.\n") == 0);
free(board916878616);
board916878616 = NULL;
assert( gamma_move(board, 5, 61, 1) == 0 );
assert( gamma_move(board, 5, 0, 41) == 1 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 1, 0, 81) == 1 );
assert( gamma_move(board, 2, 0, 70) == 0 );
assert( gamma_move(board, 3, 0, 56) == 0 );
assert( gamma_move(board, 3, 0, 63) == 0 );
assert( gamma_move(board, 4, 66, 0) == 0 );
assert( gamma_move(board, 4, 0, 35) == 0 );
assert( gamma_move(board, 5, 28, 1) == 0 );
assert( gamma_move(board, 5, 1, 56) == 0 );
assert( gamma_move(board, 1, 77, 0) == 0 );
assert( gamma_move(board, 1, 0, 52) == 0 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 51, 1) == 0 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 0, 52) == 0 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 28, 1) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 50, 0) == 0 );
assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );


char* board182994528 = gamma_board(board);
assert( board182994528 != NULL );
assert( strcmp(board182994528, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
"13\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"4.\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"..\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
"44\n"
".4\n"
".4\n"
"44\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
"..\n"
"53\n"
"4.\n"
".2\n"
"35\n"
".1\n"
".2\n"
"52\n"
"24\n"
"..\n"
"2.\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"..\n"
"4.\n"
"25\n"
"3.\n"
"3.\n"
"..\n"
".4\n"
"42\n"
"4.\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"43\n"
"..\n"
"..\n"
"11\n"
"25\n"
"35\n"
".5\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"3.\n"
"25\n"
"2.\n") == 0);
free(board182994528);
board182994528 = NULL;
assert( gamma_move(board, 2, 49, 0) == 0 );
assert( gamma_move(board, 3, 1, 66) == 1 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_move(board, 4, 1, 52) == 0 );
assert( gamma_move(board, 4, 1, 48) == 1 );
assert( gamma_move(board, 5, 21, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 1, 19, 1) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 86, 1) == 0 );
assert( gamma_move(board, 2, 1, 37) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 4, 1, 30) == 1 );
assert( gamma_move(board, 5, 1, 49) == 0 );
assert( gamma_move(board, 5, 1, 80) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 1, 79, 0) == 0 );
assert( gamma_move(board, 1, 0, 81) == 0 );
assert( gamma_move(board, 2, 36, 0) == 0 );
assert( gamma_move(board, 3, 61, 0) == 0 );
assert( gamma_move(board, 4, 51, 0) == 0 );
assert( gamma_move(board, 4, 0, 71) == 0 );
assert( gamma_free_fields(board, 4) == 63 );
assert( gamma_move(board, 5, 63, 1) == 0 );
assert( gamma_move(board, 1, 27, 0) == 0 );
assert( gamma_move(board, 2, 21, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 75, 1) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 0, 46) == 0 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 1, 0, 34) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 1, 22) == 0 );
assert( gamma_free_fields(board, 2) == 62 );
assert( gamma_move(board, 3, 0, 68) == 0 );
assert( gamma_move(board, 3, 1, 29) == 1 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 22, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 24, 0) == 0 );
assert( gamma_move(board, 1, 45, 0) == 0 );
assert( gamma_move(board, 1, 1, 33) == 1 );
assert( gamma_move(board, 2, 0, 43) == 1 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 5, 46, 1) == 0 );
assert( gamma_move(board, 1, 87, 1) == 0 );
assert( gamma_move(board, 1, 1, 38) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 46, 1) == 0 );
assert( gamma_move(board, 2, 0, 35) == 0 );
assert( gamma_move(board, 3, 0, 42) == 1 );
assert( gamma_golden_move(board, 3, 59, 1) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_free_fields(board, 5) == 56 );


char* board908607977 = gamma_board(board);
assert( board908607977 != NULL );
assert( strcmp(board908607977, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"1.\n"
"15\n"
"13\n"
".1\n"
".1\n"
"52\n"
".5\n"
"22\n"
"4.\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
".3\n"
"21\n"
"5.\n"
"2.\n"
"..\n"
"..\n"
"44\n"
".4\n"
".4\n"
"44\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"..\n"
".2\n"
".2\n"
".4\n"
"53\n"
"4.\n"
".2\n"
"35\n"
"21\n"
"32\n"
"52\n"
"24\n"
"..\n"
"21\n"
"55\n"
".4\n"
"15\n"
"1.\n"
".1\n"
"4.\n"
"25\n"
"34\n"
"33\n"
"..\n"
".4\n"
"42\n"
"4.\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"43\n"
"..\n"
"..\n"
"11\n"
"25\n"
"35\n"
"45\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"34\n"
"25\n"
"23\n") == 0);
free(board908607977);
board908607977 = NULL;
assert( gamma_move(board, 1, 22, 0) == 0 );
assert( gamma_move(board, 2, 72, 0) == 0 );
assert( gamma_move(board, 2, 1, 79) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 75) == 0 );
assert( gamma_move(board, 4, 1, 64) == 1 );
assert( gamma_move(board, 4, 0, 83) == 0 );
assert( gamma_free_fields(board, 4) == 55 );
assert( gamma_move(board, 5, 22, 0) == 0 );
assert( gamma_move(board, 1, 22, 0) == 0 );
assert( gamma_move(board, 1, 0, 34) == 0 );
assert( gamma_golden_move(board, 1, 67, 0) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 50, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_golden_move(board, 4, 53, 1) == 0 );
assert( gamma_move(board, 5, 1, 30) == 0 );
assert( gamma_move(board, 1, 1, 62) == 1 );
assert( gamma_move(board, 1, 1, 54) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 2, 0, 58) == 1 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 1, 83) == 1 );
assert( gamma_move(board, 3, 0, 26) == 0 );
assert( gamma_move(board, 4, 1, 73) == 0 );
assert( gamma_move(board, 4, 1, 46) == 1 );
assert( gamma_move(board, 5, 87, 1) == 0 );
assert( gamma_move(board, 5, 1, 84) == 0 );
assert( gamma_move(board, 1, 74, 1) == 0 );
assert( gamma_move(board, 2, 63, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 1, 68) == 0 );
assert( gamma_move(board, 4, 23, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 31 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 20, 0) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 0, 80) == 1 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 1, 51, 0) == 0 );
assert( gamma_move(board, 2, 1, 52) == 0 );
assert( gamma_move(board, 2, 0, 62) == 1 );
assert( gamma_move(board, 4, 32, 1) == 0 );
assert( gamma_move(board, 5, 55, 1) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 1, 1, 50) == 0 );
assert( gamma_busy_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 23, 1) == 0 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 21, 0) == 0 );
assert( gamma_move(board, 3, 0, 33) == 1 );
assert( gamma_move(board, 4, 0, 68) == 0 );
assert( gamma_move(board, 5, 28, 1) == 0 );
assert( gamma_move(board, 1, 17, 0) == 0 );
assert( gamma_move(board, 1, 1, 38) == 0 );
assert( gamma_move(board, 2, 1, 20) == 0 );
assert( gamma_move(board, 3, 0, 68) == 0 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 27, 0) == 0 );
assert( gamma_move(board, 4, 0, 59) == 1 );
assert( gamma_move(board, 5, 21, 0) == 0 );
assert( gamma_move(board, 5, 0, 40) == 0 );
assert( gamma_move(board, 1, 23, 1) == 0 );
assert( gamma_move(board, 1, 0, 87) == 0 );
assert( gamma_move(board, 2, 36, 0) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 0, 51) == 1 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 5, 1, 82) == 0 );
assert( gamma_move(board, 5, 0, 19) == 0 );
assert( gamma_move(board, 1, 61, 1) == 0 );
assert( gamma_move(board, 2, 74, 1) == 0 );
assert( gamma_move(board, 2, 0, 31) == 0 );
assert( gamma_move(board, 3, 34, 1) == 0 );
assert( gamma_move(board, 3, 0, 66) == 1 );
assert( gamma_free_fields(board, 3) == 44 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 5, 0, 29) == 0 );


char* board464346572 = gamma_board(board);
assert( board464346572 != NULL );
assert( strcmp(board464346572, 
".1\n"
"2.\n"
"4.\n"
"11\n"
"51\n"
"13\n"
"15\n"
"13\n"
"31\n"
".1\n"
"52\n"
".5\n"
"22\n"
"4.\n"
"1.\n"
"45\n"
".3\n"
"1.\n"
"45\n"
"5.\n"
"45\n"
"41\n"
"33\n"
"21\n"
"54\n"
"2.\n"
"21\n"
"..\n"
"44\n"
"44\n"
"24\n"
"44\n"
"15\n"
"5.\n"
"21\n"
"2.\n"
"54\n"
"3.\n"
".2\n"
".2\n"
".4\n"
"53\n"
"44\n"
".2\n"
"35\n"
"21\n"
"32\n"
"52\n"
"24\n"
"..\n"
"21\n"
"55\n"
".4\n"
"15\n"
"1.\n"
"31\n"
"4.\n"
"25\n"
"34\n"
"33\n"
"..\n"
".4\n"
"42\n"
"4.\n"
".1\n"
"1.\n"
".2\n"
".2\n"
".3\n"
"2.\n"
"41\n"
"..\n"
"23\n"
"43\n"
"2.\n"
"..\n"
"11\n"
"25\n"
"35\n"
"45\n"
"54\n"
"5.\n"
".3\n"
"44\n"
"1.\n"
".2\n"
"34\n"
"25\n"
"23\n") == 0);
free(board464346572);
board464346572 = NULL;
assert( gamma_move(board, 1, 0, 17) == 1 );
assert( gamma_move(board, 1, 1, 49) == 0 );
assert( gamma_free_fields(board, 1) == 43 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 75, 1) == 0 );
assert( gamma_move(board, 4, 0, 63) == 0 );
assert( gamma_move(board, 4, 1, 52) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 5, 36, 0) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 0, 78) == 0 );
assert( gamma_free_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 69, 1) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 3, 69, 1) == 0 );
assert( gamma_move(board, 4, 48, 0) == 0 );
assert( gamma_move(board, 4, 0, 57) == 0 );
assert( gamma_move(board, 5, 28, 0) == 0 );
assert( gamma_move(board, 5, 1, 22) == 0 );
assert( gamma_move(board, 1, 0, 17) == 0 );
assert( gamma_move(board, 2, 28, 0) == 0 );
assert( gamma_move(board, 4, 1, 35) == 0 );
assert( gamma_move(board, 4, 0, 48) == 1 );
assert( gamma_move(board, 5, 49, 0) == 0 );
assert( gamma_move(board, 5, 0, 45) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 0, 50) == 1 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_free_fields(board, 2) == 40 );
assert( gamma_move(board, 3, 87, 1) == 0 );
assert( gamma_move(board, 4, 0, 78) == 0 );
assert( gamma_move(board, 5, 1, 61) == 1 );
assert( gamma_move(board, 5, 1, 64) == 0 );
assert( gamma_busy_fields(board, 5) == 27 );
assert( gamma_golden_move(board, 5, 46, 1) == 0 );
assert( gamma_move(board, 1, 1, 58) == 0 );
assert( gamma_move(board, 2, 23, 1) == 0 );
assert( gamma_move(board, 4, 0, 81) == 0 );
assert( gamma_move(board, 5, 0, 34) == 0 );
assert( gamma_move(board, 5, 1, 20) == 0 );
assert( gamma_move(board, 1, 1, 31) == 0 );
assert( gamma_free_fields(board, 1) == 39 );
assert( gamma_golden_move(board, 1, 45, 1) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 74, 1) == 0 );
assert( gamma_move(board, 4, 53, 1) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 5, 0, 70) == 0 );
assert( gamma_move(board, 1, 49, 0) == 0 );
assert( gamma_move(board, 1, 0, 34) == 0 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 61, 0) == 0 );
assert( gamma_move(board, 4, 0, 23) == 0 );
assert( gamma_move(board, 1, 0, 62) == 0 );
assert( gamma_move(board, 2, 55, 1) == 0 );
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_move(board, 3, 0, 39) == 1 );
assert( gamma_move(board, 4, 36, 0) == 0 );
assert( gamma_move(board, 4, 1, 82) == 0 );
assert( gamma_move(board, 5, 1, 45) == 0 );
assert( gamma_move(board, 1, 20, 0) == 0 );
assert( gamma_move(board, 1, 1, 34) == 1 );
assert( gamma_golden_move(board, 1, 19, 0) == 0 );
assert( gamma_move(board, 2, 28, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 74) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 1, 70) == 0 );
assert( gamma_move(board, 5, 20, 0) == 0 );
assert( gamma_move(board, 5, 1, 61) == 0 );
assert( gamma_golden_move(board, 5, 51, 0) == 0 );
assert( gamma_move(board, 1, 1, 63) == 1 );
assert( gamma_move(board, 1, 0, 53) == 0 );
assert( gamma_golden_move(board, 1, 21, 0) == 0 );
assert( gamma_move(board, 2, 1, 17) == 1 );
assert( gamma_move(board, 3, 79, 0) == 0 );
assert( gamma_move(board, 3, 1, 59) == 0 );
assert( gamma_move(board, 4, 0, 83) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 1, 25, 1) == 0 );
assert( gamma_golden_move(board, 2, 51, 0) == 0 );
assert( gamma_move(board, 3, 39, 1) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 4, 1, 20) == 0 );
assert( gamma_move(board, 5, 1, 87) == 1 );
assert( gamma_move(board, 1, 55, 1) == 0 );
assert( gamma_free_fields(board, 1) == 34 );


gamma_delete(board);

    return 0;
}
