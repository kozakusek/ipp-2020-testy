#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 116659174
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 11, 5, 36);
assert( board != NULL );


assert( gamma_move(board, 1, 16, 8) == 1 );
assert( gamma_move(board, 1, 13, 0) == 1 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 5, 16, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 1 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 2, 13, 1) == 1 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_move(board, 5, 9, 0) == 1 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 1, 14, 8) == 1 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_golden_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 3, 16, 6) == 1 );
assert( gamma_free_fields(board, 3) == 179 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 2 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 1, 9, 6) == 1 );
assert( gamma_move(board, 1, 14, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 4 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_move(board, 5, 4, 10) == 1 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 2, 15, 2) == 1 );
assert( gamma_move(board, 3, 2, 16) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 8, 10) == 1 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 5, 8, 9) == 0 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 2, 9, 7) == 1 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_free_fields(board, 3) == 160 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 5, 14, 0) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 1, 13, 2) == 1 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 14, 1) == 1 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 3, 8, 10) == 0 );


char* board526875087 = gamma_board(board);
assert( board526875087 != NULL );
assert( strcmp(board526875087, 
"...153.15.........\n"
"....33..33........\n"
"2..3....2.....1.1.\n"
".........2........\n"
".3233....1......3.\n"
"1....2..1.........\n"
".......1......1...\n"
"..................\n"
".3.....1.....1.2..\n"
"..2..4.41....22...\n"
".5...24..5...15.5.\n") == 0);
free(board526875087);
board526875087 = NULL;
assert( gamma_move(board, 4, 7, 8) == 1 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 17, 0) == 1 );
assert( gamma_golden_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 1, 7, 16) == 0 );
assert( gamma_move(board, 1, 15, 3) == 1 );
assert( gamma_move(board, 2, 3, 17) == 0 );
assert( gamma_free_fields(board, 2) == 151 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_move(board, 1, 15, 6) == 1 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_free_fields(board, 2) == 147 );
assert( gamma_move(board, 3, 12, 3) == 1 );


char* board924029981 = gamma_board(board);
assert( board924029981 != NULL );
assert( strcmp(board924029981, 
"...153.15.........\n"
"...133..33.3......\n"
"2..3.3.42.....1.1.\n"
".........2........\n"
".3233....1.....13.\n"
"1.4..2..1.........\n"
".......1......1...\n"
"............3..1..\n"
".3.....1.....1.2..\n"
"..2..4.41....22...\n"
".5...24..5...15.55\n") == 0);
free(board924029981);
board924029981 = NULL;
assert( gamma_move(board, 4, 15, 4) == 1 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_move(board, 5, 4, 8) == 1 );
assert( gamma_golden_move(board, 5, 10, 8) == 1 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 2, 4) == 1 );
assert( gamma_golden_move(board, 1, 10, 8) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_move(board, 5, 11, 0) == 1 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_move(board, 3, 10, 16) == 0 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 9, 2) == 1 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 1, 17, 6) == 1 );
assert( gamma_busy_fields(board, 1) == 20 );
assert( gamma_move(board, 2, 2, 10) == 1 );
assert( gamma_golden_move(board, 2, 6, 17) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_golden_move(board, 4, 10, 8) == 1 );


char* board232139745 = gamma_board(board);
assert( board232139745 != NULL );
assert( strcmp(board232139745, 
"3.2153.15.........\n"
"...1334.33.3.2....\n"
"2..353.42.4...1.1.\n"
".1.......2........\n"
".3233....1.....131\n"
"1.4..24.1.........\n"
"..1..3.1......14..\n"
"....4.......3..1..\n"
".3.....1.5...1.2..\n"
"..2..4.41....22...\n"
".5...24..5.5.15.55\n") == 0);
free(board232139745);
board232139745 = NULL;
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_free_fields(board, 5) == 131 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 8, 17) == 0 );
assert( gamma_move(board, 3, 16, 8) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 5, 0, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 10, 10) == 1 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 4, 16, 10) == 1 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_golden_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 1, 16, 5) == 1 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 17, 4) == 1 );
assert( gamma_free_fields(board, 2) == 123 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_free_fields(board, 3) == 123 );
assert( gamma_move(board, 4, 5, 13) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 2, 1, 17) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_free_fields(board, 4) == 120 );
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 1, 13, 3) == 1 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 4, 10, 9) == 1 );
assert( gamma_free_fields(board, 4) == 115 );
assert( gamma_move(board, 5, 17, 7) == 1 );
assert( gamma_move(board, 1, 2, 8) == 1 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 5, 7, 16) == 0 );
assert( gamma_move(board, 5, 3, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );


char* board398133319 = gamma_board(board);
assert( board398133319 != NULL );
assert( strcmp(board398133319, 
"3.2153215.1.....4.\n"
"...1334.3343.2....\n"
"2.1353142.4...1.1.\n"
".1.......24......5\n"
".3233551.3...1.131\n"
"1.41.24.1.......1.\n"
"5.15.3.1......14.2\n"
".3..4.......31.1..\n"
".3.....1.5...1.2..\n"
"..2..4.41....22...\n"
".533.24..5.5.15.55\n") == 0);
free(board398133319);
board398133319 = NULL;
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_golden_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_golden_move(board, 3, 8, 8) == 0 );


char* board571536960 = gamma_board(board);
assert( board571536960 != NULL );
assert( strcmp(board571536960, 
"3.2153215.1.....4.\n"
"...1334.3343.2....\n"
"2.1353142.42..1.1.\n"
".1.......24......5\n"
".3233551.3...1.131\n"
"1.41.24.1.......1.\n"
"5.15.3.1......14.2\n"
".3..4.......31.1..\n"
".3.....1.5...1.2..\n"
"..2..4.41....22...\n"
".533.24..5.5.15.55\n") == 0);
free(board571536960);
board571536960 = NULL;
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 5, 11, 4) == 1 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 4, 12, 0) == 1 );
assert( gamma_move(board, 5, 1, 4) == 1 );
assert( gamma_move(board, 5, 7, 6) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 1, 8, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_free_fields(board, 2) == 103 );
assert( gamma_free_fields(board, 3) == 103 );
assert( gamma_golden_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 2, 16) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 1, 17) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 4, 2, 17) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 5, 9, 16) == 0 );
assert( gamma_move(board, 5, 0, 7) == 1 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 30 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 4, 0, 6) == 1 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board452762129 = gamma_board(board);
assert( board452762129 != NULL );
assert( strcmp(board452762129, 
"3.2153215.1.....4.\n"
"...1334.3343.2....\n"
"2.1353142.42..1.1.\n"
"51.....2.24......5\n"
"43233551.3...1.131\n"
"1.41.24.1.1.....1.\n"
"5515.3.1...5..14.2\n"
".3..4....1..31.1..\n"
".3.....115...1.2..\n"
"..2..4.41..1.22...\n"
".533.24..5.5415.55\n") == 0);
free(board452762129);
board452762129 = NULL;
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 3, 10, 17) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_move(board, 5, 10, 1) == 1 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 5, 2, 2) == 1 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_free_fields(board, 1) == 93 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 5, 8, 15) == 0 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 1, 16, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 12, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 4, 14, 9) == 1 );
assert( gamma_move(board, 5, 4, 16) == 0 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 1, 4, 16) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 9, 12) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_free_fields(board, 3) == 85 );


char* board648053337 = gamma_board(board);
assert( board648053337 != NULL );
assert( strcmp(board648053337, 
"3.2153215.1.....4.\n"
"...1334.3343.24...\n"
"231353142.42..1.1.\n"
"51.....2.24.3....5\n"
"43233551.3...1.131\n"
"1.4122431.14....1.\n"
"5515.3.1.1.5..14.2\n"
".3.44..2.1..31.1..\n"
".351...115...1.2..\n"
".22..4.41251.22...\n"
".533.24..5.5415.55\n") == 0);
free(board648053337);
board648053337 = NULL;
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 1, 1) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 1, 12, 9) == 1 );
assert( gamma_move(board, 2, 10, 15) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_free_fields(board, 3) == 83 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 5, 12, 7) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_free_fields(board, 1) == 83 );


char* board263226124 = gamma_board(board);
assert( board263226124 != NULL );
assert( strcmp(board263226124, 
"3.2153215.1.....4.\n"
"...133433343124...\n"
"231353142.42..1.1.\n"
"51.....2.24.3....5\n"
"43233551.3...1.131\n"
"1.4122431.14....1.\n"
"5515.3.1.1.5..14.2\n"
".3.44..2.1..31.1..\n"
".351...115...1.2..\n"
".22..4.41251.22...\n"
".533.24..5.5415.55\n") == 0);
free(board263226124);
board263226124 = NULL;
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_free_fields(board, 3) == 82 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_free_fields(board, 4) == 82 );
assert( gamma_move(board, 5, 10, 3) == 1 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 4, 16) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 6, 10) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 16, 8) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_free_fields(board, 2) == 79 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 17, 10) == 1 );
assert( gamma_move(board, 4, 7, 14) == 0 );
assert( gamma_move(board, 4, 10, 6) == 1 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 5, 12, 10) == 1 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 17, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_free_fields(board, 5) == 76 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_move(board, 1, 17, 1) == 1 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_free_fields(board, 2) == 75 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 3, 16, 3) == 1 );
assert( gamma_golden_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 5, 12) == 0 );
assert( gamma_move(board, 4, 17, 3) == 1 );
assert( gamma_golden_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 5, 5, 15) == 0 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_free_fields(board, 5) == 72 );


char* board980745108 = gamma_board(board);
assert( board980745108 != NULL );
assert( strcmp(board980745108, 
"3.2153215.1.5...43\n"
"1..133433343124...\n"
"231353142.42..1.1.\n"
"51.....2.24.3....5\n"
"43233551.34..1.131\n"
"1.4122431.14....1.\n"
"5515.3.1.1.5..14.2\n"
".3.44..2.15.31.134\n"
".351..2115...1.2..\n"
".22..4241251.22..1\n"
"5533.24..5.5415.55\n") == 0);
free(board980745108);
board980745108 = NULL;
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_golden_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 17, 2) == 1 );
assert( gamma_move(board, 2, 15, 8) == 1 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 2, 17, 8) == 1 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_golden_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 3, 15, 10) == 1 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_free_fields(board, 4) == 67 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 17, 9) == 1 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 1, 15, 5) == 1 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 5, 8, 8) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_golden_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 5, 8, 7) == 1 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 2, 11, 3) == 1 );
assert( gamma_move(board, 3, 12, 1) == 1 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 2, 11, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 5, 7, 6) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 1, 16, 6) == 0 );


char* board567875479 = gamma_board(board);
assert( board567875479 != NULL );
assert( strcmp(board567875479, 
"3.2153215.1.5..343\n"
"1..133433343124..4\n"
"231353142.42..1212\n"
"51.....252423....5\n"
"43233551.34.31.131\n"
"1.4122431.14...11.\n"
"551513.1.1.5..14.2\n"
".3.44..2.15231.134\n"
".351..2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24.15.5415.55\n") == 0);
free(board567875479);
board567875479 = NULL;
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 17, 9) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 16) == 0 );
assert( gamma_move(board, 3, 8, 6) == 1 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 5, 8, 12) == 0 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board318214605 = gamma_board(board);
assert( board318214605 != NULL );
assert( strcmp(board318214605, 
"3.2153215.1.5..343\n"
"1..133433343124..4\n"
"231353142.42..1212\n"
"51.....252423....5\n"
"43233551334231.131\n"
"1.4122431.14...11.\n"
"551513.1.1.5..14.2\n"
"43.44..2.15231.134\n"
".351..2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24.15.5415.55\n") == 0);
free(board318214605);
board318214605 = NULL;
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 5, 10) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 1, 9, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_busy_fields(board, 2) == 28 );
assert( gamma_move(board, 3, 1, 4) == 0 );


char* board603520638 = gamma_board(board);
assert( board603520638 != NULL );
assert( strcmp(board603520638, 
"3.2153215.1.5..343\n"
"1..133433343124..4\n"
"231353142.42..1212\n"
"51.....252423....5\n"
"43233551334231.131\n"
"1.4122431114...11.\n"
"551513.1.1.5..14.2\n"
"43.44..2.15231.134\n"
".351..2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24.15.5415.55\n") == 0);
free(board603520638);
board603520638 = NULL;
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 15, 10) == 0 );
assert( gamma_move(board, 5, 16, 3) == 0 );
assert( gamma_move(board, 5, 16, 3) == 0 );
assert( gamma_golden_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_free_fields(board, 2) == 52 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 14, 9) == 0 );
assert( gamma_move(board, 5, 12, 5) == 1 );
assert( gamma_move(board, 1, 12, 8) == 1 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 5, 9, 16) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 14, 5) == 1 );
assert( gamma_free_fields(board, 2) == 48 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_golden_move(board, 5, 5, 10) == 0 );
assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_free_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 9, 10) == 1 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_golden_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 16) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 3, 3, 9) == 0 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 5, 9, 8) == 1 );
assert( gamma_free_fields(board, 5) == 45 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 1, 13, 5) == 1 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_golden_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 4, 17, 1) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 5, 7, 0) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 4, 4, 16) == 0 );
assert( gamma_move(board, 5, 17, 10) == 0 );
assert( gamma_move(board, 5, 3, 10) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );


char* board537939232 = gamma_board(board);
assert( board537939232 != NULL );
assert( strcmp(board537939232, 
"3.215321521.5..343\n"
"1.1133433343124..4\n"
"2313531425421.1212\n"
"5121...252423....5\n"
"43233551334231.131\n"
"1.412243111451211.\n"
"551513.1.1.5..14.2\n"
"43.44.22.15231.134\n"
"3351..2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24515.5415.55\n") == 0);
free(board537939232);
board537939232 = NULL;
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 5, 5, 7) == 1 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 15, 0) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 1, 15) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 3, 17, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );


char* board587341866 = gamma_board(board);
assert( board587341866 != NULL );
assert( strcmp(board587341866, 
"3.215321521.5..343\n"
"1.1133433343124..4\n"
"2313531425421.1212\n"
"5121.5.252423....5\n"
"43233551334231.131\n"
"1.4122431114512113\n"
"551513.1.1.5..14.2\n"
"43.44.22.15231.134\n"
"3351..2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24515.5415455\n") == 0);
free(board587341866);
board587341866 = NULL;
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_golden_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_move(board, 5, 9, 16) == 0 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_move(board, 2, 9, 16) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_golden_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 5, 17, 0) == 0 );


char* board497174737 = gamma_board(board);
assert( board497174737 != NULL );
assert( strcmp(board497174737, 
"3.215321521.5..343\n"
"1.1133433343124..4\n"
"2313531425421.1212\n"
"512115.252423....5\n"
"43233551334231.131\n"
"1.4122431114512113\n"
"551513.1.1.5..14.2\n"
"43.44.22.15231.134\n"
"33511.2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24515.5415455\n") == 0);
free(board497174737);
board497174737 = NULL;
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 15, 9) == 1 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 5, 15, 8) == 0 );
assert( gamma_free_fields(board, 5) == 36 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_free_fields(board, 2) == 36 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 5, 1, 16) == 0 );
assert( gamma_move(board, 5, 7, 6) == 0 );
assert( gamma_golden_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_free_fields(board, 2) == 36 );


char* board678524101 = gamma_board(board);
assert( board678524101 != NULL );
assert( strcmp(board678524101, 
"3.215321521.5..343\n"
"1.11334333431241.4\n"
"2313531425421.1212\n"
"512115.252423....5\n"
"43233551334231.131\n"
"1.4122431114512113\n"
"551513.1.1.5..14.2\n"
"43.44.22.15231.134\n"
"33511.2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24515.5415455\n") == 0);
free(board678524101);
board678524101 = NULL;
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_free_fields(board, 4) == 36 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_free_fields(board, 1) == 36 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 46 );
assert( gamma_free_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 5, 17, 8) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_free_fields(board, 1) == 36 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_free_fields(board, 4) == 36 );
assert( gamma_move(board, 5, 10, 13) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_golden_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 5, 16, 4) == 1 );


char* board728891466 = gamma_board(board);
assert( board728891466 != NULL );
assert( strcmp(board728891466, 
"3.215321521.5..343\n"
"1.11334333431241.4\n"
"2313531425421.1212\n"
"512115.252423....5\n"
"43233551334231.131\n"
"1.4122431114512113\n"
"551513.1.1.5..1452\n"
"43.44.22.15231.134\n"
"33511.2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24515.5415455\n") == 0);
free(board728891466);
board728891466 = NULL;
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 2, 14, 10) == 1 );


char* board203860258 = gamma_board(board);
assert( board203860258 != NULL );
assert( strcmp(board203860258, 
"3.215321521.5.2343\n"
"1.11334333431241.4\n"
"2313531425421.1212\n"
"512115.252423....5\n"
"43233551334231.131\n"
"1.4122431114512113\n"
"551513.1.1.5..1452\n"
"43.44.22.15231.134\n"
"33511.2115.3.1.2.2\n"
".22..4241251322..1\n"
"5533.24515.5415455\n") == 0);
free(board203860258);
board203860258 = NULL;
assert( gamma_move(board, 3, 1, 16) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 5, 17, 3) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 16, 2) == 1 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_move(board, 3, 13, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 15, 10) == 0 );
assert( gamma_move(board, 5, 1, 16) == 0 );
assert( gamma_move(board, 5, 12, 9) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 3, 17, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board460749768 = gamma_board(board);
assert( board460749768 != NULL );
assert( strcmp(board460749768, 
"31215321521.5.2343\n"
"1.11334333431241.4\n"
"2313531425421.1212\n"
"512115.252423....5\n"
"43233551334231.131\n"
"1.4122431114512113\n"
"551513.1.1.5.31452\n"
"43.44.22.15231.134\n"
"33511.2115.3.1.222\n"
".22..4241251322..1\n"
"5533.24515.5415455\n") == 0);
free(board460749768);
board460749768 = NULL;
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 3) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 1, 14, 7) == 1 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 4, 14, 9) == 0 );


char* board937912152 = gamma_board(board);
assert( board937912152 != NULL );
assert( strcmp(board937912152, 
"31215321521.5.2343\n"
"1.11334333431241.4\n"
"2313531425421.1212\n"
"512115.252423.1..5\n"
"43233551334231.131\n"
"1.4122431114512113\n"
"551513.1.1.5.31452\n"
"43.44.22.152314134\n"
"33511.2115.3.1.222\n"
".22..4241251322..1\n"
"5533.24515.5415455\n") == 0);
free(board937912152);
board937912152 = NULL;
assert( gamma_move(board, 5, 5, 3) == 1 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_golden_move(board, 5, 1, 17) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_golden_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 7, 13) == 0 );
assert( gamma_free_fields(board, 5) == 28 );
assert( gamma_move(board, 1, 1, 0) == 0 );


gamma_delete(board);

    return 0;
}
