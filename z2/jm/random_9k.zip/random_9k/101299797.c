#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 101299797
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(13, 15, 8, 25);
assert( board != NULL );


assert( gamma_move(board, 1, 7, 1) == 1 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 2, 1, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 3, 10, 6) == 1 );


char* board808936828 = gamma_board(board);
assert( board808936828 != NULL );
assert( strcmp(board808936828, 
".............\n"
".............\n"
".2...........\n"
".............\n"
".............\n"
".............\n"
".............\n"
"........2....\n"
"..........3..\n"
".............\n"
".............\n"
".............\n"
".............\n"
".......1.....\n"
".............\n") == 0);
free(board808936828);
board808936828 = NULL;
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 5, 6, 12) == 1 );
assert( gamma_move(board, 6, 10, 4) == 1 );
assert( gamma_free_fields(board, 6) == 188 );
assert( gamma_move(board, 7, 11, 9) == 1 );
assert( gamma_move(board, 7, 8, 2) == 1 );
assert( gamma_move(board, 8, 6, 3) == 1 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_move(board, 4, 7, 14) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 5, 5) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 3, 9) == 1 );
assert( gamma_move(board, 8, 1, 12) == 0 );
assert( gamma_move(board, 8, 5, 14) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 2, 11, 7) == 1 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 3, 10, 11) == 1 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 4, 3, 1) == 1 );


char* board583310261 = gamma_board(board);
assert( board583310261 != NULL );
assert( strcmp(board583310261, 
".....8.4.....\n"
".............\n"
".2....5......\n"
".........33..\n"
".............\n"
"...7..4....7.\n"
"........4....\n"
".....3..2..2.\n"
"..2.......3..\n"
".....6.....4.\n"
"..........6..\n"
"......8......\n"
"........7....\n"
"...4...1.....\n"
"...........1.\n") == 0);
free(board583310261);
board583310261 = NULL;
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_move(board, 6, 2, 0) == 1 );
assert( gamma_move(board, 6, 12, 10) == 1 );
assert( gamma_busy_fields(board, 6) == 4 );
assert( gamma_move(board, 7, 1, 12) == 0 );
assert( gamma_move(board, 8, 0, 12) == 1 );


char* board962413661 = gamma_board(board);
assert( board962413661 != NULL );
assert( strcmp(board962413661, 
".....8.4.....\n"
".............\n"
"82....5......\n"
".........33..\n"
"............6\n"
"...7..4....7.\n"
".5......4....\n"
".....3..2..2.\n"
"..2.......3..\n"
".....6.....4.\n"
"..........6..\n"
"......8......\n"
"........7....\n"
"...4...1.....\n"
"..6..5.....1.\n") == 0);
free(board962413661);
board962413661 = NULL;
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 5, 1, 12) == 0 );
assert( gamma_move(board, 6, 2, 4) == 1 );
assert( gamma_move(board, 7, 7, 10) == 1 );
assert( gamma_move(board, 1, 3, 8) == 1 );
assert( gamma_free_fields(board, 1) == 161 );


char* board973775422 = gamma_board(board);
assert( board973775422 != NULL );
assert( strcmp(board973775422, 
".....8.4.....\n"
".............\n"
"82....5......\n"
".........33..\n"
".......7....6\n"
"...7..4....7.\n"
"25.1....4....\n"
".....3..2..2.\n"
"..2.......3..\n"
".....6.....4.\n"
"..6.......6..\n"
"......8......\n"
"........7.2..\n"
"...4...1...1.\n"
"..6..5.....1.\n") == 0);
free(board973775422);
board973775422 = NULL;
assert( gamma_move(board, 2, 9, 7) == 1 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 4, 5, 4) == 1 );
assert( gamma_move(board, 6, 2, 8) == 1 );
assert( gamma_move(board, 7, 9, 9) == 1 );
assert( gamma_golden_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 8, 14, 8) == 0 );
assert( gamma_move(board, 8, 12, 11) == 1 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_move(board, 2, 9, 14) == 1 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 5, 4, 9) == 1 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 5 );
assert( gamma_move(board, 8, 8, 3) == 1 );
assert( gamma_move(board, 8, 1, 11) == 1 );
assert( gamma_free_fields(board, 8) == 147 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_move(board, 4, 3, 10) == 1 );


char* board678330813 = gamma_board(board);
assert( board678330813 != NULL );
assert( strcmp(board678330813, 
".....8.4.2...\n"
".............\n"
"82....5......\n"
".8.......33.8\n"
".4.4...72...6\n"
"...75.4..7.7.\n"
"2561....4..1.\n"
".....3..22.2.\n"
"..2.....4.3..\n"
".....6..3..4.\n"
"..6..4....6..\n"
"..1..18.8....\n"
"........7.2..\n"
"...4...1...1.\n"
"..6..5.3...1.\n") == 0);
free(board678330813);
board678330813 = NULL;
assert( gamma_move(board, 5, 14, 12) == 0 );


char* board158883918 = gamma_board(board);
assert( board158883918 != NULL );
assert( strcmp(board158883918, 
".....8.4.2...\n"
".............\n"
"82....5......\n"
".8.......33.8\n"
".4.4...72...6\n"
"...75.4..7.7.\n"
"2561....4..1.\n"
".....3..22.2.\n"
"..2.....4.3..\n"
".....6..3..4.\n"
"..6..4....6..\n"
"..1..18.8....\n"
"........7.2..\n"
"...4...1...1.\n"
"..6..5.3...1.\n") == 0);
free(board158883918);
board158883918 = NULL;
assert( gamma_move(board, 6, 6, 4) == 1 );
assert( gamma_free_fields(board, 6) == 142 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 7, 4, 7) == 1 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_move(board, 8, 10, 8) == 1 );
assert( gamma_move(board, 8, 0, 7) == 1 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 3, 5) == 1 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 6, 4, 9) == 0 );
assert( gamma_move(board, 6, 9, 12) == 1 );
assert( gamma_move(board, 7, 3, 11) == 1 );
assert( gamma_free_fields(board, 7) == 136 );
assert( gamma_move(board, 8, 0, 8) == 0 );
assert( gamma_move(board, 8, 4, 2) == 1 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 0) == 0 );


char* board631854466 = gamma_board(board);
assert( board631854466 != NULL );
assert( strcmp(board631854466, 
".....8.4.2...\n"
".............\n"
"82....5..6...\n"
".8.7.....33.8\n"
".4.4...72...6\n"
"...75.4..7.7.\n"
"2561....4.81.\n"
"8...73..22.2.\n"
"..2.....4.3..\n"
"...4.6..3..4.\n"
"..6..46...6..\n"
"..11.18.8....\n"
"....8...7.2..\n"
"...4...1...1.\n"
"..6..5.3...1.\n") == 0);
free(board631854466);
board631854466 = NULL;
assert( gamma_move(board, 4, 0, 6) == 1 );


char* board426703626 = gamma_board(board);
assert( board426703626 != NULL );
assert( strcmp(board426703626, 
".....8.4.2...\n"
".............\n"
"82....5..6...\n"
".8.7.....33.8\n"
".4.4...72...6\n"
"...75.4..7.7.\n"
"2561....4.81.\n"
"8...73..22.2.\n"
"4.2.....4.3..\n"
"...4.6..3..4.\n"
"..6..46...6..\n"
"..11.18.8....\n"
"....8...7.2..\n"
"...4...1...1.\n"
"..6..5.3...1.\n") == 0);
free(board426703626);
board426703626 = NULL;
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_move(board, 6, 13, 8) == 0 );
assert( gamma_free_fields(board, 6) == 133 );
assert( gamma_move(board, 7, 6, 7) == 1 );
assert( gamma_free_fields(board, 7) == 132 );
assert( gamma_move(board, 8, 14, 11) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_free_fields(board, 2) == 131 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_move(board, 4, 3, 12) == 1 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_free_fields(board, 4) == 129 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 5, 4, 1) == 1 );
assert( gamma_free_fields(board, 5) == 128 );
assert( gamma_move(board, 6, 12, 3) == 1 );
assert( gamma_move(board, 7, 10, 10) == 1 );
assert( gamma_move(board, 8, 11, 6) == 1 );
assert( gamma_move(board, 8, 1, 4) == 1 );
assert( gamma_busy_fields(board, 8) == 11 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 4, 5, 6) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 5, 11, 2) == 1 );
assert( gamma_move(board, 5, 8, 0) == 1 );
assert( gamma_golden_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 6, 14, 6) == 0 );
assert( gamma_move(board, 6, 10, 14) == 1 );
assert( gamma_move(board, 7, 9, 8) == 1 );
assert( gamma_move(board, 8, 4, 8) == 1 );
assert( gamma_golden_move(board, 8, 7, 9) == 0 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_free_fields(board, 2) == 114 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_free_fields(board, 4) == 111 );
assert( gamma_move(board, 5, 1, 10) == 0 );
assert( gamma_move(board, 6, 9, 2) == 1 );
assert( gamma_move(board, 7, 9, 8) == 0 );
assert( gamma_move(board, 8, 11, 11) == 1 );
assert( gamma_move(board, 8, 6, 12) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 4, 10, 10) == 0 );
assert( gamma_move(board, 5, 4, 11) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 12) == 1 );
assert( gamma_move(board, 7, 3, 13) == 1 );
assert( gamma_move(board, 8, 8, 12) == 0 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_free_fields(board, 3) == 103 );


char* board151111733 = gamma_board(board);
assert( board151111733 != NULL );
assert( strcmp(board151111733, 
".....8.4.26..\n"
"..27......3..\n"
"82.4..5.66...\n"
".8.75....3388\n"
".4.4...72.7.6\n"
"...75.4..7.7.\n"
"25618...4781.\n"
"8...737.22.2.\n"
"4.2..4..4.38.\n"
"...4.6..3.14.\n"
".863446...6..\n"
"..11.18.8...6\n"
".13.8...7625.\n"
"...453.1.3.1.\n"
"..6..5235221.\n") == 0);
free(board151111733);
board151111733 = NULL;
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 4, 6, 13) == 1 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 6, 13, 12) == 0 );
assert( gamma_move(board, 7, 12, 7) == 1 );
assert( gamma_move(board, 7, 6, 0) == 0 );
assert( gamma_move(board, 8, 1, 2) == 0 );
assert( gamma_move(board, 8, 0, 4) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_golden_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 6, 10, 3) == 1 );
assert( gamma_move(board, 7, 3, 9) == 0 );
assert( gamma_move(board, 8, 5, 12) == 1 );
assert( gamma_move(board, 8, 11, 11) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 9, 5) == 1 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 2, 12, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_move(board, 4, 7, 6) == 1 );
assert( gamma_move(board, 4, 8, 9) == 1 );
assert( gamma_golden_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 5, 10, 9) == 1 );
assert( gamma_move(board, 5, 8, 10) == 0 );
assert( gamma_move(board, 6, 3, 7) == 1 );
assert( gamma_move(board, 7, 12, 11) == 0 );
assert( gamma_move(board, 7, 0, 11) == 1 );
assert( gamma_move(board, 8, 10, 11) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 16 );
assert( gamma_free_fields(board, 2) == 84 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 6, 2, 5) == 1 );
assert( gamma_move(board, 7, 1, 5) == 1 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_move(board, 8, 2, 0) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 4, 2, 12) == 1 );
assert( gamma_move(board, 5, 12, 7) == 0 );
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 7, 13, 4) == 0 );
assert( gamma_move(board, 8, 2, 7) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 7, 12, 10) == 0 );
assert( gamma_move(board, 7, 3, 2) == 1 );
assert( gamma_move(board, 8, 6, 4) == 0 );
assert( gamma_busy_fields(board, 8) == 16 );


char* board616622183 = gamma_board(board);
assert( board616622183 != NULL );
assert( strcmp(board616622183, 
".....8.4.26..\n"
"..27..4...3.2\n"
"8244.85.66...\n"
"78375....3388\n"
".414..172.7.6\n"
"...75.4.4757.\n"
"25618...4781.\n"
"8.86737322.27\n"
"4.22.4.44.383\n"
"3764.6..3114.\n"
"8863446..16..\n"
"..11.18.8.6.6\n"
".1378...7625.\n"
"3..45321.3.1.\n"
"..64.5235221.\n") == 0);
free(board616622183);
board616622183 = NULL;
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_free_fields(board, 1) == 75 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 5, 0, 10) == 1 );


char* board884407126 = gamma_board(board);
assert( board884407126 != NULL );
assert( strcmp(board884407126, 
".2...8.4.26..\n"
"..27..4...3.2\n"
"8244.85.66...\n"
"78375....3388\n"
"5414..172.7.6\n"
"...75.4.4757.\n"
"25618.2.4781.\n"
"8.86737322.27\n"
"4.22.4.44.383\n"
"3764.6..3114.\n"
"8863446..16..\n"
"..11.18.8.6.6\n"
".1378...7625.\n"
"3..45321.341.\n"
"..64.5235221.\n") == 0);
free(board884407126);
board884407126 = NULL;
assert( gamma_move(board, 7, 11, 7) == 0 );
assert( gamma_move(board, 7, 10, 6) == 0 );
assert( gamma_move(board, 8, 8, 5) == 0 );
assert( gamma_move(board, 8, 9, 12) == 0 );
assert( gamma_busy_fields(board, 8) == 16 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_move(board, 4, 12, 12) == 1 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 7, 1, 1) == 1 );
assert( gamma_move(board, 7, 12, 1) == 1 );
assert( gamma_golden_move(board, 7, 9, 4) == 1 );
assert( gamma_move(board, 8, 3, 1) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 6, 1) == 0 );
assert( gamma_free_fields(board, 8) == 67 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 12, 10) == 0 );
assert( gamma_move(board, 5, 11, 3) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 7, 12, 4) == 1 );
assert( gamma_move(board, 8, 3, 0) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 6, 1, 0) == 1 );
assert( gamma_free_fields(board, 6) == 63 );
assert( gamma_move(board, 7, 7, 6) == 0 );
assert( gamma_move(board, 8, 9, 7) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 12, 2) == 1 );
assert( gamma_move(board, 6, 4, 5) == 1 );
assert( gamma_move(board, 7, 12, 0) == 1 );


char* board401194445 = gamma_board(board);
assert( board401194445 != NULL );
assert( strcmp(board401194445, 
".2...8.4.26..\n"
"..27..43..3.2\n"
"8244.85.66..4\n"
"78375....3388\n"
"5414..172.7.6\n"
"...75.4.4757.\n"
"25618.2.4781.\n"
"8.86737322.27\n"
"4.22.4.44.383\n"
"376466..3114.\n"
"8863446..76.7\n"
"..11.18.8.656\n"
".1378...76255\n"
"37.45321.3417\n"
"4664.52352217\n") == 0);
free(board401194445);
board401194445 = NULL;
assert( gamma_move(board, 8, 3, 0) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 11, 13) == 1 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_free_fields(board, 5) == 58 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_move(board, 6, 2, 9) == 1 );
assert( gamma_move(board, 7, 3, 4) == 0 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_move(board, 8, 2, 6) == 0 );
assert( gamma_move(board, 8, 5, 1) == 0 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 6, 9, 10) == 1 );
assert( gamma_move(board, 7, 10, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 20 );
assert( gamma_move(board, 8, 5, 4) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_move(board, 6, 12, 1) == 0 );
assert( gamma_move(board, 7, 7, 4) == 1 );
assert( gamma_move(board, 8, 2, 5) == 0 );
assert( gamma_move(board, 1, 12, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_golden_move(board, 5, 14, 9) == 0 );
assert( gamma_move(board, 6, 12, 7) == 0 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_move(board, 8, 10, 11) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );


char* board892879467 = gamma_board(board);
assert( board892879467 != NULL );
assert( strcmp(board892879467, 
".2...8.4.26..\n"
"..27..43..312\n"
"8244.85.66..4\n"
"78375....3388\n"
"5414..17267.6\n"
"3.67534.4757.\n"
"25618.2.47811\n"
"8.86737322.27\n"
"4.22.4.44.383\n"
"376466..3114.\n"
"88634467.76.7\n"
"..11.18.8.656\n"
".1378...76255\n"
"37.45321.3417\n"
"4664.52352217\n") == 0);
free(board892879467);
board892879467 = NULL;
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 6, 0, 3) == 1 );
assert( gamma_move(board, 7, 12, 3) == 0 );
assert( gamma_move(board, 8, 3, 8) == 0 );
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_golden_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_free_fields(board, 4) == 51 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_move(board, 6, 12, 7) == 0 );
assert( gamma_move(board, 6, 8, 13) == 1 );
assert( gamma_move(board, 8, 11, 7) == 0 );
assert( gamma_move(board, 8, 5, 1) == 0 );
assert( gamma_free_fields(board, 8) == 50 );
assert( gamma_move(board, 1, 11, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_golden_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 5, 11, 6) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 6, 13, 5) == 0 );
assert( gamma_move(board, 6, 3, 8) == 0 );
assert( gamma_move(board, 7, 2, 6) == 0 );
assert( gamma_move(board, 7, 7, 6) == 0 );
assert( gamma_busy_fields(board, 7) == 21 );
assert( gamma_move(board, 8, 2, 5) == 0 );
assert( gamma_move(board, 8, 0, 3) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_move(board, 7, 12, 7) == 0 );
assert( gamma_move(board, 7, 12, 12) == 0 );
assert( gamma_move(board, 8, 2, 10) == 0 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 7, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 5, 3, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 3, 11) == 0 );
assert( gamma_move(board, 6, 5, 11) == 1 );
assert( gamma_move(board, 7, 12, 10) == 0 );
assert( gamma_move(board, 8, 3, 9) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_free_fields(board, 6) == 47 );
assert( gamma_move(board, 7, 12, 11) == 0 );
assert( gamma_move(board, 7, 9, 5) == 0 );
assert( gamma_move(board, 8, 0, 4) == 0 );
assert( gamma_move(board, 8, 2, 1) == 1 );
assert( gamma_busy_fields(board, 8) == 17 );
assert( gamma_free_fields(board, 8) == 46 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_move(board, 3, 0, 13) == 1 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 5, 14, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_move(board, 6, 12, 5) == 1 );
assert( gamma_move(board, 7, 12, 11) == 0 );
assert( gamma_move(board, 7, 12, 10) == 0 );
assert( gamma_move(board, 8, 13, 9) == 0 );
assert( gamma_move(board, 8, 3, 14) == 0 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 1, 8, 11) == 1 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 5, 11, 7) == 0 );
assert( gamma_move(board, 5, 5, 11) == 0 );
assert( gamma_move(board, 6, 1, 8) == 0 );
assert( gamma_move(board, 7, 12, 4) == 0 );
assert( gamma_move(board, 8, 2, 7) == 0 );
assert( gamma_move(board, 8, 12, 14) == 1 );
assert( gamma_move(board, 1, 11, 12) == 1 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_golden_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_golden_move(board, 4, 12, 1) == 1 );
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_move(board, 5, 11, 6) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 7, 14, 0) == 0 );
assert( gamma_move(board, 8, 7, 10) == 0 );
assert( gamma_move(board, 8, 2, 6) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_free_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 6, 13, 9) == 0 );
assert( gamma_move(board, 6, 5, 11) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 14) == 0 );
assert( gamma_move(board, 7, 10, 10) == 0 );
assert( gamma_busy_fields(board, 7) == 20 );
assert( gamma_golden_move(board, 7, 11, 12) == 0 );
assert( gamma_move(board, 8, 7, 10) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_golden_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_golden_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 5, 8, 8) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 7, 8, 2) == 0 );
assert( gamma_move(board, 7, 3, 11) == 0 );
assert( gamma_busy_fields(board, 7) == 20 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 1, 4) == 0 );
assert( gamma_busy_fields(board, 8) == 18 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 8, 8, 1) == 1 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_free_fields(board, 2) == 38 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 5, 11, 7) == 0 );
assert( gamma_free_fields(board, 5) == 38 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 9, 7) == 0 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 8, 3, 1) == 0 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_golden_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_free_fields(board, 4) == 37 );
assert( gamma_move(board, 6, 9, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 7, 10, 7) == 1 );
assert( gamma_move(board, 7, 7, 9) == 0 );
assert( gamma_move(board, 8, 13, 9) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 1, 7) == 1 );


char* board462132259 = gamma_board(board);
assert( board462132259 != NULL );
assert( strcmp(board462132259, 
".2.3.8.4.26.8\n"
"3.27..436.312\n"
"8244.85.66.14\n"
"783756..13388\n"
"5414..17267.6\n"
"346753424757.\n"
"25618.2.47811\n"
"8486737322727\n"
"4.22.4144.383\n"
"376466..31146\n"
"88634467.7617\n"
"6.11.18.8.656\n"
".13784..76255\n"
"3784522183414\n"
"4664.52352217\n") == 0);
free(board462132259);
board462132259 = NULL;
assert( gamma_move(board, 5, 6, 2) == 1 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 6, 3, 7) == 0 );
assert( gamma_move(board, 6, 10, 9) == 0 );
assert( gamma_move(board, 7, 12, 10) == 0 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_free_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_free_fields(board, 4) == 34 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 7, 10, 4) == 0 );
assert( gamma_move(board, 8, 12, 10) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 9, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 10, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_move(board, 6, 9, 12) == 0 );
assert( gamma_move(board, 6, 11, 7) == 0 );
assert( gamma_free_fields(board, 6) == 32 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 21 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_golden_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_free_fields(board, 4) == 32 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_golden_move(board, 5, 6, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 7, 13, 1) == 0 );
assert( gamma_move(board, 7, 9, 10) == 0 );
assert( gamma_move(board, 8, 5, 6) == 0 );
assert( gamma_move(board, 8, 0, 3) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 6, 12, 14) == 0 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 7, 11, 7) == 0 );
assert( gamma_move(board, 7, 4, 9) == 0 );
assert( gamma_move(board, 8, 0, 13) == 0 );
assert( gamma_busy_fields(board, 8) == 18 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_free_fields(board, 3) == 31 );
assert( gamma_move(board, 4, 14, 4) == 0 );


gamma_delete(board);

    return 0;
}
