#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 106584520
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 8, 8, 17);
assert( board != NULL );


assert( gamma_move(board, 1, 16, 1) == 1 );
assert( gamma_move(board, 2, 13, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board656383761 = gamma_board(board);
assert( board656383761 != NULL );
assert( strcmp(board656383761, 
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"................1.\n"
".............2....\n") == 0);
free(board656383761);
board656383761 = NULL;
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 5, 7, 7) == 1 );
assert( gamma_move(board, 6, 10, 2) == 1 );
assert( gamma_move(board, 6, 12, 4) == 1 );
assert( gamma_free_fields(board, 6) == 138 );
assert( gamma_move(board, 7, 4, 2) == 1 );
assert( gamma_move(board, 7, 16, 0) == 1 );
assert( gamma_move(board, 8, 9, 2) == 1 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_free_fields(board, 3) == 132 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 0) == 1 );
assert( gamma_free_fields(board, 4) == 131 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_busy_fields(board, 5) == 1 );
assert( gamma_move(board, 6, 16, 4) == 1 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_move(board, 7, 13, 4) == 1 );
assert( gamma_move(board, 8, 2, 0) == 1 );
assert( gamma_move(board, 8, 2, 0) == 0 );
assert( gamma_busy_fields(board, 8) == 2 );
assert( gamma_golden_move(board, 8, 0, 14) == 0 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_move(board, 1, 9, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 4 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 6, 14, 6) == 1 );
assert( gamma_move(board, 7, 9, 0) == 1 );
assert( gamma_move(board, 8, 6, 13) == 0 );
assert( gamma_busy_fields(board, 8) == 2 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_free_fields(board, 2) == 119 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 3, 15, 1) == 1 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_golden_move(board, 4, 7, 7) == 1 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_move(board, 6, 0, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 5 );
assert( gamma_move(board, 7, 5, 1) == 1 );
assert( gamma_move(board, 7, 14, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 5 );
assert( gamma_move(board, 8, 5, 3) == 1 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_free_fields(board, 3) == 112 );
assert( gamma_move(board, 5, 0, 7) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 6, 0, 5) == 1 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_move(board, 7, 5, 4) == 1 );
assert( gamma_move(board, 8, 1, 5) == 1 );
assert( gamma_move(board, 8, 15, 7) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 4, 14, 3) == 1 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 6, 7, 3) == 1 );
assert( gamma_move(board, 6, 11, 4) == 0 );
assert( gamma_move(board, 7, 0, 11) == 0 );
assert( gamma_move(board, 8, 1, 3) == 1 );
assert( gamma_move(board, 8, 9, 6) == 1 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 2, 16, 5) == 1 );
assert( gamma_move(board, 2, 4, 7) == 1 );


char* board475787533 = gamma_board(board);
assert( board475787533 != NULL );
assert( strcmp(board475787533, 
"51.12..4.......8..\n"
".........8.1..6...\n"
"68...2.1........2.\n"
".....7.2...267..6.\n"
"684.18.6......4...\n"
".4..7.2..86.......\n"
".2...73..1.....31.\n"
"258......7...24.7.\n") == 0);
free(board475787533);
board475787533 = NULL;
assert( gamma_busy_fields(board, 3) == 2 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 6, 3, 17) == 0 );
assert( gamma_move(board, 7, 7, 1) == 1 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 8, 5, 9) == 0 );
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 3, 13, 1) == 1 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 4, 11, 3) == 1 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 5, 7, 7) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 5, 15) == 0 );
assert( gamma_move(board, 7, 11, 6) == 0 );
assert( gamma_move(board, 7, 10, 1) == 1 );
assert( gamma_move(board, 8, 11, 0) == 1 );
assert( gamma_move(board, 8, 14, 2) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 13, 2) == 1 );
assert( gamma_free_fields(board, 1) == 90 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 2, 1, 6) == 1 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_golden_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 5, 2, 12) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 6, 3, 1) == 1 );
assert( gamma_move(board, 7, 6, 7) == 1 );
assert( gamma_move(board, 8, 6, 6) == 1 );


char* board991006064 = gamma_board(board);
assert( board991006064 != NULL );
assert( strcmp(board991006064, 
"51412.74.......8..\n"
".2....8..8.1..6...\n"
"68...2213.......2.\n"
"....37.2...267..6.\n"
"684.18.6...4..4...\n"
".4..7.2..86..18...\n"
".2.6.737.17..3.31.\n"
"258......7.8.24.7.\n") == 0);
free(board991006064);
board991006064 = NULL;
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_free_fields(board, 3) == 83 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 5, 15, 7) == 0 );
assert( gamma_move(board, 6, 4, 17) == 0 );
assert( gamma_move(board, 6, 17, 2) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_move(board, 7, 9, 4) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 0, 6) == 1 );
assert( gamma_move(board, 8, 5, 5) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 2, 17, 3) == 1 );
assert( gamma_move(board, 3, 6, 17) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 5, 6, 10) == 0 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 6, 17) == 0 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_move(board, 8, 3, 2) == 1 );
assert( gamma_move(board, 1, 4, 17) == 0 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_free_fields(board, 3) == 78 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 4, 1) == 1 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 9 );


char* board947628576 = gamma_board(board);
assert( board947628576 != NULL );
assert( strcmp(board947628576, 
"51412.74.......8..\n"
"82....8..8.1..6...\n"
"68..32213.......2.\n"
"....37.2.7.267..6.\n"
"684.18.6...4..4..2\n"
".4.87.2..86..18..6\n"
".2.65737.17..3.31.\n"
"258......7.8.24.7.\n") == 0);
free(board947628576);
board947628576 = NULL;
assert( gamma_move(board, 7, 5, 2) == 1 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 2, 16, 3) == 1 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 4, 12, 0) == 1 );
assert( gamma_move(board, 4, 10, 3) == 1 );
assert( gamma_move(board, 5, 3, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_move(board, 6, 12, 2) == 1 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_move(board, 7, 6, 1) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 7, 17) == 0 );
assert( gamma_move(board, 3, 3, 9) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 17, 1) == 1 );
assert( gamma_move(board, 6, 7, 6) == 1 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 8, 0, 8) == 0 );
assert( gamma_move(board, 8, 5, 6) == 1 );
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 2, 11, 7) == 1 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 5, 10, 6) == 1 );
assert( gamma_move(board, 5, 2, 1) == 1 );
assert( gamma_move(board, 6, 5, 11) == 0 );
assert( gamma_move(board, 6, 8, 6) == 1 );
assert( gamma_move(board, 7, 5, 15) == 0 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 4, 8) == 0 );
assert( gamma_move(board, 8, 5, 0) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 4, 17) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 7 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 5, 0, 1) == 1 );
assert( gamma_move(board, 6, 14, 1) == 1 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 7, 3, 3) == 1 );
assert( gamma_move(board, 7, 0, 1) == 0 );
assert( gamma_move(board, 8, 7, 9) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_free_fields(board, 2) == 58 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 6, 3, 6) == 1 );
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_move(board, 8, 5, 12) == 0 );
assert( gamma_move(board, 8, 17, 6) == 1 );
assert( gamma_busy_fields(board, 8) == 15 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_free_fields(board, 1) == 55 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 1, 12) == 0 );
assert( gamma_move(board, 5, 17, 6) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_move(board, 6, 0, 4) == 1 );
assert( gamma_free_fields(board, 6) == 53 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 10) == 0 );
assert( gamma_move(board, 8, 5, 5) == 0 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 3) == 0 );


char* board955135360 = gamma_board(board);
assert( board955135360 != NULL );
assert( strcmp(board955135360, 
"51412.74...2...8..\n"
"82.6.8866851..6..8\n"
"68..32213.......2.\n"
"6..537.2.7.267..6.\n"
"684718.6..44..4.22\n"
".4187724.863618..6\n"
"52565737.17..36315\n"
"258..8.3.7.8424.7.\n") == 0);
free(board955135360);
board955135360 = NULL;
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_free_fields(board, 5) == 52 );
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_move(board, 7, 3, 0) == 1 );
assert( gamma_move(board, 8, 2, 16) == 0 );
assert( gamma_move(board, 8, 14, 2) == 0 );
assert( gamma_busy_fields(board, 8) == 15 );


char* board172580171 = gamma_board(board);
assert( board172580171 != NULL );
assert( strcmp(board172580171, 
"51412.74...2...8..\n"
"82.6.8866851..6..8\n"
"68..32213.......2.\n"
"6..537.2.7.267..6.\n"
"684718.6..44..4.22\n"
"54187724.863618..6\n"
"52565737.17..36315\n"
"2587.8.3.7.8424.7.\n") == 0);
free(board172580171);
board172580171 = NULL;
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 15, 5) == 1 );
assert( gamma_move(board, 6, 4, 17) == 0 );


char* board540139860 = gamma_board(board);
assert( board540139860 != NULL );
assert( strcmp(board540139860, 
"51412.74...2...8..\n"
"82.6.8866851..6..8\n"
"68..32213......52.\n"
"6..537.2.7.267..6.\n"
"684718.6..44..4.22\n"
"54187724.863618..6\n"
"52565737.17..36315\n"
"2587.8.3.7.8424.7.\n") == 0);
free(board540139860);
board540139860 = NULL;
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 7, 13, 5) == 1 );
assert( gamma_move(board, 8, 1, 6) == 0 );
assert( gamma_free_fields(board, 8) == 49 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 16, 6) == 1 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 12, 1) == 1 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 6, 16, 3) == 0 );
assert( gamma_move(board, 7, 11, 3) == 0 );


char* board927939911 = gamma_board(board);
assert( board927939911 != NULL );
assert( strcmp(board927939911, 
"51412.74...2...8..\n"
"82.6.88668513.6.18\n"
"68..32213....7.52.\n"
"6..537.2.7.267..6.\n"
"684718.6..44..4.22\n"
"54187724.863618..6\n"
"52565737.17.436315\n"
"2587.8.3.7.8424.7.\n") == 0);
free(board927939911);
board927939911 = NULL;
assert( gamma_move(board, 8, 0, 15) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_golden_move(board, 1, 6, 1) == 1 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_free_fields(board, 4) == 46 );
assert( gamma_move(board, 5, 9, 7) == 1 );
assert( gamma_move(board, 5, 9, 5) == 1 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 6, 15, 5) == 0 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_move(board, 7, 1, 7) == 0 );
assert( gamma_move(board, 8, 5, 14) == 0 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_golden_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_free_fields(board, 3) == 43 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 8, 7) == 1 );
assert( gamma_free_fields(board, 5) == 42 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_free_fields(board, 6) == 42 );
assert( gamma_move(board, 7, 13, 7) == 1 );
assert( gamma_golden_move(board, 7, 6, 15) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_move(board, 8, 5, 5) == 0 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_free_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 0, 4) == 0 );


char* board193075864 = gamma_board(board);
assert( board193075864 != NULL );
assert( strcmp(board193075864, 
"51412.7455.2.7.8..\n"
"82.6.88668513.6.18\n"
"68..322135...7.52.\n"
"6..537.2.7.267..6.\n"
"684718.6.244..4.22\n"
"54187724.863618..6\n"
"52565717.17.436315\n"
"2587.8.3.7.8424.7.\n") == 0);
free(board193075864);
board193075864 = NULL;
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 7, 14) == 0 );
assert( gamma_move(board, 5, 14, 2) == 0 );
assert( gamma_move(board, 6, 4, 6) == 1 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_move(board, 7, 8, 2) == 1 );
assert( gamma_free_fields(board, 7) == 38 );
assert( gamma_move(board, 8, 1, 11) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_free_fields(board, 2) == 38 );


char* board108161459 = gamma_board(board);
assert( board108161459 != NULL );
assert( strcmp(board108161459, 
"51412.7455.2.7.8..\n"
"82.6688668513.6.18\n"
"684.322135...7.52.\n"
"6..537.2.7.267..6.\n"
"684718.6.244..4.22\n"
"541877247863618..6\n"
"52565717.17.436315\n"
"2587.8.3.7.8424.7.\n") == 0);
free(board108161459);
board108161459 = NULL;
assert( gamma_move(board, 3, 7, 17) == 0 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 6, 10, 6) == 0 );
assert( gamma_move(board, 7, 10, 4) == 1 );
assert( gamma_move(board, 7, 11, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 17 );
assert( gamma_free_fields(board, 7) == 36 );
assert( gamma_move(board, 8, 8, 4) == 1 );
assert( gamma_free_fields(board, 8) == 35 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 3, 17, 5) == 1 );
assert( gamma_free_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_golden_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 5, 6, 13) == 0 );
assert( gamma_move(board, 5, 15, 6) == 1 );
assert( gamma_move(board, 6, 4, 6) == 0 );
assert( gamma_move(board, 6, 17, 4) == 1 );
assert( gamma_free_fields(board, 6) == 32 );
assert( gamma_move(board, 7, 11, 4) == 0 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 11, 0) == 0 );
assert( gamma_move(board, 8, 1, 4) == 1 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 7, 17) == 0 );
assert( gamma_move(board, 4, 16, 1) == 0 );
assert( gamma_move(board, 4, 17, 7) == 1 );
assert( gamma_move(board, 5, 7, 16) == 0 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_move(board, 6, 11, 5) == 1 );
assert( gamma_move(board, 7, 2, 16) == 0 );
assert( gamma_move(board, 8, 2, 16) == 0 );
assert( gamma_free_fields(board, 8) == 29 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_free_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 6, 7, 6) == 0 );
assert( gamma_move(board, 7, 6, 3) == 1 );
assert( gamma_busy_fields(board, 7) == 18 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 3, 12) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_free_fields(board, 2) == 28 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_free_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_free_fields(board, 5) == 28 );


char* board327868348 = gamma_board(board);
assert( board327868348 != NULL );
assert( strcmp(board327868348, 
"51412.745542.7.8.4\n"
"82.6688668513.6518\n"
"684.322135.6.7.523\n"
"68.537.2877267..66\n"
"68471876.244..4.22\n"
"541877247863618..6\n"
"52565717.17.436315\n"
"2587.8.3.7.8424.7.\n") == 0);
free(board327868348);
board327868348 = NULL;
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 6, 12, 3) == 1 );
assert( gamma_move(board, 7, 5, 2) == 0 );
assert( gamma_move(board, 7, 4, 0) == 1 );
assert( gamma_move(board, 8, 0, 17) == 0 );
assert( gamma_move(board, 8, 5, 7) == 1 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 2, 15, 3) == 1 );


char* board622427090 = gamma_board(board);
assert( board622427090 != NULL );
assert( strcmp(board622427090, 
"514128745542.7.8.4\n"
"82.6688668513.6518\n"
"684.322135.6.7.523\n"
"68.537.2877267..66\n"
"68471876.2446.4222\n"
"541877247863618..6\n"
"52565717.17.436315\n"
"258778.3.7.8424.7.\n") == 0);
free(board622427090);
board622427090 = NULL;
assert( gamma_move(board, 3, 6, 0) == 1 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 5, 15, 2) == 1 );
assert( gamma_move(board, 6, 13, 3) == 1 );
assert( gamma_free_fields(board, 6) == 21 );
assert( gamma_move(board, 7, 11, 7) == 0 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 8, 16, 5) == 0 );
assert( gamma_busy_fields(board, 8) == 18 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 5, 2, 16) == 0 );
assert( gamma_move(board, 6, 5, 10) == 0 );
assert( gamma_golden_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_move(board, 7, 14, 7) == 1 );
assert( gamma_move(board, 8, 5, 10) == 0 );
assert( gamma_move(board, 8, 6, 1) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_free_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_move(board, 5, 16, 0) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_move(board, 8, 16, 0) == 0 );
assert( gamma_move(board, 8, 2, 2) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 16, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_free_fields(board, 7) == 18 );
assert( gamma_move(board, 8, 3, 0) == 0 );
assert( gamma_move(board, 8, 17, 4) == 0 );
assert( gamma_free_fields(board, 8) == 18 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_golden_move(board, 4, 6, 10) == 0 );
assert( gamma_move(board, 5, 6, 4) == 1 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_move(board, 8, 10, 5) == 0 );


char* board129408382 = gamma_board(board);
assert( board129408382 != NULL );
assert( strcmp(board129408382, 
"514128745542.778.4\n"
"82.6688668513.6518\n"
"684.32213516.7.523\n"
"68.53752877267..66\n"
"68471876.244664222\n"
"541877247863618546\n"
"52565717.17.436315\n"
"25877833.7.8424.7.\n") == 0);
free(board129408382);
board129408382 = NULL;
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_golden_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 5, 13, 6) == 1 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_golden_move(board, 6, 5, 15) == 0 );
assert( gamma_move(board, 7, 17, 3) == 0 );
assert( gamma_move(board, 7, 10, 1) == 0 );
assert( gamma_move(board, 8, 0, 17) == 0 );
assert( gamma_move(board, 8, 11, 7) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_move(board, 6, 9, 7) == 0 );
assert( gamma_move(board, 6, 16, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 3, 8) == 0 );


gamma_delete(board);

    return 0;
}
