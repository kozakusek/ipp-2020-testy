#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 106672135
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(13, 15, 5, 31);
assert( board != NULL );


assert( gamma_move(board, 1, 5, 14) == 1 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 0 );


char* board244505091 = gamma_board(board);
assert( board244505091 != NULL );
assert( strcmp(board244505091, 
".....1.......\n"
".............\n"
"..2..........\n"
".............\n"
".............\n"
"............2\n"
".............\n"
".............\n"
".............\n"
".............\n"
".3...........\n"
".............\n"
".............\n"
".............\n"
".............\n") == 0);
free(board244505091);
board244505091 = NULL;
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 11) == 1 );
assert( gamma_move(board, 4, 0, 1) == 1 );
assert( gamma_move(board, 4, 3, 9) == 1 );
assert( gamma_move(board, 5, 10, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 1, 8, 7) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 4, 6, 7) == 1 );
assert( gamma_move(board, 5, 7, 12) == 1 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_free_fields(board, 5) == 179 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 4 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 5, 6, 9) == 1 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 1, 13, 12) == 0 );
assert( gamma_move(board, 1, 8, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 5 );


char* board102533711 = gamma_board(board);
assert( board102533711 != NULL );
assert( strcmp(board102533711, 
".....1.......\n"
".............\n"
"..2....5.....\n"
"....3...1....\n"
".............\n"
"...4..5.....2\n"
"......2...5..\n"
"......4.1....\n"
".5...........\n"
"......1...3..\n"
".35.3........\n"
".............\n"
".............\n"
"41...........\n"
"..3.......2..\n") == 0);
free(board102533711);
board102533711 = NULL;
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_golden_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 5, 3, 8) == 1 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 7, 10) == 1 );
assert( gamma_move(board, 5, 4, 5) == 1 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 2, 11, 3) == 1 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_golden_move(board, 4, 7, 8) == 0 );


char* board164783058 = gamma_board(board);
assert( board164783058 != NULL );
assert( strcmp(board164783058, 
".....1.......\n"
".............\n"
"..2....5.....\n"
"....3...1....\n"
".......4.....\n"
"...4..5.....2\n"
"...5..2...5..\n"
"......4.1....\n"
".5...........\n"
"2...5.1...3..\n"
".35.3....1...\n"
"...........2.\n"
".............\n"
"41........3..\n"
"..3.......2..\n") == 0);
free(board164783058);
board164783058 = NULL;
assert( gamma_move(board, 5, 3, 11) == 1 );
assert( gamma_move(board, 5, 9, 8) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 2, 4, 10) == 1 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 11, 7) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 5, 7, 3) == 1 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );


char* board898047376 = gamma_board(board);
assert( board898047376 != NULL );
assert( strcmp(board898047376, 
".....1.......\n"
".............\n"
"..2....5....1\n"
"...53...1....\n"
"....2..4.....\n"
"3..4..5.....2\n"
"...5..2.355..\n"
"......4.1..5.\n"
".5...........\n"
"2...5.1.1.3..\n"
".35.3....1...\n"
".2..2..5...2.\n"
".............\n"
"41........31.\n"
"..3.......2..\n") == 0);
free(board898047376);
board898047376 = NULL;
assert( gamma_move(board, 5, 6, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 3, 14, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 9) == 1 );
assert( gamma_move(board, 1, 12, 12) == 0 );


char* board747450271 = gamma_board(board);
assert( board747450271 != NULL );
assert( strcmp(board747450271, 
".....1.......\n"
".............\n"
"..2....5....1\n"
"...53...1....\n"
"....2..4.....\n"
"3..4..5..5..2\n"
"...5..2.355..\n"
"......4.1..5.\n"
".5...........\n"
"2...5.1.1.32.\n"
".3523....1...\n"
".2..2..5...2.\n"
".............\n"
"41........31.\n"
"..3...5...2..\n") == 0);
free(board747450271);
board747450271 = NULL;
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_free_fields(board, 3) == 149 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 5, 11, 7) == 0 );
assert( gamma_move(board, 5, 4, 0) == 1 );
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 5, 13, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 14 );


char* board280653211 = gamma_board(board);
assert( board280653211 != NULL );
assert( strcmp(board280653211, 
".....1.......\n"
".............\n"
"..2....5....1\n"
"...53...1....\n"
"....2..4.....\n"
"3.44..5..5..2\n"
"...5..2.355..\n"
"....4.4.1..5.\n"
".5...........\n"
"2...5.1.1332.\n"
".3523....1...\n"
".2..2..5...2.\n"
"..1..........\n"
"41........31.\n"
"..3.5.5...2..\n") == 0);
free(board280653211);
board280653211 = NULL;
assert( gamma_move(board, 1, 9, 6) == 1 );
assert( gamma_move(board, 2, 12, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 4, 6, 6) == 1 );
assert( gamma_move(board, 4, 6, 13) == 1 );
assert( gamma_move(board, 5, 13, 10) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 3, 10, 12) == 1 );
assert( gamma_free_fields(board, 3) == 138 );
assert( gamma_move(board, 4, 9, 7) == 1 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_free_fields(board, 4) == 137 );
assert( gamma_move(board, 5, 12, 11) == 1 );
assert( gamma_move(board, 1, 12, 7) == 1 );
assert( gamma_move(board, 2, 11, 12) == 1 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 4, 12, 14) == 1 );
assert( gamma_move(board, 5, 6, 4) == 1 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 11, 10) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 5, 6, 14) == 1 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_golden_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_free_fields(board, 4) == 122 );
assert( gamma_move(board, 5, 0, 3) == 1 );
assert( gamma_move(board, 5, 11, 4) == 1 );
assert( gamma_free_fields(board, 5) == 120 );
assert( gamma_golden_move(board, 5, 4, 4) == 1 );


char* board331739897 = gamma_board(board);
assert( board331739897 != NULL );
assert( strcmp(board331739897, 
".....15.....4\n"
"......4...3..\n"
".32....5..321\n"
"..453...1...5\n"
"...32..4...5.\n"
"3.44..5..5..2\n"
"3.35..2.355..\n"
"....4.4.14.51\n"
".5....4..1...\n"
"2.425.1.13322\n"
".3525.5..1.5.\n"
"52..2..5...2.\n"
"..1...2......\n"
"41........31.\n"
"2.3.5.5...2..\n") == 0);
free(board331739897);
board331739897 = NULL;
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 4, 10, 14) == 1 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 9, 13) == 1 );
assert( gamma_move(board, 3, 9, 11) == 1 );


char* board695736749 = gamma_board(board);
assert( board695736749 != NULL );
assert( strcmp(board695736749, 
".....15...4.4\n"
"......4..23..\n"
".32....5..321\n"
"..453...13..5\n"
"...32..4...5.\n"
"3.44..5..5..2\n"
"3.35..2.355..\n"
"....4.4.14.51\n"
".5....4.11...\n"
"2.42511.13322\n"
".3525.5..1.5.\n"
"52..2..5...2.\n"
"..1...2......\n"
"41........31.\n"
"2.3.5.5...2..\n") == 0);
free(board695736749);
board695736749 = NULL;
assert( gamma_move(board, 4, 1, 8) == 1 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 11, 11) == 1 );
assert( gamma_move(board, 5, 14, 7) == 0 );
assert( gamma_move(board, 1, 12, 8) == 1 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_golden_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_free_fields(board, 4) == 107 );


char* board779998950 = gamma_board(board);
assert( board779998950 != NULL );
assert( strcmp(board779998950, 
".....15...4.4\n"
"......4..23..\n"
".32....5..321\n"
".4453...13.35\n"
"...32..4...5.\n"
"3.44..5..5..2\n"
"3435..2.355.1\n"
"....4.4.14.51\n"
".5....4.11...\n"
"2.42511.13322\n"
".3525.5..125.\n"
"52.42..5...2.\n"
"..1...22.....\n"
"41.......331.\n"
"2.3.5.5...2..\n") == 0);
free(board779998950);
board779998950 = NULL;
assert( gamma_move(board, 5, 13, 8) == 0 );
assert( gamma_golden_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 7, 7) == 1 );


char* board704668165 = gamma_board(board);
assert( board704668165 != NULL );
assert( strcmp(board704668165, 
".....15...4.4\n"
"......4..23..\n"
".32....5..321\n"
".4453...13.35\n"
"...32..4...5.\n"
"3.44..5..5..2\n"
"3435..2.355.1\n"
"....4.4514.51\n"
".5....4.11...\n"
"2.42511.13322\n"
".3525.5..125.\n"
"52.42..5...2.\n"
"..1...22.....\n"
"41.......331.\n"
"2.3.5.5...2..\n") == 0);
free(board704668165);
board704668165 = NULL;
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_golden_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_free_fields(board, 3) == 100 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_move(board, 5, 2, 13) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 2, 12, 4) == 1 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_free_fields(board, 3) == 98 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 8) == 0 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 2, 12, 0) == 1 );


char* board443587554 = gamma_board(board);
assert( board443587554 != NULL );
assert( strcmp(board443587554, 
".....15...4.4\n"
"..5...4..23..\n"
".32....5..321\n"
".4453...13.35\n"
".4332..4...5.\n"
"3.44.15..5..2\n"
"3435..2.355.1\n"
"....4.4514.51\n"
"15....4.11.2.\n"
"2.42511.13322\n"
".3525.5..1252\n"
"52442..5...2.\n"
"..1...22.....\n"
"41.......331.\n"
"2.3.5.5...212\n") == 0);
free(board443587554);
board443587554 = NULL;
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_free_fields(board, 5) == 96 );
assert( gamma_move(board, 1, 7, 1) == 1 );
assert( gamma_move(board, 1, 11, 13) == 1 );
assert( gamma_move(board, 2, 2, 14) == 1 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 5, 1, 7) == 1 );
assert( gamma_free_fields(board, 5) == 91 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 7, 5) == 1 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 5, 13, 3) == 0 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_golden_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_free_fields(board, 2) == 87 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 5, 5, 7) == 1 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_golden_move(board, 1, 10, 1) == 1 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 12, 10) == 1 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_move(board, 5, 7, 9) == 1 );
assert( gamma_free_fields(board, 5) == 80 );
assert( gamma_golden_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_free_fields(board, 1) == 80 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 5, 10, 9) == 1 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_golden_move(board, 4, 6, 9) == 1 );


char* board210993049 = gamma_board(board);
assert( board210993049 != NULL );
assert( strcmp(board210993049, 
"..2.215...4.4\n"
"..5...4..231.\n"
".32...35..321\n"
"14453...13.35\n"
".4332.14...54\n"
"3.44.145.55.2\n"
"3435..2.35521\n"
".5.3454514.51\n"
"15....4.11.2.\n"
"2542511513322\n"
".3525.5..1252\n"
"52442..5...2.\n"
"..1...223..3.\n"
"41.....1.311.\n"
"2.315.51..212\n") == 0);
free(board210993049);
board210993049 = NULL;
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_free_fields(board, 1) == 74 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 4, 7, 4) == 1 );
assert( gamma_move(board, 5, 8, 13) == 1 );
assert( gamma_move(board, 5, 5, 2) == 1 );
assert( gamma_move(board, 1, 10, 10) == 1 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 5, 2, 12) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 5, 9, 0) == 1 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 7, 13) == 1 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 1, 8, 4) == 1 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 9, 11) == 0 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_free_fields(board, 2) == 62 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );


char* board896066988 = gamma_board(board);
assert( board896066988 != NULL );
assert( strcmp(board896066988, 
"..2.215...4.4\n"
"..5...445231.\n"
".32...35..321\n"
"14453...13.35\n"
".4332.14..154\n"
"3.44.145255.2\n"
"3435.32.35521\n"
".5.3454514451\n"
"15.3..4.11.2.\n"
"2542511513322\n"
".3525.5411252\n"
"52442..5...2.\n"
"..1315223..3.\n"
"41....21.311.\n"
"2.315.51.5212\n") == 0);
free(board896066988);
board896066988 = NULL;
assert( gamma_move(board, 5, 4, 9) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 5, 3, 1) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_free_fields(board, 1) == 60 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_free_fields(board, 3) == 60 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );


char* board294195326 = gamma_board(board);
assert( board294195326 != NULL );
assert( strcmp(board294195326, 
"..2.215...4.4\n"
"..5...445231.\n"
".32...35..321\n"
"14453...13.35\n"
".4332.14..154\n"
"3.445145255.2\n"
"3435.32.35521\n"
".5.3454514451\n"
"15.3..4.11.2.\n"
"2542511513322\n"
".3525.5411252\n"
"52442..5...2.\n"
"..1315223..3.\n"
"41.5..21.311.\n"
"2.315.51.5212\n") == 0);
free(board294195326);
board294195326 = NULL;
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 28 );
assert( gamma_golden_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 5, 3) == 1 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 5, 8, 2) == 0 );
assert( gamma_move(board, 5, 6, 10) == 0 );
assert( gamma_free_fields(board, 5) == 59 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_free_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 5, 4, 11) == 0 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_golden_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_free_fields(board, 5) == 58 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 0, 7) == 1 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 10, 3) == 1 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 5, 12, 11) == 0 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 6, 4) == 0 );
assert( gamma_move(board, 5, 7, 6) == 1 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_free_fields(board, 5) == 52 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 3, 1, 14) == 1 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 5, 6, 13) == 0 );
assert( gamma_free_fields(board, 5) == 51 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );


char* board633488977 = gamma_board(board);
assert( board633488977 != NULL );
assert( strcmp(board633488977, 
".32.215...4.4\n"
"..5...445231.\n"
".32...35..321\n"
"14453...13.35\n"
".4332.1423154\n"
"3.445145255.2\n"
"3435.32.35521\n"
"25.3454514451\n"
"15.3.54511.2.\n"
"2542511513322\n"
".3525.5411252\n"
"524422.53.42.\n"
".21315223..3.\n"
"41.5..21.311.\n"
"2.315.51.5212\n") == 0);
free(board633488977);
board633488977 = NULL;
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 5, 1, 12) == 0 );
assert( gamma_move(board, 5, 8, 14) == 1 );
assert( gamma_free_fields(board, 5) == 49 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_free_fields(board, 2) == 49 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_free_fields(board, 4) == 47 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 5, 11, 6) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 3, 0, 12) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_free_fields(board, 5) == 46 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 11) == 1 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_golden_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 5, 6, 4) == 0 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 5, 13, 1) == 0 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 9, 3) == 1 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 5, 12, 12) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 5, 3, 11) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_free_fields(board, 4) == 41 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_golden_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 2, 0, 13) == 1 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 5, 5, 1) == 1 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_move(board, 3, 11, 10) == 0 );


char* board620061369 = gamma_board(board);
assert( board620061369 != NULL );
assert( strcmp(board620061369, 
"432.215.5.4.4\n"
"2.5...445231.\n"
"332..235..321\n"
"14453.3.13.35\n"
".4332.1423154\n"
"3.445145255.2\n"
"3435.32.35521\n"
"25.3454514451\n"
"15.3.54511.2.\n"
"2542511513322\n"
"43525.5411252\n"
"524422.534423\n"
".21315223..3.\n"
"41.5.521.311.\n"
"2.315.5115212\n") == 0);
free(board620061369);
board620061369 = NULL;
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_free_fields(board, 1) == 38 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 6, 2) == 0 );


char* board441836060 = gamma_board(board);
assert( board441836060 != NULL );
assert( strcmp(board441836060, 
"432.215.5.4.4\n"
"2.5...445231.\n"
"332..235..321\n"
"14453.3.13.35\n"
".4332.1423154\n"
"3.445145255.2\n"
"3435.32.35521\n"
"25.3454514451\n"
"15.3.54511.2.\n"
"2542511513322\n"
"43525.5411252\n"
"524422.534423\n"
".21315223..3.\n"
"41.54521.311.\n"
"2.315.5115212\n") == 0);
free(board441836060);
board441836060 = NULL;
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 5, 2, 7) == 1 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 5, 2, 12) == 0 );
assert( gamma_busy_fields(board, 5) == 38 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 4, 9, 14) == 1 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 11, 7) == 0 );
assert( gamma_move(board, 1, 12, 13) == 1 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_free_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_golden_move(board, 3, 5, 6) == 1 );


char* board701242554 = gamma_board(board);
assert( board701242554 != NULL );
assert( strcmp(board701242554, 
"432.215.544.4\n"
"2.5...4452311\n"
"332..2352.321\n"
"14453.3.13.35\n"
".4332.1423154\n"
"3.445145255.2\n"
"3435.32.35521\n"
"2553454514451\n"
"15.3.34511.2.\n"
"2542511513322\n"
"43525.5411252\n"
"524422.534423\n"
".21315223.43.\n"
"41254521.311.\n"
"2.315.5115212\n") == 0);
free(board701242554);
board701242554 = NULL;
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );


char* board253220814 = gamma_board(board);
assert( board253220814 != NULL );
assert( strcmp(board253220814, 
"432.215.544.4\n"
"2.5...4452311\n"
"332..2352.321\n"
"14453.3.13.35\n"
".4332.1423154\n"
"3.445145255.2\n"
"3435432.35521\n"
"2553454514451\n"
"15.3.34511.2.\n"
"2542511513322\n"
"43525.5411252\n"
"524422.534423\n"
".21315223.43.\n"
"41254521.311.\n"
"2.315.5115212\n") == 0);
free(board253220814);
board253220814 = NULL;
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 5, 12, 6) == 1 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );


gamma_delete(board);

    return 0;
}
