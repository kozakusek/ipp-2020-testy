#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 134271818
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(15, 18, 7, 34);
assert( board != NULL );


assert( gamma_move(board, 1, 9, 14) == 1 );
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 4, 15, 12) == 0 );
assert( gamma_move(board, 5, 10, 13) == 1 );
assert( gamma_move(board, 5, 10, 4) == 1 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 7, 12, 13) == 1 );
assert( gamma_move(board, 7, 0, 5) == 1 );


char* board202225919 = gamma_board(board);
assert( board202225919 != NULL );
assert( strcmp(board202225919, 
"...............\n"
"...............\n"
"...............\n"
".........1.....\n"
"..........5.7..\n"
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"7..............\n"
"........3.5....\n"
"........2......\n"
"...............\n"
"............2..\n"
"...............\n") == 0);
free(board202225919);
board202225919 = NULL;
assert( gamma_move(board, 1, 14, 17) == 1 );
assert( gamma_move(board, 2, 10, 9) == 1 );
assert( gamma_move(board, 2, 4, 10) == 1 );
assert( gamma_free_fields(board, 2) == 259 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 4, 13, 2) == 1 );
assert( gamma_move(board, 4, 1, 13) == 1 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_move(board, 6, 10, 10) == 1 );
assert( gamma_move(board, 7, 16, 0) == 0 );
assert( gamma_move(board, 7, 8, 5) == 1 );
assert( gamma_move(board, 1, 14, 13) == 1 );
assert( gamma_move(board, 1, 12, 17) == 1 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_move(board, 2, 11, 17) == 1 );


char* board433090235 = gamma_board(board);
assert( board433090235 != NULL );
assert( strcmp(board433090235, 
"...........21.1\n"
"...............\n"
"...............\n"
".........1.....\n"
".4........5.7.1\n"
"...............\n"
"...............\n"
"....2.....6....\n"
"..........2....\n"
"...............\n"
"...............\n"
"..3............\n"
"7.......7......\n"
"..5.....3.5....\n"
"........2......\n"
".............4.\n"
".........3..2..\n"
"...............\n") == 0);
free(board433090235);
board433090235 = NULL;
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 5, 1, 10) == 1 );
assert( gamma_move(board, 5, 13, 1) == 1 );
assert( gamma_move(board, 6, 0, 2) == 1 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_move(board, 7, 9, 3) == 1 );
assert( gamma_move(board, 7, 2, 10) == 1 );
assert( gamma_busy_fields(board, 7) == 5 );
assert( gamma_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_move(board, 4, 9, 13) == 1 );
assert( gamma_busy_fields(board, 4) == 4 );
assert( gamma_free_fields(board, 4) == 237 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 8) == 1 );
assert( gamma_move(board, 6, 10, 17) == 1 );
assert( gamma_move(board, 7, 0, 6) == 1 );
assert( gamma_move(board, 7, 7, 14) == 1 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_free_fields(board, 2) == 233 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 12, 12) == 1 );
assert( gamma_move(board, 4, 8, 1) == 1 );
assert( gamma_move(board, 5, 16, 7) == 0 );
assert( gamma_move(board, 5, 6, 10) == 1 );
assert( gamma_free_fields(board, 5) == 230 );
assert( gamma_move(board, 6, 9, 0) == 1 );
assert( gamma_golden_move(board, 6, 12, 12) == 1 );
assert( gamma_move(board, 7, 14, 9) == 1 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 9, 5) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 2, 7, 10) == 1 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 3, 6, 2) == 1 );
assert( gamma_move(board, 4, 5, 14) == 1 );
assert( gamma_move(board, 5, 14, 13) == 0 );
assert( gamma_golden_move(board, 5, 13, 1) == 0 );
assert( gamma_move(board, 7, 10, 11) == 1 );
assert( gamma_move(board, 7, 4, 3) == 1 );
assert( gamma_move(board, 1, 12, 10) == 1 );
assert( gamma_move(board, 1, 12, 7) == 1 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_free_fields(board, 5) == 215 );
assert( gamma_move(board, 6, 14, 2) == 1 );
assert( gamma_move(board, 6, 4, 15) == 1 );


char* board984408349 = gamma_board(board);
assert( board984408349 != NULL );
assert( strcmp(board984408349, 
"..........621.1\n"
"...............\n"
"....6..........\n"
".2...4.7.1.....\n"
".4.......45.711\n"
"............6..\n"
"..........7....\n"
".57.2.52..6.1..\n"
".........423..7\n"
"..6...2..3.....\n"
"............1..\n"
"7.3............\n"
"7.4.....71.....\n"
"..5..2..3.52...\n"
"....7...27..3..\n"
"6.....3......46\n"
".....2..43..25.\n"
".........6.....\n") == 0);
free(board984408349);
board984408349 = NULL;
assert( gamma_move(board, 7, 14, 0) == 1 );
assert( gamma_move(board, 7, 8, 11) == 1 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_free_fields(board, 2) == 208 );
assert( gamma_move(board, 3, 3, 11) == 1 );
assert( gamma_move(board, 4, 8, 10) == 1 );
assert( gamma_move(board, 5, 11, 3) == 1 );
assert( gamma_move(board, 6, 9, 4) == 1 );
assert( gamma_move(board, 7, 5, 8) == 1 );
assert( gamma_free_fields(board, 7) == 203 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_free_fields(board, 1) == 202 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_golden_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 4, 6, 7) == 1 );
assert( gamma_move(board, 5, 10, 13) == 0 );
assert( gamma_move(board, 5, 14, 17) == 0 );
assert( gamma_move(board, 6, 2, 10) == 0 );
assert( gamma_move(board, 7, 5, 5) == 1 );
assert( gamma_move(board, 7, 12, 8) == 1 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_move(board, 2, 10, 7) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 1, 7) == 1 );
assert( gamma_move(board, 5, 0, 2) == 0 );


char* board634122202 = gamma_board(board);
assert( board634122202 != NULL );
assert( strcmp(board634122202, 
"..........621.1\n"
"...............\n"
"....6..........\n"
".2...4.7.1.....\n"
".4.......45.711\n"
".1...2......6..\n"
"...3....7.7....\n"
".57.2.524.6.1..\n"
"...1.....423..7\n"
"..6..32..3..7..\n"
".5....4...2.1..\n"
"7.3.....4......\n"
"7.4..7..71.....\n"
"..5..2..3652...\n"
"1...7...27253..\n"
"6.....3......46\n"
"...1.23.43..25.\n"
".........6....7\n") == 0);
free(board634122202);
board634122202 = NULL;
assert( gamma_move(board, 6, 4, 17) == 1 );


char* board969825517 = gamma_board(board);
assert( board969825517 != NULL );
assert( strcmp(board969825517, 
"....6.....621.1\n"
"...............\n"
"....6..........\n"
".2...4.7.1.....\n"
".4.......45.711\n"
".1...2......6..\n"
"...3....7.7....\n"
".57.2.524.6.1..\n"
"...1.....423..7\n"
"..6..32..3..7..\n"
".5....4...2.1..\n"
"7.3.....4......\n"
"7.4..7..71.....\n"
"..5..2..3652...\n"
"1...7...27253..\n"
"6.....3......46\n"
"...1.23.43..25.\n"
".........6....7\n") == 0);
free(board969825517);
board969825517 = NULL;
assert( gamma_move(board, 7, 13, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_free_fields(board, 7) == 192 );
assert( gamma_move(board, 1, 13, 3) == 1 );
assert( gamma_move(board, 1, 5, 17) == 1 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 5, 4, 12) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 7, 10, 5) == 1 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 4, 0, 13) == 1 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 5, 4, 11) == 1 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_move(board, 6, 7, 6) == 1 );
assert( gamma_move(board, 7, 13, 4) == 1 );
assert( gamma_free_fields(board, 7) == 182 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_move(board, 5, 4, 1) == 1 );
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_move(board, 7, 8, 11) == 0 );
assert( gamma_move(board, 1, 13, 16) == 1 );
assert( gamma_move(board, 1, 11, 11) == 1 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_free_fields(board, 2) == 176 );
assert( gamma_move(board, 4, 4, 14) == 1 );
assert( gamma_golden_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 6, 0, 1) == 1 );
assert( gamma_free_fields(board, 6) == 174 );
assert( gamma_move(board, 7, 2, 1) == 1 );
assert( gamma_move(board, 7, 14, 2) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );


char* board423158538 = gamma_board(board);
assert( board423158538 != NULL );
assert( strcmp(board423158538, 
"....61....621.1\n"
".............1.\n"
"....6..........\n"
".2..44.7.1.....\n"
"44....1..45.711\n"
".1..52......6..\n"
"...35...7.71...\n"
".57.2.524.6.1..\n"
"...1.....423..7\n"
"..6..32..3..7..\n"
".5....4...2.1..\n"
"7.3....64......\n"
"7.4..7..717....\n"
".25..2..3652.7.\n"
"1...74.2272531.\n"
"6.....3......46\n"
"6.71523.43.225.\n"
".........6....7\n") == 0);
free(board423158538);
board423158538 = NULL;
assert( gamma_move(board, 2, 11, 10) == 1 );


char* board884257603 = gamma_board(board);
assert( board884257603 != NULL );
assert( strcmp(board884257603, 
"....61....621.1\n"
".............1.\n"
"....6..........\n"
".2..44.7.1.....\n"
"44....1..45.711\n"
".1..52......6..\n"
"...35...7.71...\n"
".57.2.524.621..\n"
"...1.....423..7\n"
"..6..32..3..7..\n"
".5....4...2.1..\n"
"7.3....64......\n"
"7.4..7..717....\n"
".25..2..3652.7.\n"
"1...74.2272531.\n"
"6.....3......46\n"
"6.71523.43.225.\n"
".........6....7\n") == 0);
free(board884257603);
board884257603 = NULL;
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 16) == 1 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_move(board, 6, 16, 0) == 0 );
assert( gamma_move(board, 6, 10, 6) == 1 );
assert( gamma_move(board, 7, 11, 9) == 0 );
assert( gamma_move(board, 7, 12, 5) == 1 );
assert( gamma_golden_move(board, 7, 3, 7) == 0 );
assert( gamma_move(board, 1, 17, 3) == 0 );
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 2, 13, 6) == 1 );
assert( gamma_move(board, 3, 13, 8) == 1 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 8, 0) == 1 );
assert( gamma_move(board, 5, 5, 13) == 1 );
assert( gamma_move(board, 6, 15, 10) == 0 );
assert( gamma_move(board, 6, 0, 14) == 1 );
assert( gamma_free_fields(board, 7) == 162 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 7, 8) == 1 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 4, 11, 14) == 1 );
assert( gamma_move(board, 5, 16, 0) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 1, 14, 6) == 1 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 2, 14, 8) == 1 );
assert( gamma_golden_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_golden_move(board, 3, 17, 11) == 0 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 5, 5, 13) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 6, 7, 17) == 1 );
assert( gamma_move(board, 7, 3, 14) == 1 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_move(board, 1, 14, 3) == 1 );
assert( gamma_free_fields(board, 1) == 152 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_free_fields(board, 2) == 152 );


char* board962294426 = gamma_board(board);
assert( board962294426 != NULL );
assert( strcmp(board962294426, 
"....61.6..621.1\n"
".....4.......1.\n"
"....6..........\n"
"62.744.7.1.4...\n"
"44...51..45.711\n"
".1..52......6..\n"
"...35...7.71...\n"
".57.2.524.621..\n"
"...1...1.423..7\n"
"..6..322.3..732\n"
".5....4...2.1..\n"
"7.3....64.6..21\n"
"7.4..7..717.7..\n"
"425.12.23652.7.\n"
"1...74.22725311\n"
"6.3...3......46\n"
"6.71523.43.225.\n"
"........46....7\n") == 0);
free(board962294426);
board962294426 = NULL;
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_move(board, 7, 2, 14) == 1 );
assert( gamma_golden_move(board, 7, 10, 4) == 1 );
assert( gamma_move(board, 1, 7, 16) == 1 );
assert( gamma_move(board, 1, 11, 16) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 10, 17) == 0 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 11) == 1 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 5, 12, 11) == 1 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 6, 7, 12) == 1 );
assert( gamma_move(board, 7, 3, 3) == 1 );
assert( gamma_move(board, 1, 7, 17) == 0 );
assert( gamma_free_fields(board, 4) == 140 );
assert( gamma_move(board, 5, 16, 6) == 0 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 7, 11, 10) == 0 );


char* board617857077 = gamma_board(board);
assert( board617857077 != NULL );
assert( strcmp(board617857077, 
"....61.6..621.1\n"
".....4.1...1.1.\n"
"....6..........\n"
"627744.7.1.4...\n"
"44...51..45.711\n"
".1..52.6....6..\n"
"4..352..7.715..\n"
".57.2.524.621..\n"
"...1...1.423..7\n"
"..6..322.3..732\n"
".54...4...2.1..\n"
"7.33...64.6..21\n"
"7.43.7..717.7..\n"
"425.12.23672.7.\n"
"1..774.22725311\n"
"6.3...3......46\n"
"6.71523343.225.\n"
"........46....7\n") == 0);
free(board617857077);
board617857077 = NULL;
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_free_fields(board, 2) == 140 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 3, 11, 17) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_free_fields(board, 4) == 140 );
assert( gamma_move(board, 5, 11, 12) == 1 );
assert( gamma_move(board, 5, 0, 11) == 0 );
assert( gamma_move(board, 6, 2, 16) == 1 );
assert( gamma_move(board, 6, 7, 16) == 0 );
assert( gamma_move(board, 7, 6, 5) == 1 );
assert( gamma_free_fields(board, 7) == 137 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_free_fields(board, 1) == 137 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_free_fields(board, 2) == 136 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 4, 15, 14) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 5, 9, 15) == 1 );
assert( gamma_move(board, 5, 13, 7) == 1 );
assert( gamma_move(board, 6, 0, 13) == 0 );
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_move(board, 7, 8, 4) == 0 );
assert( gamma_free_fields(board, 7) == 134 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_golden_move(board, 1, 11, 4) == 1 );
assert( gamma_free_fields(board, 2) == 134 );
assert( gamma_move(board, 3, 12, 14) == 1 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 7, 2, 10) == 0 );
assert( gamma_move(board, 1, 0, 17) == 1 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 3, 13, 16) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 12, 2) == 1 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 6, 11, 6) == 1 );
assert( gamma_move(board, 7, 7, 4) == 0 );
assert( gamma_move(board, 7, 13, 14) == 1 );
assert( gamma_free_fields(board, 7) == 126 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 2, 13, 11) == 1 );
assert( gamma_move(board, 2, 8, 15) == 1 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 12, 10) == 0 );
assert( gamma_move(board, 4, 6, 10) == 0 );
assert( gamma_move(board, 5, 2, 3) == 1 );
assert( gamma_free_fields(board, 5) == 122 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 10) == 1 );
assert( gamma_move(board, 6, 0, 9) == 1 );
assert( gamma_free_fields(board, 6) == 120 );
assert( gamma_move(board, 7, 8, 9) == 1 );
assert( gamma_move(board, 7, 10, 6) == 0 );


char* board381392308 = gamma_board(board);
assert( board381392308 != NULL );
assert( strcmp(board381392308, 
"1...61.6..621.1\n"
"..6..4.1...1.1.\n"
"....6...25.....\n"
"627744.7.1.437.\n"
"44...51..45.711\n"
".1..52.6...56..\n"
"4..352.37.7152.\n"
"65732.524.621..\n"
"6..1...17423..7\n"
"..6..322.3..732\n"
".54...4...2.15.\n"
"7.33...64266.21\n"
"7.43.77.717.7..\n"
"425212.23671.7.\n"
"1.5774.22725311\n"
"6.3...3....1446\n"
"6.71523343.225.\n"
"........46....7\n") == 0);
free(board381392308);
board381392308 = NULL;
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 17, 9) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 5, 14, 14) == 1 );
assert( gamma_move(board, 5, 0, 17) == 0 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_move(board, 5, 6, 5) == 0 );
assert( gamma_move(board, 7, 4, 14) == 0 );
assert( gamma_move(board, 7, 3, 16) == 1 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 1, 0, 17) == 0 );


char* board838068557 = gamma_board(board);
assert( board838068557 != NULL );
assert( strcmp(board838068557, 
"1...61.6..621.1\n"
"..67.4.1...1.1.\n"
"....6...25.....\n"
"627744.7.1.4375\n"
"44...51..45.711\n"
".1..52.6...56..\n"
"4..352.37.7152.\n"
"65732.524.621..\n"
"6..1...17423..7\n"
"..6..322.3..732\n"
".54...4...2.15.\n"
"7.333..64266.21\n"
"7.43.77.717.7..\n"
"425212.23671.7.\n"
"1.5774.22725311\n"
"6.3...3....1446\n"
"6.71523343.225.\n"
"........46....7\n") == 0);
free(board838068557);
board838068557 = NULL;
assert( gamma_move(board, 2, 12, 17) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 4, 17) == 0 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 15, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 7, 10, 13) == 0 );
assert( gamma_move(board, 7, 12, 16) == 1 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_free_fields(board, 2) == 113 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 5, 15, 0) == 0 );
assert( gamma_move(board, 6, 4, 6) == 0 );
assert( gamma_move(board, 7, 10, 11) == 0 );
assert( gamma_move(board, 7, 12, 5) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 1, 6, 14) == 1 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_move(board, 4, 15, 12) == 0 );
assert( gamma_move(board, 5, 14, 2) == 0 );
assert( gamma_move(board, 6, 11, 6) == 0 );
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_move(board, 7, 3, 15) == 1 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 12, 6) == 1 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 17, 9) == 0 );
assert( gamma_move(board, 4, 9, 12) == 1 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 5, 4, 16) == 1 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 6, 9, 9) == 0 );
assert( gamma_move(board, 6, 4, 17) == 0 );
assert( gamma_move(board, 7, 4, 14) == 0 );
assert( gamma_move(board, 7, 9, 10) == 1 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 4, 14, 1) == 1 );
assert( gamma_move(board, 4, 2, 15) == 1 );


char* board225938333 = gamma_board(board);
assert( board225938333 != NULL );
assert( strcmp(board225938333, 
"1...61.6..621.1\n"
"..6754.1...171.\n"
"..476...25.....\n"
"62774417.1.4375\n"
"44...51..45.711\n"
".1..52.6.4.56..\n"
"4..352.37.7152.\n"
"65732.5247621..\n"
"6..1...17423..7\n"
"..6..32223..732\n"
".54...4...2315.\n"
"7.333..64266221\n"
"7.43.77.717.7..\n"
"425212.23671.7.\n"
"1.5774.22725311\n"
"6.3...3....1446\n"
"6.71523343.2254\n"
"4.....2.46....7\n") == 0);
free(board225938333);
board225938333 = NULL;
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 7, 9, 7) == 1 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 1, 4, 9) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 14, 11) == 1 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 13, 16) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_free_fields(board, 4) == 100 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 17, 1) == 0 );
assert( gamma_move(board, 5, 5, 9) == 1 );
assert( gamma_move(board, 6, 11, 6) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 17, 13) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_golden_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 6, 5, 9) == 0 );


char* board363431073 = gamma_board(board);
assert( board363431073 != NULL );
assert( strcmp(board363431073, 
"1...61.6..621.1\n"
"..6754.1...171.\n"
"..476...25.....\n"
"62774417.1.4375\n"
"44...51..45.711\n"
".1..52.6.4.56..\n"
"4..352.37.71522\n"
"65732.5247621..\n"
"64.115.17423..7\n"
"..6..32223..732\n"
".54...4..72315.\n"
"7.333..64266221\n"
"7.43.77.717.7..\n"
"425212.23671.7.\n"
"1.5774.22725311\n"
"6.3...3....1446\n"
"6.71523343.2254\n"
"4.....2.46....7\n") == 0);
free(board363431073);
board363431073 = NULL;
assert( gamma_move(board, 7, 3, 16) == 0 );


char* board391851324 = gamma_board(board);
assert( board391851324 != NULL );
assert( strcmp(board391851324, 
"1...61.6..621.1\n"
"..6754.1...171.\n"
"..476...25.....\n"
"62774417.1.4375\n"
"44...51..45.711\n"
".1..52.6.4.56..\n"
"4..352.37.71522\n"
"65732.5247621..\n"
"64.115.17423..7\n"
"..6..32223..732\n"
".54...4..72315.\n"
"7.333..64266221\n"
"7.43.77.717.7..\n"
"425212.23671.7.\n"
"1.5774.22725311\n"
"6.3...3....1446\n"
"6.71523343.2254\n"
"4.....2.46....7\n") == 0);
free(board391851324);
board391851324 = NULL;
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 2, 3, 7) == 1 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 16, 8) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 5, 17, 8) == 0 );
assert( gamma_move(board, 6, 16, 0) == 0 );
assert( gamma_move(board, 6, 9, 17) == 1 );
assert( gamma_move(board, 7, 0, 16) == 1 );
assert( gamma_move(board, 1, 12, 14) == 0 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_free_fields(board, 3) == 94 );
assert( gamma_move(board, 4, 16, 9) == 0 );
assert( gamma_move(board, 4, 9, 12) == 0 );


char* board963034794 = gamma_board(board);
assert( board963034794 != NULL );
assert( strcmp(board963034794, 
"1...61.6.6621.1\n"
"7.6754.1...171.\n"
"..476...25.....\n"
"62774417.1.4375\n"
"44...51..45.711\n"
".1..52.6.4.56..\n"
"4..352.37.71522\n"
"65732.5247621..\n"
"642115.17423..7\n"
"..6..32223..732\n"
".542..4..72315.\n"
"7.333..64266221\n"
"7.43.77.717.7..\n"
"425212.23671.7.\n"
"1.5774.22725311\n"
"6.3...3....1446\n"
"6.71523343.2254\n"
"4.....2.46....7\n") == 0);
free(board963034794);
board963034794 = NULL;
assert( gamma_move(board, 5, 10, 14) == 1 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_golden_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 7, 8, 10) == 0 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 4, 16, 10) == 0 );
assert( gamma_move(board, 4, 8, 13) == 1 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 5, 12, 16) == 0 );
assert( gamma_move(board, 6, 14, 0) == 0 );
assert( gamma_move(board, 6, 10, 17) == 0 );
assert( gamma_move(board, 7, 10, 4) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 1, 13, 0) == 1 );
assert( gamma_free_fields(board, 1) == 89 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 3, 16, 8) == 0 );
assert( gamma_move(board, 3, 7, 8) == 0 );


char* board945277486 = gamma_board(board);
assert( board945277486 != NULL );
assert( strcmp(board945277486, 
"1...61.6.6621.1\n"
"7.6754.1...171.\n"
"..476...25.....\n"
"62774417.154375\n"
"44...51.445.711\n"
".1..52.6.4.56..\n"
"4..352.37.71522\n"
"65732.5247621..\n"
"642115.17423..7\n"
"..6..32223..732\n"
".542..41.72315.\n"
"7.333..64266221\n"
"7.43.77.717.7..\n"
"425212.23671.7.\n"
"115774.22725311\n"
"6.3...3....1446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board945277486);
board945277486 = NULL;
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 4, 5, 7) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 7, 7, 4) == 0 );
assert( gamma_move(board, 7, 3, 16) == 0 );
assert( gamma_move(board, 1, 17, 8) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 6, 12, 2) == 0 );
assert( gamma_move(board, 6, 6, 3) == 1 );
assert( gamma_move(board, 7, 13, 11) == 0 );
assert( gamma_move(board, 7, 4, 16) == 0 );
assert( gamma_move(board, 1, 12, 6) == 0 );
assert( gamma_move(board, 2, 13, 10) == 1 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 4, 17, 13) == 0 );
assert( gamma_free_fields(board, 4) == 85 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 7, 0, 10) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 12, 9) == 1 );


char* board568007809 = gamma_board(board);
assert( board568007809 != NULL );
assert( strcmp(board568007809, 
"1...61.6.6621.1\n"
"7.6754.1...171.\n"
"..476...25.....\n"
"62774417.154375\n"
"44...51.445.711\n"
"11..52.6.4.56..\n"
"4..352.37.71522\n"
"65732.52476212.\n"
"642115.174235.7\n"
"..6.332223..732\n"
".542.441.72315.\n"
"7.333..64266221\n"
"7543.77.717.7..\n"
"425212.23671.7.\n"
"115774622725311\n"
"6.3...3....1446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board568007809);
board568007809 = NULL;
assert( gamma_move(board, 6, 4, 14) == 0 );
assert( gamma_move(board, 7, 4, 11) == 0 );
assert( gamma_move(board, 7, 11, 11) == 0 );
assert( gamma_free_fields(board, 7) == 82 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_free_fields(board, 3) == 80 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 5, 0, 11) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 7, 9, 13) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 6, 13, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 22 );
assert( gamma_free_fields(board, 7) == 80 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_free_fields(board, 5) == 80 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_move(board, 7, 15, 1) == 0 );
assert( gamma_move(board, 7, 4, 2) == 1 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_golden_move(board, 1, 0, 6) == 0 );
assert( gamma_free_fields(board, 2) == 79 );


char* board989809633 = gamma_board(board);
assert( board989809633 != NULL );
assert( strcmp(board989809633, 
"1...61.6.6621.1\n"
"7.6754.1...171.\n"
"..476...25.....\n"
"62774417.154375\n"
"44...51.445.711\n"
"11..52.6.4.56..\n"
"4..352.37.71522\n"
"65732.52476212.\n"
"642115.174235.7\n"
"2.6.332223..732\n"
"1542.441.72315.\n"
"7.333..64266221\n"
"7543.77.717.7..\n"
"425212.23671.7.\n"
"115774622725311\n"
"6.3.7.3....1446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board989809633);
board989809633 = NULL;
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 6, 11, 2) == 0 );
assert( gamma_move(board, 6, 11, 4) == 0 );
assert( gamma_free_fields(board, 6) == 79 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 10, 14) == 0 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 2, 1, 15) == 1 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 5, 4, 17) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 6, 0, 13) == 0 );


char* board396966103 = gamma_board(board);
assert( board396966103 != NULL );
assert( strcmp(board396966103, 
"1...61.6.6621.1\n"
"7.6754.1...171.\n"
".2476...25.....\n"
"62774417.154375\n"
"44...51.445.711\n"
"11..52.6.4.56..\n"
"4..352.37371522\n"
"65732.52476212.\n"
"642115.174235.7\n"
"2.6.332223..732\n"
"1542.441.72315.\n"
"7.333..64266221\n"
"7543.77.717.7..\n"
"425212.23671.7.\n"
"115774622725311\n"
"6.3.7.3....1446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board396966103);
board396966103 = NULL;
assert( gamma_move(board, 7, 7, 8) == 0 );
assert( gamma_move(board, 7, 11, 14) == 0 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 1, 10, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 34 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 27 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 6, 15, 11) == 0 );
assert( gamma_move(board, 7, 6, 1) == 0 );
assert( gamma_move(board, 7, 12, 16) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );


char* board122089666 = gamma_board(board);
assert( board122089666 != NULL );
assert( strcmp(board122089666, 
"1...61.6.6621.1\n"
"7.6754.1...171.\n"
".2476...25.....\n"
"62774417.154375\n"
"44...51.445.711\n"
"11..52.6.4.56..\n"
"4..352.37371522\n"
"65732.52476212.\n"
"642115.174235.7\n"
"2.6.332223..732\n"
"1542.441.72315.\n"
"7.333..64266221\n"
"7543.77.717.7..\n"
"425212.23671.7.\n"
"115774622725311\n"
"6.3.7.3...11446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board122089666);
board122089666 = NULL;
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 12) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 13) == 0 );
assert( gamma_move(board, 5, 7, 15) == 1 );
assert( gamma_busy_fields(board, 6) == 22 );
assert( gamma_move(board, 7, 1, 11) == 1 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_free_fields(board, 2) == 73 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_move(board, 4, 15, 14) == 0 );
assert( gamma_free_fields(board, 4) == 73 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 6, 11) == 1 );
assert( gamma_golden_move(board, 5, 16, 11) == 0 );
assert( gamma_move(board, 7, 7, 4) == 0 );
assert( gamma_move(board, 7, 13, 13) == 0 );
assert( gamma_move(board, 1, 16, 9) == 0 );
assert( gamma_move(board, 1, 14, 14) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 3, 17) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_free_fields(board, 3) == 71 );


char* board618769931 = gamma_board(board);
assert( board618769931 != NULL );
assert( strcmp(board618769931, 
"1..261.6.6621.1\n"
"7.6754.1...171.\n"
".2476..525.....\n"
"62774417.154375\n"
"44...51.445.711\n"
"114.52.6.4.56..\n"
"47.352537371522\n"
"65732.52476212.\n"
"642115.174235.7\n"
"2.6.332223..732\n"
"1542.441.72315.\n"
"7.333..64266221\n"
"7543.77.717.7..\n"
"425212.23671.7.\n"
"115774622725311\n"
"6.3.7.3...11446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board618769931);
board618769931 = NULL;
assert( gamma_move(board, 4, 15, 13) == 0 );
assert( gamma_golden_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 5, 11, 11) == 0 );
assert( gamma_move(board, 5, 13, 4) == 0 );
assert( gamma_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 7, 15, 12) == 0 );
assert( gamma_move(board, 7, 4, 16) == 0 );
assert( gamma_free_fields(board, 7) == 71 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 34 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 15) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 4, 10, 17) == 0 );
assert( gamma_move(board, 5, 13, 15) == 1 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 6, 17, 1) == 0 );
assert( gamma_move(board, 7, 14, 8) == 0 );
assert( gamma_move(board, 7, 12, 11) == 0 );
assert( gamma_free_fields(board, 7) == 70 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_free_fields(board, 6) == 70 );
assert( gamma_move(board, 7, 0, 1) == 0 );
assert( gamma_move(board, 7, 10, 10) == 0 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_golden_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_free_fields(board, 5) == 69 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 7, 0, 6) == 0 );
assert( gamma_move(board, 7, 1, 12) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_move(board, 5, 16, 10) == 0 );
assert( gamma_move(board, 6, 13, 11) == 0 );
assert( gamma_move(board, 6, 6, 9) == 1 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 5, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 33 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 5, 14, 8) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 6, 4, 2) == 0 );
assert( gamma_move(board, 7, 7, 14) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_move(board, 4, 15, 14) == 0 );
assert( gamma_move(board, 5, 8, 1) == 0 );
assert( gamma_move(board, 6, 0, 3) == 0 );
assert( gamma_move(board, 6, 8, 4) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 13, 11) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 7, 14) == 0 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 6, 5, 14) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 7, 4, 7) == 1 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_free_fields(board, 4) == 65 );
assert( gamma_move(board, 5, 8, 1) == 0 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 15, 5) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 7, 2, 7) == 0 );
assert( gamma_move(board, 7, 7, 10) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 3, 3, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 5, 13) == 0 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 6, 2, 7) == 0 );
assert( gamma_move(board, 6, 9, 9) == 0 );
assert( gamma_move(board, 7, 0, 12) == 0 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 34 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 8, 16) == 1 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 13, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 25 );


char* board363297116 = gamma_board(board);
assert( board363297116 != NULL );
assert( strcmp(board363297116, 
"1..261.6.6621.1\n"
"7.6754.12..171.\n"
".2476..525...5.\n"
"62774417.154375\n"
"44...51.445.711\n"
"11435226.4.56..\n"
"47.352537371522\n"
"65732.52476212.\n"
"6421156174235.7\n"
"2.6.332223..732\n"
"15427441.72315.\n"
"75333..64266221\n"
"7543.77.717.73.\n"
"425212.23671.7.\n"
"115774622725311\n"
"6.3.7.3.3.11446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board363297116);
board363297116 = NULL;
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 6, 5, 11) == 0 );
assert( gamma_move(board, 6, 8, 7) == 1 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 7, 10, 3) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 1, 13, 13) == 0 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 2, 13, 10) == 0 );


char* board423635637 = gamma_board(board);
assert( board423635637 != NULL );
assert( strcmp(board423635637, 
"1..261.6.6621.1\n"
"7.6754.12..171.\n"
".2476..525...5.\n"
"62774417.154375\n"
"44...51.445.711\n"
"11435226.4.56..\n"
"47.352537371522\n"
"65732.52476212.\n"
"6421156174235.7\n"
"2.6.332223..732\n"
"15427441672315.\n"
"75333.264266221\n"
"7543.77.717.73.\n"
"425212.23671.7.\n"
"115774622725311\n"
"6.3.7.3.3.11446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board423635637);
board423635637 = NULL;
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 12, 16) == 0 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 5, 2, 16) == 0 );
assert( gamma_golden_move(board, 5, 6, 3) == 1 );
assert( gamma_move(board, 6, 2, 9) == 0 );
assert( gamma_move(board, 7, 1, 13) == 0 );
assert( gamma_busy_fields(board, 7) == 34 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_free_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 5, 15) == 1 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 5, 17, 1) == 0 );
assert( gamma_move(board, 6, 16, 14) == 0 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 7, 14, 6) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );


char* board553129415 = gamma_board(board);
assert( board553129415 != NULL );
assert( strcmp(board553129415, 
"1..261.6.6621.1\n"
"7.6754.12..171.\n"
".24763.525...5.\n"
"62774417.154375\n"
"44...51.445.711\n"
"11435226.4.56..\n"
"47.352537371522\n"
"65732.52476212.\n"
"6421156174235.7\n"
"2.6.332223..732\n"
"15427441672315.\n"
"75333.264266221\n"
"7543.771717.73.\n"
"425212.23671.7.\n"
"115774522725311\n"
"6.3.7.3.3.11446\n"
"6.71523343.2254\n"
"4.....2.46...17\n") == 0);
free(board553129415);
board553129415 = NULL;
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 3, 11, 13) == 1 );
assert( gamma_move(board, 4, 1, 1) == 1 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 7, 16, 6) == 0 );
assert( gamma_move(board, 7, 8, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 34 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 8, 11) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 6, 9, 13) == 0 );
assert( gamma_move(board, 6, 1, 0) == 1 );
assert( gamma_busy_fields(board, 6) == 24 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 15, 14) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 5, 6, 5) == 0 );
assert( gamma_move(board, 6, 15, 6) == 0 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 7, 12, 7) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_golden_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 5, 17, 2) == 0 );
assert( gamma_free_fields(board, 5) == 52 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 7, 12, 13) == 0 );
assert( gamma_move(board, 7, 9, 17) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board470836514 = gamma_board(board);
assert( board470836514 != NULL );
assert( strcmp(board470836514, 
"1..261.6.6621.1\n"
"7.6754.12..171.\n"
".24763.525...5.\n"
"62774417.154375\n"
"442..51.4453711\n"
"11435226.4.56..\n"
"47.352537371522\n"
"65732.52476212.\n"
"6421156174235.7\n"
"2.6.332223..732\n"
"15427441672315.\n"
"75333.264266221\n"
"7543.771717.73.\n"
"425212.23671.7.\n"
"115774522725311\n"
"6.3.7.343.11446\n"
"6471523343.2254\n"
"46...32.46...17\n") == 0);
free(board470836514);
board470836514 = NULL;
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_move(board, 6, 8, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 24 );
assert( gamma_free_fields(board, 6) == 52 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 3, 16, 9) == 0 );
assert( gamma_move(board, 3, 14, 4) == 1 );
assert( gamma_move(board, 4, 13, 13) == 0 );
assert( gamma_move(board, 4, 14, 10) == 1 );
assert( gamma_move(board, 5, 17, 6) == 0 );
assert( gamma_free_fields(board, 5) == 50 );
assert( gamma_golden_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 6, 4, 4) == 0 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 3, 17) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_move(board, 5, 9, 13) == 0 );
assert( gamma_busy_fields(board, 5) == 27 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 6, 5, 10) == 1 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 12, 8) == 0 );
assert( gamma_move(board, 7, 13, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 6, 1, 10) == 0 );
assert( gamma_move(board, 6, 3, 8) == 1 );
assert( gamma_free_fields(board, 6) == 48 );
assert( gamma_move(board, 7, 15, 0) == 0 );


char* board642034045 = gamma_board(board);
assert( board642034045 != NULL );
assert( strcmp(board642034045, 
"1..261.6.6621.1\n"
"7.6754.12..171.\n"
".24763.525...5.\n"
"62774417.154375\n"
"442..51.4453711\n"
"11435226.4.56..\n"
"47.352537371522\n"
"657326524762124\n"
"6421156174235.7\n"
"2.66332223..732\n"
"15427441672315.\n"
"75333.264266221\n"
"7543.771717.73.\n"
"425212.23671.73\n"
"115774522725311\n"
"6.3.7.343.11446\n"
"6471523343.2254\n"
"46...32.46...17\n") == 0);
free(board642034045);
board642034045 = NULL;
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 14, 15) == 1 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_free_fields(board, 4) == 47 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 5, 8, 10) == 0 );
assert( gamma_move(board, 6, 13, 3) == 0 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 7, 9, 13) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 5, 12, 10) == 0 );
assert( gamma_move(board, 6, 7, 13) == 1 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 7, 15, 0) == 0 );
assert( gamma_move(board, 7, 5, 6) == 1 );
assert( gamma_busy_fields(board, 7) == 35 );
assert( gamma_move(board, 1, 2, 17) == 1 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_golden_move(board, 4, 11, 7) == 1 );
assert( gamma_busy_fields(board, 5) == 27 );
assert( gamma_move(board, 6, 3, 14) == 0 );
assert( gamma_move(board, 7, 15, 10) == 0 );
assert( gamma_move(board, 1, 16, 9) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_free_fields(board, 4) == 42 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_golden_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 1, 6, 17) == 1 );
assert( gamma_move(board, 1, 0, 15) == 1 );
assert( gamma_free_fields(board, 1) == 40 );


char* board630318399 = gamma_board(board);
assert( board630318399 != NULL );
assert( strcmp(board630318399, 
"1.126116.6621.1\n"
"7.6754.12..171.\n"
"124763.525...53\n"
"62774417.154375\n"
"4422.5164453711\n"
"11435226.4.56..\n"
"47.352537371522\n"
"657326524762124\n"
"6421156174235.7\n"
"2.66332223..732\n"
"15427441672415.\n"
"753337264266221\n"
"7543.771717.73.\n"
"425212.23671.73\n"
"115774522725311\n"
"6.3.7.343211446\n"
"6471523343.2254\n"
"46...32.46...17\n") == 0);
free(board630318399);
board630318399 = NULL;
assert( gamma_move(board, 2, 16, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 14) == 0 );


char* board376833249 = gamma_board(board);
assert( board376833249 != NULL );
assert( strcmp(board376833249, 
"1.126116.6621.1\n"
"7.6754.12..171.\n"
"124763.525...53\n"
"62774417.154375\n"
"4422.5164453711\n"
"11435226.4.56..\n"
"47.352537371522\n"
"657326524762124\n"
"6421156174235.7\n"
"2.66332223..732\n"
"15427441672415.\n"
"753337264266221\n"
"7543.771717.73.\n"
"425212.23671.73\n"
"115774522725311\n"
"6.3.7.343211446\n"
"6471523343.2254\n"
"46...32.46...17\n") == 0);
free(board376833249);
board376833249 = NULL;
assert( gamma_move(board, 4, 9, 17) == 0 );
assert( gamma_move(board, 5, 13, 4) == 0 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_move(board, 6, 7, 8) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 7, 11, 8) == 1 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 12, 12) == 0 );
assert( gamma_move(board, 1, 10, 16) == 1 );
assert( gamma_move(board, 2, 6, 15) == 1 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 16, 9) == 0 );


char* board129337181 = gamma_board(board);
assert( board129337181 != NULL );
assert( strcmp(board129337181, 
"1.126116.6621.1\n"
"7.6754.12.1171.\n"
"1247632525...53\n"
"62774417.154375\n"
"4422.5164453711\n"
"11435226.4.56..\n"
"47.352537371522\n"
"657326524762124\n"
"6421156174235.7\n"
"2.66332223.7732\n"
"15427441672415.\n"
"753337264266221\n"
"7543.771717.73.\n"
"425212.23671.73\n"
"115774522725311\n"
"6.3.7.343211446\n"
"6471523343.2254\n"
"46...32.46...17\n") == 0);
free(board129337181);
board129337181 = NULL;
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_move(board, 4, 4, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 5, 14, 17) == 0 );
assert( gamma_move(board, 6, 12, 3) == 0 );
assert( gamma_move(board, 6, 12, 17) == 0 );
assert( gamma_move(board, 7, 0, 10) == 0 );
assert( gamma_move(board, 1, 16, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


gamma_delete(board);

    return 0;
}
