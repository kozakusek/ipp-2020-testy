#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 125533955
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 14, 9, 24);
assert( board != NULL );


assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 3, 0, 13) == 1 );
assert( gamma_move(board, 4, 5, 11) == 1 );
assert( gamma_move(board, 5, 5, 1) == 1 );
assert( gamma_move(board, 6, 14, 13) == 1 );
assert( gamma_busy_fields(board, 6) == 1 );
assert( gamma_move(board, 7, 3, 10) == 1 );
assert( gamma_move(board, 7, 16, 9) == 1 );
assert( gamma_move(board, 8, 13, 12) == 1 );
assert( gamma_move(board, 9, 14, 7) == 1 );
assert( gamma_move(board, 9, 2, 3) == 1 );
assert( gamma_move(board, 1, 3, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 12, 8) == 1 );
assert( gamma_golden_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 4, 16, 0) == 1 );
assert( gamma_move(board, 4, 4, 6) == 1 );
assert( gamma_move(board, 5, 10, 15) == 0 );
assert( gamma_move(board, 5, 14, 12) == 1 );
assert( gamma_free_fields(board, 5) == 221 );
assert( gamma_move(board, 6, 10, 16) == 0 );
assert( gamma_move(board, 6, 15, 13) == 1 );
assert( gamma_free_fields(board, 6) == 220 );
assert( gamma_move(board, 7, 0, 2) == 1 );
assert( gamma_move(board, 7, 12, 8) == 0 );
assert( gamma_move(board, 8, 12, 4) == 1 );
assert( gamma_move(board, 8, 11, 11) == 1 );
assert( gamma_golden_move(board, 8, 13, 0) == 0 );
assert( gamma_move(board, 9, 10, 11) == 1 );
assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_move(board, 2, 15, 5) == 1 );
assert( gamma_move(board, 2, 15, 1) == 1 );
assert( gamma_golden_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_golden_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 5, 11, 15) == 0 );
assert( gamma_move(board, 5, 16, 7) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 1, 13) == 1 );
assert( gamma_move(board, 6, 0, 7) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 10, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 10, 9) == 1 );
assert( gamma_free_fields(board, 8) == 207 );
assert( gamma_move(board, 9, 9, 13) == 1 );
assert( gamma_move(board, 9, 13, 1) == 1 );


char* board223240623 = gamma_board(board);
assert( board223240623 != NULL );
assert( strcmp(board223240623, 
"36.......9....66.\n"
".............85..\n"
".41..4....98.....\n"
"...7.............\n"
"..........8.....7\n"
"..32........3....\n"
"6.............9.5\n"
"....4............\n"
"...............2.\n"
"...1........8....\n"
"..9..............\n"
"7................\n"
".....5...32..9.2.\n"
"................4\n") == 0);
free(board223240623);
board223240623 = NULL;
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_move(board, 2, 10, 8) == 1 );
assert( gamma_move(board, 2, 16, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 5) == 1 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_free_fields(board, 3) == 200 );
assert( gamma_move(board, 4, 2, 6) == 1 );
assert( gamma_move(board, 5, 8, 1) == 1 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 6, 0, 4) == 1 );
assert( gamma_move(board, 6, 10, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 6 );
assert( gamma_move(board, 8, 3, 11) == 1 );
assert( gamma_busy_fields(board, 8) == 5 );
assert( gamma_move(board, 9, 8, 14) == 0 );
assert( gamma_move(board, 9, 14, 7) == 0 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 16, 13) == 1 );
assert( gamma_golden_move(board, 3, 10, 3) == 1 );


char* board401713825 = gamma_board(board);
assert( board401713825 != NULL );
assert( strcmp(board401713825, 
"36.......9....662\n"
".............85..\n"
".418.4....98.....\n"
"...7.............\n"
"...1......8.....7\n"
"..32......2.3....\n"
"6.............9.5\n"
"..4.4............\n"
".............3.2.\n"
"6..1........8....\n"
"..9.......3.....2\n"
"7.3..............\n"
".....5..532..9.2.\n"
"................4\n") == 0);
free(board401713825);
board401713825 = NULL;
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 13, 2) == 1 );
assert( gamma_move(board, 6, 15, 11) == 1 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 9, 6) == 1 );
assert( gamma_free_fields(board, 7) == 191 );
assert( gamma_move(board, 8, 15, 0) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 5, 1) == 0 );
assert( gamma_free_fields(board, 9) == 190 );
assert( gamma_move(board, 1, 7, 12) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_move(board, 5, 3, 6) == 1 );
assert( gamma_move(board, 6, 0, 9) == 1 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 7, 8, 0) == 1 );
assert( gamma_move(board, 7, 5, 9) == 1 );
assert( gamma_move(board, 8, 9, 15) == 0 );
assert( gamma_move(board, 9, 14, 1) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_move(board, 2, 15, 6) == 1 );
assert( gamma_move(board, 2, 16, 7) == 0 );
assert( gamma_move(board, 3, 10, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 5, 4, 12) == 1 );
assert( gamma_move(board, 5, 10, 4) == 1 );
assert( gamma_move(board, 6, 9, 14) == 0 );
assert( gamma_move(board, 6, 16, 9) == 0 );
assert( gamma_move(board, 7, 7, 3) == 1 );
assert( gamma_move(board, 7, 16, 6) == 1 );
assert( gamma_busy_fields(board, 7) == 8 );
assert( gamma_move(board, 8, 6, 12) == 1 );
assert( gamma_move(board, 8, 2, 8) == 0 );
assert( gamma_move(board, 9, 6, 5) == 1 );
assert( gamma_move(board, 9, 5, 3) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 1, 9, 10) == 1 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 4, 9, 12) == 1 );
assert( gamma_move(board, 5, 9, 13) == 0 );
assert( gamma_move(board, 6, 2, 3) == 0 );
assert( gamma_move(board, 7, 10, 5) == 1 );
assert( gamma_move(board, 7, 1, 10) == 1 );
assert( gamma_move(board, 8, 13, 11) == 1 );
assert( gamma_move(board, 8, 6, 7) == 1 );
assert( gamma_move(board, 9, 8, 7) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_move(board, 5, 0, 14) == 0 );
assert( gamma_move(board, 5, 4, 5) == 1 );
assert( gamma_move(board, 6, 11, 16) == 0 );
assert( gamma_move(board, 6, 6, 11) == 1 );
assert( gamma_move(board, 7, 1, 1) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 1, 15, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_golden_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 3, 15, 2) == 1 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 5, 12, 1) == 1 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 6, 0, 3) == 1 );
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_golden_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 4, 16) == 0 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 8, 13, 10) == 1 );
assert( gamma_move(board, 8, 13, 12) == 0 );
assert( gamma_move(board, 9, 1, 16) == 0 );
assert( gamma_move(board, 9, 15, 13) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 2, 12, 12) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 15, 7) == 1 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 6, 12, 4) == 0 );
assert( gamma_move(board, 6, 4, 0) == 1 );
assert( gamma_busy_fields(board, 6) == 11 );
assert( gamma_move(board, 7, 13, 4) == 1 );
assert( gamma_move(board, 7, 16, 10) == 1 );
assert( gamma_move(board, 8, 3, 11) == 0 );
assert( gamma_move(board, 8, 2, 0) == 1 );
assert( gamma_move(board, 9, 12, 15) == 0 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_move(board, 6, 9, 3) == 1 );
assert( gamma_move(board, 6, 13, 8) == 1 );
assert( gamma_move(board, 7, 7, 10) == 1 );
assert( gamma_move(board, 7, 4, 4) == 0 );
assert( gamma_move(board, 8, 4, 8) == 1 );
assert( gamma_move(board, 8, 1, 13) == 0 );
assert( gamma_golden_move(board, 8, 4, 0) == 1 );


char* board424431889 = gamma_board(board);
assert( board424431889 != NULL );
assert( strcmp(board424431889, 
"36.......9....662\n"
"....5.81.43.285..\n"
".418.46...98.8.6.\n"
".7.7...7.1...8..7\n"
"6..1.7.3..8.....7\n"
"..328.....2136...\n"
"64....8.9....4935\n"
"2.454...17.....27\n"
"....5.9...7..3.2.\n"
"6.214.....5.17.1.\n"
"6.9..9.7.63.....2\n"
"7.3..........6.3.\n"
".7...5..532.5992.\n"
"1.8.81..7......84\n") == 0);
free(board424431889);
board424431889 = NULL;
assert( gamma_move(board, 9, 2, 6) == 0 );
assert( gamma_move(board, 1, 12, 0) == 1 );
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 5, 8) == 1 );
assert( gamma_move(board, 5, 13, 6) == 1 );
assert( gamma_golden_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 6, 6, 3) == 1 );
assert( gamma_move(board, 7, 7, 4) == 1 );
assert( gamma_move(board, 8, 4, 11) == 1 );
assert( gamma_move(board, 9, 5, 8) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_move(board, 4, 13, 3) == 1 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 1, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_move(board, 8, 3, 15) == 0 );
assert( gamma_move(board, 8, 10, 13) == 1 );
assert( gamma_move(board, 9, 5, 16) == 0 );
assert( gamma_move(board, 9, 13, 10) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_golden_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 4, 6, 10) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 6, 11, 8) == 0 );
assert( gamma_move(board, 7, 9, 13) == 0 );
assert( gamma_move(board, 8, 8, 7) == 0 );
assert( gamma_move(board, 8, 11, 9) == 1 );
assert( gamma_move(board, 9, 6, 11) == 0 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 5, 6, 14) == 0 );
assert( gamma_move(board, 6, 7, 5) == 1 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 9, 7) == 0 );


char* board496619042 = gamma_board(board);
assert( board496619042 != NULL );
assert( strcmp(board496619042, 
"36.......98...662\n"
"..2.5.81.43.285..\n"
".418846...98.8.6.\n"
".7.7..47.1...8..7\n"
"6..1.7.3.188....7\n"
"..3285....2136...\n"
"64....8.9....4935\n"
"2.454...172..5.27\n"
"..3.5196..7..3.2.\n"
"65214..7..5.17.1.\n"
"6.93.967.63..4..2\n"
"7.3......2...6.3.\n"
".7...5..532.5992.\n"
"1.8.81..7.1.1..84\n") == 0);
free(board496619042);
board496619042 = NULL;
assert( gamma_move(board, 7, 10, 11) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 8, 11, 2) == 1 );
assert( gamma_move(board, 9, 4, 6) == 0 );
assert( gamma_move(board, 9, 14, 11) == 1 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 10, 15) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );


char* board124630265 = gamma_board(board);
assert( board124630265 != NULL );
assert( strcmp(board124630265, 
"36.......98...662\n"
"..2.5.81.43.285..\n"
".418846...98.896.\n"
".7.7..47.1...8..7\n"
"6..1.7.3.188....7\n"
"..3285....2136...\n"
"64....8.9....4935\n"
"2.454...172..5.27\n"
"..3.5196..7..3.2.\n"
"65214..7..5.17.1.\n"
"6.93.967.63..4..2\n"
"7.3......2.8.6.3.\n"
".7...5..532.5992.\n"
"1.8.81..7.1.1..84\n") == 0);
free(board124630265);
board124630265 = NULL;
assert( gamma_move(board, 5, 4, 14) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_free_fields(board, 5) == 118 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_move(board, 7, 2, 5) == 0 );
assert( gamma_move(board, 7, 15, 0) == 0 );
assert( gamma_free_fields(board, 7) == 118 );
assert( gamma_move(board, 8, 11, 0) == 1 );
assert( gamma_move(board, 9, 2, 1) == 1 );
assert( gamma_move(board, 9, 9, 5) == 1 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_free_fields(board, 1) == 115 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 4, 12, 3) == 1 );
assert( gamma_move(board, 6, 9, 8) == 1 );
assert( gamma_move(board, 6, 14, 5) == 1 );
assert( gamma_move(board, 7, 7, 10) == 0 );


char* board112760159 = gamma_board(board);
assert( board112760159 != NULL );
assert( strcmp(board112760159, 
"36.......98...662\n"
"..2.5.81.43.285..\n"
".418846...98.896.\n"
".7.7..47.1...8..7\n"
"62.1.7.3.188....7\n"
"..3285...62136...\n"
"644...8.9....4935\n"
"2.454...172..5.27\n"
"..3.5196.97..362.\n"
"65214..7..5.17.1.\n"
"6.93.967.63.44..2\n"
"7.3......2.8.6.3.\n"
".79..5..532.5992.\n"
"1.8.81..7.181..84\n") == 0);
free(board112760159);
board112760159 = NULL;
assert( gamma_move(board, 8, 1, 12) == 1 );
assert( gamma_move(board, 8, 11, 3) == 1 );
assert( gamma_move(board, 9, 0, 1) == 1 );
assert( gamma_move(board, 9, 15, 5) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );


char* board355479133 = gamma_board(board);
assert( board355479133 != NULL );
assert( strcmp(board355479133, 
"36.......98...662\n"
".82.5.81.43.285..\n"
".418846...98.896.\n"
".7.7..47.1...8..7\n"
"62.1.7.3.188....7\n"
"..3285...62136...\n"
"644...8.9....4935\n"
"2.454...172..5.27\n"
"..3.5196.97..362.\n"
"65214..7..5.17.1.\n"
"6.93.967.63844..2\n"
"7.3......2.8.6.3.\n"
"979..5..532.5992.\n"
"1.8.81..7.181..84\n") == 0);
free(board355479133);
board355479133 = NULL;
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 4, 12, 6) == 1 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_move(board, 6, 13, 7) == 0 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_move(board, 7, 10, 8) == 0 );
assert( gamma_move(board, 7, 15, 12) == 1 );
assert( gamma_move(board, 8, 3, 8) == 0 );
assert( gamma_move(board, 9, 10, 10) == 1 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );


char* board521318529 = gamma_board(board);
assert( board521318529 != NULL );
assert( strcmp(board521318529, 
"36.......98...662\n"
".82.5.81.43.2857.\n"
".418846...98.896.\n"
"37.7..47.19..8..7\n"
"62.1.7.3.188....7\n"
"..3285...62136...\n"
"644...8.9....4935\n"
"2.454...172.45.27\n"
"..3.5196.97..362.\n"
"65214..7..5.17.1.\n"
"6.93.967.63844..2\n"
"7.3......2.8.6.3.\n"
"979..5..532.5992.\n"
"1.8.81..7.181..84\n") == 0);
free(board521318529);
board521318529 = NULL;
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 5, 16, 1) == 1 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_free_fields(board, 7) == 101 );
assert( gamma_move(board, 8, 6, 11) == 0 );
assert( gamma_move(board, 8, 12, 6) == 0 );
assert( gamma_busy_fields(board, 8) == 19 );
assert( gamma_move(board, 9, 12, 3) == 0 );
assert( gamma_move(board, 9, 13, 8) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_golden_move(board, 3, 3, 9) == 0 );
assert( gamma_move(board, 4, 8, 10) == 1 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 5, 15, 13) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 7, 5, 4) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 7) == 1 );
assert( gamma_move(board, 9, 3, 4) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_move(board, 4, 16, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 2, 10) == 1 );
assert( gamma_move(board, 5, 16, 11) == 1 );
assert( gamma_move(board, 6, 10, 3) == 0 );
assert( gamma_move(board, 7, 4, 11) == 0 );
assert( gamma_busy_fields(board, 7) == 17 );
assert( gamma_busy_fields(board, 8) == 20 );


char* board669904907 = gamma_board(board);
assert( board669904907 != NULL );
assert( strcmp(board669904907, 
"36.....3.98...662\n"
".82.5.81.43.2857.\n"
".418846.2.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.188....7\n"
"..3285..362136..4\n"
"644...889....4935\n"
"2.454...172.45.27\n"
".53.5196.97..362.\n"
"652147.7..5.17.1.\n"
"6.93.967.63844..2\n"
"7.3....1.2.8.6.3.\n"
"979..5..532.59925\n"
"1.8.81..7.181..84\n") == 0);
free(board669904907);
board669904907 = NULL;
assert( gamma_move(board, 9, 11, 0) == 0 );
assert( gamma_move(board, 9, 15, 4) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 15, 13) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_free_fields(board, 4) == 90 );
assert( gamma_move(board, 5, 0, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_move(board, 6, 9, 12) == 0 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 17 );
assert( gamma_golden_move(board, 7, 9, 9) == 1 );
assert( gamma_move(board, 8, 11, 9) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );


char* board768793362 = gamma_board(board);
assert( board768793362 != NULL );
assert( strcmp(board768793362, 
"36.....3.98...662\n"
".82.5.81.43.2857.\n"
".418846.2.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.788....7\n"
"5.3285..362136..4\n"
"644...889....4935\n"
"2.454...172.45.27\n"
".53.5196.97..362.\n"
"652147.7..5.17.1.\n"
"6.93.967.63844..2\n"
"7.3....1.2.8.6.3.\n"
"979..5..532.59925\n"
"1.8.81..7.181..84\n") == 0);
free(board768793362);
board768793362 = NULL;
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_golden_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );


char* board652703347 = gamma_board(board);
assert( board652703347 != NULL );
assert( strcmp(board652703347, 
"36.....3.98...662\n"
".82.5.81.43.2857.\n"
".418846.2.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.788....7\n"
"5.3285..362136..4\n"
"644...889....4935\n"
"2.454...172.45.27\n"
".53.5196.97..362.\n"
"652147.7..5.17.1.\n"
"6.93.967.63844..2\n"
"7.3....1.2.8.6.3.\n"
"979..5..532.59925\n"
"1.8.81..7.181..84\n") == 0);
free(board652703347);
board652703347 = NULL;
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 5, 5, 11) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 7, 11, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 18 );
assert( gamma_move(board, 8, 13, 6) == 0 );


char* board415275390 = gamma_board(board);
assert( board415275390 != NULL );
assert( strcmp(board415275390, 
"36.....3.98...662\n"
".82.5.81.43.2857.\n"
".418846.2.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.788....7\n"
"5.3285..362136..4\n"
"644...889....4935\n"
"2.454...172.45.27\n"
".53.5196.97..362.\n"
"652147.7..5.17.1.\n"
"6.93.967.63844..2\n"
"7.3....1.2.8.6.3.\n"
"979..5..532.59925\n"
"1.8.81..7.181..84\n") == 0);
free(board415275390);
board415275390 = NULL;
assert( gamma_move(board, 9, 10, 12) == 0 );
assert( gamma_move(board, 9, 14, 1) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 2, 16, 4) == 1 );
assert( gamma_golden_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 3, 9, 4) == 1 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_move(board, 5, 4, 4) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_move(board, 6, 7, 11) == 1 );


char* board576648959 = gamma_board(board);
assert( board576648959 != NULL );
assert( strcmp(board576648959, 
"36.....3.98...662\n"
".82.5.81.43.2857.\n"
".41884662.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.788....7\n"
"5.3285..362136..4\n"
"644...889....4935\n"
"2.454...172.45.27\n"
".53.5196.97..362.\n"
"652147.7.35.17.12\n"
"6.93.967.63844..2\n"
"7.3....1.2.8.6.3.\n"
"979..5..532.59925\n"
"1.8.81..7.181..84\n") == 0);
free(board576648959);
board576648959 = NULL;
assert( gamma_move(board, 7, 10, 5) == 0 );
assert( gamma_move(board, 7, 11, 2) == 0 );


char* board181022900 = gamma_board(board);
assert( board181022900 != NULL );
assert( strcmp(board181022900, 
"36.....3.98...662\n"
".82.5.81.43.2857.\n"
".41884662.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.788....7\n"
"5.3285..362136..4\n"
"644...889....4935\n"
"2.454...172.45.27\n"
".53.5196.97..362.\n"
"652147.7.35.17.12\n"
"6.93.967.63844..2\n"
"7.3....1.2.8.6.3.\n"
"979..5..532.59925\n"
"1.8.81..7.181..84\n") == 0);
free(board181022900);
board181022900 = NULL;
assert( gamma_move(board, 8, 11, 0) == 0 );
assert( gamma_free_fields(board, 8) == 86 );
assert( gamma_move(board, 9, 5, 12) == 1 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 13) == 1 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 5, 9, 0) == 1 );
assert( gamma_move(board, 6, 4, 2) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 8, 7) == 0 );
assert( gamma_move(board, 8, 13, 2) == 0 );
assert( gamma_move(board, 8, 5, 4) == 0 );
assert( gamma_move(board, 9, 13, 11) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_free_fields(board, 2) == 82 );


char* board875584608 = gamma_board(board);
assert( board875584608 != NULL );
assert( strcmp(board875584608, 
"36.3...3.98...662\n"
".82.5981.43.2857.\n"
".41884662.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.788....7\n"
"5.3285..362136..4\n"
"644...889....4935\n"
"2.454...172.45.27\n"
".53.5196.97..362.\n"
"652147.7.35.17.12\n"
"6.93.967.63844..2\n"
"7.3.6..1.2.8.6.3.\n"
"979..5..532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board875584608);
board875584608 = NULL;
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 3, 4, 1) == 1 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );


char* board573789482 = gamma_board(board);
assert( board573789482 != NULL );
assert( strcmp(board573789482, 
"36.3...3.98...662\n"
".82.5981.43.2857.\n"
".41884662.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.788....7\n"
"5.3285..362136..4\n"
"644...889....4935\n"
"23454...172.45.27\n"
".53.5196.97..362.\n"
"652147.7.35.17.12\n"
"6.93.967.63844..2\n"
"7.3.6..1.2.8.6.3.\n"
"979.35..532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board573789482);
board573789482 = NULL;
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_move(board, 7, 11, 3) == 0 );
assert( gamma_move(board, 8, 12, 11) == 0 );
assert( gamma_move(board, 8, 13, 12) == 0 );
assert( gamma_move(board, 9, 5, 0) == 0 );
assert( gamma_move(board, 9, 7, 12) == 0 );
assert( gamma_free_fields(board, 1) == 79 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_free_fields(board, 5) == 78 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 6, 3, 7) == 1 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_free_fields(board, 7) == 77 );
assert( gamma_move(board, 8, 7, 9) == 0 );
assert( gamma_move(board, 8, 12, 9) == 1 );
assert( gamma_golden_move(board, 8, 1, 8) == 0 );
assert( gamma_move(board, 9, 6, 14) == 0 );
assert( gamma_move(board, 9, 13, 9) == 1 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_move(board, 3, 12, 5) == 1 );


char* board794657107 = gamma_board(board);
assert( board794657107 != NULL );
assert( strcmp(board794657107, 
"36.3...3.98...662\n"
".82.5981.43.2857.\n"
".41884662.9828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889..7\n"
"5.3285..362136..4\n"
"6446..889....4935\n"
"23454...172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"6.93.967.63844..2\n"
"7.3.6..1.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board794657107);
board794657107 = NULL;
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_move(board, 7, 4, 3) == 1 );
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_move(board, 8, 15, 6) == 0 );
assert( gamma_move(board, 9, 13, 13) == 1 );
assert( gamma_move(board, 9, 9, 11) == 1 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_move(board, 1, 16, 11) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_free_fields(board, 3) == 71 );


char* board450612101 = gamma_board(board);
assert( board450612101 != NULL );
assert( strcmp(board450612101, 
"36.3...3.98..9662\n"
".82.5981.43.2857.\n"
".4188466299828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889..7\n"
"5.3285..362136..4\n"
"6446..889....4935\n"
"23454...172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"6.937967.63844..2\n"
"7.3.6..1.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board450612101);
board450612101 = NULL;
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_free_fields(board, 4) == 71 );


char* board687138386 = gamma_board(board);
assert( board687138386 != NULL );
assert( strcmp(board687138386, 
"36.3...3.98..9662\n"
".82.5981.43.2857.\n"
".4188466299828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889..7\n"
"5.3285..362136..4\n"
"6446..889....4935\n"
"23454...172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"6.937967.63844..2\n"
"7.3.6..1.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board687138386);
board687138386 = NULL;
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_move(board, 6, 10, 12) == 0 );
assert( gamma_move(board, 6, 16, 11) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 7, 5, 13) == 1 );
assert( gamma_move(board, 8, 4, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 21 );
assert( gamma_move(board, 9, 2, 1) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_golden_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 15, 3) == 1 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 7, 5, 5) == 0 );
assert( gamma_move(board, 8, 3, 8) == 0 );
assert( gamma_move(board, 8, 6, 6) == 0 );
assert( gamma_busy_fields(board, 8) == 21 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 9, 13, 2) == 0 );
assert( gamma_move(board, 9, 16, 6) == 0 );


char* board845082381 = gamma_board(board);
assert( board845082381 != NULL );
assert( strcmp(board845082381, 
"36.3.7.3.98..9662\n"
".82.5981.43.2857.\n"
".4188466299828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889..7\n"
"5.3285..362136..4\n"
"6446..889....4935\n"
"23454.5.172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"6.937967.63844.32\n"
"7.3.6..1.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board845082381);
board845082381 = NULL;
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 1, 3, 12) == 1 );


char* board131255708 = gamma_board(board);
assert( board131255708 != NULL );
assert( strcmp(board131255708, 
"36.3.7.3.98..9662\n"
".8215981.43.2857.\n"
".4188466299828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889..7\n"
"5.3285..362136..4\n"
"6446..889....4935\n"
"23454.5.172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"6.937967.63844.32\n"
"7.3.6..1.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board131255708);
board131255708 = NULL;
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 2, 13, 13) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_free_fields(board, 6) == 67 );
assert( gamma_move(board, 7, 9, 15) == 0 );
assert( gamma_golden_move(board, 7, 11, 5) == 0 );
assert( gamma_move(board, 8, 9, 6) == 0 );
assert( gamma_free_fields(board, 8) == 67 );
assert( gamma_move(board, 9, 1, 10) == 0 );
assert( gamma_move(board, 9, 10, 12) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 2, 16, 10) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 3, 11, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 24 );


char* board703095974 = gamma_board(board);
assert( board703095974 != NULL );
assert( strcmp(board703095974, 
"36.3.7.3.983.9662\n"
".8215981.43.2857.\n"
".4188466299828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889..7\n"
"5.3285..362136..4\n"
"6446..889....4935\n"
"23454.5.172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"6.937967.63844.32\n"
"7.3.6..1.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board703095974);
board703095974 = NULL;
assert( gamma_move(board, 4, 10, 15) == 0 );
assert( gamma_free_fields(board, 5) == 66 );
assert( gamma_golden_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 7, 12) == 0 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 8, 5, 16) == 0 );
assert( gamma_move(board, 9, 0, 14) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_free_fields(board, 3) == 66 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 12, 13) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 11) == 1 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_move(board, 7, 9, 6) == 0 );
assert( gamma_move(board, 7, 15, 11) == 0 );
assert( gamma_move(board, 8, 2, 14) == 0 );
assert( gamma_move(board, 8, 15, 8) == 1 );
assert( gamma_move(board, 9, 14, 11) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 3, 14, 11) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 6, 9, 14) == 0 );
assert( gamma_move(board, 6, 5, 12) == 0 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 7, 15, 9) == 1 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 5, 4) == 0 );
assert( gamma_move(board, 8, 10, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 22 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 9, 1, 7) == 0 );
assert( gamma_move(board, 9, 5, 4) == 0 );
assert( gamma_busy_fields(board, 9) == 18 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 3, 4, 13) == 1 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );


char* board350280373 = gamma_board(board);
assert( board350280373 != NULL );
assert( strcmp(board350280373, 
"36.337.3.98359662\n"
".8215981.43.2857.\n"
"64188466299828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889.77\n"
"5.3285..362136.84\n"
"6446..889....4935\n"
"23454.5.172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"61937967.63844.32\n"
"7.3.6..1.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board350280373);
board350280373 = NULL;
assert( gamma_move(board, 5, 12, 16) == 0 );
assert( gamma_move(board, 5, 9, 11) == 0 );
assert( gamma_move(board, 6, 3, 14) == 0 );
assert( gamma_free_fields(board, 6) == 60 );
assert( gamma_move(board, 7, 5, 8) == 0 );
assert( gamma_move(board, 8, 13, 6) == 0 );
assert( gamma_move(board, 8, 15, 2) == 0 );
assert( gamma_busy_fields(board, 8) == 22 );
assert( gamma_move(board, 9, 13, 8) == 0 );
assert( gamma_move(board, 9, 11, 0) == 0 );
assert( gamma_busy_fields(board, 9) == 18 );
assert( gamma_move(board, 1, 12, 16) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_free_fields(board, 2) == 60 );
assert( gamma_move(board, 3, 10, 14) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_free_fields(board, 4) == 60 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 6, 12, 12) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 7, 13, 13) == 0 );
assert( gamma_move(board, 8, 4, 14) == 0 );
assert( gamma_move(board, 8, 6, 2) == 1 );
assert( gamma_move(board, 9, 12, 11) == 0 );
assert( gamma_busy_fields(board, 9) == 18 );
assert( gamma_free_fields(board, 9) == 59 );


char* board314214697 = gamma_board(board);
assert( board314214697 != NULL );
assert( strcmp(board314214697, 
"36.337.3.98359662\n"
".8215981.43.2857.\n"
"64188466299828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889.77\n"
"5.3285..362136.84\n"
"6446..889....4935\n"
"23454.5.172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"61937967.63844.32\n"
"7.3.6.81.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board314214697);
board314214697 = NULL;
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_free_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 4, 16, 7) == 0 );
assert( gamma_move(board, 5, 9, 14) == 0 );
assert( gamma_move(board, 7, 0, 14) == 0 );
assert( gamma_move(board, 8, 13, 8) == 0 );


char* board989606093 = gamma_board(board);
assert( board989606093 != NULL );
assert( strcmp(board989606093, 
"36.337.3.98359662\n"
".8215981.43.2857.\n"
"64188466299828965\n"
"3757..47419..8..7\n"
"62.1.7.3.78889.77\n"
"5.3285..362136.84\n"
"6446..889....4935\n"
"23454.5.172.45.27\n"
".5335196.97.3362.\n"
"652147.7.35.17.12\n"
"61937967.63844.32\n"
"7.3.6.81.2.8.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181..84\n") == 0);
free(board989606093);
board989606093 = NULL;
assert( gamma_move(board, 9, 9, 6) == 0 );
assert( gamma_move(board, 9, 10, 6) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 5, 14, 7) == 0 );
assert( gamma_free_fields(board, 5) == 59 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 14, 0) == 1 );
assert( gamma_move(board, 8, 2, 14) == 0 );
assert( gamma_move(board, 9, 2, 14) == 0 );
assert( gamma_move(board, 9, 9, 4) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 6, 0, 7) == 0 );
assert( gamma_move(board, 7, 9, 12) == 0 );
assert( gamma_move(board, 8, 12, 0) == 0 );
assert( gamma_move(board, 9, 7, 9) == 0 );
assert( gamma_move(board, 9, 0, 10) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_golden_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 6, 13, 8) == 0 );
assert( gamma_move(board, 7, 3, 14) == 0 );
assert( gamma_move(board, 7, 15, 10) == 1 );
assert( gamma_busy_fields(board, 7) == 23 );
assert( gamma_move(board, 8, 12, 0) == 0 );
assert( gamma_move(board, 9, 7, 5) == 0 );
assert( gamma_move(board, 1, 11, 5) == 1 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_golden_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_golden_move(board, 4, 11, 11) == 1 );
assert( gamma_move(board, 5, 14, 6) == 1 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 6, 13, 6) == 0 );
assert( gamma_move(board, 7, 15, 4) == 0 );
assert( gamma_move(board, 7, 0, 10) == 0 );
assert( gamma_move(board, 8, 15, 0) == 0 );
assert( gamma_free_fields(board, 8) == 53 );
assert( gamma_move(board, 9, 12, 4) == 0 );
assert( gamma_free_fields(board, 9) == 53 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_golden_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 5, 15, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 16, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_move(board, 8, 7, 12) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 9, 3, 11) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 6, 3, 14) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 7, 9, 7) == 1 );
assert( gamma_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 8, 5, 4) == 0 );
assert( gamma_move(board, 9, 10, 14) == 0 );
assert( gamma_move(board, 9, 7, 9) == 0 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 5, 15, 7) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 9, 10) == 1 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 6, 13, 10) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 5) == 0 );
assert( gamma_move(board, 7, 13, 12) == 0 );
assert( gamma_move(board, 8, 2, 8) == 0 );
assert( gamma_move(board, 9, 13, 6) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 13, 13) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 6, 15, 2) == 0 );
assert( gamma_move(board, 7, 0, 13) == 0 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 8, 5, 8) == 0 );
assert( gamma_move(board, 9, 8, 6) == 0 );
assert( gamma_move(board, 9, 7, 3) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_move(board, 6, 16, 5) == 1 );
assert( gamma_free_fields(board, 6) == 50 );
assert( gamma_move(board, 7, 0, 13) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 9, 13) == 0 );
assert( gamma_move(board, 9, 9, 6) == 0 );
assert( gamma_move(board, 9, 14, 13) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_free_fields(board, 2) == 50 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_golden_move(board, 3, 4, 15) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 5, 10, 7) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_move(board, 7, 7, 5) == 0 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 8, 12, 8) == 0 );
assert( gamma_move(board, 9, 6, 7) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_free_fields(board, 2) == 47 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 5, 13, 6) == 0 );
assert( gamma_move(board, 6, 15, 2) == 0 );
assert( gamma_move(board, 8, 10, 10) == 0 );
assert( gamma_move(board, 8, 13, 6) == 0 );
assert( gamma_move(board, 9, 7, 11) == 0 );
assert( gamma_move(board, 9, 14, 3) == 1 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 12, 10) == 1 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 4, 12, 13) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 7, 0, 13) == 0 );
assert( gamma_move(board, 9, 13, 2) == 0 );
assert( gamma_move(board, 1, 12, 6) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_free_fields(board, 3) == 44 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 4, 8, 3) == 1 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_busy_fields(board, 7) == 24 );
assert( gamma_move(board, 8, 0, 7) == 0 );


char* board864889383 = gamma_board(board);
assert( board864889383 != NULL );
assert( strcmp(board864889383, 
"36.337.3.98359662\n"
".8215981.43.2857.\n"
"64188466299428965\n"
"3757..47459.28.77\n"
"62.1.7.3.78889.77\n"
"553285..362136.84\n"
"6446..88975..4935\n"
"23454.5.172.45527\n"
".5335196.97133626\n"
"65214727.35.17.12\n"
"61937967463844932\n"
"733.63812248.6.3.\n"
"979.356.532.59925\n"
"1.8.81..75181.784\n") == 0);
free(board864889383);
board864889383 = NULL;
assert( gamma_move(board, 9, 4, 8) == 0 );
assert( gamma_move(board, 9, 9, 1) == 0 );
assert( gamma_golden_move(board, 9, 1, 14) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 16) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 6, 11, 0) == 0 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_move(board, 7, 10, 14) == 0 );
assert( gamma_move(board, 8, 15, 4) == 0 );
assert( gamma_move(board, 9, 9, 6) == 0 );
assert( gamma_move(board, 9, 4, 1) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 5, 10, 11) == 0 );
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 6, 2, 16) == 0 );
assert( gamma_golden_move(board, 6, 13, 13) == 1 );
assert( gamma_move(board, 7, 10, 5) == 0 );


gamma_delete(board);

    return 0;
}
