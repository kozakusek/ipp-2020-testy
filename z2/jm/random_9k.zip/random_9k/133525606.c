#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 133525606
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 14, 7, 21);
assert( board != NULL );


assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_move(board, 2, 15, 13) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 3, 5, 12) == 1 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_move(board, 4, 16, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 2 );
assert( gamma_free_fields(board, 4) == 233 );
assert( gamma_move(board, 5, 15, 9) == 1 );
assert( gamma_move(board, 6, 5, 10) == 1 );
assert( gamma_move(board, 6, 8, 6) == 1 );
assert( gamma_move(board, 7, 2, 6) == 1 );
assert( gamma_move(board, 7, 11, 2) == 1 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_free_fields(board, 2) == 226 );
assert( gamma_free_fields(board, 3) == 226 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 4, 9, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 3 );
assert( gamma_free_fields(board, 4) == 225 );
assert( gamma_golden_move(board, 4, 10, 5) == 0 );
assert( gamma_free_fields(board, 5) == 225 );
assert( gamma_golden_move(board, 5, 13, 15) == 0 );
assert( gamma_move(board, 6, 6, 3) == 1 );
assert( gamma_move(board, 6, 6, 10) == 1 );
assert( gamma_busy_fields(board, 6) == 4 );
assert( gamma_move(board, 7, 7, 2) == 1 );
assert( gamma_busy_fields(board, 7) == 3 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_golden_move(board, 2, 9, 15) == 0 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 4, 2, 1) == 1 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_free_fields(board, 4) == 216 );
assert( gamma_move(board, 5, 5, 7) == 1 );
assert( gamma_move(board, 6, 6, 6) == 1 );
assert( gamma_move(board, 7, 3, 3) == 1 );
assert( gamma_move(board, 1, 15, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 3 );
assert( gamma_move(board, 2, 10, 8) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 4, 12, 13) == 1 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 5, 15, 9) == 0 );
assert( gamma_move(board, 5, 2, 11) == 1 );
assert( gamma_free_fields(board, 5) == 208 );
assert( gamma_move(board, 6, 12, 3) == 1 );
assert( gamma_move(board, 6, 15, 0) == 1 );
assert( gamma_move(board, 7, 10, 12) == 1 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 12, 8) == 1 );
assert( gamma_move(board, 3, 3, 11) == 1 );
assert( gamma_move(board, 3, 15, 10) == 1 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 4, 9, 6) == 1 );
assert( gamma_move(board, 5, 7, 1) == 1 );


char* board840348721 = gamma_board(board);
assert( board840348721 != NULL );
assert( strcmp(board840348721, 
".3..........4..2.\n"
".....3...17......\n"
"..53..4..........\n"
"...3.66........3.\n"
"...............5.\n"
".........42.2...4\n"
".....5...........\n"
"2.7...6.64.......\n"
"....4............\n"
".................\n"
"13.7..6.....6....\n"
".......7...7.....\n"
".24....5.......1.\n"
".3....4........6.\n") == 0);
free(board840348721);
board840348721 = NULL;
assert( gamma_move(board, 6, 8, 2) == 1 );
assert( gamma_move(board, 6, 8, 3) == 1 );
assert( gamma_move(board, 7, 0, 4) == 1 );
assert( gamma_free_fields(board, 1) == 196 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_move(board, 3, 16, 5) == 1 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 6, 12, 0) == 1 );
assert( gamma_move(board, 7, 2, 4) == 1 );
assert( gamma_move(board, 7, 11, 0) == 1 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 3, 10, 11) == 1 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 5, 7, 0) == 1 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_move(board, 6, 8, 0) == 1 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_move(board, 3, 13, 2) == 1 );
assert( gamma_move(board, 3, 4, 1) == 1 );
assert( gamma_move(board, 4, 11, 8) == 1 );
assert( gamma_move(board, 5, 0, 14) == 0 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 11) == 1 );
assert( gamma_golden_move(board, 7, 3, 2) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 10, 0) == 1 );


char* board212622734 = gamma_board(board);
assert( board212622734 != NULL );
assert( strcmp(board212622734, 
".3..........4..2.\n"
".....3...17......\n"
".453..47..3......\n"
"..63.66........3.\n"
".........2...2.5.\n"
".........4242...4\n"
".....5...........\n"
"2.7...6.64.......\n"
"....4...........3\n"
"7.7..............\n"
"13371.6.6...6....\n"
".......76..7.3...\n"
".24.3..52......1.\n"
".3....456.376..6.\n") == 0);
free(board212622734);
board212622734 = NULL;
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 5, 12, 11) == 1 );
assert( gamma_move(board, 6, 9, 3) == 1 );
assert( gamma_golden_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 7, 16, 8) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 16) == 0 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_move(board, 5, 0, 9) == 1 );
assert( gamma_move(board, 5, 4, 13) == 1 );
assert( gamma_move(board, 6, 13, 3) == 1 );
assert( gamma_move(board, 7, 10, 13) == 0 );
assert( gamma_move(board, 7, 6, 13) == 1 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_golden_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 4, 7, 7) == 1 );
assert( gamma_move(board, 6, 2, 3) == 0 );
assert( gamma_move(board, 7, 11, 13) == 1 );
assert( gamma_move(board, 7, 4, 12) == 1 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_move(board, 4, 7, 3) == 1 );
assert( gamma_move(board, 5, 2, 7) == 1 );
assert( gamma_move(board, 6, 1, 16) == 0 );
assert( gamma_move(board, 6, 4, 12) == 0 );
assert( gamma_free_fields(board, 7) == 160 );


char* board632401051 = gamma_board(board);
assert( board632401051 != NULL );
assert( strcmp(board632401051, 
".3..5.7...274..2.\n"
"....73...17......\n"
".453..47..3.5....\n"
"..63.661.......3.\n"
"5........1...2.5.\n"
"..4......4242...4\n"
"..5..5.4.........\n"
"2.7...6.64.......\n"
"....41..........3\n"
"7.7..............\n"
"13371.6466..66...\n"
"2......763.7.3...\n"
".24.3..52......1.\n"
".3....456.376..6.\n") == 0);
free(board632401051);
board632401051 = NULL;
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_move(board, 1, 16, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_move(board, 2, 12, 4) == 1 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 3, 0, 16) == 0 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 4, 8, 5) == 1 );
assert( gamma_move(board, 4, 1, 12) == 1 );
assert( gamma_move(board, 5, 7, 14) == 0 );
assert( gamma_move(board, 5, 8, 12) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 6, 16, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 3, 5) == 1 );
assert( gamma_move(board, 7, 8, 4) == 1 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_golden_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 3, 16, 5) == 0 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 5, 16, 1) == 1 );
assert( gamma_move(board, 5, 14, 3) == 1 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 6, 12, 7) == 1 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 1, 14, 2) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 2, 11, 12) == 1 );
assert( gamma_golden_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 9) == 1 );
assert( gamma_move(board, 5, 12, 12) == 1 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 7, 12, 14) == 0 );
assert( gamma_move(board, 1, 11, 4) == 1 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 10, 13) == 0 );
assert( gamma_golden_move(board, 5, 2, 14) == 0 );
assert( gamma_move(board, 6, 5, 8) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board660523374 = gamma_board(board);
assert( board660523374 != NULL );
assert( strcmp(board660523374, 
".3..5.7...274..2.\n"
".4.273..51725....\n"
".453..47..3.5...1\n"
"..63.661.......3.\n"
"53..3....25..2.5.\n"
"..4..6...4242...4\n"
"..5..524....6....\n"
"2.7...6.64.......\n"
"...741..4.......3\n"
"737.....7..12....\n"
"13371.6466..665..\n"
"2......763.7.31..\n"
".24.3..52......15\n"
".3....456.376..6.\n") == 0);
free(board660523374);
board660523374 = NULL;
assert( gamma_move(board, 7, 6, 12) == 1 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 2, 6, 14) == 0 );
assert( gamma_move(board, 2, 15, 11) == 1 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_move(board, 5, 13, 1) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_move(board, 7, 5, 14) == 0 );
assert( gamma_move(board, 7, 8, 3) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_move(board, 4, 8, 10) == 1 );
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 14, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 7) == 1 );
assert( gamma_free_fields(board, 3) == 130 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 5, 11, 3) == 1 );
assert( gamma_move(board, 5, 1, 10) == 1 );


char* board418274164 = gamma_board(board);
assert( board418274164 != NULL );
assert( strcmp(board418274164, 
".3..5.7...274..2.\n"
".4.2737.51725....\n"
".453..47..3.5..21\n"
".563.6614......3.\n"
"53..3....25..225.\n"
"..4..6...4242...4\n"
".25..524....63...\n"
"2.7...6.64.......\n"
"...741..4.......3\n"
"737...3.7..12....\n"
"13371.6466.5665..\n"
"2......763.7.31..\n"
".24.34.52....5.15\n"
".3....456.376..6.\n") == 0);
free(board418274164);
board418274164 = NULL;
assert( gamma_move(board, 6, 13, 9) == 0 );
assert( gamma_move(board, 6, 4, 2) == 1 );
assert( gamma_move(board, 7, 12, 15) == 0 );
assert( gamma_move(board, 7, 13, 3) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_move(board, 5, 5, 15) == 0 );
assert( gamma_move(board, 6, 9, 12) == 0 );
assert( gamma_move(board, 7, 2, 2) == 1 );
assert( gamma_move(board, 7, 15, 5) == 1 );
assert( gamma_move(board, 1, 15, 7) == 1 );
assert( gamma_move(board, 1, 5, 11) == 1 );


char* board881823350 = gamma_board(board);
assert( board881823350 != NULL );
assert( strcmp(board881823350, 
".3..5.7...274..2.\n"
".4.2737.51725....\n"
".453.147..3.5..21\n"
".563.6614......3.\n"
"53..3....25..225.\n"
"..4..6...4242...4\n"
".25..524....63.1.\n"
"247...6.64.......\n"
"1..741..4......73\n"
"737.3.3.7..12....\n"
"13371.6466.5665..\n"
"2.7.6..763.7.31..\n"
".24.34.52....5.15\n"
".3....456.376..6.\n") == 0);
free(board881823350);
board881823350 = NULL;
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_free_fields(board, 2) == 120 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 4, 7, 9) == 1 );
assert( gamma_free_fields(board, 4) == 118 );
assert( gamma_move(board, 5, 12, 7) == 0 );
assert( gamma_move(board, 6, 13, 0) == 1 );
assert( gamma_free_fields(board, 6) == 117 );


char* board140960120 = gamma_board(board);
assert( board140960120 != NULL );
assert( strcmp(board140960120, 
".3..5.7...274..2.\n"
".4.2737.51725....\n"
".453.147..3.5..21\n"
".563.6614......3.\n"
"53..3..4.25..225.\n"
"..4..6...4242...4\n"
".25..524....63.1.\n"
"247...6.64.......\n"
"1..741..4......73\n"
"737.3.3.7..12....\n"
"1337136466.5665..\n"
"2.7.6..763.7.31..\n"
".24.34.52....5.15\n"
".3....456.3766.6.\n") == 0);
free(board140960120);
board140960120 = NULL;
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 1, 7, 12) == 1 );
assert( gamma_move(board, 2, 8, 13) == 1 );
assert( gamma_free_fields(board, 2) == 115 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 6, 4, 9) == 0 );
assert( gamma_move(board, 6, 15, 11) == 0 );
assert( gamma_golden_move(board, 6, 9, 7) == 0 );
assert( gamma_move(board, 7, 7, 4) == 1 );
assert( gamma_free_fields(board, 7) == 114 );
assert( gamma_move(board, 1, 12, 10) == 1 );
assert( gamma_move(board, 2, 11, 10) == 1 );
assert( gamma_move(board, 2, 8, 5) == 0 );


char* board555721601 = gamma_board(board);
assert( board555721601 != NULL );
assert( strcmp(board555721601, 
".3..5.7.2.274..2.\n"
".4.2737151725....\n"
".453.147..3.5..21\n"
".563.6614..21..3.\n"
"53..3..4.25..225.\n"
"..4..6...4242...4\n"
".25..524....63.1.\n"
"247...6.64.......\n"
"1..741..4......73\n"
"737.3.377..12....\n"
"1337136466.5665..\n"
"2.7.6..763.7.31..\n"
".24.34.52....5.15\n"
".3....456.3766.6.\n") == 0);
free(board555721601);
board555721601 = NULL;
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 22 );


char* board747309765 = gamma_board(board);
assert( board747309765 != NULL );
assert( strcmp(board747309765, 
".33.5.7.2.274..2.\n"
".4.2737151725....\n"
".453.147..3.5..21\n"
".563.6614..21..3.\n"
"53..3..4.25..225.\n"
"..4..6...4242...4\n"
".25..524....63.1.\n"
"247...6.64.......\n"
"1..741..4......73\n"
"737.3.377..12....\n"
"1337136466.5665..\n"
"2.7.6..763.7.31..\n"
".24.34.52....5.15\n"
".3....456.3766.6.\n") == 0);
free(board747309765);
board747309765 = NULL;
assert( gamma_move(board, 4, 16, 4) == 1 );
assert( gamma_move(board, 5, 6, 5) == 1 );
assert( gamma_move(board, 6, 12, 9) == 1 );
assert( gamma_move(board, 7, 12, 13) == 0 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 5, 14, 8) == 1 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 15, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_golden_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_free_fields(board, 4) == 106 );
assert( gamma_move(board, 5, 6, 2) == 1 );
assert( gamma_move(board, 6, 3, 7) == 1 );
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 13, 14) == 0 );
assert( gamma_move(board, 5, 6, 9) == 1 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 16, 5) == 0 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_golden_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 5, 6, 14) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 6, 9, 11) == 1 );
assert( gamma_move(board, 7, 0, 13) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 6) == 1 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_golden_move(board, 6, 3, 5) == 1 );
assert( gamma_move(board, 7, 4, 15) == 0 );
assert( gamma_move(board, 7, 4, 10) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 4, 6) == 1 );


char* board330035099 = gamma_board(board);
assert( board330035099 != NULL );
assert( strcmp(board330035099, 
"733.5.7.2.274..2.\n"
".4.2737151725....\n"
".453.147.63.5..21\n"
".56376614..21..3.\n"
"53..3354.25.6225.\n"
"..4..6...4242.5.4\n"
".256.524....63.1.\n"
"2475156.64.......\n"
"1..6415.4......73\n"
"737.3.377..12...4\n"
"1337136466.56651.\n"
"2.7.6.5763.7.31..\n"
".24.34.52...25.15\n"
".3....456.3766.6.\n") == 0);
free(board330035099);
board330035099 = NULL;
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 2, 13, 11) == 1 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 4, 7, 8) == 1 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_free_fields(board, 5) == 93 );
assert( gamma_golden_move(board, 5, 11, 3) == 0 );
assert( gamma_move(board, 6, 10, 16) == 0 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 19 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 12, 16) == 0 );
assert( gamma_move(board, 1, 16, 7) == 1 );
assert( gamma_free_fields(board, 1) == 92 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 4, 14, 4) == 1 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 5, 1, 11) == 0 );
assert( gamma_move(board, 6, 9, 2) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 7, 8) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_free_fields(board, 1) == 91 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_free_fields(board, 4) == 91 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 6, 4) == 0 );
assert( gamma_move(board, 6, 13, 9) == 0 );
assert( gamma_free_fields(board, 6) == 91 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_free_fields(board, 1) == 91 );
assert( gamma_move(board, 2, 13, 5) == 1 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 12, 2) == 1 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_golden_move(board, 5, 3, 3) == 1 );
assert( gamma_move(board, 6, 13, 11) == 0 );
assert( gamma_move(board, 6, 16, 5) == 0 );
assert( gamma_move(board, 7, 8, 13) == 0 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 16, 7) == 0 );
assert( gamma_move(board, 4, 5, 12) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );
assert( gamma_move(board, 6, 3, 12) == 0 );
assert( gamma_move(board, 7, 16, 11) == 0 );
assert( gamma_move(board, 7, 12, 8) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 5, 10, 11) == 0 );
assert( gamma_move(board, 6, 12, 13) == 0 );
assert( gamma_move(board, 7, 8, 4) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 3, 4) == 0 );


char* board312590304 = gamma_board(board);
assert( board312590304 != NULL );
assert( strcmp(board312590304, 
"733.5.7.2.274..2.\n"
".4.2737151725....\n"
".453.147.63.52.21\n"
".56376614..21..3.\n"
"53..3354.25.6225.\n"
"..4..6.4.4242.5.4\n"
".25655244...63.11\n"
"2475156.64.......\n"
"1..6415.4...32.73\n"
"737.3.377..12.4.4\n"
"1335136466.56651.\n"
"2.7.6.5763.7431..\n"
".24334.52...25.15\n"
".3....456.3766.6.\n") == 0);
free(board312590304);
board312590304 = NULL;


char* board785811376 = gamma_board(board);
assert( board785811376 != NULL );
assert( strcmp(board785811376, 
"733.5.7.2.274..2.\n"
".4.2737151725....\n"
".453.147.63.52.21\n"
".56376614..21..3.\n"
"53..3354.25.6225.\n"
"..4..6.4.4242.5.4\n"
".25655244...63.11\n"
"2475156.64.......\n"
"1..6415.4...32.73\n"
"737.3.377..12.4.4\n"
"1335136466.56651.\n"
"2.7.6.5763.7431..\n"
".24334.52...25.15\n"
".3....456.3766.6.\n") == 0);
free(board785811376);
board785811376 = NULL;
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_golden_move(board, 5, 8, 2) == 0 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_free_fields(board, 2) == 28 );
assert( gamma_move(board, 3, 4, 15) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_free_fields(board, 3) == 85 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_move(board, 5, 10, 14) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 7, 0, 2) == 0 );
assert( gamma_move(board, 7, 13, 6) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 7) == 0 );
assert( gamma_move(board, 6, 4, 9) == 0 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 12, 6) == 1 );
assert( gamma_move(board, 1, 11, 11) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_free_fields(board, 1) == 82 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 0, 5) == 0 );


char* board604754631 = gamma_board(board);
assert( board604754631 != NULL );
assert( strcmp(board604754631, 
"733.5.7.2.274..2.\n"
".4.2737151725....\n"
".453.147.63152.21\n"
".56376614..21..3.\n"
"53..3354.25.6225.\n"
"..4..6.4.4242.5.4\n"
".25655244...63.11\n"
"2475156.64..77...\n"
"1..6415.4...32.73\n"
"737.3.377..12.4.4\n"
"1335136466.56651.\n"
"2.7.6.5763.7431..\n"
".24334.52...25.15\n"
".3....456.3766.6.\n") == 0);
free(board604754631);
board604754631 = NULL;
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_free_fields(board, 3) == 82 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 5, 6, 14) == 0 );
assert( gamma_move(board, 6, 8, 13) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 16, 13) == 1 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 15, 2) == 1 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 6, 5, 2) == 1 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 9, 4) == 1 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 5, 14, 2) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 1, 14) == 0 );
assert( gamma_move(board, 7, 8, 2) == 0 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 6, 8, 4) == 0 );
assert( gamma_move(board, 6, 16, 9) == 1 );
assert( gamma_move(board, 7, 10, 13) == 0 );
assert( gamma_move(board, 7, 16, 4) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_free_fields(board, 1) == 76 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 10, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 7, 15, 3) == 0 );
assert( gamma_move(board, 7, 10, 9) == 0 );


char* board482127787 = gamma_board(board);
assert( board482127787 != NULL );
assert( strcmp(board482127787, 
"733.5.7.2.274..22\n"
".4.2737151725....\n"
".453.147.63152.21\n"
".56376614.321..3.\n"
"53..3354.25.62256\n"
"..4..6.4.4242.5.4\n"
".25655244...63.11\n"
"2475156.64..77...\n"
"1..6415.4...32.73\n"
"737.3.3774.12.4.4\n"
"1335136466.56651.\n"
"2.7.665763.74313.\n"
".24334.52...25.15\n"
".31...456.3766.6.\n") == 0);
free(board482127787);
board482127787 = NULL;
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_free_fields(board, 1) == 75 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_free_fields(board, 2) == 25 );
assert( gamma_golden_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 5, 12, 14) == 0 );
assert( gamma_move(board, 6, 2, 16) == 0 );
assert( gamma_busy_fields(board, 6) == 24 );
assert( gamma_move(board, 7, 14, 13) == 1 );
assert( gamma_move(board, 7, 4, 8) == 1 );
assert( gamma_move(board, 1, 3, 16) == 0 );
assert( gamma_golden_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 5, 13, 13) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 6, 1, 11) == 0 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_free_fields(board, 6) == 73 );
assert( gamma_move(board, 7, 2, 16) == 0 );
assert( gamma_move(board, 7, 4, 1) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_golden_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 3, 6, 16) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 4, 6, 10) == 0 );
assert( gamma_move(board, 5, 3, 10) == 0 );
assert( gamma_move(board, 5, 15, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_golden_move(board, 5, 13, 14) == 0 );
assert( gamma_move(board, 6, 8, 4) == 0 );
assert( gamma_free_fields(board, 6) == 72 );
assert( gamma_move(board, 7, 8, 8) == 1 );
assert( gamma_move(board, 7, 12, 2) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 13, 8) == 1 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 5, 13, 1) == 0 );
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 7, 0, 3) == 0 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_free_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 16, 7) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 5, 13, 9) == 0 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 7, 13, 5) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );


char* board874777472 = gamma_board(board);
assert( board874777472 != NULL );
assert( strcmp(board874777472, 
"733.5.7.2.274.722\n"
".4.2737151725....\n"
".453.147.63152.21\n"
".56376614.321..3.\n"
"531.3354.25.62256\n"
"..4.76.47424225.4\n"
".25655244...63.11\n"
"2475156.64..77...\n"
"1..6415.4...32.73\n"
"737.323774.12.4.4\n"
"1335136466.56651.\n"
"2.7.665763.74313.\n"
".24334.52...25.15\n"
".31...456.3766.6.\n") == 0);
free(board874777472);
board874777472 = NULL;
assert( gamma_move(board, 7, 0, 14) == 0 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 20 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 16, 12) == 1 );
assert( gamma_free_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_move(board, 3, 5, 11) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_golden_move(board, 4, 4, 9) == 0 );


char* board591769166 = gamma_board(board);
assert( board591769166 != NULL );
assert( strcmp(board591769166, 
"733.5.7.2.274.722\n"
".4.2737151725...2\n"
".453.147.63152.21\n"
".56376614.321..3.\n"
"531.3354325.62256\n"
"..4.76.47424225.4\n"
".25655244...63.11\n"
"2475156.64..77...\n"
"1..6415.4...32.73\n"
"737.323774.12.4.4\n"
"1335136466.56651.\n"
"2.7.665763.74313.\n"
".24334.52...25.15\n"
".31...456.3766.6.\n") == 0);
free(board591769166);
board591769166 = NULL;
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_free_fields(board, 5) == 19 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 24 );
assert( gamma_free_fields(board, 6) == 67 );
assert( gamma_move(board, 7, 6, 11) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 7, 5, 8) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 8, 15) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_golden_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 5, 13, 9) == 0 );
assert( gamma_move(board, 5, 3, 7) == 0 );


char* board549578059 = gamma_board(board);
assert( board549578059 != NULL );
assert( strcmp(board549578059, 
"733.5.7.2.274.722\n"
".4.2737151725...2\n"
".453.147.63152.21\n"
".56376614.321..3.\n"
"531.3354325.62256\n"
"..4.76.47424225.4\n"
".25655244...63.11\n"
"2475156.64..77...\n"
"1..6415.4...32.73\n"
"737.323774.12.4.4\n"
"1335136466.56651.\n"
"2.7.665763.74313.\n"
".24334.52...25.15\n"
".31...456.3766.6.\n") == 0);
free(board549578059);
board549578059 = NULL;
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 6, 11, 2) == 0 );
assert( gamma_move(board, 7, 1, 6) == 0 );
assert( gamma_move(board, 7, 14, 6) == 1 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 24 );
assert( gamma_move(board, 7, 8, 15) == 0 );
assert( gamma_move(board, 7, 15, 5) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_free_fields(board, 1) == 65 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 3, 1, 5) == 1 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_free_fields(board, 4) == 22 );
assert( gamma_move(board, 5, 11, 14) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 1, 14) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 1, 14, 5) == 1 );
assert( gamma_move(board, 2, 12, 15) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 5, 6, 15) == 0 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 6, 6, 16) == 0 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 16) == 0 );
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_move(board, 6, 7, 10) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_free_fields(board, 7) == 61 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 7, 14, 13) == 0 );
assert( gamma_move(board, 7, 11, 10) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 5, 16, 13) == 0 );
assert( gamma_move(board, 6, 11, 4) == 0 );
assert( gamma_move(board, 6, 15, 8) == 1 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_move(board, 7, 10, 9) == 0 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 3, 4, 15) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 4, 15, 12) == 0 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_free_fields(board, 5) == 17 );
assert( gamma_move(board, 6, 16, 11) == 0 );
assert( gamma_move(board, 7, 10, 14) == 0 );
assert( gamma_busy_fields(board, 7) == 24 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_free_fields(board, 3) == 23 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 5) == 1 );
assert( gamma_move(board, 6, 5, 10) == 0 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_free_fields(board, 6) == 58 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 16, 12) == 0 );
assert( gamma_move(board, 7, 16, 9) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_move(board, 7, 3, 8) == 1 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_free_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 4, 16, 9) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_free_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 3, 13) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 6, 0, 13) == 0 );
assert( gamma_move(board, 7, 13, 5) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 5, 14, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 3, 12) == 0 );
assert( gamma_move(board, 6, 4, 4) == 0 );
assert( gamma_golden_move(board, 6, 6, 4) == 0 );
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 25 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_golden_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 3, 16) == 0 );
assert( gamma_free_fields(board, 3) == 20 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 1) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_move(board, 7, 4, 13) == 0 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_free_fields(board, 2) == 17 );
assert( gamma_golden_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_free_fields(board, 3) == 20 );
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 6, 1, 14) == 0 );
assert( gamma_move(board, 6, 7, 12) == 0 );
assert( gamma_move(board, 7, 6, 16) == 0 );
assert( gamma_move(board, 7, 13, 1) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_move(board, 5, 12, 14) == 0 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 6, 15) == 0 );
assert( gamma_move(board, 7, 1, 13) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_free_fields(board, 2) == 17 );
assert( gamma_golden_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_golden_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 6, 13, 13) == 1 );
assert( gamma_move(board, 7, 1, 11) == 0 );
assert( gamma_move(board, 7, 8, 13) == 0 );


gamma_delete(board);

    return 0;
}
