#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 137047842
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 6, 3, 20);
assert( board != NULL );


assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_golden_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 2, 4, 16) == 0 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_free_fields(board, 3) == 103 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 2, 7, 3) == 1 );


char* board338979683 = gamma_board(board);
assert( board338979683 != NULL );
assert( strcmp(board338979683, 
"......2...........\n"
".3.....121........\n"
".....1.2..........\n"
"..................\n"
"..................\n"
"1.................\n") == 0);
free(board338979683);
board338979683 = NULL;
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 3, 15, 4) == 1 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 8, 2) == 1 );
assert( gamma_move(board, 2, 5, 2) == 1 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 2, 12, 3) == 1 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_free_fields(board, 3) == 94 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_golden_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_free_fields(board, 2) == 93 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_free_fields(board, 1) == 89 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 13, 5) == 1 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 7 );


char* board352548848 = gamma_board(board);
assert( board352548848 != NULL );
assert( strcmp(board352548848, 
"......2......3....\n"
"233....121.....3..\n"
".....1.2....2.....\n"
".....2..13..3.....\n"
"..3....2.2........\n"
"1..........2......\n") == 0);
free(board352548848);
board352548848 = NULL;
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_free_fields(board, 2) == 87 );
assert( gamma_golden_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board193062266 = gamma_board(board);
assert( board193062266 != NULL );
assert( strcmp(board193062266, 
"..3...2......3....\n"
"233....121.....3..\n"
".....1.2....2.....\n"
".....2..13..3.....\n"
"..3....2.2........\n"
"1..........2......\n") == 0);
free(board193062266);
board193062266 = NULL;
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 1, 16, 2) == 1 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_free_fields(board, 1) == 82 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 15, 0) == 1 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 3, 17, 1) == 1 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 11, 4) == 1 );
assert( gamma_golden_move(board, 1, 1, 17) == 0 );
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_free_fields(board, 3) == 73 );
assert( gamma_golden_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 1, 17, 3) == 1 );
assert( gamma_move(board, 2, 3, 1) == 1 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 1, 16, 4) == 1 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_golden_move(board, 1, 1, 17) == 0 );
assert( gamma_move(board, 2, 16, 0) == 1 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 13, 0) == 1 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 1, 15, 2) == 1 );
assert( gamma_free_fields(board, 1) == 62 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 2, 2, 0) == 1 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 15, 3) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 14, 0) == 1 );
assert( gamma_move(board, 2, 4, 17) == 0 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_move(board, 3, 15, 1) == 1 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 6, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 1, 14, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 1, 15, 5) == 1 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );


char* board437194922 = gamma_board(board);
assert( board437194922 != NULL );
assert( strcmp(board437194922, 
"12323323...2.3.1..\n"
"2333...12111...31.\n"
"3.11.1.231..2..3.1\n"
".23..21.13..3.111.\n"
"3132...2.2.22..3.3\n"
"1.2.2..13..2.2112.\n") == 0);
free(board437194922);
board437194922 = NULL;
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_free_fields(board, 2) == 45 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_free_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 2, 4, 17) == 0 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 14, 3) == 1 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 10, 3) == 1 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 4, 17) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_free_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 1, 12, 3) == 0 );


char* board300757181 = gamma_board(board);
assert( board300757181 != NULL );
assert( strcmp(board300757181, 
"12323323.212.3.1..\n"
"23331..12111...31.\n"
"3.11.1.2313.2.33.1\n"
".23..21.13213.111.\n"
"3132...2.2322..3.3\n"
"1.2.2..13.22.2112.\n") == 0);
free(board300757181);
board300757181 = NULL;
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_free_fields(board, 1) == 36 );
assert( gamma_golden_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 1, 4, 17) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_free_fields(board, 3) == 35 );
assert( gamma_golden_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 1, 17, 4) == 1 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_golden_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_free_fields(board, 3) == 32 );
assert( gamma_free_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 14, 1) == 1 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_move(board, 3, 4, 14) == 0 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 17, 4) == 0 );
assert( gamma_free_fields(board, 3) == 30 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );


char* board371264216 = gamma_board(board);
assert( board371264216 != NULL );
assert( strcmp(board371264216, 
"12323323.212.3.1..\n"
"23331..12111...311\n"
"3.11.1.2313.2.33.1\n"
"1231.21.13213.111.\n"
"3132.3.2.2322.13.3\n"
"12232..13.22.2112.\n") == 0);
free(board371264216);
board371264216 = NULL;
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_free_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 2, 17, 2) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 16, 3) == 1 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_free_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 16, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 14, 4) == 1 );
assert( gamma_move(board, 2, 17, 1) == 0 );


char* board772148744 = gamma_board(board);
assert( board772148744 != NULL );
assert( strcmp(board772148744, 
"12323323.212.3.13.\n"
"233311.12111..1311\n"
"3.11.112313.2.3311\n"
"1231.21.13213.111.\n"
"3132.3.2.2322.13.3\n"
"12232..13.22.2112.\n") == 0);
free(board772148744);
board772148744 = NULL;
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 17, 4) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );


char* board291125855 = gamma_board(board);
assert( board291125855 != NULL );
assert( strcmp(board291125855, 
"12323323.212.3.13.\n"
"233311.12111..1311\n"
"3.11.112313.2.3311\n"
"1231.21.13213.111.\n"
"3132.3.2.2322.13.3\n"
"12232..13.22.2112.\n") == 0);
free(board291125855);
board291125855 = NULL;
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_golden_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 14, 5) == 1 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 1, 13, 3) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_free_fields(board, 2) == 17 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 1, 12, 5) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_free_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_free_fields(board, 1) == 20 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_move(board, 3, 1, 16) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 16, 5) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_free_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board569434264 = gamma_board(board);
assert( board569434264 != NULL );
assert( strcmp(board569434264, 
"12323323.21213313.\n"
"233311.12111..1311\n"
"3.11.112313.213311\n"
"1231221.13213.111.\n"
"3132.3.2.2322.13.3\n"
"122323.13.22.2112.\n") == 0);
free(board569434264);
board569434264 = NULL;
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_free_fields(board, 3) == 20 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_golden_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board432536113 = gamma_board(board);
assert( board432536113 != NULL );
assert( strcmp(board432536113, 
"12323323.21213313.\n"
"233311.12111..1311\n"
"3.11.112313.213311\n"
"1231221.13213.111.\n"
"3132.3.2.2322.13.3\n"
"122323.13.22.2112.\n") == 0);
free(board432536113);
board432536113 = NULL;
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 1, 5, 17) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );


char* board514361812 = gamma_board(board);
assert( board514361812 != NULL );
assert( strcmp(board514361812, 
"12323323.21213313.\n"
"233311.12111..1311\n"
"3.11.112313.213311\n"
"1231221.13213.111.\n"
"3132.3.2.2322.13.3\n"
"122323.13.22.2112.\n") == 0);
free(board514361812);
board514361812 = NULL;
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_free_fields(board, 1) == 20 );
assert( gamma_move(board, 2, 17, 2) == 0 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 3, 16, 3) == 0 );


gamma_delete(board);

    return 0;
}
