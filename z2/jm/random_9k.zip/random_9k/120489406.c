#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 120489406
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(5, 18, 8, 12);
assert( board != NULL );


assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 1, 16) == 1 );
assert( gamma_move(board, 4, 2, 17) == 1 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 5, 3, 2) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 3) == 0 );
assert( gamma_move(board, 7, 0, 8) == 1 );
assert( gamma_move(board, 8, 1, 7) == 1 );
assert( gamma_free_fields(board, 8) == 83 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_free_fields(board, 2) == 81 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 6, 2, 8) == 1 );
assert( gamma_move(board, 6, 3, 9) == 1 );
assert( gamma_free_fields(board, 6) == 77 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 8, 3, 5) == 1 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 5, 2, 12) == 1 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 6, 4, 9) == 1 );
assert( gamma_move(board, 7, 3, 15) == 1 );
assert( gamma_move(board, 7, 1, 17) == 1 );
assert( gamma_move(board, 8, 11, 3) == 0 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 16, 4) == 0 );
assert( gamma_move(board, 3, 1, 10) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 5, 4, 17) == 1 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_move(board, 6, 3, 8) == 1 );
assert( gamma_move(board, 7, 14, 2) == 0 );
assert( gamma_move(board, 7, 0, 10) == 1 );
assert( gamma_free_fields(board, 7) == 64 );
assert( gamma_move(board, 8, 17, 0) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 3, 4, 3) == 1 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 6, 3, 1) == 1 );
assert( gamma_move(board, 7, 3, 2) == 0 );
assert( gamma_move(board, 7, 3, 10) == 1 );
assert( gamma_move(board, 8, 2, 1) == 1 );
assert( gamma_move(board, 8, 2, 2) == 1 );
assert( gamma_move(board, 1, 0, 7) == 1 );


char* board190611589 = gamma_board(board);
assert( board190611589 != NULL );
assert( strcmp(board190611589, 
".74.5\n"
".3...\n"
"...7.\n"
"1....\n"
"..1..\n"
"..5..\n"
".....\n"
"73.7.\n"
"...66\n"
"7.66.\n"
"18..5\n"
".4...\n"
".2.8.\n"
"1....\n"
".2..3\n"
".285.\n"
"31861\n"
".....\n") == 0);
free(board190611589);
board190611589 = NULL;
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 5, 16, 3) == 0 );
assert( gamma_move(board, 6, 14, 1) == 0 );
assert( gamma_move(board, 6, 4, 13) == 1 );
assert( gamma_golden_move(board, 6, 2, 3) == 0 );
assert( gamma_move(board, 7, 5, 4) == 0 );
assert( gamma_move(board, 7, 0, 6) == 1 );
assert( gamma_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 8, 2, 6) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 2, 0, 13) == 1 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_free_fields(board, 4) == 52 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 6, 16, 3) == 0 );
assert( gamma_free_fields(board, 6) == 52 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 8, 0, 1) == 0 );
assert( gamma_move(board, 1, 17, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_free_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 3, 4, 16) == 1 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 5, 10, 4) == 0 );
assert( gamma_move(board, 5, 2, 7) == 1 );
assert( gamma_free_fields(board, 5) == 49 );
assert( gamma_move(board, 6, 4, 4) == 1 );
assert( gamma_move(board, 7, 2, 0) == 1 );
assert( gamma_move(board, 7, 1, 2) == 0 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_move(board, 8, 2, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 5 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_free_fields(board, 2) == 47 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 14, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 3 );
assert( gamma_move(board, 5, 3, 13) == 1 );
assert( gamma_move(board, 6, 3, 0) == 1 );
assert( gamma_move(board, 6, 4, 3) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board341322550 = gamma_board(board);
assert( board341322550 != NULL );
assert( strcmp(board341322550, 
".74.5\n"
".3..3\n"
"...7.\n"
"1....\n"
"2.156\n"
"..5..\n"
".....\n"
"73.7.\n"
"3..66\n"
"7.66.\n"
"185.5\n"
"748..\n"
".2.8.\n"
"1...6\n"
".24.3\n"
".285.\n"
"31861\n"
"..76.\n") == 0);
free(board341322550);
board341322550 = NULL;
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_move(board, 8, 4, 13) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 6, 3, 12) == 1 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 16, 2) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 4, 5) == 1 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 6, 4, 15) == 1 );
assert( gamma_move(board, 7, 3, 15) == 0 );
assert( gamma_move(board, 7, 3, 17) == 1 );
assert( gamma_move(board, 8, 8, 4) == 0 );
assert( gamma_move(board, 8, 3, 4) == 1 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 1, 0, 16) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board320216579 = gamma_board(board);
assert( board320216579 != NULL );
assert( strcmp(board320216579, 
".7475\n"
"13..3\n"
"...76\n"
"1....\n"
"2.156\n"
"..56.\n"
".....\n"
"73.7.\n"
"3..66\n"
"7.66.\n"
"185.5\n"
"748..\n"
".2.81\n"
"1..86\n"
".24.3\n"
".285.\n"
"31861\n"
"4.76.\n") == 0);
free(board320216579);
board320216579 = NULL;
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 4, 16, 2) == 0 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 5, 4, 8) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board749309728 = gamma_board(board);
assert( board749309728 != NULL );
assert( strcmp(board749309728, 
".7475\n"
"13..3\n"
"...76\n"
"1....\n"
"2.156\n"
"..56.\n"
".....\n"
"73.7.\n"
"3.266\n"
"7.665\n"
"185.5\n"
"748..\n"
".2.81\n"
"1..86\n"
".24.3\n"
".285.\n"
"31861\n"
"4.76.\n") == 0);
free(board749309728);
board749309728 = NULL;
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_move(board, 7, 11, 3) == 0 );
assert( gamma_move(board, 7, 2, 9) == 0 );
assert( gamma_move(board, 8, 3, 3) == 1 );
assert( gamma_move(board, 8, 1, 8) == 1 );
assert( gamma_golden_move(board, 8, 2, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 6, 14, 4) == 0 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_move(board, 8, 9, 1) == 0 );
assert( gamma_move(board, 8, 3, 16) == 1 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 3, 6) == 1 );
assert( gamma_free_fields(board, 1) == 32 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 12) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 6, 11, 3) == 0 );
assert( gamma_move(board, 7, 17, 0) == 0 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_free_fields(board, 7) == 31 );


char* board725465026 = gamma_board(board);
assert( board725465026 != NULL );
assert( strcmp(board725465026, 
".7475\n"
"13.83\n"
"...76\n"
"1....\n"
"2.156\n"
"3.56.\n"
".....\n"
"73.7.\n"
"3.266\n"
"78665\n"
"185.5\n"
"7481.\n"
".2.81\n"
"1..86\n"
".2883\n"
".285.\n"
"31861\n"
"4.76.\n") == 0);
free(board725465026);
board725465026 = NULL;
assert( gamma_move(board, 8, 12, 1) == 0 );
assert( gamma_move(board, 8, 2, 5) == 1 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_free_fields(board, 4) == 30 );
assert( gamma_golden_move(board, 4, 17, 4) == 0 );
assert( gamma_move(board, 5, 1, 4) == 1 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_move(board, 8, 15, 0) == 0 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_free_fields(board, 2) == 29 );
assert( gamma_golden_move(board, 2, 17, 2) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );


char* board562723308 = gamma_board(board);
assert( board562723308 != NULL );
assert( strcmp(board562723308, 
".7475\n"
"13.83\n"
"...76\n"
"1....\n"
"2.156\n"
"3.56.\n"
".....\n"
"73.7.\n"
"3.266\n"
"78665\n"
"185.5\n"
"7481.\n"
".2881\n"
"15.86\n"
".2883\n"
"3285.\n"
"31861\n"
"4.76.\n") == 0);
free(board562723308);
board562723308 = NULL;
assert( gamma_move(board, 4, 15, 2) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 4, 10) == 1 );
assert( gamma_move(board, 5, 4, 15) == 0 );
assert( gamma_move(board, 6, 4, 10) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_move(board, 7, 3, 2) == 0 );
assert( gamma_move(board, 7, 3, 17) == 0 );
assert( gamma_move(board, 8, 3, 5) == 0 );
assert( gamma_move(board, 8, 0, 12) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 2, 16) == 1 );


char* board176864314 = gamma_board(board);
assert( board176864314 != NULL );
assert( strcmp(board176864314, 
".7475\n"
"13283\n"
"...76\n"
"1....\n"
"2.156\n"
"3.56.\n"
".....\n"
"73.75\n"
"3.266\n"
"78665\n"
"185.5\n"
"7481.\n"
".2881\n"
"15.86\n"
".2883\n"
"3285.\n"
"31861\n"
"4.76.\n") == 0);
free(board176864314);
board176864314 = NULL;
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_free_fields(board, 3) == 26 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 4) == 1 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_move(board, 7, 4, 11) == 1 );
assert( gamma_free_fields(board, 7) == 24 );
assert( gamma_move(board, 8, 0, 4) == 0 );
assert( gamma_busy_fields(board, 8) == 11 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_free_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 5, 0, 13) == 0 );
assert( gamma_move(board, 6, 15, 1) == 0 );
assert( gamma_golden_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 7, 14, 3) == 0 );
assert( gamma_move(board, 8, 15, 2) == 0 );
assert( gamma_move(board, 8, 0, 9) == 0 );
assert( gamma_free_fields(board, 1) == 23 );


char* board994520053 = gamma_board(board);
assert( board994520053 != NULL );
assert( strcmp(board994520053, 
".7475\n"
"13283\n"
"...76\n"
"1....\n"
"2.156\n"
"3.563\n"
"....7\n"
"73.75\n"
"3.266\n"
"78665\n"
"185.5\n"
"7481.\n"
".2881\n"
"15486\n"
".2883\n"
"3285.\n"
"31861\n"
"4.76.\n") == 0);
free(board994520053);
board994520053 = NULL;
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_free_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_move(board, 5, 14, 2) == 0 );
assert( gamma_move(board, 6, 15, 1) == 0 );
assert( gamma_move(board, 7, 14, 4) == 0 );
assert( gamma_golden_move(board, 7, 0, 2) == 1 );
assert( gamma_move(board, 8, 0, 13) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_free_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_move(board, 5, 13, 1) == 0 );


char* board772743483 = gamma_board(board);
assert( board772743483 != NULL );
assert( strcmp(board772743483, 
".7475\n"
"13283\n"
"...76\n"
"1..3.\n"
"2.156\n"
"3.563\n"
"...47\n"
"73.75\n"
"3.266\n"
"78665\n"
"185.5\n"
"74812\n"
".2881\n"
"15486\n"
".2883\n"
"7285.\n"
"31861\n"
"4.76.\n") == 0);
free(board772743483);
board772743483 = NULL;
assert( gamma_move(board, 7, 17, 0) == 0 );
assert( gamma_move(board, 7, 3, 10) == 0 );
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 0, 11) == 1 );


char* board474552490 = gamma_board(board);
assert( board474552490 != NULL );
assert( strcmp(board474552490, 
".7475\n"
"13283\n"
"...76\n"
"1..3.\n"
"2.156\n"
"3.563\n"
"3..47\n"
"73.75\n"
"3.266\n"
"78665\n"
"185.5\n"
"74812\n"
".2881\n"
"15486\n"
".2883\n"
"7285.\n"
"31861\n"
"4.76.\n") == 0);
free(board474552490);
board474552490 = NULL;
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_move(board, 6, 3, 15) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_move(board, 7, 15, 0) == 0 );
assert( gamma_move(board, 7, 1, 2) == 0 );
assert( gamma_move(board, 8, 0, 14) == 0 );
assert( gamma_move(board, 8, 0, 16) == 0 );
assert( gamma_free_fields(board, 8) == 18 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 4, 15) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 5, 17, 0) == 0 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 6, 15, 0) == 0 );
assert( gamma_move(board, 6, 1, 16) == 0 );
assert( gamma_move(board, 7, 11, 1) == 0 );
assert( gamma_move(board, 7, 1, 16) == 0 );
assert( gamma_move(board, 8, 17, 0) == 0 );


char* board728849846 = gamma_board(board);
assert( board728849846 != NULL );
assert( strcmp(board728849846, 
".7475\n"
"13283\n"
"...76\n"
"1..3.\n"
"2.156\n"
"3.563\n"
"3..47\n"
"73175\n"
"3.266\n"
"78665\n"
"185.5\n"
"74812\n"
".2881\n"
"15486\n"
".2883\n"
"7285.\n"
"31861\n"
"4576.\n") == 0);
free(board728849846);
board728849846 = NULL;
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_golden_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_golden_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 17, 0) == 0 );


char* board819425669 = gamma_board(board);
assert( board819425669 != NULL );
assert( strcmp(board819425669, 
".7475\n"
"13283\n"
"...76\n"
"1..3.\n"
"2.156\n"
"3.563\n"
"3..47\n"
"73175\n"
"3.266\n"
"78665\n"
"185.5\n"
"74812\n"
".2881\n"
"15486\n"
".2883\n"
"7285.\n"
"31861\n"
"4576.\n") == 0);
free(board819425669);
board819425669 = NULL;


gamma_delete(board);

    return 0;
}
