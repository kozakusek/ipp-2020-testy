#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 109579832
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 11, 4, 53);
assert( board != NULL );


assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 2, 13, 8) == 1 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_free_fields(board, 2) == 184 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 4, 14, 2) == 1 );
assert( gamma_move(board, 1, 9, 0) == 1 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_golden_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 1, 2, 8) == 1 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 3 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 1, 2, 1) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_move(board, 4, 10, 0) == 1 );
assert( gamma_free_fields(board, 1) == 168 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 3, 9, 4) == 1 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 9, 6) == 1 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 2, 6, 9) == 1 );


char* board869155445 = gamma_board(board);
assert( board869155445 != NULL );
assert( strcmp(board869155445, 
".................\n"
"..1..42..4.......\n"
"..1..........2...\n"
".2.....2.........\n"
"...3.....1.2.....\n"
".......3.........\n"
".........3.......\n"
"....2....1.......\n"
"..2........3..4..\n"
"..1.1..3.........\n"
"2.4...4..14......\n") == 0);
free(board869155445);
board869155445 = NULL;
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_free_fields(board, 4) == 159 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 16, 7) == 1 );
assert( gamma_move(board, 1, 15, 7) == 1 );
assert( gamma_move(board, 2, 5, 3) == 1 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 4, 3, 10) == 1 );
assert( gamma_golden_move(board, 4, 7, 15) == 0 );
assert( gamma_move(board, 1, 14, 0) == 1 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_golden_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 8, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 14, 7) == 1 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 1, 12, 10) == 1 );
assert( gamma_golden_move(board, 1, 9, 3) == 0 );


char* board204989223 = gamma_board(board);
assert( board204989223 != NULL );
assert( strcmp(board204989223, 
"...4..213..41....\n"
"..12.42..43......\n"
".213.........2...\n"
".2.....2......411\n"
"...3.....1.2.....\n"
".......3..3......\n"
"3........3.......\n"
"....22...1.......\n"
"..2........3..4..\n"
"..1.1..3.........\n"
"2.4...4..14...1..\n") == 0);
free(board204989223);
board204989223 = NULL;
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 2, 16, 4) == 1 );
assert( gamma_free_fields(board, 2) == 143 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 14, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 3, 14, 4) == 1 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 1, 3, 0) == 1 );


char* board696788301 = gamma_board(board);
assert( board696788301 != NULL );
assert( strcmp(board696788301, 
"...4..213..41....\n"
"..12.42..43......\n"
".213.........2...\n"
".2.....2......411\n"
"...3.....1.2.....\n"
"..4....3..3......\n"
"3........3....3.2\n"
"....22...1.......\n"
"..2.3......3..4..\n"
"..1.1..3......3..\n"
"2.41..4..14...1..\n") == 0);
free(board696788301);
board696788301 = NULL;
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 3, 2, 15) == 0 );


char* board202699261 = gamma_board(board);
assert( board202699261 != NULL );
assert( strcmp(board202699261, 
"...4..213..41....\n"
"..12.42..43......\n"
".213.........2...\n"
".2.....2......411\n"
"...3.....1.2.....\n"
"..4....3..3......\n"
"3........3....3.2\n"
"....22...1.......\n"
"..2.3......3..4..\n"
"..1.12.3......3..\n"
"2.41..4..14...1..\n") == 0);
free(board202699261);
board202699261 = NULL;
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 4, 12, 1) == 1 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 1, 15, 3) == 1 );
assert( gamma_move(board, 1, 11, 7) == 1 );


char* board448996199 = gamma_board(board);
assert( board448996199 != NULL );
assert( strcmp(board448996199, 
"...4..213..41....\n"
"..12.42..43......\n"
".213.........2...\n"
".2.....2...1..411\n"
"...3.....1.2.....\n"
"..4....3..3......\n"
"3.......23....3.2\n"
"....22...1.....1.\n"
"..2.3......3..4..\n"
"..1.12.3....4.3..\n"
"2.41..4..14...1..\n") == 0);
free(board448996199);
board448996199 = NULL;
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_golden_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_move(board, 4, 11, 8) == 1 );
assert( gamma_move(board, 4, 9, 2) == 1 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 1, 10) == 1 );
assert( gamma_free_fields(board, 3) == 127 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_golden_move(board, 1, 2, 9) == 0 );


char* board551513740 = gamma_board(board);
assert( board551513740 != NULL );
assert( strcmp(board551513740, 
".3.4..213..41....\n"
"..12.421.23......\n"
".213......44.2...\n"
".2.....2...1..411\n"
"...3.....1.2.....\n"
"1.4....3..3......\n"
"3.....3.23....3.2\n"
"....22...1.....1.\n"
"..2.3....4.3..4..\n"
"..1.12.3....4.3..\n"
"2.41..42.14...1..\n") == 0);
free(board551513740);
board551513740 = NULL;
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );


char* board696231748 = gamma_board(board);
assert( board696231748 != NULL );
assert( strcmp(board696231748, 
".3.4..213..41....\n"
"..12.421.23......\n"
".213......44.2...\n"
".2.....2...1..411\n"
"...3.....1.2.....\n"
"1.4....3..3......\n"
"3.....3.23....3.2\n"
"....22...1.....1.\n"
"..2.3....4.3..4..\n"
"..1.12.3....4.3..\n"
"2.41..42.14...1..\n") == 0);
free(board696231748);
board696231748 = NULL;
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 6, 8) == 1 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );


char* board834338290 = gamma_board(board);
assert( board834338290 != NULL );
assert( strcmp(board834338290, 
".3.4..213..41....\n"
"..12.421.23......\n"
".213..3...44.2...\n"
".2.....2...1..411\n"
"...3.....1.2.....\n"
"1.4....3..3......\n"
"3.....3.23....3.2\n"
"...222...1.....1.\n"
"..2.3....4.3..4..\n"
"..1.12.3....4.3..\n"
"2.41..42.14...1..\n") == 0);
free(board834338290);
board834338290 = NULL;
assert( gamma_golden_move(board, 2, 6, 9) == 0 );


char* board642261046 = gamma_board(board);
assert( board642261046 != NULL );
assert( strcmp(board642261046, 
".3.4..213..41....\n"
"..12.421.23......\n"
".213..3...44.2...\n"
".2.....2...1..411\n"
"...3.....1.2.....\n"
"1.4....3..3......\n"
"3.....3.23....3.2\n"
"...222...1.....1.\n"
"..2.3....4.3..4..\n"
"..1.12.3....4.3..\n"
"2.41..42.14...1..\n") == 0);
free(board642261046);
board642261046 = NULL;
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 1, 11, 4) == 1 );
assert( gamma_free_fields(board, 1) == 122 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_move(board, 2, 3, 7) == 1 );
assert( gamma_move(board, 3, 6, 16) == 0 );
assert( gamma_move(board, 4, 1, 0) == 1 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 1, 12, 9) == 1 );
assert( gamma_move(board, 2, 7, 6) == 1 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_golden_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 13, 2) == 1 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 15, 2) == 1 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_free_fields(board, 4) == 114 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 9, 7) == 1 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_move(board, 3, 12, 0) == 1 );


char* board596700158 = gamma_board(board);
assert( board596700158 != NULL );
assert( strcmp(board596700158, 
".3.44.213..41....\n"
"..12.421.23.12...\n"
".213..3...44.2...\n"
".2.2...2.2.1..411\n"
"...3...2.1.2.....\n"
"1.4....3..3......\n"
"3.....3.23.1..3.2\n"
"...222...1.....1.\n"
"..2.3..2.4.3.243.\n"
"..1.12.3....4.3..\n"
"2441..42.14.3.1..\n") == 0);
free(board596700158);
board596700158 = NULL;
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_free_fields(board, 4) == 111 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_golden_move(board, 1, 1, 14) == 0 );


char* board162613230 = gamma_board(board);
assert( board162613230 != NULL );
assert( strcmp(board162613230, 
".3.44.213..41....\n"
"..12.421.23.12...\n"
".213..3...44.2...\n"
".2.2...2.2.1..411\n"
"...3...2.1.2.....\n"
"1.4....3..3......\n"
"3.....3.23.1..3.2\n"
"...222...1.....1.\n"
"..2.3..2.4.3.243.\n"
"..1.12.3....4.3..\n"
"2441..42.14.3.1..\n") == 0);
free(board162613230);
board162613230 = NULL;
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 4, 14, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_move(board, 1, 16, 2) == 1 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 4, 3, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );


char* board174108332 = gamma_board(board);
assert( board174108332 != NULL );
assert( strcmp(board174108332, 
".3.44.213..41....\n"
"..12.421.23.12...\n"
".213..3.3.44.2...\n"
".2.2...2.2.1..411\n"
"...3...2.1.2.....\n"
"1.44...3..3......\n"
"3...4.3.23.1..3.2\n"
".3.222..11.....1.\n"
"..2.3..2.4.3.2431\n"
"..1.12.3....4.3..\n"
"2441..42.1413.1..\n") == 0);
free(board174108332);
board174108332 = NULL;
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 4, 16) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_free_fields(board, 1) == 99 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 6, 14) == 0 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_move(board, 3, 3, 6) == 0 );


char* board585936311 = gamma_board(board);
assert( board585936311 != NULL );
assert( strcmp(board585936311, 
".3.44.213..41....\n"
"..12.421.23.12...\n"
"2213..3.3.44.2...\n"
".2.2...2.2.1..411\n"
"...33..241.2.....\n"
"1.44..432.3.3....\n"
"3...4.3.23.1..3.2\n"
".3.222..11.....1.\n"
"..2.3..2.4.3.2431\n"
"..1312.3....4.3..\n"
"2441..42.1413.1..\n") == 0);
free(board585936311);
board585936311 = NULL;
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 1, 10, 10) == 1 );
assert( gamma_free_fields(board, 1) == 94 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 0, 3) == 1 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 8, 9) == 1 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 7, 8) == 1 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 3, 14, 10) == 1 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_move(board, 1, 1, 6) == 1 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_free_fields(board, 1) == 87 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 3, 16, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_free_fields(board, 1) == 86 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 2, 5, 6) == 1 );


char* board196946998 = gamma_board(board);
assert( board196946998 != NULL );
assert( strcmp(board196946998, 
".3.44.213.141.3..\n"
"..12.421123.12...\n"
"2213..323.44.2...\n"
"42.2...2.2.1..411\n"
".1.332.241.2.....\n"
"1444..432.3.3....\n"
"3...4.3.23.1..3.2\n"
"23.2224.11.....1.\n"
"..2.3.42.4.3.2431\n"
"..1312.3....4.3..\n"
"24413.42.1413.1..\n") == 0);
free(board196946998);
board196946998 = NULL;
assert( gamma_move(board, 3, 4, 15) == 0 );
assert( gamma_move(board, 3, 15, 6) == 1 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 3, 11, 3) == 1 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 2, 15, 5) == 1 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 10, 4) == 1 );
assert( gamma_move(board, 4, 9, 1) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 8, 15) == 0 );
assert( gamma_move(board, 2, 15, 1) == 1 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 4, 12, 8) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_free_fields(board, 1) == 76 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_free_fields(board, 1) == 75 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 12, 2) == 1 );
assert( gamma_free_fields(board, 1) == 74 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 13, 0) == 1 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 4, 4, 0) == 0 );


char* board880750346 = gamma_board(board);
assert( board880750346 != NULL );
assert( strcmp(board880750346, 
".3.44.213.141.3..\n"
"..12.421123.12...\n"
"2213..323.4442...\n"
"42.21..2.2.1..411\n"
".11332.241.2...3.\n"
"1444..432.3.3..2.\n"
"3...4.3.2341..3.2\n"
"2342224.11.33..1.\n"
"..2.3.42.4.312431\n"
"..1312.314..4.32.\n"
"24413.42.141321..\n") == 0);
free(board880750346);
board880750346 = NULL;
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_free_fields(board, 4) == 71 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_free_fields(board, 3) == 71 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 5, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 16) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 1, 5, 10) == 1 );


char* board647188101 = gamma_board(board);
assert( board647188101 != NULL );
assert( strcmp(board647188101, 
".3.441213.141.3..\n"
"..12.421123.12...\n"
"2213..323.4442...\n"
"42.21..2.2.1..411\n"
".11332.241.2...3.\n"
"1444..432.3.3..2.\n"
"3...443.2341..3.2\n"
"2342224.11.33..1.\n"
"..2.3.42.4.312431\n"
"..1312.314..4.32.\n"
"24413.42.141321..\n") == 0);
free(board647188101);
board647188101 = NULL;
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 15, 10) == 1 );
assert( gamma_free_fields(board, 3) == 68 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_free_fields(board, 4) == 68 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 9, 16) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 8, 16) == 0 );
assert( gamma_move(board, 4, 16, 8) == 1 );


char* board613193691 = gamma_board(board);
assert( board613193691 != NULL );
assert( strcmp(board613193691, 
".3.441213.141.33.\n"
"..12.421123.12...\n"
"2213..323.4442..4\n"
"42.21..2.2.1..411\n"
".11332.241.2...3.\n"
"1444..432.3.3..2.\n"
"3...443.2341..3.2\n"
"2342224.11.33..1.\n"
"..2.3.42.4.312431\n"
".31312.314..4.32.\n"
"24413.42.141321..\n") == 0);
free(board613193691);
board613193691 = NULL;
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 30 );
assert( gamma_golden_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 2, 11, 9) == 1 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_move(board, 4, 0, 15) == 0 );


char* board853008562 = gamma_board(board);
assert( board853008562 != NULL );
assert( strcmp(board853008562, 
".3.441213.141.33.\n"
"..12.421123212...\n"
"2213..323.4442..4\n"
"42321..2.2.1..411\n"
".11332.241.2...3.\n"
"1444..432.3.3..2.\n"
"3...443.2341..3.2\n"
"2342224.11.33..1.\n"
"..2.3.42.4.312431\n"
".31312.314..4.32.\n"
"24413.42.141321..\n") == 0);
free(board853008562);
board853008562 = NULL;
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_free_fields(board, 2) == 64 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_golden_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_free_fields(board, 3) == 62 );
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 1, 2, 4) == 1 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 2, 16, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 36 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 4, 16, 1) == 1 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 2, 15, 8) == 1 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 32 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_free_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 38 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_free_fields(board, 4) == 55 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 4, 14, 9) == 1 );
assert( gamma_move(board, 1, 2, 0) == 0 );


char* board233585994 = gamma_board(board);
assert( board233585994 != NULL );
assert( strcmp(board233585994, 
".3.441213.141.332\n"
".21224211232124..\n"
"22133.323.4442.24\n"
"42321..222.1..411\n"
".11332.241.2...3.\n"
"1444..432.3.3..2.\n"
"3.14443.2341..3.2\n"
"2342224311.33..1.\n"
"..2.3.42.42312431\n"
".31312.314..4.324\n"
"24413.42.141321..\n") == 0);
free(board233585994);
board233585994 = NULL;
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 14, 5) == 1 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_free_fields(board, 1) == 50 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 40 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_free_fields(board, 4) == 50 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 2, 16, 0) == 1 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 4, 13, 1) == 1 );
assert( gamma_golden_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_free_fields(board, 1) == 45 );
assert( gamma_golden_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_free_fields(board, 3) == 45 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_free_fields(board, 2) == 45 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 0, 6) == 1 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_golden_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 4, 4, 10) == 0 );
assert( gamma_move(board, 4, 16, 6) == 1 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 4, 5) == 1 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board360327211 = gamma_board(board);
assert( board360327211 != NULL );
assert( strcmp(board360327211, 
".3.441213.141.332\n"
"121324211232124..\n"
"22133.323.4442.24\n"
"42321..22241..411\n"
"4113323241.2...34\n"
"14441.432.3.3.42.\n"
"3.14443.23411.3.2\n"
"2342224311.33..1.\n"
"..223.42.42312431\n"
".31312.314..44324\n"
"24413.42.141321.2\n") == 0);
free(board360327211);
board360327211 = NULL;
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 7, 7) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_golden_move(board, 1, 5, 6) == 1 );
assert( gamma_move(board, 3, 13, 10) == 1 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );


char* board957451882 = gamma_board(board);
assert( board957451882 != NULL );
assert( strcmp(board957451882, 
".3.441213.1413332\n"
"121324211232124..\n"
"22133.323.4442.24\n"
"42321..22241..411\n"
"4113313241.2...34\n"
"14441.432.3.3.42.\n"
"3.14443.23411.3.2\n"
"2342224311.33..1.\n"
"..223.42.42312431\n"
".31312.314..44324\n"
"24413242.141321.2\n") == 0);
free(board957451882);
board957451882 = NULL;
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_free_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 5, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 4, 5, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 16, 9) == 1 );
assert( gamma_move(board, 1, 16, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_golden_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );


char* board493548768 = gamma_board(board);
assert( board493548768 != NULL );
assert( strcmp(board493548768, 
".3.441213.1413332\n"
"121324211232124.1\n"
"22133.323.4442.24\n"
"42321..22241..411\n"
"4113313241.2...34\n"
"14441.432.3.3.42.\n"
"3114443.23411.3.2\n"
"2342224311.33..1.\n"
"..223.42.42312431\n"
".31312.314..44324\n"
"244132422141321.2\n") == 0);
free(board493548768);
board493548768 = NULL;
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 4, 14, 6) == 1 );
assert( gamma_busy_fields(board, 4) == 38 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_free_fields(board, 1) == 35 );
assert( gamma_free_fields(board, 2) == 35 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 4, 14, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_golden_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_free_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 39 );


char* board945090137 = gamma_board(board);
assert( board945090137 != NULL );
assert( strcmp(board945090137, 
".3.441213.1413332\n"
"121324211232124.1\n"
"22133.323.4442.24\n"
"42321..22241..411\n"
"4113313241.2..434\n"
"144414432.3.3.42.\n"
"3114443.23411.3.2\n"
"2342224311.33..1.\n"
"..223.42.42312431\n"
".31312.314..44324\n"
"244132422141321.2\n") == 0);
free(board945090137);
board945090137 = NULL;
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 2, 13, 6) == 1 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_golden_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_free_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 10, 6) == 1 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 3, 4, 15) == 0 );


char* board706742091 = gamma_board(board);
assert( board706742091 != NULL );
assert( strcmp(board706742091, 
".3.441213.1413332\n"
"121324211232124.1\n"
"22133.323.4442.24\n"
"42321..22241..411\n"
"411331324142.2434\n"
"144414432.3.3.42.\n"
"3114443.23411.3.2\n"
"2342224311.33..1.\n"
"..223.42.42312431\n"
".31312.314..44324\n"
"244132422141321.2\n") == 0);
free(board706742091);
board706742091 = NULL;
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 6, 10) == 0 );
assert( gamma_free_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_free_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 13, 4) == 1 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_free_fields(board, 3) == 31 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 4, 13, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 40 );
assert( gamma_golden_move(board, 4, 1, 15) == 0 );


char* board666857318 = gamma_board(board);
assert( board666857318 != NULL );
assert( strcmp(board666857318, 
".3.441213.1413332\n"
"121324211232124.1\n"
"22133.323.4442.24\n"
"42321..22241..411\n"
"411331324142.2434\n"
"144414432.3.3.42.\n"
"3114443.2341113.2\n"
"2342224311.33..1.\n"
"..223.42.42312431\n"
".31312.314..44324\n"
"244132422141321.2\n") == 0);
free(board666857318);
board666857318 = NULL;
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 15, 0) == 1 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_free_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 4, 14, 3) == 1 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 15) == 0 );
assert( gamma_golden_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_free_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );


gamma_delete(board);

    return 0;
}
