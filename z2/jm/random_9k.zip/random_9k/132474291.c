#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 132474291
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 15, 4, 59);
assert( board != NULL );


assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 1, 11, 3) == 1 );
assert( gamma_move(board, 2, 5, 13) == 1 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_free_fields(board, 3) == 205 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_move(board, 4, 7, 12) == 1 );
assert( gamma_move(board, 4, 10, 10) == 1 );


char* board631318740 = gamma_board(board);
assert( board631318740 != NULL );
assert( strcmp(board631318740, 
"..............\n"
".....2....2...\n"
".......4......\n"
"..............\n"
"..........4...\n"
"..3....1......\n"
"..............\n"
"..............\n"
"...3....4.....\n"
"..............\n"
"..............\n"
"....1......1..\n"
".........3....\n"
"........3.....\n"
"..............\n") == 0);
free(board631318740);
board631318740 = NULL;
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 4 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_move(board, 4, 8, 10) == 1 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_free_fields(board, 1) == 190 );
assert( gamma_move(board, 3, 13, 4) == 1 );
assert( gamma_move(board, 3, 11, 11) == 1 );
assert( gamma_move(board, 4, 13, 9) == 1 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 12) == 0 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 1, 13, 2) == 1 );
assert( gamma_move(board, 1, 11, 11) == 0 );
assert( gamma_move(board, 2, 10, 9) == 1 );
assert( gamma_move(board, 2, 3, 0) == 1 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_move(board, 1, 11, 9) == 1 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_free_fields(board, 2) == 178 );
assert( gamma_move(board, 3, 11, 6) == 1 );


char* board135559556 = gamma_board(board);
assert( board135559556 != NULL );
assert( strcmp(board135559556, 
"..............\n"
"...1.2....2...\n"
".......42.....\n"
"...4....4..3..\n"
"....1...4.4...\n"
"..3....1..21.4\n"
".....3........\n"
"..............\n"
"..13....4.23..\n"
".........2....\n"
".............3\n"
"...41......1..\n"
".........3.3.1\n"
"........3.....\n"
"...2...1......\n") == 0);
free(board135559556);
board135559556 = NULL;
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 1, 13, 3) == 1 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 4, 4, 11) == 1 );
assert( gamma_golden_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 2, 7, 10) == 1 );
assert( gamma_move(board, 3, 10, 11) == 1 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_move(board, 4, 10, 12) == 1 );
assert( gamma_move(board, 1, 0, 9) == 1 );


char* board801840543 = gamma_board(board);
assert( board801840543 != NULL );
assert( strcmp(board801840543, 
"..............\n"
"...1.2....2...\n"
".......42.4...\n"
"...44...4.33..\n"
"....1..24.4...\n"
"1.3....12.21.4\n"
".....3........\n"
"...........3..\n"
"..13..1.4.23..\n"
".........2....\n"
".............3\n"
"...41....1.1.1\n"
".........3.3.1\n"
"........3.....\n"
"...2...12.....\n") == 0);
free(board801840543);
board801840543 = NULL;
assert( gamma_move(board, 2, 13, 12) == 1 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_golden_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 2, 9, 10) == 1 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 12, 10) == 1 );
assert( gamma_free_fields(board, 3) == 157 );
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_free_fields(board, 4) == 155 );
assert( gamma_move(board, 1, 13, 1) == 1 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_free_fields(board, 2) == 154 );


char* board784252495 = gamma_board(board);
assert( board784252495 != NULL );
assert( strcmp(board784252495, 
"..............\n"
"...1.2....2...\n"
".......42.4..2\n"
"...44...4.33..\n"
"....13.2424.3.\n"
"1.3....12.21.4\n"
".....3....4...\n"
".1..32.....3..\n"
"..13..1.4.23..\n"
".........2....\n"
"24...........3\n"
"...41....1.1.1\n"
".........3.3.1\n"
"....4...3....1\n"
"...2...12.....\n") == 0);
free(board784252495);
board784252495 = NULL;
assert( gamma_move(board, 3, 12, 0) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_free_fields(board, 3) == 152 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_free_fields(board, 4) == 151 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_free_fields(board, 1) == 151 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 11, 11) == 0 );
assert( gamma_move(board, 3, 11, 5) == 1 );
assert( gamma_move(board, 4, 5, 13) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 6, 11) == 1 );
assert( gamma_move(board, 2, 3, 7) == 1 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_free_fields(board, 3) == 147 );
assert( gamma_move(board, 4, 3, 1) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 0, 6) == 1 );
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 4, 11, 1) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 9, 12) == 1 );


char* board984506221 = gamma_board(board);
assert( board984506221 != NULL );
assert( strcmp(board984506221, 
"..............\n"
"...1.2....2...\n"
".......4224..2\n"
"...44.1.4.332.\n"
"....13.2424.3.\n"
"1.3....12.21.4\n"
".....3..4.4...\n"
"11.232.....3..\n"
"3.13..114.23..\n"
".........233..\n"
"24...........3\n"
"...41....1.1.1\n"
"..3......3.3.1\n"
"...44...3.44.1\n"
"...2...12.2.3.\n") == 0);
free(board984506221);
board984506221 = NULL;
assert( gamma_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 1, 11, 13) == 1 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_golden_move(board, 3, 3, 13) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 4, 8, 13) == 1 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 4, 13, 5) == 1 );
assert( gamma_free_fields(board, 4) == 125 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 6) == 1 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 0) == 0 );


char* board766667731 = gamma_board(board);
assert( board766667731 != NULL );
assert( strcmp(board766667731, 
".............1\n"
"...3.2..4.21.1\n"
"...2...4224..2\n"
".4.44.1.4.332.\n"
"....13.2424.3.\n"
"1.3....12.21.4\n"
".....3..4.4...\n"
"11.232.....3..\n"
"3213..114.23..\n"
"........1233.4\n"
"24...........3\n"
"...41.4..1.1.1\n"
"..32...1.3.3.1\n"
".2.44...3344.1\n"
"...2...1222.3.\n") == 0);
free(board766667731);
board766667731 = NULL;
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 4, 6, 1) == 1 );
assert( gamma_move(board, 1, 10, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 3, 13, 0) == 1 );
assert( gamma_free_fields(board, 3) == 120 );
assert( gamma_golden_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 1, 13, 7) == 1 );
assert( gamma_free_fields(board, 1) == 118 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_free_fields(board, 3) == 117 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 4) == 1 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_free_fields(board, 1) == 112 );


char* board435263086 = gamma_board(board);
assert( board435263086 != NULL );
assert( strcmp(board435263086, 
".............1\n"
"...3.2..4.21.1\n"
"...2...4224..2\n"
".4.44.1.4.332.\n"
"....13.2424.3.\n"
"1.3....12.21.4\n"
"...343..4.4...\n"
"11.2323....3.1\n"
"3213..114323..\n"
".....2..1233.4\n"
"24..........23\n"
"1..41.4..1.1.1\n"
"..32...1.313.1\n"
".2.44.4.3344.1\n"
"...2...1222.33\n") == 0);
free(board435263086);
board435263086 = NULL;
assert( gamma_move(board, 3, 3, 10) == 1 );


char* board508508157 = gamma_board(board);
assert( board508508157 != NULL );
assert( strcmp(board508508157, 
".............1\n"
"...3.2..4.21.1\n"
"...2...4224..2\n"
".4.44.1.4.332.\n"
"...313.2424.3.\n"
"1.3....12.21.4\n"
"...343..4.4...\n"
"11.2323....3.1\n"
"3213..114323..\n"
".....2..1233.4\n"
"24..........23\n"
"1..41.4..1.1.1\n"
"..32...1.313.1\n"
".2.44.4.3344.1\n"
"...2...1222.33\n") == 0);
free(board508508157);
board508508157 = NULL;
assert( gamma_move(board, 4, 5, 12) == 1 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 1, 4, 10) == 0 );


char* board831858309 = gamma_board(board);
assert( board831858309 != NULL );
assert( strcmp(board831858309, 
".............1\n"
"...3.2..4.21.1\n"
"...2.4.4224..2\n"
".4.44.1.4.332.\n"
"...313.2424.3.\n"
"1.3....12.21.4\n"
"...343..4.4...\n"
"11.2323....3.1\n"
"3213..114323..\n"
".....2..1233.4\n"
"24..........23\n"
"1..41.4..1.1.1\n"
"..32...1.313.1\n"
".2.44.4.3344.1\n"
"...2...1222.33\n") == 0);
free(board831858309);
board831858309 = NULL;
assert( gamma_move(board, 3, 4, 13) == 1 );
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_free_fields(board, 1) == 107 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 3, 11, 11) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 4, 13, 14) == 0 );
assert( gamma_golden_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );


char* board850704572 = gamma_board(board);
assert( board850704572 != NULL );
assert( strcmp(board850704572, 
"..3..........1\n"
"...332..4.21.1\n"
".1.2.4.4224..2\n"
".4.44.1.4.332.\n"
"...313.2424.3.\n"
"1.3....12.21.4\n"
"...343..4.43..\n"
"11.2323....3.1\n"
"3213..114323..\n"
".....2..1233.4\n"
"24....1.....23\n"
"1..41.4..1.1.1\n"
"..32...1.313.1\n"
".2.44.4.3344.1\n"
".212...1222.33\n") == 0);
free(board850704572);
board850704572 = NULL;
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_golden_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_free_fields(board, 2) == 103 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 8, 2) == 1 );


char* board640064732 = gamma_board(board);
assert( board640064732 != NULL );
assert( strcmp(board640064732, 
"..3..........1\n"
"...332..4.21.1\n"
".1.2.4.42243.2\n"
".4.44.1.4.332.\n"
"...313.2424.3.\n"
"1.3....12.21.4\n"
"...343..4.43..\n"
"11.2323....3.1\n"
"3213..114323..\n"
".....2..1233.4\n"
"24....1.....23\n"
"1..41.4..1.1.1\n"
"..32...14313.1\n"
".2.44.4.3344.1\n"
".212...1222.33\n") == 0);
free(board640064732);
board640064732 = NULL;
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board942892302 = gamma_board(board);
assert( board942892302 != NULL );
assert( strcmp(board942892302, 
"..3..........1\n"
"...332..4.21.1\n"
".1.2.4.42243.2\n"
".4.44.1.4.332.\n"
"...313.2424.3.\n"
"1.3....12.21.4\n"
"...343..4.43..\n"
"11.2323..1.3.1\n"
"3213..114323..\n"
".....2..1233.4\n"
"24....1.....23\n"
"1..41.4..1.1.1\n"
"..32...14313.1\n"
".2.44.4.3344.1\n"
".212...1222.33\n") == 0);
free(board942892302);
board942892302 = NULL;
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 4, 13, 8) == 1 );
assert( gamma_move(board, 1, 5, 6) == 1 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 4, 4, 6) == 1 );
assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_free_fields(board, 1) == 94 );


char* board556904073 = gamma_board(board);
assert( board556904073 != NULL );
assert( strcmp(board556904073, 
"..3..........1\n"
"...332..4.21.1\n"
".1.2.4.42243.2\n"
".4.44.1.4.332.\n"
"...313.2424.3.\n"
"1.3....12.21.4\n"
"...343..4.43.4\n"
"11.2323..1.3.1\n"
"321341114323..\n"
"3....2..1233.4\n"
"24....1.....23\n"
"1..4144..1.1.1\n"
".132...14313.1\n"
".2.44.4.3344.1\n"
".212...1222.33\n") == 0);
free(board556904073);
board556904073 = NULL;
assert( gamma_move(board, 2, 9, 12) == 0 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_free_fields(board, 2) == 93 );
assert( gamma_golden_move(board, 2, 3, 13) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 13, 11) == 1 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 1, 12, 6) == 1 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_golden_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_free_fields(board, 2) == 86 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_golden_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_golden_move(board, 4, 9, 10) == 1 );


char* board160543974 = gamma_board(board);
assert( board160543974 != NULL );
assert( strcmp(board160543974, 
"..33.......3.1\n"
"...232..4.21.1\n"
".1.224342243.2\n"
".4.44.1.4.3323\n"
".4.313.2444.3.\n"
"1.3....12.21.4\n"
"...343..4.43.4\n"
"11.2323..1.3.1\n"
"3213411143231.\n"
"3..2.24.1233.4\n"
"24....1.....23\n"
"1..41442.1.1.1\n"
".132...1431331\n"
".2344.4.3344.1\n"
".212...1222.33\n") == 0);
free(board160543974);
board160543974 = NULL;
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 6, 13) == 1 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 9, 4) == 1 );
assert( gamma_move(board, 4, 12, 3) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 9, 13) == 1 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_free_fields(board, 4) == 74 );
assert( gamma_move(board, 1, 5, 7) == 0 );


char* board642031358 = gamma_board(board);
assert( board642031358 != NULL );
assert( strcmp(board642031358, 
"..33.......3.1\n"
"...2323.4121.1\n"
"21.224342243.2\n"
".4.44.1.4.3323\n"
".4.313.2444.3.\n"
"1.3....12221.4\n"
"...343..4.43.4\n"
"11.2323..1.3.1\n"
"3213411143231.\n"
"3.32.24.1233.4\n"
"24....1..3..23\n"
"1..41442.1.141\n"
".132..21431331\n"
".2344.4.3344.1\n"
".212...1222.33\n") == 0);
free(board642031358);
board642031358 = NULL;
assert( gamma_move(board, 2, 7, 11) == 1 );
assert( gamma_free_fields(board, 2) == 73 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 4, 0) == 1 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_free_fields(board, 3) == 70 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_free_fields(board, 4) == 70 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_golden_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_free_fields(board, 3) == 68 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 41 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_move(board, 4, 2, 4) == 1 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_free_fields(board, 1) == 63 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 35 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 35 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_golden_move(board, 1, 12, 6) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 7, 7) == 1 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 8) == 1 );
assert( gamma_free_fields(board, 3) == 60 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_free_fields(board, 4) == 60 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_free_fields(board, 1) == 60 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_golden_move(board, 2, 3, 13) == 0 );
assert( gamma_free_fields(board, 3) == 60 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_move(board, 1, 12, 8) == 1 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 13, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 13, 10) == 1 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_free_fields(board, 3) == 56 );
assert( gamma_golden_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 1, 12, 1) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );


char* board976177918 = gamma_board(board);
assert( board976177918 != NULL );
assert( strcmp(board976177918, 
"1.33..3....3.1\n"
"1.32323.4121.1\n"
"21.22434224312\n"
"24.44.124.3323\n"
".4.313.2444432\n"
"1.3....12221.4\n"
"..4343..424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3.32424.1233.4\n"
"244..21..3..23\n"
"1..41442.1.141\n"
".132..21431331\n"
".2344.4.334411\n"
"12121..1222.33\n") == 0);
free(board976177918);
board976177918 = NULL;
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_free_fields(board, 4) == 54 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_golden_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 12, 9) == 1 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_free_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 7, 13) == 1 );
assert( gamma_golden_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_golden_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_free_fields(board, 1) == 50 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 7, 8) == 1 );
assert( gamma_move(board, 4, 3, 6) == 0 );


char* board142946547 = gamma_board(board);
assert( board142946547 != NULL );
assert( strcmp(board142946547, 
"1.33..33...3.1\n"
"1.3232314121.1\n"
"21.22434224312\n"
"24.44.124.3323\n"
".4.313.2444432\n"
"1.3....1222134\n"
"..4343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3.32424.1233.4\n"
"244..21..32.23\n"
"1..41442.11141\n"
".132..21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board142946547);
board142946547 = NULL;
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_golden_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 38 );
assert( gamma_move(board, 3, 12, 14) == 1 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );


char* board243564406 = gamma_board(board);
assert( board243564406 != NULL );
assert( strcmp(board243564406, 
"1.333.33...331\n"
"1.3232314121.1\n"
"21.22434224312\n"
"24.44.124.3323\n"
".4.313.2444432\n"
"1.3....1222134\n"
"..4343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3.32424.1233.4\n"
"244..21..32.23\n"
"1..41442.11141\n"
".132..21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board243564406);
board243564406 = NULL;
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 4, 4) == 1 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_golden_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_golden_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 13, 14) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_free_fields(board, 3) == 40 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 13, 12) == 0 );


char* board192294510 = gamma_board(board);
assert( board192294510 != NULL );
assert( strcmp(board192294510, 
"1.333.33...331\n"
"1.3232314121.1\n"
"21.22434224312\n"
"24444.124.3323\n"
".4.313.2444432\n"
"143...41222134\n"
"..4343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3.32424.1233.4\n"
"244.221..32.23\n"
"1..41442.11141\n"
".132..21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board192294510);
board192294510 = NULL;
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_free_fields(board, 2) == 40 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 40 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 40 );
assert( gamma_free_fields(board, 4) == 40 );
assert( gamma_golden_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 1, 12, 13) == 1 );
assert( gamma_free_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_golden_move(board, 4, 6, 11) == 0 );
assert( gamma_free_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 5, 7) == 0 );


char* board744353959 = gamma_board(board);
assert( board744353959 != NULL );
assert( strcmp(board744353959, 
"1.333.33...331\n"
"1.323231412111\n"
"21.22434224312\n"
"24444.124.3323\n"
".4.313.2444432\n"
"143...41222134\n"
"..4343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3.32424.1233.4\n"
"244.221..32.23\n"
"1..41442.11141\n"
".1322.21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board744353959);
board744353959 = NULL;
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 48 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 4, 10, 10) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 12, 8) == 0 );


char* board695533690 = gamma_board(board);
assert( board695533690 != NULL );
assert( strcmp(board695533690, 
"1.333.33...331\n"
"1.323231412111\n"
"21.22434224312\n"
"24444.124.3323\n"
".4.313.2444432\n"
"143...41222134\n"
"..4343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3.32424.1233.4\n"
"244.221..32.23\n"
"1..41442.11141\n"
"21322.21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board695533690);
board695533690 = NULL;
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_free_fields(board, 4) == 37 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 1, 12, 12) == 0 );
assert( gamma_free_fields(board, 1) == 37 );
assert( gamma_golden_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 1, 12, 5) == 1 );
assert( gamma_free_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 40 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_free_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 4, 4, 9) == 1 );
assert( gamma_busy_fields(board, 4) == 41 );
assert( gamma_move(board, 1, 1, 8) == 1 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );


char* board643899854 = gamma_board(board);
assert( board643899854 != NULL );
assert( strcmp(board643899854, 
"1.333.33...331\n"
"1.323231412111\n"
"21.22434224312\n"
"24444.124.3323\n"
".4.313.2444432\n"
"143.4.41222134\n"
".14343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3.32424.123314\n"
"244.221..32.23\n"
"1.241442.11141\n"
"21322.21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board643899854);
board643899854 = NULL;
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 1, 12, 14) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 41 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 43 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_golden_move(board, 4, 10, 7) == 0 );


char* board961525914 = gamma_board(board);
assert( board961525914 != NULL );
assert( strcmp(board961525914, 
"1.333.33...331\n"
"1.323231412111\n"
"21.22434224312\n"
"24444.124.3323\n"
".43313.2444432\n"
"143.4.41222134\n"
".14343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3232424.123314\n"
"244.2213232.23\n"
"1.241442111141\n"
"21322.21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board961525914);
board961525914 = NULL;
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );


char* board123537461 = gamma_board(board);
assert( board123537461 != NULL );
assert( strcmp(board123537461, 
"1.333.33...331\n"
"1.323231412111\n"
"21.22434224312\n"
"24444.124.3323\n"
".43313.2444432\n"
"143.4.41222134\n"
".14343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3232424.123314\n"
"244.2213232.23\n"
"1.241442111141\n"
"21322.21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board123537461);
board123537461 = NULL;
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_golden_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 5) == 0 );


char* board144877740 = gamma_board(board);
assert( board144877740 != NULL );
assert( strcmp(board144877740, 
"1.333.33...331\n"
"1.323231412111\n"
"21.22434224312\n"
"24444.124.3323\n"
".43313.2444432\n"
"143.4.41222134\n"
".14343.3424314\n"
"11.2323431.3.1\n"
"3213411143231.\n"
"3232424.123314\n"
"244.2213232.23\n"
"1.241442111141\n"
"21322.21431331\n"
".234434.334411\n"
"12121..1222133\n") == 0);
free(board144877740);
board144877740 = NULL;
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 41 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_free_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_golden_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 1, 3, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_free_fields(board, 4) == 27 );
assert( gamma_move(board, 1, 5, 14) == 1 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 3, 13, 13) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );


gamma_delete(board);

    return 0;
}
