#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 147082222
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(2, 119, 6, 47);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 40) == 1 );
assert( gamma_move(board, 1, 1, 100) == 1 );
assert( gamma_move(board, 2, 109, 1) == 0 );
assert( gamma_move(board, 2, 1, 70) == 1 );
assert( gamma_move(board, 3, 0, 39) == 1 );
assert( gamma_move(board, 3, 1, 39) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 5, 17, 0) == 0 );
assert( gamma_move(board, 5, 0, 32) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 30, 1) == 0 );
assert( gamma_move(board, 6, 1, 112) == 1 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 1, 0, 92) == 1 );
assert( gamma_move(board, 2, 0, 17) == 1 );
assert( gamma_move(board, 2, 0, 102) == 1 );
assert( gamma_move(board, 3, 0, 79) == 1 );
assert( gamma_move(board, 4, 45, 1) == 0 );
assert( gamma_move(board, 4, 1, 99) == 1 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 5, 1, 71) == 1 );
assert( gamma_move(board, 6, 0, 6) == 1 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_move(board, 1, 0, 34) == 1 );
assert( gamma_move(board, 2, 47, 1) == 0 );
assert( gamma_move(board, 3, 94, 0) == 0 );
assert( gamma_move(board, 3, 1, 24) == 1 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_move(board, 4, 38, 1) == 0 );
assert( gamma_move(board, 4, 0, 63) == 1 );
assert( gamma_move(board, 6, 84, 1) == 0 );
assert( gamma_free_fields(board, 6) == 220 );
assert( gamma_move(board, 1, 1, 61) == 1 );
assert( gamma_move(board, 2, 0, 80) == 1 );
assert( gamma_busy_fields(board, 2) == 4 );
assert( gamma_move(board, 3, 104, 0) == 0 );


char* board839280546 = gamma_board(board);
assert( board839280546 != NULL );
assert( strcmp(board839280546, 
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
".1\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
".2\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"33\n"
"..\n"
"..\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"5.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n") == 0);
free(board839280546);
board839280546 = NULL;
assert( gamma_move(board, 4, 79, 1) == 0 );
assert( gamma_move(board, 4, 0, 85) == 1 );
assert( gamma_move(board, 5, 0, 101) == 1 );
assert( gamma_move(board, 5, 1, 58) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 6, 49, 0) == 0 );
assert( gamma_move(board, 6, 1, 67) == 1 );
assert( gamma_free_fields(board, 6) == 214 );
assert( gamma_golden_move(board, 6, 39, 1) == 0 );
assert( gamma_move(board, 1, 1, 97) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 118, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 117, 0) == 0 );
assert( gamma_move(board, 3, 0, 59) == 1 );
assert( gamma_move(board, 4, 0, 55) == 1 );
assert( gamma_move(board, 5, 1, 104) == 1 );
assert( gamma_move(board, 5, 0, 85) == 0 );
assert( gamma_move(board, 6, 66, 0) == 0 );
assert( gamma_move(board, 6, 1, 36) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 85, 1) == 0 );
assert( gamma_free_fields(board, 1) == 209 );
assert( gamma_golden_move(board, 1, 17, 0) == 0 );
assert( gamma_move(board, 2, 87, 1) == 0 );
assert( gamma_move(board, 2, 0, 85) == 0 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 3, 0, 79) == 0 );


char* board822526667 = gamma_board(board);
assert( board822526667 != NULL );
assert( strcmp(board822526667, 
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
"..\n"
"2.\n"
"5.\n"
".1\n"
".4\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
".2\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
".1\n"
"..\n"
"3.\n"
".5\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"33\n"
"..\n"
"..\n"
".6\n"
"..\n"
"1.\n"
"..\n"
"5.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n") == 0);
free(board822526667);
board822526667 = NULL;
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 0, 95) == 1 );
assert( gamma_move(board, 5, 1, 105) == 1 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_free_fields(board, 5) == 205 );
assert( gamma_move(board, 6, 41, 0) == 0 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 1, 0, 44) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 2, 1, 70) == 0 );
assert( gamma_busy_fields(board, 2) == 4 );
assert( gamma_move(board, 3, 69, 0) == 0 );
assert( gamma_move(board, 3, 0, 97) == 1 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_free_fields(board, 4) == 202 );
assert( gamma_move(board, 5, 69, 1) == 0 );
assert( gamma_move(board, 5, 1, 109) == 1 );
assert( gamma_move(board, 6, 49, 0) == 0 );
assert( gamma_move(board, 6, 1, 23) == 1 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 0, 67) == 1 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 4, 91, 1) == 0 );
assert( gamma_golden_move(board, 4, 67, 0) == 0 );
assert( gamma_move(board, 5, 37, 0) == 0 );
assert( gamma_move(board, 5, 1, 99) == 0 );
assert( gamma_busy_fields(board, 5) == 8 );
assert( gamma_free_fields(board, 5) == 198 );
assert( gamma_move(board, 6, 109, 0) == 0 );
assert( gamma_move(board, 6, 0, 52) == 1 );
assert( gamma_move(board, 1, 24, 0) == 0 );
assert( gamma_move(board, 1, 1, 70) == 0 );
assert( gamma_move(board, 2, 0, 16) == 1 );
assert( gamma_move(board, 2, 0, 26) == 1 );
assert( gamma_busy_fields(board, 2) == 6 );
assert( gamma_move(board, 3, 101, 1) == 0 );
assert( gamma_move(board, 4, 84, 0) == 0 );
assert( gamma_move(board, 4, 1, 80) == 1 );
assert( gamma_move(board, 5, 88, 1) == 0 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 79) == 0 );
assert( gamma_move(board, 2, 1, 25) == 1 );
assert( gamma_move(board, 3, 1, 45) == 1 );
assert( gamma_free_fields(board, 3) == 192 );
assert( gamma_move(board, 4, 19, 0) == 0 );
assert( gamma_move(board, 4, 0, 50) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 6, 31, 1) == 0 );
assert( gamma_move(board, 6, 0, 93) == 1 );
assert( gamma_move(board, 1, 23, 0) == 0 );
assert( gamma_move(board, 1, 1, 55) == 1 );
assert( gamma_move(board, 2, 34, 1) == 0 );
assert( gamma_move(board, 2, 0, 93) == 0 );
assert( gamma_move(board, 3, 1, 54) == 1 );
assert( gamma_move(board, 3, 1, 46) == 1 );
assert( gamma_move(board, 4, 48, 0) == 0 );
assert( gamma_move(board, 5, 77, 1) == 0 );
assert( gamma_move(board, 1, 1, 97) == 0 );
assert( gamma_move(board, 1, 1, 62) == 1 );
assert( gamma_move(board, 2, 74, 0) == 0 );
assert( gamma_move(board, 2, 1, 37) == 1 );
assert( gamma_move(board, 3, 1, 70) == 0 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_move(board, 4, 28, 0) == 0 );
assert( gamma_move(board, 4, 0, 44) == 0 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_free_fields(board, 5) == 184 );
assert( gamma_move(board, 6, 0, 37) == 1 );
assert( gamma_move(board, 1, 1, 56) == 1 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 86, 1) == 0 );
assert( gamma_free_fields(board, 2) == 181 );
assert( gamma_move(board, 3, 1, 80) == 0 );
assert( gamma_move(board, 3, 1, 42) == 1 );
assert( gamma_move(board, 4, 0, 31) == 1 );
assert( gamma_move(board, 4, 1, 49) == 1 );
assert( gamma_free_fields(board, 4) == 178 );
assert( gamma_move(board, 5, 48, 0) == 0 );
assert( gamma_move(board, 6, 89, 0) == 0 );
assert( gamma_free_fields(board, 6) == 178 );


char* board253896057 = gamma_board(board);
assert( board253896057 != NULL );
assert( strcmp(board253896057, 
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
".5\n"
"..\n"
"..\n"
"..\n"
".5\n"
".5\n"
"..\n"
"2.\n"
"5.\n"
".1\n"
".4\n"
"..\n"
"31\n"
"..\n"
"5.\n"
"..\n"
"6.\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"24\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
".2\n"
"..\n"
"..\n"
"16\n"
"..\n"
"..\n"
"..\n"
"4.\n"
".1\n"
".1\n"
"..\n"
"3.\n"
".5\n"
"..\n"
".1\n"
"41\n"
".3\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"..\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"33\n"
"..\n"
"62\n"
".6\n"
"..\n"
"1.\n"
"..\n"
"5.\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
".2\n"
".3\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
".3\n"
"..\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board253896057);
board253896057 = NULL;
assert( gamma_move(board, 1, 28, 1) == 0 );
assert( gamma_move(board, 1, 1, 108) == 1 );
assert( gamma_move(board, 2, 33, 1) == 0 );
assert( gamma_move(board, 3, 0, 118) == 1 );
assert( gamma_move(board, 3, 1, 106) == 1 );
assert( gamma_move(board, 4, 0, 54) == 1 );
assert( gamma_free_fields(board, 4) == 174 );


char* board653139678 = gamma_board(board);
assert( board653139678 != NULL );
assert( strcmp(board653139678, 
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
".5\n"
".1\n"
"..\n"
".3\n"
".5\n"
".5\n"
"..\n"
"2.\n"
"5.\n"
".1\n"
".4\n"
"..\n"
"31\n"
"..\n"
"5.\n"
"..\n"
"6.\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"24\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
".2\n"
"..\n"
"..\n"
"16\n"
"..\n"
"..\n"
"..\n"
"4.\n"
".1\n"
".1\n"
"..\n"
"3.\n"
".5\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"..\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"33\n"
"..\n"
"62\n"
".6\n"
"..\n"
"1.\n"
"..\n"
"5.\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
".2\n"
".3\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
".3\n"
"..\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board653139678);
board653139678 = NULL;
assert( gamma_move(board, 5, 94, 0) == 0 );
assert( gamma_move(board, 6, 24, 0) == 0 );
assert( gamma_move(board, 1, 0, 50) == 0 );
assert( gamma_move(board, 2, 65, 0) == 0 );
assert( gamma_move(board, 2, 1, 49) == 0 );
assert( gamma_move(board, 3, 0, 69) == 1 );
assert( gamma_move(board, 3, 1, 26) == 1 );
assert( gamma_free_fields(board, 3) == 172 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 48, 0) == 0 );
assert( gamma_move(board, 4, 1, 103) == 1 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 6, 72, 0) == 0 );
assert( gamma_move(board, 6, 1, 61) == 0 );
assert( gamma_busy_fields(board, 6) == 8 );
assert( gamma_free_fields(board, 1) == 171 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 57, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 33, 1) == 0 );
assert( gamma_move(board, 4, 31, 1) == 0 );
assert( gamma_move(board, 6, 77, 1) == 0 );
assert( gamma_move(board, 1, 106, 0) == 0 );
assert( gamma_move(board, 1, 1, 106) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_free_fields(board, 1) == 171 );
assert( gamma_move(board, 2, 78, 1) == 0 );
assert( gamma_free_fields(board, 2) == 171 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 100) == 0 );
assert( gamma_move(board, 4, 1, 77) == 1 );
assert( gamma_move(board, 5, 44, 1) == 0 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_free_fields(board, 5) == 170 );
assert( gamma_move(board, 6, 75, 1) == 0 );
assert( gamma_move(board, 1, 0, 55) == 0 );
assert( gamma_move(board, 1, 0, 65) == 1 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 92, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 107, 0) == 0 );
assert( gamma_move(board, 4, 1, 73) == 1 );
assert( gamma_free_fields(board, 4) == 168 );
assert( gamma_move(board, 5, 0, 66) == 1 );
assert( gamma_move(board, 6, 95, 1) == 0 );
assert( gamma_move(board, 6, 0, 25) == 1 );
assert( gamma_move(board, 1, 1, 33) == 1 );
assert( gamma_move(board, 1, 0, 38) == 1 );
assert( gamma_move(board, 2, 1, 59) == 1 );
assert( gamma_free_fields(board, 2) == 163 );
assert( gamma_move(board, 4, 74, 0) == 0 );
assert( gamma_move(board, 5, 86, 1) == 0 );
assert( gamma_move(board, 6, 15, 1) == 0 );
assert( gamma_move(board, 6, 1, 99) == 0 );
assert( gamma_move(board, 1, 100, 0) == 0 );
assert( gamma_move(board, 2, 0, 26) == 0 );
assert( gamma_move(board, 3, 0, 47) == 1 );
assert( gamma_move(board, 4, 1, 19) == 1 );
assert( gamma_move(board, 4, 1, 96) == 1 );
assert( gamma_free_fields(board, 4) == 160 );
assert( gamma_move(board, 5, 110, 1) == 0 );
assert( gamma_move(board, 5, 0, 62) == 1 );
assert( gamma_move(board, 6, 0, 3) == 1 );
assert( gamma_move(board, 1, 78, 0) == 0 );
assert( gamma_move(board, 1, 0, 81) == 1 );
assert( gamma_move(board, 2, 1, 73) == 0 );
assert( gamma_move(board, 3, 43, 1) == 0 );
assert( gamma_move(board, 3, 0, 58) == 1 );
assert( gamma_free_fields(board, 3) == 156 );
assert( gamma_move(board, 4, 61, 0) == 0 );
assert( gamma_move(board, 4, 1, 84) == 1 );
assert( gamma_move(board, 5, 51, 1) == 0 );
assert( gamma_move(board, 6, 14, 0) == 0 );
assert( gamma_move(board, 1, 19, 0) == 0 );
assert( gamma_move(board, 1, 0, 78) == 1 );
assert( gamma_move(board, 2, 64, 1) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_free_fields(board, 3) == 154 );
assert( gamma_move(board, 4, 30, 0) == 0 );
assert( gamma_move(board, 4, 1, 65) == 1 );
assert( gamma_move(board, 5, 60, 0) == 0 );
assert( gamma_move(board, 5, 0, 20) == 1 );


char* board913414420 = gamma_board(board);
assert( board913414420 != NULL );
assert( strcmp(board913414420, 
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
".5\n"
".1\n"
"..\n"
".3\n"
".5\n"
".5\n"
".4\n"
"2.\n"
"5.\n"
".1\n"
".4\n"
"..\n"
"31\n"
".4\n"
"5.\n"
"..\n"
"6.\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"..\n"
"1.\n"
"24\n"
"3.\n"
"1.\n"
".4\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"5.\n"
"14\n"
"..\n"
"4.\n"
"51\n"
".1\n"
"..\n"
"32\n"
"35\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"3.\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"..\n"
"1.\n"
".1\n"
"5.\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"23\n"
"62\n"
".3\n"
".6\n"
"..\n"
"..\n"
"5.\n"
".4\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board913414420);
board913414420 = NULL;
assert( gamma_move(board, 6, 30, 0) == 0 );
assert( gamma_free_fields(board, 6) == 152 );
assert( gamma_busy_fields(board, 1) == 20 );
assert( gamma_move(board, 2, 0, 27) == 1 );
assert( gamma_move(board, 2, 1, 65) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 100) == 0 );
assert( gamma_free_fields(board, 4) == 151 );
assert( gamma_move(board, 5, 95, 1) == 0 );
assert( gamma_move(board, 5, 1, 77) == 0 );
assert( gamma_move(board, 6, 72, 0) == 0 );
assert( gamma_move(board, 6, 1, 76) == 1 );
assert( gamma_move(board, 1, 0, 17) == 0 );
assert( gamma_move(board, 1, 0, 95) == 0 );


char* board813170462 = gamma_board(board);
assert( board813170462 != NULL );
assert( strcmp(board813170462, 
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
".5\n"
".1\n"
"..\n"
".3\n"
".5\n"
".5\n"
".4\n"
"2.\n"
"5.\n"
".1\n"
".4\n"
"..\n"
"31\n"
".4\n"
"5.\n"
"..\n"
"6.\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"..\n"
"1.\n"
"24\n"
"3.\n"
"1.\n"
".4\n"
".6\n"
"..\n"
"..\n"
".4\n"
"..\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"5.\n"
"14\n"
"..\n"
"4.\n"
"51\n"
".1\n"
"..\n"
"32\n"
"35\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"3.\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"..\n"
"1.\n"
".1\n"
"5.\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"23\n"
"62\n"
".3\n"
".6\n"
"..\n"
"..\n"
"5.\n"
".4\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board813170462);
board813170462 = NULL;
assert( gamma_move(board, 2, 40, 0) == 0 );
assert( gamma_move(board, 3, 68, 1) == 0 );
assert( gamma_move(board, 4, 0, 29) == 1 );
assert( gamma_move(board, 5, 71, 0) == 0 );
assert( gamma_move(board, 5, 0, 26) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_free_fields(board, 5) == 149 );
assert( gamma_move(board, 6, 113, 1) == 0 );
assert( gamma_move(board, 6, 1, 70) == 0 );
assert( gamma_move(board, 1, 117, 1) == 0 );
assert( gamma_move(board, 1, 1, 65) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 1, 100) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 42) == 0 );
assert( gamma_move(board, 5, 1, 77) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_free_fields(board, 5) == 149 );
assert( gamma_move(board, 6, 1, 111) == 1 );
assert( gamma_move(board, 6, 0, 69) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 32, 1) == 0 );
assert( gamma_move(board, 2, 0, 29) == 0 );
assert( gamma_move(board, 3, 111, 0) == 0 );
assert( gamma_move(board, 4, 21, 1) == 0 );
assert( gamma_move(board, 4, 0, 97) == 0 );
assert( gamma_move(board, 5, 90, 0) == 0 );
assert( gamma_move(board, 5, 1, 24) == 0 );
assert( gamma_move(board, 6, 86, 0) == 0 );
assert( gamma_move(board, 6, 0, 54) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 82, 1) == 0 );
assert( gamma_move(board, 1, 1, 61) == 0 );
assert( gamma_free_fields(board, 1) == 148 );
assert( gamma_move(board, 2, 66, 1) == 0 );
assert( gamma_move(board, 2, 1, 104) == 0 );
assert( gamma_free_fields(board, 2) == 148 );
assert( gamma_move(board, 3, 71, 0) == 0 );
assert( gamma_move(board, 3, 0, 113) == 1 );
assert( gamma_move(board, 4, 0, 32) == 0 );
assert( gamma_move(board, 5, 1, 29) == 1 );
assert( gamma_move(board, 6, 1, 10) == 1 );
assert( gamma_move(board, 1, 18, 0) == 0 );
assert( gamma_move(board, 1, 1, 62) == 0 );
assert( gamma_move(board, 2, 27, 1) == 0 );
assert( gamma_move(board, 2, 0, 58) == 0 );
assert( gamma_move(board, 3, 18, 0) == 0 );
assert( gamma_move(board, 4, 105, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 5, 0, 84) == 1 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 1, 20, 1) == 0 );
assert( gamma_move(board, 1, 0, 35) == 1 );
assert( gamma_free_fields(board, 1) == 143 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 4, 0, 19) == 1 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 110, 0) == 0 );
assert( gamma_move(board, 5, 1, 77) == 0 );
assert( gamma_move(board, 5, 0, 108) == 1 );


char* board970597999 = gamma_board(board);
assert( board970597999 != NULL );
assert( strcmp(board970597999, 
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
".6\n"
".6\n"
"..\n"
".5\n"
"51\n"
"..\n"
".3\n"
".5\n"
".5\n"
".4\n"
"2.\n"
"5.\n"
".1\n"
".4\n"
"..\n"
"31\n"
".4\n"
"5.\n"
"..\n"
"6.\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"54\n"
"..\n"
"..\n"
"1.\n"
"24\n"
"3.\n"
"1.\n"
".4\n"
".6\n"
"..\n"
"..\n"
".4\n"
"..\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"5.\n"
"14\n"
"..\n"
"4.\n"
"51\n"
".1\n"
"..\n"
"32\n"
"35\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"3.\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"1.\n"
"1.\n"
".1\n"
"5.\n"
"4.\n"
"..\n"
"45\n"
"..\n"
"2.\n"
"23\n"
"62\n"
".3\n"
".6\n"
"..\n"
"..\n"
"5.\n"
"44\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"16\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board970597999);
board970597999 = NULL;
assert( gamma_move(board, 6, 98, 1) == 0 );
assert( gamma_move(board, 6, 0, 72) == 1 );
assert( gamma_move(board, 1, 68, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 1, 39) == 0 );
assert( gamma_move(board, 3, 1, 14) == 1 );
assert( gamma_free_fields(board, 3) == 139 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 1, 55) == 0 );
assert( gamma_move(board, 6, 0, 99) == 1 );
assert( gamma_move(board, 1, 21, 0) == 0 );


char* board919471714 = gamma_board(board);
assert( board919471714 != NULL );
assert( strcmp(board919471714, 
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
".6\n"
".6\n"
"..\n"
".5\n"
"51\n"
"..\n"
".3\n"
".5\n"
".5\n"
".4\n"
"2.\n"
"5.\n"
".1\n"
"64\n"
"..\n"
"31\n"
".4\n"
"5.\n"
"..\n"
"6.\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"54\n"
"..\n"
"..\n"
"1.\n"
"24\n"
"3.\n"
"1.\n"
".4\n"
".6\n"
"..\n"
"..\n"
".4\n"
"6.\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"5.\n"
"14\n"
"..\n"
"4.\n"
"51\n"
".1\n"
"..\n"
"32\n"
"35\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"3.\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"1.\n"
"1.\n"
".1\n"
"5.\n"
"4.\n"
"..\n"
"45\n"
"..\n"
"2.\n"
"23\n"
"62\n"
".3\n"
".6\n"
"..\n"
"..\n"
"5.\n"
"44\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"..\n"
"16\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board919471714);
board919471714 = NULL;
assert( gamma_move(board, 3, 89, 1) == 0 );
assert( gamma_move(board, 4, 64, 1) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 6, 56, 0) == 0 );
assert( gamma_move(board, 6, 1, 92) == 1 );
assert( gamma_free_fields(board, 6) == 137 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 87, 0) == 0 );
assert( gamma_move(board, 2, 0, 44) == 0 );
assert( gamma_move(board, 3, 0, 30) == 1 );
assert( gamma_move(board, 3, 1, 86) == 1 );
assert( gamma_move(board, 4, 96, 0) == 0 );
assert( gamma_move(board, 4, 0, 39) == 0 );
assert( gamma_move(board, 5, 0, 65) == 0 );
assert( gamma_move(board, 5, 0, 23) == 1 );
assert( gamma_move(board, 6, 1, 106) == 0 );
assert( gamma_free_fields(board, 6) == 134 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 2, 24, 0) == 0 );
assert( gamma_move(board, 3, 1, 80) == 0 );
assert( gamma_move(board, 3, 0, 104) == 1 );
assert( gamma_golden_move(board, 3, 111, 1) == 0 );
assert( gamma_move(board, 4, 0, 78) == 0 );
assert( gamma_move(board, 4, 0, 61) == 1 );


char* board549219503 = gamma_board(board);
assert( board549219503 != NULL );
assert( strcmp(board549219503, 
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
".6\n"
".6\n"
"..\n"
".5\n"
"51\n"
"..\n"
".3\n"
".5\n"
"35\n"
".4\n"
"2.\n"
"5.\n"
".1\n"
"64\n"
"..\n"
"31\n"
".4\n"
"5.\n"
"..\n"
"6.\n"
"16\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"4.\n"
"54\n"
"..\n"
"..\n"
"1.\n"
"24\n"
"3.\n"
"1.\n"
".4\n"
".6\n"
"..\n"
"..\n"
".4\n"
"6.\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"5.\n"
"14\n"
"..\n"
"4.\n"
"51\n"
"41\n"
"..\n"
"32\n"
"35\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"3.\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"1.\n"
"1.\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
"..\n"
"2.\n"
"23\n"
"62\n"
".3\n"
"56\n"
"..\n"
"..\n"
"5.\n"
"44\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"..\n"
"16\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board549219503);
board549219503 = NULL;
assert( gamma_move(board, 5, 109, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 73, 0) == 0 );
assert( gamma_free_fields(board, 6) == 132 );
assert( gamma_move(board, 1, 1, 109) == 0 );
assert( gamma_free_fields(board, 1) == 132 );
assert( gamma_move(board, 2, 57, 0) == 0 );
assert( gamma_move(board, 3, 75, 1) == 0 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_move(board, 4, 43, 1) == 0 );
assert( gamma_move(board, 4, 1, 111) == 0 );
assert( gamma_move(board, 5, 117, 1) == 0 );
assert( gamma_move(board, 6, 1, 110) == 1 );
assert( gamma_move(board, 1, 1, 107) == 1 );
assert( gamma_move(board, 1, 1, 34) == 1 );
assert( gamma_move(board, 2, 1, 114) == 1 );
assert( gamma_move(board, 2, 0, 40) == 1 );
assert( gamma_move(board, 3, 89, 0) == 0 );
assert( gamma_move(board, 4, 114, 0) == 0 );
assert( gamma_move(board, 4, 1, 40) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_free_fields(board, 5) == 126 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_free_fields(board, 1) == 126 );
assert( gamma_move(board, 2, 117, 1) == 0 );
assert( gamma_move(board, 2, 1, 22) == 1 );
assert( gamma_move(board, 3, 1, 80) == 0 );
assert( gamma_move(board, 4, 89, 0) == 0 );
assert( gamma_move(board, 4, 1, 22) == 0 );
assert( gamma_move(board, 5, 44, 1) == 0 );
assert( gamma_move(board, 5, 1, 28) == 1 );
assert( gamma_move(board, 6, 94, 1) == 0 );
assert( gamma_move(board, 1, 68, 1) == 0 );
assert( gamma_move(board, 1, 1, 27) == 1 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 43, 0) == 0 );
assert( gamma_move(board, 3, 1, 95) == 1 );
assert( gamma_move(board, 4, 1, 29) == 0 );
assert( gamma_move(board, 5, 22, 0) == 0 );
assert( gamma_move(board, 5, 0, 19) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_move(board, 1, 0, 85) == 0 );
assert( gamma_move(board, 2, 1, 66) == 1 );
assert( gamma_move(board, 2, 0, 27) == 0 );
assert( gamma_move(board, 3, 1, 22) == 0 );
assert( gamma_move(board, 3, 1, 39) == 0 );
assert( gamma_move(board, 4, 87, 1) == 0 );
assert( gamma_move(board, 4, 1, 67) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_free_fields(board, 5) == 121 );
assert( gamma_move(board, 6, 117, 1) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 0, 85) == 0 );
assert( gamma_move(board, 3, 1, 91) == 1 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 89, 0) == 0 );
assert( gamma_move(board, 5, 78, 1) == 0 );
assert( gamma_move(board, 5, 1, 65) == 0 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_move(board, 1, 0, 72) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 108) == 0 );
assert( gamma_move(board, 3, 76, 0) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board291223580 = gamma_board(board);
assert( board291223580 != NULL );
assert( strcmp(board291223580, 
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"3.\n"
".6\n"
".6\n"
".6\n"
".5\n"
"51\n"
".1\n"
".3\n"
".5\n"
"35\n"
".4\n"
"2.\n"
"5.\n"
".1\n"
"64\n"
"..\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"4.\n"
"54\n"
"..\n"
"..\n"
"1.\n"
"24\n"
"3.\n"
"1.\n"
".4\n"
".6\n"
"..\n"
"..\n"
".4\n"
"6.\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
"..\n"
"4.\n"
"51\n"
"41\n"
"..\n"
"32\n"
"35\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"3.\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"1.\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"5.\n"
"44\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"6.\n"
"..\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board291223580);
board291223580 = NULL;
assert( gamma_move(board, 4, 0, 100) == 1 );
assert( gamma_move(board, 5, 86, 0) == 0 );
assert( gamma_move(board, 1, 44, 1) == 0 );


char* board868085142 = gamma_board(board);
assert( board868085142 != NULL );
assert( strcmp(board868085142, 
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"3.\n"
".6\n"
".6\n"
".6\n"
".5\n"
"51\n"
".1\n"
".3\n"
".5\n"
"35\n"
".4\n"
"2.\n"
"5.\n"
"41\n"
"64\n"
"..\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"4.\n"
"54\n"
"..\n"
"..\n"
"1.\n"
"24\n"
"3.\n"
"1.\n"
".4\n"
".6\n"
"..\n"
"..\n"
".4\n"
"6.\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
"..\n"
"4.\n"
"51\n"
"41\n"
"..\n"
"32\n"
"35\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"3.\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"1.\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"5.\n"
"44\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"6.\n"
"..\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board868085142);
board868085142 = NULL;
assert( gamma_move(board, 2, 117, 0) == 0 );


char* board478620026 = gamma_board(board);
assert( board478620026 != NULL );
assert( strcmp(board478620026, 
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"3.\n"
".6\n"
".6\n"
".6\n"
".5\n"
"51\n"
".1\n"
".3\n"
".5\n"
"35\n"
".4\n"
"2.\n"
"5.\n"
"41\n"
"64\n"
"..\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"4.\n"
"54\n"
"..\n"
"..\n"
"1.\n"
"24\n"
"3.\n"
"1.\n"
".4\n"
".6\n"
"..\n"
"..\n"
".4\n"
"6.\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
"..\n"
"4.\n"
"51\n"
"41\n"
"..\n"
"32\n"
"35\n"
"..\n"
".1\n"
"41\n"
"43\n"
"..\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"3.\n"
".3\n"
".3\n"
"1.\n"
"..\n"
".3\n"
"..\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"1.\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"5.\n"
"44\n"
"..\n"
"2.\n"
"2.\n"
"..\n"
".3\n"
"..\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"6.\n"
"..\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"4.\n") == 0);
free(board478620026);
board478620026 = NULL;
assert( gamma_move(board, 3, 0, 99) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 1, 53) == 1 );
assert( gamma_move(board, 5, 116, 1) == 0 );
assert( gamma_move(board, 5, 0, 103) == 1 );
assert( gamma_move(board, 6, 1, 47) == 1 );
assert( gamma_move(board, 1, 53, 0) == 0 );
assert( gamma_free_fields(board, 1) == 115 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 3, 118, 1) == 0 );
assert( gamma_move(board, 4, 52, 1) == 0 );
assert( gamma_move(board, 4, 1, 16) == 1 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 6, 112, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 118) == 0 );
assert( gamma_move(board, 1, 1, 20) == 1 );
assert( gamma_move(board, 2, 89, 0) == 0 );
assert( gamma_golden_move(board, 2, 33, 1) == 0 );
assert( gamma_move(board, 3, 0, 50) == 0 );
assert( gamma_move(board, 3, 0, 99) == 0 );
assert( gamma_move(board, 4, 0, 72) == 0 );
assert( gamma_move(board, 5, 1, 43) == 1 );
assert( gamma_move(board, 6, 1, 64) == 1 );
assert( gamma_move(board, 1, 1, 82) == 1 );
assert( gamma_move(board, 1, 0, 106) == 1 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_move(board, 2, 1, 105) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 96, 0) == 0 );
assert( gamma_move(board, 5, 72, 1) == 0 );
assert( gamma_move(board, 5, 1, 57) == 1 );
assert( gamma_move(board, 6, 83, 0) == 0 );
assert( gamma_move(board, 6, 0, 44) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 2, 0, 116) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 77, 0) == 0 );
assert( gamma_move(board, 4, 17, 1) == 0 );
assert( gamma_move(board, 4, 1, 100) == 0 );
assert( gamma_golden_move(board, 4, 116, 0) == 0 );
assert( gamma_move(board, 5, 1, 74) == 1 );
assert( gamma_move(board, 6, 46, 0) == 0 );
assert( gamma_move(board, 6, 1, 112) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 2, 1, 60) == 1 );
assert( gamma_move(board, 2, 1, 79) == 1 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 0, 52) == 0 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_golden_move(board, 5, 36, 1) == 0 );
assert( gamma_move(board, 6, 0, 111) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 2, 68, 0) == 0 );
assert( gamma_move(board, 2, 1, 104) == 0 );
assert( gamma_move(board, 3, 0, 73) == 1 );
assert( gamma_move(board, 4, 98, 1) == 0 );
assert( gamma_move(board, 5, 115, 0) == 0 );
assert( gamma_move(board, 5, 0, 15) == 1 );
assert( gamma_move(board, 6, 74, 0) == 0 );
assert( gamma_free_fields(board, 6) == 98 );
assert( gamma_move(board, 1, 28, 0) == 0 );
assert( gamma_move(board, 1, 1, 79) == 0 );
assert( gamma_move(board, 3, 98, 1) == 0 );
assert( gamma_move(board, 4, 117, 0) == 0 );
assert( gamma_move(board, 4, 1, 92) == 0 );
assert( gamma_move(board, 5, 72, 1) == 0 );
assert( gamma_move(board, 6, 1, 58) == 0 );
assert( gamma_move(board, 6, 0, 116) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 0, 98) == 1 );
assert( gamma_move(board, 2, 52, 1) == 0 );
assert( gamma_move(board, 3, 48, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 56, 0) == 0 );
assert( gamma_move(board, 4, 1, 75) == 1 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 5, 115, 1) == 0 );
assert( gamma_move(board, 5, 1, 86) == 0 );
assert( gamma_move(board, 6, 90, 1) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 1, 1, 105) == 0 );
assert( gamma_move(board, 2, 109, 0) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 50, 1) == 0 );
assert( gamma_free_fields(board, 4) == 96 );
assert( gamma_move(board, 5, 0, 42) == 1 );
assert( gamma_move(board, 6, 56, 0) == 0 );
assert( gamma_move(board, 6, 0, 67) == 0 );
assert( gamma_move(board, 1, 1, 20) == 0 );
assert( gamma_golden_move(board, 1, 79, 1) == 0 );
assert( gamma_move(board, 2, 33, 0) == 0 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_golden_move(board, 2, 37, 0) == 0 );
assert( gamma_move(board, 3, 52, 1) == 0 );
assert( gamma_move(board, 5, 0, 117) == 1 );
assert( gamma_move(board, 5, 0, 77) == 1 );
assert( gamma_move(board, 6, 21, 0) == 0 );
assert( gamma_move(board, 6, 0, 101) == 0 );
assert( gamma_move(board, 1, 90, 1) == 0 );


char* board371273219 = gamma_board(board);
assert( board371273219 != NULL );
assert( strcmp(board371273219, 
"3.\n"
"5.\n"
"2.\n"
"..\n"
".2\n"
"3.\n"
".6\n"
"66\n"
".6\n"
".5\n"
"51\n"
".1\n"
"13\n"
".5\n"
"35\n"
"54\n"
"2.\n"
"5.\n"
"41\n"
"64\n"
"1.\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"1.\n"
"24\n"
"32\n"
"1.\n"
"54\n"
".6\n"
".4\n"
".5\n"
"34\n"
"6.\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"4.\n"
"51\n"
"41\n"
".2\n"
"32\n"
"35\n"
".5\n"
".1\n"
"41\n"
"43\n"
".4\n"
"6.\n"
"..\n"
"4.\n"
".4\n"
"..\n"
"36\n"
".3\n"
".3\n"
"1.\n"
".5\n"
"53\n"
"..\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"1.\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"5.\n"
".3\n"
"1.\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board371273219);
board371273219 = NULL;
assert( gamma_move(board, 2, 30, 1) == 0 );
assert( gamma_move(board, 2, 0, 31) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 20) == 0 );
assert( gamma_move(board, 5, 1, 52) == 1 );
assert( gamma_move(board, 5, 0, 29) == 0 );
assert( gamma_move(board, 6, 1, 82) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 1, 90, 1) == 0 );
assert( gamma_move(board, 1, 1, 81) == 1 );
assert( gamma_free_fields(board, 2) == 90 );
assert( gamma_move(board, 3, 56, 0) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 36, 0) == 0 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 5, 0, 86) == 1 );
assert( gamma_free_fields(board, 5) == 89 );
assert( gamma_golden_move(board, 5, 110, 1) == 0 );
assert( gamma_move(board, 1, 0, 52) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 112, 0) == 0 );
assert( gamma_move(board, 3, 1, 106) == 0 );
assert( gamma_move(board, 3, 0, 51) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 56) == 1 );
assert( gamma_move(board, 5, 36, 0) == 0 );
assert( gamma_move(board, 5, 0, 117) == 0 );
assert( gamma_move(board, 6, 1, 35) == 1 );
assert( gamma_move(board, 6, 1, 102) == 1 );
assert( gamma_move(board, 1, 1, 101) == 1 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_free_fields(board, 1) == 84 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 2, 0, 48) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 18, 0) == 0 );
assert( gamma_free_fields(board, 4) == 83 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 89, 0) == 0 );
assert( gamma_free_fields(board, 5) == 83 );
assert( gamma_busy_fields(board, 6) == 22 );
assert( gamma_move(board, 1, 109, 0) == 0 );
assert( gamma_move(board, 1, 0, 62) == 0 );
assert( gamma_golden_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 46, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 91, 0) == 0 );
assert( gamma_move(board, 3, 1, 61) == 0 );
assert( gamma_free_fields(board, 3) == 83 );
assert( gamma_move(board, 4, 41, 1) == 0 );


char* board362590584 = gamma_board(board);
assert( board362590584 != NULL );
assert( strcmp(board362590584, 
"3.\n"
"5.\n"
"2.\n"
"..\n"
".2\n"
"3.\n"
".6\n"
"66\n"
".6\n"
".5\n"
"51\n"
".1\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"1.\n"
"54\n"
".6\n"
".4\n"
".5\n"
"34\n"
"6.\n"
".5\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"4.\n"
"51\n"
"41\n"
".2\n"
"32\n"
"35\n"
".5\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
".4\n"
"2.\n"
"36\n"
".3\n"
".3\n"
"1.\n"
".5\n"
"53\n"
"..\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"5.\n"
".3\n"
"1.\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board362590584);
board362590584 = NULL;
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 6, 87, 0) == 0 );
assert( gamma_move(board, 6, 0, 109) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 84) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 96, 0) == 0 );
assert( gamma_move(board, 3, 1, 118) == 1 );
assert( gamma_move(board, 4, 112, 0) == 0 );
assert( gamma_move(board, 4, 1, 52) == 0 );
assert( gamma_move(board, 5, 87, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 1, 46, 0) == 0 );
assert( gamma_move(board, 1, 0, 71) == 1 );
assert( gamma_golden_move(board, 1, 81, 0) == 0 );


char* board139569146 = gamma_board(board);
assert( board139569146 != NULL );
assert( strcmp(board139569146, 
"33\n"
"5.\n"
"2.\n"
"..\n"
".2\n"
"3.\n"
".6\n"
"66\n"
".6\n"
"65\n"
"51\n"
".1\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"1.\n"
"54\n"
".6\n"
".4\n"
".5\n"
"34\n"
"6.\n"
"15\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"4.\n"
"51\n"
"41\n"
".2\n"
"32\n"
"35\n"
".5\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
".4\n"
"2.\n"
"36\n"
".3\n"
".3\n"
"1.\n"
".5\n"
"53\n"
"..\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"5.\n"
".3\n"
"1.\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board139569146);
board139569146 = NULL;
assert( gamma_move(board, 2, 41, 0) == 0 );
assert( gamma_free_fields(board, 2) == 80 );
assert( gamma_move(board, 3, 48, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 21, 0) == 0 );
assert( gamma_move(board, 5, 0, 65) == 0 );
assert( gamma_move(board, 5, 1, 44) == 1 );
assert( gamma_move(board, 6, 0, 41) == 1 );
assert( gamma_move(board, 2, 0, 93) == 0 );
assert( gamma_move(board, 3, 89, 1) == 0 );
assert( gamma_move(board, 3, 0, 49) == 1 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 4, 90, 1) == 0 );
assert( gamma_move(board, 5, 1, 73) == 0 );
assert( gamma_move(board, 6, 90, 0) == 0 );
assert( gamma_move(board, 1, 83, 1) == 0 );
assert( gamma_move(board, 2, 1, 80) == 0 );
assert( gamma_move(board, 3, 43, 0) == 0 );
assert( gamma_golden_move(board, 3, 25, 1) == 0 );
assert( gamma_move(board, 4, 53, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 6, 18, 0) == 0 );
assert( gamma_move(board, 2, 74, 0) == 0 );
assert( gamma_move(board, 2, 0, 118) == 0 );
assert( gamma_move(board, 3, 89, 0) == 0 );
assert( gamma_move(board, 3, 1, 62) == 0 );
assert( gamma_move(board, 4, 0, 26) == 0 );
assert( gamma_move(board, 5, 68, 1) == 0 );
assert( gamma_free_fields(board, 5) == 77 );
assert( gamma_move(board, 6, 85, 1) == 0 );
assert( gamma_move(board, 6, 0, 88) == 1 );
assert( gamma_move(board, 1, 0, 89) == 1 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 90, 0) == 0 );
assert( gamma_move(board, 2, 1, 34) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board798436004 = gamma_board(board);
assert( board798436004 != NULL );
assert( strcmp(board798436004, 
"33\n"
"5.\n"
"2.\n"
"..\n"
".2\n"
"3.\n"
".6\n"
"66\n"
".6\n"
"65\n"
"51\n"
".1\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"1.\n"
"54\n"
".6\n"
".4\n"
".5\n"
"34\n"
"6.\n"
"15\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"4.\n"
"51\n"
"41\n"
".2\n"
"32\n"
"35\n"
".5\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"2.\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"5.\n"
".3\n"
"1.\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board798436004);
board798436004 = NULL;
assert( gamma_move(board, 3, 1, 79) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 75, 0) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 1, 23) == 0 );
assert( gamma_move(board, 6, 1, 115) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 1, 55) == 0 );
assert( gamma_golden_move(board, 1, 52, 0) == 0 );
assert( gamma_move(board, 2, 1, 67) == 0 );
assert( gamma_move(board, 2, 1, 78) == 1 );
assert( gamma_move(board, 3, 1, 118) == 0 );
assert( gamma_move(board, 3, 0, 95) == 0 );


char* board918762454 = gamma_board(board);
assert( board918762454 != NULL );
assert( strcmp(board918762454, 
"33\n"
"5.\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
".6\n"
"65\n"
"51\n"
".1\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
".4\n"
".5\n"
"34\n"
"6.\n"
"15\n"
".2\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"4.\n"
"51\n"
"41\n"
".2\n"
"32\n"
"35\n"
".5\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"2.\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"5.\n"
".3\n"
"1.\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board918762454);
board918762454 = NULL;
assert( gamma_move(board, 4, 0, 70) == 1 );


char* board491512229 = gamma_board(board);
assert( board491512229 != NULL );
assert( strcmp(board491512229, 
"33\n"
"5.\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
".6\n"
"65\n"
"51\n"
".1\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
".4\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
".4\n"
".5\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"4.\n"
"51\n"
"41\n"
".2\n"
"32\n"
"35\n"
".5\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"2.\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"5.\n"
".3\n"
"1.\n"
".1\n"
"1.\n"
"16\n"
"..\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board491512229);
board491512229 = NULL;
assert( gamma_move(board, 5, 76, 0) == 0 );
assert( gamma_move(board, 6, 117, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 60) == 1 );
assert( gamma_move(board, 2, 96, 0) == 0 );
assert( gamma_move(board, 2, 1, 44) == 0 );
assert( gamma_move(board, 3, 90, 1) == 0 );
assert( gamma_move(board, 4, 1, 60) == 0 );
assert( gamma_free_fields(board, 4) == 71 );
assert( gamma_move(board, 5, 83, 1) == 0 );
assert( gamma_move(board, 5, 1, 63) == 1 );
assert( gamma_move(board, 6, 51, 1) == 0 );
assert( gamma_move(board, 1, 0, 85) == 0 );
assert( gamma_move(board, 1, 0, 96) == 1 );
assert( gamma_free_fields(board, 1) == 69 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 1, 74) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 110) == 1 );
assert( gamma_move(board, 6, 0, 88) == 0 );
assert( gamma_golden_move(board, 1, 69, 0) == 0 );
assert( gamma_move(board, 2, 68, 0) == 0 );
assert( gamma_move(board, 2, 0, 25) == 0 );
assert( gamma_free_fields(board, 3) == 68 );
assert( gamma_move(board, 4, 1, 15) == 1 );
assert( gamma_move(board, 5, 113, 1) == 0 );
assert( gamma_move(board, 5, 1, 16) == 0 );
assert( gamma_move(board, 6, 1, 75) == 0 );
assert( gamma_move(board, 6, 1, 99) == 0 );
assert( gamma_move(board, 1, 38, 1) == 0 );
assert( gamma_move(board, 1, 1, 26) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 26, 1) == 0 );
assert( gamma_move(board, 2, 0, 58) == 0 );
assert( gamma_move(board, 2, 1, 92) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 38, 1) == 0 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 90, 1) == 0 );
assert( gamma_free_fields(board, 5) == 66 );
assert( gamma_move(board, 6, 1, 73) == 0 );
assert( gamma_move(board, 1, 41, 1) == 0 );
assert( gamma_move(board, 1, 0, 51) == 0 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 115, 0) == 0 );
assert( gamma_move(board, 3, 113, 1) == 0 );
assert( gamma_move(board, 4, 28, 0) == 0 );
assert( gamma_move(board, 4, 0, 12) == 1 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 5, 0, 118) == 0 );
assert( gamma_move(board, 6, 41, 1) == 0 );
assert( gamma_move(board, 6, 0, 57) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board982144577 = gamma_board(board);
assert( board982144577 != NULL );
assert( strcmp(board982144577, 
"33\n"
"5.\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
"56\n"
"65\n"
"51\n"
".1\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
"14\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
".4\n"
".5\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"45\n"
"51\n"
"41\n"
"12\n"
"32\n"
"35\n"
"65\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"2.\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
".6\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"54\n"
".3\n"
"1.\n"
"41\n"
"1.\n"
"16\n"
"3.\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board982144577);
board982144577 = NULL;
assert( gamma_move(board, 2, 0, 107) == 1 );
assert( gamma_move(board, 2, 1, 53) == 0 );
assert( gamma_move(board, 3, 1, 64) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 1, 48) == 1 );
assert( gamma_move(board, 5, 1, 117) == 1 );
assert( gamma_busy_fields(board, 5) == 32 );
assert( gamma_move(board, 6, 105, 0) == 0 );
assert( gamma_move(board, 6, 0, 36) == 1 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 1, 66) == 0 );
assert( gamma_free_fields(board, 2) == 60 );


char* board976770361 = gamma_board(board);
assert( board976770361 != NULL );
assert( strcmp(board976770361, 
"33\n"
"55\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
"56\n"
"65\n"
"51\n"
"21\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
"14\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
".4\n"
".5\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"45\n"
"51\n"
"41\n"
"12\n"
"32\n"
"35\n"
"65\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"24\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
"66\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"54\n"
".3\n"
"1.\n"
"41\n"
"1.\n"
"16\n"
"3.\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board976770361);
board976770361 = NULL;
assert( gamma_busy_fields(board, 3) == 32 );
assert( gamma_move(board, 4, 0, 39) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 5, 0, 80) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 1, 53, 0) == 0 );
assert( gamma_move(board, 1, 0, 92) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 43, 0) == 0 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 3, 1, 99) == 0 );
assert( gamma_move(board, 3, 1, 109) == 0 );
assert( gamma_move(board, 4, 91, 0) == 0 );
assert( gamma_move(board, 6, 85, 1) == 0 );
assert( gamma_move(board, 6, 0, 32) == 0 );
assert( gamma_move(board, 1, 83, 0) == 0 );
assert( gamma_move(board, 1, 1, 24) == 0 );
assert( gamma_move(board, 2, 94, 0) == 0 );
assert( gamma_move(board, 3, 30, 1) == 0 );
assert( gamma_move(board, 4, 17, 1) == 0 );
assert( gamma_move(board, 5, 0, 74) == 1 );
assert( gamma_move(board, 5, 0, 102) == 0 );


char* board978479310 = gamma_board(board);
assert( board978479310 != NULL );
assert( strcmp(board978479310, 
"33\n"
"55\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
"56\n"
"65\n"
"51\n"
"21\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
"14\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
".4\n"
"55\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"45\n"
"51\n"
"41\n"
"12\n"
"32\n"
"35\n"
"65\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"24\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
"66\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"54\n"
".3\n"
"1.\n"
"41\n"
"1.\n"
"16\n"
"3.\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board978479310);
board978479310 = NULL;
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board594544024 = gamma_board(board);
assert( board594544024 != NULL );
assert( strcmp(board594544024, 
"33\n"
"55\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
"56\n"
"65\n"
"51\n"
"21\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"1.\n"
"31\n"
"14\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
".4\n"
"55\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"45\n"
"51\n"
"41\n"
"12\n"
"32\n"
"35\n"
"65\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"24\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
"66\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
"..\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"54\n"
".3\n"
"1.\n"
"41\n"
"1.\n"
"16\n"
"3.\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board594544024);
board594544024 = NULL;
assert( gamma_move(board, 1, 91, 0) == 0 );
assert( gamma_move(board, 1, 0, 75) == 1 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 1, 48) == 0 );
assert( gamma_move(board, 4, 94, 1) == 0 );
assert( gamma_move(board, 4, 0, 117) == 0 );
assert( gamma_move(board, 5, 1, 98) == 1 );
assert( gamma_move(board, 6, 69, 1) == 0 );
assert( gamma_move(board, 6, 0, 25) == 0 );
assert( gamma_move(board, 1, 32, 1) == 0 );
assert( gamma_move(board, 1, 1, 60) == 0 );
assert( gamma_move(board, 2, 82, 0) == 0 );
assert( gamma_move(board, 3, 0, 44) == 0 );
assert( gamma_move(board, 3, 1, 42) == 0 );
assert( gamma_move(board, 4, 1, 105) == 0 );
assert( gamma_move(board, 5, 1, 58) == 0 );
assert( gamma_free_fields(board, 5) == 57 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 1, 1, 21) == 1 );
assert( gamma_move(board, 2, 45, 0) == 0 );
assert( gamma_move(board, 2, 1, 52) == 0 );
assert( gamma_move(board, 3, 94, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );


char* board792759246 = gamma_board(board);
assert( board792759246 != NULL );
assert( strcmp(board792759246, 
"33\n"
"55\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
"56\n"
"65\n"
"51\n"
"21\n"
"13\n"
".5\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"15\n"
"31\n"
"14\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"..\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
"14\n"
"55\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"45\n"
"51\n"
"41\n"
"12\n"
"32\n"
"35\n"
"65\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"24\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
"66\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
".1\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"54\n"
".3\n"
"1.\n"
"41\n"
"1.\n"
"16\n"
"3.\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board792759246);
board792759246 = NULL;
assert( gamma_move(board, 5, 89, 1) == 0 );
assert( gamma_move(board, 5, 0, 92) == 0 );
assert( gamma_move(board, 6, 1, 22) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 53, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 64, 0) == 0 );
assert( gamma_move(board, 3, 30, 1) == 0 );
assert( gamma_move(board, 3, 0, 41) == 0 );
assert( gamma_free_fields(board, 3) == 56 );
assert( gamma_move(board, 4, 0, 90) == 1 );
assert( gamma_move(board, 4, 0, 47) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 105) == 1 );


char* board758371127 = gamma_board(board);
assert( board758371127 != NULL );
assert( strcmp(board758371127, 
"33\n"
"55\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
"56\n"
"65\n"
"51\n"
"21\n"
"13\n"
"55\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"15\n"
"31\n"
"14\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"4.\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
"14\n"
"55\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"45\n"
"51\n"
"41\n"
"12\n"
"32\n"
"35\n"
"65\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"24\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
"66\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
".1\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"54\n"
".3\n"
"1.\n"
"41\n"
"1.\n"
"16\n"
"3.\n"
"..\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board758371127);
board758371127 = NULL;
assert( gamma_golden_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 83, 0) == 0 );
assert( gamma_move(board, 3, 0, 32) == 0 );
assert( gamma_busy_fields(board, 3) == 32 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_move(board, 5, 17, 1) == 0 );
assert( gamma_free_fields(board, 5) == 53 );
assert( gamma_move(board, 6, 1, 13) == 1 );


char* board752777743 = gamma_board(board);
assert( board752777743 != NULL );
assert( strcmp(board752777743, 
"33\n"
"55\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
"56\n"
"65\n"
"51\n"
"21\n"
"13\n"
"55\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"15\n"
"31\n"
"14\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"4.\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
"14\n"
"55\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"45\n"
"51\n"
"41\n"
"12\n"
"32\n"
"35\n"
"65\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"24\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
"66\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
".1\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"54\n"
".3\n"
"16\n"
"41\n"
"1.\n"
"16\n"
"3.\n"
"4.\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board752777743);
board752777743 = NULL;
assert( gamma_move(board, 1, 1, 112) == 0 );


char* board562220324 = gamma_board(board);
assert( board562220324 != NULL );
assert( strcmp(board562220324, 
"33\n"
"55\n"
"2.\n"
".6\n"
".2\n"
"3.\n"
".6\n"
"66\n"
"56\n"
"65\n"
"51\n"
"21\n"
"13\n"
"55\n"
"35\n"
"54\n"
"26\n"
"51\n"
"41\n"
"64\n"
"15\n"
"31\n"
"14\n"
"53\n"
"..\n"
"6.\n"
"16\n"
".3\n"
"4.\n"
"1.\n"
"6.\n"
"..\n"
"53\n"
"4.\n"
"54\n"
"..\n"
".1\n"
"11\n"
"24\n"
"32\n"
"12\n"
"54\n"
".6\n"
"14\n"
"55\n"
"34\n"
"6.\n"
"15\n"
"42\n"
"3.\n"
"..\n"
"16\n"
"52\n"
"14\n"
".6\n"
"45\n"
"51\n"
"41\n"
"12\n"
"32\n"
"35\n"
"65\n"
"41\n"
"41\n"
"43\n"
".4\n"
"65\n"
"3.\n"
"4.\n"
"34\n"
"24\n"
"36\n"
".3\n"
".3\n"
"15\n"
".5\n"
"53\n"
"6.\n"
"21\n"
"33\n"
"1.\n"
"62\n"
"66\n"
"16\n"
"11\n"
".1\n"
"5.\n"
"4.\n"
"3.\n"
"45\n"
".5\n"
"21\n"
"23\n"
"62\n"
".3\n"
"56\n"
".2\n"
".1\n"
"51\n"
"44\n"
"..\n"
"2.\n"
"24\n"
"54\n"
".3\n"
"16\n"
"41\n"
"1.\n"
"16\n"
"3.\n"
"4.\n"
".3\n"
"63\n"
"2.\n"
".3\n"
"6.\n"
"1.\n"
"35\n"
"45\n") == 0);
free(board562220324);
board562220324 = NULL;
assert( gamma_golden_move(board, 2, 19, 0) == 0 );
assert( gamma_move(board, 3, 68, 1) == 0 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 32, 1) == 0 );
assert( gamma_move(board, 4, 0, 45) == 1 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_move(board, 5, 0, 21) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 18, 0) == 0 );
assert( gamma_move(board, 1, 83, 1) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 0, 110) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 5, 0, 49) == 0 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 6, 1, 36) == 0 );
assert( gamma_busy_fields(board, 6) == 29 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 1, 41) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );


gamma_delete(board);

    return 0;
}
