#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 120579828
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 10, 8, 23);
assert( board != NULL );


assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 1, 3, 9) == 1 );


char* board497165585 = gamma_board(board);
assert( board497165585 != NULL );
assert( strcmp(board497165585, 
"...1.............\n"
".................\n"
".................\n"
".................\n"
".................\n"
".................\n"
".................\n"
".................\n"
".................\n"
".................\n") == 0);
free(board497165585);
board497165585 = NULL;
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_free_fields(board, 2) == 167 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 13, 0) == 1 );
assert( gamma_move(board, 4, 14, 1) == 1 );
assert( gamma_move(board, 5, 7, 3) == 1 );
assert( gamma_busy_fields(board, 5) == 1 );
assert( gamma_move(board, 6, 6, 3) == 1 );
assert( gamma_move(board, 7, 13, 8) == 1 );
assert( gamma_move(board, 7, 6, 9) == 1 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 2, 14, 6) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 5, 12, 3) == 1 );
assert( gamma_free_fields(board, 5) == 156 );
assert( gamma_move(board, 6, 16, 5) == 1 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_move(board, 7, 3, 10) == 0 );
assert( gamma_move(board, 8, 3, 3) == 0 );
assert( gamma_free_fields(board, 8) == 155 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 15, 4) == 1 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 2) == 1 );


char* board471905226 = gamma_board(board);
assert( board471905226 != NULL );
assert( strcmp(board471905226, 
"...1..7..........\n"
"......1......7...\n"
"1................\n"
"......2.......2..\n"
"................6\n"
"...............1.\n"
"...4..65.2..5....\n"
".............3...\n"
"..............4..\n"
"........2....3...\n") == 0);
free(board471905226);
board471905226 = NULL;
assert( gamma_move(board, 4, 5, 7) == 1 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 3 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_move(board, 7, 7, 7) == 1 );
assert( gamma_free_fields(board, 7) == 149 );
assert( gamma_move(board, 8, 5, 9) == 1 );
assert( gamma_move(board, 8, 13, 2) == 0 );
assert( gamma_move(board, 1, 12, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 4, 11, 3) == 1 );
assert( gamma_move(board, 4, 15, 2) == 1 );
assert( gamma_move(board, 5, 2, 6) == 1 );
assert( gamma_move(board, 5, 0, 4) == 1 );
assert( gamma_move(board, 6, 8, 7) == 1 );
assert( gamma_move(board, 6, 3, 3) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 7) == 1 );
assert( gamma_move(board, 7, 0, 5) == 1 );
assert( gamma_move(board, 8, 1, 12) == 0 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 1, 10, 2) == 1 );


char* board530172366 = gamma_board(board);
assert( board530172366 != NULL );
assert( strcmp(board530172366, 
"..51.87..........\n"
"......1......7...\n"
"1....4.767.......\n"
"..5.3.2.......2..\n"
"7...............6\n"
"5..............1.\n"
"...4..65.2.45....\n"
"12........1.13.4.\n"
"..............4..\n"
"........2....3...\n") == 0);
free(board530172366);
board530172366 = NULL;
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 6) == 1 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 6, 2, 9) == 0 );
assert( gamma_move(board, 7, 7, 1) == 1 );
assert( gamma_move(board, 8, 3, 6) == 1 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_free_fields(board, 2) == 130 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_free_fields(board, 4) == 128 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board913826797 = gamma_board(board);
assert( board913826797 != NULL );
assert( strcmp(board913826797, 
"..51.87..2.......\n"
"......1......7...\n"
"1....4.767.......\n"
"..583.2......42..\n"
"7....4....3.....6\n"
"5..............1.\n"
"...4..65.2.45....\n"
"12........1.13.4.\n"
"2......7..3...4..\n"
"5.......2....3...\n") == 0);
free(board913826797);
board913826797 = NULL;
assert( gamma_move(board, 6, 0, 15) == 0 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 7, 4, 6) == 0 );
assert( gamma_move(board, 7, 12, 3) == 0 );
assert( gamma_move(board, 8, 3, 13) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_free_fields(board, 1) == 127 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 5, 11, 1) == 1 );
assert( gamma_move(board, 5, 5, 1) == 1 );
assert( gamma_move(board, 6, 3, 5) == 1 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 7, 14, 4) == 1 );
assert( gamma_busy_fields(board, 7) == 7 );
assert( gamma_move(board, 8, 4, 8) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 1, 3, 4) == 1 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_free_fields(board, 2) == 117 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 6, 0, 9) == 1 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 7, 0, 3) == 1 );
assert( gamma_move(board, 7, 8, 2) == 1 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 8, 5, 6) == 1 );
assert( gamma_move(board, 8, 2, 0) == 1 );
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_free_fields(board, 3) == 107 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_move(board, 6, 2, 7) == 1 );
assert( gamma_move(board, 7, 4, 5) == 1 );
assert( gamma_move(board, 7, 5, 9) == 0 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 2, 4) == 1 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 5, 13, 9) == 1 );
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 6, 7, 10) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_move(board, 8, 4, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_golden_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 6, 16) == 0 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_move(board, 5, 13, 5) == 1 );
assert( gamma_busy_fields(board, 5) == 11 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board964918013 = gamma_board(board);
assert( board964918013 != NULL );
assert( strcmp(board964918013, 
"6.51.87..2...5...\n"
"....8.1..1...7...\n"
"1.6..4.767.......\n"
".558382......42..\n"
"7..674.41.3..5..6\n"
"5.81......3.1.71.\n"
"7..4.46522.45....\n"
"12......7.1.13.4.\n"
"23.385.7.235..4..\n"
"5.81....2..2.3...\n") == 0);
free(board964918013);
board964918013 = NULL;
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 7, 13, 4) == 1 );
assert( gamma_move(board, 8, 13, 8) == 0 );
assert( gamma_golden_move(board, 8, 1, 4) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 2, 15, 9) == 1 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_free_fields(board, 3) == 95 );
assert( gamma_move(board, 4, 11, 7) == 1 );
assert( gamma_move(board, 4, 13, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 6, 16, 4) == 1 );
assert( gamma_move(board, 6, 3, 7) == 1 );
assert( gamma_move(board, 7, 5, 12) == 0 );
assert( gamma_free_fields(board, 7) == 91 );


char* board742735554 = gamma_board(board);
assert( board742735554 != NULL );
assert( strcmp(board742735554, 
"6.51.87..2...5.2.\n"
"....8.1..1...7...\n"
"1.66.4.767.4.....\n"
".558382......42..\n"
"7..674.41.3..5..6\n"
"5.81......3.17716\n"
"7..4.46522.45....\n"
"12......7.1.13.4.\n"
"23.385.7.235.44..\n"
"5.81....2..2.3...\n") == 0);
free(board742735554);
board742735554 = NULL;
assert( gamma_move(board, 8, 8, 14) == 0 );
assert( gamma_move(board, 8, 15, 1) == 1 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_free_fields(board, 2) == 90 );


char* board580735458 = gamma_board(board);
assert( board580735458 != NULL );
assert( strcmp(board580735458, 
"6.51.87..2...5.2.\n"
"....8.1..1...7...\n"
"1.66.4.767.4.....\n"
".558382......42..\n"
"7..674.41.3..5..6\n"
"5.81......3.17716\n"
"7..4.46522.45....\n"
"12......7.1.13.4.\n"
"23.385.7.235.448.\n"
"5.81....2..2.3...\n") == 0);
free(board580735458);
board580735458 = NULL;
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 4, 3, 15) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_free_fields(board, 4) == 89 );
assert( gamma_move(board, 5, 1, 16) == 0 );
assert( gamma_move(board, 5, 16, 3) == 1 );
assert( gamma_free_fields(board, 5) == 88 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 3, 4) == 0 );
assert( gamma_move(board, 7, 8, 9) == 1 );
assert( gamma_move(board, 8, 4, 3) == 1 );
assert( gamma_move(board, 8, 0, 8) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );


char* board348184168 = gamma_board(board);
assert( board348184168 != NULL );
assert( strcmp(board348184168, 
"6.51.87.72...5.2.\n"
"8...8.1..1...7...\n"
"1.66.4.767.4.....\n"
".558382......42..\n"
"7..674.41.3..5..6\n"
"5.81...3..3.17716\n"
"7..4846522.45...5\n"
"12......7.1.13.4.\n"
"23.385.7.235.448.\n"
"5.81....2..2.3...\n") == 0);
free(board348184168);
board348184168 = NULL;
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 4, 14, 0) == 1 );
assert( gamma_move(board, 4, 9, 4) == 1 );
assert( gamma_free_fields(board, 4) == 83 );
assert( gamma_move(board, 5, 1, 9) == 1 );
assert( gamma_move(board, 6, 6, 0) == 1 );
assert( gamma_move(board, 6, 3, 7) == 0 );
assert( gamma_move(board, 8, 2, 16) == 0 );
assert( gamma_move(board, 8, 15, 0) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_free_fields(board, 3) == 79 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 7, 0) == 1 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 6, 6, 7) == 1 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_move(board, 7, 16, 7) == 1 );
assert( gamma_move(board, 8, 0, 9) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_free_fields(board, 5) == 76 );
assert( gamma_move(board, 6, 7, 12) == 0 );
assert( gamma_move(board, 7, 12, 6) == 1 );
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_free_fields(board, 8) == 75 );
assert( gamma_move(board, 1, 14, 9) == 1 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_free_fields(board, 2) == 74 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_free_fields(board, 5) == 74 );
assert( gamma_move(board, 6, 7, 10) == 0 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_move(board, 7, 9, 7) == 0 );
assert( gamma_move(board, 7, 4, 0) == 1 );
assert( gamma_move(board, 8, 0, 6) == 1 );
assert( gamma_move(board, 8, 11, 4) == 1 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_move(board, 6, 7, 8) == 1 );
assert( gamma_move(board, 7, 5, 7) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 15, 8) == 1 );
assert( gamma_free_fields(board, 8) == 68 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_free_fields(board, 1) == 68 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_golden_move(board, 2, 5, 3) == 1 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_free_fields(board, 3) == 67 );
assert( gamma_move(board, 4, 7, 14) == 0 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 10, 0) == 1 );
assert( gamma_move(board, 7, 9, 6) == 1 );
assert( gamma_move(board, 8, 9, 8) == 0 );
assert( gamma_move(board, 8, 3, 3) == 0 );
assert( gamma_free_fields(board, 8) == 64 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_golden_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );
assert( gamma_move(board, 5, 15, 0) == 0 );
assert( gamma_move(board, 6, 3, 2) == 1 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 7, 7, 4) == 0 );
assert( gamma_free_fields(board, 7) == 61 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 5, 9) == 0 );
assert( gamma_move(board, 8, 13, 0) == 0 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 3, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 10, 8) == 1 );


char* board290548859 = gamma_board(board);
assert( board290548859 != NULL );
assert( strcmp(board290548859, 
"6551.87.72...512.\n"
"8...8.16.162.7.8.\n"
"1366.46767.4....7\n"
"8558382..7.2742..\n"
"7..674241.34.5..6\n"
"5.814..3.43817716\n"
"7..4826522245...5\n"
"12.6....7.1.13.4.\n"
"23.385.7.235.448.\n"
"5.817.652.62.348.\n") == 0);
free(board290548859);
board290548859 = NULL;
assert( gamma_move(board, 7, 1, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 3, 15) == 0 );
assert( gamma_move(board, 8, 2, 3) == 1 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_free_fields(board, 2) == 56 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 12, 9) == 1 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_move(board, 7, 2, 14) == 0 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 16) == 0 );
assert( gamma_move(board, 8, 9, 3) == 0 );
assert( gamma_free_fields(board, 8) == 53 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 12, 5) == 1 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_move(board, 6, 6, 10) == 0 );
assert( gamma_move(board, 6, 2, 8) == 1 );
assert( gamma_move(board, 7, 4, 5) == 0 );
assert( gamma_move(board, 7, 10, 5) == 0 );
assert( gamma_move(board, 8, 2, 7) == 0 );
assert( gamma_move(board, 8, 14, 3) == 1 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 7, 7, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_move(board, 8, 1, 4) == 0 );
assert( gamma_move(board, 8, 4, 0) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 0, 12) == 0 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_move(board, 8, 6, 10) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 6, 16) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board102932918 = gamma_board(board);
assert( board102932918 != NULL );
assert( strcmp(board102932918, 
"6551.87.72..4512.\n"
"8.6.8.16.162.7.8.\n"
"1366.46767.4.4..7\n"
"85583823.7.2742..\n"
"7..674241.3415..6\n"
"53814.13.43817716\n"
"7284826522245.8.5\n"
"12.6.1..7.1.13.4.\n"
"23.385.73235.448.\n"
"5.817.652.62.348.\n") == 0);
free(board102932918);
board102932918 = NULL;
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 6, 12, 4) == 0 );
assert( gamma_move(board, 7, 8, 12) == 0 );
assert( gamma_move(board, 7, 15, 5) == 1 );
assert( gamma_move(board, 8, 0, 5) == 0 );
assert( gamma_move(board, 8, 12, 1) == 1 );
assert( gamma_move(board, 1, 8, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 8, 4) == 1 );
assert( gamma_move(board, 7, 9, 11) == 0 );
assert( gamma_move(board, 7, 4, 1) == 0 );
assert( gamma_move(board, 8, 9, 16) == 0 );
assert( gamma_busy_fields(board, 8) == 17 );
assert( gamma_free_fields(board, 8) == 43 );


char* board662656059 = gamma_board(board);
assert( board662656059 != NULL );
assert( strcmp(board662656059, 
"6551.87.72..4512.\n"
"8.6.8.161162.7.8.\n"
"1366.46767.4.4..7\n"
"85583823.7.2742..\n"
"7..674241.3415.76\n"
"53814.13543817716\n"
"7284826522245.8.5\n"
"12.6.1..7.1.13.4.\n"
"23.385.732358448.\n"
"5.817.652.62.348.\n") == 0);
free(board662656059);
board662656059 = NULL;
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_free_fields(board, 5) == 42 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_move(board, 6, 12, 0) == 1 );
assert( gamma_move(board, 7, 4, 5) == 0 );
assert( gamma_move(board, 7, 3, 3) == 0 );
assert( gamma_move(board, 8, 14, 7) == 1 );
assert( gamma_move(board, 8, 1, 0) == 1 );
assert( gamma_free_fields(board, 8) == 39 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 4, 15, 2) == 0 );
assert( gamma_free_fields(board, 5) == 39 );
assert( gamma_move(board, 6, 7, 12) == 0 );
assert( gamma_move(board, 6, 2, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 6, 0) == 0 );
assert( gamma_free_fields(board, 7) == 39 );
assert( gamma_move(board, 8, 3, 13) == 0 );
assert( gamma_move(board, 8, 2, 1) == 1 );
assert( gamma_busy_fields(board, 8) == 20 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 5, 4) == 1 );
assert( gamma_free_fields(board, 4) == 37 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 16) == 0 );
assert( gamma_free_fields(board, 5) == 37 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 7, 11, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 15, 9) == 0 );
assert( gamma_move(board, 8, 5, 8) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_golden_move(board, 8, 6, 4) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 10, 9) == 1 );
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 5, 8, 1) == 0 );
assert( gamma_move(board, 6, 6, 16) == 0 );
assert( gamma_move(board, 6, 15, 5) == 0 );
assert( gamma_free_fields(board, 6) == 35 );
assert( gamma_move(board, 7, 8, 7) == 0 );
assert( gamma_move(board, 8, 2, 9) == 0 );
assert( gamma_move(board, 8, 7, 6) == 0 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_move(board, 6, 11, 9) == 1 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 7, 6, 10) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 12) == 0 );
assert( gamma_move(board, 1, 8, 16) == 0 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_free_fields(board, 2) == 33 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_free_fields(board, 3) == 33 );
assert( gamma_golden_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 5, 15, 7) == 1 );
assert( gamma_move(board, 6, 13, 5) == 0 );
assert( gamma_move(board, 7, 5, 2) == 0 );
assert( gamma_move(board, 8, 8, 12) == 0 );
assert( gamma_move(board, 8, 4, 7) == 1 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_golden_move(board, 3, 5, 15) == 0 );


char* board830422296 = gamma_board(board);
assert( board830422296 != NULL );
assert( strcmp(board830422296, 
"6551.87.72464512.\n"
"8.6.88161162.7.8.\n"
"1366846767.4.4857\n"
"85533823.7.2742..\n"
"72.674241.3415.76\n"
"53814483543817716\n"
"7284826522245.8.5\n"
"1236.1..7.1.13.4.\n"
"238385.732358448.\n"
"58817.652.626348.\n") == 0);
free(board830422296);
board830422296 = NULL;
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_golden_move(board, 4, 9, 1) == 1 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_move(board, 6, 3, 13) == 0 );
assert( gamma_move(board, 7, 10, 0) == 0 );
assert( gamma_move(board, 7, 0, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 2) == 0 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 2, 8, 16) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 6, 0, 16) == 0 );
assert( gamma_move(board, 7, 4, 7) == 0 );
assert( gamma_move(board, 7, 13, 9) == 0 );
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 6, 5, 14) == 0 );
assert( gamma_move(board, 6, 13, 3) == 1 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_free_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 13, 9) == 0 );
assert( gamma_move(board, 7, 14, 9) == 0 );
assert( gamma_move(board, 8, 5, 14) == 0 );
assert( gamma_busy_fields(board, 8) == 22 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_free_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_move(board, 7, 5, 2) == 0 );
assert( gamma_move(board, 8, 1, 16) == 0 );
assert( gamma_move(board, 8, 0, 2) == 0 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 6, 10) == 0 );
assert( gamma_move(board, 5, 2, 16) == 0 );
assert( gamma_move(board, 6, 12, 7) == 1 );
assert( gamma_move(board, 7, 2, 14) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 9, 4) == 0 );
assert( gamma_move(board, 8, 5, 2) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 2, 15, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_golden_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_move(board, 6, 5, 9) == 0 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 7, 5, 4) == 0 );
assert( gamma_move(board, 8, 0, 5) == 0 );
assert( gamma_move(board, 1, 1, 16) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board356934788 = gamma_board(board);
assert( board356934788 != NULL );
assert( strcmp(board356934788, 
"6551.87.72464512.\n"
"8.6.88161162.7.8.\n"
"1366846767.464857\n"
"8553382347.2742..\n"
"72.674241.3415.76\n"
"53814483543817716\n"
"728482652224568.5\n"
"123611..7.1.13.4.\n"
"2383852734358448.\n"
"58817.652.626348.\n") == 0);
free(board356934788);
board356934788 = NULL;
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 8, 14) == 0 );
assert( gamma_move(board, 7, 6, 2) == 1 );
assert( gamma_move(board, 8, 9, 4) == 0 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 2, 16) == 0 );
assert( gamma_golden_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );


char* board386627317 = gamma_board(board);
assert( board386627317 != NULL );
assert( strcmp(board386627317, 
"6551.87.72464512.\n"
"8.6.88161162.7.8.\n"
"1366846767.464857\n"
"8553382347.2742..\n"
"72.674241.3415.76\n"
"53814483543817716\n"
"728482652224568.5\n"
"123611747.1.13.4.\n"
"2383852734358448.\n"
"58817.652.626348.\n") == 0);
free(board386627317);
board386627317 = NULL;


gamma_delete(board);

    return 0;
}
