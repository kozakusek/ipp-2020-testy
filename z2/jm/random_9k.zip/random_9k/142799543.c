#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 142799543
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(3, 95, 9, 29);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 76) == 1 );
assert( gamma_move(board, 1, 0, 75) == 1 );
assert( gamma_move(board, 2, 1, 93) == 1 );
assert( gamma_move(board, 4, 2, 33) == 1 );
assert( gamma_move(board, 4, 1, 85) == 1 );
assert( gamma_move(board, 5, 2, 36) == 1 );
assert( gamma_move(board, 6, 1, 36) == 1 );
assert( gamma_move(board, 7, 63, 2) == 0 );
assert( gamma_move(board, 8, 2, 39) == 1 );
assert( gamma_move(board, 9, 83, 2) == 0 );
assert( gamma_move(board, 1, 77, 1) == 0 );


char* board396589202 = gamma_board(board);
assert( board396589202 != NULL );
assert( strcmp(board396589202, 
"...\n"
".2.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"1..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..8\n"
"...\n"
"...\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board396589202);
board396589202 = NULL;
assert( gamma_move(board, 2, 1, 36) == 0 );
assert( gamma_move(board, 3, 0, 62) == 1 );
assert( gamma_move(board, 4, 78, 0) == 0 );
assert( gamma_move(board, 5, 0, 14) == 1 );
assert( gamma_move(board, 5, 0, 9) == 1 );
assert( gamma_golden_move(board, 5, 62, 0) == 0 );
assert( gamma_move(board, 6, 49, 1) == 0 );
assert( gamma_move(board, 7, 58, 2) == 0 );
assert( gamma_move(board, 7, 0, 90) == 1 );
assert( gamma_move(board, 8, 10, 2) == 0 );
assert( gamma_move(board, 8, 1, 15) == 1 );
assert( gamma_golden_move(board, 8, 85, 1) == 0 );
assert( gamma_move(board, 9, 43, 1) == 0 );
assert( gamma_free_fields(board, 9) == 272 );
assert( gamma_move(board, 1, 73, 1) == 0 );
assert( gamma_move(board, 2, 21, 0) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_free_fields(board, 3) == 272 );
assert( gamma_move(board, 4, 40, 2) == 0 );
assert( gamma_move(board, 4, 0, 48) == 1 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 6, 0, 71) == 1 );
assert( gamma_move(board, 6, 2, 48) == 1 );
assert( gamma_move(board, 7, 31, 1) == 0 );
assert( gamma_move(board, 8, 41, 2) == 0 );
assert( gamma_move(board, 8, 2, 49) == 1 );
assert( gamma_move(board, 9, 0, 28) == 1 );
assert( gamma_move(board, 1, 54, 0) == 0 );
assert( gamma_free_fields(board, 1) == 267 );
assert( gamma_move(board, 2, 32, 1) == 0 );
assert( gamma_move(board, 3, 89, 1) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 5, 74, 2) == 0 );
assert( gamma_free_fields(board, 5) == 267 );
assert( gamma_move(board, 6, 2, 14) == 1 );
assert( gamma_move(board, 6, 1, 71) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 39) == 1 );
assert( gamma_busy_fields(board, 7) == 2 );
assert( gamma_free_fields(board, 7) == 264 );


char* board338036253 = gamma_board(board);
assert( board338036253 != NULL );
assert( strcmp(board338036253, 
"...\n"
".2.\n"
"...\n"
"...\n"
"7..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"1..\n"
"...\n"
"...\n"
"...\n"
"66.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..8\n"
"4.6\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".78\n"
"...\n"
"...\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"...\n"
"...\n"
"...\n"
"9..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".8.\n"
"5.6\n"
"...\n"
"...\n"
"...\n"
"...\n"
"5..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board338036253);
board338036253 = NULL;
assert( gamma_move(board, 8, 80, 1) == 0 );
assert( gamma_move(board, 1, 70, 1) == 0 );
assert( gamma_move(board, 2, 1, 80) == 1 );
assert( gamma_move(board, 3, 2, 24) == 1 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_free_fields(board, 3) == 261 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_move(board, 4, 2, 62) == 1 );
assert( gamma_free_fields(board, 4) == 259 );
assert( gamma_move(board, 5, 0, 77) == 1 );
assert( gamma_move(board, 6, 88, 1) == 0 );
assert( gamma_move(board, 6, 1, 60) == 1 );
assert( gamma_move(board, 7, 1, 38) == 1 );
assert( gamma_move(board, 8, 88, 1) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 1, 87) == 1 );
assert( gamma_golden_move(board, 9, 24, 2) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_move(board, 2, 50, 0) == 0 );
assert( gamma_move(board, 3, 1, 91) == 1 );
assert( gamma_move(board, 4, 1, 66) == 1 );
assert( gamma_move(board, 4, 0, 31) == 1 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_move(board, 5, 1, 67) == 1 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_move(board, 6, 2, 77) == 1 );
assert( gamma_move(board, 7, 72, 0) == 0 );
assert( gamma_move(board, 7, 0, 88) == 1 );
assert( gamma_move(board, 8, 1, 26) == 1 );
assert( gamma_move(board, 8, 1, 84) == 1 );
assert( gamma_move(board, 9, 0, 59) == 1 );
assert( gamma_move(board, 9, 2, 25) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 82, 0) == 0 );
assert( gamma_move(board, 1, 0, 78) == 1 );
assert( gamma_move(board, 2, 55, 2) == 0 );
assert( gamma_move(board, 2, 1, 59) == 1 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_move(board, 3, 43, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 37) == 1 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 47) == 1 );


char* board600042770 = gamma_board(board);
assert( board600042770 != NULL );
assert( strcmp(board600042770, 
"...\n"
".2.\n"
"...\n"
".3.\n"
"7..\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
".4.\n"
".8.\n"
"...\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
".1.\n"
"1..\n"
"...\n"
"...\n"
"...\n"
"66.\n"
"...\n"
"...\n"
"...\n"
".5.\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"3.4\n"
"...\n"
".6.\n"
"92.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..8\n"
"4.6\n"
".5.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".78\n"
".7.\n"
"4..\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".8.\n"
"..9\n"
"..3\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".8.\n"
"5.6\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"5..\n"
"...\n"
"3..\n"
"5..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board600042770);
board600042770 = NULL;
assert( gamma_move(board, 6, 1, 72) == 1 );
assert( gamma_move(board, 6, 0, 93) == 1 );
assert( gamma_move(board, 7, 2, 46) == 1 );
assert( gamma_move(board, 7, 1, 25) == 1 );
assert( gamma_move(board, 8, 2, 92) == 1 );
assert( gamma_move(board, 8, 2, 85) == 1 );
assert( gamma_move(board, 9, 21, 2) == 0 );
assert( gamma_move(board, 1, 52, 2) == 0 );
assert( gamma_move(board, 1, 1, 17) == 1 );


char* board892297740 = gamma_board(board);
assert( board892297740 != NULL );
assert( strcmp(board892297740, 
"...\n"
"62.\n"
"..8\n"
".3.\n"
"7..\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
".48\n"
".8.\n"
"...\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
".1.\n"
"1..\n"
"...\n"
"...\n"
".6.\n"
"66.\n"
"...\n"
"...\n"
"...\n"
".5.\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"3.4\n"
"...\n"
".6.\n"
"92.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".78\n"
".7.\n"
"4..\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".8.\n"
".79\n"
"..3\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
".8.\n"
"5.6\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"5..\n"
"...\n"
"3..\n"
"5..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board892297740);
board892297740 = NULL;
assert( gamma_move(board, 2, 1, 83) == 1 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_move(board, 3, 61, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_move(board, 4, 40, 2) == 0 );


char* board881259761 = gamma_board(board);
assert( board881259761 != NULL );
assert( strcmp(board881259761, 
"...\n"
"62.\n"
"..8\n"
".3.\n"
"7..\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
".48\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
".1.\n"
"1..\n"
"...\n"
"...\n"
".6.\n"
"66.\n"
"...\n"
"...\n"
"...\n"
".5.\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"3.4\n"
"...\n"
".6.\n"
"92.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".78\n"
".7.\n"
"4..\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".8.\n"
".79\n"
"..3\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
".8.\n"
"5.6\n"
"...\n"
"..2\n"
"..4\n"
"...\n"
"5..\n"
"...\n"
"3..\n"
"5..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board881259761);
board881259761 = NULL;
assert( gamma_move(board, 5, 2, 37) == 1 );
assert( gamma_move(board, 6, 2, 18) == 1 );
assert( gamma_move(board, 7, 2, 66) == 1 );
assert( gamma_move(board, 8, 90, 2) == 0 );
assert( gamma_move(board, 8, 0, 5) == 1 );
assert( gamma_move(board, 9, 55, 2) == 0 );
assert( gamma_move(board, 9, 2, 15) == 1 );
assert( gamma_move(board, 1, 69, 0) == 0 );
assert( gamma_move(board, 1, 0, 85) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 1, 41) == 1 );
assert( gamma_move(board, 3, 0, 88) == 0 );
assert( gamma_free_fields(board, 3) == 224 );
assert( gamma_move(board, 4, 0, 67) == 1 );
assert( gamma_move(board, 5, 42, 1) == 0 );
assert( gamma_move(board, 6, 2, 55) == 1 );
assert( gamma_move(board, 7, 1, 0) == 1 );
assert( gamma_move(board, 7, 2, 71) == 1 );
assert( gamma_free_fields(board, 7) == 220 );
assert( gamma_move(board, 8, 1, 21) == 1 );
assert( gamma_move(board, 8, 1, 25) == 0 );
assert( gamma_move(board, 9, 0, 57) == 1 );
assert( gamma_move(board, 1, 2, 60) == 1 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 3, 47, 2) == 0 );
assert( gamma_move(board, 3, 1, 62) == 1 );
assert( gamma_golden_move(board, 3, 72, 1) == 0 );
assert( gamma_move(board, 4, 79, 2) == 0 );
assert( gamma_move(board, 5, 56, 2) == 0 );
assert( gamma_move(board, 5, 0, 74) == 1 );
assert( gamma_golden_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 6, 89, 0) == 0 );
assert( gamma_move(board, 6, 0, 31) == 0 );
assert( gamma_move(board, 7, 2, 71) == 0 );
assert( gamma_move(board, 7, 2, 33) == 0 );
assert( gamma_move(board, 8, 0, 37) == 0 );


char* board446176370 = gamma_board(board);
assert( board446176370 != NULL );
assert( strcmp(board446176370, 
"...\n"
"62.\n"
"..8\n"
".3.\n"
"7..\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
".1.\n"
"1..\n"
"5..\n"
"...\n"
".6.\n"
"667\n"
"...\n"
"...\n"
"...\n"
"45.\n"
".47\n"
"...\n"
"...\n"
"...\n"
"334\n"
"...\n"
".61\n"
"92.\n"
"...\n"
"9..\n"
"...\n"
"..6\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"...\n"
"...\n"
"...\n"
".3.\n"
"...\n"
".78\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".8.\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".1.\n"
"...\n"
".89\n"
"5.6\n"
"...\n"
"..2\n"
"..4\n"
"...\n"
"5..\n"
"2..\n"
"3..\n"
"5..\n"
"8..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".7.\n") == 0);
free(board446176370);
board446176370 = NULL;
assert( gamma_move(board, 9, 1, 73) == 1 );
assert( gamma_move(board, 9, 2, 37) == 0 );
assert( gamma_move(board, 1, 2, 93) == 1 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_move(board, 4, 58, 1) == 0 );
assert( gamma_move(board, 4, 2, 17) == 1 );
assert( gamma_move(board, 5, 2, 46) == 0 );
assert( gamma_move(board, 5, 2, 42) == 1 );


char* board240534216 = gamma_board(board);
assert( board240534216 != NULL );
assert( strcmp(board240534216, 
"...\n"
"621\n"
"..8\n"
".3.\n"
"7..\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
".1.\n"
"1..\n"
"5..\n"
".9.\n"
".6.\n"
"667\n"
"...\n"
"...\n"
"...\n"
"45.\n"
".47\n"
"...\n"
"...\n"
"...\n"
"334\n"
"...\n"
".61\n"
"92.\n"
"...\n"
"9..\n"
"...\n"
"..6\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"...\n"
"...\n"
"..5\n"
".3.\n"
"...\n"
".78\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".8.\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
"...\n"
".89\n"
"5.6\n"
"...\n"
"..2\n"
"..4\n"
"...\n"
"5..\n"
"2..\n"
"3..\n"
"5..\n"
"8..\n"
".2.\n"
"...\n"
"...\n"
"...\n"
".7.\n") == 0);
free(board240534216);
board240534216 = NULL;
assert( gamma_move(board, 6, 79, 2) == 0 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_move(board, 7, 0, 48) == 0 );
assert( gamma_move(board, 7, 2, 8) == 1 );
assert( gamma_move(board, 8, 38, 0) == 0 );
assert( gamma_move(board, 8, 1, 16) == 1 );
assert( gamma_move(board, 9, 2, 32) == 1 );
assert( gamma_free_fields(board, 9) == 206 );
assert( gamma_move(board, 1, 1, 50) == 1 );
assert( gamma_move(board, 1, 2, 70) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 44) == 1 );
assert( gamma_move(board, 3, 81, 1) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_golden_move(board, 4, 85, 0) == 0 );
assert( gamma_move(board, 5, 78, 2) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_busy_fields(board, 6) == 11 );
assert( gamma_move(board, 7, 10, 1) == 0 );
assert( gamma_free_fields(board, 8) == 203 );
assert( gamma_move(board, 9, 33, 0) == 0 );
assert( gamma_free_fields(board, 9) == 203 );
assert( gamma_move(board, 1, 0, 59) == 0 );


char* board899249449 = gamma_board(board);
assert( board899249449 != NULL );
assert( strcmp(board899249449, 
"...\n"
"621\n"
"..8\n"
".3.\n"
"7..\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
".1.\n"
"1..\n"
"5..\n"
".9.\n"
".6.\n"
"667\n"
"..1\n"
"...\n"
"...\n"
"45.\n"
".47\n"
"...\n"
"...\n"
"...\n"
"334\n"
"...\n"
".61\n"
"92.\n"
"...\n"
"9..\n"
"...\n"
"..6\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"...\n"
"..5\n"
".3.\n"
"...\n"
".78\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".8.\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
".8.\n"
".89\n"
"5.6\n"
"...\n"
"..2\n"
"..4\n"
"...\n"
"5..\n"
"2.7\n"
"3..\n"
"5..\n"
"8..\n"
".2.\n"
"...\n"
"...\n"
"...\n"
".7.\n") == 0);
free(board899249449);
board899249449 = NULL;
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 2, 2, 90) == 1 );
assert( gamma_move(board, 3, 20, 1) == 0 );
assert( gamma_move(board, 4, 77, 1) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 5, 2, 74) == 1 );


char* board292066165 = gamma_board(board);
assert( board292066165 != NULL );
assert( strcmp(board292066165, 
"...\n"
"621\n"
"..8\n"
".3.\n"
"7.2\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
".1.\n"
"1..\n"
"5.5\n"
".9.\n"
".6.\n"
"667\n"
"..1\n"
"...\n"
"...\n"
"45.\n"
".47\n"
"...\n"
"...\n"
"...\n"
"334\n"
"...\n"
".61\n"
"92.\n"
"...\n"
"9..\n"
"...\n"
"..6\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"...\n"
"..5\n"
".3.\n"
"...\n"
".78\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".8.\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
".8.\n"
".89\n"
"5.6\n"
"...\n"
"..2\n"
"..4\n"
"...\n"
"5..\n"
"2.7\n"
"3..\n"
"5..\n"
"8..\n"
".2.\n"
"...\n"
"...\n"
"..2\n"
".7.\n") == 0);
free(board292066165);
board292066165 = NULL;
assert( gamma_move(board, 6, 0, 76) == 1 );
assert( gamma_move(board, 7, 64, 1) == 0 );
assert( gamma_move(board, 8, 9, 2) == 0 );
assert( gamma_move(board, 9, 2, 51) == 1 );
assert( gamma_move(board, 9, 2, 76) == 1 );
assert( gamma_move(board, 2, 70, 1) == 0 );
assert( gamma_move(board, 2, 2, 53) == 1 );
assert( gamma_move(board, 3, 64, 1) == 0 );
assert( gamma_move(board, 4, 55, 0) == 0 );
assert( gamma_move(board, 4, 1, 68) == 1 );
assert( gamma_move(board, 5, 21, 2) == 0 );
assert( gamma_move(board, 5, 0, 39) == 1 );
assert( gamma_move(board, 6, 1, 12) == 1 );
assert( gamma_move(board, 7, 2, 8) == 0 );
assert( gamma_move(board, 8, 44, 1) == 0 );
assert( gamma_move(board, 8, 0, 15) == 1 );
assert( gamma_move(board, 9, 9, 2) == 0 );
assert( gamma_move(board, 9, 2, 26) == 1 );
assert( gamma_move(board, 1, 58, 1) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 0, 72) == 1 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 1, 71) == 0 );
assert( gamma_golden_move(board, 3, 48, 0) == 0 );


char* board169338578 = gamma_board(board);
assert( board169338578 != NULL );
assert( strcmp(board169338578, 
"...\n"
"621\n"
"..8\n"
".3.\n"
"7.2\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
"619\n"
"1..\n"
"5.5\n"
".9.\n"
"26.\n"
"667\n"
"..1\n"
"...\n"
".4.\n"
"45.\n"
".47\n"
"...\n"
"...\n"
"...\n"
"334\n"
"...\n"
".61\n"
"92.\n"
"...\n"
"9..\n"
"...\n"
"..6\n"
"...\n"
"..2\n"
"...\n"
"..9\n"
".1.\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"...\n"
"..5\n"
".3.\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".89\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
".8.\n"
"889\n"
"5.6\n"
"...\n"
".62\n"
"..4\n"
"...\n"
"5..\n"
"2.7\n"
"3..\n"
"5..\n"
"8..\n"
".2.\n"
"...\n"
"...\n"
"..2\n"
".7.\n") == 0);
free(board169338578);
board169338578 = NULL;
assert( gamma_move(board, 4, 2, 70) == 0 );
assert( gamma_move(board, 4, 0, 94) == 1 );
assert( gamma_free_fields(board, 4) == 189 );
assert( gamma_move(board, 5, 0, 11) == 1 );
assert( gamma_move(board, 5, 0, 76) == 0 );
assert( gamma_move(board, 6, 69, 0) == 0 );
assert( gamma_move(board, 6, 1, 74) == 1 );
assert( gamma_move(board, 7, 82, 1) == 0 );
assert( gamma_move(board, 7, 1, 83) == 0 );
assert( gamma_free_fields(board, 7) == 187 );
assert( gamma_move(board, 8, 13, 1) == 0 );
assert( gamma_move(board, 8, 2, 67) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 36, 0) == 0 );
assert( gamma_move(board, 3, 2, 72) == 1 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_free_fields(board, 3) == 185 );
assert( gamma_move(board, 4, 52, 2) == 0 );
assert( gamma_move(board, 4, 0, 90) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );


char* board145721187 = gamma_board(board);
assert( board145721187 != NULL );
assert( strcmp(board145721187, 
"4..\n"
"621\n"
"..8\n"
".3.\n"
"7.2\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
"619\n"
"1..\n"
"565\n"
".9.\n"
"263\n"
"667\n"
"..1\n"
"...\n"
".4.\n"
"458\n"
".47\n"
"...\n"
"...\n"
"...\n"
"334\n"
"...\n"
".61\n"
"92.\n"
"...\n"
"9..\n"
"...\n"
"..6\n"
"...\n"
"..2\n"
"...\n"
"..9\n"
".1.\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"...\n"
"..5\n"
".3.\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".89\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
".8.\n"
"889\n"
"5.6\n"
"...\n"
".62\n"
"5.4\n"
"...\n"
"5..\n"
"2.7\n"
"3..\n"
"5..\n"
"8..\n"
".2.\n"
"...\n"
"...\n"
"..2\n"
".7.\n") == 0);
free(board145721187);
board145721187 = NULL;
assert( gamma_move(board, 5, 57, 1) == 0 );
assert( gamma_move(board, 5, 0, 70) == 1 );
assert( gamma_move(board, 7, 52, 1) == 0 );
assert( gamma_move(board, 7, 2, 90) == 0 );
assert( gamma_move(board, 8, 0, 0) == 1 );
assert( gamma_move(board, 8, 1, 3) == 1 );
assert( gamma_move(board, 9, 2, 92) == 0 );
assert( gamma_move(board, 1, 88, 2) == 0 );
assert( gamma_move(board, 1, 2, 39) == 0 );


char* board893589285 = gamma_board(board);
assert( board893589285 != NULL );
assert( strcmp(board893589285, 
"4..\n"
"621\n"
"..8\n"
".3.\n"
"7.2\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"1..\n"
"5.6\n"
"619\n"
"1..\n"
"565\n"
".9.\n"
"263\n"
"667\n"
"5.1\n"
"...\n"
".4.\n"
"458\n"
".47\n"
"...\n"
"...\n"
"...\n"
"334\n"
"...\n"
".61\n"
"92.\n"
"...\n"
"9..\n"
"...\n"
"..6\n"
"...\n"
"..2\n"
"...\n"
"..9\n"
".1.\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"...\n"
"..5\n"
".3.\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".89\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
".8.\n"
"889\n"
"5.6\n"
"...\n"
".62\n"
"5.4\n"
"...\n"
"5..\n"
"2.7\n"
"3..\n"
"5..\n"
"8..\n"
".2.\n"
".8.\n"
"...\n"
"..2\n"
"87.\n") == 0);
free(board893589285);
board893589285 = NULL;
assert( gamma_move(board, 2, 2, 25) == 0 );
assert( gamma_move(board, 2, 1, 60) == 0 );
assert( gamma_move(board, 3, 1, 63) == 1 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 0, 91) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 69) == 1 );
assert( gamma_free_fields(board, 5) == 179 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 7, 81, 1) == 0 );
assert( gamma_move(board, 7, 0, 80) == 1 );


char* board628934864 = gamma_board(board);
assert( board628934864 != NULL );
assert( strcmp(board628934864, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
"72.\n"
"...\n"
"1..\n"
"5.6\n"
"619\n"
"1..\n"
"565\n"
".9.\n"
"263\n"
"667\n"
"5.1\n"
".5.\n"
".4.\n"
"458\n"
".47\n"
"...\n"
"...\n"
".3.\n"
"334\n"
"...\n"
".61\n"
"92.\n"
"...\n"
"9..\n"
"...\n"
"..6\n"
"...\n"
"..2\n"
"...\n"
"..9\n"
".1.\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"...\n"
"..5\n"
".3.\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".89\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
".8.\n"
"889\n"
"5.6\n"
"...\n"
".62\n"
"5.4\n"
"...\n"
"5..\n"
"2.7\n"
"3..\n"
"5..\n"
"8..\n"
".2.\n"
".8.\n"
"...\n"
"..2\n"
"87.\n") == 0);
free(board628934864);
board628934864 = NULL;
assert( gamma_move(board, 8, 57, 2) == 0 );
assert( gamma_move(board, 8, 0, 58) == 1 );
assert( gamma_golden_move(board, 8, 80, 0) == 0 );
assert( gamma_move(board, 9, 6, 1) == 0 );
assert( gamma_move(board, 2, 17, 0) == 0 );
assert( gamma_move(board, 4, 78, 2) == 0 );
assert( gamma_move(board, 5, 0, 59) == 0 );
assert( gamma_move(board, 6, 2, 93) == 0 );
assert( gamma_move(board, 7, 1, 57) == 1 );
assert( gamma_move(board, 7, 2, 63) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 8, 0, 69) == 1 );
assert( gamma_move(board, 9, 0, 60) == 1 );
assert( gamma_move(board, 9, 2, 66) == 0 );
assert( gamma_free_fields(board, 9) == 173 );
assert( gamma_move(board, 1, 0, 75) == 0 );
assert( gamma_move(board, 2, 29, 2) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 0, 16) == 1 );
assert( gamma_move(board, 4, 2, 53) == 0 );
assert( gamma_move(board, 5, 78, 1) == 0 );
assert( gamma_move(board, 7, 27, 1) == 0 );
assert( gamma_move(board, 7, 1, 26) == 0 );
assert( gamma_move(board, 8, 64, 1) == 0 );
assert( gamma_golden_move(board, 8, 74, 2) == 0 );
assert( gamma_move(board, 9, 33, 0) == 0 );
assert( gamma_move(board, 9, 2, 41) == 1 );
assert( gamma_free_fields(board, 9) == 171 );


char* board599803645 = gamma_board(board);
assert( board599803645 != NULL );
assert( strcmp(board599803645, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"...\n"
"7..\n"
".9.\n"
"...\n"
"148\n"
".8.\n"
".2.\n"
"...\n"
"...\n"
"72.\n"
"...\n"
"1..\n"
"5.6\n"
"619\n"
"1..\n"
"565\n"
".9.\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
".4.\n"
"458\n"
".47\n"
"...\n"
"...\n"
".37\n"
"334\n"
"...\n"
"961\n"
"92.\n"
"8..\n"
"97.\n"
"...\n"
"..6\n"
"...\n"
"..2\n"
"...\n"
"..9\n"
".1.\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"...\n"
"..5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".89\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
"48.\n"
"889\n"
"5.6\n"
"...\n"
".62\n"
"5.4\n"
"...\n"
"5..\n"
"2.7\n"
"3..\n"
"5..\n"
"8..\n"
".2.\n"
".8.\n"
"...\n"
"..2\n"
"87.\n") == 0);
free(board599803645);
board599803645 = NULL;
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 44) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 4, 0, 83) == 1 );
assert( gamma_golden_move(board, 4, 26, 1) == 0 );
assert( gamma_move(board, 5, 30, 2) == 0 );
assert( gamma_move(board, 5, 1, 54) == 1 );
assert( gamma_move(board, 6, 61, 0) == 0 );
assert( gamma_move(board, 6, 2, 43) == 1 );
assert( gamma_move(board, 7, 2, 37) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 1) == 1 );
assert( gamma_move(board, 9, 28, 1) == 0 );
assert( gamma_move(board, 9, 2, 16) == 1 );
assert( gamma_free_fields(board, 9) == 165 );
assert( gamma_move(board, 1, 2, 87) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 92) == 0 );
assert( gamma_move(board, 2, 1, 6) == 1 );
assert( gamma_move(board, 3, 58, 2) == 0 );
assert( gamma_move(board, 3, 1, 54) == 0 );


char* board775287640 = gamma_board(board);
assert( board775287640 != NULL );
assert( strcmp(board775287640, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"...\n"
"7..\n"
".91\n"
"...\n"
"148\n"
".8.\n"
"42.\n"
"...\n"
"...\n"
"72.\n"
"...\n"
"1..\n"
"5.6\n"
"619\n"
"1..\n"
"565\n"
".9.\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
".4.\n"
"458\n"
".47\n"
"...\n"
"...\n"
".37\n"
"334\n"
"...\n"
"961\n"
"92.\n"
"8..\n"
"97.\n"
"...\n"
"..6\n"
".5.\n"
"..2\n"
"...\n"
"..9\n"
".1.\n"
"..8\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"..6\n"
"..5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".89\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"...\n"
".62\n"
"5.4\n"
"3..\n"
"5..\n"
"2.7\n"
"3..\n"
"52.\n"
"8..\n"
".2.\n"
".8.\n"
"...\n"
".82\n"
"87.\n") == 0);
free(board775287640);
board775287640 = NULL;
assert( gamma_move(board, 4, 2, 13) == 1 );
assert( gamma_move(board, 4, 0, 88) == 0 );
assert( gamma_move(board, 5, 35, 2) == 0 );
assert( gamma_move(board, 6, 27, 1) == 0 );
assert( gamma_move(board, 6, 1, 49) == 1 );
assert( gamma_move(board, 7, 0, 86) == 1 );
assert( gamma_move(board, 8, 2, 90) == 0 );
assert( gamma_move(board, 9, 2, 37) == 0 );
assert( gamma_move(board, 9, 2, 75) == 1 );
assert( gamma_busy_fields(board, 9) == 15 );
assert( gamma_move(board, 1, 61, 2) == 0 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 2, 2, 18) == 0 );
assert( gamma_move(board, 3, 89, 1) == 0 );
assert( gamma_move(board, 3, 2, 59) == 1 );
assert( gamma_move(board, 4, 0, 78) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 8, 64, 1) == 0 );
assert( gamma_move(board, 9, 32, 0) == 0 );
assert( gamma_busy_fields(board, 9) == 15 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 43, 1) == 0 );
assert( gamma_move(board, 2, 0, 81) == 1 );
assert( gamma_free_fields(board, 2) == 156 );
assert( gamma_move(board, 3, 0, 16) == 0 );
assert( gamma_move(board, 3, 2, 55) == 0 );


char* board628437607 = gamma_board(board);
assert( board628437607 != NULL );
assert( strcmp(board628437607, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"...\n"
"7..\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"...\n"
"2..\n"
"72.\n"
"...\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".9.\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
".4.\n"
"458\n"
".47\n"
"...\n"
"...\n"
".37\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"...\n"
"..6\n"
".5.\n"
"..2\n"
"...\n"
"..9\n"
".1.\n"
".68\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"..6\n"
"..5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
"...\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
"...\n"
".89\n"
".79\n"
"..3\n"
"...\n"
"...\n"
".8.\n"
"...\n"
"...\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"2.7\n"
"3..\n"
"52.\n"
"8..\n"
".2.\n"
".8.\n"
"...\n"
".82\n"
"87.\n") == 0);
free(board628437607);
board628437607 = NULL;
assert( gamma_move(board, 4, 68, 0) == 0 );
assert( gamma_move(board, 5, 27, 2) == 0 );
assert( gamma_move(board, 5, 1, 93) == 0 );
assert( gamma_golden_move(board, 5, 49, 2) == 0 );
assert( gamma_move(board, 6, 34, 1) == 0 );
assert( gamma_move(board, 6, 0, 43) == 1 );
assert( gamma_move(board, 7, 2, 36) == 0 );
assert( gamma_move(board, 7, 1, 20) == 1 );
assert( gamma_move(board, 8, 2, 68) == 1 );
assert( gamma_free_fields(board, 8) == 153 );
assert( gamma_move(board, 9, 75, 1) == 0 );
assert( gamma_move(board, 1, 0, 63) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_golden_move(board, 2, 39, 2) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 77, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 58, 2) == 0 );
assert( gamma_move(board, 6, 27, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 38) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_free_fields(board, 7) == 150 );
assert( gamma_move(board, 8, 44, 2) == 0 );
assert( gamma_move(board, 8, 2, 82) == 1 );
assert( gamma_move(board, 9, 1, 22) == 1 );
assert( gamma_move(board, 1, 48, 1) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 0, 44) == 0 );
assert( gamma_move(board, 3, 2, 74) == 0 );
assert( gamma_move(board, 3, 2, 79) == 1 );
assert( gamma_move(board, 4, 64, 2) == 0 );
assert( gamma_move(board, 4, 2, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 94) == 0 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 6, 0, 26) == 1 );
assert( gamma_move(board, 7, 0, 55) == 1 );
assert( gamma_move(board, 7, 2, 25) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 2, 65) == 1 );
assert( gamma_free_fields(board, 8) == 143 );
assert( gamma_move(board, 9, 1, 24) == 1 );
assert( gamma_move(board, 1, 50, 2) == 0 );
assert( gamma_move(board, 2, 70, 1) == 0 );
assert( gamma_free_fields(board, 2) == 142 );
assert( gamma_move(board, 3, 42, 0) == 0 );
assert( gamma_move(board, 3, 2, 21) == 1 );
assert( gamma_move(board, 4, 64, 1) == 0 );
assert( gamma_move(board, 4, 1, 73) == 0 );
assert( gamma_move(board, 5, 1, 51) == 1 );
assert( gamma_move(board, 6, 1, 22) == 0 );
assert( gamma_move(board, 7, 24, 0) == 0 );
assert( gamma_move(board, 7, 2, 56) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 36, 0) == 0 );
assert( gamma_free_fields(board, 8) == 139 );
assert( gamma_move(board, 9, 1, 35) == 1 );
assert( gamma_busy_fields(board, 9) == 18 );
assert( gamma_free_fields(board, 9) == 138 );
assert( gamma_move(board, 1, 1, 27) == 1 );
assert( gamma_golden_move(board, 1, 43, 0) == 0 );
assert( gamma_move(board, 3, 19, 1) == 0 );
assert( gamma_move(board, 3, 1, 52) == 1 );
assert( gamma_move(board, 4, 38, 2) == 0 );
assert( gamma_move(board, 5, 23, 1) == 0 );
assert( gamma_move(board, 5, 2, 33) == 0 );


char* board530342289 = gamma_board(board);
assert( board530342289 != NULL );
assert( strcmp(board530342289, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"...\n"
"7..\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"..8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".9.\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
".48\n"
"458\n"
".47\n"
"..8\n"
"...\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"..7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
".68\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"6.6\n"
"..5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9..\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"...\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"2.7\n"
"3..\n"
"522\n"
"8..\n"
".24\n"
"38.\n"
"...\n"
".82\n"
"87.\n") == 0);
free(board530342289);
board530342289 = NULL;
assert( gamma_move(board, 6, 82, 1) == 0 );
assert( gamma_move(board, 7, 1, 25) == 0 );
assert( gamma_move(board, 7, 2, 51) == 0 );
assert( gamma_move(board, 8, 18, 0) == 0 );
assert( gamma_move(board, 9, 33, 1) == 0 );
assert( gamma_move(board, 1, 0, 68) == 1 );
assert( gamma_move(board, 2, 81, 2) == 0 );
assert( gamma_move(board, 2, 2, 79) == 0 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 31, 2) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 6, 0, 89) == 1 );
assert( gamma_move(board, 6, 1, 20) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 56) == 1 );
assert( gamma_move(board, 8, 2, 28) == 1 );
assert( gamma_golden_move(board, 8, 37, 2) == 0 );
assert( gamma_move(board, 9, 28, 1) == 0 );
assert( gamma_move(board, 9, 1, 66) == 0 );
assert( gamma_move(board, 1, 2, 73) == 1 );
assert( gamma_golden_move(board, 1, 41, 2) == 0 );


char* board742564046 = gamma_board(board);
assert( board742564046 != NULL );
assert( strcmp(board742564046, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7..\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"..8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
"...\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
".68\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"6.6\n"
"..5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"...\n"
"..4\n"
"..9\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"...\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"2.7\n"
"3..\n"
"522\n"
"8..\n"
".24\n"
"38.\n"
"...\n"
".82\n"
"87.\n") == 0);
free(board742564046);
board742564046 = NULL;
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 33, 1) == 0 );
assert( gamma_move(board, 4, 2, 34) == 1 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 92, 0) == 0 );
assert( gamma_move(board, 6, 35, 0) == 0 );
assert( gamma_move(board, 6, 2, 74) == 0 );
assert( gamma_busy_fields(board, 6) == 19 );
assert( gamma_move(board, 7, 2, 19) == 1 );
assert( gamma_move(board, 8, 1, 62) == 0 );
assert( gamma_move(board, 9, 82, 0) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 19, 0) == 0 );
assert( gamma_move(board, 3, 0, 82) == 1 );
assert( gamma_move(board, 4, 2, 67) == 0 );
assert( gamma_free_fields(board, 4) == 128 );
assert( gamma_move(board, 5, 54, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_move(board, 6, 0, 89) == 0 );
assert( gamma_free_fields(board, 6) == 128 );
assert( gamma_move(board, 8, 50, 2) == 0 );
assert( gamma_busy_fields(board, 8) == 21 );
assert( gamma_move(board, 9, 2, 49) == 0 );
assert( gamma_busy_fields(board, 9) == 18 );
assert( gamma_move(board, 1, 54, 0) == 0 );
assert( gamma_move(board, 2, 2, 65) == 0 );
assert( gamma_move(board, 2, 1, 32) == 1 );
assert( gamma_golden_move(board, 2, 46, 2) == 0 );
assert( gamma_move(board, 3, 81, 2) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 5, 46, 1) == 0 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 7, 61, 2) == 0 );
assert( gamma_move(board, 8, 29, 2) == 0 );
assert( gamma_move(board, 8, 0, 89) == 0 );
assert( gamma_move(board, 9, 11, 1) == 0 );
assert( gamma_move(board, 9, 0, 3) == 0 );
assert( gamma_busy_fields(board, 9) == 18 );


char* board904754707 = gamma_board(board);
assert( board904754707 != NULL );
assert( strcmp(board904754707, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7..\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
"...\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
".68\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"6.6\n"
"..5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"2.7\n"
"3..\n"
"522\n"
"8..\n"
".24\n"
"38.\n"
"...\n"
".82\n"
"87.\n") == 0);
free(board904754707);
board904754707 = NULL;
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 86, 0) == 0 );
assert( gamma_move(board, 3, 1, 67) == 0 );
assert( gamma_move(board, 3, 2, 49) == 0 );
assert( gamma_move(board, 4, 0, 42) == 1 );
assert( gamma_move(board, 4, 1, 39) == 0 );
assert( gamma_move(board, 5, 27, 0) == 0 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_move(board, 6, 70, 1) == 0 );
assert( gamma_golden_move(board, 6, 91, 1) == 0 );
assert( gamma_move(board, 7, 0, 14) == 0 );
assert( gamma_move(board, 8, 82, 1) == 0 );


char* board151177448 = gamma_board(board);
assert( board151177448 != NULL );
assert( strcmp(board151177448, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7..\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
"...\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
".68\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"6.6\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
".24\n"
"38.\n"
"...\n"
".82\n"
"87.\n") == 0);
free(board151177448);
board151177448 = NULL;
assert( gamma_move(board, 9, 27, 0) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 2, 88) == 1 );
assert( gamma_move(board, 2, 0, 49) == 1 );
assert( gamma_move(board, 3, 61, 1) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_free_fields(board, 4) == 123 );


char* board876989409 = gamma_board(board);
assert( board876989409 != NULL );
assert( strcmp(board876989409, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7.1\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
"...\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
"268\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"6.6\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
".24\n"
"38.\n"
"...\n"
".82\n"
"87.\n") == 0);
free(board876989409);
board876989409 = NULL;
assert( gamma_move(board, 6, 14, 1) == 0 );
assert( gamma_move(board, 7, 55, 1) == 0 );


char* board128151778 = gamma_board(board);
assert( board128151778 != NULL );
assert( strcmp(board128151778, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7.1\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
"...\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
"268\n"
"4.6\n"
".5.\n"
"..7\n"
"...\n"
"2..\n"
"6.6\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
".24\n"
"38.\n"
"...\n"
".82\n"
"87.\n") == 0);
free(board128151778);
board128151778 = NULL;
assert( gamma_move(board, 8, 92, 0) == 0 );
assert( gamma_move(board, 8, 2, 6) == 0 );
assert( gamma_move(board, 9, 35, 0) == 0 );
assert( gamma_move(board, 1, 31, 1) == 0 );
assert( gamma_move(board, 1, 0, 46) == 1 );
assert( gamma_move(board, 2, 81, 1) == 0 );
assert( gamma_free_fields(board, 2) == 122 );
assert( gamma_move(board, 3, 22, 2) == 0 );
assert( gamma_move(board, 3, 2, 56) == 0 );
assert( gamma_move(board, 4, 87, 0) == 0 );
assert( gamma_move(board, 4, 0, 47) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 6, 0, 2) == 1 );
assert( gamma_move(board, 7, 13, 1) == 0 );
assert( gamma_move(board, 7, 2, 36) == 0 );
assert( gamma_busy_fields(board, 7) == 19 );
assert( gamma_golden_move(board, 7, 48, 0) == 0 );
assert( gamma_move(board, 8, 1, 64) == 1 );
assert( gamma_move(board, 8, 1, 63) == 0 );
assert( gamma_move(board, 9, 1, 63) == 0 );
assert( gamma_move(board, 1, 2, 64) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 2, 1, 80) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board403875306 = gamma_board(board);
assert( board403875306 != NULL );
assert( strcmp(board403875306, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7.1\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
"268\n"
"4.6\n"
"45.\n"
"1.7\n"
"...\n"
"2..\n"
"6.6\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
"124\n"
"38.\n"
"6..\n"
".82\n"
"87.\n") == 0);
free(board403875306);
board403875306 = NULL;
assert( gamma_move(board, 3, 0, 55) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 0, 48) == 0 );
assert( gamma_move(board, 5, 0, 94) == 0 );
assert( gamma_move(board, 6, 92, 1) == 0 );
assert( gamma_move(board, 6, 2, 74) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_free_fields(board, 6) == 117 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 8, 51, 0) == 0 );
assert( gamma_free_fields(board, 8) == 117 );
assert( gamma_move(board, 9, 22, 0) == 0 );
assert( gamma_move(board, 9, 2, 15) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 94, 1) == 0 );
assert( gamma_move(board, 2, 1, 25) == 0 );
assert( gamma_move(board, 3, 2, 71) == 0 );
assert( gamma_golden_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 29, 1) == 0 );
assert( gamma_move(board, 5, 1, 26) == 0 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 6, 78, 2) == 0 );
assert( gamma_move(board, 6, 1, 57) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 7, 24, 0) == 0 );
assert( gamma_move(board, 8, 31, 2) == 0 );
assert( gamma_move(board, 8, 1, 36) == 0 );


char* board935449973 = gamma_board(board);
assert( board935449973 != NULL );
assert( strcmp(board935449973, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7.1\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
"268\n"
"4.6\n"
"45.\n"
"1.7\n"
"...\n"
"2..\n"
"6.6\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
"124\n"
"38.\n"
"6..\n"
".32\n"
"87.\n") == 0);
free(board935449973);
board935449973 = NULL;
assert( gamma_move(board, 9, 64, 0) == 0 );
assert( gamma_move(board, 9, 0, 5) == 0 );


char* board344755197 = gamma_board(board);
assert( board344755197 != NULL );
assert( strcmp(board344755197, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7.1\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
"268\n"
"4.6\n"
"45.\n"
"1.7\n"
"...\n"
"2..\n"
"6.6\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
"124\n"
"38.\n"
"6..\n"
".32\n"
"87.\n") == 0);
free(board344755197);
board344755197 = NULL;
assert( gamma_move(board, 1, 0, 5) == 0 );


char* board508878044 = gamma_board(board);
assert( board508878044 != NULL );
assert( strcmp(board508878044, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"7.1\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"...\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
".1.\n"
"268\n"
"4.6\n"
"45.\n"
"1.7\n"
"...\n"
"2..\n"
"6.6\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"...\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
"124\n"
"38.\n"
"6..\n"
".32\n"
"87.\n") == 0);
free(board508878044);
board508878044 = NULL;
assert( gamma_move(board, 2, 45, 2) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 92, 1) == 0 );
assert( gamma_move(board, 3, 1, 87) == 0 );
assert( gamma_move(board, 5, 45, 0) == 0 );
assert( gamma_move(board, 7, 40, 1) == 0 );
assert( gamma_move(board, 7, 2, 18) == 0 );
assert( gamma_busy_fields(board, 7) == 19 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 54, 2) == 0 );
assert( gamma_move(board, 8, 2, 67) == 0 );
assert( gamma_move(board, 9, 0, 50) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 94, 2) == 0 );
assert( gamma_move(board, 2, 55, 1) == 0 );
assert( gamma_move(board, 2, 1, 43) == 1 );
assert( gamma_move(board, 3, 40, 0) == 0 );
assert( gamma_move(board, 3, 1, 59) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 19, 0) == 0 );
assert( gamma_move(board, 6, 2, 92) == 0 );
assert( gamma_move(board, 6, 2, 25) == 0 );
assert( gamma_free_fields(board, 6) == 114 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_move(board, 8, 27, 0) == 0 );
assert( gamma_move(board, 8, 1, 44) == 1 );
assert( gamma_golden_move(board, 8, 36, 2) == 0 );
assert( gamma_move(board, 9, 87, 0) == 0 );
assert( gamma_move(board, 9, 2, 61) == 1 );
assert( gamma_move(board, 1, 2, 65) == 0 );
assert( gamma_move(board, 2, 90, 1) == 0 );
assert( gamma_move(board, 2, 2, 53) == 0 );
assert( gamma_move(board, 3, 23, 2) == 0 );
assert( gamma_move(board, 3, 2, 64) == 0 );
assert( gamma_move(board, 4, 40, 1) == 0 );
assert( gamma_move(board, 5, 32, 0) == 0 );
assert( gamma_move(board, 5, 1, 88) == 1 );
assert( gamma_move(board, 6, 20, 0) == 0 );
assert( gamma_move(board, 6, 2, 30) == 1 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_move(board, 7, 61, 1) == 0 );
assert( gamma_move(board, 8, 92, 0) == 0 );
assert( gamma_move(board, 9, 33, 1) == 0 );
assert( gamma_move(board, 9, 2, 87) == 0 );
assert( gamma_move(board, 1, 91, 2) == 0 );


char* board169760115 = gamma_board(board);
assert( board169760115 != NULL );
assert( strcmp(board169760115, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
".91\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"..9\n"
"961\n"
"923\n"
"8..\n"
"97.\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
"91.\n"
"268\n"
"4.6\n"
"45.\n"
"1.7\n"
"...\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
".7.\n"
"4.5\n"
".65\n"
".9.\n"
"..4\n"
"..4\n"
".29\n"
"4..\n"
"..6\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"..7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"..4\n"
".62\n"
"5.4\n"
"3..\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
"124\n"
"382\n"
"6..\n"
".32\n"
"87.\n") == 0);
free(board169760115);
board169760115 = NULL;
assert( gamma_move(board, 2, 0, 48) == 0 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 3, 37, 1) == 0 );
assert( gamma_move(board, 3, 1, 91) == 0 );
assert( gamma_move(board, 4, 29, 0) == 0 );
assert( gamma_move(board, 5, 53, 1) == 0 );
assert( gamma_move(board, 6, 1, 63) == 0 );
assert( gamma_move(board, 6, 0, 19) == 1 );
assert( gamma_move(board, 7, 31, 2) == 0 );
assert( gamma_move(board, 7, 2, 34) == 0 );
assert( gamma_move(board, 8, 0, 38) == 1 );
assert( gamma_move(board, 9, 38, 2) == 0 );
assert( gamma_busy_fields(board, 9) == 20 );
assert( gamma_move(board, 1, 2, 45) == 1 );
assert( gamma_move(board, 2, 0, 19) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 31, 1) == 0 );
assert( gamma_move(board, 6, 61, 1) == 0 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_move(board, 7, 17, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 81, 1) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 73, 0) == 0 );
assert( gamma_move(board, 9, 1, 36) == 0 );
assert( gamma_move(board, 1, 34, 0) == 0 );
assert( gamma_move(board, 1, 0, 34) == 1 );
assert( gamma_move(board, 2, 1, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 70) == 0 );
assert( gamma_move(board, 4, 2, 35) == 1 );
assert( gamma_move(board, 4, 1, 58) == 1 );
assert( gamma_move(board, 5, 2, 53) == 0 );
assert( gamma_move(board, 5, 2, 21) == 0 );
assert( gamma_golden_move(board, 5, 66, 1) == 0 );
assert( gamma_move(board, 6, 12, 0) == 0 );
assert( gamma_move(board, 7, 0, 87) == 1 );
assert( gamma_move(board, 8, 36, 0) == 0 );
assert( gamma_move(board, 8, 0, 7) == 0 );
assert( gamma_move(board, 9, 80, 2) == 0 );
assert( gamma_move(board, 1, 47, 2) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 54, 2) == 0 );
assert( gamma_move(board, 2, 2, 70) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 1, 33) == 1 );
assert( gamma_move(board, 4, 30, 1) == 0 );
assert( gamma_move(board, 5, 2, 57) == 1 );
assert( gamma_move(board, 5, 0, 71) == 0 );
assert( gamma_free_fields(board, 5) == 99 );
assert( gamma_move(board, 6, 47, 2) == 0 );
assert( gamma_move(board, 7, 37, 1) == 0 );
assert( gamma_move(board, 7, 2, 47) == 1 );
assert( gamma_move(board, 8, 32, 0) == 0 );
assert( gamma_move(board, 8, 0, 4) == 0 );


char* board152930741 = gamma_board(board);
assert( board152930741 != NULL );
assert( strcmp(board152930741, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"7..\n"
"148\n"
".8.\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"..9\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
"91.\n"
"268\n"
"4.6\n"
"457\n"
"1.7\n"
"..1\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
"87.\n"
"4.5\n"
".65\n"
".94\n"
"1.4\n"
".34\n"
".29\n"
"4..\n"
"..6\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"6.7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"5.4\n"
"3.6\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
"124\n"
"382\n"
"6..\n"
".32\n"
"87.\n") == 0);
free(board152930741);
board152930741 = NULL;
assert( gamma_move(board, 9, 2, 34) == 0 );
assert( gamma_move(board, 1, 1, 38) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 2, 2, 84) == 1 );
assert( gamma_move(board, 2, 2, 62) == 0 );
assert( gamma_move(board, 3, 2, 55) == 0 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_free_fields(board, 3) == 97 );


char* board733446586 = gamma_board(board);
assert( board733446586 != NULL );
assert( strcmp(board733446586, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"7..\n"
"148\n"
".82\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"..9\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
".59\n"
"91.\n"
"268\n"
"4.6\n"
"457\n"
"1.7\n"
"..1\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
"87.\n"
"4.5\n"
".65\n"
".94\n"
"1.4\n"
".34\n"
".29\n"
"4..\n"
"..6\n"
"...\n"
"9.8\n"
".1.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"6.7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"5.4\n"
"3.6\n"
"5.1\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
"124\n"
"382\n"
"6..\n"
".32\n"
"87.\n") == 0);
free(board733446586);
board733446586 = NULL;
assert( gamma_move(board, 4, 84, 0) == 0 );
assert( gamma_move(board, 5, 1, 69) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_free_fields(board, 5) == 97 );
assert( gamma_move(board, 6, 92, 0) == 0 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_free_fields(board, 6) == 97 );
assert( gamma_move(board, 7, 94, 2) == 0 );
assert( gamma_move(board, 7, 1, 49) == 0 );
assert( gamma_move(board, 8, 24, 0) == 0 );
assert( gamma_move(board, 8, 1, 9) == 1 );
assert( gamma_move(board, 9, 29, 2) == 0 );
assert( gamma_move(board, 9, 1, 46) == 1 );
assert( gamma_free_fields(board, 9) == 95 );
assert( gamma_move(board, 1, 0, 27) == 1 );
assert( gamma_free_fields(board, 1) == 94 );
assert( gamma_move(board, 2, 81, 1) == 0 );
assert( gamma_move(board, 2, 1, 64) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 4, 40, 2) == 0 );
assert( gamma_move(board, 5, 42, 1) == 0 );
assert( gamma_move(board, 6, 24, 0) == 0 );
assert( gamma_move(board, 7, 73, 0) == 0 );
assert( gamma_move(board, 7, 2, 36) == 0 );
assert( gamma_move(board, 8, 19, 1) == 0 );
assert( gamma_move(board, 9, 2, 92) == 0 );
assert( gamma_move(board, 1, 45, 1) == 0 );
assert( gamma_move(board, 1, 0, 77) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 78, 2) == 0 );
assert( gamma_free_fields(board, 2) == 93 );
assert( gamma_move(board, 3, 82, 1) == 0 );
assert( gamma_move(board, 4, 65, 0) == 0 );
assert( gamma_move(board, 4, 0, 81) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 30, 0) == 0 );
assert( gamma_move(board, 6, 2, 88) == 0 );
assert( gamma_move(board, 7, 45, 1) == 0 );
assert( gamma_move(board, 7, 0, 80) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 0, 51) == 1 );


char* board601395678 = gamma_board(board);
assert( board601395678 != NULL );
assert( strcmp(board601395678, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"7..\n"
"148\n"
".82\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"1.9\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"85.\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"..9\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"7.7\n"
"7.6\n"
".5.\n"
"..2\n"
".3.\n"
"859\n"
"91.\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
"..1\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
"...\n"
"578\n"
"87.\n"
"4.5\n"
".65\n"
".94\n"
"1.4\n"
".34\n"
".29\n"
"4..\n"
"..6\n"
"...\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
".93\n"
"...\n"
".9.\n"
".83\n"
".7.\n"
"6.7\n"
"..6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"5.4\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8..\n"
"124\n"
"382\n"
"63.\n"
".32\n"
"87.\n") == 0);
free(board601395678);
board601395678 = NULL;
assert( gamma_move(board, 9, 79, 0) == 0 );
assert( gamma_move(board, 1, 90, 1) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 80, 2) == 0 );
assert( gamma_move(board, 2, 0, 24) == 1 );
assert( gamma_move(board, 3, 69, 2) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 86) == 1 );
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 5, 0, 58) == 0 );
assert( gamma_move(board, 6, 1, 76) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 7, 53, 0) == 0 );
assert( gamma_move(board, 7, 1, 49) == 0 );
assert( gamma_move(board, 8, 89, 2) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 2, 38) == 1 );
assert( gamma_move(board, 9, 1, 17) == 0 );
assert( gamma_move(board, 1, 1, 40) == 1 );
assert( gamma_move(board, 2, 70, 1) == 0 );
assert( gamma_move(board, 2, 2, 40) == 1 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 4, 82, 1) == 0 );
assert( gamma_move(board, 4, 2, 26) == 0 );
assert( gamma_move(board, 5, 80, 2) == 0 );
assert( gamma_move(board, 6, 1, 56) == 1 );
assert( gamma_move(board, 6, 2, 5) == 1 );
assert( gamma_move(board, 7, 1, 23) == 1 );
assert( gamma_move(board, 8, 2, 79) == 0 );
assert( gamma_move(board, 8, 0, 59) == 0 );
assert( gamma_move(board, 9, 2, 47) == 0 );
assert( gamma_busy_fields(board, 9) == 22 );
assert( gamma_move(board, 1, 0, 88) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 89, 2) == 0 );
assert( gamma_move(board, 2, 0, 52) == 1 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 4, 82, 1) == 0 );
assert( gamma_free_fields(board, 4) == 82 );
assert( gamma_move(board, 5, 53, 0) == 0 );
assert( gamma_move(board, 5, 2, 70) == 0 );
assert( gamma_golden_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 44, 2) == 0 );
assert( gamma_move(board, 6, 0, 26) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 11) == 1 );
assert( gamma_move(board, 8, 10, 1) == 0 );
assert( gamma_move(board, 8, 0, 80) == 0 );
assert( gamma_move(board, 9, 2, 1) == 0 );
assert( gamma_move(board, 1, 1, 93) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 4, 1, 74) == 0 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 0, 84) == 1 );
assert( gamma_move(board, 5, 2, 33) == 0 );
assert( gamma_move(board, 6, 0, 91) == 0 );
assert( gamma_move(board, 6, 2, 38) == 0 );
assert( gamma_move(board, 7, 65, 0) == 0 );
assert( gamma_move(board, 8, 0, 15) == 0 );
assert( gamma_move(board, 9, 0, 18) == 1 );
assert( gamma_move(board, 9, 1, 6) == 0 );
assert( gamma_move(board, 1, 1, 34) == 1 );
assert( gamma_move(board, 1, 0, 36) == 1 );
assert( gamma_move(board, 2, 2, 50) == 1 );
assert( gamma_move(board, 2, 2, 26) == 0 );
assert( gamma_move(board, 4, 1, 75) == 1 );
assert( gamma_move(board, 5, 2, 46) == 0 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 7, 54, 0) == 0 );
assert( gamma_move(board, 7, 1, 93) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 2, 74) == 0 );
assert( gamma_free_fields(board, 8) == 75 );
assert( gamma_move(board, 9, 54, 2) == 0 );
assert( gamma_free_fields(board, 9) == 75 );
assert( gamma_move(board, 1, 65, 1) == 0 );
assert( gamma_move(board, 1, 0, 49) == 0 );
assert( gamma_move(board, 2, 45, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 2, 69) == 1 );
assert( gamma_move(board, 4, 0, 85) == 0 );
assert( gamma_move(board, 5, 1, 55) == 1 );
assert( gamma_move(board, 5, 1, 61) == 1 );
assert( gamma_move(board, 6, 65, 0) == 0 );
assert( gamma_move(board, 7, 65, 0) == 0 );
assert( gamma_move(board, 7, 2, 88) == 0 );


char* board174849981 = gamma_board(board);
assert( board174849981 != NULL );
assert( strcmp(board174849981, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2..\n"
"72.\n"
"..3\n"
"1..\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
".59\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
".5.\n"
"..2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
"..1\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
".12\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"..6\n"
"...\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".9.\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board174849981);
board174849981 = NULL;
assert( gamma_move(board, 8, 53, 0) == 0 );
assert( gamma_move(board, 8, 0, 79) == 1 );
assert( gamma_move(board, 9, 0, 2) == 0 );
assert( gamma_move(board, 1, 0, 48) == 0 );
assert( gamma_move(board, 2, 0, 87) == 0 );
assert( gamma_move(board, 2, 0, 30) == 1 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 25, 0) == 0 );
assert( gamma_move(board, 4, 35, 0) == 0 );
assert( gamma_move(board, 5, 37, 1) == 0 );
assert( gamma_move(board, 6, 23, 0) == 0 );
assert( gamma_move(board, 7, 78, 2) == 0 );
assert( gamma_move(board, 7, 1, 4) == 0 );
assert( gamma_move(board, 8, 2, 22) == 1 );
assert( gamma_move(board, 9, 2, 80) == 1 );
assert( gamma_move(board, 9, 1, 20) == 0 );
assert( gamma_move(board, 1, 27, 2) == 0 );


char* board750478848 = gamma_board(board);
assert( board750478848 != NULL );
assert( strcmp(board750478848, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2..\n"
"729\n"
"8.3\n"
"1..\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
".59\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
".5.\n"
"..2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
"..1\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
".12\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
"...\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board750478848);
board750478848 = NULL;
assert( gamma_move(board, 2, 37, 1) == 0 );
assert( gamma_move(board, 2, 0, 54) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_golden_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 5, 0, 46) == 0 );
assert( gamma_move(board, 6, 2, 81) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 45) == 1 );
assert( gamma_move(board, 8, 1, 78) == 1 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 2, 76) == 0 );
assert( gamma_move(board, 2, 0, 63) == 0 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 30, 1) == 0 );
assert( gamma_move(board, 3, 0, 40) == 1 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_move(board, 5, 31, 2) == 0 );
assert( gamma_move(board, 6, 89, 2) == 0 );
assert( gamma_move(board, 7, 73, 0) == 0 );
assert( gamma_move(board, 8, 2, 43) == 0 );


char* board929462930 = gamma_board(board);
assert( board929462930 != NULL );
assert( strcmp(board929462930, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2.6\n"
"729\n"
"8.3\n"
"18.\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
".59\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
"25.\n"
"..2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
".71\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
"312\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
"...\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board929462930);
board929462930 = NULL;
assert( gamma_move(board, 9, 94, 2) == 0 );
assert( gamma_move(board, 9, 2, 70) == 0 );
assert( gamma_move(board, 1, 0, 86) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 47) == 0 );
assert( gamma_move(board, 2, 1, 78) == 0 );


char* board492274147 = gamma_board(board);
assert( board492274147 != NULL );
assert( strcmp(board492274147, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2.6\n"
"729\n"
"8.3\n"
"18.\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
".59\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
"25.\n"
"..2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
".71\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
"312\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
"...\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board492274147);
board492274147 = NULL;
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );


char* board893744809 = gamma_board(board);
assert( board893744809 != NULL );
assert( strcmp(board893744809, 
"4..\n"
"621\n"
"..8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2.6\n"
"729\n"
"8.3\n"
"18.\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
".59\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
"25.\n"
"..2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
".71\n"
"28.\n"
"626\n"
"4.5\n"
".39\n"
"312\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
"...\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board893744809);
board893744809 = NULL;
assert( gamma_move(board, 5, 65, 0) == 0 );
assert( gamma_move(board, 5, 1, 29) == 1 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_move(board, 7, 22, 0) == 0 );
assert( gamma_move(board, 7, 0, 92) == 1 );
assert( gamma_move(board, 8, 0, 2) == 0 );
assert( gamma_move(board, 9, 23, 2) == 0 );
assert( gamma_move(board, 1, 83, 2) == 0 );
assert( gamma_golden_move(board, 1, 45, 1) == 0 );
assert( gamma_move(board, 2, 18, 1) == 0 );
assert( gamma_move(board, 2, 0, 41) == 1 );
assert( gamma_move(board, 3, 0, 88) == 0 );
assert( gamma_move(board, 4, 54, 2) == 0 );


char* board886751432 = gamma_board(board);
assert( board886751432 != NULL );
assert( strcmp(board886751432, 
"4..\n"
"621\n"
"7.8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2.6\n"
"729\n"
"8.3\n"
"18.\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
".59\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
"25.\n"
"..2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
".71\n"
"28.\n"
"626\n"
"4.5\n"
"239\n"
"312\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
".5.\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
".24\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board886751432);
board886751432 = NULL;
assert( gamma_move(board, 5, 1, 86) == 0 );
assert( gamma_move(board, 5, 0, 13) == 1 );
assert( gamma_move(board, 6, 92, 1) == 0 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_move(board, 8, 37, 1) == 0 );
assert( gamma_move(board, 9, 19, 1) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 0, 85) == 0 );
assert( gamma_move(board, 1, 0, 72) == 0 );
assert( gamma_free_fields(board, 1) == 59 );


char* board178704966 = gamma_board(board);
assert( board178704966 != NULL );
assert( strcmp(board178704966, 
"4..\n"
"621\n"
"7.8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2.6\n"
"729\n"
"8.3\n"
"18.\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
".59\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
"25.\n"
"..2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
".71\n"
"28.\n"
"626\n"
"4.5\n"
"239\n"
"312\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
".5.\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"524\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board178704966);
board178704966 = NULL;
assert( gamma_move(board, 2, 0, 62) == 0 );
assert( gamma_move(board, 2, 1, 66) == 0 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_free_fields(board, 4) == 59 );
assert( gamma_move(board, 5, 2, 30) == 0 );
assert( gamma_move(board, 5, 0, 44) == 0 );
assert( gamma_move(board, 6, 1, 43) == 0 );
assert( gamma_move(board, 6, 0, 53) == 1 );
assert( gamma_free_fields(board, 6) == 58 );
assert( gamma_move(board, 7, 29, 2) == 0 );
assert( gamma_move(board, 7, 1, 4) == 0 );
assert( gamma_free_fields(board, 7) == 58 );
assert( gamma_move(board, 8, 44, 2) == 0 );
assert( gamma_move(board, 8, 2, 63) == 0 );
assert( gamma_free_fields(board, 8) == 58 );
assert( gamma_move(board, 1, 23, 2) == 0 );
assert( gamma_move(board, 1, 2, 66) == 0 );
assert( gamma_move(board, 2, 58, 2) == 0 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_move(board, 5, 1, 25) == 0 );
assert( gamma_move(board, 6, 42, 1) == 0 );
assert( gamma_free_fields(board, 6) == 58 );
assert( gamma_move(board, 8, 61, 0) == 0 );
assert( gamma_move(board, 9, 0, 29) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 1, 79) == 1 );
assert( gamma_move(board, 2, 70, 1) == 0 );
assert( gamma_golden_move(board, 2, 39, 1) == 0 );
assert( gamma_move(board, 3, 0, 61) == 1 );
assert( gamma_move(board, 4, 91, 2) == 0 );
assert( gamma_move(board, 4, 2, 18) == 0 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 5, 0, 50) == 0 );
assert( gamma_free_fields(board, 5) == 55 );
assert( gamma_move(board, 7, 0, 34) == 0 );


char* board503953417 = gamma_board(board);
assert( board503953417 != NULL );
assert( strcmp(board503953417, 
"4..\n"
"621\n"
"7.8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2.6\n"
"729\n"
"813\n"
"18.\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"5.1\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"359\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
"25.\n"
"6.2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
".71\n"
"28.\n"
"626\n"
"4.5\n"
"239\n"
"312\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
"95.\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"524\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board503953417);
board503953417 = NULL;
assert( gamma_move(board, 8, 31, 1) == 0 );
assert( gamma_move(board, 9, 64, 0) == 0 );
assert( gamma_move(board, 9, 2, 3) == 0 );
assert( gamma_free_fields(board, 9) == 55 );
assert( gamma_move(board, 1, 1, 39) == 0 );
assert( gamma_move(board, 1, 1, 71) == 0 );
assert( gamma_move(board, 2, 0, 53) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 23, 0) == 0 );
assert( gamma_move(board, 3, 1, 17) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 82, 1) == 0 );
assert( gamma_move(board, 6, 0, 47) == 0 );
assert( gamma_move(board, 7, 54, 2) == 0 );
assert( gamma_move(board, 8, 32, 0) == 0 );
assert( gamma_move(board, 8, 2, 70) == 0 );
assert( gamma_busy_fields(board, 8) == 28 );
assert( gamma_move(board, 9, 1, 70) == 1 );
assert( gamma_busy_fields(board, 9) == 26 );
assert( gamma_move(board, 1, 20, 2) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_move(board, 3, 31, 1) == 0 );
assert( gamma_move(board, 4, 0, 76) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 5, 20, 0) == 0 );
assert( gamma_move(board, 5, 2, 49) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_free_fields(board, 5) == 54 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 6, 2, 32) == 0 );
assert( gamma_busy_fields(board, 6) == 27 );


char* board589681417 = gamma_board(board);
assert( board589681417 != NULL );
assert( strcmp(board589681417, 
"4..\n"
"621\n"
"7.8\n"
"43.\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2.6\n"
"729\n"
"813\n"
"18.\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"591\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"359\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
"25.\n"
"6.2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
".71\n"
"28.\n"
"626\n"
"4.5\n"
"239\n"
"312\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
"95.\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"524\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board589681417);
board589681417 = NULL;
assert( gamma_move(board, 7, 91, 2) == 0 );
assert( gamma_move(board, 7, 1, 40) == 0 );
assert( gamma_move(board, 8, 37, 1) == 0 );
assert( gamma_move(board, 9, 66, 0) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 1, 0, 69) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 0, 91) == 0 );
assert( gamma_golden_move(board, 2, 35, 2) == 0 );
assert( gamma_move(board, 3, 77, 1) == 0 );
assert( gamma_move(board, 3, 0, 86) == 0 );
assert( gamma_move(board, 4, 17, 0) == 0 );
assert( gamma_move(board, 4, 2, 91) == 1 );
assert( gamma_move(board, 5, 89, 2) == 0 );
assert( gamma_free_fields(board, 5) == 53 );
assert( gamma_move(board, 6, 32, 0) == 0 );
assert( gamma_move(board, 6, 1, 36) == 0 );
assert( gamma_move(board, 7, 92, 1) == 0 );


char* board344249814 = gamma_board(board);
assert( board344249814 != NULL );
assert( strcmp(board344249814, 
"4..\n"
"621\n"
"7.8\n"
"434\n"
"7.2\n"
"6..\n"
"751\n"
"791\n"
"74.\n"
"148\n"
"582\n"
"42.\n"
"3.8\n"
"2.6\n"
"729\n"
"813\n"
"18.\n"
"5.6\n"
"619\n"
"149\n"
"565\n"
".91\n"
"263\n"
"667\n"
"591\n"
"854\n"
"148\n"
"458\n"
".47\n"
"..8\n"
".81\n"
"137\n"
"334\n"
"359\n"
"961\n"
"923\n"
"84.\n"
"975\n"
"767\n"
"756\n"
"25.\n"
"6.2\n"
"23.\n"
"859\n"
"912\n"
"268\n"
"4.6\n"
"457\n"
"197\n"
".71\n"
"28.\n"
"626\n"
"4.5\n"
"239\n"
"312\n"
"578\n"
"879\n"
"4.5\n"
"165\n"
".94\n"
"114\n"
".34\n"
".29\n"
"4..\n"
"2.6\n"
"95.\n"
"9.8\n"
"11.\n"
"689\n"
".79\n"
"293\n"
".7.\n"
".98\n"
".83\n"
".7.\n"
"6.7\n"
"9.6\n"
".14\n"
"489\n"
"889\n"
"5.6\n"
"524\n"
".62\n"
"574\n"
"3.6\n"
"581\n"
"257\n"
"3..\n"
"522\n"
"8.6\n"
"124\n"
"382\n"
"633\n"
".32\n"
"87.\n") == 0);
free(board344249814);
board344249814 = NULL;
assert( gamma_move(board, 8, 65, 1) == 0 );
assert( gamma_move(board, 8, 1, 57) == 0 );
assert( gamma_free_fields(board, 8) == 53 );
assert( gamma_move(board, 9, 21, 0) == 0 );
assert( gamma_move(board, 1, 1, 46) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 66, 0) == 0 );
assert( gamma_move(board, 2, 2, 89) == 1 );
assert( gamma_move(board, 3, 0, 75) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


gamma_delete(board);

    return 0;
}
