#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 115910533
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(15, 14, 4, 51);
assert( board != NULL );


assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 2, 4, 4) == 1 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_free_fields(board, 3) == 205 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 1, 9, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 3 );
assert( gamma_free_fields(board, 1) == 202 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 0) == 1 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 4, 11, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board898922862 = gamma_board(board);
assert( board898922862 != NULL );
assert( strcmp(board898922862, 
".1.............\n"
"...........4...\n"
"...............\n"
"...3.....1.....\n"
"....3..........\n"
"......2........\n"
"...3...3.......\n"
"...............\n"
"........1......\n"
".3..2......4...\n"
"............3..\n"
"...2.......1...\n"
"1..............\n"
"...4........4..\n") == 0);
free(board898922862);
board898922862 = NULL;
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_move(board, 1, 7, 1) == 1 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_move(board, 3, 10, 11) == 1 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 1, 14, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 2, 8, 11) == 0 );


char* board152871561 = gamma_board(board);
assert( board152871561 != NULL );
assert( strcmp(board152871561, 
".1.............\n"
"...........4...\n"
"........4.3....\n"
"...3.....1....1\n"
"....3..........\n"
"......2........\n"
"...3...3.......\n"
".4.............\n"
"..12....1......\n"
".3..2.....24...\n"
"............3..\n"
"...2.......1...\n"
"1......1.......\n"
"...4........4..\n") == 0);
free(board152871561);
board152871561 = NULL;
assert( gamma_move(board, 3, 13, 9) == 1 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 4, 11, 9) == 1 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_move(board, 1, 6, 11) == 1 );
assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_free_fields(board, 2) == 178 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 3, 14, 5) == 1 );
assert( gamma_move(board, 3, 8, 12) == 1 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_move(board, 1, 8, 9) == 1 );
assert( gamma_move(board, 1, 8, 10) == 1 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_golden_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_free_fields(board, 1) == 160 );


char* board785286071 = gamma_board(board);
assert( board785286071 != NULL );
assert( strcmp(board785286071, 
".1.............\n"
"......3.3..4...\n"
".....11.2.3....\n"
"...3..2311....1\n"
"....3...1..4.3.\n"
"....2.2.4..3...\n"
"...31.23.......\n"
".4......2......\n"
"..12....1.....3\n"
"23..2.....24...\n"
"....4...1...3..\n"
"...2..4....13..\n"
"1......1.......\n"
"...4..11....4..\n") == 0);
free(board785286071);
board785286071 = NULL;
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 3, 2, 9) == 0 );


char* board101590759 = gamma_board(board);
assert( board101590759 != NULL );
assert( strcmp(board101590759, 
".1.............\n"
"......3.3..4...\n"
".....11.2.3....\n"
".4.3..2311....1\n"
"..1.3...1..4.3.\n"
"....2.2.4..3...\n"
"...31.23.......\n"
".4......2......\n"
"..12....1.....3\n"
"23..2..2..24...\n"
"....4...1...3..\n"
"...2..4....13..\n"
"1....2.1.......\n"
"...4..11....4..\n") == 0);
free(board101590759);
board101590759 = NULL;
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_move(board, 1, 13, 5) == 1 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 3, 7, 8) == 1 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_move(board, 2, 4, 11) == 1 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 4, 11, 11) == 1 );
assert( gamma_free_fields(board, 4) == 147 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board504923433 = gamma_board(board);
assert( board504923433 != NULL );
assert( strcmp(board504923433, 
".1.............\n"
"......3.3..4...\n"
"....211.2.34...\n"
".4.3..2311....1\n"
".11.3.431..4.3.\n"
"2...2.234..3...\n"
".2.31.23.......\n"
".4......2......\n"
"..12....1....13\n"
"23..2..2..24...\n"
"....4...1...3..\n"
"...2..4....13..\n"
"1....2.1.......\n"
"...4..11....4..\n") == 0);
free(board504923433);
board504923433 = NULL;
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 1, 10, 12) == 1 );
assert( gamma_free_fields(board, 1) == 145 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board462497672 = gamma_board(board);
assert( board462497672 != NULL );
assert( strcmp(board462497672, 
".1.............\n"
"......3.3.14...\n"
"....211.2.34...\n"
".4.3..2311....1\n"
".11.3.431..4.3.\n"
"2...2.234..3...\n"
".2.31.23.......\n"
".4......2......\n"
"1.12....1....13\n"
"23..2..2..24...\n"
"....4...1...3..\n"
"...2..4....13..\n"
"1....2.1.......\n"
"...4..11....4..\n") == 0);
free(board462497672);
board462497672 = NULL;
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_golden_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 13, 4) == 1 );
assert( gamma_golden_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 12, 12) == 1 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 1, 11, 11) == 0 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_move(board, 4, 13, 8) == 1 );


char* board191485234 = gamma_board(board);
assert( board191485234 != NULL );
assert( strcmp(board191485234, 
".1.............\n"
"......3.3.144..\n"
"....211.2.34...\n"
".433..2311....1\n"
".11.3.431..4.3.\n"
"2...2.234..3.4.\n"
".2.31.23.....4.\n"
".4......2......\n"
"1.12.2..1..2.13\n"
"23..2..2..24.3.\n"
"....4...1...3..\n"
"...2.14....13..\n"
"1....2.1....2..\n"
"...4..11....4..\n") == 0);
free(board191485234);
board191485234 = NULL;
assert( gamma_move(board, 1, 10, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 11) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 11, 1) == 1 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 3) == 1 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 13, 12) == 1 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_free_fields(board, 1) == 128 );
assert( gamma_move(board, 2, 1, 12) == 1 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_free_fields(board, 2) == 123 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_move(board, 1, 9, 1) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 4, 13, 2) == 1 );
assert( gamma_move(board, 4, 13, 3) == 1 );
assert( gamma_move(board, 1, 4, 1) == 1 );


char* board570806892 = gamma_board(board);
assert( board570806892 != NULL );
assert( strcmp(board570806892, 
".1........1....\n"
".2....3.3.1443.\n"
"....21132.34...\n"
".433..2311....1\n"
".11.34431..4.3.\n"
"22..23234..3.4.\n"
".2.31.23.....4.\n"
".4......2....1.\n"
"1.12.2..1..2.13\n"
"23..2..2..24.3.\n"
"....4...14..34.\n"
"34.2.142...134.\n"
"1...12.1.1.42..\n"
"...4..11..1.4..\n") == 0);
free(board570806892);
board570806892 = NULL;
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 1, 8, 2) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_move(board, 4, 9, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 12, 9) == 1 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 2, 14, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 4, 8, 8) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 14, 3) == 1 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 4, 11, 6) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_free_fields(board, 4) == 101 );
assert( gamma_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_free_fields(board, 3) == 99 );
assert( gamma_move(board, 4, 13, 0) == 1 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_golden_move(board, 4, 7, 4) == 1 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_free_fields(board, 3) == 97 );
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 3, 9) == 0 );


char* board709235946 = gamma_board(board);
assert( board709235946 != NULL );
assert( strcmp(board709235946, 
".1........1..12\n"
".2...23.3.1443.\n"
"....21132.34...\n"
".433..23114...1\n"
".11.344311.443.\n"
"223.23234..3.4.\n"
".2.31.23.....4.\n"
"14......2..4.1.\n"
"1412.22414.2.13\n"
"233.2..4..2413.\n"
".1.441..14..341\n"
"34.2.1421..134.\n"
"11..12.1.1.42..\n"
"3..4..11..1.44.\n") == 0);
free(board709235946);
board709235946 = NULL;
assert( gamma_move(board, 2, 5, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 14) == 0 );
assert( gamma_move(board, 4, 10, 5) == 1 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_free_fields(board, 4) == 90 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 4, 14, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_free_fields(board, 1) == 85 );
assert( gamma_move(board, 2, 14, 13) == 0 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 0) == 1 );
assert( gamma_move(board, 4, 2, 6) == 1 );
assert( gamma_move(board, 1, 13, 12) == 0 );
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_free_fields(board, 3) == 81 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_move(board, 1, 13, 1) == 1 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 4, 9, 2) == 1 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 8, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_golden_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_free_fields(board, 4) == 75 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 2, 14, 1) == 1 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 4, 7, 12) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 11, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 13, 11) == 1 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_free_fields(board, 3) == 71 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 38 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_free_fields(board, 2) == 70 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 4, 6, 1) == 1 );
assert( gamma_free_fields(board, 4) == 66 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_golden_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 32 );
assert( gamma_golden_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_free_fields(board, 1) == 65 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_free_fields(board, 2) == 65 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 12, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_move(board, 4, 7, 6) == 1 );
assert( gamma_move(board, 1, 5, 6) == 1 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_free_fields(board, 4) == 62 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 2, 13, 10) == 1 );
assert( gamma_move(board, 3, 0, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_free_fields(board, 3) == 59 );
assert( gamma_move(board, 4, 12, 14) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_free_fields(board, 4) == 59 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 11, 13) == 1 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 1, 13, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 4, 14, 4) == 1 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_golden_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_golden_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_free_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_free_fields(board, 1) == 55 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_free_fields(board, 4) == 55 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );


char* board369990093 = gamma_board(board);
assert( board369990093 != NULL );
assert( strcmp(board369990093, 
"1112.2....14.12\n"
"32...2343.1443.\n"
"34..21132334.3.\n"
".433..23114..21\n"
"411.344311.4434\n"
"223.23234..3.4.\n"
".2.31.23..3..4.\n"
"144.21242.34.1.\n"
"141222241442.13\n"
"233.23.4.124134\n"
"11.4411.1422341\n"
"3412.142142134.\n"
"313.124111.4212\n"
"34.43.11..1.44.\n") == 0);
free(board369990093);
board369990093 = NULL;
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_free_fields(board, 4) == 55 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 42 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 45 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 14, 7) == 1 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 4, 3, 6) == 1 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_golden_move(board, 4, 13, 14) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 43 );
assert( gamma_golden_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 1, 12, 7) == 1 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 10, 9) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 43 );
assert( gamma_free_fields(board, 4) == 49 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 36 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 4, 5, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 43 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 46 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_golden_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 4, 9, 12) == 1 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_free_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 4, 5, 12) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 46 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 1, 9, 7) == 1 );


char* board752427340 = gamma_board(board);
assert( board752427340 != NULL );
assert( strcmp(board752427340, 
"1112.2....14.12\n"
"32...234341443.\n"
"34..21132334.3.\n"
".433..23114..21\n"
"411.34431124434\n"
"223.23234..3.4.\n"
"32.31.23313.142\n"
"144421242.34.1.\n"
"141222241442.13\n"
"233.23.4.124134\n"
"11.4411.1422341\n"
"3412.142142134.\n"
"313.124111.4212\n"
"34343111..1.44.\n") == 0);
free(board752427340);
board752427340 = NULL;
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_free_fields(board, 3) == 44 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_free_fields(board, 4) == 44 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_free_fields(board, 2) == 44 );
assert( gamma_golden_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 0) == 1 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_golden_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 44 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_free_fields(board, 2) == 43 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_golden_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 4, 8, 8) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 44 );


char* board726461661 = gamma_board(board);
assert( board726461661 != NULL );
assert( strcmp(board726461661, 
"1112.2....14.12\n"
"32...234341443.\n"
"34..21132334.3.\n"
".433.223114..21\n"
"411.34431124434\n"
"223.23234..3.4.\n"
"32.31.23313.142\n"
"144421242.34.1.\n"
"141222241442.13\n"
"233.23.4.124134\n"
"11.4411.1422341\n"
"3412.142142134.\n"
"313.124111.4212\n"
"34343111..1344.\n") == 0);
free(board726461661);
board726461661 = NULL;
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 2, 3, 1) == 1 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_free_fields(board, 4) == 42 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_free_fields(board, 4) == 40 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_free_fields(board, 1) == 40 );


char* board374873429 = gamma_board(board);
assert( board374873429 != NULL );
assert( strcmp(board374873429, 
"1112.2....14.12\n"
"32...234341443.\n"
"34..21132334.3.\n"
".433.223114..21\n"
"411.34431124434\n"
"223.23234..3.4.\n"
"32.31.23313.142\n"
"144421242.34.1.\n"
"141222241442.13\n"
"233.23.4.124134\n"
"1124411.1422341\n"
"3412.142142134.\n"
"313212411144212\n"
"34343111..1344.\n") == 0);
free(board374873429);
board374873429 = NULL;
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_free_fields(board, 2) == 40 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 5, 6) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_golden_move(board, 1, 10, 1) == 1 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_free_fields(board, 3) == 40 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 44 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_golden_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_move(board, 2, 0, 10) == 1 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 40 );
assert( gamma_golden_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_free_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_free_fields(board, 4) == 39 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_golden_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 44 );
assert( gamma_free_fields(board, 4) == 38 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 3, 12, 11) == 1 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );


char* board790395500 = gamma_board(board);
assert( board790395500 != NULL );
assert( strcmp(board790395500, 
"1112.2....14.12\n"
"32...234341443.\n"
"34..2113233433.\n"
"2433.223114..21\n"
"411.34431124434\n"
"223.23234..3.4.\n"
"32.31.23313.142\n"
"144421242.34.1.\n"
"141222241442.13\n"
"233223.4.124134\n"
"1124411.1422341\n"
"3412.142142134.\n"
"313212411114212\n"
"34343111..1344.\n") == 0);
free(board790395500);
board790395500 = NULL;
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_move(board, 4, 12, 14) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );


char* board903254156 = gamma_board(board);
assert( board903254156 != NULL );
assert( strcmp(board903254156, 
"1112.2....14.12\n"
"32...234341443.\n"
"34..2113233433.\n"
"2433.223114..21\n"
"411.34431124434\n"
"223.23234..3.4.\n"
"32.31323313.142\n"
"144421242.34.1.\n"
"141222241442.13\n"
"233223.4.124134\n"
"1124411.1422341\n"
"3412.142142134.\n"
"313212411114212\n"
"34343111..1344.\n") == 0);
free(board903254156);
board903254156 = NULL;
assert( gamma_move(board, 1, 13, 12) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 4, 11, 7) == 1 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_golden_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 11, 11) == 0 );
assert( gamma_move(board, 3, 12, 12) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 2, 12) == 1 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_free_fields(board, 4) == 33 );


gamma_delete(board);

    return 0;
}
