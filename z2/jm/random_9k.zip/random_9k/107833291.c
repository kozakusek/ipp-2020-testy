#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 107833291
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 16, 9, 20);
assert( board != NULL );


assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board484125425 = gamma_board(board);
assert( board484125425 != NULL );
assert( strcmp(board484125425, 
"..............\n"
"..............\n"
"..............\n"
"..............\n"
"..............\n"
"..............\n"
"..............\n"
".......1......\n"
"..............\n"
"..............\n"
"..............\n"
"..............\n"
".........2....\n"
"..............\n"
".........2....\n"
"..............\n") == 0);
free(board484125425);
board484125425 = NULL;
assert( gamma_move(board, 4, 10, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 2) == 1 );
assert( gamma_move(board, 6, 14, 4) == 0 );
assert( gamma_move(board, 6, 1, 6) == 1 );
assert( gamma_free_fields(board, 6) == 218 );
assert( gamma_move(board, 7, 10, 2) == 1 );
assert( gamma_move(board, 8, 6, 9) == 1 );
assert( gamma_free_fields(board, 8) == 216 );
assert( gamma_move(board, 9, 12, 9) == 1 );
assert( gamma_move(board, 9, 4, 3) == 1 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 2 );
assert( gamma_golden_move(board, 3, 9, 6) == 0 );
assert( gamma_golden_move(board, 4, 2, 1) == 0 );


char* board638365454 = gamma_board(board);
assert( board638365454 != NULL );
assert( strcmp(board638365454, 
"..............\n"
".............1\n"
"..............\n"
"..............\n"
"..............\n"
"...2..........\n"
"......8.....9.\n"
"....3..1......\n"
"..............\n"
".6............\n"
"1.............\n"
"..............\n"
"....9....2....\n"
".5........7...\n"
".....3...2....\n"
"..........4...\n") == 0);
free(board638365454);
board638365454 = NULL;
assert( gamma_move(board, 5, 9, 8) == 1 );
assert( gamma_move(board, 5, 13, 11) == 1 );
assert( gamma_move(board, 6, 6, 14) == 1 );
assert( gamma_free_fields(board, 6) == 206 );
assert( gamma_move(board, 7, 3, 15) == 1 );
assert( gamma_move(board, 8, 7, 0) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 1, 11) == 1 );
assert( gamma_move(board, 9, 2, 8) == 1 );
assert( gamma_busy_fields(board, 9) == 4 );


char* board111627771 = gamma_board(board);
assert( board111627771 != NULL );
assert( strcmp(board111627771, 
"...7..........\n"
"......6......1\n"
"..............\n"
"..............\n"
".9...........5\n"
"...2..........\n"
"......8.....9.\n"
"..9.3..1.5....\n"
"..............\n"
".6............\n"
"1.............\n"
"..............\n"
"....9....2....\n"
".5........7...\n"
".....3...2....\n"
".......8..4...\n") == 0);
free(board111627771);
board111627771 = NULL;
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 2, 5, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 4, 8, 13) == 1 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 5, 4, 4) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 0) == 1 );
assert( gamma_move(board, 6, 13, 14) == 0 );
assert( gamma_move(board, 7, 7, 9) == 1 );
assert( gamma_move(board, 7, 5, 10) == 1 );
assert( gamma_move(board, 8, 11, 11) == 1 );
assert( gamma_move(board, 9, 1, 7) == 1 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 3 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_move(board, 5, 7, 12) == 1 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_move(board, 7, 10, 10) == 1 );
assert( gamma_move(board, 8, 13, 15) == 1 );
assert( gamma_move(board, 8, 10, 1) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 13, 2) == 1 );
assert( gamma_move(board, 9, 0, 6) == 0 );
assert( gamma_move(board, 1, 2, 12) == 1 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_free_fields(board, 2) == 181 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 5, 9, 11) == 1 );
assert( gamma_move(board, 5, 2, 14) == 1 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_move(board, 6, 7, 5) == 1 );
assert( gamma_move(board, 7, 10, 10) == 0 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 5 );
assert( gamma_move(board, 8, 7, 13) == 1 );
assert( gamma_move(board, 8, 11, 8) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 8, 0) == 1 );
assert( gamma_move(board, 9, 9, 12) == 1 );
assert( gamma_move(board, 1, 8, 8) == 1 );
assert( gamma_move(board, 1, 13, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 2 );
assert( gamma_move(board, 5, 6, 3) == 1 );
assert( gamma_free_fields(board, 5) == 169 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 4) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 10, 3) == 1 );
assert( gamma_move(board, 8, 3, 12) == 1 );
assert( gamma_move(board, 8, 13, 0) == 1 );
assert( gamma_move(board, 9, 6, 5) == 1 );
assert( gamma_free_fields(board, 9) == 164 );


char* board201877867 = gamma_board(board);
assert( board201877867 != NULL );
assert( strcmp(board201877867, 
"...7.........8\n"
"..5..26......1\n"
"...2...84.....\n"
"..18...5.9....\n"
"392......5.8.5\n"
"...2.7....7...\n"
"......87....9.\n"
"..923..115.3..\n"
".9....2.......\n"
"26............\n"
"1..1..96......\n"
"..6.3........1\n"
"....9.5..27...\n"
".5....2...7..9\n"
".....3...28...\n"
"5...6..89.4..8\n") == 0);
free(board201877867);
board201877867 = NULL;
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_move(board, 2, 5, 13) == 1 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_free_fields(board, 2) == 162 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 8 );
assert( gamma_move(board, 6, 11, 3) == 1 );
assert( gamma_move(board, 7, 0, 13) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 0, 12) == 1 );
assert( gamma_move(board, 9, 11, 7) == 1 );
assert( gamma_free_fields(board, 9) == 156 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 1, 1, 15) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 4, 14) == 1 );
assert( gamma_move(board, 6, 10, 8) == 1 );
assert( gamma_move(board, 6, 9, 2) == 1 );
assert( gamma_move(board, 7, 5, 9) == 1 );
assert( gamma_busy_fields(board, 7) == 8 );
assert( gamma_move(board, 8, 1, 1) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 12, 10) == 1 );
assert( gamma_move(board, 9, 0, 7) == 1 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_free_fields(board, 2) == 143 );
assert( gamma_move(board, 3, 6, 13) == 1 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_free_fields(board, 5) == 140 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 8 );
assert( gamma_golden_move(board, 6, 9, 12) == 1 );
assert( gamma_move(board, 7, 10, 10) == 0 );
assert( gamma_move(board, 8, 13, 9) == 1 );
assert( gamma_busy_fields(board, 8) == 11 );
assert( gamma_move(board, 9, 0, 0) == 0 );
assert( gamma_move(board, 1, 4, 13) == 1 );
assert( gamma_move(board, 1, 7, 5) == 0 );


char* board459313590 = gamma_board(board);
assert( board459313590 != NULL );
assert( strcmp(board459313590, 
".1.7.........8\n"
"..5.5262.....1\n"
"7..212384.....\n"
"8118.2.5.6....\n"
"392......518.5\n"
"...2.7....7.9.\n"
".....787....98\n"
".3923..11563..\n"
"99..4.2....9..\n"
"26............\n"
"1..1..96......\n"
"..633........1\n"
"...59.5..276..\n"
".5....2..67..9\n"
".8...3...28...\n"
"5..16..8924..8\n") == 0);
free(board459313590);
board459313590 = NULL;
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 8, 5) == 1 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 5, 2, 14) == 0 );
assert( gamma_move(board, 6, 6, 11) == 1 );
assert( gamma_move(board, 6, 11, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_free_fields(board, 6) == 134 );
assert( gamma_move(board, 7, 5, 5) == 1 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 8, 9, 7) == 1 );
assert( gamma_move(board, 8, 11, 8) == 0 );
assert( gamma_move(board, 9, 11, 13) == 1 );
assert( gamma_golden_move(board, 9, 5, 7) == 0 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_golden_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_free_fields(board, 3) == 128 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_move(board, 6, 4, 6) == 1 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 7, 5, 4) == 1 );
assert( gamma_move(board, 7, 9, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_move(board, 9, 3, 0) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 4, 2, 13) == 1 );
assert( gamma_move(board, 5, 12, 10) == 0 );
assert( gamma_move(board, 5, 0, 9) == 1 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_move(board, 6, 13, 13) == 1 );
assert( gamma_move(board, 7, 4, 1) == 1 );
assert( gamma_move(board, 7, 4, 12) == 1 );
assert( gamma_move(board, 8, 6, 1) == 1 );
assert( gamma_move(board, 9, 4, 12) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 13, 12) == 1 );
assert( gamma_move(board, 4, 1, 3) == 1 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_move(board, 6, 12, 15) == 1 );
assert( gamma_move(board, 7, 2, 0) == 1 );
assert( gamma_move(board, 8, 11, 4) == 1 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 8, 11) == 1 );


char* board121085331 = gamma_board(board);
assert( board121085331 != NULL );
assert( strcmp(board121085331, 
".1.7........68\n"
"..5.5262.....1\n"
"7.4212384..9.6\n"
"811872.526...4\n"
"392...6.1518.5\n"
"...2.7....7.9.\n"
"5...3787....98\n"
".3923..11563..\n"
"99..4.21.8.9..\n"
"26..6.........\n"
"1..1.7964..4..\n"
"..6337.....8.1\n"
".4.59.51.276..\n"
".5....2..67..9\n"
".8..738..28...\n"
"55716.48924..8\n") == 0);
free(board121085331);
board121085331 = NULL;
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_move(board, 4, 10, 13) == 1 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_move(board, 5, 9, 6) == 1 );
assert( gamma_move(board, 6, 0, 8) == 1 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 7, 6, 15) == 1 );
assert( gamma_move(board, 8, 11, 9) == 1 );
assert( gamma_move(board, 8, 6, 10) == 1 );
assert( gamma_move(board, 9, 11, 12) == 1 );
assert( gamma_move(board, 9, 7, 7) == 0 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_free_fields(board, 1) == 104 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_move(board, 3, 7, 15) == 1 );
assert( gamma_move(board, 4, 5, 6) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 5, 10, 4) == 1 );
assert( gamma_move(board, 6, 15, 4) == 0 );
assert( gamma_move(board, 7, 1, 7) == 0 );
assert( gamma_move(board, 8, 7, 12) == 0 );
assert( gamma_move(board, 8, 4, 15) == 1 );
assert( gamma_move(board, 9, 3, 0) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 5, 12) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 5, 3, 3) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 8, 5) == 0 );
assert( gamma_move(board, 9, 6, 10) == 0 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_move(board, 3, 8, 6) == 1 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 6, 2, 9) == 1 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 11, 5) == 0 );
assert( gamma_move(board, 7, 12, 12) == 0 );
assert( gamma_move(board, 8, 7, 13) == 0 );
assert( gamma_free_fields(board, 8) == 93 );
assert( gamma_move(board, 9, 3, 15) == 0 );
assert( gamma_move(board, 9, 10, 12) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_golden_move(board, 3, 12, 5) == 0 );


char* board285126380 = gamma_board(board);
assert( board285126380 != NULL );
assert( strcmp(board285126380, 
".1.78.73....68\n"
"..5.5262.....1\n"
"7.4212384.49.6\n"
"81187225269914\n"
"392...6.1518.5\n"
"...2.78.2.7.9.\n"
"5.633787...898\n"
"63923..11563..\n"
"99..4.21.8.9..\n"
"26..62..35..3.\n"
"1..1.7964..4..\n"
"..6337....58.1\n"
".4.59.51.276..\n"
".5..2.2..67..9\n"
".8..738..28...\n"
"55716.48924..8\n") == 0);
free(board285126380);
board285126380 = NULL;
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_free_fields(board, 4) == 92 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 6, 12, 14) == 1 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 7, 9, 7) == 0 );
assert( gamma_move(board, 8, 9, 1) == 0 );
assert( gamma_move(board, 8, 0, 3) == 1 );
assert( gamma_move(board, 9, 5, 2) == 1 );
assert( gamma_move(board, 9, 9, 3) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 1, 12, 12) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 12) == 0 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_free_fields(board, 6) == 89 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 7, 5, 9) == 0 );
assert( gamma_golden_move(board, 7, 15, 1) == 0 );
assert( gamma_move(board, 8, 4, 2) == 0 );
assert( gamma_move(board, 8, 8, 5) == 0 );
assert( gamma_busy_fields(board, 8) == 18 );
assert( gamma_move(board, 9, 7, 8) == 0 );
assert( gamma_move(board, 9, 5, 2) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 4, 11, 0) == 1 );
assert( gamma_golden_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 13, 12) == 0 );


char* board707793700 = gamma_board(board);
assert( board707793700 != NULL );
assert( strcmp(board707793700, 
".1.78.73....68\n"
"..5.5262....61\n"
"7.4212384.49.6\n"
"81187225269914\n"
"392...6.1518.5\n"
"...2.78.2.7.9.\n"
"5.633787...898\n"
"63923..11563..\n"
"99..4.21.8.9..\n"
"26..62..35..3.\n"
"1..1.7964..4..\n"
"..6337....58.1\n"
"84.59.51.276..\n"
".5.3292..67..9\n"
".8..738..28...\n"
"55716.489244.8\n") == 0);
free(board707793700);
board707793700 = NULL;
assert( gamma_move(board, 6, 14, 1) == 0 );
assert( gamma_move(board, 6, 12, 15) == 0 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_move(board, 8, 14, 3) == 0 );
assert( gamma_move(board, 9, 14, 0) == 0 );
assert( gamma_move(board, 9, 3, 11) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_golden_move(board, 9, 4, 2) == 1 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_free_fields(board, 4) == 86 );
assert( gamma_move(board, 5, 2, 7) == 1 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 13, 14) == 0 );
assert( gamma_move(board, 8, 10, 11) == 0 );
assert( gamma_move(board, 8, 10, 2) == 0 );
assert( gamma_move(board, 9, 5, 1) == 0 );
assert( gamma_free_fields(board, 9) == 85 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 5, 6, 15) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_free_fields(board, 6) == 82 );
assert( gamma_move(board, 7, 2, 8) == 0 );
assert( gamma_move(board, 8, 6, 6) == 1 );
assert( gamma_move(board, 8, 1, 13) == 1 );
assert( gamma_move(board, 9, 11, 12) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 2, 12, 15) == 0 );
assert( gamma_free_fields(board, 2) == 80 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_free_fields(board, 3) == 79 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 5, 11, 11) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_move(board, 7, 13, 11) == 0 );
assert( gamma_move(board, 7, 13, 8) == 1 );
assert( gamma_move(board, 8, 11, 7) == 0 );
assert( gamma_move(board, 9, 4, 8) == 0 );
assert( gamma_move(board, 9, 8, 15) == 1 );
assert( gamma_busy_fields(board, 9) == 18 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_move(board, 3, 11, 10) == 1 );
assert( gamma_free_fields(board, 3) == 75 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 4, 9) == 0 );
assert( gamma_move(board, 5, 12, 3) == 1 );
assert( gamma_move(board, 6, 4, 9) == 0 );
assert( gamma_move(board, 6, 8, 2) == 1 );


char* board987636868 = gamma_board(board);
assert( board987636868 != NULL );
assert( strcmp(board987636868, 
".1.78.739...68\n"
"..5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929..6.1518.5\n"
"...2.78.2.739.\n"
"5.633787..3898\n"
"63923..11563.7\n"
"995.4.21.8.9..\n"
"26..628.35..3.\n"
"1.31479643.4..\n"
"..6337....58.1\n"
"84.59.51.2765.\n"
".543992.667..9\n"
".8..738.228...\n"
"55716.489244.8\n") == 0);
free(board987636868);
board987636868 = NULL;
assert( gamma_move(board, 7, 13, 9) == 0 );
assert( gamma_move(board, 7, 9, 10) == 1 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 0) == 0 );
assert( gamma_move(board, 8, 7, 9) == 0 );
assert( gamma_move(board, 9, 6, 13) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 7, 10) == 1 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 6, 4, 2) == 0 );
assert( gamma_move(board, 7, 6, 6) == 0 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 13) == 0 );
assert( gamma_move(board, 8, 4, 3) == 0 );
assert( gamma_move(board, 9, 14, 0) == 0 );
assert( gamma_move(board, 9, 12, 0) == 1 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_free_fields(board, 2) == 68 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_golden_move(board, 3, 5, 0) == 0 );
assert( gamma_free_fields(board, 5) == 68 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_golden_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 7, 15, 5) == 0 );
assert( gamma_move(board, 8, 14, 0) == 0 );
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_move(board, 9, 15, 2) == 0 );


char* board932362543 = gamma_board(board);
assert( board932362543 != NULL );
assert( strcmp(board932362543, 
".1.78.739...68\n"
"..5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929..6.1518.5\n"
"...2.78427739.\n"
"5.633787.23898\n"
"63923..11563.7\n"
"995.4.21.8.9..\n"
"26..628.35..3.\n"
"1.31479643.4..\n"
"..6337....58.1\n"
"84.59.51.2765.\n"
".543992.667..9\n"
".8..738.228...\n"
"55716.48924498\n") == 0);
free(board932362543);
board932362543 = NULL;
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 3, 4, 10) == 1 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 5, 11, 12) == 0 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_move(board, 7, 6, 13) == 0 );
assert( gamma_move(board, 7, 3, 11) == 0 );
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 20 );
assert( gamma_move(board, 9, 2, 12) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_free_fields(board, 2) == 66 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 4, 13, 1) == 1 );
assert( gamma_move(board, 5, 1, 13) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 13, 8) == 1 );
assert( gamma_move(board, 7, 6, 7) == 0 );
assert( gamma_move(board, 8, 15, 5) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 9, 5) == 0 );
assert( gamma_golden_move(board, 9, 1, 13) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 6, 8) == 1 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 9, 8) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 13, 9) == 0 );
assert( gamma_move(board, 8, 1, 8) == 0 );
assert( gamma_free_fields(board, 8) == 64 );
assert( gamma_move(board, 9, 15, 10) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 8, 1, 12) == 0 );
assert( gamma_move(board, 8, 6, 6) == 0 );
assert( gamma_move(board, 9, 8, 12) == 0 );
assert( gamma_move(board, 9, 13, 12) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 2, 15) == 1 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 5, 0, 14) == 1 );


char* board993870242 = gamma_board(board);
assert( board993870242 != NULL );
assert( strcmp(board993870242, 
".1178.739...68\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.26.1518.5\n"
"...2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.2138.9..\n"
"26..628.35..3.\n"
"1.31479643.4..\n"
"..6337....58.1\n"
"84259.51.2765.\n"
".543992.667..9\n"
".8..738.228..4\n"
"55716.48924498\n") == 0);
free(board993870242);
board993870242 = NULL;
assert( gamma_move(board, 6, 2, 6) == 1 );
assert( gamma_move(board, 6, 10, 10) == 0 );
assert( gamma_move(board, 7, 13, 12) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 10) == 0 );
assert( gamma_move(board, 9, 5, 10) == 0 );
assert( gamma_move(board, 9, 4, 6) == 0 );
assert( gamma_free_fields(board, 9) == 58 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 12, 6) == 0 );


char* board761496261 = gamma_board(board);
assert( board761496261 != NULL );
assert( strcmp(board761496261, 
".1178.739...68\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.26.1518.5\n"
"...2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.2138.9..\n"
"266.628.35..3.\n"
"1.31479643.4..\n"
"..6337....58.1\n"
"84259.51.2765.\n"
".543992.667..9\n"
".8..738.228..4\n"
"55716.48924498\n") == 0);
free(board761496261);
board761496261 = NULL;
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 1, 2) == 0 );
assert( gamma_move(board, 7, 9, 15) == 1 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_golden_possible(board, 7) == 1 );


char* board543835938 = gamma_board(board);
assert( board543835938 != NULL );
assert( strcmp(board543835938, 
".1178.7397..68\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.26.1518.5\n"
"...2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.2138.9..\n"
"266.628.35..3.\n"
"1.31479643.4..\n"
"..6337....58.1\n"
"84259.51.2765.\n"
".543992.667..9\n"
".8..738.228..4\n"
"55716.48924498\n") == 0);
free(board543835938);
board543835938 = NULL;
assert( gamma_move(board, 8, 13, 8) == 0 );
assert( gamma_free_fields(board, 8) == 57 );
assert( gamma_move(board, 9, 2, 11) == 0 );
assert( gamma_move(board, 9, 4, 7) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 7, 11, 4) == 0 );
assert( gamma_move(board, 7, 12, 7) == 1 );
assert( gamma_move(board, 8, 13, 11) == 0 );
assert( gamma_move(board, 9, 5, 12) == 0 );
assert( gamma_move(board, 9, 7, 3) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_move(board, 5, 10, 2) == 0 );


char* board582663820 = gamma_board(board);
assert( board582663820 != NULL );
assert( strcmp(board582663820, 
".1178.7397..68\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.26.1518.5\n"
".1.2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.2138.97.\n"
"266.628.35..3.\n"
"1.31479643.4..\n"
"..6337....58.1\n"
"84259.51.2765.\n"
".5439924667.39\n"
".8..738.228..4\n"
"55716.48924498\n") == 0);
free(board582663820);
board582663820 = NULL;
assert( gamma_move(board, 6, 14, 8) == 0 );
assert( gamma_move(board, 7, 5, 4) == 0 );
assert( gamma_move(board, 8, 0, 14) == 0 );
assert( gamma_move(board, 8, 4, 4) == 0 );
assert( gamma_move(board, 9, 7, 7) == 0 );
assert( gamma_move(board, 9, 6, 4) == 1 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_busy_fields(board, 8) == 20 );
assert( gamma_move(board, 9, 8, 12) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 13, 15) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 5, 7, 12) == 0 );


char* board461818637 = gamma_board(board);
assert( board461818637 != NULL );
assert( strcmp(board461818637, 
".1178.7397..68\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.26.1518.5\n"
".1.2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.2138.97.\n"
"266.628.35..3.\n"
"1.31479643.43.\n"
"..63379...58.1\n"
"84259.51.2765.\n"
".5439924667.39\n"
".8..738.228..4\n"
"55716.48924498\n") == 0);
free(board461818637);
board461818637 = NULL;
assert( gamma_move(board, 6, 13, 12) == 0 );
assert( gamma_move(board, 6, 8, 9) == 0 );
assert( gamma_move(board, 7, 10, 5) == 1 );
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_move(board, 8, 1, 0) == 0 );
assert( gamma_move(board, 9, 9, 1) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_golden_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 7, 11, 13) == 0 );
assert( gamma_move(board, 8, 4, 8) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 10, 15) == 1 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_free_fields(board, 2) == 48 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_move(board, 4, 11, 15) == 1 );
assert( gamma_golden_move(board, 4, 3, 0) == 1 );
assert( gamma_move(board, 5, 7, 11) == 1 );
assert( gamma_move(board, 6, 1, 12) == 0 );


char* board902128768 = gamma_board(board);
assert( board902128768 != NULL );
assert( strcmp(board902128768, 
".1178.73971468\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.2651518.5\n"
".1.2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.2138.97.\n"
"266.628.35..31\n"
"1.31479643743.\n"
"..63379...58.1\n"
"84259.51.2765.\n"
".5439924667.39\n"
".8..738.228..4\n"
"55746.48924498\n") == 0);
free(board902128768);
board902128768 = NULL;
assert( gamma_move(board, 7, 1, 11) == 0 );
assert( gamma_move(board, 7, 6, 6) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 7) == 0 );
assert( gamma_move(board, 8, 3, 6) == 1 );
assert( gamma_move(board, 9, 3, 12) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 13, 12) == 0 );
assert( gamma_move(board, 7, 6, 12) == 0 );
assert( gamma_move(board, 8, 6, 10) == 0 );
assert( gamma_move(board, 9, 3, 5) == 0 );
assert( gamma_move(board, 9, 4, 2) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_free_fields(board, 2) == 45 );
assert( gamma_golden_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );


char* board781066280 = gamma_board(board);
assert( board781066280 != NULL );
assert( strcmp(board781066280, 
".1178.73971468\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.2651518.5\n"
".1.2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.2138.97.\n"
"2668628.35..31\n"
"1.31479643743.\n"
"..63379...58.1\n"
"84259.51.2765.\n"
".5439924667.39\n"
".8..738.228..4\n"
"55746.48924498\n") == 0);
free(board781066280);
board781066280 = NULL;
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_free_fields(board, 4) == 45 );
assert( gamma_move(board, 5, 13, 12) == 0 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 6, 11, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_move(board, 7, 14, 8) == 0 );
assert( gamma_free_fields(board, 7) == 45 );
assert( gamma_move(board, 8, 9, 9) == 0 );
assert( gamma_move(board, 9, 1, 2) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 6, 11, 3) == 0 );
assert( gamma_move(board, 8, 13, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 21 );
assert( gamma_move(board, 9, 13, 4) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 1, 8, 10) == 0 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_free_fields(board, 2) == 44 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_move(board, 5, 3, 3) == 0 );
assert( gamma_free_fields(board, 5) == 44 );
assert( gamma_move(board, 6, 7, 15) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 7, 13, 7) == 1 );
assert( gamma_move(board, 8, 14, 9) == 0 );


char* board471731101 = gamma_board(board);
assert( board471731101 != NULL );
assert( strcmp(board471731101, 
".1178.73971468\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.2651518.5\n"
".1.2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.2138.977\n"
"2668628.35..31\n"
"1.31479643743.\n"
"..63379...58.1\n"
"84259.51.2765.\n"
".5439924667.39\n"
"28..738.228..4\n"
"55746.48924498\n") == 0);
free(board471731101);
board471731101 = NULL;
assert( gamma_move(board, 9, 10, 7) == 1 );
assert( gamma_move(board, 9, 4, 15) == 0 );
assert( gamma_free_fields(board, 9) == 42 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 6, 8, 12) == 0 );
assert( gamma_free_fields(board, 6) == 40 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_move(board, 8, 1, 2) == 0 );
assert( gamma_move(board, 8, 7, 6) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 6, 12, 11) == 1 );
assert( gamma_move(board, 7, 7, 3) == 0 );
assert( gamma_move(board, 8, 10, 2) == 0 );
assert( gamma_free_fields(board, 8) == 10 );
assert( gamma_move(board, 9, 8, 9) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 3, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 5, 3, 3) == 0 );
assert( gamma_move(board, 6, 8, 12) == 0 );
assert( gamma_move(board, 7, 4, 0) == 0 );
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_move(board, 9, 14, 1) == 0 );
assert( gamma_busy_fields(board, 9) == 21 );
assert( gamma_move(board, 1, 11, 2) == 1 );


char* board766587812 = gamma_board(board);
assert( board766587812 != NULL );
assert( strcmp(board766587812, 
".1178.73971468\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.265151865\n"
"41.2378427739.\n"
"5.633787323898\n"
"63923.311563.5\n"
"995.4.22389977\n"
"26686288353131\n"
"1.31479643743.\n"
"..63379...58.1\n"
"84259.5132765.\n"
".5439924667139\n"
"28.2738.228..4\n"
"55746.48924498\n") == 0);
free(board766587812);
board766587812 = NULL;
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 6, 9, 15) == 0 );


char* board696930747 = gamma_board(board);
assert( board696930747 != NULL );
assert( strcmp(board696930747, 
".1178.73971468\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.265151865\n"
"41.2378427739.\n"
"5.633787323898\n"
"639234311563.5\n"
"995.4.22389977\n"
"26686288353131\n"
"1.31479643743.\n"
"..63379...58.1\n"
"84259.5132765.\n"
".5439924667139\n"
"28.2738.228..4\n"
"55746.48924498\n") == 0);
free(board696930747);
board696930747 = NULL;
assert( gamma_move(board, 7, 13, 13) == 0 );
assert( gamma_move(board, 8, 8, 12) == 0 );


char* board291542759 = gamma_board(board);
assert( board291542759 != NULL );
assert( strcmp(board291542759, 
".1178.73971468\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"3929.265151865\n"
"41.2378427739.\n"
"5.633787323898\n"
"639234311563.5\n"
"995.4.22389977\n"
"26686288353131\n"
"1.31479643743.\n"
"..63379...58.1\n"
"84259.5132765.\n"
".5439924667139\n"
"28.2738.228..4\n"
"55746.48924498\n") == 0);
free(board291542759);
board291542759 = NULL;
assert( gamma_move(board, 9, 14, 10) == 0 );
assert( gamma_move(board, 1, 2, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 4, 4, 11) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 1, 12) == 0 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 14, 3) == 0 );
assert( gamma_move(board, 8, 8, 12) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 7, 3) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_free_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );


char* board614443187 = gamma_board(board);
assert( board614443187 != NULL );
assert( strcmp(board614443187, 
".1178.73971468\n"
"5.5.5262....61\n"
"784212384.49.6\n"
"81187225269914\n"
"39294265151865\n"
"41.2378427739.\n"
"5.633787323898\n"
"639234311563.5\n"
"995.4.22389977\n"
"26686288353131\n"
"1.31479643743.\n"
"..63379...58.1\n"
"84259.5132765.\n"
".5439924667139\n"
"2812738.228..4\n"
"55746.48924498\n") == 0);
free(board614443187);
board614443187 = NULL;
assert( gamma_move(board, 6, 1, 11) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 8, 2, 0) == 0 );
assert( gamma_move(board, 9, 14, 9) == 0 );
assert( gamma_move(board, 9, 2, 12) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 5, 8, 14) == 1 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_move(board, 7, 0, 6) == 0 );
assert( gamma_move(board, 8, 4, 14) == 0 );
assert( gamma_move(board, 9, 4, 8) == 0 );
assert( gamma_move(board, 9, 1, 13) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 6, 14, 11) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );


char* board560133431 = gamma_board(board);
assert( board560133431 != NULL );
assert( strcmp(board560133431, 
".1178.73971468\n"
"5.5.52625...61\n"
"784212384.49.6\n"
"81187225269914\n"
"39294265151865\n"
"41.2378427739.\n"
"5.633787323898\n"
"639234311563.5\n"
"995.4.22389977\n"
"26686288353131\n"
"1231479643743.\n"
"..63379...58.1\n"
"84259.5132765.\n"
".5439924667139\n"
"2812738.228..4\n"
"55746.48924498\n") == 0);
free(board560133431);
board560133431 = NULL;
assert( gamma_move(board, 7, 1, 15) == 0 );


gamma_delete(board);

    return 0;
}
