#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 145243027
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(3, 92, 4, 28);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 37) == 1 );
assert( gamma_move(board, 1, 0, 80) == 1 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_free_fields(board, 2) == 274 );
assert( gamma_move(board, 3, 88, 1) == 0 );
assert( gamma_move(board, 3, 0, 60) == 1 );
assert( gamma_move(board, 4, 88, 1) == 0 );
assert( gamma_move(board, 1, 86, 1) == 0 );
assert( gamma_move(board, 1, 2, 57) == 1 );
assert( gamma_move(board, 2, 0, 75) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 65, 1) == 0 );


char* board632690919 = gamma_board(board);
assert( board632690919 != NULL );
assert( strcmp(board632690919, 
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board632690919);
board632690919 = NULL;
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 1, 33, 2) == 0 );
assert( gamma_move(board, 2, 68, 1) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 74, 0) == 0 );
assert( gamma_move(board, 4, 1, 23) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 60, 0) == 0 );
assert( gamma_move(board, 1, 29, 2) == 0 );
assert( gamma_move(board, 1, 2, 86) == 1 );
assert( gamma_free_fields(board, 1) == 268 );


char* board636395496 = gamma_board(board);
assert( board636395496 != NULL );
assert( strcmp(board636395496, 
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n") == 0);
free(board636395496);
board636395496 = NULL;
assert( gamma_move(board, 2, 2, 44) == 1 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_free_fields(board, 2) == 266 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 45) == 1 );
assert( gamma_move(board, 3, 1, 41) == 1 );
assert( gamma_move(board, 4, 2, 48) == 1 );
assert( gamma_move(board, 4, 0, 73) == 1 );
assert( gamma_move(board, 1, 82, 0) == 0 );
assert( gamma_move(board, 3, 37, 2) == 0 );
assert( gamma_move(board, 4, 48, 1) == 0 );
assert( gamma_move(board, 1, 0, 37) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 91) == 1 );
assert( gamma_move(board, 3, 50, 2) == 0 );
assert( gamma_move(board, 4, 44, 1) == 0 );
assert( gamma_move(board, 4, 0, 91) == 0 );
assert( gamma_move(board, 1, 0, 24) == 1 );
assert( gamma_move(board, 2, 39, 1) == 0 );
assert( gamma_move(board, 2, 1, 78) == 1 );


char* board426141213 = gamma_board(board);
assert( board426141213 != NULL );
assert( strcmp(board426141213, 
"2..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"...\n"
"3..\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n") == 0);
free(board426141213);
board426141213 = NULL;
assert( gamma_move(board, 3, 0, 23) == 1 );
assert( gamma_move(board, 3, 0, 35) == 1 );
assert( gamma_move(board, 4, 74, 0) == 0 );
assert( gamma_move(board, 4, 2, 19) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 1, 2, 68) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 26) == 1 );
assert( gamma_move(board, 1, 27, 0) == 0 );
assert( gamma_move(board, 1, 2, 67) == 1 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 1, 1, 30) == 1 );
assert( gamma_move(board, 2, 38, 0) == 0 );
assert( gamma_move(board, 2, 0, 59) == 1 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_move(board, 4, 84, 0) == 0 );
assert( gamma_free_fields(board, 4) == 247 );
assert( gamma_move(board, 2, 81, 1) == 0 );
assert( gamma_move(board, 2, 0, 73) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 86) == 0 );
assert( gamma_move(board, 4, 0, 63) == 1 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_move(board, 1, 1, 52) == 1 );
assert( gamma_move(board, 1, 2, 59) == 1 );
assert( gamma_move(board, 2, 1, 51) == 1 );
assert( gamma_move(board, 2, 2, 47) == 1 );
assert( gamma_golden_move(board, 2, 19, 2) == 0 );
assert( gamma_move(board, 3, 90, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 7 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 44, 1) == 0 );
assert( gamma_move(board, 4, 0, 1) == 1 );
assert( gamma_move(board, 1, 2, 86) == 0 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 1, 86) == 1 );
assert( gamma_move(board, 2, 1, 84) == 1 );
assert( gamma_move(board, 3, 55, 0) == 0 );
assert( gamma_move(board, 4, 28, 0) == 0 );
assert( gamma_move(board, 1, 1, 26) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 25) == 1 );
assert( gamma_move(board, 2, 0, 37) == 0 );
assert( gamma_move(board, 3, 1, 82) == 1 );
assert( gamma_free_fields(board, 3) == 236 );
assert( gamma_golden_move(board, 3, 47, 2) == 0 );
assert( gamma_move(board, 4, 0, 21) == 1 );
assert( gamma_move(board, 4, 0, 15) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board912457484 = gamma_board(board);
assert( board912457484 != NULL );
assert( strcmp(board912457484, 
"2..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".21\n"
"...\n"
".2.\n"
"...\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"2.1\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
".2.\n"
"...\n"
"...\n"
"..4\n"
"..2\n"
"...\n"
"3..\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
"...\n"
"...\n"
".14\n"
"..2\n"
"1..\n"
"34.\n"
"...\n"
"4..\n"
"...\n"
"..4\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"..3\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
"...\n"
"..4\n"
"4..\n"
"4..\n"
"...\n") == 0);
free(board912457484);
board912457484 = NULL;
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 2, 2, 84) == 1 );
assert( gamma_move(board, 3, 1, 82) == 0 );
assert( gamma_move(board, 3, 2, 76) == 1 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 51, 2) == 0 );
assert( gamma_move(board, 4, 0, 12) == 1 );
assert( gamma_move(board, 1, 50, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 0, 27) == 1 );
assert( gamma_move(board, 3, 88, 1) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 2, 31, 1) == 0 );
assert( gamma_move(board, 3, 87, 2) == 0 );
assert( gamma_move(board, 3, 2, 26) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board324743926 = gamma_board(board);
assert( board324743926 != NULL );
assert( strcmp(board324743926, 
"2..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".21\n"
"...\n"
".22\n"
"...\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
".2.\n"
"...\n"
"..3\n"
"2..\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"2.1\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
".2.\n"
"...\n"
"...\n"
"..4\n"
"..2\n"
"...\n"
"3..\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
"...\n"
"2..\n"
".14\n"
"..2\n"
"1..\n"
"34.\n"
"...\n"
"4..\n"
"...\n"
"..4\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"..3\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
"...\n"
"..4\n"
"4..\n"
"4..\n"
".1.\n") == 0);
free(board324743926);
board324743926 = NULL;
assert( gamma_move(board, 4, 40, 0) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 1, 2, 44) == 0 );
assert( gamma_move(board, 1, 2, 52) == 1 );
assert( gamma_move(board, 2, 37, 2) == 0 );
assert( gamma_golden_move(board, 2, 59, 2) == 0 );
assert( gamma_move(board, 3, 85, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 75, 2) == 0 );


char* board623020685 = gamma_board(board);
assert( board623020685 != NULL );
assert( strcmp(board623020685, 
"2..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".21\n"
"...\n"
".22\n"
"...\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
".2.\n"
"...\n"
"..3\n"
"2..\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"2.1\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
".11\n"
".2.\n"
"...\n"
"...\n"
"..4\n"
"..2\n"
"...\n"
"3..\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
"...\n"
"2..\n"
".14\n"
"..2\n"
"1..\n"
"34.\n"
"...\n"
"4..\n"
"...\n"
"..4\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"..3\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
"...\n"
"..4\n"
"4..\n"
"4..\n"
".1.\n") == 0);
free(board623020685);
board623020685 = NULL;
assert( gamma_move(board, 1, 1, 16) == 1 );
assert( gamma_move(board, 2, 24, 1) == 0 );
assert( gamma_move(board, 2, 2, 83) == 1 );
assert( gamma_move(board, 3, 42, 2) == 0 );
assert( gamma_move(board, 4, 35, 1) == 0 );
assert( gamma_move(board, 1, 63, 1) == 0 );
assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_move(board, 2, 90, 2) == 0 );
assert( gamma_move(board, 2, 1, 44) == 1 );
assert( gamma_free_fields(board, 2) == 224 );
assert( gamma_move(board, 3, 61, 2) == 0 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 71, 0) == 0 );
assert( gamma_move(board, 1, 90, 0) == 0 );
assert( gamma_move(board, 1, 2, 69) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 58, 0) == 0 );
assert( gamma_move(board, 2, 0, 31) == 1 );
assert( gamma_move(board, 3, 67, 1) == 0 );
assert( gamma_free_fields(board, 3) == 221 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 4, 0, 78) == 1 );
assert( gamma_move(board, 1, 1, 84) == 0 );
assert( gamma_move(board, 1, 1, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 73, 1) == 0 );
assert( gamma_move(board, 2, 0, 75) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 46, 0) == 0 );
assert( gamma_move(board, 1, 80, 2) == 0 );
assert( gamma_move(board, 1, 1, 29) == 1 );
assert( gamma_move(board, 2, 0, 35) == 0 );
assert( gamma_move(board, 3, 57, 1) == 0 );
assert( gamma_move(board, 3, 2, 44) == 0 );
assert( gamma_move(board, 4, 1, 20) == 1 );
assert( gamma_move(board, 4, 2, 44) == 0 );
assert( gamma_move(board, 1, 1, 22) == 1 );
assert( gamma_move(board, 1, 2, 91) == 1 );
assert( gamma_move(board, 2, 1, 77) == 1 );
assert( gamma_move(board, 3, 55, 2) == 0 );
assert( gamma_move(board, 3, 0, 25) == 1 );
assert( gamma_move(board, 4, 67, 1) == 0 );
assert( gamma_move(board, 1, 2, 46) == 1 );
assert( gamma_move(board, 2, 1, 57) == 1 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 4, 0, 89) == 1 );
assert( gamma_move(board, 4, 1, 55) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 78, 1) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 4, 17, 0) == 0 );
assert( gamma_move(board, 4, 2, 90) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 0, 77) == 1 );
assert( gamma_move(board, 4, 1, 37) == 0 );
assert( gamma_move(board, 4, 1, 27) == 1 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 1, 0, 21) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 2, 19, 1) == 0 );
assert( gamma_move(board, 2, 1, 48) == 1 );
assert( gamma_golden_move(board, 2, 37, 1) == 0 );
assert( gamma_move(board, 3, 1, 26) == 0 );
assert( gamma_busy_fields(board, 3) == 12 );


char* board943360780 = gamma_board(board);
assert( board943360780 != NULL );
assert( strcmp(board943360780, 
"2.1\n"
"..4\n"
"4..\n"
"...\n"
"...\n"
".21\n"
"...\n"
".22\n"
"..2\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
"42.\n"
"22.\n"
"..3\n"
"2..\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"2.1\n"
"...\n"
".21\n"
"...\n"
".4.\n"
"...\n"
"...\n"
".11\n"
".2.\n"
"...\n"
"...\n"
".24\n"
"..2\n"
"..1\n"
"3..\n"
".22\n"
"...\n"
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"2..\n"
".1.\n"
".1.\n"
"...\n"
"24.\n"
".14\n"
"3.2\n"
"1..\n"
"34.\n"
".1.\n"
"4..\n"
".4.\n"
"..4\n"
"...\n"
"...\n"
".1.\n"
"4..\n"
"...\n"
"..3\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"..3\n"
".3.\n"
"23.\n"
".1.\n"
"...\n"
"..4\n"
"41.\n"
"4..\n"
".1.\n") == 0);
free(board943360780);
board943360780 = NULL;
assert( gamma_move(board, 4, 1, 85) == 1 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 33, 1) == 0 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 1, 1, 40) == 1 );
assert( gamma_move(board, 2, 55, 2) == 0 );
assert( gamma_free_fields(board, 2) == 200 );
assert( gamma_move(board, 3, 29, 2) == 0 );
assert( gamma_move(board, 1, 81, 0) == 0 );
assert( gamma_move(board, 2, 29, 0) == 0 );
assert( gamma_move(board, 3, 68, 0) == 0 );
assert( gamma_move(board, 3, 2, 69) == 0 );
assert( gamma_move(board, 4, 86, 0) == 0 );
assert( gamma_move(board, 4, 2, 50) == 1 );
assert( gamma_free_fields(board, 4) == 199 );
assert( gamma_move(board, 1, 67, 1) == 0 );
assert( gamma_move(board, 1, 2, 29) == 1 );
assert( gamma_move(board, 2, 31, 2) == 0 );
assert( gamma_move(board, 2, 2, 33) == 1 );
assert( gamma_move(board, 3, 89, 2) == 0 );
assert( gamma_move(board, 3, 0, 51) == 1 );
assert( gamma_move(board, 4, 0, 21) == 0 );
assert( gamma_move(board, 4, 1, 88) == 1 );
assert( gamma_move(board, 1, 0, 78) == 0 );
assert( gamma_move(board, 1, 0, 88) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 74, 2) == 0 );
assert( gamma_move(board, 3, 1, 35) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_golden_move(board, 3, 86, 2) == 0 );
assert( gamma_move(board, 4, 71, 2) == 0 );
assert( gamma_move(board, 4, 2, 67) == 0 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 2, 76, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 1, 42) == 1 );
assert( gamma_move(board, 3, 1, 25) == 1 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 0, 18) == 1 );
assert( gamma_busy_fields(board, 1) == 28 );
assert( gamma_move(board, 3, 39, 2) == 0 );
assert( gamma_move(board, 3, 2, 65) == 1 );
assert( gamma_move(board, 4, 1, 90) == 1 );
assert( gamma_move(board, 4, 1, 28) == 1 );
assert( gamma_free_fields(board, 4) == 184 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 1, 49) == 1 );
assert( gamma_move(board, 2, 0, 15) == 0 );


char* board708992159 = gamma_board(board);
assert( board708992159 != NULL );
assert( strcmp(board708992159, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"...\n"
".21\n"
".4.\n"
".22\n"
"..2\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
"42.\n"
"22.\n"
"..3\n"
"2..\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"..1\n"
"..1\n"
"...\n"
"..3\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"2.1\n"
"...\n"
".21\n"
"...\n"
".4.\n"
"...\n"
"...\n"
".11\n"
"32.\n"
"..4\n"
".1.\n"
".24\n"
"..2\n"
"..1\n"
"3..\n"
".22\n"
"...\n"
".3.\n"
".3.\n"
".1.\n"
"...\n"
"...\n"
"11.\n"
"...\n"
"33.\n"
"...\n"
"..2\n"
"...\n"
"2..\n"
".1.\n"
".11\n"
".4.\n"
"24.\n"
".14\n"
"332\n"
"1..\n"
"34.\n"
".1.\n"
"4..\n"
".4.\n"
"..4\n"
"1..\n"
"...\n"
".1.\n"
"4..\n"
"...\n"
"..3\n"
"41.\n"
"...\n"
"...\n"
"...\n"
"..3\n"
".3.\n"
"23.\n"
".1.\n"
"...\n"
"434\n"
"41.\n"
"41.\n"
"41.\n") == 0);
free(board708992159);
board708992159 = NULL;
assert( gamma_move(board, 3, 28, 2) == 0 );
assert( gamma_move(board, 3, 0, 36) == 1 );
assert( gamma_move(board, 4, 45, 2) == 0 );
assert( gamma_move(board, 1, 65, 1) == 0 );
assert( gamma_move(board, 1, 2, 56) == 1 );
assert( gamma_golden_move(board, 1, 55, 1) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 3, 73, 1) == 0 );
assert( gamma_move(board, 3, 1, 27) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 4, 1, 20) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 1, 1, 59) == 1 );
assert( gamma_free_fields(board, 1) == 179 );
assert( gamma_move(board, 2, 41, 2) == 0 );
assert( gamma_golden_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 78, 2) == 0 );
assert( gamma_move(board, 3, 1, 25) == 0 );
assert( gamma_move(board, 4, 66, 0) == 0 );
assert( gamma_move(board, 4, 1, 78) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 34) == 1 );
assert( gamma_move(board, 1, 1, 67) == 1 );
assert( gamma_golden_move(board, 1, 31, 0) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 2, 63) == 1 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 34 );
assert( gamma_move(board, 2, 33, 1) == 0 );
assert( gamma_move(board, 2, 2, 83) == 0 );
assert( gamma_move(board, 4, 1, 56) == 1 );
assert( gamma_move(board, 4, 1, 61) == 1 );
assert( gamma_move(board, 1, 18, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 79, 0) == 0 );
assert( gamma_move(board, 2, 1, 38) == 1 );
assert( gamma_move(board, 3, 2, 61) == 1 );
assert( gamma_free_fields(board, 3) == 171 );
assert( gamma_move(board, 4, 67, 0) == 0 );
assert( gamma_move(board, 2, 68, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );


char* board154529390 = gamma_board(board);
assert( board154529390 != NULL );
assert( strcmp(board154529390, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"...\n"
".21\n"
".4.\n"
".22\n"
"..2\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
"42.\n"
"22.\n"
"..3\n"
"2..\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"..1\n"
".11\n"
"...\n"
"..3\n"
"...\n"
"4.2\n"
"...\n"
".43\n"
"3..\n"
"211\n"
"...\n"
".21\n"
".41\n"
".4.\n"
"...\n"
"...\n"
".11\n"
"32.\n"
"..4\n"
".1.\n"
".24\n"
"..2\n"
"..1\n"
"3..\n"
".22\n"
"...\n"
".3.\n"
".3.\n"
".1.\n"
"...\n"
".2.\n"
"11.\n"
"3..\n"
"33.\n"
".1.\n"
"..2\n"
"...\n"
"2..\n"
".1.\n"
".11\n"
".4.\n"
"24.\n"
".14\n"
"332\n"
"1..\n"
"34.\n"
".1.\n"
"4..\n"
".4.\n"
"..4\n"
"1..\n"
"...\n"
".1.\n"
"43.\n"
"...\n"
"..3\n"
"41.\n"
"...\n"
"1..\n"
"...\n"
"..3\n"
".3.\n"
"23.\n"
".1.\n"
"...\n"
"434\n"
"41.\n"
"41.\n"
"41.\n") == 0);
free(board154529390);
board154529390 = NULL;
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_free_fields(board, 4) == 171 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 1, 69) == 1 );
assert( gamma_free_fields(board, 2) == 169 );
assert( gamma_move(board, 3, 53, 0) == 0 );
assert( gamma_move(board, 3, 1, 35) == 0 );
assert( gamma_move(board, 4, 75, 2) == 0 );
assert( gamma_move(board, 1, 1, 75) == 1 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_move(board, 2, 2, 24) == 1 );
assert( gamma_golden_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 3, 1, 53) == 1 );
assert( gamma_move(board, 4, 76, 0) == 0 );
assert( gamma_move(board, 4, 2, 27) == 1 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 3, 1, 62) == 1 );
assert( gamma_move(board, 4, 70, 2) == 0 );
assert( gamma_move(board, 1, 31, 1) == 0 );
assert( gamma_move(board, 1, 1, 53) == 0 );
assert( gamma_move(board, 2, 0, 19) == 1 );
assert( gamma_move(board, 3, 31, 1) == 0 );
assert( gamma_move(board, 4, 16, 2) == 0 );
assert( gamma_move(board, 4, 1, 42) == 0 );
assert( gamma_move(board, 1, 39, 2) == 0 );
assert( gamma_move(board, 1, 1, 74) == 1 );
assert( gamma_move(board, 2, 0, 40) == 1 );
assert( gamma_move(board, 2, 2, 25) == 0 );
assert( gamma_move(board, 3, 2, 26) == 0 );
assert( gamma_move(board, 4, 17, 1) == 0 );
assert( gamma_move(board, 1, 2, 15) == 1 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 3, 82, 0) == 0 );
assert( gamma_move(board, 3, 0, 31) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_move(board, 1, 89, 1) == 0 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 67) == 0 );
assert( gamma_move(board, 4, 20, 2) == 0 );
assert( gamma_move(board, 1, 21, 2) == 0 );
assert( gamma_move(board, 1, 0, 43) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 2, 25) == 0 );
assert( gamma_move(board, 3, 60, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 1, 54) == 1 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 1, 18, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 58, 2) == 0 );
assert( gamma_move(board, 2, 2, 52) == 0 );
assert( gamma_move(board, 3, 2, 87) == 1 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 4, 1, 90) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 83) == 0 );
assert( gamma_move(board, 1, 1, 66) == 1 );
assert( gamma_move(board, 2, 81, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 57, 0) == 0 );
assert( gamma_move(board, 4, 47, 1) == 0 );
assert( gamma_move(board, 4, 2, 16) == 1 );
assert( gamma_move(board, 1, 79, 2) == 0 );
assert( gamma_move(board, 1, 0, 54) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 90, 0) == 0 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 3, 1, 39) == 1 );
assert( gamma_move(board, 4, 63, 1) == 0 );
assert( gamma_move(board, 4, 1, 46) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 2, 70, 2) == 0 );
assert( gamma_move(board, 3, 65, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 85, 2) == 0 );
assert( gamma_move(board, 1, 2, 61) == 0 );
assert( gamma_move(board, 2, 65, 0) == 0 );
assert( gamma_move(board, 2, 0, 48) == 1 );
assert( gamma_move(board, 3, 64, 2) == 0 );
assert( gamma_move(board, 3, 2, 75) == 1 );
assert( gamma_move(board, 4, 0, 66) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 32, 1) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 55, 0) == 0 );
assert( gamma_move(board, 3, 42, 0) == 0 );
assert( gamma_move(board, 4, 47, 1) == 0 );
assert( gamma_move(board, 1, 60, 2) == 0 );
assert( gamma_move(board, 1, 0, 54) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 81, 0) == 0 );


char* board396265494 = gamma_board(board);
assert( board396265494 != NULL );
assert( strcmp(board396265494, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"..3\n"
".21\n"
".4.\n"
".22\n"
"..2\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
"42.\n"
"22.\n"
"..3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"...\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
"..3\n"
"...\n"
"4.2\n"
".3.\n"
".43\n"
"3..\n"
"211\n"
"...\n"
".21\n"
".41\n"
".4.\n"
".4.\n"
".3.\n"
".11\n"
"32.\n"
"..4\n"
".1.\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"...\n"
".3.\n"
".3.\n"
"21.\n"
".3.\n"
".2.\n"
"11.\n"
"3..\n"
"33.\n"
".1.\n"
"..2\n"
"...\n"
"2..\n"
".1.\n"
".11\n"
".4.\n"
"244\n"
".14\n"
"332\n"
"1.2\n"
"34.\n"
".1.\n"
"4..\n"
".4.\n"
"2.4\n"
"1..\n"
"...\n"
".14\n"
"431\n"
".2.\n"
"..3\n"
"41.\n"
"...\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"23.\n"
".1.\n"
"...\n"
"434\n"
"412\n"
"41.\n"
"414\n") == 0);
free(board396265494);
board396265494 = NULL;
assert( gamma_move(board, 1, 46, 0) == 0 );
assert( gamma_move(board, 1, 0, 27) == 0 );
assert( gamma_move(board, 2, 20, 2) == 0 );
assert( gamma_move(board, 2, 2, 35) == 1 );
assert( gamma_move(board, 3, 33, 0) == 0 );
assert( gamma_move(board, 4, 1, 86) == 0 );
assert( gamma_free_fields(board, 4) == 143 );
assert( gamma_move(board, 1, 36, 1) == 0 );
assert( gamma_move(board, 2, 63, 1) == 0 );
assert( gamma_move(board, 3, 42, 0) == 0 );
assert( gamma_move(board, 3, 1, 66) == 0 );
assert( gamma_move(board, 4, 1, 58) == 1 );
assert( gamma_move(board, 1, 1, 89) == 0 );
assert( gamma_move(board, 2, 0, 58) == 1 );
assert( gamma_free_fields(board, 2) == 141 );
assert( gamma_move(board, 3, 83, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 2, 28) == 1 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 18, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 83, 0) == 0 );
assert( gamma_move(board, 4, 1, 54) == 0 );
assert( gamma_move(board, 1, 2, 55) == 1 );
assert( gamma_free_fields(board, 1) == 60 );
assert( gamma_move(board, 2, 0, 83) == 1 );
assert( gamma_move(board, 2, 0, 18) == 0 );
assert( gamma_free_fields(board, 2) == 138 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 3, 0, 26) == 1 );
assert( gamma_move(board, 4, 0, 62) == 1 );
assert( gamma_move(board, 1, 84, 0) == 0 );
assert( gamma_move(board, 1, 2, 36) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 37) == 0 );
assert( gamma_move(board, 3, 73, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 31) == 1 );
assert( gamma_move(board, 4, 0, 66) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 71) == 1 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 3, 1, 32) == 1 );
assert( gamma_golden_move(board, 3, 44, 2) == 0 );
assert( gamma_move(board, 4, 64, 1) == 0 );
assert( gamma_move(board, 4, 2, 24) == 0 );
assert( gamma_move(board, 1, 52, 0) == 0 );
assert( gamma_move(board, 1, 2, 33) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 0, 31) == 0 );
assert( gamma_free_fields(board, 2) == 133 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 21) == 0 );
assert( gamma_move(board, 3, 2, 26) == 0 );
assert( gamma_move(board, 4, 81, 0) == 0 );
assert( gamma_move(board, 1, 46, 0) == 0 );
assert( gamma_move(board, 1, 0, 45) == 0 );
assert( gamma_move(board, 2, 2, 53) == 1 );
assert( gamma_move(board, 3, 65, 0) == 0 );
assert( gamma_move(board, 4, 62, 2) == 0 );
assert( gamma_move(board, 4, 0, 38) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_golden_move(board, 1, 21, 0) == 0 );
assert( gamma_move(board, 2, 1, 23) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 78, 2) == 0 );
assert( gamma_move(board, 3, 1, 13) == 1 );


char* board231955836 = gamma_board(board);
assert( board231955836 != NULL );
assert( strcmp(board231955836, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"..3\n"
".21\n"
".4.\n"
".22\n"
"2.2\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
"42.\n"
"22.\n"
"..3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
".2.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
"..3\n"
"...\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
".11\n"
"32.\n"
"..4\n"
".1.\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"...\n"
".3.\n"
".3.\n"
"21.\n"
".3.\n"
"42.\n"
"11.\n"
"3..\n"
"332\n"
".1.\n"
"..2\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"1.2\n"
"34.\n"
".1.\n"
"4..\n"
".4.\n"
"2.4\n"
"1..\n"
"...\n"
".14\n"
"431\n"
".2.\n"
".33\n"
"41.\n"
"...\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"23.\n"
".1.\n"
"...\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board231955836);
board231955836 = NULL;
assert( gamma_move(board, 4, 81, 2) == 0 );
assert( gamma_move(board, 1, 72, 2) == 0 );
assert( gamma_move(board, 1, 0, 86) == 0 );
assert( gamma_move(board, 2, 80, 2) == 0 );
assert( gamma_move(board, 3, 73, 1) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 0, 71) == 1 );
assert( gamma_move(board, 1, 66, 2) == 0 );
assert( gamma_move(board, 2, 2, 52) == 0 );
assert( gamma_move(board, 3, 1, 50) == 1 );
assert( gamma_move(board, 4, 0, 84) == 1 );
assert( gamma_move(board, 4, 0, 20) == 1 );
assert( gamma_move(board, 1, 0, 34) == 1 );
assert( gamma_free_fields(board, 1) == 54 );
assert( gamma_move(board, 2, 2, 43) == 1 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_move(board, 3, 2, 49) == 1 );
assert( gamma_move(board, 1, 70, 0) == 0 );
assert( gamma_move(board, 1, 2, 83) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 70, 1) == 0 );
assert( gamma_move(board, 3, 0, 18) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_golden_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_free_fields(board, 1) == 51 );
assert( gamma_move(board, 2, 85, 0) == 0 );
assert( gamma_move(board, 3, 2, 39) == 1 );


char* board984399418 = gamma_board(board);
assert( board984399418 != NULL );
assert( strcmp(board984399418, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"..3\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"...\n"
"1..\n"
"...\n"
"42.\n"
"22.\n"
"..3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
"..3\n"
"...\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
".11\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".3.\n"
"21.\n"
".33\n"
"42.\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"..2\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"1.2\n"
"34.\n"
".1.\n"
"4..\n"
"44.\n"
"2.4\n"
"1..\n"
"...\n"
".14\n"
"431\n"
".23\n"
".33\n"
"41.\n"
"...\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"23.\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board984399418);
board984399418 = NULL;
assert( gamma_move(board, 4, 76, 0) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_golden_move(board, 1, 32, 1) == 0 );
assert( gamma_move(board, 2, 2, 77) == 1 );
assert( gamma_move(board, 2, 2, 39) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 21, 2) == 0 );
assert( gamma_move(board, 3, 1, 24) == 1 );
assert( gamma_move(board, 4, 21, 1) == 0 );
assert( gamma_move(board, 4, 0, 70) == 0 );
assert( gamma_busy_fields(board, 4) == 40 );
assert( gamma_move(board, 1, 0, 81) == 1 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 1, 24) == 0 );
assert( gamma_move(board, 4, 29, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_free_fields(board, 1) == 51 );
assert( gamma_move(board, 2, 0, 63) == 0 );
assert( gamma_move(board, 3, 30, 2) == 0 );
assert( gamma_move(board, 3, 1, 65) == 1 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_free_fields(board, 4) == 44 );


char* board787238950 = gamma_board(board);
assert( board787238950 != NULL );
assert( strcmp(board787238950, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"..3\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"1..\n"
"...\n"
"42.\n"
"222\n"
"..3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"...\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
".11\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".3.\n"
"21.\n"
".33\n"
"42.\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"..2\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"44.\n"
"2.4\n"
"1..\n"
"...\n"
".14\n"
"431\n"
".23\n"
".33\n"
"41.\n"
"...\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"23.\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board787238950);
board787238950 = NULL;
assert( gamma_move(board, 1, 2, 24) == 0 );


char* board553954767 = gamma_board(board);
assert( board553954767 != NULL );
assert( strcmp(board553954767, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"..3\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"1..\n"
"...\n"
"42.\n"
"222\n"
"..3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"...\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
".11\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".3.\n"
"21.\n"
".33\n"
"42.\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"..2\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"44.\n"
"2.4\n"
"1..\n"
"...\n"
".14\n"
"431\n"
".23\n"
".33\n"
"41.\n"
"...\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"23.\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board553954767);
board553954767 = NULL;
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 2, 59) == 0 );
assert( gamma_move(board, 3, 43, 1) == 0 );
assert( gamma_move(board, 3, 2, 64) == 1 );
assert( gamma_move(board, 4, 91, 1) == 0 );
assert( gamma_move(board, 1, 2, 84) == 0 );
assert( gamma_move(board, 1, 0, 64) == 0 );
assert( gamma_move(board, 2, 70, 2) == 0 );
assert( gamma_move(board, 3, 0, 76) == 1 );
assert( gamma_move(board, 3, 0, 33) == 1 );
assert( gamma_move(board, 4, 66, 2) == 0 );
assert( gamma_move(board, 1, 73, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 29, 0) == 0 );
assert( gamma_move(board, 3, 87, 0) == 0 );
assert( gamma_move(board, 3, 2, 38) == 1 );
assert( gamma_move(board, 4, 36, 2) == 0 );
assert( gamma_move(board, 4, 2, 18) == 1 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 72, 0) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 87, 1) == 0 );
assert( gamma_move(board, 3, 1, 58) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 1, 79, 2) == 0 );
assert( gamma_move(board, 1, 2, 38) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_golden_move(board, 2, 63, 0) == 0 );
assert( gamma_move(board, 3, 52, 0) == 0 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 4, 64, 0) == 0 );
assert( gamma_golden_move(board, 4, 38, 2) == 0 );


char* board604034509 = gamma_board(board);
assert( board604034509 != NULL );
assert( strcmp(board604034509, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"..3\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"1..\n"
"...\n"
"42.\n"
"222\n"
"3.3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
".11\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".3.\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"3.2\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"44.\n"
"2.4\n"
"1.4\n"
"...\n"
".14\n"
"431\n"
".23\n"
".33\n"
"41.\n"
"...\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"233\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board604034509);
board604034509 = NULL;
assert( gamma_move(board, 1, 60, 1) == 0 );
assert( gamma_move(board, 1, 1, 88) == 0 );
assert( gamma_move(board, 2, 91, 1) == 0 );
assert( gamma_move(board, 3, 51, 2) == 0 );
assert( gamma_move(board, 1, 53, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 74, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 88, 2) == 0 );
assert( gamma_move(board, 4, 82, 0) == 0 );
assert( gamma_move(board, 1, 2, 78) == 0 );
assert( gamma_move(board, 2, 0, 17) == 1 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 55, 0) == 0 );
assert( gamma_move(board, 3, 2, 48) == 0 );
assert( gamma_move(board, 4, 0, 26) == 0 );
assert( gamma_busy_fields(board, 4) == 41 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 45, 2) == 0 );
assert( gamma_move(board, 4, 1, 68) == 0 );
assert( gamma_move(board, 1, 0, 52) == 1 );
assert( gamma_move(board, 1, 1, 3) == 0 );


char* board142998423 = gamma_board(board);
assert( board142998423 != NULL );
assert( strcmp(board142998423, 
"2.1\n"
".44\n"
"4..\n"
"14.\n"
"..3\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"1..\n"
"...\n"
"42.\n"
"222\n"
"3.3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".3.\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"3.2\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"44.\n"
"2.4\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
".23\n"
".33\n"
"41.\n"
"...\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"233\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board142998423);
board142998423 = NULL;
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 17, 2) == 0 );
assert( gamma_move(board, 4, 47, 1) == 0 );
assert( gamma_move(board, 4, 0, 50) == 0 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 56) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 2, 29) == 0 );
assert( gamma_free_fields(board, 2) == 49 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 3, 0, 87) == 1 );
assert( gamma_move(board, 4, 1, 44) == 0 );
assert( gamma_move(board, 4, 0, 83) == 0 );
assert( gamma_busy_fields(board, 1) == 45 );
assert( gamma_move(board, 2, 49, 0) == 0 );
assert( gamma_free_fields(board, 2) == 49 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 83, 1) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 4, 57, 0) == 0 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_move(board, 1, 21, 1) == 0 );
assert( gamma_move(board, 2, 74, 0) == 0 );
assert( gamma_move(board, 2, 2, 50) == 0 );
assert( gamma_move(board, 3, 1, 32) == 0 );
assert( gamma_move(board, 4, 2, 59) == 0 );
assert( gamma_move(board, 1, 55, 0) == 0 );
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_move(board, 2, 2, 47) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 54) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 4, 0, 90) == 1 );
assert( gamma_busy_fields(board, 4) == 42 );
assert( gamma_move(board, 1, 80, 2) == 0 );
assert( gamma_move(board, 2, 0, 29) == 0 );
assert( gamma_move(board, 3, 23, 2) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_move(board, 4, 0, 11) == 1 );
assert( gamma_move(board, 1, 28, 0) == 0 );
assert( gamma_move(board, 1, 2, 52) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 30, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 32, 0) == 0 );
assert( gamma_move(board, 1, 0, 19) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );


char* board107915150 = gamma_board(board);
assert( board107915150 != NULL );
assert( strcmp(board107915150, 
"2.1\n"
"444\n"
"4..\n"
"14.\n"
"3.3\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"1..\n"
"...\n"
"42.\n"
"222\n"
"3.3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".3.\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"3.2\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"44.\n"
"2.4\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
".33\n"
"41.\n"
"4..\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"233\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board107915150);
board107915150 = NULL;
assert( gamma_move(board, 4, 32, 2) == 0 );
assert( gamma_move(board, 4, 0, 51) == 0 );
assert( gamma_move(board, 1, 21, 2) == 0 );
assert( gamma_move(board, 1, 1, 67) == 0 );
assert( gamma_move(board, 2, 36, 1) == 0 );


char* board502022435 = gamma_board(board);
assert( board502022435 != NULL );
assert( strcmp(board502022435, 
"2.1\n"
"444\n"
"4..\n"
"14.\n"
"3.3\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"1..\n"
"...\n"
"42.\n"
"222\n"
"3.3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".3.\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"3.2\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"44.\n"
"2.4\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
".33\n"
"41.\n"
"4..\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"233\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board502022435);
board502022435 = NULL;
assert( gamma_move(board, 4, 1, 33) == 1 );
assert( gamma_move(board, 4, 2, 20) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 42, 0) == 0 );
assert( gamma_move(board, 2, 22, 0) == 0 );
assert( gamma_move(board, 2, 1, 60) == 0 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_move(board, 3, 1, 87) == 1 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_free_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 53, 0) == 0 );
assert( gamma_move(board, 3, 78, 2) == 0 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_move(board, 4, 1, 28) == 0 );
assert( gamma_golden_move(board, 4, 25, 2) == 0 );
assert( gamma_move(board, 1, 82, 2) == 0 );
assert( gamma_move(board, 2, 44, 0) == 0 );
assert( gamma_move(board, 2, 1, 46) == 0 );
assert( gamma_move(board, 3, 2, 35) == 0 );
assert( gamma_move(board, 4, 23, 2) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 30) == 0 );
assert( gamma_move(board, 1, 1, 45) == 0 );
assert( gamma_move(board, 2, 29, 0) == 0 );
assert( gamma_move(board, 2, 1, 80) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 71, 2) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 1, 77) == 0 );
assert( gamma_move(board, 1, 44, 0) == 0 );


char* board662684030 = gamma_board(board);
assert( board662684030 != NULL );
assert( strcmp(board662684030, 
"2.1\n"
"444\n"
"4..\n"
"14.\n"
"333\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"1..\n"
"...\n"
"42.\n"
"222\n"
"3.3\n"
"213\n"
".1.\n"
"4..\n"
"...\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".3.\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"342\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
".44\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"444\n"
"2.4\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
".33\n"
"41.\n"
"4..\n"
"1.1\n"
"31.\n"
"..3\n"
"231\n"
"233\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"314\n") == 0);
free(board662684030);
board662684030 = NULL;
assert( gamma_move(board, 2, 17, 2) == 0 );
assert( gamma_move(board, 3, 56, 0) == 0 );
assert( gamma_move(board, 4, 49, 0) == 0 );
assert( gamma_move(board, 1, 57, 0) == 0 );
assert( gamma_move(board, 2, 2, 83) == 0 );
assert( gamma_golden_move(board, 2, 36, 2) == 0 );
assert( gamma_move(board, 3, 0, 90) == 0 );
assert( gamma_move(board, 3, 2, 83) == 0 );
assert( gamma_free_fields(board, 3) == 101 );
assert( gamma_free_fields(board, 4) == 101 );
assert( gamma_golden_move(board, 4, 51, 1) == 0 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 18, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 1, 76) == 1 );
assert( gamma_move(board, 4, 2, 48) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 2, 65) == 0 );
assert( gamma_move(board, 2, 39, 0) == 0 );
assert( gamma_golden_move(board, 2, 81, 0) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_golden_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 1, 50) == 0 );
assert( gamma_move(board, 3, 1, 90) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 4, 74, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 45 );
assert( gamma_move(board, 1, 0, 88) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 2, 0, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 45 );
assert( gamma_golden_move(board, 3, 50, 2) == 0 );
assert( gamma_move(board, 4, 68, 1) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 1, 1, 24) == 0 );
assert( gamma_move(board, 2, 42, 2) == 0 );
assert( gamma_move(board, 2, 1, 72) == 1 );
assert( gamma_free_fields(board, 2) == 45 );
assert( gamma_move(board, 3, 82, 0) == 0 );
assert( gamma_move(board, 3, 1, 33) == 0 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_move(board, 1, 2, 59) == 0 );
assert( gamma_move(board, 2, 72, 0) == 0 );
assert( gamma_move(board, 3, 67, 0) == 0 );
assert( gamma_move(board, 4, 60, 2) == 0 );
assert( gamma_move(board, 1, 79, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 53, 0) == 0 );
assert( gamma_move(board, 2, 1, 61) == 0 );
assert( gamma_move(board, 3, 54, 0) == 0 );
assert( gamma_free_fields(board, 3) == 97 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 41) == 1 );
assert( gamma_move(board, 4, 2, 25) == 0 );
assert( gamma_free_fields(board, 4) == 41 );
assert( gamma_move(board, 1, 60, 1) == 0 );
assert( gamma_move(board, 2, 0, 59) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 1, 89) == 1 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 47 );
assert( gamma_move(board, 1, 82, 2) == 0 );
assert( gamma_move(board, 1, 1, 26) == 0 );
assert( gamma_move(board, 2, 86, 0) == 0 );
assert( gamma_move(board, 2, 1, 58) == 0 );
assert( gamma_move(board, 3, 1, 19) == 1 );
assert( gamma_move(board, 3, 2, 55) == 0 );
assert( gamma_move(board, 4, 1, 49) == 0 );
assert( gamma_move(board, 4, 1, 79) == 1 );
assert( gamma_move(board, 1, 2, 41) == 0 );
assert( gamma_move(board, 2, 74, 0) == 0 );
assert( gamma_move(board, 2, 2, 76) == 0 );
assert( gamma_busy_fields(board, 2) == 43 );
assert( gamma_move(board, 3, 66, 2) == 0 );
assert( gamma_move(board, 3, 0, 71) == 0 );
assert( gamma_free_fields(board, 3) == 93 );
assert( gamma_move(board, 4, 66, 2) == 0 );
assert( gamma_move(board, 4, 1, 28) == 0 );
assert( gamma_busy_fields(board, 4) == 48 );
assert( gamma_move(board, 1, 44, 0) == 0 );
assert( gamma_move(board, 1, 2, 69) == 0 );
assert( gamma_move(board, 2, 17, 2) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 0, 28) == 1 );
assert( gamma_move(board, 3, 1, 68) == 0 );
assert( gamma_move(board, 4, 0, 78) == 0 );
assert( gamma_move(board, 4, 2, 81) == 0 );
assert( gamma_move(board, 1, 0, 60) == 0 );
assert( gamma_move(board, 1, 2, 33) == 0 );
assert( gamma_move(board, 2, 70, 2) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_free_fields(board, 2) == 42 );
assert( gamma_move(board, 4, 2, 87) == 0 );
assert( gamma_move(board, 1, 1, 80) == 1 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_free_fields(board, 2) == 42 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 3, 1, 48) == 0 );
assert( gamma_golden_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 0, 51) == 0 );
assert( gamma_move(board, 4, 0, 0) == 0 );
assert( gamma_move(board, 1, 70, 0) == 0 );
assert( gamma_move(board, 2, 67, 0) == 0 );
assert( gamma_move(board, 3, 1, 66) == 0 );
assert( gamma_move(board, 4, 18, 1) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 3, 55, 0) == 0 );
assert( gamma_move(board, 4, 39, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 48 );
assert( gamma_move(board, 1, 1, 30) == 0 );
assert( gamma_move(board, 1, 0, 89) == 0 );
assert( gamma_golden_move(board, 1, 54, 2) == 0 );
assert( gamma_move(board, 2, 79, 2) == 0 );
assert( gamma_move(board, 2, 0, 22) == 0 );
assert( gamma_move(board, 3, 53, 0) == 0 );
assert( gamma_move(board, 3, 1, 54) == 0 );
assert( gamma_move(board, 1, 0, 32) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 85, 0) == 0 );
assert( gamma_free_fields(board, 2) == 42 );
assert( gamma_golden_move(board, 2, 65, 2) == 0 );
assert( gamma_move(board, 3, 79, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );
assert( gamma_move(board, 4, 37, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 48 );
assert( gamma_free_fields(board, 4) == 39 );
assert( gamma_golden_move(board, 4, 59, 1) == 0 );
assert( gamma_move(board, 1, 83, 1) == 0 );
assert( gamma_move(board, 1, 1, 33) == 0 );


char* board553964946 = gamma_board(board);
assert( board553964946 != NULL );
assert( strcmp(board553964946, 
"2.1\n"
"444\n"
"44.\n"
"14.\n"
"333\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"11.\n"
".4.\n"
"42.\n"
"222\n"
"343\n"
"213\n"
".1.\n"
"4..\n"
".2.\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
".41\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".34\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"342\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
"344\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"444\n"
"234\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
"233\n"
"41.\n"
"4..\n"
"1.1\n"
"31.\n"
".33\n"
"231\n"
"233\n"
".1.\n"
".4.\n"
"434\n"
"412\n"
"41.\n"
"311\n") == 0);
free(board553964946);
board553964946 = NULL;
assert( gamma_move(board, 2, 43, 0) == 0 );
assert( gamma_move(board, 2, 1, 61) == 0 );
assert( gamma_move(board, 3, 22, 2) == 0 );
assert( gamma_move(board, 4, 57, 0) == 0 );
assert( gamma_move(board, 4, 0, 23) == 0 );
assert( gamma_move(board, 1, 1, 31) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 48) == 0 );
assert( gamma_move(board, 3, 1, 30) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );
assert( gamma_move(board, 4, 2, 47) == 0 );
assert( gamma_move(board, 4, 1, 73) == 1 );
assert( gamma_move(board, 1, 36, 2) == 0 );
assert( gamma_move(board, 1, 1, 54) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 0, 55) == 0 );
assert( gamma_busy_fields(board, 2) == 43 );
assert( gamma_move(board, 3, 21, 1) == 0 );
assert( gamma_move(board, 3, 0, 30) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );
assert( gamma_move(board, 4, 2, 43) == 0 );
assert( gamma_move(board, 4, 2, 60) == 0 );
assert( gamma_move(board, 1, 60, 2) == 0 );
assert( gamma_move(board, 1, 2, 31) == 0 );
assert( gamma_move(board, 2, 1, 52) == 0 );
assert( gamma_move(board, 3, 1, 22) == 0 );
assert( gamma_move(board, 4, 40, 2) == 0 );
assert( gamma_golden_move(board, 4, 26, 1) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 85, 0) == 0 );
assert( gamma_move(board, 2, 0, 29) == 0 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 42, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 49 );
assert( gamma_move(board, 1, 0, 19) == 0 );
assert( gamma_free_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 22, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 43 );
assert( gamma_move(board, 3, 22, 2) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 2, 49) == 0 );
assert( gamma_free_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 2, 72) == 1 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 4, 2, 48) == 0 );
assert( gamma_move(board, 4, 1, 91) == 1 );
assert( gamma_busy_fields(board, 4) == 50 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 77, 1) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 82, 0) == 0 );
assert( gamma_move(board, 3, 70, 1) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 36, 2) == 0 );
assert( gamma_move(board, 4, 0, 56) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 89, 2) == 0 );
assert( gamma_move(board, 1, 1, 42) == 0 );
assert( gamma_move(board, 2, 66, 2) == 0 );
assert( gamma_move(board, 3, 64, 0) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_golden_move(board, 3, 20, 0) == 0 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 4, 2, 16) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 88, 2) == 0 );
assert( gamma_move(board, 1, 2, 35) == 0 );


char* board612625242 = gamma_board(board);
assert( board612625242 != NULL );
assert( strcmp(board612625242, 
"241\n"
"444\n"
"44.\n"
"14.\n"
"333\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"11.\n"
".4.\n"
"42.\n"
"222\n"
"343\n"
"213\n"
".1.\n"
"44.\n"
".22\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
"441\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".34\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"342\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
"344\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"444\n"
"234\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
"233\n"
"41.\n"
"4..\n"
"1.1\n"
"31.\n"
".33\n"
"231\n"
"233\n"
".1.\n"
"44.\n"
"434\n"
"412\n"
"41.\n"
"311\n") == 0);
free(board612625242);
board612625242 = NULL;
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 0, 91) == 0 );
assert( gamma_move(board, 3, 1, 25) == 0 );
assert( gamma_move(board, 3, 2, 81) == 0 );
assert( gamma_move(board, 4, 74, 2) == 0 );


char* board772385690 = gamma_board(board);
assert( board772385690 != NULL );
assert( strcmp(board772385690, 
"241\n"
"444\n"
"44.\n"
"14.\n"
"333\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"11.\n"
".4.\n"
"42.\n"
"222\n"
"343\n"
"213\n"
".1.\n"
"44.\n"
".22\n"
"22.\n"
"...\n"
".21\n"
"..1\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
"441\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".34\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"342\n"
".3.\n"
"24.\n"
".1.\n"
".11\n"
"344\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
".1.\n"
"4..\n"
"444\n"
"234\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
"233\n"
"41.\n"
"4..\n"
"1.1\n"
"31.\n"
".33\n"
"231\n"
"233\n"
".1.\n"
"44.\n"
"434\n"
"412\n"
"41.\n"
"311\n") == 0);
free(board772385690);
board772385690 = NULL;
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 1, 2, 80) == 1 );
assert( gamma_move(board, 2, 30, 2) == 0 );
assert( gamma_move(board, 2, 0, 37) == 0 );
assert( gamma_move(board, 3, 1, 21) == 0 );
assert( gamma_move(board, 4, 62, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 52 );
assert( gamma_move(board, 1, 61, 0) == 0 );
assert( gamma_move(board, 3, 0, 19) == 0 );
assert( gamma_move(board, 4, 70, 2) == 0 );
assert( gamma_move(board, 1, 23, 2) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 2, 1, 56) == 0 );
assert( gamma_move(board, 2, 1, 68) == 1 );
assert( gamma_move(board, 3, 60, 2) == 0 );
assert( gamma_move(board, 3, 0, 43) == 0 );
assert( gamma_move(board, 4, 2, 25) == 0 );
assert( gamma_move(board, 4, 0, 60) == 0 );
assert( gamma_free_fields(board, 4) == 84 );
assert( gamma_move(board, 1, 70, 1) == 0 );
assert( gamma_move(board, 1, 0, 90) == 0 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 2, 68, 0) == 0 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_move(board, 4, 2, 73) == 1 );
assert( gamma_free_fields(board, 4) == 81 );
assert( gamma_move(board, 1, 0, 30) == 1 );
assert( gamma_move(board, 1, 0, 22) == 1 );
assert( gamma_golden_move(board, 1, 20, 0) == 0 );
assert( gamma_move(board, 2, 29, 0) == 0 );
assert( gamma_move(board, 3, 43, 0) == 0 );
assert( gamma_free_fields(board, 3) == 35 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 31, 2) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );


char* board909791888 = gamma_board(board);
assert( board909791888 != NULL );
assert( strcmp(board909791888, 
"241\n"
"444\n"
"44.\n"
"14.\n"
"333\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"111\n"
".4.\n"
"42.\n"
"222\n"
"343\n"
"213\n"
".1.\n"
"444\n"
".22\n"
"22.\n"
"...\n"
".21\n"
".21\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
"441\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".34\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"342\n"
".3.\n"
"24.\n"
"11.\n"
".11\n"
"344\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
"11.\n"
"4..\n"
"444\n"
"234\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
"233\n"
"41.\n"
"4..\n"
"1.1\n"
"313\n"
".33\n"
"231\n"
"233\n"
".13\n"
"44.\n"
"434\n"
"412\n"
"41.\n"
"311\n") == 0);
free(board909791888);
board909791888 = NULL;
assert( gamma_move(board, 3, 0, 38) == 0 );
assert( gamma_golden_move(board, 3, 0, 2) == 0 );


char* board107609830 = gamma_board(board);
assert( board107609830 != NULL );
assert( strcmp(board107609830, 
"241\n"
"444\n"
"44.\n"
"14.\n"
"333\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"111\n"
".4.\n"
"42.\n"
"222\n"
"343\n"
"213\n"
".1.\n"
"444\n"
".22\n"
"22.\n"
"...\n"
".21\n"
".21\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"43.\n"
".43\n"
"3..\n"
"211\n"
"24.\n"
".21\n"
"441\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
"..2\n"
".3.\n"
".34\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"342\n"
".3.\n"
"24.\n"
"11.\n"
".11\n"
"344\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
"11.\n"
"4..\n"
"444\n"
"234\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
"233\n"
"41.\n"
"4..\n"
"1.1\n"
"313\n"
".33\n"
"231\n"
"233\n"
".13\n"
"44.\n"
"434\n"
"412\n"
"41.\n"
"311\n") == 0);
free(board107609830);
board107609830 = NULL;
assert( gamma_move(board, 4, 64, 1) == 0 );
assert( gamma_free_fields(board, 4) == 79 );
assert( gamma_golden_move(board, 1, 24, 2) == 0 );
assert( gamma_move(board, 3, 54, 0) == 0 );
assert( gamma_move(board, 4, 1, 43) == 1 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 43, 0) == 0 );
assert( gamma_move(board, 1, 1, 46) == 0 );
assert( gamma_move(board, 2, 2, 25) == 0 );
assert( gamma_move(board, 3, 36, 1) == 0 );
assert( gamma_move(board, 3, 2, 62) == 1 );
assert( gamma_move(board, 4, 74, 2) == 0 );
assert( gamma_move(board, 4, 1, 44) == 0 );
assert( gamma_move(board, 1, 58, 2) == 0 );
assert( gamma_move(board, 1, 1, 49) == 0 );
assert( gamma_move(board, 2, 70, 2) == 0 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_golden_move(board, 2, 57, 2) == 0 );
assert( gamma_move(board, 3, 32, 2) == 0 );
assert( gamma_move(board, 3, 2, 58) == 1 );
assert( gamma_move(board, 4, 45, 1) == 0 );
assert( gamma_move(board, 1, 2, 27) == 0 );
assert( gamma_move(board, 2, 70, 1) == 0 );
assert( gamma_move(board, 2, 0, 88) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 1, 74) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 1, 83) == 0 );
assert( gamma_move(board, 4, 0, 37) == 0 );
assert( gamma_move(board, 2, 2, 38) == 0 );
assert( gamma_free_fields(board, 2) == 36 );
assert( gamma_move(board, 3, 0, 6) == 0 );


char* board663526485 = gamma_board(board);
assert( board663526485 != NULL );
assert( strcmp(board663526485, 
"241\n"
"444\n"
"44.\n"
"14.\n"
"333\n"
".21\n"
".4.\n"
"422\n"
"2.2\n"
".3.\n"
"1..\n"
"111\n"
".4.\n"
"42.\n"
"222\n"
"343\n"
"213\n"
".1.\n"
"444\n"
".22\n"
"22.\n"
"...\n"
".21\n"
".21\n"
".11\n"
"41.\n"
".33\n"
"..3\n"
"4.2\n"
"433\n"
".43\n"
"3..\n"
"211\n"
"243\n"
".21\n"
"441\n"
".41\n"
".4.\n"
".32\n"
"111\n"
"32.\n"
".34\n"
".13\n"
"224\n"
"..2\n"
".41\n"
"3..\n"
".22\n"
".42\n"
".3.\n"
".34\n"
"21.\n"
".33\n"
"423\n"
"11.\n"
"3..\n"
"332\n"
"11.\n"
"342\n"
".3.\n"
"24.\n"
"11.\n"
".11\n"
"344\n"
"244\n"
"314\n"
"332\n"
"132\n"
"34.\n"
"11.\n"
"4..\n"
"444\n"
"234\n"
"1.4\n"
"2..\n"
".14\n"
"431\n"
"223\n"
"233\n"
"41.\n"
"4..\n"
"1.1\n"
"313\n"
".33\n"
"231\n"
"233\n"
".13\n"
"44.\n"
"434\n"
"412\n"
"41.\n"
"311\n") == 0);
free(board663526485);
board663526485 = NULL;
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 54 );


gamma_delete(board);

    return 0;
}
