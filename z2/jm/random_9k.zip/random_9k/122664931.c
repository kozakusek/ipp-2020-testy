#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 122664931
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 17, 4, 45);
assert( board != NULL );


assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 1, 10, 1) == 1 );
assert( gamma_free_fields(board, 1) == 236 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 4, 9, 7) == 1 );
assert( gamma_move(board, 4, 12, 16) == 1 );
assert( gamma_move(board, 1, 12, 8) == 1 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 16, 1) == 0 );
assert( gamma_move(board, 4, 9, 3) == 1 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 1, 13, 3) == 1 );
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 3 );
assert( gamma_move(board, 1, 1, 5) == 1 );
assert( gamma_move(board, 1, 7, 1) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 4, 10, 9) == 1 );
assert( gamma_golden_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_move(board, 2, 7, 10) == 1 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 3, 11, 13) == 1 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 3, 3, 12) == 1 );
assert( gamma_move(board, 3, 9, 16) == 1 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_free_fields(board, 1) == 211 );
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_move(board, 3, 0, 13) == 1 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_move(board, 3, 3, 11) == 1 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 6, 16) == 1 );
assert( gamma_move(board, 1, 8, 15) == 1 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 2, 12, 2) == 1 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_free_fields(board, 4) == 196 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 3, 11, 4) == 1 );
assert( gamma_move(board, 4, 6, 12) == 1 );
assert( gamma_move(board, 1, 12, 13) == 1 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_free_fields(board, 1) == 190 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 10) == 1 );
assert( gamma_golden_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_move(board, 1, 2, 16) == 1 );


char* board268402555 = gamma_board(board);
assert( board268402555 != NULL );
assert( strcmp(board268402555, 
"..1...1..3..4.\n"
"........1.....\n"
"....3.........\n"
"3..2..1....31.\n"
"...3..4.21....\n"
"..13..........\n"
"3..2...2....3.\n"
"..........4..2\n"
".34...1.....1.\n"
"..4...2..4....\n"
"..13..........\n"
".1......3.....\n"
"......2..1.3..\n"
"...4....24...1\n"
"...21...2..12.\n"
".......1..1...\n"
".....3.21..2..\n") == 0);
free(board268402555);
board268402555 = NULL;
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 2, 10, 7) == 1 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_golden_move(board, 3, 13, 3) == 1 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 4, 9, 11) == 1 );


char* board529798795 = gamma_board(board);
assert( board529798795 != NULL );
assert( strcmp(board529798795, 
"..1...1..3..4.\n"
"........1.....\n"
"....3.........\n"
"3..2..1....31.\n"
"...3..4.21....\n"
"..13.....4....\n"
"3..2...2....3.\n"
".........34..2\n"
".34...1.2...1.\n"
"..4...2..42...\n"
"..13..........\n"
".1......3.....\n"
"......2..1.3..\n"
"...4....24...3\n"
"...21...2..12.\n"
".......1..1...\n"
".....3.21..2..\n") == 0);
free(board529798795);
board529798795 = NULL;
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 4, 11) == 1 );
assert( gamma_move(board, 3, 13, 2) == 1 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_move(board, 4, 12, 9) == 1 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 1, 9, 2) == 1 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 1, 2, 15) == 1 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 3, 10, 14) == 1 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 12, 12) == 1 );
assert( gamma_move(board, 3, 2, 1) == 1 );


char* board635571571 = gamma_board(board);
assert( board635571571 != NULL );
assert( strcmp(board635571571, 
"..1...1..3..4.\n"
"..1.....1.....\n"
"....3.....3...\n"
"3..2..1....31.\n"
"...3..4.21..3.\n"
"..132....4....\n"
"3..2...2...43.\n"
".........34.42\n"
".34...1.2...1.\n"
"..4..22..42...\n"
"..13..........\n"
".1..33..3.....\n"
"......2..1.3..\n"
"...4....24...3\n"
"...21...21.123\n"
"..3.4..1..1.2.\n"
".....3.21..2..\n") == 0);
free(board635571571);
board635571571 = NULL;
assert( gamma_move(board, 4, 11, 1) == 1 );
assert( gamma_move(board, 4, 8, 14) == 1 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 1, 6, 14) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 2, 5, 7) == 0 );


char* board247750403 = gamma_board(board);
assert( board247750403 != NULL );
assert( strcmp(board247750403, 
"..1...1..3..4.\n"
"..1.....1.....\n"
"....3.1.4.3...\n"
"3..2..1....31.\n"
"...3..4.21..3.\n"
"..132....4....\n"
"3..2...2...43.\n"
"....2....34.42\n"
".34...1.2...1.\n"
"..4..22..42...\n"
"..13..........\n"
".1..334.3.....\n"
"......2..133..\n"
"...4....24...3\n"
"...21...21.123\n"
"..3.4..1..142.\n"
".....3.21..2..\n") == 0);
free(board247750403);
board247750403 = NULL;
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 2, 5, 8) == 1 );


char* board613119609 = gamma_board(board);
assert( board613119609 != NULL );
assert( strcmp(board613119609, 
"..1...1..3..4.\n"
"..1.....1.....\n"
"....3.1.4.3...\n"
"3..2..1....31.\n"
"...3..4.21..3.\n"
"..132....4....\n"
"3..2...2...43.\n"
"....2....34.42\n"
".34..21121..1.\n"
"..4..22..42...\n"
"..13..........\n"
".1..334.3.....\n"
"......2..133..\n"
"...4....24...3\n"
"...21...21.123\n"
"..3.4..1..142.\n"
"...3.3.21..2..\n") == 0);
free(board613119609);
board613119609 = NULL;
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 9, 5) == 1 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 2, 13, 10) == 1 );
assert( gamma_move(board, 3, 13, 7) == 1 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 4, 14, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 1, 7, 12) == 1 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 2, 9, 15) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_move(board, 4, 2, 10) == 1 );
assert( gamma_move(board, 4, 3, 9) == 1 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 2, 11, 11) == 1 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 1, 13, 1) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 16, 11) == 0 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 3, 8, 16) == 1 );
assert( gamma_move(board, 3, 3, 15) == 1 );
assert( gamma_free_fields(board, 3) == 139 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_move(board, 2, 0, 16) == 1 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_free_fields(board, 2) == 137 );
assert( gamma_move(board, 3, 11, 13) == 0 );
assert( gamma_move(board, 3, 10, 10) == 1 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_move(board, 1, 2, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 2, 12, 3) == 1 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 10, 8) == 1 );


char* board196551775 = gamma_board(board);
assert( board196551775 != NULL );
assert( strcmp(board196551775, 
"2.1...1.33..4.\n"
"..13....12....\n"
"....3.1.4.3...\n"
"3..2..1....31.\n"
"...3.24121..3.\n"
"..132....4.2..\n"
"3.42...2..3432\n"
"..342....34342\n"
".34.3211211.1.\n"
"..4.422..42..3\n"
"..13..1.......\n"
".1..334.34....\n"
"2.1...2..133..\n"
"...4.4..24..23\n"
"2..21...21.123\n"
"..3.4.21..1421\n"
"...3.3.21..2..\n") == 0);
free(board196551775);
board196551775 = NULL;
assert( gamma_move(board, 2, 14, 7) == 0 );


char* board536167431 = gamma_board(board);
assert( board536167431 != NULL );
assert( strcmp(board536167431, 
"2.1...1.33..4.\n"
"..13....12....\n"
"....3.1.4.3...\n"
"3..2..1....31.\n"
"...3.24121..3.\n"
"..132....4.2..\n"
"3.42...2..3432\n"
"..342....34342\n"
".34.3211211.1.\n"
"..4.422..42..3\n"
"..13..1.......\n"
".1..334.34....\n"
"2.1...2..133..\n"
"...4.4..24..23\n"
"2..21...21.123\n"
"..3.4.21..1421\n"
"...3.3.21..2..\n") == 0);
free(board536167431);
board536167431 = NULL;
assert( gamma_move(board, 3, 16, 13) == 0 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_golden_move(board, 3, 5, 9) == 0 );
assert( gamma_free_fields(board, 4) == 128 );
assert( gamma_move(board, 1, 4, 13) == 1 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_free_fields(board, 4) == 127 );
assert( gamma_move(board, 1, 5, 13) == 1 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_free_fields(board, 2) == 125 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_golden_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 10, 10) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_free_fields(board, 1) == 125 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 3, 11, 15) == 1 );
assert( gamma_golden_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 13, 4) == 1 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_free_fields(board, 4) == 120 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 1, 12, 14) == 1 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_move(board, 4, 12, 7) == 1 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 2, 7, 11) == 1 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_free_fields(board, 3) == 113 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_free_fields(board, 1) == 113 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 8, 10) == 1 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 12, 12) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 4, 15) == 1 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 11, 7) == 1 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_move(board, 2, 12, 16) == 0 );
assert( gamma_free_fields(board, 2) == 104 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_golden_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 40 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 2, 7, 5) == 1 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 16, 3) == 0 );
assert( gamma_move(board, 4, 10, 11) == 1 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_free_fields(board, 1) == 99 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 3, 13, 8) == 1 );
assert( gamma_move(board, 4, 13, 5) == 1 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_golden_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );


char* board235192749 = gamma_board(board);
assert( board235192749 != NULL );
assert( strcmp(board235192749, 
"2.1...1.33..4.\n"
"..133...12.3..\n"
"....3.134.3.1.\n"
"3.22111....31.\n"
".3.3324121..3.\n"
"..132..2.442..\n"
"3.42...24.3432\n"
".4342....34342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13..1..32...\n"
"311.33423434.4\n"
"2.1.4.2..133.4\n"
"...424..24..23\n"
"2.421...21.123\n"
"2.334.21..1421\n"
"...3.3.212.2..\n") == 0);
free(board235192749);
board235192749 = NULL;
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 1, 10, 14) == 0 );


char* board744565757 = gamma_board(board);
assert( board744565757 != NULL );
assert( strcmp(board744565757, 
"2.1...1.33..4.\n"
"..133...12.3..\n"
"....3.134.3.1.\n"
"3.22111....31.\n"
".3.3324121..3.\n"
"..132..2.442..\n"
"3.42...24.3432\n"
".4342....34342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13..1..32...\n"
"311.33423434.4\n"
"2.1.4.2..133.4\n"
"...424..24..23\n"
"2.421...21.123\n"
"2.334.21..1421\n"
"...3.3.212.2..\n") == 0);
free(board744565757);
board744565757 = NULL;
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 40 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 3, 11, 13) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 3, 16, 11) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_golden_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 11, 3) == 1 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 13, 8) == 0 );


char* board642428826 = gamma_board(board);
assert( board642428826 != NULL );
assert( strcmp(board642428826, 
"2.1...1.33..4.\n"
"..133...12.3..\n"
"....3.134.3.1.\n"
"3.22111....31.\n"
".3.3324121..3.\n"
"..132.22.442..\n"
"3.42...24.3432\n"
".4342....44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21..32...\n"
"311.33423434.4\n"
"2.124.2..133.4\n"
"...424..24.123\n"
"2.421...21.123\n"
"2.334.21..1421\n"
"...3.3.212.2..\n") == 0);
free(board642428826);
board642428826 = NULL;
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 1, 12, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 3, 11, 15) == 0 );
assert( gamma_move(board, 4, 9, 13) == 1 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 31 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_free_fields(board, 1) == 90 );
assert( gamma_move(board, 2, 16, 11) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_free_fields(board, 2) == 90 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_move(board, 3, 6, 15) == 1 );


char* board646756591 = gamma_board(board);
assert( board646756591 != NULL );
assert( strcmp(board646756591, 
"2.1...1.33..4.\n"
"..133.3.12.3..\n"
"....3.134.3.1.\n"
"3.22111..4.31.\n"
".3.3324121..3.\n"
"..132.22.442..\n"
"3.42...24.3432\n"
".4342....44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21..32...\n"
"311.33423434.4\n"
"2.12412..133.4\n"
"...424..24.123\n"
"2.421...21.123\n"
"2.334.21..1421\n"
"...3.3.212.21.\n") == 0);
free(board646756591);
board646756591 = NULL;
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );


char* board391304563 = gamma_board(board);
assert( board391304563 != NULL );
assert( strcmp(board391304563, 
"2.1...1.33..4.\n"
"..133.3.12.3..\n"
"....3.134.3.1.\n"
"3.22111..4.31.\n"
".3.3324121..3.\n"
"..132.22.442..\n"
"3.42...24.3432\n"
".4342....44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21..32...\n"
"311.33423434.4\n"
"2.12412..133.4\n"
"...424..24.123\n"
"2.421...21.123\n"
"2.334.21..1421\n"
"...3.3.212.21.\n") == 0);
free(board391304563);
board391304563 = NULL;
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_move(board, 4, 5, 14) == 1 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 16, 7) == 0 );
assert( gamma_move(board, 1, 16, 13) == 0 );
assert( gamma_golden_move(board, 1, 8, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 12, 15) == 1 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 2, 0) == 1 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_free_fields(board, 1) == 86 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 7, 16) == 1 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_golden_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_move(board, 4, 10, 12) == 1 );
assert( gamma_free_fields(board, 4) == 83 );


char* board882675052 = gamma_board(board);
assert( board882675052 != NULL );
assert( strcmp(board882675052, 
"2.1...1133..4.\n"
"..133.3.12.33.\n"
"....34134.3.1.\n"
"3.22111..4.31.\n"
".3.33241214.3.\n"
"..132.22.442..\n"
"3.42...24.3432\n"
".4342....44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21..32...\n"
"311.33423434.4\n"
"2.12412..133.4\n"
"...424..24.123\n"
"2.421...21.123\n"
"2.334.212.1421\n"
"..23.3.212.21.\n") == 0);
free(board882675052);
board882675052 = NULL;
assert( gamma_move(board, 1, 16, 11) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 5, 16) == 1 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_free_fields(board, 2) == 81 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 42 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_golden_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 1, 12, 12) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 4, 11, 16) == 1 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 43 );


char* board870132197 = gamma_board(board);
assert( board870132197 != NULL );
assert( strcmp(board870132197, 
"2.1..21133.44.\n"
"..133.3.12.33.\n"
"....34134.3.1.\n"
"3.22111..4.31.\n"
".3.33241214.3.\n"
"..132.22.442..\n"
"3.42...24.3432\n"
".4342....44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21..32...\n"
"311.33423434.4\n"
"2.12412..133.4\n"
"..3424..24.123\n"
"2.421...21.123\n"
"2.334.212.1421\n"
"4.23.34212.21.\n") == 0);
free(board870132197);
board870132197 = NULL;
assert( gamma_move(board, 4, 10, 16) == 1 );
assert( gamma_move(board, 1, 12, 16) == 0 );
assert( gamma_free_fields(board, 1) == 77 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_free_fields(board, 2) == 77 );
assert( gamma_move(board, 3, 11, 13) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_golden_move(board, 1, 11, 4) == 1 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 3, 10, 0) == 1 );
assert( gamma_move(board, 4, 11, 12) == 1 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 15, 13) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 4, 5, 15) == 1 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 15, 13) == 0 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_free_fields(board, 4) == 74 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_free_fields(board, 1) == 74 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 3, 16) == 1 );
assert( gamma_golden_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 44 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_move(board, 4, 13, 16) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 4, 0) == 1 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_free_fields(board, 2) == 69 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_free_fields(board, 4) == 68 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_move(board, 1, 6, 15) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );


char* board365304288 = gamma_board(board);
assert( board365304288 != NULL );
assert( strcmp(board365304288, 
"2.14.211334444\n"
"..13343.12.33.\n"
"....34134.3.1.\n"
"3.22111..4.311\n"
".3.3324121443.\n"
"..132.22.442..\n"
"3.42...24.3432\n"
".4342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21..32...\n"
"311.33423434.4\n"
"2112412..131.4\n"
"..3424..24.123\n"
"2.421.4.21.123\n"
"2.334.212.1421\n"
"4.23134212321.\n") == 0);
free(board365304288);
board365304288 = NULL;
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_golden_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_free_fields(board, 1) == 67 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_free_fields(board, 4) == 66 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 42 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_golden_move(board, 2, 9, 12) == 1 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_move(board, 4, 6, 10) == 1 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 2, 13, 12) == 1 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_free_fields(board, 4) == 62 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 12, 12) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_golden_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_free_fields(board, 1) == 62 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_free_fields(board, 3) == 62 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 9, 1) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 47 );


char* board119414911 = gamma_board(board);
assert( board119414911 != NULL );
assert( strcmp(board119414911, 
"2.14.211334444\n"
"..13343.12.33.\n"
"...234134.3.1.\n"
"3.22111..4.311\n"
".3.33241224432\n"
"..132.22.442..\n"
"3142..424.3432\n"
".4342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21..32.3.\n"
"311.33423434.4\n"
"2112412..131.4\n"
"..3424..24.123\n"
"2.421.4.21.123\n"
"2.334.21211421\n"
"4.23134212321.\n") == 0);
free(board119414911);
board119414911 = NULL;
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_free_fields(board, 4) == 61 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_free_fields(board, 2) == 61 );


char* board521289379 = gamma_board(board);
assert( board521289379 != NULL );
assert( strcmp(board521289379, 
"2.14.211334444\n"
"..13343.12.33.\n"
"...234134.3.1.\n"
"3.22111..4.311\n"
".3.33241224432\n"
"..132.22.442..\n"
"3142..424.3432\n"
".4342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21..32.3.\n"
"311.33423434.4\n"
"2112412..131.4\n"
"..3424..24.123\n"
"2.421.4.21.123\n"
"2.334.21211421\n"
"4.23134212321.\n") == 0);
free(board521289379);
board521289379 = NULL;
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 43 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_free_fields(board, 1) == 61 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 4, 11, 15) == 0 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_move(board, 2, 1, 16) == 1 );


char* board339489258 = gamma_board(board);
assert( board339489258 != NULL );
assert( strcmp(board339489258, 
"2214.211334444\n"
"..13343.12.33.\n"
"...234134.3.1.\n"
"3.22111..4.311\n"
".3.33241224432\n"
"..132.22.4422.\n"
"3142..424.3432\n"
".4342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.3.\n"
"311.33423434.4\n"
"2112412..131.4\n"
"..3424..24.123\n"
"2.421.4.21.123\n"
"2.334.21211421\n"
"4.23134212321.\n") == 0);
free(board339489258);
board339489258 = NULL;
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_free_fields(board, 4) == 58 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 2, 13, 6) == 1 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 9, 10) == 1 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 13, 15) == 1 );
assert( gamma_busy_fields(board, 2) == 51 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 4, 0, 0) == 0 );


char* board418699205 = gamma_board(board);
assert( board418699205 != NULL );
assert( strcmp(board418699205, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..4.311\n"
".3.33241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
".4342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311.33423434.4\n"
"2112412..131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"2.334.21211421\n"
"4.23134212321.\n") == 0);
free(board418699205);
board418699205 = NULL;
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 46 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_free_fields(board, 4) == 52 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 8, 16) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 12, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 51 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 14, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 51 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board693980031 = gamma_board(board);
assert( board693980031 != NULL );
assert( strcmp(board693980031, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..4.311\n"
".3.33241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
".4342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311.33423434.4\n"
"2112412..131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"2.334.21211421\n"
"4.23134212321.\n") == 0);
free(board693980031);
board693980031 = NULL;
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 44 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_free_fields(board, 1) == 52 );
assert( gamma_golden_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 4, 1, 1) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_golden_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 46 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );


char* board232922164 = gamma_board(board);
assert( board232922164 != NULL );
assert( strcmp(board232922164, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..4.311\n"
".3.33241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
"24342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311.33423434.4\n"
"21124121.131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"23334.21211421\n"
"4.23134212321.\n") == 0);
free(board232922164);
board232922164 = NULL;
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );


char* board802878176 = gamma_board(board);
assert( board802878176 != NULL );
assert( strcmp(board802878176, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..4.311\n"
".3.33241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
"24342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311.33423434.4\n"
"21124121.131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"23334.21211421\n"
"4.23134212321.\n") == 0);
free(board802878176);
board802878176 = NULL;
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 52 );


char* board889974384 = gamma_board(board);
assert( board889974384 != NULL );
assert( strcmp(board889974384, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..4.311\n"
".3.33241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
"24342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311.33423434.4\n"
"21124121.131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"23334.21211421\n"
"4.23134212321.\n") == 0);
free(board889974384);
board889974384 = NULL;
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_golden_move(board, 4, 15, 12) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_free_fields(board, 2) == 47 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );


char* board845175155 = gamma_board(board);
assert( board845175155 != NULL );
assert( strcmp(board845175155, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..43311\n"
".3.33241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
"24342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311333423434.4\n"
"21124121.131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"23334.21211421\n"
"4323134212321.\n") == 0);
free(board845175155);
board845175155 = NULL;
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_free_fields(board, 3) == 46 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_free_fields(board, 4) == 46 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 1, 13, 0) == 1 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 2, 16) == 0 );


char* board107395435 = gamma_board(board);
assert( board107395435 != NULL );
assert( strcmp(board107395435, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..43311\n"
".3.33241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
"24342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311333423434.4\n"
"21124121.131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"23334.21211421\n"
"43231342123211\n") == 0);
free(board107395435);
board107395435 = NULL;
assert( gamma_move(board, 4, 2, 12) == 1 );


char* board690428271 = gamma_board(board);
assert( board690428271 != NULL );
assert( strcmp(board690428271, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..43311\n"
".3433241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
"24342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311333423434.4\n"
"21124121.131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"23334.21211421\n"
"43231342123211\n") == 0);
free(board690428271);
board690428271 = NULL;
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_free_fields(board, 1) == 44 );


char* board448124392 = gamma_board(board);
assert( board448124392 != NULL );
assert( strcmp(board448124392, 
"2214.211334444\n"
"..13343.12.332\n"
"...234134.331.\n"
"3.22111..43311\n"
".3433241224432\n"
"..132122.4422.\n"
"3142..42413432\n"
"24342..3.44342\n"
".34.3211211213\n"
".2434221.42143\n"
"..13.21.132.32\n"
"311333423434.4\n"
"21124121.131.4\n"
"..3424..24.123\n"
"2.421.4.214123\n"
"23334.21211421\n"
"43231342123211\n") == 0);
free(board448124392);
board448124392 = NULL;
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_move(board, 4, 0, 15) == 1 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 3, 0, 16) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_free_fields(board, 4) == 42 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_free_fields(board, 2) == 42 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_free_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 4, 11, 6) == 1 );
assert( gamma_free_fields(board, 4) == 41 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 4, 9, 16) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_move(board, 1, 6, 15) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 11, 4) == 0 );


gamma_delete(board);

    return 0;
}
