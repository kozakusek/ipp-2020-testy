#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 144388745
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(6, 12, 9, 6);
assert( board != NULL );


assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 4, 0, 1) == 1 );
assert( gamma_move(board, 5, 5, 8) == 1 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_move(board, 7, 1, 10) == 1 );
assert( gamma_move(board, 7, 4, 10) == 1 );
assert( gamma_move(board, 8, 7, 0) == 0 );
assert( gamma_move(board, 8, 2, 0) == 1 );
assert( gamma_golden_move(board, 8, 11, 5) == 0 );
assert( gamma_move(board, 9, 4, 5) == 1 );


char* board308754851 = gamma_board(board);
assert( board308754851 != NULL );
assert( strcmp(board308754851, 
".....1\n"
".7..7.\n"
"......\n"
".....5\n"
"......\n"
"2.....\n"
"....9.\n"
"......\n"
"......\n"
".3....\n"
"4.....\n"
"..8..1\n") == 0);
free(board308754851);
board308754851 = NULL;
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 1, 5) == 1 );
assert( gamma_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_move(board, 4, 3, 7) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 5, 1, 9) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_free_fields(board, 5) == 56 );
assert( gamma_move(board, 6, 5, 3) == 1 );
assert( gamma_move(board, 6, 4, 8) == 1 );
assert( gamma_move(board, 7, 0, 1) == 0 );
assert( gamma_move(board, 7, 3, 5) == 1 );
assert( gamma_move(board, 8, 11, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 1 );
assert( gamma_free_fields(board, 8) == 53 );


char* board629848889 = gamma_board(board);
assert( board629848889 != NULL );
assert( strcmp(board629848889, 
".....1\n"
".7..73\n"
".5....\n"
"....65\n"
"...4..\n"
"2.....\n"
".3.791\n"
"......\n"
"....46\n"
".3....\n"
"4.....\n"
"..8..1\n") == 0);
free(board629848889);
board629848889 = NULL;
assert( gamma_move(board, 9, 5, 11) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 3 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 5, 2, 10) == 1 );
assert( gamma_move(board, 6, 5, 9) == 1 );
assert( gamma_move(board, 6, 2, 2) == 1 );


char* board709444026 = gamma_board(board);
assert( board709444026 != NULL );
assert( strcmp(board709444026, 
".....1\n"
".75.73\n"
".5...6\n"
"....65\n"
"...4..\n"
"2.....\n"
".3.791\n"
"......\n"
"....46\n"
".36..4\n"
"4.....\n"
"..8..1\n") == 0);
free(board709444026);
board709444026 = NULL;
assert( gamma_move(board, 8, 5, 1) == 1 );
assert( gamma_move(board, 9, 8, 1) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_free_fields(board, 3) == 46 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 5, 2, 3) == 1 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_free_fields(board, 5) == 44 );
assert( gamma_busy_fields(board, 6) == 4 );
assert( gamma_free_fields(board, 6) == 44 );
assert( gamma_move(board, 7, 3, 11) == 1 );
assert( gamma_move(board, 8, 10, 3) == 0 );
assert( gamma_move(board, 8, 0, 3) == 1 );
assert( gamma_free_fields(board, 8) == 42 );
assert( gamma_move(board, 9, 6, 2) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_free_fields(board, 1) == 42 );


char* board214732059 = gamma_board(board);
assert( board214732059 != NULL );
assert( strcmp(board214732059, 
"3..7.1\n"
".75.73\n"
".5...6\n"
".2..65\n"
"...4..\n"
"2.....\n"
".3.791\n"
"......\n"
"8.5446\n"
".36..4\n"
"4....8\n"
"..8..1\n") == 0);
free(board214732059);
board214732059 = NULL;
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 3, 1) == 1 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 6, 0, 10) == 1 );
assert( gamma_move(board, 7, 9, 0) == 0 );
assert( gamma_move(board, 7, 3, 11) == 0 );
assert( gamma_move(board, 8, 2, 4) == 1 );
assert( gamma_move(board, 9, 3, 2) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_golden_move(board, 9, 4, 4) == 1 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_move(board, 8, 6, 3) == 0 );
assert( gamma_move(board, 8, 0, 5) == 1 );
assert( gamma_move(board, 9, 1, 6) == 1 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_free_fields(board, 3) == 31 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 4, 5, 11) == 0 );


char* board816512408 = gamma_board(board);
assert( board816512408 != NULL );
assert( strcmp(board816512408, 
"3..7.1\n"
"675173\n"
".5...6\n"
"32..65\n"
"...41.\n"
"29....\n"
"83.791\n"
"4.8.9.\n"
"8.5446\n"
".369.4\n"
"4..5.8\n"
"..8..1\n") == 0);
free(board816512408);
board816512408 = NULL;
assert( gamma_move(board, 5, 8, 2) == 0 );
assert( gamma_move(board, 6, 3, 0) == 1 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_free_fields(board, 6) == 6 );
assert( gamma_move(board, 7, 1, 1) == 1 );
assert( gamma_free_fields(board, 7) == 29 );


char* board561437432 = gamma_board(board);
assert( board561437432 != NULL );
assert( strcmp(board561437432, 
"3..7.1\n"
"675173\n"
".5...6\n"
"32..65\n"
"...41.\n"
"29....\n"
"83.791\n"
"4.8.9.\n"
"8.5446\n"
".369.4\n"
"47.5.8\n"
"..86.1\n") == 0);
free(board561437432);
board561437432 = NULL;
assert( gamma_busy_fields(board, 8) == 5 );
assert( gamma_move(board, 9, 2, 0) == 0 );
assert( gamma_move(board, 9, 4, 1) == 1 );
assert( gamma_free_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_golden_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 6, 11, 2) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 2) == 1 );
assert( gamma_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 8, 3, 1) == 0 );
assert( gamma_move(board, 9, 6, 5) == 0 );
assert( gamma_busy_fields(board, 9) == 5 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_free_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_golden_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_free_fields(board, 7) == 8 );
assert( gamma_move(board, 8, 5, 2) == 0 );
assert( gamma_move(board, 8, 4, 4) == 0 );
assert( gamma_move(board, 9, 11, 4) == 0 );
assert( gamma_move(board, 9, 1, 9) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_free_fields(board, 3) == 6 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_busy_fields(board, 8) == 5 );
assert( gamma_move(board, 9, 1, 3) == 1 );
assert( gamma_busy_fields(board, 9) == 6 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 6, 5, 5) == 0 );
assert( gamma_move(board, 7, 11, 1) == 0 );
assert( gamma_move(board, 7, 5, 5) == 0 );
assert( gamma_move(board, 9, 7, 0) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_free_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_move(board, 5, 2, 11) == 1 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_golden_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 5, 11) == 0 );
assert( gamma_move(board, 9, 1, 4) == 1 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_free_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 5, 6) == 1 );
assert( gamma_move(board, 5, 7, 0) == 0 );


char* board735559745 = gamma_board(board);
assert( board735559745 != NULL );
assert( strcmp(board735559745, 
"3.57.1\n"
"675173\n"
".5...6\n"
"32..65\n"
".1.41.\n"
"292..4\n"
"83.792\n"
"498.9.\n"
"895446\n"
"7369.4\n"
"473598\n"
"..86.1\n") == 0);
free(board735559745);
board735559745 = NULL;
assert( gamma_move(board, 6, 6, 4) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 6 );
assert( gamma_move(board, 7, 9, 0) == 0 );
assert( gamma_move(board, 8, 9, 4) == 0 );
assert( gamma_move(board, 8, 0, 6) == 0 );


char* board591114573 = gamma_board(board);
assert( board591114573 != NULL );
assert( strcmp(board591114573, 
"3.57.1\n"
"675173\n"
".5...6\n"
"32..65\n"
".1.41.\n"
"292..4\n"
"83.792\n"
"498.9.\n"
"895446\n"
"7369.4\n"
"473598\n"
"..86.1\n") == 0);
free(board591114573);
board591114573 = NULL;
assert( gamma_move(board, 9, 9, 4) == 0 );
assert( gamma_move(board, 9, 2, 5) == 1 );
assert( gamma_free_fields(board, 9) == 5 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 6 );
assert( gamma_move(board, 7, 7, 5) == 0 );
assert( gamma_move(board, 7, 4, 7) == 0 );
assert( gamma_move(board, 8, 6, 3) == 0 );
assert( gamma_move(board, 8, 3, 4) == 0 );
assert( gamma_move(board, 9, 0, 0) == 0 );
assert( gamma_move(board, 9, 3, 10) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 1, 2, 8) == 1 );
assert( gamma_golden_move(board, 1, 9, 0) == 0 );


char* board882088501 = gamma_board(board);
assert( board882088501 != NULL );
assert( strcmp(board882088501, 
"3.57.1\n"
"675173\n"
".5...6\n"
"321.65\n"
".1.41.\n"
"292..4\n"
"839792\n"
"49849.\n"
"895446\n"
"7369.4\n"
"473598\n"
"..86.1\n") == 0);
free(board882088501);
board882088501 = NULL;
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_golden_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 6, 11, 4) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_golden_move(board, 6, 0, 0) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_move(board, 8, 9, 2) == 0 );
assert( gamma_move(board, 8, 5, 6) == 0 );
assert( gamma_free_fields(board, 8) == 15 );
assert( gamma_move(board, 9, 7, 0) == 0 );
assert( gamma_move(board, 9, 0, 9) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 2, 1, 0) == 1 );


char* board421016521 = gamma_board(board);
assert( board421016521 != NULL );
assert( strcmp(board421016521, 
"3.57.1\n"
"675173\n"
".5...6\n"
"321.65\n"
".1.41.\n"
"292..4\n"
"839792\n"
"49849.\n"
"895446\n"
"736924\n"
"473598\n"
"5286.1\n") == 0);
free(board421016521);
board421016521 = NULL;
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 5, 9, 4) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 6 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_move(board, 8, 9, 2) == 0 );
assert( gamma_free_fields(board, 8) == 14 );
assert( gamma_move(board, 9, 0, 4) == 0 );
assert( gamma_move(board, 9, 3, 4) == 0 );


gamma_delete(board);

    return 0;
}
