#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 117226483
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 15, 6, 45);
assert( board != NULL );


assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 2, 17, 9) == 1 );


char* board816225834 = gamma_board(board);
assert( board816225834 != NULL );
assert( strcmp(board816225834, 
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
".................2\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"........1.........\n"
"..................\n"
"..................\n"
"..................\n") == 0);
free(board816225834);
board816225834 = NULL;
assert( gamma_move(board, 3, 10, 12) == 1 );
assert( gamma_golden_move(board, 3, 9, 17) == 0 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_move(board, 4, 13, 14) == 1 );
assert( gamma_move(board, 5, 11, 5) == 1 );
assert( gamma_move(board, 5, 15, 1) == 1 );
assert( gamma_move(board, 6, 9, 12) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_busy_fields(board, 4) == 3 );
assert( gamma_move(board, 5, 1, 10) == 0 );
assert( gamma_move(board, 5, 4, 6) == 1 );
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_move(board, 6, 2, 5) == 1 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_move(board, 4, 9, 11) == 1 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 5, 0, 11) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 6, 9, 13) == 1 );
assert( gamma_move(board, 6, 11, 11) == 1 );
assert( gamma_golden_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_move(board, 1, 14, 10) == 1 );
assert( gamma_free_fields(board, 1) == 246 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_move(board, 3, 13, 10) == 1 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 5, 0, 3) == 1 );
assert( gamma_move(board, 6, 2, 1) == 1 );
assert( gamma_move(board, 1, 14, 1) == 1 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 2, 2, 14) == 1 );
assert( gamma_free_fields(board, 2) == 238 );
assert( gamma_golden_move(board, 2, 12, 9) == 0 );
assert( gamma_free_fields(board, 3) == 238 );
assert( gamma_move(board, 4, 17, 1) == 1 );
assert( gamma_move(board, 4, 12, 2) == 1 );
assert( gamma_move(board, 5, 10, 7) == 1 );
assert( gamma_free_fields(board, 5) == 235 );
assert( gamma_move(board, 6, 3, 4) == 1 );
assert( gamma_golden_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 1, 12, 0) == 1 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_golden_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 4, 15, 3) == 1 );
assert( gamma_move(board, 5, 8, 1) == 1 );
assert( gamma_move(board, 6, 2, 9) == 0 );
assert( gamma_move(board, 6, 16, 13) == 1 );


char* board187742331 = gamma_board(board);
assert( board187742331 != NULL );
assert( strcmp(board187742331, 
"..2..........4....\n"
"........36......6.\n"
".........63.......\n"
"5........4.6......\n"
".4.........4.31...\n"
"..2..............2\n"
"..................\n"
"..3.......5.......\n"
"....5.............\n"
"..6...1....5......\n"
"...6.....1........\n"
"5.......1.2....4..\n"
"......2.....4.....\n"
".2611.6.5..1..15.4\n"
"..4.....2...1.....\n") == 0);
free(board187742331);
board187742331 = NULL;
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_free_fields(board, 1) == 226 );
assert( gamma_move(board, 2, 8, 17) == 0 );
assert( gamma_move(board, 3, 8, 12) == 1 );
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 13, 15) == 0 );
assert( gamma_move(board, 5, 17, 12) == 1 );
assert( gamma_free_fields(board, 5) == 222 );
assert( gamma_move(board, 6, 8, 12) == 0 );
assert( gamma_busy_fields(board, 6) == 8 );
assert( gamma_move(board, 1, 4, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_free_fields(board, 2) == 221 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 13, 1) == 1 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_golden_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 1, 17, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 4, 10) == 1 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_move(board, 3, 14, 4) == 1 );
assert( gamma_move(board, 5, 16, 2) == 1 );
assert( gamma_free_fields(board, 5) == 213 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 1, 6, 7) == 1 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 5, 13) == 1 );
assert( gamma_busy_fields(board, 4) == 11 );


char* board467978171 = gamma_board(board);
assert( board467978171 != NULL );
assert( strcmp(board467978171, 
"..2..........4....\n"
".....4..36......6.\n"
"....1...363......5\n"
"5....3...4.6......\n"
".4..2......4.31...\n"
"..2..............2\n"
"..................\n"
"..3...1...5.......\n"
"....5.............\n"
"..6...11.3.5......\n"
"...6.2...1....3...\n"
"5.4....11.2....4..\n"
"......2.....4...51\n"
".2611.6.5..1.515.4\n"
"4.4.....2...1.....\n") == 0);
free(board467978171);
board467978171 = NULL;
assert( gamma_move(board, 5, 6, 0) == 1 );
assert( gamma_move(board, 5, 9, 8) == 1 );
assert( gamma_move(board, 6, 14, 5) == 1 );
assert( gamma_move(board, 1, 7, 13) == 1 );
assert( gamma_move(board, 1, 11, 14) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 16, 5) == 1 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 3, 16, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 5, 14, 3) == 1 );
assert( gamma_move(board, 6, 9, 10) == 1 );
assert( gamma_free_fields(board, 6) == 200 );
assert( gamma_move(board, 1, 6, 12) == 1 );
assert( gamma_move(board, 1, 4, 5) == 1 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_free_fields(board, 1) == 198 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 5, 8, 14) == 1 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 4, 4, 13) == 1 );
assert( gamma_move(board, 5, 4, 15) == 0 );
assert( gamma_move(board, 6, 8, 10) == 1 );
assert( gamma_move(board, 6, 3, 7) == 1 );
assert( gamma_free_fields(board, 6) == 189 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 5) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );


char* board618315011 = gamma_board(board);
assert( board618315011 != NULL );
assert( strcmp(board618315011, 
"..2.....5..1.4....\n"
"....44.136......6.\n"
".3..1.1.363......5\n"
"5....3...4.6......\n"
".4..2...66.4.31...\n"
"..2.....2........2\n"
".........5........\n"
"..36..1...5.....3.\n"
"....5...4.........\n"
"..6.1.11.3.52.6.2.\n"
"3..632...1....3...\n"
"5.4....11.2...54..\n"
"....2.2.....4...51\n"
".2611.6.5..1.515.4\n"
"4.4...5.2...1.....\n") == 0);
free(board618315011);
board618315011 = NULL;
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_move(board, 3, 4, 11) == 1 );
assert( gamma_move(board, 4, 7, 0) == 1 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_move(board, 6, 6, 13) == 1 );
assert( gamma_move(board, 6, 11, 0) == 1 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_move(board, 5, 7, 12) == 1 );
assert( gamma_move(board, 6, 5, 8) == 1 );
assert( gamma_move(board, 6, 12, 0) == 0 );


char* board837422571 = gamma_board(board);
assert( board837422571 != NULL );
assert( strcmp(board837422571, 
"..2.....5..1.4....\n"
"....446136...1..6.\n"
".3..1.15363......5\n"
"5...33...4.6......\n"
".4..2...66.4.31...\n"
".32.....2........2\n"
".....6...5........\n"
"..36..1...5.....3.\n"
"...25...4.........\n"
"4.631.11.3.52.6.2.\n"
"3..632...1....3...\n"
"5.4....11.2...54..\n"
"....2.2.....4...51\n"
".2611.6.5..1.515.4\n"
"4.4...542..61.....\n") == 0);
free(board837422571);
board837422571 = NULL;
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 1, 16, 6) == 1 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_golden_move(board, 3, 11, 11) == 1 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 5, 7, 9) == 1 );
assert( gamma_golden_move(board, 5, 5, 14) == 0 );
assert( gamma_move(board, 6, 6, 10) == 1 );
assert( gamma_move(board, 6, 7, 1) == 1 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_golden_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_move(board, 3, 13, 7) == 1 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 4, 5, 14) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 16, 2) == 0 );
assert( gamma_move(board, 5, 1, 14) == 1 );
assert( gamma_move(board, 6, 9, 13) == 0 );
assert( gamma_move(board, 6, 8, 4) == 1 );
assert( gamma_move(board, 1, 10, 2) == 1 );
assert( gamma_move(board, 2, 13, 3) == 1 );
assert( gamma_move(board, 2, 13, 12) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 1) == 1 );
assert( gamma_free_fields(board, 3) == 161 );
assert( gamma_move(board, 4, 15, 9) == 1 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 5, 0, 1) == 1 );
assert( gamma_move(board, 5, 11, 8) == 1 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 14, 9) == 1 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 2, 13, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_free_fields(board, 2) == 156 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_golden_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 8, 11) == 0 );
assert( gamma_move(board, 4, 7, 10) == 1 );
assert( gamma_move(board, 5, 14, 0) == 1 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 6, 4, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 0) == 1 );
assert( gamma_move(board, 3, 8, 12) == 0 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_move(board, 4, 3, 13) == 1 );
assert( gamma_free_fields(board, 4) == 149 );
assert( gamma_move(board, 5, 4, 17) == 0 );
assert( gamma_move(board, 5, 17, 7) == 1 );
assert( gamma_move(board, 6, 7, 15) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 13, 13) == 0 );
assert( gamma_golden_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 15, 6) == 1 );
assert( gamma_free_fields(board, 3) == 146 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 5, 13, 8) == 1 );


char* board690580010 = gamma_board(board);
assert( board690580010 != NULL );
assert( strcmp(board690580010, 
".52..4..5..1.4....\n"
"...4446136...1..6.\n"
".3..1.15363..2...5\n"
"5...33.124.32.....\n"
".4..22646644.31...\n"
"432....521....14.2\n"
"..2..6...5.5.5....\n"
"..36..1...5..3..35\n"
"...25...4....2.31.\n"
"4.631.11.3.52.6.2.\n"
"3..632..61....3...\n"
"5.4....11.2..254..\n"
"....2.2...1.4...51\n"
"52611.665..13515.4\n"
"4.4...542..6135...\n") == 0);
free(board690580010);
board690580010 = NULL;
assert( gamma_free_fields(board, 6) == 145 );
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 4, 16) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );


char* board346859018 = gamma_board(board);
assert( board346859018 != NULL );
assert( strcmp(board346859018, 
".52..4..5..1.4....\n"
"...4446136...1..6.\n"
".3..1.15363..2...5\n"
"5...33.124.32.....\n"
".4..22646644.31...\n"
"432....521....14.2\n"
"..2..6...5.5.5....\n"
"..36..1.2.5..3..35\n"
"...25...4....2.31.\n"
"4.631.11.3.52.6.2.\n"
"3..632..61....3...\n"
"5.4....11.2..254..\n"
"....2.2...1.4...51\n"
"52611.665..13515.4\n"
"4.4...542..6135...\n") == 0);
free(board346859018);
board346859018 = NULL;
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_move(board, 4, 12, 12) == 1 );
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 6, 16, 8) == 1 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_free_fields(board, 2) == 140 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 2, 17) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_free_fields(board, 3) == 140 );
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_move(board, 5, 12, 14) == 1 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 6, 12, 7) == 1 );
assert( gamma_busy_fields(board, 6) == 19 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 3, 14) == 1 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_move(board, 4, 13, 4) == 1 );
assert( gamma_move(board, 5, 12, 3) == 1 );
assert( gamma_move(board, 5, 15, 6) == 0 );
assert( gamma_move(board, 6, 10, 9) == 1 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_golden_move(board, 1, 9, 15) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 10, 17) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 5, 2, 8) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 1, 13, 12) == 0 );
assert( gamma_move(board, 1, 15, 7) == 1 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board501679420 = gamma_board(board);
assert( board501679420 != NULL );
assert( strcmp(board501679420, 
".521.4..5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5...33.124.32.....\n"
".4..22646644.31...\n"
"432....5216...14.2\n"
"..2..6...5.5.5..6.\n"
"..364.1.2.5.63.135\n"
"...25...4....2.31.\n"
"4.631.11.3.52.6.2.\n"
"3..632..61...43...\n"
"5.4....11.2.5254..\n"
"...22.2...1.4...51\n"
"526113665..13515.4\n"
"4.4...542..6135...\n") == 0);
free(board501679420);
board501679420 = NULL;
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 5, 11, 6) == 1 );
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 6, 13, 13) == 0 );
assert( gamma_move(board, 6, 8, 14) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 1, 12, 10) == 1 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_move(board, 6, 11, 8) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_move(board, 6, 16, 6) == 0 );
assert( gamma_golden_move(board, 6, 12, 13) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 13, 2) == 1 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 14, 7) == 1 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_free_fields(board, 3) == 121 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 6, 14) == 1 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 1, 17, 4) == 1 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_free_fields(board, 3) == 119 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 5, 10, 11) == 1 );
assert( gamma_busy_fields(board, 5) == 28 );
assert( gamma_move(board, 6, 4, 13) == 0 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 1, 17, 5) == 1 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board935781979 = gamma_board(board);
assert( board935781979 != NULL );
assert( strcmp(board935781979, 
".521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532.....\n"
".4..22646644131...\n"
"432....5216...14.2\n"
"..2..6...545.5..6.\n"
".3364.1.2.5.633135\n"
"...25...4..5.2.31.\n"
"45631.11.3.52.6.21\n"
"3..632..613..43..1\n"
"5.4....11.2.5254..\n"
"..222.2...1.42..51\n"
"526113665..13515.4\n"
"4.4.2.542..6135...\n") == 0);
free(board935781979);
board935781979 = NULL;
assert( gamma_move(board, 5, 13, 1) == 0 );
assert( gamma_move(board, 6, 10, 6) == 1 );
assert( gamma_move(board, 1, 11, 3) == 1 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 8, 1) == 0 );
assert( gamma_move(board, 5, 16, 10) == 1 );
assert( gamma_move(board, 6, 1, 16) == 0 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 10, 5) == 1 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 28 );
assert( gamma_move(board, 3, 16, 0) == 1 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_free_fields(board, 4) == 111 );
assert( gamma_move(board, 5, 14, 15) == 0 );
assert( gamma_move(board, 5, 6, 13) == 0 );


char* board424073905 = gamma_board(board);
assert( board424073905 != NULL );
assert( strcmp(board424073905, 
".521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532.....\n"
".4..22646644131.5.\n"
"432....5216...14.2\n"
"..2..6...545.5..6.\n"
".3364.1.2.5.633135\n"
"...25...4.65.2.31.\n"
"45631.11.3252.6.21\n"
"3..632..613..43..1\n"
"5.4....11.215254..\n"
"..222.2...1.42..51\n"
"526113665..13515.4\n"
"4.4.2.542..6135.3.\n") == 0);
free(board424073905);
board424073905 = NULL;
assert( gamma_move(board, 6, 3, 17) == 0 );
assert( gamma_move(board, 6, 15, 3) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 10, 0) == 1 );


char* board563669281 = gamma_board(board);
assert( board563669281 != NULL );
assert( strcmp(board563669281, 
".521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532.....\n"
".4..22646644131.5.\n"
"432....5216...14.2\n"
"..2..6...545.5..6.\n"
".3364.1.2.5.633135\n"
"...25...4.65.2.31.\n"
"45631.11.3252.6.21\n"
"3..632..613..43..1\n"
"5.4....11.215254..\n"
"..222.2...1.42..51\n"
"526113665..13515.4\n"
"4.4.2.542.16135.3.\n") == 0);
free(board563669281);
board563669281 = NULL;
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 3, 17, 7) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );


char* board728728572 = gamma_board(board);
assert( board728728572 != NULL );
assert( strcmp(board728728572, 
".521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532.....\n"
".4..22646644131.5.\n"
"432.2..5216...14.2\n"
"..2..6...545.5..6.\n"
".3364.1.2.5.633135\n"
"...25...4.65.2.31.\n"
"45631.11.3252.6.21\n"
"3..632..613..43..1\n"
"5.4....11.215254..\n"
"..222.2...1.42..51\n"
"526113665..13515.4\n"
"4.4.2.542.16135.3.\n") == 0);
free(board728728572);
board728728572 = NULL;
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 5, 16, 7) == 0 );
assert( gamma_golden_move(board, 5, 13, 7) == 1 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 15, 11) == 1 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_golden_move(board, 3, 0, 8) == 0 );


char* board940652392 = gamma_board(board);
assert( board940652392 != NULL );
assert( strcmp(board940652392, 
".521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532..1..\n"
".4..22646644131.5.\n"
"432.2..5216...14.2\n"
"..2..6...545.5..6.\n"
".3364.1.2.5.653135\n"
"...25...4.65.2.31.\n"
"45631.11.3252.6.21\n"
"33.632..613..43..1\n"
"5.4....11.215254..\n"
"..222.2...1.42..51\n"
"526113665..13515.4\n"
"4.4.2.542.16135.3.\n") == 0);
free(board940652392);
board940652392 = NULL;
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 5, 8, 17) == 0 );
assert( gamma_move(board, 6, 8, 17) == 0 );
assert( gamma_free_fields(board, 6) == 107 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 30 );


char* board786025262 = gamma_board(board);
assert( board786025262 != NULL );
assert( strcmp(board786025262, 
".521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532..1..\n"
".4..22646644131.5.\n"
"432.2..5216...14.2\n"
"..2..62..545.5..6.\n"
".3364.1.2.5.653135\n"
"...25...4.65.2.31.\n"
"45631.11.3252.6.21\n"
"33.632..613..43..1\n"
"5.4....11.215254..\n"
"..222.2...1.42..51\n"
"526113665..13515.4\n"
"4.4.2.542.16135.3.\n") == 0);
free(board786025262);
board786025262 = NULL;
assert( gamma_move(board, 3, 17, 7) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );


char* board236537108 = gamma_board(board);
assert( board236537108 != NULL );
assert( strcmp(board236537108, 
".521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532..1..\n"
".4..22646644131.5.\n"
"432.2..5216...14.2\n"
"..2..62..545.5..6.\n"
".3364.1.2.5.653135\n"
"...25...4.65.2.31.\n"
"45631.11.3252.6.21\n"
"33.632..613..43..1\n"
"5.4....11.215254..\n"
"..222.2...1.42..51\n"
"526113665..13515.4\n"
"4.4.2.542.16135.3.\n") == 0);
free(board236537108);
board236537108 = NULL;
assert( gamma_move(board, 5, 10, 17) == 0 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_free_fields(board, 4) == 105 );
assert( gamma_move(board, 5, 13, 8) == 0 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_move(board, 1, 10, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 3) == 1 );
assert( gamma_move(board, 5, 2, 8) == 0 );
assert( gamma_move(board, 6, 3, 3) == 0 );
assert( gamma_move(board, 6, 3, 0) == 1 );
assert( gamma_busy_fields(board, 6) == 22 );
assert( gamma_move(board, 1, 14, 16) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_golden_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 11, 16) == 0 );
assert( gamma_free_fields(board, 2) == 102 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 4, 17, 8) == 1 );
assert( gamma_move(board, 5, 5, 15) == 0 );
assert( gamma_move(board, 5, 0, 14) == 1 );
assert( gamma_move(board, 6, 12, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_free_fields(board, 1) == 99 );


char* board304549436 = gamma_board(board);
assert( board304549436 != NULL );
assert( strcmp(board304549436, 
"5521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532..1..\n"
".4..22646644131.5.\n"
"432.2..5216...14.2\n"
"..2..62..545.5..64\n"
".3364.1.2.5.653135\n"
"...25...4.65.2.31.\n"
"45631.11.3252.6.21\n"
"33.632..613..43..1\n"
"5.43...114215254..\n"
"..222.2..31.42..51\n"
"526113665.113515.4\n"
"4.462.542.16135.3.\n") == 0);
free(board304549436);
board304549436 = NULL;
assert( gamma_move(board, 2, 6, 6) == 1 );


char* board994485079 = gamma_board(board);
assert( board994485079 != NULL );
assert( strcmp(board994485079, 
"5521.45.5..154....\n"
"...44461363..1..6.\n"
".3..1.15363.42...5\n"
"5.2.33.124532..1..\n"
".4..22646644131.5.\n"
"432.2..5216...14.2\n"
"..2..62..545.5..64\n"
".3364.1.2.5.653135\n"
"...25.2.4.65.2.31.\n"
"45631.11.3252.6.21\n"
"33.632..613..43..1\n"
"5.43...114215254..\n"
"..222.2..31.42..51\n"
"526113665.113515.4\n"
"4.462.542.16135.3.\n") == 0);
free(board994485079);
board994485079 = NULL;
assert( gamma_move(board, 3, 15, 2) == 1 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 5, 14, 16) == 0 );
assert( gamma_free_fields(board, 5) == 97 );
assert( gamma_move(board, 6, 17, 2) == 0 );
assert( gamma_free_fields(board, 6) == 97 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 5, 14, 11) == 1 );
assert( gamma_move(board, 5, 11, 8) == 0 );
assert( gamma_free_fields(board, 5) == 93 );
assert( gamma_move(board, 6, 11, 13) == 1 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_free_fields(board, 2) == 91 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );


char* board238636547 = gamma_board(board);
assert( board238636547 != NULL );
assert( strcmp(board238636547, 
"5521.45.5..154....\n"
"...444613636.1..6.\n"
".3..1.15363342...5\n"
"5.2.33.124532.51..\n"
".4..22646644131.5.\n"
"43222..5216...14.2\n"
"..2..62..545.5..64\n"
".3364.1.2.53653135\n"
"...25.2.4.65.2.31.\n"
"45631.11.3252.6.21\n"
"33.632..613..43..1\n"
"5.43...114215254..\n"
"..222.24231.42.351\n"
"526113665.113515.4\n"
"4.462.542.16135.3.\n") == 0);
free(board238636547);
board238636547 = NULL;
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 5, 15, 6) == 0 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 5, 4, 15) == 0 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_move(board, 6, 2, 12) == 1 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 15) == 0 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 4, 13, 9) == 1 );
assert( gamma_golden_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 6, 14, 16) == 0 );
assert( gamma_busy_fields(board, 6) == 24 );
assert( gamma_move(board, 1, 11, 17) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );


char* board268669490 = gamma_board(board);
assert( board268669490 != NULL );
assert( strcmp(board268669490, 
"5521.45.5..154....\n"
"...444613636.1..6.\n"
".36.1.15363342...5\n"
"5.2.33.124532.51..\n"
".4..22646644131.5.\n"
"43222..5216..414.2\n"
"..2..62.2545.5..64\n"
".3364.1.2.53653135\n"
"...25.2.4.6532.31.\n"
"45631.11.3252.6.21\n"
"33.632..613..43..1\n"
"5.43...114215254..\n"
"..222.24231.42.351\n"
"526113665.113515.4\n"
"45462.542.16135.3.\n") == 0);
free(board268669490);
board268669490 = NULL;
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 16, 9) == 1 );
assert( gamma_free_fields(board, 2) == 84 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_free_fields(board, 3) == 84 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_move(board, 6, 4, 15) == 0 );
assert( gamma_free_fields(board, 6) == 84 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 1, 15, 11) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_free_fields(board, 2) == 83 );
assert( gamma_move(board, 3, 6, 13) == 0 );


char* board552405481 = gamma_board(board);
assert( board552405481 != NULL );
assert( strcmp(board552405481, 
"5521.45.5..154....\n"
"...444613636.1..6.\n"
".36.1.15363342...5\n"
"5.2.33.124532.51..\n"
".4..22646644131.5.\n"
"43222..5216..41422\n"
"..2..62.2545.5..64\n"
".3364.1.2.53653135\n"
"...25.2.4.6532.31.\n"
"45631.11.3252.6.21\n"
"33.632..613..43..1\n"
"5.43...114215254..\n"
"..222124231.42.351\n"
"526113665.113515.4\n"
"45462.542.16135.3.\n") == 0);
free(board552405481);
board552405481 = NULL;
assert( gamma_golden_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_golden_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 6, 5, 5) == 1 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 2, 16, 1) == 1 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 5, 12, 7) == 0 );
assert( gamma_move(board, 6, 14, 12) == 1 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_golden_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 5, 7, 16) == 0 );
assert( gamma_move(board, 6, 4, 8) == 1 );
assert( gamma_free_fields(board, 6) == 79 );


char* board412130720 = gamma_board(board);
assert( board412130720 != NULL );
assert( strcmp(board412130720, 
"5521.45.5..154....\n"
"...444613636.1..6.\n"
".36.1.153633426..5\n"
"5.2.33.124532.51..\n"
".4..22646644131.5.\n"
"43222..5216..41422\n"
"..2.662.2545.5..64\n"
".3364.1.2.53653135\n"
"...25.2.4.6532.31.\n"
"45631611.3252.6.21\n"
"33.632..613..43..1\n"
"5.43...114215254..\n"
"..222124231.42.351\n"
"526113665.11351524\n"
"45462.542.16135.3.\n") == 0);
free(board412130720);
board412130720 = NULL;
assert( gamma_move(board, 1, 15, 12) == 1 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 36 );
assert( gamma_move(board, 3, 3, 17) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_free_fields(board, 3) == 78 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_move(board, 6, 8, 8) == 0 );
assert( gamma_move(board, 1, 12, 16) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 14, 15) == 0 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_free_fields(board, 5) == 78 );
assert( gamma_move(board, 6, 13, 13) == 0 );
assert( gamma_free_fields(board, 6) == 78 );
assert( gamma_move(board, 1, 12, 16) == 0 );
assert( gamma_move(board, 2, 10, 17) == 0 );
assert( gamma_move(board, 3, 3, 8) == 1 );


char* board227030450 = gamma_board(board);
assert( board227030450 != NULL );
assert( strcmp(board227030450, 
"5521.45.5..154....\n"
"...444613636.1..6.\n"
".36.1.1536334261.5\n"
"5.2.33.124532.51..\n"
".4..22646644131.5.\n"
"43222..5216..41422\n"
"..23662.2545.5..64\n"
".3364.1.2.53653135\n"
"...25.2.4.6532.31.\n"
"45631611.3252.6.21\n"
"33.632..613..43..1\n"
"5.43...114215254..\n"
"..222124231.42.351\n"
"526113665.11351524\n"
"45462.542.16135.3.\n") == 0);
free(board227030450);
board227030450 = NULL;
assert( gamma_move(board, 4, 7, 7) == 1 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 6, 3, 16) == 0 );
assert( gamma_move(board, 6, 9, 0) == 1 );
assert( gamma_move(board, 1, 4, 16) == 0 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 3, 12) == 1 );
assert( gamma_move(board, 4, 5, 15) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_free_fields(board, 5) == 72 );
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 11, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 5, 11, 6) == 0 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 6, 0, 6) == 1 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_free_fields(board, 1) == 69 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );


char* board317920252 = gamma_board(board);
assert( board317920252 != NULL );
assert( strcmp(board317920252, 
"5521.45.5..154....\n"
"...444613636.1..6.\n"
".3631.1536334261.5\n"
"5.2.33.124532.51..\n"
".4.222646644131.5.\n"
"43222.25216..41422\n"
"..23662.2545.5..64\n"
".3364.142.53653135\n"
"6..25.2.4.6532.31.\n"
"45631611.3252.6.21\n"
"33.632..613..43..1\n"
"5143...114215254..\n"
"5.222124231.42.351\n"
"526113665.11351524\n"
"45462.542616135.3.\n") == 0);
free(board317920252);
board317920252 = NULL;
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 5, 15) == 0 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 1, 4, 16) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 16, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 4, 14, 6) == 1 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 6, 14, 16) == 0 );
assert( gamma_busy_fields(board, 6) == 29 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 16, 14) == 1 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_free_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_golden_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_free_fields(board, 4) == 67 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 5, 15, 0) == 1 );
assert( gamma_move(board, 6, 4, 10) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 17) == 0 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_free_fields(board, 2) == 66 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_golden_move(board, 3, 5, 6) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 5, 13, 3) == 0 );
assert( gamma_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 6, 17, 7) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );


char* board140516830 = gamma_board(board);
assert( board140516830 != NULL );
assert( strcmp(board140516830, 
"5521.45.5..154..2.\n"
"...444613636.1..6.\n"
".3631.1536334261.5\n"
"5.2.33.124532.51..\n"
".4.222646644131.5.\n"
"43222.25216..41422\n"
"..23662.2545.5..64\n"
".3364.142.53653135\n"
"6..25.2.4.6532431.\n"
"45631611.3252.6.21\n"
"33.632..613..43..1\n"
"5143...114215254..\n"
"5.222124231.42.351\n"
"526113665.11351524\n"
"45462.54261613553.\n") == 0);
free(board140516830);
board140516830 = NULL;
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 6, 5, 14) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_free_fields(board, 5) == 66 );
assert( gamma_move(board, 6, 13, 15) == 0 );
assert( gamma_move(board, 6, 14, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 29 );
assert( gamma_move(board, 1, 13, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 4, 15, 8) == 1 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_free_fields(board, 5) == 65 );
assert( gamma_move(board, 6, 0, 17) == 0 );
assert( gamma_free_fields(board, 6) == 65 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_free_fields(board, 2) == 65 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_golden_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 6, 17, 5) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 1, 15, 4) == 1 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_free_fields(board, 3) == 64 );
assert( gamma_move(board, 4, 14, 14) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 5, 9) == 1 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 6, 12, 1) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 4, 15, 5) == 1 );
assert( gamma_move(board, 6, 11, 3) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 2, 15, 12) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_free_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 13, 17) == 0 );
assert( gamma_move(board, 6, 0, 7) == 1 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 6, 11, 2) == 1 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_free_fields(board, 6) == 59 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 12, 8) == 1 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );


char* board638257449 = gamma_board(board);
assert( board638257449 != NULL );
assert( strcmp(board638257449, 
"5521.45.5..1544.2.\n"
"...444613636.1..6.\n"
".3631.1536334261.5\n"
"5.2.33.124532.51..\n"
".4.222646644131.5.\n"
"43222525216..41422\n"
"..23662.254535.464\n"
"63364.142.53653135\n"
"6..25.2.4.6532431.\n"
"45631611.3252.6421\n"
"33.632..613..431.1\n"
"5143...114215254..\n"
"5.222124231642.351\n"
"526113665.11351524\n"
"45462.54261613553.\n") == 0);
free(board638257449);
board638257449 = NULL;
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_free_fields(board, 5) == 58 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 6, 2, 14) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 2, 11, 17) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 3, 5, 12) == 1 );
assert( gamma_golden_move(board, 3, 13, 16) == 0 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 5, 6, 17) == 0 );
assert( gamma_move(board, 6, 3, 3) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_free_fields(board, 2) == 57 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 3, 12, 9) == 1 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 34 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 6, 2, 14) == 0 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );


char* board602156373 = gamma_board(board);
assert( board602156373 != NULL );
assert( strcmp(board602156373, 
"5521.45.5..1544.2.\n"
"...444613636.1..6.\n"
".363131536334261.5\n"
"5.2.33.124532.51..\n"
".4.222646644131.5.\n"
"43222525216.341422\n"
"..23662.254535.464\n"
"63364.142.53653135\n"
"6..25.2.4.6532431.\n"
"45631611.3252.6421\n"
"33.632..613..431.1\n"
"5143...114215254..\n"
"5.222124231642.351\n"
"526113665.11351524\n"
"45462.54261613553.\n") == 0);
free(board602156373);
board602156373 = NULL;
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 16, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_golden_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_move(board, 6, 10, 0) == 0 );


char* board647042771 = gamma_board(board);
assert( board647042771 != NULL );
assert( strcmp(board647042771, 
"5521.45.5..1544.2.\n"
"...444613636.1..6.\n"
".363131536334261.5\n"
"5.2.33.124532.51..\n"
".4.222646644131.5.\n"
"43222525216.341422\n"
"..23662.254535.464\n"
"63364.142.53653135\n"
"6..25.2.4.6532431.\n"
"45631611.3252.6421\n"
"33.632..613..431.1\n"
"4143...114215254..\n"
"5.222124231642.351\n"
"526113665.11351524\n"
"45462.54261613553.\n") == 0);
free(board647042771);
board647042771 = NULL;
assert( gamma_move(board, 1, 11, 9) == 1 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_free_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 10, 15) == 0 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 6, 11, 14) == 0 );
assert( gamma_busy_fields(board, 6) == 31 );
assert( gamma_move(board, 1, 14, 17) == 0 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 5, 15, 7) == 0 );
assert( gamma_move(board, 6, 16, 7) == 0 );
assert( gamma_free_fields(board, 6) == 55 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_free_fields(board, 1) == 55 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 14) == 1 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 5, 10, 12) == 0 );
assert( gamma_free_fields(board, 5) == 54 );


char* board622560524 = gamma_board(board);
assert( board622560524 != NULL );
assert( strcmp(board622560524, 
"5521.45.52.1544.2.\n"
"...444613636.1..6.\n"
".363131536334261.5\n"
"5.2.33.124532.51..\n"
".4.222646644131.5.\n"
"432225252161341422\n"
"..23662.254535.464\n"
"63364.142.53653135\n"
"6..25.2.4.6532431.\n"
"45631611.3252.6421\n"
"33.632..613..431.1\n"
"4143...114215254..\n"
"5.222124231642.351\n"
"526113665.11351524\n"
"45462.54261613553.\n") == 0);
free(board622560524);
board622560524 = NULL;
assert( gamma_move(board, 6, 0, 12) == 1 );
assert( gamma_move(board, 6, 7, 4) == 1 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 14) == 1 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_golden_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 35 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 0, 3) == 0 );
assert( gamma_move(board, 1, 12, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 6, 0, 10) == 1 );
assert( gamma_move(board, 6, 16, 1) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 16, 12) == 1 );
assert( gamma_free_fields(board, 2) == 48 );
assert( gamma_move(board, 3, 14, 13) == 1 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 0, 13) == 1 );
assert( gamma_move(board, 6, 11, 3) == 0 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 42 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 5, 2, 13) == 1 );
assert( gamma_free_fields(board, 5) == 44 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_golden_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_free_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 3, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 35 );


char* board469281008 = gamma_board(board);
assert( board469281008 != NULL );
assert( strcmp(board469281008, 
"5521.45.52.154422.\n"
"5.5444613636.13.6.\n"
"636313153633426125\n"
"5.2.33.124532.51..\n"
"64.222646644131.5.\n"
"432225252161341422\n"
"..23662.254535.464\n"
"63364.142.53653135\n"
"6..25.2.4.6532431.\n"
"4563161133252.6421\n"
"33.632.6613..431.1\n"
"4143...114215254..\n"
"5.222124231642.351\n"
"526113665.11351524\n"
"45462154261113553.\n") == 0);
free(board469281008);
board469281008 = NULL;
assert( gamma_move(board, 5, 11, 16) == 0 );
assert( gamma_move(board, 6, 4, 6) == 0 );
assert( gamma_move(board, 1, 13, 11) == 1 );
assert( gamma_golden_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 13, 17) == 0 );
assert( gamma_free_fields(board, 4) == 42 );
assert( gamma_move(board, 5, 14, 17) == 0 );
assert( gamma_busy_fields(board, 5) == 37 );
assert( gamma_move(board, 6, 13, 17) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_free_fields(board, 4) == 41 );
assert( gamma_move(board, 5, 14, 7) == 0 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_move(board, 6, 6, 9) == 0 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_free_fields(board, 1) == 41 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 3, 11) == 1 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_move(board, 5, 13, 12) == 0 );
assert( gamma_free_fields(board, 5) == 40 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_golden_move(board, 2, 12, 9) == 1 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 11, 17) == 0 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 13, 17) == 0 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 8) == 1 );
assert( gamma_move(board, 5, 17, 0) == 1 );
assert( gamma_move(board, 6, 13, 13) == 0 );
assert( gamma_move(board, 6, 7, 14) == 1 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_golden_move(board, 1, 7, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );


char* board775063694 = gamma_board(board);
assert( board775063694 != NULL );
assert( strcmp(board775063694, 
"5521.45652.154422.\n"
"5.5444613636.13.6.\n"
"636313153633426125\n"
"5.2333.124532151..\n"
"64.222646644131.5.\n"
"432225252161241422\n"
".2236623254535.464\n"
"63364.142.53653135\n"
"6.225.2.4.6532431.\n"
"4563161133252.6421\n"
"33.632.6613..431.1\n"
"4143...114215254..\n"
"5.222124231642.351\n"
"526113665.11351524\n"
"454621542611135535\n") == 0);
free(board775063694);
board775063694 = NULL;
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_free_fields(board, 6) == 37 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 45 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 3, 17, 6) == 1 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 5, 11, 14) == 0 );
assert( gamma_move(board, 6, 16, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 35 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 5, 16, 6) == 0 );
assert( gamma_move(board, 6, 4, 0) == 0 );


gamma_delete(board);

    return 0;
}
