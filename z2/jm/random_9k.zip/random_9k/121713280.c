#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 121713280
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 15, 5, 26);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 2, 8, 13) == 1 );
assert( gamma_free_fields(board, 2) == 176 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 2 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_move(board, 5, 11, 4) == 1 );
assert( gamma_free_fields(board, 1) == 171 );
assert( gamma_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 4, 2, 6) == 1 );
assert( gamma_move(board, 1, 4, 0) == 1 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_free_fields(board, 3) == 166 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 5, 0, 1) == 1 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 2, 5, 14) == 1 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_move(board, 4, 9, 4) == 1 );
assert( gamma_move(board, 4, 3, 6) == 1 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 10, 3) == 0 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_golden_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_golden_move(board, 3, 6, 3) == 0 );


char* board991132310 = gamma_board(board);
assert( board991132310 != NULL );
assert( strcmp(board991132310, 
".....2.3....\n"
"........2...\n"
"............\n"
"...1........\n"
".4.3.2......\n"
"............\n"
"............\n"
"............\n"
"..442.......\n"
"...3..4.1...\n"
".1.....3.4.5\n"
"...3.....1..\n"
"....1.......\n"
"5....3......\n"
"5...1.......\n") == 0);
free(board991132310);
board991132310 = NULL;
assert( gamma_move(board, 4, 9, 11) == 1 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_free_fields(board, 4) == 154 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 3, 11, 5) == 1 );
assert( gamma_free_fields(board, 3) == 149 );
assert( gamma_move(board, 4, 11, 3) == 1 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );


char* board402561792 = gamma_board(board);
assert( board402561792 != NULL );
assert( strcmp(board402561792, 
".....2.3....\n"
"........2...\n"
"............\n"
"...1.....4..\n"
".4.3.22...4.\n"
".........1..\n"
".........1..\n"
"............\n"
"..442.......\n"
"...3..4.1..3\n"
".1.....3.4.5\n"
"...3.....1.4\n"
".4..1.......\n"
"55...3......\n"
"5...1.......\n") == 0);
free(board402561792);
board402561792 = NULL;
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 0) == 1 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 5, 11, 7) == 1 );
assert( gamma_move(board, 5, 5, 10) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_move(board, 4, 6, 8) == 1 );
assert( gamma_move(board, 5, 7, 1) == 1 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_move(board, 2, 6, 13) == 1 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 8, 4) == 1 );
assert( gamma_move(board, 4, 2, 14) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 9) == 1 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 4, 5, 7) == 1 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_move(board, 1, 10, 7) == 1 );
assert( gamma_move(board, 2, 1, 6) == 1 );
assert( gamma_move(board, 2, 11, 11) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 11) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_golden_move(board, 5, 10, 4) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_move(board, 1, 8, 11) == 1 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 8, 11) == 0 );
assert( gamma_move(board, 4, 11, 8) == 1 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_free_fields(board, 5) == 120 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 5, 9) == 1 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 5, 11, 1) == 1 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_free_fields(board, 1) == 117 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 0) == 1 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 5, 2, 2) == 1 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 3, 10, 2) == 1 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_golden_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 3, 0, 12) == 1 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 4, 3, 1) == 1 );
assert( gamma_move(board, 4, 11, 11) == 0 );
assert( gamma_move(board, 5, 11, 7) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 6, 1) == 1 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 11, 13) == 1 );
assert( gamma_move(board, 4, 14, 6) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 5, 8, 2) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_move(board, 5, 11, 14) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 3, 3, 11) == 0 );


char* board767917085 = gamma_board(board);
assert( board767917085 != NULL );
assert( strcmp(board767917085, 
"..4..2.3...5\n"
"......2.2..3\n"
"3...........\n"
"...1.3..1412\n"
".4.3122.2.44\n"
"35...2...133\n"
"2.....4..1.4\n"
"...1.4....15\n"
".2442.23...1\n"
".2.34.4.1..3\n"
".1..3..344.5\n"
"..23....31.4\n"
".45.1...5.3.\n"
"5524.315..45\n"
"5.2.12....4.\n") == 0);
free(board767917085);
board767917085 = NULL;
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_golden_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_free_fields(board, 1) == 99 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 0) == 1 );
assert( gamma_move(board, 3, 10, 11) == 0 );


char* board463659664 = gamma_board(board);
assert( board463659664 != NULL );
assert( strcmp(board463659664, 
"..4..2.3...5\n"
"1.....2.2..3\n"
"3...........\n"
"...1.3..1412\n"
".4.3122.2.44\n"
"35...2...133\n"
"2.....4..1.4\n"
"...1.4....15\n"
".2442.23...1\n"
".2.34.4.1..3\n"
".1..3..344.5\n"
"4.23....31.4\n"
".45.1...5.3.\n"
"5524.315..45\n"
"5.2.12....43\n") == 0);
free(board463659664);
board463659664 = NULL;
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 5, 2, 7) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 1, 6, 12) == 1 );
assert( gamma_free_fields(board, 1) == 96 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 12) == 1 );
assert( gamma_move(board, 5, 8, 1) == 1 );
assert( gamma_move(board, 5, 11, 8) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_golden_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_free_fields(board, 3) == 93 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_move(board, 5, 11, 6) == 0 );
assert( gamma_move(board, 5, 2, 13) == 1 );
assert( gamma_move(board, 2, 11, 2) == 1 );
assert( gamma_move(board, 2, 4, 11) == 1 );


char* board223566560 = gamma_board(board);
assert( board223566560 != NULL );
assert( strcmp(board223566560, 
"..4..2.3...5\n"
"1.5...2.2..3\n"
"3...4.1.4...\n"
"...123..1412\n"
".4.3122.2.44\n"
"35...2...233\n"
"2.....4..1.4\n"
"..51.4....15\n"
".2442.23...1\n"
".2.34.4.1..3\n"
".1.23..344.5\n"
"4.23....31.4\n"
".45.1...5.32\n"
"5524.3155.45\n"
"5.2.12....43\n") == 0);
free(board223566560);
board223566560 = NULL;
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_free_fields(board, 4) == 88 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_free_fields(board, 2) == 86 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 3, 2, 5) == 1 );


char* board514015110 = gamma_board(board);
assert( board514015110 != NULL );
assert( strcmp(board514015110, 
"..4..2.3...5\n"
"1.5...2.2..3\n"
"3...4.1.4...\n"
"...123..1412\n"
".413122.2.44\n"
"35...2...233\n"
"2.....4..1.4\n"
".351.4....15\n"
".2442.23.2.1\n"
".2334.4.1..3\n"
".1.23..344.5\n"
"4.23....31.4\n"
".45.1...5.32\n"
"5524.3155.45\n"
"5.2.12....43\n") == 0);
free(board514015110);
board514015110 = NULL;
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 5, 10, 14) == 1 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 9, 13) == 1 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 4, 3, 12) == 1 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 5, 10, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_free_fields(board, 2) == 79 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_free_fields(board, 3) == 77 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 5, 9, 4) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 9, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 14, 6) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_move(board, 5, 12, 9) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 4, 3, 9) == 1 );
assert( gamma_move(board, 5, 11, 12) == 1 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_golden_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_free_fields(board, 4) == 70 );
assert( gamma_move(board, 5, 10, 13) == 1 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 4, 3, 13) == 1 );
assert( gamma_golden_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 0, 10) == 1 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_golden_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 4, 7, 13) == 1 );
assert( gamma_move(board, 5, 1, 3) == 1 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_free_fields(board, 3) == 63 );
assert( gamma_move(board, 4, 7, 11) == 1 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 5, 5, 3) == 1 );
assert( gamma_free_fields(board, 5) == 61 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 5, 6) == 1 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 5, 7, 14) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_free_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_move(board, 5, 11, 5) == 0 );


char* board587088807 = gamma_board(board);
assert( board587088807 != NULL );
assert( strcmp(board587088807, 
"..4..2.3..55\n"
"1.54..242153\n"
"3..44.1.4..5\n"
"...123.41412\n"
"241312232.44\n"
"3524.2...233\n"
"2...4.4.2154\n"
"3351.42.3315\n"
"22442423.2.1\n"
".2334.4.13.3\n"
".1.23..344.5\n"
"4523.5.33114\n"
"34541...5.32\n"
"552423155.45\n"
"5.2.12.3..43\n") == 0);
free(board587088807);
board587088807 = NULL;
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 9, 10) == 1 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 9, 12) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 10, 12) == 1 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_free_fields(board, 5) == 51 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 10, 5) == 1 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_free_fields(board, 2) == 49 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 4, 6, 10) == 0 );
assert( gamma_move(board, 5, 14, 9) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 1, 2, 12) == 1 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );


char* board730158834 = gamma_board(board);
assert( board730158834 != NULL );
assert( strcmp(board730158834, 
"124..2.3..55\n"
"1.54..242153\n"
"3.144.1.4425\n"
"...123.41412\n"
"241312232244\n"
"3524.2...233\n"
"2...4.4.2154\n"
"3351342.3315\n"
"22442423.2.1\n"
".233434.1353\n"
".1.23..344.5\n"
"4523.5.33114\n"
"34541.2.5.32\n"
"552423155.45\n"
"5.2412.3..43\n") == 0);
free(board730158834);
board730158834 = NULL;
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_free_fields(board, 5) == 44 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_golden_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 6, 10) == 0 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 6, 4) == 1 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_free_fields(board, 1) == 41 );


char* board579612129 = gamma_board(board);
assert( board579612129 != NULL );
assert( strcmp(board579612129, 
"124..2.3..55\n"
"1.54..242153\n"
"3.144.1.4425\n"
"...123.41412\n"
"241312232244\n"
"3524.2...233\n"
"2...4.4.2154\n"
"3351342.3315\n"
"22442423.2.1\n"
".233434.1353\n"
".1.23.534415\n"
"4523.5.33114\n"
"34541.2.5.32\n"
"552423155.45\n"
"5.241213..43\n") == 0);
free(board579612129);
board579612129 = NULL;
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 9, 11) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_free_fields(board, 1) == 41 );


char* board328245602 = gamma_board(board);
assert( board328245602 != NULL );
assert( strcmp(board328245602, 
"124..2.3..55\n"
"1.54..242153\n"
"3.144.1.4425\n"
"...123.41412\n"
"241312232244\n"
"3524.2...233\n"
"2...4.4.2154\n"
"3351342.3315\n"
"22442423.2.1\n"
".233434.1353\n"
".1.23.534415\n"
"4523.5.33114\n"
"34541.2.5.32\n"
"552423155.45\n"
"5.241213..43\n") == 0);
free(board328245602);
board328245602 = NULL;
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_free_fields(board, 5) == 41 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 1, 9, 14) == 1 );
assert( gamma_free_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 2, 6, 3) == 1 );


char* board688868053 = gamma_board(board);
assert( board688868053 != NULL );
assert( strcmp(board688868053, 
"124..2.3.155\n"
"1.54..242153\n"
"3.144.1.4425\n"
"...123.41412\n"
"241312232244\n"
"3524.2...233\n"
"2...4.4.2154\n"
"3351342.3315\n"
"22442423.2.1\n"
".233434.1353\n"
".1.23.534415\n"
"4523.5233114\n"
"34541.2.5.32\n"
"552423155.45\n"
"5.241213..43\n") == 0);
free(board688868053);
board688868053 = NULL;
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 5, 14, 8) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_free_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 5, 2, 12) == 0 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );


char* board364231026 = gamma_board(board);
assert( board364231026 != NULL );
assert( strcmp(board364231026, 
"124.32.3.155\n"
"1.54..242153\n"
"3.144.1.4425\n"
"...123.41412\n"
"241312232244\n"
"3524.2...233\n"
"2...4.4.2154\n"
"3351342.3315\n"
"22442423.2.1\n"
".233434.1353\n"
".1.23.534415\n"
"4523.5233114\n"
"34541.2.5.32\n"
"552423155.45\n"
"5.241213..43\n") == 0);
free(board364231026);
board364231026 = NULL;
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_golden_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_golden_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 4, 6, 10) == 0 );
assert( gamma_move(board, 5, 11, 7) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 5, 7, 8) == 1 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_golden_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 32 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 9, 0) == 1 );
assert( gamma_free_fields(board, 4) == 32 );
assert( gamma_move(board, 5, 9, 11) == 0 );
assert( gamma_free_fields(board, 5) == 32 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_free_fields(board, 4) == 31 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_free_fields(board, 3) == 18 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 4, 6, 14) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 8, 9) == 1 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_free_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_move(board, 5, 10, 4) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_golden_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 5, 9, 13) == 0 );


gamma_delete(board);

    return 0;
}
