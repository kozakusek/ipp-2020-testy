#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 114037014
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 15, 4, 33);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_free_fields(board, 1) == 179 );
assert( gamma_move(board, 2, 11, 9) == 1 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 1, 4, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 4, 8, 2) == 1 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 1, 9, 6) == 1 );
assert( gamma_move(board, 3, 3, 13) == 1 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 11) == 1 );
assert( gamma_free_fields(board, 3) == 163 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 6 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_free_fields(board, 3) == 158 );
assert( gamma_move(board, 4, 3, 7) == 1 );
assert( gamma_move(board, 4, 9, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_golden_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_move(board, 4, 2, 14) == 1 );
assert( gamma_move(board, 1, 4, 8) == 1 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 6, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 1, 9, 10) == 1 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_move(board, 3, 11, 5) == 1 );


char* board283046465 = gamma_board(board);
assert( board283046465 != NULL );
assert( strcmp(board283046465, 
"1.4.........\n"
"...31.......\n"
"............\n"
".4..1.23..3.\n"
".2.......1..\n"
".2..2......2\n"
"....1...2...\n"
"...4......3.\n"
"...2.....1..\n"
"4..........3\n"
"...2......2.\n"
".1...3......\n"
".4.11.4.4...\n"
".3....4.....\n"
".1....4..4..\n") == 0);
free(board283046465);
board283046465 = NULL;
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 1, 2, 1) == 1 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );


char* board897777995 = gamma_board(board);
assert( board897777995 != NULL );
assert( strcmp(board897777995, 
"1.4.........\n"
"...31.......\n"
"............\n"
".4..1.23..3.\n"
".2.......1..\n"
".2..2......2\n"
"....13..2...\n"
"...4...2..3.\n"
"...2..3.41..\n"
"4..........3\n"
"...2......2.\n"
".1...3......\n"
".4.11.4.4...\n"
".31...4.....\n"
".1....4..4..\n") == 0);
free(board897777995);
board897777995 = NULL;
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 8) == 1 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 4, 7, 14) == 1 );
assert( gamma_move(board, 4, 9, 5) == 1 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_golden_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 3, 10, 8) == 1 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 6, 12) == 1 );
assert( gamma_move(board, 1, 10, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 2, 11, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 4, 4, 0) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 3, 10, 0) == 1 );
assert( gamma_move(board, 4, 2, 12) == 1 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 1, 6, 7) == 1 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_free_fields(board, 3) == 115 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 14) == 1 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 2, 4, 6) == 1 );


char* board456864185 = gamma_board(board);
assert( board456864185 != NULL );
assert( strcmp(board456864185, 
"1.4...44....\n"
"...31......2\n"
".34...1.....\n"
".4..1.23..3.\n"
".2..1....11.\n"
"22..2.1....2\n"
"2...13.22.3.\n"
"...44.12.13.\n"
"2..22.3.41..\n"
"4....2.3.4.3\n"
"...2......2.\n"
".1...3......\n"
".4.11.4.4..1\n"
".31...4...2.\n"
"314.4.4.343.\n") == 0);
free(board456864185);
board456864185 = NULL;
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 9, 2) == 1 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_free_fields(board, 2) == 108 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_free_fields(board, 3) == 107 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_free_fields(board, 4) == 107 );
assert( gamma_move(board, 2, 5, 4) == 1 );


char* board900255857 = gamma_board(board);
assert( board900255857 != NULL );
assert( strcmp(board900255857, 
"1.4...44....\n"
"...31......2\n"
".34...1.....\n"
".4..1323..3.\n"
".2..1....11.\n"
"22..2.1....2\n"
"2...13.22.3.\n"
"...44.12.13.\n"
"2..22.3.41..\n"
"4....2.3.4.3\n"
".1.2.2....2.\n"
".1...3......\n"
".4.11.4.44.1\n"
".31...4...2.\n"
"31434.4.343.\n") == 0);
free(board900255857);
board900255857 = NULL;
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 4, 7, 12) == 1 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_free_fields(board, 1) == 105 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 11, 8) == 1 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 1, 1, 5) == 1 );
assert( gamma_move(board, 1, 5, 6) == 1 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_free_fields(board, 3) == 98 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 2) == 0 );


char* board128529176 = gamma_board(board);
assert( board128529176 != NULL );
assert( strcmp(board128529176, 
"1.4...44....\n"
"...31......2\n"
".34...14....\n"
".4..1323..3.\n"
".2..1....11.\n"
"22..2.1....2\n"
"2...13.22.34\n"
"..144.12.13.\n"
"2..2213.41..\n"
"41...2.3.433\n"
".1.2.2...22.\n"
".1...33.....\n"
".4.11.4.44.1\n"
".31...4...2.\n"
"31434.4.343.\n") == 0);
free(board128529176);
board128529176 = NULL;
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_golden_move(board, 4, 1, 10) == 1 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 2, 0, 10) == 1 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 4, 10, 6) == 1 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_free_fields(board, 4) == 89 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 2, 10) == 1 );
assert( gamma_golden_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 11) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_free_fields(board, 1) == 84 );
assert( gamma_golden_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_free_fields(board, 3) == 84 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 4, 5, 0) == 1 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_free_fields(board, 2) == 78 );
assert( gamma_move(board, 3, 5, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_free_fields(board, 3) == 75 );
assert( gamma_move(board, 4, 13, 10) == 0 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_free_fields(board, 1) == 74 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 7, 9) == 1 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_free_fields(board, 4) == 71 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 3, 8, 12) == 1 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 11) == 0 );
assert( gamma_move(board, 4, 1, 14) == 1 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 10, 9) == 1 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_golden_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_free_fields(board, 2) == 64 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 10, 3) == 0 );


char* board890850286 = gamma_board(board);
assert( board890850286 != NULL );
assert( strcmp(board890850286, 
"144.3.44...3\n"
"...313.....2\n"
".34...143...\n"
"341.1323..34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".4144.12.13.\n"
"2.32213.414.\n"
"411.22.3.433\n"
".1.242.2.224\n"
".14..331.11.\n"
".441134.44.1\n"
".31...421.2.\n"
"31434443343.\n") == 0);
free(board890850286);
board890850286 = NULL;
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_free_fields(board, 1) == 63 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 1, 9, 13) == 1 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_free_fields(board, 1) == 62 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 2, 13) == 1 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 30 );
assert( gamma_free_fields(board, 1) == 60 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 2, 1, 13) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_free_fields(board, 3) == 59 );
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 8, 13) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_free_fields(board, 3) == 56 );
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_free_fields(board, 2) == 56 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_free_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_golden_move(board, 1, 8, 10) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_golden_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_golden_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 28 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board120875941 = gamma_board(board);
assert( board120875941 != NULL );
assert( strcmp(board120875941, 
"144.3.44...3\n"
".24313.321.2\n"
".34...143...\n"
"34141323..34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".4144212.133\n"
"2.32213.414.\n"
"411.22.3.433\n"
".1.242.2.224\n"
".14.4331.11.\n"
"1441134.44.1\n"
".31.1.421.21\n"
"31434443343.\n") == 0);
free(board120875941);
board120875941 = NULL;
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 4, 6, 13) == 1 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_free_fields(board, 2) == 51 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 2, 3, 14) == 0 );


char* board631479716 = gamma_board(board);
assert( board631479716 != NULL );
assert( strcmp(board631479716, 
"14433.44...3\n"
".243134321.2\n"
".34...143...\n"
"34141323..34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".4144212.133\n"
"2.32213.414.\n"
"411.22.3.433\n"
".1.242.2.224\n"
".14.4331.11.\n"
"1441134.44.1\n"
".31.1.421.21\n"
"31434443343.\n") == 0);
free(board631479716);
board631479716 = NULL;
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_free_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_free_fields(board, 4) == 50 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_free_fields(board, 1) == 50 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 11, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board735540150 = gamma_board(board);
assert( board735540150 != NULL );
assert( strcmp(board735540150, 
"14433.44...3\n"
".243134321.2\n"
".34...143...\n"
"34141323..34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".4144212.133\n"
"2.32213.414.\n"
"411.22.3.433\n"
".1.242.2.224\n"
".14.4331.11.\n"
"1441134.44.1\n"
".31.1.421.21\n"
"31434443343.\n") == 0);
free(board735540150);
board735540150 = NULL;
assert( gamma_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 4, 0, 6) == 0 );


char* board564794302 = gamma_board(board);
assert( board564794302 != NULL );
assert( strcmp(board564794302, 
"14433.44...3\n"
".243134321.2\n"
".34...143...\n"
"34141323..34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".4144212.133\n"
"2.32213.414.\n"
"411.22.3.433\n"
".1.242.2.224\n"
".1434331.11.\n"
"1441134.44.1\n"
".31.1.421.21\n"
"31434443343.\n") == 0);
free(board564794302);
board564794302 = NULL;
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_golden_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 12, 0) == 0 );


char* board644264749 = gamma_board(board);
assert( board644264749 != NULL );
assert( strcmp(board644264749, 
"14433.44...3\n"
".243134321.2\n"
".34...143...\n"
"34141323..34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".4144212.133\n"
"2.32213.414.\n"
"411.22.31433\n"
".1.242.2.224\n"
".1434331.11.\n"
"1441134.44.1\n"
".31.1.421.21\n"
"31434443343.\n") == 0);
free(board644264749);
board644264749 = NULL;
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_golden_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 28 );


char* board647417714 = gamma_board(board);
assert( board647417714 != NULL );
assert( strcmp(board647417714, 
"14433.44...3\n"
".243134321.2\n"
".34...143...\n"
"34141323..34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".4144212.133\n"
"2.32213.414.\n"
"411.22.31433\n"
".1.242.2.224\n"
".1434331.11.\n"
"1441134.44.1\n"
".31.1.421.21\n"
"31434443343.\n") == 0);
free(board647417714);
board647417714 = NULL;
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 38 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_golden_move(board, 1, 6, 2) == 1 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_free_fields(board, 4) == 47 );
assert( gamma_golden_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );


char* board440179110 = gamma_board(board);
assert( board440179110 != NULL );
assert( strcmp(board440179110, 
"14433.44...3\n"
".243134321.2\n"
".34...143...\n"
"34141323..34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".4144212.133\n"
"2.322133414.\n"
"411.22.31433\n"
".1.242.2.224\n"
".1434331.11.\n"
"1441131.44.1\n"
".31.1.421.21\n"
"31434443343.\n") == 0);
free(board440179110);
board440179110 = NULL;
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 3, 11, 3) == 1 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_golden_move(board, 4, 13, 3) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_golden_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_golden_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 5, 6) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );


char* board788247273 = gamma_board(board);
assert( board788247273 != NULL );
assert( strcmp(board788247273, 
"14433.44...3\n"
".243134321.2\n"
"234...1431..\n"
"341413232.34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".41442122133\n"
"2.322133414.\n"
"411.22.31433\n"
".1.242.2.224\n"
"31434331.113\n"
"1441131.44.1\n"
".31.1.421.21\n"
"314344433432\n") == 0);
free(board788247273);
board788247273 = NULL;
assert( gamma_move(board, 3, 8, 1) == 0 );


char* board101701306 = gamma_board(board);
assert( board101701306 != NULL );
assert( strcmp(board101701306, 
"14433.44...3\n"
".243134321.2\n"
"234...1431..\n"
"341413232.34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
".41442122133\n"
"2.322133414.\n"
"411.22.31433\n"
".1.242.2.224\n"
"31434331.113\n"
"1441131.44.1\n"
".31.1.421.21\n"
"314344433432\n") == 0);
free(board101701306);
board101701306 = NULL;
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 6, 4) == 1 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_free_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 1, 0, 7) == 1 );


char* board618883040 = gamma_board(board);
assert( board618883040 != NULL );
assert( strcmp(board618883040, 
"14433.44...3\n"
".243134321.2\n"
"234...1431..\n"
"341413232.34\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
"141442122133\n"
"2.322133414.\n"
"411.22.31433\n"
".1.24242.224\n"
"31434331.113\n"
"1441131.44.1\n"
".31.1.421.21\n"
"314344433432\n") == 0);
free(board618883040);
board618883040 = NULL;
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 3, 11, 6) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 9, 11) == 1 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );


char* board887566807 = gamma_board(board);
assert( board887566807 != NULL );
assert( strcmp(board887566807, 
"14433.44...3\n"
".243134321.2\n"
"234...1431..\n"
"341413232134\n"
"242.13...11.\n"
"22..2.143442\n"
"2..213.22.34\n"
"141442122133\n"
"2.3221334143\n"
"411.22.31433\n"
".1.24242.224\n"
"31434331.113\n"
"1441131.44.1\n"
".31.1.421.21\n"
"314344433432\n") == 0);
free(board887566807);
board887566807 = NULL;
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 38 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_free_fields(board, 4) == 36 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 38 );


char* board247295068 = gamma_board(board);
assert( board247295068 != NULL );
assert( strcmp(board247295068, 
"14433.44...3\n"
".243134321.2\n"
"234...1431..\n"
"341413232134\n"
"242.13...11.\n"
"221.2.143442\n"
"2..213.22.34\n"
"141442122133\n"
"2.3221334143\n"
"411.22.31433\n"
".1.24242.224\n"
"31434331.113\n"
"1441131.44.1\n"
".31.1.421.21\n"
"314344433432\n") == 0);
free(board247295068);
board247295068 = NULL;
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 2, 0, 1) == 1 );


char* board233011191 = gamma_board(board);
assert( board233011191 != NULL );
assert( strcmp(board233011191, 
"14433.44...3\n"
".243134321.2\n"
"234...1431..\n"
"341413232134\n"
"242.13...11.\n"
"221.2.143442\n"
"2..213.22.34\n"
"141442122133\n"
"2.3221334143\n"
"411.22.31433\n"
".1.24242.224\n"
"31434331.113\n"
"1441131.44.1\n"
"231.1.421.21\n"
"314344433432\n") == 0);
free(board233011191);
board233011191 = NULL;
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_golden_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_free_fields(board, 4) == 34 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_golden_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 10, 14) == 1 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 2, 11, 12) == 1 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 9, 14) == 1 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 38 );
assert( gamma_golden_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_golden_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 1, 10, 12) == 1 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );


char* board864842553 = gamma_board(board);
assert( board864842553 != NULL );
assert( strcmp(board864842553, 
"14433.44.223\n"
".243134321.2\n"
"234...143112\n"
"341413232134\n"
"242.13...11.\n"
"221.23143442\n"
"2..213.22.34\n"
"141442122133\n"
"2.3221334143\n"
"411.22.31433\n"
".1.24242.224\n"
"31434331.113\n"
"1441131.44.1\n"
"231.1.421.21\n"
"314344433432\n") == 0);
free(board864842553);
board864842553 = NULL;
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_move(board, 4, 3, 10) == 1 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 39 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_free_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 38 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );


char* board226300333 = gamma_board(board);
assert( board226300333 != NULL );
assert( strcmp(board226300333, 
"14433.44.223\n"
".243134321.2\n"
"234...143112\n"
"341413232134\n"
"242413...11.\n"
"221.23143442\n"
"2..213.22.34\n"
"141442122133\n"
"2.3221334143\n"
"411.22.31433\n"
".1.24242.224\n"
"31434331.113\n"
"1441131244.1\n"
"231.1.421.21\n"
"314344433432\n") == 0);
free(board226300333);
board226300333 = NULL;


gamma_delete(board);

    return 0;
}
