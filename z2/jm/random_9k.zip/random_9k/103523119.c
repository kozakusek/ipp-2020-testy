#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 103523119
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 8, 5, 24);
assert( board != NULL );


assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 1, 17, 2) == 1 );
assert( gamma_move(board, 2, 13, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 1, 7, 16) == 0 );
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 1, 10, 3) == 1 );


char* board593599804 = gamma_board(board);
assert( board593599804 != NULL );
assert( strcmp(board593599804, 
"..................\n"
"..1...............\n"
"...2...4.....2....\n"
"..5...............\n"
"......4...1.......\n"
".3...............1\n"
".......4..........\n"
"...1..............\n") == 0);
free(board593599804);
board593599804 = NULL;
assert( gamma_move(board, 2, 17, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 1) == 1 );
assert( gamma_golden_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 5, 14, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 1, 5, 1) == 1 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 11, 3) == 1 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_move(board, 2, 15, 2) == 1 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 3, 16, 6) == 1 );


char* board393041153 = gamma_board(board);
assert( board393041153 != NULL );
assert( strcmp(board393041153, 
"..2...............\n"
"..1.............32\n"
"...2...4.....2....\n"
"..5...............\n"
"......4...15......\n"
".3.............2.1\n"
"...4.1.4..........\n"
"...1...1......5...\n") == 0);
free(board393041153);
board393041153 = NULL;
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );


char* board610392318 = gamma_board(board);
assert( board610392318 != NULL );
assert( strcmp(board610392318, 
"..2...............\n"
"..1.............32\n"
"...2...4.....2....\n"
"..5...............\n"
"......4...15......\n"
".3.............2.1\n"
"...4.1.4..........\n"
"...1...1......5...\n") == 0);
free(board610392318);
board610392318 = NULL;
assert( gamma_move(board, 5, 6, 5) == 1 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 7, 6) == 1 );
assert( gamma_move(board, 5, 0, 5) == 1 );
assert( gamma_move(board, 5, 11, 4) == 1 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 1, 17, 0) == 1 );
assert( gamma_move(board, 3, 10, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 5, 2, 1) == 1 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 2, 12, 6) == 1 );
assert( gamma_move(board, 3, 1, 17) == 0 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_free_fields(board, 3) == 114 );
assert( gamma_move(board, 4, 1, 17) == 0 );
assert( gamma_move(board, 4, 17, 2) == 0 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 5, 12, 4) == 1 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_golden_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 5, 17, 5) == 1 );
assert( gamma_golden_move(board, 5, 6, 16) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 3, 3, 16) == 0 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_move(board, 5, 10, 7) == 1 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_golden_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_move(board, 4, 11, 7) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_move(board, 5, 6, 0) == 1 );
assert( gamma_golden_move(board, 5, 6, 17) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_free_fields(board, 2) == 103 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_golden_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 17, 0) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 4, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_free_fields(board, 5) == 100 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 3, 10, 7) == 0 );


char* board756890843 = gamma_board(board);
assert( board756890843 != NULL );
assert( strcmp(board756890843, 
"..2.....2.54......\n"
".31....4....2...32\n"
"5.42..54.....2...5\n"
"..5..22....55.....\n"
"....3.4...15......\n"
".34........3...2.1\n"
"335411.4..........\n"
"..31.551..3...5..1\n") == 0);
free(board756890843);
board756890843 = NULL;
assert( gamma_move(board, 4, 7, 14) == 0 );
assert( gamma_move(board, 5, 10, 1) == 1 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 14, 3) == 1 );
assert( gamma_golden_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_free_fields(board, 3) == 96 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 5, 8, 6) == 1 );
assert( gamma_free_fields(board, 5) == 95 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_move(board, 5, 2, 3) == 1 );
assert( gamma_free_fields(board, 5) == 94 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 1, 17, 0) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 5, 13, 7) == 1 );
assert( gamma_move(board, 1, 14, 6) == 1 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_move(board, 4, 4, 10) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 12 );


char* board138036415 = gamma_board(board);
assert( board138036415 != NULL );
assert( strcmp(board138036415, 
"..2...3.2.54.5....\n"
"231....45...2.1.32\n"
"5.42..54...4.2...5\n"
"..53.22....55.....\n"
"..5.3.4...15..2...\n"
".34........3...2.1\n"
"335411.4..5.......\n"
"2.31.551..3...5..1\n") == 0);
free(board138036415);
board138036415 = NULL;
assert( gamma_move(board, 3, 1, 5) == 1 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_free_fields(board, 4) == 85 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_free_fields(board, 5) == 85 );
assert( gamma_move(board, 1, 0, 4) == 1 );


char* board480204668 = gamma_board(board);
assert( board480204668 != NULL );
assert( strcmp(board480204668, 
"..2...3.2.54.5....\n"
"231....45...2.1.32\n"
"5342..54...4.2...5\n"
"1.53.22....55.....\n"
"..5.3.4...15..2...\n"
".34.4......3...2.1\n"
"335411.4..5.......\n"
"2.31.551..3...5..1\n") == 0);
free(board480204668);
board480204668 = NULL;
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 15, 5) == 1 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 5, 4, 5) == 1 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_free_fields(board, 2) == 81 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 13, 6) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_free_fields(board, 1) == 79 );
assert( gamma_move(board, 2, 1, 17) == 0 );
assert( gamma_move(board, 3, 16, 3) == 1 );
assert( gamma_move(board, 3, 13, 1) == 1 );


char* board618871624 = gamma_board(board);
assert( board618871624 != NULL );
assert( strcmp(board618871624, 
"..2.5.3.2.54.5....\n"
"231....45...231.32\n"
"53425.54...4.2.3.5\n"
"1.53.22....55.....\n"
"..5.3.4...15..2.3.\n"
".34.4..4...3...2.1\n"
"335411.4..5..3....\n"
"2.31.551..3...5..1\n") == 0);
free(board618871624);
board618871624 = NULL;
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_golden_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 5, 10, 6) == 1 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_free_fields(board, 3) == 75 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 6, 11) == 0 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_free_fields(board, 1) == 72 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 4, 14, 1) == 1 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_move(board, 5, 17, 5) == 0 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 16, 5) == 1 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_golden_move(board, 5, 5, 11) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_golden_move(board, 3, 5, 17) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_move(board, 1, 4, 16) == 0 );
assert( gamma_move(board, 2, 12, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_free_fields(board, 2) == 64 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 4, 15, 6) == 1 );
assert( gamma_move(board, 5, 7, 16) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_free_fields(board, 1) == 62 );
assert( gamma_move(board, 2, 7, 17) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 12, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_move(board, 1, 7, 16) == 0 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 4, 14, 7) == 1 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 2, 17, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 11, 1) == 1 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 4, 13, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 5, 14, 5) == 1 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_golden_move(board, 1, 6, 7) == 1 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board716272752 = gamma_board(board);
assert( board716272752 != NULL );
assert( strcmp(board716272752, 
"..2.5.122.54.54...\n"
"231...145.5.231432\n"
"53425.54...4225345\n"
"1153.22...2554....\n"
"4.5.3.43..15..2.32\n"
".34.41.4.2.3...2.1\n"
"335411.43.53.34...\n"
"2531.551..313.5..1\n") == 0);
free(board716272752);
board716272752 = NULL;
assert( gamma_move(board, 3, 16, 4) == 1 );
assert( gamma_move(board, 3, 6, 2) == 1 );


char* board985301185 = gamma_board(board);
assert( board985301185 != NULL );
assert( strcmp(board985301185, 
"..2.5.122.54.54...\n"
"231...145.5.231432\n"
"53425.54...4225345\n"
"1153.22...2554..3.\n"
"4.5.3.43..15..2.32\n"
".34.4134.2.3...2.1\n"
"335411.43.53.34...\n"
"2531.551..313.5..1\n") == 0);
free(board985301185);
board985301185 = NULL;
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_golden_move(board, 4, 0, 17) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_free_fields(board, 5) == 52 );
assert( gamma_golden_move(board, 5, 0, 17) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );


char* board691184812 = gamma_board(board);
assert( board691184812 != NULL );
assert( strcmp(board691184812, 
".12.5.122.54.54...\n"
"231...145.5.231432\n"
"53425.54...4225345\n"
"1153.22...2554..3.\n"
"4.5.3.43..15..2.32\n"
".34.4134.2.3...2.1\n"
"335411.43.53.34...\n"
"2531.551..313.5..1\n") == 0);
free(board691184812);
board691184812 = NULL;
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_move(board, 5, 17, 2) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 2, 2) == 0 );
assert( gamma_move(board, 5, 13, 4) == 0 );
assert( gamma_free_fields(board, 5) == 51 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 1, 4, 17) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 7, 17) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 4, 4, 17) == 0 );
assert( gamma_free_fields(board, 4) == 51 );
assert( gamma_golden_move(board, 4, 1, 17) == 0 );
assert( gamma_move(board, 5, 17, 4) == 1 );
assert( gamma_move(board, 5, 1, 7) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 7, 16) == 0 );
assert( gamma_move(board, 2, 12, 2) == 1 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 16, 7) == 1 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 17, 2) == 0 );
assert( gamma_move(board, 4, 4, 6) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 15) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_free_fields(board, 2) == 46 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );


char* board954634249 = gamma_board(board);
assert( board954634249 != NULL );
assert( strcmp(board954634249, 
".12.5.122.54.54.2.\n"
"231.4.145.5.231432\n"
"53425.54...4225345\n"
"1153.22...2554..35\n"
"4.5.3343..15..2.32\n"
".34.413432.32..2.1\n"
"335411.43.53.34...\n"
"2531.551..313.5..1\n") == 0);
free(board954634249);
board954634249 = NULL;
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 15, 7) == 1 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_free_fields(board, 2) == 45 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 8, 0) == 1 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 2, 13, 0) == 1 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );


char* board887216620 = gamma_board(board);
assert( board887216620 != NULL );
assert( strcmp(board887216620, 
".12.5.122.54.5422.\n"
"231.4.145.5.231432\n"
"53425.54...4225345\n"
"1153.22...2554..35\n"
"4.5.3343..15..2.32\n"
".34.413432.32..2.1\n"
"335411.43.53.34...\n"
"2531.5514.31325..1\n") == 0);
free(board887216620);
board887216620 = NULL;
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 4, 15, 4) == 1 );
assert( gamma_move(board, 5, 4, 4) == 1 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 1, 15, 0) == 1 );


char* board753724663 = gamma_board(board);
assert( board753724663 != NULL );
assert( strcmp(board753724663, 
".12.5.122.54.5422.\n"
"231.4.145.5.231432\n"
"53425.54...4225345\n"
"1153522...2554.435\n"
"4.5.3343..15..2.32\n"
".34.413432.32..2.1\n"
"335411.43.53.34...\n"
"2531.5514.313251.1\n") == 0);
free(board753724663);
board753724663 = NULL;
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_golden_move(board, 2, 5, 2) == 0 );
assert( gamma_golden_move(board, 3, 7, 1) == 1 );


char* board257780754 = gamma_board(board);
assert( board257780754 != NULL );
assert( strcmp(board257780754, 
".12.5.122.54.5422.\n"
"231.4.145.5.231432\n"
"53425.54...4225345\n"
"1153522...2554.435\n"
"4.5.3343..15..2.32\n"
".34.413432.32..2.1\n"
"335411.33.53.34...\n"
"2531.5514.313251.1\n") == 0);
free(board257780754);
board257780754 = NULL;
assert( gamma_move(board, 4, 13, 2) == 1 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );


char* board951137078 = gamma_board(board);
assert( board951137078 != NULL );
assert( strcmp(board951137078, 
".12.5.122.54.5422.\n"
"231.4.145.5.231432\n"
"53425.54...4225345\n"
"1153522...2554.435\n"
"4.5.3343..15..2.32\n"
".34.413432.324.2.1\n"
"335411.33.53.34...\n"
"2531.5514.313251.1\n") == 0);
free(board951137078);
board951137078 = NULL;
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 14, 4) == 1 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 1, 17) == 0 );
assert( gamma_move(board, 5, 10, 2) == 1 );
assert( gamma_move(board, 5, 14, 7) == 0 );
assert( gamma_free_fields(board, 5) == 37 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_golden_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 2, 17, 2) == 0 );
assert( gamma_move(board, 3, 1, 17) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 13, 3) == 1 );
assert( gamma_free_fields(board, 4) == 36 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 5, 15, 0) == 0 );
assert( gamma_move(board, 1, 1, 17) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_free_fields(board, 1) == 36 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_free_fields(board, 4) == 35 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 2) == 0 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 7, 17) == 0 );
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 5, 14, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 24 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_golden_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_free_fields(board, 4) == 31 );
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board687676133 = gamma_board(board);
assert( board687676133 != NULL );
assert( strcmp(board687676133, 
".1235.122.54.5422.\n"
"231.4.14535.231432\n"
"53425454...4225345\n"
"1153522...25542435\n"
"4.5.3343..15.42.32\n"
".34.4134325324.2.1\n"
"335411.33353.34...\n"
"253125514.313251.1\n") == 0);
free(board687676133);
board687676133 = NULL;
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 7, 17) == 0 );
assert( gamma_golden_move(board, 3, 7, 7) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 17, 2) == 0 );
assert( gamma_free_fields(board, 5) == 31 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 5, 16, 1) == 1 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_free_fields(board, 5) == 30 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 3, 7, 17) == 0 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_move(board, 4, 16, 6) == 0 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 17) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_free_fields(board, 4) == 29 );
assert( gamma_golden_move(board, 4, 4, 16) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 16, 2) == 1 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_free_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 17, 3) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_free_fields(board, 5) == 28 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 5, 15, 1) == 1 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );


char* board505131579 = gamma_board(board);
assert( board505131579 != NULL );
assert( strcmp(board505131579, 
".1235.122.54.5422.\n"
"231.4.14535.231432\n"
"53425454...4225345\n"
"1153522...25542435\n"
"4.5233433.15.42.32\n"
".34.4134325324.231\n"
"335411.33353.3455.\n"
"253125514.313251.1\n") == 0);
free(board505131579);
board505131579 = NULL;
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_move(board, 3, 1, 17) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );


gamma_delete(board);

    return 0;
}
