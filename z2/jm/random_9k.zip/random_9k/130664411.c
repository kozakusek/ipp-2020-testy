#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 130664411
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 18, 6, 43);
assert( board != NULL );


assert( gamma_move(board, 1, 13, 2) == 1 );
assert( gamma_move(board, 2, 9, 7) == 1 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_move(board, 3, 16, 17) == 1 );
assert( gamma_move(board, 4, 12, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 1 );


char* board737896353 = gamma_board(board);
assert( board737896353 != NULL );
assert( strcmp(board737896353, 
"................3.\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"..2...............\n"
".........2........\n"
"..................\n"
"..................\n"
"..................\n"
"..................\n"
"............41....\n"
"..................\n"
"..................\n") == 0);
free(board737896353);
board737896353 = NULL;
assert( gamma_move(board, 5, 10, 10) == 1 );
assert( gamma_busy_fields(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_move(board, 1, 15, 6) == 1 );
assert( gamma_move(board, 2, 0, 3) == 1 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_move(board, 4, 8, 3) == 1 );
assert( gamma_move(board, 5, 17, 17) == 1 );
assert( gamma_move(board, 5, 16, 4) == 1 );
assert( gamma_move(board, 6, 10, 9) == 1 );
assert( gamma_move(board, 6, 8, 1) == 1 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 3, 17, 2) == 1 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 4, 9, 6) == 1 );
assert( gamma_move(board, 5, 16, 2) == 1 );
assert( gamma_move(board, 6, 10, 12) == 1 );
assert( gamma_move(board, 1, 9, 15) == 1 );
assert( gamma_move(board, 2, 16, 5) == 1 );
assert( gamma_move(board, 4, 11, 3) == 1 );
assert( gamma_move(board, 5, 0, 11) == 1 );
assert( gamma_move(board, 6, 14, 16) == 1 );
assert( gamma_move(board, 6, 6, 5) == 1 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_move(board, 2, 14, 6) == 1 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_move(board, 3, 0, 17) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 1) == 1 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 5, 12, 0) == 1 );
assert( gamma_move(board, 5, 11, 9) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 3, 4) == 1 );
assert( gamma_move(board, 6, 11, 1) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_golden_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 3, 2, 12) == 1 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 4, 16, 1) == 1 );
assert( gamma_move(board, 5, 4, 15) == 1 );
assert( gamma_move(board, 6, 2, 0) == 1 );
assert( gamma_free_fields(board, 6) == 276 );


char* board445002411 = gamma_board(board);
assert( board445002411 != NULL );
assert( strcmp(board445002411, 
"3...............35\n"
"..............6...\n"
"....5....1........\n"
".......2..........\n"
"..................\n"
".13.......6.......\n"
"5.................\n"
"..6...3...5.......\n"
".1.......465......\n"
"..2...............\n"
"........42........\n"
".........4....21..\n"
".....26.........2.\n"
"...6............5.\n"
"2......14..4......\n"
"..3........441..53\n"
"3..3.3..64.6....4.\n"
"..6.........5.....\n") == 0);
free(board445002411);
board445002411 = NULL;
assert( gamma_move(board, 1, 10, 16) == 1 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 3, 1, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_golden_move(board, 3, 16, 10) == 0 );
assert( gamma_move(board, 4, 2, 6) == 1 );
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_move(board, 5, 15, 8) == 1 );
assert( gamma_move(board, 6, 14, 3) == 1 );
assert( gamma_move(board, 6, 0, 6) == 1 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 2, 17, 6) == 1 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 3, 16, 5) == 0 );


char* board805320298 = gamma_board(board);
assert( board805320298 != NULL );
assert( strcmp(board805320298, 
"3...............35\n"
"..........1...6...\n"
"....5....1........\n"
".......2..........\n"
"..................\n"
".13.......6.......\n"
"5.................\n"
"..6...3...5.......\n"
"11.....3.465......\n"
"..2............5..\n"
"........42........\n"
"6.4...5.24....21.2\n"
".3.1.26.........2.\n"
"...6............5.\n"
"2......14..4..6...\n"
"..3........441..53\n"
"3..3.3..64.6....4.\n"
"..6.........5.....\n") == 0);
free(board805320298);
board805320298 = NULL;
assert( gamma_move(board, 4, 4, 9) == 1 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 17) == 1 );
assert( gamma_move(board, 5, 0, 16) == 1 );
assert( gamma_move(board, 6, 17, 10) == 1 );
assert( gamma_move(board, 6, 17, 7) == 1 );
assert( gamma_move(board, 1, 2, 14) == 1 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 2, 17, 11) == 1 );
assert( gamma_move(board, 2, 12, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 4, 6, 1) == 1 );
assert( gamma_move(board, 4, 8, 2) == 1 );
assert( gamma_free_fields(board, 4) == 250 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 1, 0) == 1 );
assert( gamma_move(board, 6, 12, 10) == 1 );
assert( gamma_move(board, 2, 10, 13) == 1 );


char* board265083294 = gamma_board(board);
assert( board265083294 != NULL );
assert( strcmp(board265083294, 
"3.........5.....35\n"
"5.........1...6...\n"
"....5....1........\n"
"..1....2..........\n"
"..........2.......\n"
".13.......6.......\n"
"5................2\n"
"..6...3...5.6....6\n"
"11..4..3.465......\n"
"..2.........2..5..\n"
"...3....42.......6\n"
"6.43..5.24....21.2\n"
".3.1.26.........2.\n"
"...6......1.....5.\n"
"2......14..4..6...\n"
"..3.....4..441..53\n"
"3..3.34.64.6....4.\n"
".664........5.....\n") == 0);
free(board265083294);
board265083294 = NULL;
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 14, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 10) == 1 );
assert( gamma_move(board, 6, 15, 15) == 1 );
assert( gamma_move(board, 1, 17, 15) == 1 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 3, 6, 15) == 1 );
assert( gamma_move(board, 4, 13, 17) == 1 );
assert( gamma_move(board, 4, 4, 17) == 1 );
assert( gamma_move(board, 5, 15, 3) == 1 );
assert( gamma_move(board, 5, 4, 17) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board695804824 = gamma_board(board);
assert( board695804824 != NULL );
assert( strcmp(board695804824, 
"3...4.....5..4..35\n"
"5.........1...6...\n"
"....5.3..1.....6.1\n"
"..1....2..........\n"
"..........2.......\n"
".13.......6.......\n"
"5................2\n"
"6.6...3...5.6....6\n"
"11..4..3.465......\n"
"..2.........2..5..\n"
"...3....42.......6\n"
"6.43..5.24....21.2\n"
".3.1.26.........2.\n"
"...6......1...5.5.\n"
"2......14.24..65..\n"
"..3.....4..441..53\n"
"3..3.34.64.6....4.\n"
".664...3....5.....\n") == 0);
free(board695804824);
board695804824 = NULL;
assert( gamma_move(board, 6, 0, 17) == 0 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_free_fields(board, 1) == 236 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 5, 13) == 1 );
assert( gamma_free_fields(board, 3) == 235 );
assert( gamma_move(board, 4, 17, 1) == 1 );
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_free_fields(board, 5) == 233 );
assert( gamma_move(board, 6, 2, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_move(board, 1, 11, 16) == 1 );
assert( gamma_move(board, 1, 1, 11) == 1 );
assert( gamma_move(board, 2, 4, 17) == 0 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_golden_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 17, 9) == 1 );
assert( gamma_move(board, 5, 1, 7) == 1 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_move(board, 6, 12, 14) == 1 );
assert( gamma_move(board, 6, 11, 14) == 1 );


char* board406386680 = gamma_board(board);
assert( board406386680 != NULL );
assert( strcmp(board406386680, 
"3...4.....5..4..35\n"
"5.........11..6...\n"
"....5.3..1.....6.1\n"
"..1....2...66.....\n"
".....3....2.......\n"
".13.......6.......\n"
"51...............2\n"
"6.6...3...5.6....6\n"
"11..4..3.465.....5\n"
"..2.........2..5..\n"
".5.3....42.......6\n"
"6.43135.24....21.2\n"
".3.1.26.........2.\n"
"..56......1...5.5.\n"
"2.6....14.24..65..\n"
".33.....4..441..53\n"
"3..3.34.64.6....44\n"
".664...3....5.....\n") == 0);
free(board406386680);
board406386680 = NULL;
assert( gamma_move(board, 1, 14, 9) == 1 );
assert( gamma_move(board, 1, 11, 16) == 0 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 16, 3) == 1 );
assert( gamma_move(board, 4, 1, 13) == 1 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 10, 8) == 1 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 6, 12, 7) == 1 );
assert( gamma_free_fields(board, 6) == 218 );
assert( gamma_move(board, 1, 15, 12) == 1 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 11) == 1 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );


char* board766387206 = gamma_board(board);
assert( board766387206 != NULL );
assert( strcmp(board766387206, 
"3...4.....5..4..35\n"
"5.........11..6...\n"
"....5.3..1.....6.1\n"
"..1....2...66.....\n"
".4...3....2.......\n"
".13.......6....1..\n"
"51.............2.2\n"
"6.6...3...5.6....6\n"
"11..4..3.4652.1..5\n"
"..2.......5.2..5..\n"
".5.3....42..6....6\n"
"6.43135.24....21.2\n"
".3.1.26.........2.\n"
"..56......1...5.5.\n"
"2.6....14.24..653.\n"
".33.....4..441..53\n"
"3..3.34.64.6....44\n"
".664...3....5.....\n") == 0);
free(board766387206);
board766387206 = NULL;
assert( gamma_move(board, 4, 4, 0) == 1 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_golden_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 2, 14, 0) == 1 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_move(board, 3, 5, 17) == 1 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 10) == 0 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 6, 4, 5) == 1 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 2, 16, 12) == 1 );
assert( gamma_move(board, 2, 8, 17) == 1 );
assert( gamma_move(board, 3, 16, 12) == 0 );
assert( gamma_move(board, 3, 17, 4) == 1 );
assert( gamma_move(board, 4, 13, 6) == 1 );
assert( gamma_move(board, 4, 11, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 16, 15) == 1 );
assert( gamma_move(board, 5, 15, 5) == 1 );
assert( gamma_move(board, 6, 8, 8) == 1 );
assert( gamma_move(board, 1, 14, 16) == 0 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_move(board, 2, 2, 17) == 1 );
assert( gamma_golden_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 4, 15, 13) == 1 );


char* board588877415 = gamma_board(board);
assert( board588877415 != NULL );
assert( strcmp(board588877415, 
"3.2.43..2.5..4..35\n"
"5.........11..6...\n"
"....5.3..1.....651\n"
"..1....2...66.....\n"
".4...3....2....4..\n"
".13.3.....6....12.\n"
"51.............2.2\n"
"6.6...3...5.6....6\n"
"11..4..3.4652.1..5\n"
"..2.....6.5.2..5..\n"
".5.3....42..6....6\n"
"6.43135.24...421.2\n"
".311626........52.\n"
"..56......1...5.53\n"
"2.6....14.24..653.\n"
".33.....4..441..53\n"
"3..3.34.64.6....44\n"
".66445.3...45.2...\n") == 0);
free(board588877415);
board588877415 = NULL;
assert( gamma_move(board, 6, 17, 9) == 0 );
assert( gamma_move(board, 1, 17, 9) == 0 );
assert( gamma_move(board, 1, 8, 15) == 1 );
assert( gamma_move(board, 2, 7, 11) == 1 );
assert( gamma_move(board, 3, 14, 2) == 1 );
assert( gamma_free_fields(board, 3) == 196 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 16, 9) == 1 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 5, 15, 2) == 1 );
assert( gamma_move(board, 5, 15, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 11, 3) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );


char* board507016862 = gamma_board(board);
assert( board507016862 != NULL );
assert( strcmp(board507016862, 
"3.2.43..2.5..4..35\n"
"5.........11..6...\n"
"....5.3.11.....651\n"
"..1....2...66.....\n"
".4...3....2....4..\n"
".13.3.....6....12.\n"
"51.....2.......2.2\n"
"6.6...3...5.6....6\n"
"11..4..3.4652.1.45\n"
"..2.....6.5.2..5..\n"
".5.3....42..6....6\n"
"6.43135.24...421.2\n"
".311626........52.\n"
"..56......1...5.53\n"
"2.6....14.24..653.\n"
".33.....4..4413553\n"
"3..3.34.64.6....44\n"
".66445.3...45.2...\n") == 0);
free(board507016862);
board507016862 = NULL;
assert( gamma_move(board, 2, 13, 3) == 1 );
assert( gamma_move(board, 2, 13, 7) == 1 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 15) == 1 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 6, 3, 9) == 1 );
assert( gamma_move(board, 6, 10, 1) == 1 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_move(board, 1, 3, 17) == 1 );
assert( gamma_move(board, 1, 4, 13) == 1 );
assert( gamma_free_fields(board, 1) == 187 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 3, 9, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 4, 3, 14) == 1 );
assert( gamma_move(board, 5, 16, 13) == 1 );
assert( gamma_move(board, 5, 9, 0) == 1 );
assert( gamma_move(board, 6, 2, 11) == 1 );
assert( gamma_move(board, 1, 3, 12) == 1 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 2, 16, 9) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 3, 1, 14) == 1 );
assert( gamma_move(board, 4, 13, 17) == 0 );
assert( gamma_move(board, 5, 8, 13) == 1 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 6, 7, 10) == 1 );
assert( gamma_move(board, 6, 16, 14) == 1 );
assert( gamma_move(board, 1, 15, 1) == 1 );
assert( gamma_move(board, 1, 8, 12) == 1 );
assert( gamma_move(board, 2, 11, 17) == 1 );
assert( gamma_move(board, 3, 7, 15) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 5, 5, 11) == 1 );
assert( gamma_move(board, 6, 3, 12) == 0 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_free_fields(board, 6) == 171 );


char* board923968298 = gamma_board(board);
assert( board923968298 != NULL );
assert( strcmp(board923968298, 
"3.2143..2.52.4..35\n"
"5.........11..6...\n"
"4...5.3311.....651\n"
".314...2...66...6.\n"
".4..13..532....45.\n"
".1313...1.6....12.\n"
"516..5.2.......2.2\n"
"6.6...36..5.6....6\n"
"11.64..3.4652.1.45\n"
"..2.....6.5.2..5..\n"
".5.3....42..62...6\n"
"6.43135.24...421.2\n"
".311626.3......52.\n"
"..56......1...5.53\n"
"2.6....14.24.2653.\n"
".33.....4..4413553\n"
"3..3.34.6466...144\n"
".66445.3.5.45.2...\n") == 0);
free(board923968298);
board923968298 = NULL;
assert( gamma_move(board, 1, 17, 7) == 0 );
assert( gamma_move(board, 2, 14, 5) == 1 );
assert( gamma_move(board, 2, 10, 11) == 1 );
assert( gamma_free_fields(board, 3) == 169 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 5, 16, 12) == 0 );
assert( gamma_move(board, 5, 5, 8) == 1 );
assert( gamma_free_fields(board, 5) == 167 );
assert( gamma_move(board, 6, 10, 14) == 1 );
assert( gamma_move(board, 6, 16, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 29 );
assert( gamma_move(board, 1, 16, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 7, 16) == 1 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 3, 5, 12) == 1 );
assert( gamma_move(board, 4, 13, 11) == 1 );
assert( gamma_move(board, 5, 13, 17) == 0 );
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 6, 6, 13) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 12, 11) == 1 );
assert( gamma_move(board, 2, 16, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 6) == 1 );
assert( gamma_move(board, 4, 16, 10) == 1 );
assert( gamma_move(board, 5, 14, 8) == 1 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 6, 6, 2) == 1 );
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board994211349 = gamma_board(board);
assert( board994211349 != NULL );
assert( strcmp(board994211349, 
"3.2143..2.52.4..35\n"
"5......2..11..6...\n"
"4...5.3311.....651\n"
".314...2..666...6.\n"
".4..136.532....45.\n"
".13133..1.6....12.\n"
"516..5.24.2.14.2.2\n"
"6.6..336..5.6...46\n"
"11.64..3.4652.1.45\n"
"..2..5..6.5.2.55..\n"
".5.3....42..62...6\n"
"6.43135.24.4.421.2\n"
".311626.3.....252.\n"
"..56......1...5.53\n"
"2.6....14.24.2653.\n"
".33...6.4..4413553\n"
"3..3.34.6466...144\n"
".66445.3.5.45.2...\n") == 0);
free(board994211349);
board994211349 = NULL;
assert( gamma_move(board, 3, 16, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 4, 12, 12) == 1 );
assert( gamma_move(board, 5, 0, 11) == 0 );
assert( gamma_move(board, 5, 15, 0) == 1 );
assert( gamma_golden_move(board, 5, 13, 1) == 0 );
assert( gamma_move(board, 6, 1, 12) == 0 );
assert( gamma_move(board, 1, 5, 7) == 1 );
assert( gamma_move(board, 1, 17, 11) == 0 );
assert( gamma_move(board, 2, 12, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 16, 3) == 0 );


char* board472557128 = gamma_board(board);
assert( board472557128 != NULL );
assert( strcmp(board472557128, 
"3.2143..2.52.4..35\n"
"5......2..11..6...\n"
"4...5.3311.....651\n"
".314...2..666...6.\n"
".4..136.532....45.\n"
".13133..1.6.4..12.\n"
"516..5.24.2.14.2.2\n"
"6.6..336..5.6...46\n"
"11.64..3.4652.1.45\n"
"..2..5..6.5.2.55..\n"
".5.3.1..42..62...6\n"
"6.43135.24.42421.2\n"
".311626.3.....252.\n"
"..56......1...5.53\n"
"2.6....14.24.2653.\n"
".33...6.4..4413553\n"
"3..3.34.6466...144\n"
".66445.3.5.45.25..\n") == 0);
free(board472557128);
board472557128 = NULL;
assert( gamma_move(board, 5, 16, 3) == 0 );
assert( gamma_move(board, 5, 14, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 29 );


char* board398968186 = gamma_board(board);
assert( board398968186 != NULL );
assert( strcmp(board398968186, 
"3.2143..2.52.4..35\n"
"5......2..11..6...\n"
"4...5.3311.....651\n"
".314...2..666...6.\n"
".4..136.532....45.\n"
".13133..1.6.4..12.\n"
"516..5.24.2.14.2.2\n"
"6.6..336..5.6...46\n"
"11.64..3.4652.1.45\n"
"..2..5..6.5.2.55..\n"
".5.3.1..42..62...6\n"
"6.43135.24.42421.2\n"
".311626.3.....252.\n"
"..56......1...5.53\n"
"2.6....14.24.2653.\n"
".33...6.4..4413553\n"
"3..3.34.6466...144\n"
".66445.3.5.45.25..\n") == 0);
free(board398968186);
board398968186 = NULL;
assert( gamma_move(board, 6, 16, 5) == 0 );
assert( gamma_move(board, 6, 6, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_free_fields(board, 2) == 152 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board349373079 = gamma_board(board);
assert( board349373079 != NULL );
assert( strcmp(board349373079, 
"3.2143..2.52.4..35\n"
"5......2..11..6...\n"
"4...5.3311.....651\n"
".314...2..666...6.\n"
".4..136.532....45.\n"
".13133..1.6.4..12.\n"
"516..5.24.2.14.2.2\n"
"6.6..336..5.6...46\n"
"11.64..3.4652.1.45\n"
"..2..5..6.5.2.55..\n"
".5.3.1..42..62...6\n"
"6.43135.24.42421.2\n"
".311626.3.....252.\n"
"..56......1...5.53\n"
"2.6....14.24.2653.\n"
".33...6.4..4413553\n"
"3..3.34.6466...144\n"
".66445.3.5.45.25..\n") == 0);
free(board349373079);
board349373079 = NULL;
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 3, 14, 1) == 1 );
assert( gamma_move(board, 4, 9, 8) == 1 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 5, 12, 4) == 1 );
assert( gamma_free_fields(board, 5) == 148 );
assert( gamma_golden_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 6, 15, 15) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 28 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 6, 9, 2) == 1 );
assert( gamma_move(board, 1, 16, 1) == 0 );
assert( gamma_move(board, 1, 15, 4) == 1 );
assert( gamma_free_fields(board, 1) == 144 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 1, 5) == 1 );
assert( gamma_move(board, 2, 15, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 6, 2, 3) == 0 );
assert( gamma_move(board, 6, 6, 1) == 0 );


char* board124630828 = gamma_board(board);
assert( board124630828 != NULL );
assert( strcmp(board124630828, 
"3.2143..2.52.4..35\n"
"5......2..11..6...\n"
"43..5.3311.....651\n"
".314...2..666...6.\n"
".42.136.532....45.\n"
".13133..1.6.4..12.\n"
"516..5.24.2.14.2.2\n"
"6.6..336..5.6..246\n"
"11.64..3.4652.1.45\n"
"..2..5..645.2.55..\n"
".5.3.1..42..62...6\n"
"6.43135.24.42421.2\n"
".111626.3.....252.\n"
"..563.....1.5.5153\n"
"2.6....14.24.2653.\n"
".33...6.46.4413553\n"
"3..3.34.6466..3144\n"
".66445.3.5.45.25..\n") == 0);
free(board124630828);
board124630828 = NULL;
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 5, 5, 10) == 0 );
assert( gamma_golden_move(board, 5, 6, 2) == 1 );
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 2, 17, 6) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_move(board, 5, 8, 14) == 1 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_golden_move(board, 5, 1, 3) == 0 );
assert( gamma_move(board, 6, 11, 9) == 0 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 16, 13) == 0 );
assert( gamma_move(board, 4, 16, 13) == 0 );
assert( gamma_move(board, 5, 17, 4) == 0 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_free_fields(board, 6) == 137 );
assert( gamma_move(board, 1, 13, 9) == 1 );
assert( gamma_move(board, 2, 15, 14) == 1 );
assert( gamma_move(board, 2, 13, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 17, 8) == 1 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_move(board, 6, 2, 7) == 1 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_move(board, 3, 12, 13) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 5, 13, 0) == 1 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 2, 16, 7) == 1 );
assert( gamma_move(board, 2, 16, 11) == 1 );
assert( gamma_move(board, 3, 6, 16) == 1 );
assert( gamma_move(board, 3, 8, 17) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 9, 11) == 1 );
assert( gamma_free_fields(board, 2) == 123 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 4, 9, 14) == 1 );
assert( gamma_free_fields(board, 4) == 122 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );


char* board435133927 = gamma_board(board);
assert( board435133927 != NULL );
assert( strcmp(board435133927, 
"3.2143..2.52.4..35\n"
"5.....32..11..6...\n"
"43..5.3311.....651\n"
".314...254666..26.\n"
".42.136.532.32.45.\n"
".13133..1.6.4..12.\n"
"516..5.2422.14.222\n"
"6.6..336..5.6..246\n"
"11.64.43.465211.45\n"
"152..5..64522.55.5\n"
".563.1..42..62..26\n"
"6.43135.24.42421.2\n"
".111626.3.....252.\n"
".2563.....1.5.5153\n"
"2.65...14.24.2653.\n"
"333...5146.4413553\n"
"3..3.34.6466..3144\n"
".66445.315.45525..\n") == 0);
free(board435133927);
board435133927 = NULL;
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 6, 16, 15) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 1, 15, 8) == 0 );


char* board767398386 = gamma_board(board);
assert( board767398386 != NULL );
assert( strcmp(board767398386, 
"3.2143..2.52.4..35\n"
"5.....32..11..6...\n"
"43..5.3311.....651\n"
".314...254666..26.\n"
".42.136.532.32.45.\n"
".13133..1.6.4..12.\n"
"516..5.2422.14.222\n"
"6.6..336..5.6..246\n"
"11.64.43.465211.45\n"
"152..5..64522.55.5\n"
".563.1..42..62..26\n"
"6.43135.24.42421.2\n"
".111626.3.....252.\n"
".2563.....1.5.5153\n"
"2.65...14.24.2653.\n"
"333...5146.4413553\n"
"3..3.34.6466..3144\n"
".66445.315.45525..\n") == 0);
free(board767398386);
board767398386 = NULL;
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );


char* board413736360 = gamma_board(board);
assert( board413736360 != NULL );
assert( strcmp(board413736360, 
"3.2143..2.52.4..35\n"
"5.....32..11..6...\n"
"43..5.3311.....651\n"
".314...254666..26.\n"
".42.136.532.32.45.\n"
".13133..1.6.4..12.\n"
"516..5.2422.14.222\n"
"6.6..336..5.6..246\n"
"11.64.43.465211.45\n"
"152..5..64522.55.5\n"
".563.1..42..62..26\n"
"6.43135.24.42421.2\n"
".111626.3.....252.\n"
".2563.....1.5.5153\n"
"2.65...14.24.2653.\n"
"333...5146.4413553\n"
"3..3.34.6466..3144\n"
".66445.315.45525..\n") == 0);
free(board413736360);
board413736360 = NULL;
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );


char* board750488988 = gamma_board(board);
assert( board750488988 != NULL );
assert( strcmp(board750488988, 
"3.2143..2.52.4..35\n"
"5.....32..11..6...\n"
"43..5.3311.....651\n"
".314...254666..26.\n"
".42.136.532.32.45.\n"
".13133..1.6.4..12.\n"
"516..5.2422.14.222\n"
"6.6..336..5.6..246\n"
"11.64.43.465211.45\n"
"152..5..64522.55.5\n"
".563.1..42..62..26\n"
"6.43135.24.42421.2\n"
".111626.3.....252.\n"
".2563.....1.5.5153\n"
"2.65...14.24.2653.\n"
"333...5146.4413553\n"
"3..3.34.6466..3144\n"
".66445.315.45525..\n") == 0);
free(board750488988);
board750488988 = NULL;
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 3, 2, 16) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 5, 14, 7) == 1 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_move(board, 6, 13, 11) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 13, 17) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 7, 8) == 1 );
assert( gamma_move(board, 5, 1, 12) == 0 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 16, 1) == 0 );
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 13, 14) == 1 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_free_fields(board, 5) == 112 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_move(board, 6, 2, 10) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 3, 16, 17) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 5, 5, 10) == 0 );
assert( gamma_move(board, 5, 12, 16) == 1 );
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_free_fields(board, 1) == 111 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 4, 7) == 1 );
assert( gamma_move(board, 2, 15, 13) == 0 );
assert( gamma_move(board, 3, 6, 16) == 0 );
assert( gamma_move(board, 3, 14, 11) == 1 );
assert( gamma_move(board, 4, 16, 8) == 1 );


char* board717965729 = gamma_board(board);
assert( board717965729 != NULL );
assert( strcmp(board717965729, 
"3.2143..2.52.4..35\n"
"5.3...32..115.6...\n"
"43..5.3311.....651\n"
".314...2546664.26.\n"
".42.136.532.32.45.\n"
".13133..1.6.4..12.\n"
"516..5.2422.143222\n"
"6.6..336..5.6..246\n"
"11.64.43.465211.45\n"
"152..5.464522.5545\n"
".56321..42..625.26\n"
"6.43135224.42421.2\n"
".111626.32....252.\n"
".2563...3.1.5.5153\n"
"2.65...14324.2653.\n"
"333...5146.4413553\n"
"31.3.34.6466..3144\n"
".66445.315.45525..\n") == 0);
free(board717965729);
board717965729 = NULL;
assert( gamma_move(board, 5, 5, 17) == 0 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_free_fields(board, 5) == 108 );
assert( gamma_move(board, 6, 2, 10) == 0 );
assert( gamma_move(board, 1, 14, 14) == 1 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 6, 14) == 1 );
assert( gamma_move(board, 5, 12, 17) == 1 );
assert( gamma_move(board, 6, 3, 17) == 0 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 12, 6) == 0 );
assert( gamma_move(board, 2, 14, 12) == 1 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 5, 6, 12) == 1 );
assert( gamma_move(board, 6, 16, 17) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 4, 11) == 1 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 4, 5, 17) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 5, 13, 14) == 0 );
assert( gamma_move(board, 5, 4, 4) == 0 );
assert( gamma_move(board, 6, 11, 6) == 0 );
assert( gamma_move(board, 6, 14, 15) == 1 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 8) == 0 );


char* board281031426 = gamma_board(board);
assert( board281031426 != NULL );
assert( strcmp(board281031426, 
"3.2143..2.5254..35\n"
"5.3...32..115.6...\n"
"43..5.3311....6651\n"
".314..52546664126.\n"
".42.136.532.32.45.\n"
".131335.1.6.4.212.\n"
"516.25.2422.143222\n"
"6.6..336..5.6..246\n"
"11.64.43.465211.45\n"
"152..5.464522.5545\n"
".56321.142..625.26\n"
"6.43135224.42421.2\n"
".111626.32..3.252.\n"
".2563...3.1.5.5153\n"
"2.65...14324.2653.\n"
"333...5146.4413553\n"
"31.3.34.6466..3144\n"
".66445.315.45525..\n") == 0);
free(board281031426);
board281031426 = NULL;
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_move(board, 6, 13, 17) == 0 );
assert( gamma_move(board, 6, 5, 9) == 1 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_free_fields(board, 4) == 97 );
assert( gamma_move(board, 5, 1, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_golden_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 6, 12, 5) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_golden_move(board, 1, 17, 11) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 16) == 0 );
assert( gamma_move(board, 5, 17, 9) == 0 );
assert( gamma_move(board, 6, 6, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 35 );
assert( gamma_free_fields(board, 6) == 96 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 11, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 15, 9) == 1 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_golden_move(board, 3, 11, 17) == 1 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 5, 17, 2) == 0 );
assert( gamma_move(board, 6, 15, 2) == 0 );
assert( gamma_move(board, 6, 15, 1) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_golden_move(board, 1, 8, 9) == 0 );
assert( gamma_free_fields(board, 2) == 93 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 41 );
assert( gamma_free_fields(board, 3) == 93 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 6, 14, 5) == 0 );
assert( gamma_free_fields(board, 6) == 93 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 2, 15, 11) == 0 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_free_fields(board, 5) == 93 );
assert( gamma_golden_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 6, 16, 12) == 0 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_move(board, 2, 17, 7) == 0 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 5, 16, 1) == 0 );
assert( gamma_move(board, 6, 5, 10) == 0 );
assert( gamma_move(board, 1, 16, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 4, 17, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 6, 16, 8) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 3, 15, 16) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 5, 0, 17) == 0 );
assert( gamma_move(board, 1, 16, 5) == 0 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 4, 16, 13) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 5, 8, 15) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 13, 11) == 0 );
assert( gamma_move(board, 6, 1, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );


char* board873478396 = gamma_board(board);
assert( board873478396 != NULL );
assert( strcmp(board873478396, 
"3.2143..2.5354..35\n"
"5.3...32..115.63..\n"
"43..5.3311....6651\n"
".314..52546664126.\n"
".42.136.532.32.45.\n"
".131335.1.6.4.212.\n"
"516.25.24221143222\n"
"6.6..336..5.6..246\n"
"11.64643.465211245\n"
"152..5.464522.5545\n"
".56321.142..625.26\n"
"6.43135224342421.2\n"
".111626.32..3.252.\n"
"12563...3.1.5.5153\n"
"2.65..614324.2653.\n"
"333...5146.4413553\n"
"31.3.34.6466..3144\n"
"266445.315.45525..\n") == 0);
free(board873478396);
board873478396 = NULL;
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 42 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 4, 16, 4) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 5, 6, 4) == 1 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 6, 13, 4) == 1 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_free_fields(board, 1) == 89 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 6, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 42 );
assert( gamma_move(board, 3, 5, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 43 );
assert( gamma_move(board, 4, 17, 14) == 1 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 5, 17, 14) == 0 );
assert( gamma_move(board, 5, 17, 14) == 0 );
assert( gamma_move(board, 6, 13, 14) == 0 );
assert( gamma_move(board, 6, 9, 17) == 1 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 2, 13, 5) == 1 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_golden_move(board, 5, 13, 6) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 6, 9, 16) == 1 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_move(board, 2, 16, 1) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_free_fields(board, 3) == 83 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 10, 14) == 0 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_move(board, 6, 15, 10) == 0 );
assert( gamma_move(board, 1, 15, 3) == 0 );


char* board953840483 = gamma_board(board);
assert( board953840483 != NULL );
assert( strcmp(board953840483, 
"3.2143..265354..35\n"
"5.3...32.6115.63..\n"
"43..5.3311....6651\n"
".314.3525466641264\n"
".42.136.532.32.45.\n"
".131335.1.6.4.212.\n"
"516.25.24221143222\n"
"6.6..336..5.6..246\n"
"11564643.465211245\n"
"152..5.464522.5545\n"
".56321.142..625.26\n"
"6.43135224342421.2\n"
".111626.32.432252.\n"
"12563.5.3.1.565153\n"
"2.65..614324.2653.\n"
"333...5146.4413553\n"
"31.3.34.6466..3144\n"
"266445.315.45525..\n") == 0);
free(board953840483);
board953840483 = NULL;
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 5, 10, 11) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_golden_move(board, 5, 14, 5) == 0 );
assert( gamma_move(board, 6, 15, 10) == 0 );
assert( gamma_move(board, 1, 12, 1) == 1 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 3, 17, 5) == 1 );
assert( gamma_golden_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );


char* board990071293 = gamma_board(board);
assert( board990071293 != NULL );
assert( strcmp(board990071293, 
"3.2143..265354..35\n"
"5.3...32.6115.63..\n"
"43..5.3311....6651\n"
".314.3525466641264\n"
".42.136.532.32.45.\n"
".131335.1.6.4.212.\n"
"516.25.24221143222\n"
"6.6..336..5.6..246\n"
"11564643.465211245\n"
"152..5.464522.5545\n"
".56321.142..625.26\n"
"6.43135224342421.2\n"
".111626.32.4322523\n"
"12563.5.3.1.565153\n"
"2.65..614324.2653.\n"
"333...5146.4413553\n"
"31.3.34.64661.3144\n"
"266445.315.45525..\n") == 0);
free(board990071293);
board990071293 = NULL;
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_free_fields(board, 5) == 80 );
assert( gamma_move(board, 6, 0, 16) == 0 );
assert( gamma_move(board, 6, 10, 15) == 1 );
assert( gamma_move(board, 1, 16, 16) == 1 );
assert( gamma_free_fields(board, 1) == 78 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_move(board, 6, 17, 15) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_move(board, 2, 16, 8) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 38 );
assert( gamma_move(board, 5, 15, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 43 );
assert( gamma_golden_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 6, 2, 10) == 0 );


char* board515381279 = gamma_board(board);
assert( board515381279 != NULL );
assert( strcmp(board515381279, 
"3.2143..265354..35\n"
"5.3...32.6115.631.\n"
"43..5.33116...6651\n"
".314.3525466641264\n"
".42.136.532.32.45.\n"
".131335.1.6.4.212.\n"
"516.25.24221143222\n"
"6.6..336..5.6..246\n"
"11564643.465211245\n"
"152..5.464522.5545\n"
".56321.142..625.26\n"
"6.43135224342421.2\n"
".111626.32.4322523\n"
"12563.5.3.1.565153\n"
"2.65..614324.2653.\n"
"333...5146.4413553\n"
"31.3.34.64661.3144\n"
"266445.315.45525..\n") == 0);
free(board515381279);
board515381279 = NULL;
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 3, 11) == 1 );
assert( gamma_move(board, 4, 7, 6) == 0 );


char* board472513566 = gamma_board(board);
assert( board472513566 != NULL );
assert( strcmp(board472513566, 
"3.2143..265354..35\n"
"5.3...32.6115.631.\n"
"43..5.33116...6651\n"
".314.3525466641264\n"
".42.136.532.32.45.\n"
".131335.1.6.4.212.\n"
"516325.24221143222\n"
"6.6..336..5.6..246\n"
"11564643.465211245\n"
"152..5.464522.5545\n"
".56321.142..625.26\n"
"6.43135224342421.2\n"
".111626.32.4322523\n"
"12563.5.3.1.565153\n"
"2.65..614324.2653.\n"
"333...5146.4413553\n"
"31.3.34.64661.3144\n"
"266445.315.45525..\n") == 0);
free(board472513566);
board472513566 = NULL;
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 6, 12, 9) == 0 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_free_fields(board, 1) == 77 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 3, 9, 17) == 0 );
assert( gamma_move(board, 4, 10, 5) == 1 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 6, 11, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 39 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 3, 17) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 1, 10) == 1 );
assert( gamma_move(board, 4, 8, 4) == 0 );


char* board509022186 = gamma_board(board);
assert( board509022186 != NULL );
assert( strcmp(board509022186, 
"3.2143..265354..35\n"
"5.3...32.6115.631.\n"
"43..5.33116...6651\n"
".314.3525466641264\n"
".42.136.532.32.45.\n"
".131335.1.6.4.212.\n"
"516325.24221143222\n"
"636..336..5.6..246\n"
"11564643.465211245\n"
"152..5.464522.5545\n"
".56321.142..625.26\n"
"6.43135224342421.2\n"
".111626.3244322523\n"
"12563.5.3.1.565153\n"
"2.65..614324.2653.\n"
"3334..5146.4413553\n"
"31.3.34.64661.3144\n"
"266445.315.45525..\n") == 0);
free(board509022186);
board509022186 = NULL;
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_move(board, 6, 14, 4) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 16, 4) == 0 );
assert( gamma_golden_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 4, 17, 1) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_busy_fields(board, 5) == 43 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_move(board, 6, 3, 2) == 0 );
assert( gamma_free_fields(board, 6) == 74 );
assert( gamma_move(board, 1, 16, 17) == 0 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 2, 16, 17) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 4, 11, 7) == 1 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_free_fields(board, 4) == 72 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_move(board, 6, 16, 6) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_move(board, 3, 15, 13) == 0 );
assert( gamma_golden_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 6, 11, 13) == 1 );
assert( gamma_move(board, 6, 3, 13) == 1 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 1, 1, 6) == 1 );
assert( gamma_golden_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_free_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 4, 13, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 43 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 16, 1) == 0 );
assert( gamma_move(board, 5, 13, 13) == 0 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 6, 15, 10) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 0, 13) == 1 );
assert( gamma_move(board, 4, 8, 8) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_move(board, 6, 7, 10) == 0 );
assert( gamma_golden_move(board, 6, 12, 8) == 1 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 17, 15) == 0 );
assert( gamma_golden_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_move(board, 5, 15, 13) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 6, 16, 3) == 0 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 1, 1, 17) == 1 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_free_fields(board, 2) == 62 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 5, 15, 11) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 6, 15, 8) == 0 );
assert( gamma_move(board, 1, 13, 14) == 0 );
assert( gamma_move(board, 2, 17, 7) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 16, 5) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 4, 14, 14) == 0 );
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 6, 15, 3) == 0 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 1, 7, 17) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 2, 12, 16) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 47 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 4, 15, 4) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 5, 4, 14) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_free_fields(board, 6) == 60 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 3, 3, 17) == 0 );
assert( gamma_move(board, 3, 10, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 16, 5) == 0 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 5, 8, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 8, 13) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_move(board, 5, 10, 14) == 0 );
assert( gamma_move(board, 6, 17, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 43 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 13, 8) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_free_fields(board, 3) == 58 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 12, 13) == 0 );
assert( gamma_move(board, 4, 0, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 16, 17) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_free_fields(board, 3) == 58 );
assert( gamma_move(board, 4, 4, 13) == 0 );


char* board666005370 = gamma_board(board);
assert( board666005370 != NULL );
assert( strcmp(board666005370, 
"312143.1265354..35\n"
"5.3...32.6115.631.\n"
"43..5.33116...6651\n"
".31453525466641264\n"
"3426136.532632.45.\n"
".131335.1.6.4.212.\n"
"516325424221143222\n"
"636.43362.546..246\n"
"11564643.465211245\n"
"152..5.46452625545\n"
".56321.142.4625.26\n"
"614313522434242162\n"
".111626.3244322523\n"
"12563.5.3.1.565153\n"
"2.65..614324.2653.\n"
"3334..5146.4413553\n"
"31.3.34.6466143144\n"
"2664451315.45525..\n") == 0);
free(board666005370);
board666005370 = NULL;
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_free_fields(board, 6) == 58 );
assert( gamma_free_fields(board, 1) == 58 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 4, 4, 16) == 1 );
assert( gamma_move(board, 4, 16, 5) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 6, 12, 0) == 0 );
assert( gamma_move(board, 1, 14, 10) == 1 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 2, 14, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 4, 8, 8) == 0 );
assert( gamma_move(board, 5, 15, 11) == 0 );
assert( gamma_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_free_fields(board, 2) == 54 );
assert( gamma_move(board, 3, 15, 7) == 1 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 4, 11, 15) == 1 );
assert( gamma_move(board, 5, 12, 7) == 0 );
assert( gamma_move(board, 6, 15, 1) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_free_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_move(board, 4, 14, 13) == 1 );
assert( gamma_move(board, 5, 16, 17) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_golden_move(board, 5, 16, 12) == 0 );
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 2, 12, 17) == 0 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 5, 10, 12) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 3, 4, 3) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 11) == 0 );
assert( gamma_move(board, 6, 17, 6) == 0 );
assert( gamma_move(board, 6, 10, 16) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 17, 6) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 16, 16) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_free_fields(board, 2) == 49 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_move(board, 6, 3, 17) == 0 );
assert( gamma_busy_fields(board, 6) == 43 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 16, 17) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_free_fields(board, 3) == 48 );
assert( gamma_move(board, 4, 17, 15) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 6, 3, 14) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_free_fields(board, 2) == 47 );


char* board749508740 = gamma_board(board);
assert( board749508740 != NULL );
assert( strcmp(board749508740, 
"312143.1265354..35\n"
"5.3.4.32.6115.631.\n"
"43..5.331164..6651\n"
".31453525466641264\n"
"3426136.532632445.\n"
".131335.1.6.4.212.\n"
"516325424221143222\n"
"636.43362.546.1246\n"
"11564643.465211245\n"
"152..5.46452625545\n"
"456321.14234625326\n"
"614313522434242162\n"
".11162643244322523\n"
"12563.5.3.12565153\n"
"2.653.614324.2653.\n"
"3334..5146.4413553\n"
"31.3.34.6466143144\n"
"2664451315145525..\n") == 0);
free(board749508740);
board749508740 = NULL;
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 3, 13, 10) == 1 );
assert( gamma_move(board, 4, 12, 13) == 0 );
assert( gamma_move(board, 5, 10, 15) == 0 );
assert( gamma_move(board, 5, 9, 14) == 0 );


char* board935463911 = gamma_board(board);
assert( board935463911 != NULL );
assert( strcmp(board935463911, 
"312143.1265354..35\n"
"5.3.4.32.6115.631.\n"
"43..5.331164..6651\n"
".31453525466641264\n"
"3426136.532632445.\n"
".131335.1.6.4.212.\n"
"516325424221143222\n"
"636.43362.54631246\n"
"11564643.465211245\n"
"152..5.46452625545\n"
"456321.14234625326\n"
"614313522434242162\n"
".11162643244322523\n"
"12563.5.3.12565153\n"
"2.653.614324.2653.\n"
"3334..5146.4413553\n"
"31.3.34.6466143144\n"
"2664451315145525..\n") == 0);
free(board935463911);
board935463911 = NULL;
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );


char* board284235481 = gamma_board(board);
assert( board284235481 != NULL );
assert( strcmp(board284235481, 
"312143.1265354..35\n"
"5.3.4.32.6115.631.\n"
"43..5.331164..6651\n"
".31453525466641264\n"
"3426136.532632445.\n"
".131335.1.6.4.212.\n"
"516325424221143222\n"
"636.43362.54631246\n"
"11564643.465211245\n"
"152..5.46452625545\n"
"456321.14234625326\n"
"614313522434242162\n"
".11162643244322523\n"
"12563.5.3.12565153\n"
"2.653.614324.2653.\n"
"3334..5146.4413553\n"
"31.3.34.6466143144\n"
"2664451315145525..\n") == 0);
free(board284235481);
board284235481 = NULL;
assert( gamma_move(board, 2, 13, 17) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );


char* board306144913 = gamma_board(board);
assert( board306144913 != NULL );
assert( strcmp(board306144913, 
"312143.1265354..35\n"
"5.3.4.32.6115.631.\n"
"43..5.331164..6651\n"
".31453525466641264\n"
"3426136.532632445.\n"
".131335.1.6.4.212.\n"
"516325424221143222\n"
"636.43362.54631246\n"
"11564643.465211245\n"
"152..5.46452625545\n"
"456321.14234625326\n"
"614313522434242162\n"
".11162643244322523\n"
"12563.5.3.12565153\n"
"2.653.614324.2653.\n"
"3334..5146.4413553\n"
"31.3.34.6466143144\n"
"2664451315145525..\n") == 0);
free(board306144913);
board306144913 = NULL;
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_free_fields(board, 4) == 46 );
assert( gamma_move(board, 5, 17, 6) == 0 );
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 6, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 2, 10) == 0 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 16, 17) == 0 );
assert( gamma_golden_move(board, 3, 5, 4) == 0 );


char* board527958638 = gamma_board(board);
assert( board527958638 != NULL );
assert( strcmp(board527958638, 
"312143.1265354..35\n"
"5.3.4.32.6115.631.\n"
"43..5.331164..6651\n"
".31453525466641264\n"
"3426136.532632445.\n"
".131335.1.6.4.212.\n"
"516325424221143222\n"
"636143362.54631246\n"
"11564643.465211245\n"
"152..5.46452625545\n"
"456321.14234625326\n"
"614313522434242162\n"
".11162643244322523\n"
"12563.5.3.12565153\n"
"2.653.614324.2653.\n"
"3334..5146.4413553\n"
"31.3134.6466143144\n"
"2664451315145525..\n") == 0);
free(board527958638);
board527958638 = NULL;
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 6, 17, 15) == 0 );
assert( gamma_move(board, 6, 11, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 1, 3, 16) == 1 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 17, 15) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 4, 14, 14) == 0 );
assert( gamma_move(board, 5, 17, 15) == 0 );
assert( gamma_move(board, 6, 12, 17) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 3, 5, 17) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_free_fields(board, 3) == 43 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_move(board, 5, 8, 15) == 0 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_free_fields(board, 6) == 43 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 0, 16) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_golden_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 5, 0, 17) == 0 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 1, 17, 6) == 0 );
assert( gamma_move(board, 1, 16, 14) == 0 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 15, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 50 );
assert( gamma_golden_move(board, 4, 15, 15) == 1 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 17, 6) == 0 );
assert( gamma_move(board, 2, 15, 13) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 13, 17) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 5, 15, 10) == 0 );
assert( gamma_free_fields(board, 5) == 41 );
assert( gamma_move(board, 6, 8, 15) == 0 );
assert( gamma_move(board, 6, 4, 9) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_move(board, 2, 17, 0) == 1 );
assert( gamma_move(board, 3, 16, 8) == 0 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_move(board, 4, 13, 17) == 0 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_busy_fields(board, 4) == 51 );
assert( gamma_move(board, 5, 16, 14) == 0 );
assert( gamma_move(board, 6, 13, 17) == 0 );


char* board137177810 = gamma_board(board);
assert( board137177810 != NULL );
assert( strcmp(board137177810, 
"312143.1265354..35\n"
"5.314.32.6115.631.\n"
"43..5.331164..6451\n"
"331453525466641264\n"
"3426136.532632445.\n"
".131335.1.6.4.212.\n"
"516325424221143222\n"
"636143362.54631246\n"
"11564643.465211245\n"
"152..5.46452625545\n"
"456321.14234625326\n"
"614313522434242162\n"
"211162643244322523\n"
"12563.533.12565153\n"
"2.653.614324.2653.\n"
"3334..5146.4413553\n"
"31.313426466143144\n"
"2664451315145525.2\n") == 0);
free(board137177810);
board137177810 = NULL;
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 10, 16) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 4, 17, 14) == 0 );
assert( gamma_move(board, 4, 16, 2) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 17, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 17) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 4, 17, 3) == 1 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 1, 15, 15) == 0 );


char* board632242255 = gamma_board(board);
assert( board632242255 != NULL );
assert( strcmp(board632242255, 
"312143.1265354..35\n"
"5.314.32.6115.631.\n"
"43..5.331164..6451\n"
"331453525466641264\n"
"3426136.532632445.\n"
".131335.1.6.4.212.\n"
"516325424221143222\n"
"636143362.54631246\n"
"11564643.465211245\n"
"152..5.46452625545\n"
"456321.14234625326\n"
"614313522434242162\n"
"211162643244322523\n"
"12563.533.12565153\n"
"2.653.614324.26534\n"
"3334..5146.4413553\n"
"31.313426466143144\n"
"2664451315145525.2\n") == 0);
free(board632242255);
board632242255 = NULL;
assert( gamma_move(board, 2, 16, 13) == 0 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_move(board, 4, 12, 17) == 0 );
assert( gamma_busy_fields(board, 4) == 52 );
assert( gamma_move(board, 5, 6, 7) == 1 );
assert( gamma_move(board, 6, 0, 16) == 0 );
assert( gamma_busy_fields(board, 6) == 42 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 52 );
assert( gamma_free_fields(board, 4) == 35 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 6, 15, 4) == 0 );
assert( gamma_move(board, 1, 16, 17) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 2, 16, 8) == 0 );
assert( gamma_move(board, 2, 3, 15) == 1 );
assert( gamma_move(board, 3, 17, 15) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 14, 17) == 1 );
assert( gamma_move(board, 6, 15, 5) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 17, 9) == 0 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_move(board, 5, 17, 4) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );


gamma_delete(board);

    return 0;
}
