#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 148325628
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 100, 7, 13);
assert( board != NULL );


assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_move(board, 3, 39, 0) == 0 );
assert( gamma_move(board, 3, 0, 81) == 1 );
assert( gamma_move(board, 4, 38, 0) == 0 );
assert( gamma_golden_move(board, 4, 81, 0) == 0 );
assert( gamma_move(board, 5, 52, 0) == 0 );
assert( gamma_move(board, 5, 0, 68) == 1 );
assert( gamma_move(board, 6, 63, 0) == 0 );
assert( gamma_move(board, 7, 0, 5) == 1 );
assert( gamma_move(board, 7, 0, 92) == 1 );
assert( gamma_move(board, 1, 31, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 3, 28, 0) == 0 );
assert( gamma_move(board, 3, 0, 34) == 1 );
assert( gamma_free_fields(board, 3) == 93 );
assert( gamma_move(board, 4, 21, 0) == 0 );
assert( gamma_free_fields(board, 4) == 93 );
assert( gamma_move(board, 5, 93, 0) == 0 );
assert( gamma_move(board, 5, 0, 84) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 6, 26, 0) == 0 );
assert( gamma_move(board, 7, 0, 41) == 1 );
assert( gamma_move(board, 7, 0, 17) == 1 );
assert( gamma_move(board, 1, 73, 0) == 0 );
assert( gamma_move(board, 1, 0, 44) == 1 );
assert( gamma_move(board, 2, 20, 0) == 0 );
assert( gamma_move(board, 2, 0, 27) == 1 );
assert( gamma_free_fields(board, 2) == 88 );
assert( gamma_move(board, 3, 0, 98) == 1 );
assert( gamma_move(board, 4, 0, 80) == 1 );
assert( gamma_move(board, 4, 0, 71) == 1 );
assert( gamma_free_fields(board, 4) == 85 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_move(board, 5, 0, 31) == 1 );
assert( gamma_move(board, 6, 20, 0) == 0 );
assert( gamma_move(board, 7, 0, 52) == 1 );
assert( gamma_move(board, 1, 0, 33) == 1 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 94, 0) == 0 );
assert( gamma_move(board, 2, 0, 10) == 1 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 3, 0, 99) == 1 );
assert( gamma_move(board, 4, 63, 0) == 0 );
assert( gamma_move(board, 4, 0, 75) == 1 );
assert( gamma_free_fields(board, 4) == 78 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 0, 49) == 1 );
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_move(board, 1, 0, 87) == 1 );


char* board717000409 = gamma_board(board);
assert( board717000409 != NULL );
assert( strcmp(board717000409, 
"3\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
"3\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
"5\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"1\n") == 0);
free(board717000409);
board717000409 = NULL;
assert( gamma_move(board, 2, 0, 31) == 0 );
assert( gamma_move(board, 3, 0, 22) == 1 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 4, 0, 30) == 1 );
assert( gamma_move(board, 5, 63, 0) == 0 );
assert( gamma_move(board, 6, 55, 0) == 0 );
assert( gamma_move(board, 7, 76, 0) == 0 );
assert( gamma_move(board, 7, 0, 59) == 1 );
assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_free_fields(board, 1) == 72 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 49, 0) == 0 );
assert( gamma_move(board, 2, 0, 33) == 0 );
assert( gamma_move(board, 3, 19, 0) == 0 );
assert( gamma_move(board, 3, 0, 71) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_move(board, 5, 90, 0) == 0 );
assert( gamma_move(board, 5, 0, 75) == 0 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 6, 0, 23) == 1 );
assert( gamma_move(board, 6, 0, 68) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 45) == 1 );
assert( gamma_move(board, 7, 0, 34) == 0 );
assert( gamma_move(board, 1, 86, 0) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 4, 43, 0) == 0 );
assert( gamma_move(board, 4, 0, 94) == 1 );
assert( gamma_move(board, 5, 0, 19) == 1 );
assert( gamma_move(board, 6, 0, 20) == 1 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_move(board, 1, 0, 19) == 0 );
assert( gamma_move(board, 3, 46, 0) == 0 );
assert( gamma_move(board, 3, 0, 32) == 1 );
assert( gamma_move(board, 4, 0, 23) == 0 );
assert( gamma_move(board, 4, 0, 40) == 1 );
assert( gamma_move(board, 5, 38, 0) == 0 );
assert( gamma_move(board, 7, 0, 97) == 1 );
assert( gamma_move(board, 1, 0, 78) == 1 );
assert( gamma_move(board, 2, 90, 0) == 0 );
assert( gamma_move(board, 3, 72, 0) == 0 );
assert( gamma_move(board, 4, 39, 0) == 0 );
assert( gamma_move(board, 4, 0, 66) == 1 );
assert( gamma_move(board, 5, 46, 0) == 0 );
assert( gamma_move(board, 5, 0, 72) == 1 );
assert( gamma_busy_fields(board, 5) == 6 );


char* board999186051 = gamma_board(board);
assert( board999186051 != NULL );
assert( strcmp(board999186051, 
"3\n"
"3\n"
"7\n"
".\n"
".\n"
"4\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
"3\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"7\n"
"1\n"
".\n"
".\n"
"7\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
"5\n"
"4\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"6\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
"4\n"
".\n"
"5\n"
"7\n"
"2\n"
".\n"
".\n"
"1\n"
"1\n") == 0);
free(board999186051);
board999186051 = NULL;
assert( gamma_move(board, 6, 0, 97) == 0 );
assert( gamma_move(board, 7, 63, 0) == 0 );
assert( gamma_move(board, 7, 0, 19) == 0 );
assert( gamma_free_fields(board, 7) == 59 );
assert( gamma_move(board, 1, 0, 49) == 0 );
assert( gamma_move(board, 1, 0, 67) == 1 );
assert( gamma_move(board, 2, 60, 0) == 0 );
assert( gamma_move(board, 3, 37, 0) == 0 );
assert( gamma_move(board, 3, 0, 39) == 1 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 5, 95, 0) == 0 );
assert( gamma_move(board, 5, 0, 86) == 1 );
assert( gamma_move(board, 6, 57, 0) == 0 );
assert( gamma_move(board, 7, 51, 0) == 0 );
assert( gamma_move(board, 7, 0, 61) == 1 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 2, 76, 0) == 0 );
assert( gamma_golden_move(board, 2, 32, 0) == 0 );
assert( gamma_move(board, 3, 0, 73) == 1 );
assert( gamma_move(board, 3, 0, 40) == 0 );
assert( gamma_move(board, 4, 0, 76) == 1 );
assert( gamma_move(board, 4, 0, 85) == 1 );
assert( gamma_move(board, 5, 0, 40) == 0 );
assert( gamma_move(board, 5, 0, 41) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 6, 0, 17) == 0 );
assert( gamma_move(board, 7, 60, 0) == 0 );
assert( gamma_move(board, 7, 0, 33) == 0 );
assert( gamma_move(board, 1, 0, 30) == 0 );
assert( gamma_golden_move(board, 1, 49, 0) == 0 );
assert( gamma_move(board, 2, 91, 0) == 0 );
assert( gamma_free_fields(board, 2) == 51 );
assert( gamma_move(board, 4, 60, 0) == 0 );
assert( gamma_move(board, 4, 0, 51) == 1 );
assert( gamma_move(board, 5, 0, 43) == 1 );
assert( gamma_move(board, 5, 0, 33) == 0 );


char* board652840170 = gamma_board(board);
assert( board652840170 != NULL );
assert( strcmp(board652840170, 
"3\n"
"3\n"
"7\n"
".\n"
".\n"
"4\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"3\n"
"4\n"
".\n"
"1\n"
".\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"4\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"7\n"
"1\n"
"5\n"
".\n"
"7\n"
"4\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
"5\n"
"4\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"6\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
"4\n"
"4\n"
"5\n"
"7\n"
"2\n"
".\n"
".\n"
"1\n"
"1\n") == 0);
free(board652840170);
board652840170 = NULL;
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_move(board, 2, 57, 0) == 0 );
assert( gamma_move(board, 2, 0, 22) == 0 );
assert( gamma_move(board, 3, 0, 46) == 1 );
assert( gamma_free_fields(board, 3) == 48 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_move(board, 4, 0, 50) == 1 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 42, 0) == 0 );
assert( gamma_move(board, 5, 0, 66) == 0 );
assert( gamma_move(board, 6, 16, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_move(board, 7, 93, 0) == 0 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 89, 0) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_move(board, 4, 0, 76) == 0 );
assert( gamma_move(board, 5, 0, 30) == 0 );
assert( gamma_move(board, 6, 70, 0) == 0 );
assert( gamma_move(board, 6, 0, 91) == 1 );
assert( gamma_move(board, 7, 0, 58) == 1 );
assert( gamma_move(board, 1, 38, 0) == 0 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 2, 0, 96) == 1 );
assert( gamma_golden_move(board, 2, 23, 0) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_free_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 5, 88, 0) == 0 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_move(board, 6, 38, 0) == 0 );
assert( gamma_move(board, 6, 0, 7) == 0 );
assert( gamma_move(board, 7, 89, 0) == 0 );
assert( gamma_golden_move(board, 7, 20, 0) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 0, 57) == 1 );
assert( gamma_move(board, 3, 26, 0) == 0 );
assert( gamma_move(board, 4, 88, 0) == 0 );
assert( gamma_move(board, 4, 0, 66) == 0 );
assert( gamma_move(board, 5, 0, 99) == 0 );
assert( gamma_move(board, 6, 0, 60) == 1 );
assert( gamma_move(board, 7, 0, 20) == 0 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_move(board, 1, 37, 0) == 0 );
assert( gamma_move(board, 1, 0, 73) == 0 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 79, 0) == 0 );
assert( gamma_move(board, 3, 0, 79) == 1 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 27, 0) == 0 );
assert( gamma_move(board, 6, 15, 0) == 0 );
assert( gamma_move(board, 7, 0, 15) == 1 );
assert( gamma_golden_move(board, 7, 10, 0) == 0 );
assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_move(board, 2, 21, 0) == 0 );
assert( gamma_move(board, 2, 0, 71) == 0 );
assert( gamma_move(board, 3, 53, 0) == 0 );
assert( gamma_move(board, 3, 0, 62) == 1 );
assert( gamma_move(board, 4, 0, 89) == 1 );
assert( gamma_golden_move(board, 4, 86, 0) == 0 );
assert( gamma_move(board, 5, 18, 0) == 0 );
assert( gamma_move(board, 5, 0, 76) == 0 );
assert( gamma_move(board, 6, 0, 20) == 0 );
assert( gamma_move(board, 6, 0, 14) == 1 );
assert( gamma_move(board, 7, 12, 0) == 0 );


char* board592991573 = gamma_board(board);
assert( board592991573 != NULL );
assert( strcmp(board592991573, 
"3\n"
"3\n"
"7\n"
"2\n"
".\n"
"4\n"
".\n"
"7\n"
"6\n"
".\n"
"4\n"
".\n"
"1\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"3\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"3\n"
"7\n"
"6\n"
"7\n"
"7\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"4\n"
"4\n"
"6\n"
".\n"
".\n"
"3\n"
"7\n"
"1\n"
"5\n"
".\n"
"7\n"
"4\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
"5\n"
"4\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"6\n"
"5\n"
".\n"
"7\n"
".\n"
"7\n"
"6\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
"4\n"
"4\n"
"5\n"
"7\n"
"2\n"
"1\n"
"1\n"
"1\n"
"1\n") == 0);
free(board592991573);
board592991573 = NULL;
assert( gamma_move(board, 1, 28, 0) == 0 );
assert( gamma_move(board, 1, 0, 42) == 1 );
assert( gamma_move(board, 2, 63, 0) == 0 );
assert( gamma_move(board, 2, 0, 37) == 1 );
assert( gamma_move(board, 3, 74, 0) == 0 );
assert( gamma_move(board, 4, 70, 0) == 0 );
assert( gamma_move(board, 4, 0, 46) == 0 );
assert( gamma_move(board, 5, 90, 0) == 0 );
assert( gamma_move(board, 5, 0, 57) == 0 );
assert( gamma_move(board, 6, 29, 0) == 0 );
assert( gamma_move(board, 6, 0, 12) == 1 );
assert( gamma_move(board, 7, 90, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 1, 0, 39) == 0 );
assert( gamma_move(board, 1, 0, 60) == 0 );
assert( gamma_move(board, 4, 26, 0) == 0 );
assert( gamma_move(board, 4, 0, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 95, 0) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 6, 74, 0) == 0 );
assert( gamma_free_fields(board, 6) == 32 );
assert( gamma_move(board, 7, 64, 0) == 0 );
assert( gamma_move(board, 1, 0, 19) == 0 );
assert( gamma_move(board, 2, 0, 69) == 1 );
assert( gamma_move(board, 3, 55, 0) == 0 );
assert( gamma_move(board, 3, 0, 75) == 0 );
assert( gamma_move(board, 4, 21, 0) == 0 );
assert( gamma_move(board, 4, 0, 49) == 0 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 6, 25, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 21, 0) == 0 );
assert( gamma_move(board, 7, 0, 46) == 0 );
assert( gamma_move(board, 1, 63, 0) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 36, 0) == 0 );
assert( gamma_move(board, 3, 0, 43) == 0 );
assert( gamma_move(board, 3, 0, 66) == 0 );
assert( gamma_move(board, 4, 29, 0) == 0 );
assert( gamma_move(board, 6, 0, 84) == 0 );
assert( gamma_move(board, 7, 47, 0) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 90, 0) == 0 );
assert( gamma_move(board, 2, 0, 25) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 3, 0, 20) == 0 );
assert( gamma_move(board, 5, 0, 14) == 0 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_move(board, 6, 63, 0) == 0 );
assert( gamma_move(board, 6, 0, 44) == 0 );
assert( gamma_move(board, 7, 65, 0) == 0 );
assert( gamma_move(board, 7, 0, 58) == 0 );
assert( gamma_move(board, 1, 56, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 88, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 56, 0) == 0 );
assert( gamma_move(board, 3, 0, 23) == 0 );
assert( gamma_move(board, 4, 65, 0) == 0 );
assert( gamma_move(board, 4, 0, 72) == 0 );
assert( gamma_move(board, 5, 88, 0) == 0 );
assert( gamma_move(board, 6, 18, 0) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 74, 0) == 0 );
assert( gamma_move(board, 7, 0, 86) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 65, 0) == 0 );
assert( gamma_move(board, 1, 0, 62) == 0 );
assert( gamma_move(board, 2, 0, 29) == 1 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 3, 0, 58) == 0 );
assert( gamma_move(board, 3, 0, 48) == 1 );
assert( gamma_move(board, 4, 65, 0) == 0 );
assert( gamma_move(board, 5, 0, 43) == 0 );
assert( gamma_move(board, 6, 0, 32) == 0 );
assert( gamma_move(board, 6, 0, 69) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 46, 0) == 0 );
assert( gamma_move(board, 7, 64, 0) == 0 );
assert( gamma_move(board, 3, 28, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 21, 0) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 5, 88, 0) == 0 );
assert( gamma_move(board, 6, 64, 0) == 0 );
assert( gamma_move(board, 7, 95, 0) == 0 );
assert( gamma_free_fields(board, 7) == 28 );
assert( gamma_move(board, 1, 93, 0) == 0 );
assert( gamma_move(board, 1, 0, 86) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 54, 0) == 0 );
assert( gamma_move(board, 3, 0, 85) == 0 );
assert( gamma_move(board, 5, 70, 0) == 0 );
assert( gamma_move(board, 5, 0, 41) == 0 );
assert( gamma_move(board, 6, 18, 0) == 0 );
assert( gamma_move(board, 6, 0, 91) == 0 );
assert( gamma_move(board, 7, 55, 0) == 0 );
assert( gamma_move(board, 7, 0, 51) == 0 );
assert( gamma_free_fields(board, 7) == 28 );
assert( gamma_move(board, 1, 0, 45) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 54, 0) == 0 );
assert( gamma_move(board, 3, 0, 38) == 1 );
assert( gamma_move(board, 3, 0, 23) == 0 );
assert( gamma_move(board, 4, 54, 0) == 0 );
assert( gamma_move(board, 5, 26, 0) == 0 );
assert( gamma_move(board, 5, 0, 36) == 1 );
assert( gamma_move(board, 6, 55, 0) == 0 );
assert( gamma_move(board, 6, 0, 79) == 0 );
assert( gamma_move(board, 7, 53, 0) == 0 );
assert( gamma_move(board, 1, 18, 0) == 0 );
assert( gamma_move(board, 1, 0, 93) == 1 );
assert( gamma_move(board, 2, 56, 0) == 0 );
assert( gamma_move(board, 2, 0, 96) == 0 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 70, 0) == 0 );


gamma_delete(board);

    return 0;
}
