#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 143649050
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(21, 23, 6, 90);
assert( board != NULL );


assert( gamma_move(board, 1, 14, 4) == 1 );
assert( gamma_free_fields(board, 1) == 482 );
assert( gamma_move(board, 2, 18, 2) == 1 );
assert( gamma_move(board, 2, 1, 19) == 1 );
assert( gamma_move(board, 3, 12, 14) == 1 );
assert( gamma_move(board, 4, 6, 4) == 1 );
assert( gamma_move(board, 5, 3, 7) == 1 );
assert( gamma_free_fields(board, 5) == 477 );
assert( gamma_move(board, 6, 11, 17) == 1 );
assert( gamma_move(board, 1, 8, 16) == 1 );
assert( gamma_free_fields(board, 1) == 475 );
assert( gamma_move(board, 2, 9, 7) == 1 );
assert( gamma_move(board, 2, 16, 10) == 1 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 4, 3, 5) == 1 );
assert( gamma_move(board, 4, 0, 22) == 1 );
assert( gamma_move(board, 5, 14, 0) == 1 );


char* board566427163 = gamma_board(board);
assert( board566427163 != NULL );
assert( strcmp(board566427163, 
"4....................\n"
".....................\n"
".....................\n"
".2...................\n"
".....................\n"
"...........6.........\n"
"........1............\n"
".....................\n"
"............3........\n"
".....................\n"
".....................\n"
".....................\n"
"................2....\n"
".....................\n"
".....................\n"
"...5.....2...........\n"
".....................\n"
"...4.................\n"
"......4.......1......\n"
".....................\n"
"3.................2..\n"
".....................\n"
"..............5......\n") == 0);
free(board566427163);
board566427163 = NULL;
assert( gamma_move(board, 6, 12, 4) == 1 );
assert( gamma_move(board, 6, 2, 5) == 1 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_move(board, 2, 12, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 20, 12) == 1 );
assert( gamma_move(board, 4, 3, 14) == 1 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_move(board, 5, 14, 5) == 1 );
assert( gamma_move(board, 5, 16, 22) == 1 );
assert( gamma_move(board, 6, 15, 5) == 1 );
assert( gamma_move(board, 6, 6, 10) == 0 );
assert( gamma_move(board, 1, 2, 17) == 1 );
assert( gamma_move(board, 1, 19, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 20, 9) == 1 );
assert( gamma_move(board, 3, 20, 2) == 1 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_free_fields(board, 3) == 454 );
assert( gamma_move(board, 4, 13, 11) == 1 );
assert( gamma_move(board, 5, 17, 18) == 1 );
assert( gamma_move(board, 6, 11, 19) == 1 );
assert( gamma_move(board, 6, 13, 7) == 1 );
assert( gamma_move(board, 1, 19, 0) == 1 );
assert( gamma_move(board, 2, 2, 3) == 1 );


char* board337282721 = gamma_board(board);
assert( board337282721 != NULL );
assert( strcmp(board337282721, 
"4...............5....\n"
".....................\n"
".....................\n"
".2.........6.........\n"
".................5...\n"
"..1........6.........\n"
"........1............\n"
".....................\n"
"...4.......33........\n"
".....................\n"
"....................3\n"
".............4.......\n"
"......1.........2....\n"
"....................2\n"
".....4...............\n"
"...5.....2...6.......\n"
".....................\n"
"..64........2.56.....\n"
"......4.....6.1......\n"
"..2..................\n"
"3.................213\n"
".....................\n"
"..............5....1.\n") == 0);
free(board337282721);
board337282721 = NULL;
assert( gamma_move(board, 3, 3, 18) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 4, 6, 12) == 1 );
assert( gamma_move(board, 5, 20, 2) == 0 );
assert( gamma_move(board, 6, 10, 18) == 1 );
assert( gamma_move(board, 1, 10, 22) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_move(board, 2, 16, 10) == 0 );
assert( gamma_golden_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 4, 3, 16) == 1 );


char* board942530959 = gamma_board(board);
assert( board942530959 != NULL );
assert( strcmp(board942530959, 
"4.........1.....5....\n"
".....................\n"
".....................\n"
".2.........6.........\n"
"...3......6......5...\n"
"..1........6.........\n"
"...4....1............\n"
".....................\n"
"...4.......33........\n"
".3...................\n"
"......4.............3\n"
".............4.......\n"
"......1.........2....\n"
"....................2\n"
".....4...............\n"
"...5.....2...6.......\n"
".....................\n"
"..64........2.56.....\n"
"......4.....6.1......\n"
"..2..................\n"
"3.................213\n"
".....................\n"
"....33........5....1.\n") == 0);
free(board942530959);
board942530959 = NULL;
assert( gamma_move(board, 5, 8, 15) == 1 );
assert( gamma_move(board, 6, 15, 9) == 1 );
assert( gamma_move(board, 1, 14, 15) == 1 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_golden_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 13, 3) == 1 );
assert( gamma_move(board, 2, 6, 13) == 1 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 4, 7, 4) == 1 );
assert( gamma_move(board, 5, 18, 11) == 1 );
assert( gamma_move(board, 6, 2, 0) == 1 );
assert( gamma_move(board, 1, 11, 10) == 1 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_free_fields(board, 2) == 429 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_move(board, 4, 13, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 14, 14) == 1 );
assert( gamma_move(board, 5, 20, 0) == 1 );
assert( gamma_move(board, 6, 10, 14) == 1 );
assert( gamma_move(board, 1, 20, 17) == 1 );
assert( gamma_move(board, 1, 17, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 12, 8) == 1 );
assert( gamma_move(board, 3, 2, 22) == 1 );
assert( gamma_move(board, 3, 13, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 8, 20) == 1 );
assert( gamma_free_fields(board, 4) == 417 );
assert( gamma_move(board, 5, 19, 20) == 1 );
assert( gamma_move(board, 5, 9, 3) == 1 );
assert( gamma_move(board, 6, 4, 15) == 1 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_free_fields(board, 1) == 413 );
assert( gamma_move(board, 2, 18, 19) == 1 );
assert( gamma_move(board, 2, 3, 17) == 1 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 17, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 5, 4, 11) == 1 );
assert( gamma_move(board, 5, 15, 20) == 1 );
assert( gamma_free_fields(board, 5) == 408 );
assert( gamma_move(board, 6, 1, 13) == 0 );
assert( gamma_move(board, 6, 13, 15) == 1 );
assert( gamma_move(board, 1, 2, 21) == 1 );
assert( gamma_move(board, 1, 12, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 20, 14) == 1 );
assert( gamma_move(board, 3, 1, 18) == 1 );
assert( gamma_move(board, 3, 4, 22) == 1 );


char* board424808148 = gamma_board(board);
assert( board424808148 != NULL );
assert( strcmp(board424808148, 
"4.3.3.....1.....5....\n"
"..1..................\n"
"........4......5...5.\n"
".2.........6......2..\n"
".3.3......6......5...\n"
"..12.......6........1\n"
"...4....1............\n"
"....6...5....61......\n"
"...4......633.5.....2\n"
".3....2..............\n"
"......4......3......3\n"
"....5........4...15..\n"
"1.....1....11...2....\n"
"...............6....2\n"
".....4......2........\n"
"...5.....2...6.......\n"
"..1..3...............\n"
"..64........2.56.3...\n"
"......44....641......\n"
"..2......5...2.......\n"
"3....3............213\n"
".....3...............\n"
"..6.33........5....15\n") == 0);
free(board424808148);
board424808148 = NULL;
assert( gamma_move(board, 5, 7, 14) == 1 );
assert( gamma_free_fields(board, 5) == 401 );
assert( gamma_move(board, 6, 21, 7) == 0 );
assert( gamma_free_fields(board, 6) == 401 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 17, 3) == 1 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 18, 16) == 1 );
assert( gamma_move(board, 3, 1, 19) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 16, 11) == 1 );
assert( gamma_move(board, 4, 11, 20) == 1 );
assert( gamma_move(board, 5, 5, 7) == 1 );
assert( gamma_move(board, 5, 10, 21) == 1 );
assert( gamma_move(board, 6, 9, 5) == 1 );
assert( gamma_move(board, 1, 16, 18) == 1 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 3, 1, 14) == 1 );
assert( gamma_move(board, 3, 11, 16) == 1 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 9, 1) == 1 );
assert( gamma_move(board, 4, 8, 3) == 1 );
assert( gamma_move(board, 5, 5, 11) == 1 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_move(board, 6, 3, 12) == 1 );
assert( gamma_free_fields(board, 6) == 386 );


char* board317952655 = gamma_board(board);
assert( board317952655 != NULL );
assert( strcmp(board317952655, 
"4.3.3.....1.....5....\n"
"..1.......5..........\n"
"........4..4...5...5.\n"
".2.........6......2..\n"
".3.3......6.....15...\n"
"..12.......6........1\n"
"...4....1..3......3..\n"
"....6...5....61......\n"
".3.4...5..633.5.....2\n"
".3....2..............\n"
"...6..4......3......3\n"
"....55..2....4..415..\n"
"1.....1....11...2....\n"
"...............6....2\n"
".....4......2........\n"
"...5.5...2...6.......\n"
"..1..3...............\n"
"..64.....6..2.56.3...\n"
"......44....641......\n"
"..2.....45...2...1...\n"
"3....3............213\n"
".....3...4...........\n"
"..6.33........5....15\n") == 0);
free(board317952655);
board317952655 = NULL;
assert( gamma_move(board, 1, 3, 18) == 0 );
assert( gamma_move(board, 2, 18, 12) == 1 );
assert( gamma_move(board, 3, 13, 6) == 1 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 5, 16, 22) == 0 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_move(board, 6, 18, 4) == 1 );
assert( gamma_move(board, 6, 10, 18) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_free_fields(board, 2) == 380 );
assert( gamma_move(board, 3, 13, 20) == 1 );
assert( gamma_move(board, 4, 7, 22) == 1 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_free_fields(board, 4) == 378 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 6, 16) == 1 );
assert( gamma_move(board, 6, 19, 14) == 1 );
assert( gamma_move(board, 1, 9, 16) == 1 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 2, 9, 13) == 1 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 3, 22, 3) == 0 );
assert( gamma_move(board, 4, 10, 11) == 1 );
assert( gamma_move(board, 4, 15, 3) == 1 );
assert( gamma_move(board, 5, 11, 6) == 1 );
assert( gamma_move(board, 1, 12, 11) == 1 );
assert( gamma_move(board, 1, 15, 4) == 1 );
assert( gamma_move(board, 2, 13, 18) == 1 );
assert( gamma_move(board, 3, 13, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 17, 13) == 1 );
assert( gamma_move(board, 5, 9, 0) == 1 );
assert( gamma_move(board, 5, 3, 16) == 0 );
assert( gamma_golden_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 6, 8, 16) == 0 );
assert( gamma_move(board, 6, 8, 8) == 1 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_free_fields(board, 1) == 362 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 4, 19, 3) == 1 );
assert( gamma_move(board, 4, 17, 16) == 1 );
assert( gamma_move(board, 5, 13, 18) == 0 );
assert( gamma_move(board, 6, 3, 16) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_move(board, 3, 22, 1) == 0 );
assert( gamma_move(board, 4, 8, 19) == 1 );
assert( gamma_move(board, 5, 4, 17) == 1 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_move(board, 6, 0, 17) == 1 );
assert( gamma_move(board, 2, 1, 15) == 1 );


char* board734705285 = gamma_board(board);
assert( board734705285 != NULL );
assert( strcmp(board734705285, 
"4.3.3..4..1.....5....\n"
"..1.......5..........\n"
"........4..4.3.5...5.\n"
".2......4..6......2..\n"
".3.3......6..2..15...\n"
"6.125......6........1\n"
"...4..5.11.3.....43..\n"
".2..6...5....61......\n"
".3.4...5..633.5....62\n"
".3....2..2.......4...\n"
"...6..4......3....2.3\n"
"....55..2.4.14..415..\n"
"1.....1.2..11...2....\n"
"...............6....2\n"
".....4..6...2........\n"
".4.5.5...2...6.......\n"
"5.1..3.....5.3.......\n"
"..64.1...6..2356.3...\n"
"......44....6411..6..\n"
"..24....451..2.4.1.4.\n"
"3....3............213\n"
".5...3...4...........\n"
"..6.33...52...5....15\n") == 0);
free(board734705285);
board734705285 = NULL;
assert( gamma_move(board, 3, 2, 16) == 1 );
assert( gamma_move(board, 3, 13, 9) == 1 );
assert( gamma_move(board, 4, 9, 18) == 1 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 5, 18, 11) == 0 );
assert( gamma_move(board, 6, 16, 1) == 1 );
assert( gamma_move(board, 1, 19, 6) == 1 );
assert( gamma_move(board, 1, 1, 20) == 1 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 3, 4, 16) == 1 );
assert( gamma_move(board, 4, 9, 8) == 1 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 18) == 0 );
assert( gamma_move(board, 6, 15, 19) == 1 );
assert( gamma_free_fields(board, 6) == 340 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 3, 18) == 0 );
assert( gamma_move(board, 2, 21, 14) == 0 );
assert( gamma_move(board, 2, 17, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_free_fields(board, 3) == 338 );


char* board882532980 = gamma_board(board);
assert( board882532980 != NULL );
assert( strcmp(board882532980, 
"4.3.3..4..1.....5....\n"
"..1.......5..........\n"
".1......4..4.3.5...5.\n"
".2......4..6...6..2..\n"
".3.3.....46..2..15...\n"
"6.125......6........1\n"
"..343.5.11.3.....43..\n"
".2..6...5....61......\n"
".3.4...5..633.5....62\n"
".3....2..2.......4...\n"
"...6..4......3....2.3\n"
"....55..2.4.14..415..\n"
"1.....1.2..11...2....\n"
"......4......3.6....2\n"
".....4..64..2........\n"
".4.5.5...2...6.......\n"
"5.1..3...3.5.3.....1.\n"
"..64.1...6..2356.3...\n"
"......44....6411..6..\n"
"..24....451..2.4.1.4.\n"
"34...3...........2213\n"
".5...3...4......6....\n"
".36.33..252...5....15\n") == 0);
free(board882532980);
board882532980 = NULL;
assert( gamma_move(board, 4, 17, 8) == 1 );
assert( gamma_move(board, 4, 4, 11) == 0 );


char* board296540821 = gamma_board(board);
assert( board296540821 != NULL );
assert( strcmp(board296540821, 
"4.3.3..4..1.....5....\n"
"..1.......5..........\n"
".1......4..4.3.5...5.\n"
".2......4..6...6..2..\n"
".3.3.....46..2..15...\n"
"6.125......6........1\n"
"..343.5.11.3.....43..\n"
".2..6...5....61......\n"
".3.4...5..633.5....62\n"
".3....2..2.......4...\n"
"...6..4......3....2.3\n"
"....55..2.4.14..415..\n"
"1.....1.2..11...2....\n"
"......4......3.6....2\n"
".....4..64..2....4...\n"
".4.5.5...2...6.......\n"
"5.1..3...3.5.3.....1.\n"
"..64.1...6..2356.3...\n"
"......44....6411..6..\n"
"..24....451..2.4.1.4.\n"
"34...3...........2213\n"
".5...3...4......6....\n"
".36.33..252...5....15\n") == 0);
free(board296540821);
board296540821 = NULL;
assert( gamma_move(board, 5, 15, 22) == 1 );
assert( gamma_move(board, 5, 16, 17) == 1 );
assert( gamma_free_fields(board, 6) == 335 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 1, 18, 22) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 19, 14) == 0 );
assert( gamma_move(board, 3, 20, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 16, 8) == 1 );
assert( gamma_move(board, 6, 18, 5) == 1 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 1, 20, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 6, 18) == 1 );
assert( gamma_move(board, 2, 19, 0) == 0 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 4, 14, 2) == 1 );
assert( gamma_free_fields(board, 4) == 327 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 11) == 0 );
assert( gamma_move(board, 6, 11, 19) == 0 );
assert( gamma_move(board, 6, 10, 3) == 0 );
assert( gamma_free_fields(board, 1) == 327 );
assert( gamma_move(board, 2, 16, 5) == 1 );
assert( gamma_move(board, 2, 19, 4) == 1 );
assert( gamma_move(board, 3, 19, 3) == 0 );


char* board897126247 = gamma_board(board);
assert( board897126247 != NULL );
assert( strcmp(board897126247, 
"4.3.3..4..1....55.1..\n"
"..1.......5..........\n"
".1......4..4.3.5...5.\n"
".2......4..6...6..2..\n"
".3.3..2..46..2..15...\n"
"6.125......6....5...1\n"
"..343.5.11.3.....43..\n"
".2..6...5....61......\n"
".3.4...5..633.5....62\n"
".3....2..2.......4...\n"
"...6..4......3....2.3\n"
"....55..2.4.14..415..\n"
"1.....1.2..11...2...3\n"
"3.....4......3.6....2\n"
".....4..64..2...54...\n"
".4.5.5...2...6.......\n"
"5.1..3...3.5.3.....1.\n"
"..64.1...6..2356236..\n"
"......44....6411..62.\n"
"..24....451..2.4.1.4.\n"
"34...3........4..2213\n"
".5...3...4......6....\n"
"436.33..252...5....15\n") == 0);
free(board897126247);
board897126247 = NULL;
assert( gamma_move(board, 4, 15, 12) == 1 );
assert( gamma_move(board, 5, 3, 9) == 1 );
assert( gamma_move(board, 5, 6, 2) == 1 );
assert( gamma_move(board, 6, 4, 16) == 0 );
assert( gamma_move(board, 1, 15, 22) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 17, 9) == 1 );
assert( gamma_move(board, 3, 11, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_free_fields(board, 3) == 320 );
assert( gamma_move(board, 4, 6, 18) == 0 );
assert( gamma_move(board, 4, 11, 20) == 0 );
assert( gamma_move(board, 5, 22, 17) == 0 );
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_move(board, 6, 4, 1) == 1 );
assert( gamma_free_fields(board, 6) == 318 );
assert( gamma_move(board, 1, 0, 18) == 1 );
assert( gamma_move(board, 1, 14, 16) == 1 );
assert( gamma_move(board, 2, 16, 1) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 3, 1, 22) == 1 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 5, 15, 3) == 0 );
assert( gamma_move(board, 6, 0, 4) == 1 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_move(board, 2, 13, 16) == 1 );
assert( gamma_move(board, 2, 17, 4) == 1 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 3, 19, 11) == 1 );


char* board782703672 = gamma_board(board);
assert( board782703672 != NULL );
assert( strcmp(board782703672, 
"433.3..4..1....55.1..\n"
"..1.......5..........\n"
".1......4..4.3.5...5.\n"
".2......4..6...6..2..\n"
"13.3..2..46..2..15...\n"
"6.125......6....5...1\n"
"..343.5.11.3.21..43..\n"
".2..6...5....61......\n"
".3.4...5..633.5....62\n"
".3....2..2.......4...\n"
"...6..4......3.4..2.3\n"
"....55..2.4.14..4153.\n"
"1.....1.2..11...2...3\n"
"3..5.14......3.6.2..2\n"
".....4..64..2...54...\n"
".4.5.5...2...6.......\n"
"5.13.3...3.5.3.....1.\n"
"..64.1...6.32356236..\n"
"6.....44....6411.262.\n"
"..24....451..2.4.1.4.\n"
"34...35.......4..2213\n"
".5..636..4......6....\n"
"436.33..252...5....15\n") == 0);
free(board782703672);
board782703672 = NULL;
assert( gamma_move(board, 4, 21, 15) == 0 );
assert( gamma_move(board, 4, 9, 22) == 1 );
assert( gamma_move(board, 5, 22, 13) == 0 );
assert( gamma_move(board, 6, 1, 19) == 0 );
assert( gamma_move(board, 1, 0, 15) == 1 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 2, 3, 17) == 0 );
assert( gamma_move(board, 3, 18, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 21, 18) == 0 );
assert( gamma_move(board, 4, 9, 18) == 0 );
assert( gamma_move(board, 5, 20, 0) == 0 );
assert( gamma_free_fields(board, 5) == 304 );
assert( gamma_move(board, 6, 20, 20) == 1 );
assert( gamma_move(board, 6, 17, 20) == 1 );
assert( gamma_move(board, 1, 19, 0) == 0 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 4, 13, 0) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 3, 1) == 1 );
assert( gamma_free_fields(board, 6) == 300 );
assert( gamma_move(board, 1, 20, 6) == 1 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_free_fields(board, 2) == 298 );
assert( gamma_move(board, 3, 21, 18) == 0 );
assert( gamma_move(board, 4, 18, 1) == 1 );
assert( gamma_move(board, 5, 11, 7) == 1 );
assert( gamma_move(board, 6, 10, 15) == 1 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_free_fields(board, 1) == 295 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 5, 7, 19) == 1 );
assert( gamma_move(board, 5, 20, 18) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 5, 17) == 0 );
assert( gamma_move(board, 6, 10, 19) == 1 );
assert( gamma_move(board, 6, 6, 17) == 1 );
assert( gamma_move(board, 1, 6, 15) == 1 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_free_fields(board, 1) == 289 );
assert( gamma_move(board, 2, 19, 13) == 1 );
assert( gamma_move(board, 3, 22, 14) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 5, 0, 20) == 1 );
assert( gamma_move(board, 6, 19, 14) == 0 );
assert( gamma_move(board, 1, 10, 7) == 1 );
assert( gamma_move(board, 1, 5, 5) == 0 );


char* board687211702 = gamma_board(board);
assert( board687211702 != NULL );
assert( strcmp(board687211702, 
"433.3..4.41....55.1..\n"
"..1.......5..........\n"
"51......4..4.3.5.6.56\n"
".2.....54.66...6..2..\n"
"13.3..2..46..2..15..5\n"
"6.125.6....6....5...1\n"
"..343.5.11.3.21..43..\n"
"12..6.1.5.6..61......\n"
".3.4...5..633.5...362\n"
".3....2..2.......4.2.\n"
"...6.24......3.4..2.3\n"
"....55..2.4.14..4153.\n"
"1.....1.2..11...2...3\n"
"3..5.14......3.6.2..2\n"
"1....4..64..2...54...\n"
".415.5...215.6.......\n"
"5.13.3...3.5.3.....11\n"
"..64.1...6.32356236..\n"
"6.....44....6411.262.\n"
"..241...451..2.4.1.4.\n"
"34...35.......4..2213\n"
".5.6636..4......6.4..\n"
"436.33..252..45....15\n") == 0);
free(board687211702);
board687211702 = NULL;
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 18, 15) == 1 );
assert( gamma_move(board, 3, 18, 17) == 1 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 5, 14, 13) == 1 );
assert( gamma_move(board, 5, 14, 15) == 0 );
assert( gamma_move(board, 6, 12, 0) == 1 );
assert( gamma_move(board, 6, 17, 22) == 1 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_free_fields(board, 1) == 278 );
assert( gamma_move(board, 2, 7, 11) == 1 );


char* board551118707 = gamma_board(board);
assert( board551118707 != NULL );
assert( strcmp(board551118707, 
"433.3..4.41....5561..\n"
"..1.......5..........\n"
"51......4..4.3.5.6.56\n"
".2.....54.66...6..2..\n"
"13.3..2..46..2..15..5\n"
"6.125.6....6....5.3.1\n"
"..343.5.11.3.21..43..\n"
"12..6.1.5.6..61...3..\n"
".3.4...5..633.5...362\n"
".3....2..2....5..4.2.\n"
"...6.24......3.4..2.3\n"
"..2.55.22.4.14..4153.\n"
"1.....1.2..11...2...3\n"
"3..5.14......3.6.2..2\n"
"1....4..64..2...54...\n"
".415.5...215.6.......\n"
"5.13.3...3.5.3.....11\n"
"..64.1...6.32356236..\n"
"6.....44....6411.262.\n"
"..241...451..2.4.1.4.\n"
"34...352......4..2213\n"
".5.6636.14......6.4..\n"
"436.33..252.645....15\n") == 0);
free(board551118707);
board551118707 = NULL;
assert( gamma_move(board, 3, 15, 21) == 1 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 5, 10, 2) == 1 );
assert( gamma_move(board, 5, 7, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 35 );
assert( gamma_move(board, 6, 19, 4) == 0 );
assert( gamma_move(board, 1, 7, 22) == 0 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 3, 7, 18) == 1 );
assert( gamma_move(board, 3, 16, 7) == 1 );
assert( gamma_move(board, 4, 21, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 35 );
assert( gamma_move(board, 5, 17, 1) == 1 );


char* board404589996 = gamma_board(board);
assert( board404589996 != NULL );
assert( strcmp(board404589996, 
"433.3..4.41....5561..\n"
"..1.......5....3.....\n"
"51......4..4.3.5.6.56\n"
".2.....54.66...6..2..\n"
"13.3..23.46..2..15..5\n"
"6.125.6....6....5.3.1\n"
"..343.5.11.3.21..43..\n"
"12..6.1.5.6..61...3..\n"
".3.4...5..633.5...362\n"
".3....2..2....5..4.2.\n"
"...6.24......3.4..2.3\n"
"..2.55.22.4.14..4153.\n"
"1.....1.2..11...2...3\n"
"3..5.14......3.6.2..2\n"
"1....4.564..2...54...\n"
".415.5...215.6..3....\n"
"5.13.3...3.5.3.....11\n"
"..64.1...6.32356236..\n"
"6.....44....6411.262.\n"
"..241...451..2.4.1.4.\n"
"34...352..5...4..2213\n"
".5.6636.14.2....654..\n"
"436.33..252.645....15\n") == 0);
free(board404589996);
board404589996 = NULL;
assert( gamma_move(board, 6, 14, 6) == 1 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 13, 21) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 20, 2) == 0 );
assert( gamma_move(board, 3, 19, 13) == 0 );
assert( gamma_move(board, 6, 15, 12) == 0 );
assert( gamma_move(board, 6, 11, 21) == 1 );
assert( gamma_busy_fields(board, 6) == 34 );
assert( gamma_free_fields(board, 6) == 266 );
assert( gamma_move(board, 1, 18, 8) == 1 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 15, 16) == 1 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_move(board, 4, 10, 18) == 0 );
assert( gamma_move(board, 4, 17, 11) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 17, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 36 );
assert( gamma_move(board, 6, 10, 1) == 1 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 40 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 5, 0, 17) == 0 );
assert( gamma_move(board, 5, 14, 21) == 1 );
assert( gamma_move(board, 6, 4, 8) == 1 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 1, 16, 13) == 1 );
assert( gamma_free_fields(board, 1) == 258 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 2, 15, 18) == 1 );
assert( gamma_move(board, 3, 7, 19) == 0 );


char* board957825537 = gamma_board(board);
assert( board957825537 != NULL );
assert( strcmp(board957825537, 
"433.3..4.41....5561..\n"
"..1.......56.153.....\n"
"51......4..4.3.5.6.56\n"
".2.....54.66...6..2..\n"
"13.3..23.46..2.215..5\n"
"6.125.6....6....5.3.1\n"
"..343.5.11.3.212.43..\n"
"12..6.1.5.6..61...3..\n"
".3.4...5..633.5...362\n"
".3....2..2....5.14.2.\n"
"...6.24......3.4..2.3\n"
"..2.55.22.4.14..4153.\n"
"1.....1.2..11...2...3\n"
"3..5.14......3.6.2..2\n"
"1...64.564..2...541..\n"
".415.5.1.215.6..3....\n"
"5.13.3..13.5.36....11\n"
"..64.1...6.32356236..\n"
"6..2..44....6411.262.\n"
"..241...451..2.4.1.4.\n"
"34...352..5...4..2213\n"
".5.6636.1462....654..\n"
"436.33..252.645....15\n") == 0);
free(board957825537);
board957825537 = NULL;
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 5, 13, 18) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_golden_move(board, 6, 20, 13) == 0 );
assert( gamma_move(board, 1, 16, 4) == 1 );
assert( gamma_move(board, 1, 16, 12) == 1 );
assert( gamma_move(board, 2, 8, 14) == 1 );
assert( gamma_move(board, 3, 6, 17) == 0 );
assert( gamma_move(board, 3, 0, 16) == 1 );
assert( gamma_move(board, 4, 16, 1) == 0 );
assert( gamma_move(board, 6, 4, 5) == 1 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 1, 11, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 15, 16) == 0 );
assert( gamma_move(board, 4, 20, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 3) == 0 );
assert( gamma_move(board, 6, 13, 18) == 0 );
assert( gamma_move(board, 6, 4, 15) == 0 );
assert( gamma_free_fields(board, 6) == 250 );
assert( gamma_move(board, 1, 3, 16) == 0 );
assert( gamma_move(board, 1, 1, 16) == 1 );
assert( gamma_free_fields(board, 1) == 249 );
assert( gamma_move(board, 3, 14, 18) == 1 );
assert( gamma_move(board, 3, 17, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 43 );
assert( gamma_move(board, 4, 19, 20) == 0 );
assert( gamma_move(board, 5, 19, 1) == 1 );
assert( gamma_move(board, 6, 11, 0) == 1 );
assert( gamma_move(board, 6, 2, 3) == 0 );
assert( gamma_move(board, 1, 15, 7) == 1 );
assert( gamma_move(board, 2, 13, 10) == 1 );
assert( gamma_move(board, 2, 19, 8) == 1 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 8, 13) == 1 );
assert( gamma_move(board, 5, 17, 15) == 1 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 6, 6, 18) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 9, 19) == 1 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 4, 6, 6) == 1 );
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_move(board, 5, 18, 18) == 1 );
assert( gamma_move(board, 6, 16, 12) == 0 );
assert( gamma_move(board, 6, 3, 21) == 1 );
assert( gamma_move(board, 1, 10, 17) == 1 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 2, 3, 17) == 0 );
assert( gamma_move(board, 3, 15, 15) == 1 );
assert( gamma_move(board, 3, 15, 15) == 0 );
assert( gamma_move(board, 4, 19, 14) == 0 );
assert( gamma_move(board, 4, 19, 10) == 1 );
assert( gamma_move(board, 5, 14, 5) == 0 );
assert( gamma_move(board, 5, 12, 21) == 1 );
assert( gamma_move(board, 2, 19, 17) == 1 );
assert( gamma_move(board, 2, 17, 22) == 0 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 4, 17, 12) == 1 );
assert( gamma_busy_fields(board, 4) == 40 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_move(board, 6, 9, 19) == 0 );
assert( gamma_move(board, 1, 17, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 42 );
assert( gamma_move(board, 3, 21, 1) == 0 );
assert( gamma_move(board, 3, 2, 22) == 0 );
assert( gamma_move(board, 4, 7, 12) == 1 );
assert( gamma_move(board, 5, 2, 8) == 1 );
assert( gamma_move(board, 5, 6, 17) == 0 );


char* board486533019 = gamma_board(board);
assert( board486533019 != NULL );
assert( strcmp(board486533019, 
"433.3..4.41....5561..\n"
"..16......565153.....\n"
"51......4..4.3.5.6.56\n"
".2.....54166...6..2..\n"
"13.3..23.46..232155.5\n"
"6.125.6...16....5.321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.5.6..613.53..\n"
".3.4...52.633.5...362\n"
".32...2.42.1..5.14.2.\n"
"...6.244.....3.4142.3\n"
"..2.55.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14......3.6.2..2\n"
"1.5.64.564..2...5412.\n"
".415.5.1.215.6.133...\n"
"5.13.34.13.5.36....11\n"
"..6461...6.32356236..\n"
"6..2..44....64111262.\n"
".3241...451..2.4.1.44\n"
"34...352..5...4..2213\n"
".5.6636.1462....6545.\n"
"436.33..2526645....15\n") == 0);
free(board486533019);
board486533019 = NULL;
assert( gamma_move(board, 6, 17, 5) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 1, 4, 14) == 1 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 2, 16, 0) == 1 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 4, 16) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 6, 20, 7) == 1 );
assert( gamma_busy_fields(board, 6) == 40 );
assert( gamma_move(board, 1, 19, 13) == 0 );
assert( gamma_move(board, 1, 9, 15) == 1 );
assert( gamma_move(board, 2, 11, 20) == 0 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 15, 19) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 4, 10, 5) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 5, 2, 21) == 0 );
assert( gamma_move(board, 6, 4, 11) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_golden_move(board, 1, 17, 18) == 1 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 4, 19, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 42 );
assert( gamma_golden_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 5, 2, 12) == 1 );
assert( gamma_move(board, 5, 6, 7) == 1 );
assert( gamma_busy_fields(board, 5) == 43 );
assert( gamma_move(board, 6, 16, 20) == 1 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 2, 6, 18) == 0 );
assert( gamma_move(board, 2, 19, 20) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 3, 17, 18) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 1) == 1 );
assert( gamma_move(board, 4, 1, 8) == 1 );
assert( gamma_move(board, 5, 8, 15) == 0 );
assert( gamma_move(board, 6, 17, 7) == 0 );


char* board756752609 = gamma_board(board);
assert( board756752609 != NULL );
assert( strcmp(board756752609, 
"433.3..4.41....5561..\n"
"..16......565153.....\n"
"51......4..4.3.566.56\n"
".2.....54166...6..2..\n"
"13.3..23.46..232115.5\n"
"6.125.6...16....5.321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.516..613.53..\n"
".3.41..52.633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244.....3.4142.3\n"
"..2.55.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.2....3.6.2..2\n"
"145.64.564..2...5412.\n"
".415.551.215.6.133..6\n"
"5.13.34.13.5.36....11\n"
"..6461...6432356236..\n"
"6..2..44....64111262.\n"
".3241...451..2.4.1.44\n"
"343..352..5...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board756752609);
board756752609 = NULL;
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 1, 2, 14) == 1 );
assert( gamma_move(board, 2, 17, 9) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 3, 7, 19) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 5, 14, 13) == 0 );
assert( gamma_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 6, 20, 5) == 1 );
assert( gamma_move(board, 6, 8, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 42 );
assert( gamma_move(board, 2, 9, 18) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 18) == 1 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 4, 14, 16) == 0 );
assert( gamma_free_fields(board, 4) == 209 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 5, 4, 11) == 0 );
assert( gamma_move(board, 6, 3, 11) == 1 );
assert( gamma_move(board, 6, 7, 17) == 1 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_move(board, 1, 18, 9) == 1 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_golden_move(board, 2, 1, 19) == 0 );
assert( gamma_move(board, 3, 7, 18) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 15, 22) == 0 );
assert( gamma_move(board, 4, 19, 3) == 0 );
assert( gamma_move(board, 5, 13, 10) == 0 );
assert( gamma_move(board, 6, 18, 14) == 0 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 55 );
assert( gamma_move(board, 2, 17, 17) == 1 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_move(board, 3, 15, 8) == 1 );
assert( gamma_move(board, 3, 5, 9) == 0 );


char* board934377303 = gamma_board(board);
assert( board934377303 != NULL );
assert( strcmp(board934377303, 
"433.3..4.41....5561..\n"
"..16......565153.....\n"
"51......4..4.3.566.56\n"
".2.....54166...6..2..\n"
"13.3..23.463.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.516..613.53..\n"
".3141..52.633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244.....3.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.22.3.3.6.21.2\n"
"145.64.564..2..35412.\n"
".415.551.215.6.133..6\n"
"5.13.34.13.5.36....11\n"
"..6461...6432356236.6\n"
"6..2..44....64111262.\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board934377303);
board934377303 = NULL;
assert( gamma_move(board, 4, 8, 20) == 0 );


char* board385497158 = gamma_board(board);
assert( board385497158 != NULL );
assert( strcmp(board385497158, 
"433.3..4.41....5561..\n"
"..16......565153.....\n"
"51......4..4.3.566.56\n"
".2.....54166...6..2..\n"
"13.3..23.463.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.516..613.53..\n"
".3141..52.633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244.....3.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.22.3.3.6.21.2\n"
"145.64.564..2..35412.\n"
".415.551.215.6.133..6\n"
"5.13.34.13.5.36....11\n"
"..6461...6432356236.6\n"
"6..2..44....64111262.\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board385497158);
board385497158 = NULL;
assert( gamma_move(board, 5, 9, 14) == 1 );
assert( gamma_move(board, 6, 17, 15) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 1, 15, 20) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 11, 21) == 0 );
assert( gamma_move(board, 3, 22, 5) == 0 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 4, 15, 15) == 0 );
assert( gamma_move(board, 5, 17, 8) == 0 );
assert( gamma_move(board, 5, 18, 22) == 0 );
assert( gamma_move(board, 6, 10, 17) == 0 );
assert( gamma_move(board, 6, 1, 6) == 1 );
assert( gamma_move(board, 1, 18, 11) == 0 );
assert( gamma_move(board, 2, 22, 12) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 19, 19) == 1 );
assert( gamma_move(board, 5, 4, 6) == 1 );


char* board458522663 = gamma_board(board);
assert( board458522663 != NULL );
assert( strcmp(board458522663, 
"433.3..4.41....5561..\n"
"..16......565153.....\n"
"51......4..4.3.566.56\n"
".2.....54166...6..24.\n"
"13.3..23.463.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.516..613.53..\n"
".3141..525633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244.....3.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.22.3.3.6.21.2\n"
"145.64.564..2..35412.\n"
".415.551.215.6.133..6\n"
"5613534.13.5.36....11\n"
"..6461...6432356236.6\n"
"6..2..44....64111262.\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board458522663);
board458522663 = NULL;
assert( gamma_move(board, 6, 9, 16) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 16, 10) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 12, 12) == 1 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 45 );
assert( gamma_move(board, 5, 13, 20) == 0 );


char* board782857140 = gamma_board(board);
assert( board782857140 != NULL );
assert( strcmp(board782857140, 
"433.3..4.41....5561..\n"
"..16......565153.....\n"
"51......4..4.3.566.56\n"
".2.....54166...6..24.\n"
"13.3..23.463.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.516..613.53..\n"
".3141..525633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244....33.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.22.3.3.6.21.2\n"
"145.64.564..2..35412.\n"
".415.551.215.6.133..6\n"
"5613534.13.5.36....11\n"
"..6461...6432356236.6\n"
"6..2..44....64111262.\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board782857140);
board782857140 = NULL;
assert( gamma_move(board, 6, 0, 3) == 0 );
assert( gamma_move(board, 1, 21, 16) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 18, 9) == 0 );
assert( gamma_move(board, 3, 12, 19) == 1 );


char* board222064353 = gamma_board(board);
assert( board222064353 != NULL );
assert( strcmp(board222064353, 
"433.3..4.41....5561..\n"
"..16......565153.....\n"
"51......4..4.3.566.56\n"
".2.....541663..6..24.\n"
"13.3..23.463.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.516..613.53..\n"
".3141..525633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244....33.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.22.3.3.6.21.2\n"
"145.64.564..2..35412.\n"
".415.551.215.6.133..6\n"
"5613534.13.5.36....11\n"
"..6461...6432356236.6\n"
"6..2..44....64111262.\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board222064353);
board222064353 = NULL;
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_move(board, 4, 8, 22) == 1 );
assert( gamma_busy_fields(board, 4) == 46 );
assert( gamma_golden_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 5, 22, 3) == 0 );


char* board571451577 = gamma_board(board);
assert( board571451577 != NULL );
assert( strcmp(board571451577, 
"433.3..4441....5561..\n"
"..16......565153.....\n"
"51......4..4.3.566.56\n"
".2.....541663..6..24.\n"
"13.3..23.463.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.516..613.53..\n"
".3141..525633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244....33.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.22.3.3.6.21.2\n"
"145.64.564..2..35412.\n"
".415.551.215.6.133..6\n"
"5613534.13.5.36....11\n"
"..6461...6432356236.6\n"
"6..2..44....64111262.\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board571451577);
board571451577 = NULL;
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 1, 20, 4) == 1 );
assert( gamma_move(board, 2, 17, 12) == 0 );


char* board866781569 = gamma_board(board);
assert( board866781569 != NULL );
assert( strcmp(board866781569, 
"433.3..4441....5561..\n"
"..16......565153.....\n"
"51......4..4.3.566.56\n"
".2.....541663..6..24.\n"
"13.3..23.463.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"12..6.1.516..613.53..\n"
".3141..525633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244....33.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.22.3.3.6.21.2\n"
"145.64.564..2..35412.\n"
".415.551.215.6.133..6\n"
"5613534.13.5.36....11\n"
"..6461...6432356236.6\n"
"6..2..44....641112621\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board866781569);
board866781569 = NULL;
assert( gamma_move(board, 4, 15, 19) == 0 );
assert( gamma_move(board, 5, 18, 19) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 48 );
assert( gamma_move(board, 3, 20, 14) == 0 );
assert( gamma_move(board, 3, 19, 15) == 1 );
assert( gamma_move(board, 4, 2, 15) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 5, 8, 21) == 1 );
assert( gamma_move(board, 5, 20, 2) == 0 );
assert( gamma_move(board, 6, 6, 17) == 0 );
assert( gamma_free_fields(board, 6) == 189 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 48 );
assert( gamma_free_fields(board, 2) == 189 );
assert( gamma_move(board, 3, 1, 18) == 0 );
assert( gamma_move(board, 4, 20, 12) == 0 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_move(board, 5, 6, 17) == 0 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 6, 18, 22) == 0 );
assert( gamma_move(board, 1, 21, 4) == 0 );
assert( gamma_move(board, 1, 17, 20) == 0 );
assert( gamma_move(board, 2, 20, 10) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_free_fields(board, 5) == 189 );
assert( gamma_move(board, 6, 10, 8) == 1 );
assert( gamma_move(board, 6, 5, 6) == 0 );


char* board782108644 = gamma_board(board);
assert( board782108644 != NULL );
assert( strcmp(board782108644, 
"433.3..4441....5561..\n"
"..16....5.565153.....\n"
"51......4..4.3.566.56\n"
".2.....541663..6..24.\n"
"13.3..23.463.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244....33.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.22.3.3.6.21.2\n"
"145.64.5646.2..35412.\n"
".415.551.215.6.133..6\n"
"5613534.13.5.36....11\n"
".26461...6432356236.6\n"
"6..2..44....641112621\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board782108644);
board782108644 = NULL;
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_free_fields(board, 4) == 187 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_golden_move(board, 5, 9, 18) == 1 );


char* board376069152 = gamma_board(board);
assert( board376069152 != NULL );
assert( strcmp(board376069152, 
"433.3..4441....5561..\n"
"..16....5.565153.....\n"
"51......4..4.3.566.56\n"
".2.....541663..6..24.\n"
"13.3..23.563.232115.5\n"
"6.125.66..16....52321\n"
"31343.5.11.3.212.43..\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1..5.14.2.\n"
"..56.244....33.4142.3\n"
"..2655.22.4.14..4153.\n"
"1.....1.2..112..2..43\n"
"3..5.14.2233.3.6.21.2\n"
"145.64.5646.2..35412.\n"
".415.551.215.6.133..6\n"
"5613534.13.5.36....11\n"
".26461...6432356236.6\n"
"6..2..44....641112621\n"
"13241.1.451..2.4.1.44\n"
"343..352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2..15\n") == 0);
free(board376069152);
board376069152 = NULL;
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 46 );
assert( gamma_move(board, 1, 9, 19) == 0 );
assert( gamma_free_fields(board, 1) == 187 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_free_fields(board, 4) == 186 );
assert( gamma_move(board, 5, 6, 11) == 1 );
assert( gamma_move(board, 6, 22, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 46 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_free_fields(board, 2) == 185 );
assert( gamma_move(board, 3, 21, 16) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 22, 3) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 6, 20, 18) == 0 );
assert( gamma_move(board, 2, 17, 12) == 0 );
assert( gamma_move(board, 3, 1, 22) == 0 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_golden_move(board, 3, 9, 3) == 1 );
assert( gamma_move(board, 4, 7, 3) == 1 );
assert( gamma_move(board, 4, 15, 18) == 0 );
assert( gamma_move(board, 6, 0, 3) == 0 );
assert( gamma_move(board, 6, 18, 17) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 14, 1) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 1, 18, 10) == 1 );
assert( gamma_free_fields(board, 1) == 182 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 3, 14, 16) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_free_fields(board, 4) == 182 );
assert( gamma_move(board, 5, 21, 20) == 0 );
assert( gamma_move(board, 6, 20, 16) == 1 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 17, 12) == 0 );
assert( gamma_free_fields(board, 4) == 181 );
assert( gamma_move(board, 5, 5, 3) == 1 );
assert( gamma_move(board, 6, 15, 16) == 0 );
assert( gamma_free_fields(board, 6) == 180 );
assert( gamma_move(board, 1, 18, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 15, 6) == 1 );
assert( gamma_move(board, 6, 21, 19) == 0 );
assert( gamma_busy_fields(board, 6) == 47 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 2, 21, 0) == 0 );
assert( gamma_free_fields(board, 2) == 177 );
assert( gamma_move(board, 3, 10, 14) == 0 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 4, 19, 2) == 0 );
assert( gamma_move(board, 5, 14, 19) == 1 );
assert( gamma_free_fields(board, 5) == 175 );
assert( gamma_move(board, 6, 3, 18) == 0 );
assert( gamma_move(board, 1, 20, 6) == 0 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_golden_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 5, 19, 16) == 1 );
assert( gamma_busy_fields(board, 5) == 51 );
assert( gamma_move(board, 6, 9, 2) == 0 );
assert( gamma_move(board, 1, 14, 14) == 0 );
assert( gamma_free_fields(board, 1) == 174 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 17) == 1 );
assert( gamma_move(board, 2, 15, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 51 );
assert( gamma_move(board, 3, 19, 16) == 0 );
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_move(board, 5, 13, 13) == 1 );
assert( gamma_move(board, 5, 10, 20) == 1 );
assert( gamma_busy_fields(board, 5) == 53 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_move(board, 6, 18, 17) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 22, 14) == 0 );
assert( gamma_move(board, 4, 19, 16) == 0 );
assert( gamma_move(board, 5, 19, 20) == 0 );


char* board428489982 = gamma_board(board);
assert( board428489982 != NULL );
assert( strcmp(board428489982, 
"433.3..4441....5561..\n"
"..16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3..23.563.232115.5\n"
"6.125.66.216....52321\n"
"31343.5.11.3.212.4356\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1.55.14.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2..112..2.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.64.564632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.365...11\n"
".26461..36432356236.6\n"
"6..2..44....641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2.115\n") == 0);
free(board428489982);
board428489982 = NULL;
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_free_fields(board, 6) == 169 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_golden_move(board, 1, 11, 16) == 0 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_free_fields(board, 2) == 169 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_free_fields(board, 3) == 169 );
assert( gamma_move(board, 5, 9, 4) == 1 );
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_golden_move(board, 5, 3, 15) == 0 );
assert( gamma_move(board, 6, 2, 16) == 0 );
assert( gamma_move(board, 1, 20, 4) == 0 );
assert( gamma_free_fields(board, 1) == 168 );
assert( gamma_move(board, 2, 17, 12) == 0 );
assert( gamma_free_fields(board, 2) == 168 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 3, 17, 20) == 0 );
assert( gamma_move(board, 4, 8, 11) == 0 );
assert( gamma_move(board, 5, 20, 9) == 0 );
assert( gamma_move(board, 5, 17, 16) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_golden_move(board, 5, 15, 13) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 6, 13, 10) == 0 );
assert( gamma_free_fields(board, 6) == 168 );
assert( gamma_move(board, 1, 19, 0) == 0 );
assert( gamma_move(board, 1, 16, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_move(board, 1, 20, 20) == 0 );
assert( gamma_move(board, 2, 18, 12) == 0 );
assert( gamma_move(board, 2, 19, 10) == 0 );
assert( gamma_move(board, 3, 19, 16) == 0 );
assert( gamma_free_fields(board, 3) == 168 );
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 5, 15, 16) == 0 );
assert( gamma_move(board, 5, 9, 22) == 0 );
assert( gamma_move(board, 6, 16, 1) == 0 );
assert( gamma_move(board, 6, 1, 17) == 1 );
assert( gamma_move(board, 2, 17, 13) == 0 );


char* board852656520 = gamma_board(board);
assert( board852656520 != NULL );
assert( strcmp(board852656520, 
"433.3..4441....5561..\n"
"..16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3..23.563.232115.5\n"
"66125.66.216....52321\n"
"31343.5.11.3.212.4356\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1.55.14.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2..112..2.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.64.564632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.365...11\n"
".26461..36432356236.6\n"
"6..2..44.5..641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2.115\n") == 0);
free(board852656520);
board852656520 = NULL;
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_move(board, 4, 14, 19) == 0 );
assert( gamma_free_fields(board, 4) == 167 );
assert( gamma_golden_move(board, 4, 5, 13) == 0 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 5, 15, 10) == 1 );


char* board689261025 = gamma_board(board);
assert( board689261025 != NULL );
assert( strcmp(board689261025, 
"433.3..4441....5561..\n"
"..16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3..23.563.232115.5\n"
"66125.66.216....52321\n"
"31343.5.11.3.212.4356\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1.55.14.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2..112.52.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.64.564632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.365...11\n"
".26461..36432356236.6\n"
"6..2..44.5..641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2.115\n") == 0);
free(board689261025);
board689261025 = NULL;
assert( gamma_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 1, 13, 13) == 0 );
assert( gamma_move(board, 1, 20, 3) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_move(board, 3, 20, 7) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_free_fields(board, 4) == 166 );
assert( gamma_move(board, 5, 19, 13) == 0 );
assert( gamma_move(board, 6, 21, 0) == 0 );
assert( gamma_move(board, 6, 0, 16) == 0 );
assert( gamma_free_fields(board, 6) == 166 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_free_fields(board, 1) == 166 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 4, 13, 21) == 0 );
assert( gamma_move(board, 4, 10, 19) == 0 );
assert( gamma_move(board, 6, 20, 12) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 1, 18, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 20, 10) == 0 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_busy_fields(board, 4) == 47 );
assert( gamma_move(board, 5, 17, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 48 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 10, 17) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );


char* board911215051 = gamma_board(board);
assert( board911215051 != NULL );
assert( strcmp(board911215051, 
"433.3..4441....5561..\n"
"..16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3..23.563.232115.5\n"
"66125.66.216....52321\n"
"31343.5.11.3.212.4356\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1.55.14.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2..112.52.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.64.564632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.365...11\n"
".26461..36432356236.6\n"
"6..2..44.52.641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...6545.\n"
"436.33..2526645.2.115\n") == 0);
free(board911215051);
board911215051 = NULL;
assert( gamma_move(board, 5, 8, 20) == 0 );
assert( gamma_move(board, 6, 19, 18) == 1 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 3, 13, 22) == 1 );
assert( gamma_free_fields(board, 3) == 163 );
assert( gamma_move(board, 4, 16, 6) == 1 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_move(board, 5, 21, 20) == 0 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 6, 19, 13) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 10, 22) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 21, 17) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 49 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_move(board, 6, 8, 15) == 0 );
assert( gamma_move(board, 1, 20, 14) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_move(board, 4, 21, 7) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_golden_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 5, 3, 11) == 0 );
assert( gamma_move(board, 5, 17, 18) == 0 );
assert( gamma_golden_move(board, 5, 22, 18) == 0 );
assert( gamma_move(board, 6, 20, 3) == 0 );
assert( gamma_move(board, 6, 15, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 1, 20, 1) == 1 );
assert( gamma_free_fields(board, 1) == 160 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 6, 18, 4) == 0 );
assert( gamma_move(board, 6, 15, 18) == 0 );
assert( gamma_move(board, 1, 1, 22) == 0 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 3, 19, 16) == 0 );
assert( gamma_move(board, 3, 3, 21) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 15, 12) == 0 );
assert( gamma_move(board, 5, 20, 10) == 0 );


char* board361855287 = gamma_board(board);
assert( board361855287 != NULL );
assert( strcmp(board361855287, 
"433.3..4441..3.5561..\n"
"..16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3..23.563.23211565\n"
"66125.66.216....52321\n"
"31343.5.11.3.212.4356\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1.55.14.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2..112.52.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.642544632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.3654..11\n"
".26461..36432356236.6\n"
"6..2..44.52.641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...65451\n"
"436433..2526645.2.115\n") == 0);
free(board361855287);
board361855287 = NULL;
assert( gamma_move(board, 6, 14, 15) == 0 );
assert( gamma_move(board, 6, 6, 16) == 0 );
assert( gamma_busy_fields(board, 6) == 48 );
assert( gamma_move(board, 1, 21, 9) == 0 );
assert( gamma_move(board, 1, 1, 20) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 20, 5) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 50 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_golden_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 6, 19, 1) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 3, 17, 3) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 58 );
assert( gamma_free_fields(board, 3) == 159 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_move(board, 5, 22, 20) == 0 );
assert( gamma_move(board, 5, 8, 22) == 0 );
assert( gamma_busy_fields(board, 5) == 55 );
assert( gamma_free_fields(board, 5) == 159 );
assert( gamma_move(board, 6, 20, 6) == 0 );
assert( gamma_move(board, 6, 20, 10) == 0 );


char* board350982768 = gamma_board(board);
assert( board350982768 != NULL );
assert( strcmp(board350982768, 
"433.3..4441..3.5561..\n"
"..16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3..23.563.23211565\n"
"66125.66.216....52321\n"
"31343.5.11.3.212.4356\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1.55.14.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2..112.52.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.642544632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.3654..11\n"
".26461..36432356236.6\n"
"6..2..44.52.641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...65451\n"
"436433..2526645.2.115\n") == 0);
free(board350982768);
board350982768 = NULL;
assert( gamma_move(board, 1, 20, 3) == 0 );
assert( gamma_move(board, 1, 19, 5) == 1 );
assert( gamma_move(board, 3, 17, 20) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );


char* board946801882 = gamma_board(board);
assert( board946801882 != NULL );
assert( strcmp(board946801882, 
"433.3..4441..3.5561..\n"
"..16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3..23.563.23211565\n"
"66125.66.216....52321\n"
"31343.5.11.3.212.4356\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1.55.14.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2..112.52.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.642544632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"6..2..44.52.641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...65451\n"
"436433..2526645.2.115\n") == 0);
free(board946801882);
board946801882 = NULL;
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_move(board, 5, 20, 9) == 0 );
assert( gamma_move(board, 1, 11, 20) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_move(board, 3, 20, 4) == 0 );
assert( gamma_move(board, 3, 13, 17) == 1 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 50 );


char* board897282317 = gamma_board(board);
assert( board897282317 != NULL );
assert( strcmp(board897282317, 
"433.3..4441..3.5561..\n"
"..16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3..23.563.23211565\n"
"66125.66.216.3..52321\n"
"31343.5.11.3.212.4356\n"
"124.6.1.516..613.533.\n"
".3141..525633.5...362\n"
".32...2.42.1.55.14.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2.2112.52.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.642544632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"6..2..44.52.641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...65451\n"
"436433..2526645.2.115\n") == 0);
free(board897282317);
board897282317 = NULL;
assert( gamma_move(board, 5, 8, 19) == 0 );
assert( gamma_move(board, 5, 19, 20) == 0 );
assert( gamma_move(board, 6, 8, 14) == 0 );
assert( gamma_move(board, 6, 9, 11) == 0 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 1, 15, 16) == 0 );
assert( gamma_free_fields(board, 1) == 156 );
assert( gamma_move(board, 2, 18, 4) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 4, 17, 3) == 0 );
assert( gamma_move(board, 5, 18, 5) == 0 );
assert( gamma_move(board, 5, 5, 18) == 1 );
assert( gamma_busy_fields(board, 5) == 56 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 20, 9) == 0 );
assert( gamma_move(board, 6, 19, 13) == 0 );
assert( gamma_move(board, 1, 18, 12) == 0 );
assert( gamma_move(board, 1, 12, 15) == 1 );
assert( gamma_busy_fields(board, 1) == 62 );
assert( gamma_golden_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 17, 14) == 1 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 12, 16) == 1 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_move(board, 5, 15, 13) == 1 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 22, 14) == 0 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 4, 0, 21) == 1 );
assert( gamma_move(board, 5, 6, 10) == 0 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_move(board, 6, 10, 22) == 0 );
assert( gamma_move(board, 1, 15, 15) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_free_fields(board, 3) == 150 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 4, 17, 7) == 0 );
assert( gamma_move(board, 5, 12, 11) == 0 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_golden_move(board, 6, 9, 8) == 1 );


char* board253279425 = gamma_board(board);
assert( board253279425 != NULL );
assert( strcmp(board253279425, 
"433.3..4441..3.5561..\n"
"4.16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.3..52321\n"
"31343.5.11.33212.4356\n"
"124.6.1.516.1613.533.\n"
".3141..525633.5..2362\n"
".32...2.42.1.55514.2.\n"
"..56.244....33.4142.3\n"
"..265552234.14.24153.\n"
"1.....1.2.2112.52.143\n"
"3..5.14.2233.3.6.21.2\n"
"145.642546632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"6..2..44.52.641112621\n"
"13241514431..2.4.1.44\n"
"343.2352.25...4..2213\n"
".5.6636.14624...65451\n"
"436433..2526645.2.115\n") == 0);
free(board253279425);
board253279425 = NULL;
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 19, 17) == 0 );
assert( gamma_move(board, 3, 6, 18) == 0 );
assert( gamma_move(board, 4, 1, 20) == 0 );
assert( gamma_move(board, 4, 17, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 51 );
assert( gamma_golden_move(board, 4, 21, 11) == 0 );
assert( gamma_move(board, 5, 18, 12) == 0 );
assert( gamma_move(board, 5, 8, 12) == 1 );
assert( gamma_free_fields(board, 5) == 148 );
assert( gamma_move(board, 6, 3, 14) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 5, 16) == 1 );
assert( gamma_move(board, 3, 19, 18) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 6, 22, 19) == 0 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 1, 20, 4) == 0 );
assert( gamma_free_fields(board, 1) == 146 );
assert( gamma_move(board, 2, 9, 16) == 0 );
assert( gamma_free_fields(board, 2) == 146 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 62 );
assert( gamma_move(board, 4, 6, 17) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 20, 14) == 0 );
assert( gamma_move(board, 5, 11, 4) == 1 );
assert( gamma_move(board, 6, 19, 20) == 0 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_free_fields(board, 6) == 144 );
assert( gamma_move(board, 1, 14, 15) == 0 );
assert( gamma_move(board, 1, 11, 16) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 4, 18, 2) == 0 );
assert( gamma_move(board, 5, 11, 11) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 2, 16) == 0 );
assert( gamma_move(board, 6, 8, 22) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 17, 8) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 11, 22) == 1 );
assert( gamma_move(board, 3, 22, 20) == 0 );
assert( gamma_free_fields(board, 3) == 141 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 5, 6, 17) == 0 );
assert( gamma_move(board, 6, 14, 0) == 0 );
assert( gamma_move(board, 6, 4, 9) == 1 );
assert( gamma_move(board, 1, 7, 19) == 0 );
assert( gamma_move(board, 2, 7, 19) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );


char* board695523860 = gamma_board(board);
assert( board695523860 != NULL );
assert( strcmp(board695523860, 
"433.3..44412.3.5561..\n"
"4.16....5.565153.....\n"
"51......4.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.3..52321\n"
"3134335.11.33212.4356\n"
"124.6.1.516.1613.533.\n"
".3141..525633.5..2362\n"
".32...2.42.1.55514.2.\n"
"..56.2445...33.4142.3\n"
"..265552234514.24153.\n"
"1.....112.2112.52.143\n"
"3..5614.2233.3.6.21.2\n"
"145.642546632..35412.\n"
".415.551.215.6.133..6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"6..2..44.525641112621\n"
"13241514431..2.4.1.44\n"
"343.2352325.3.4..2213\n"
".5.6636.14624...65451\n"
"436433..2526645.24115\n") == 0);
free(board695523860);
board695523860 = NULL;
assert( gamma_move(board, 4, 1, 1) == 0 );
assert( gamma_move(board, 4, 16, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 51 );
assert( gamma_move(board, 5, 12, 9) == 1 );
assert( gamma_move(board, 6, 4, 4) == 1 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_golden_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 14, 11) == 1 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_free_fields(board, 5) == 137 );
assert( gamma_move(board, 6, 3, 16) == 0 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_move(board, 2, 22, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 16) == 0 );
assert( gamma_move(board, 5, 12, 10) == 0 );
assert( gamma_move(board, 5, 18, 7) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_free_fields(board, 1) == 136 );
assert( gamma_move(board, 2, 7, 20) == 1 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 14, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 15, 0) == 1 );
assert( gamma_move(board, 5, 22, 5) == 0 );
assert( gamma_move(board, 6, 14, 6) == 0 );
assert( gamma_move(board, 6, 11, 5) == 0 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_move(board, 4, 12, 15) == 0 );
assert( gamma_move(board, 4, 17, 20) == 0 );
assert( gamma_golden_move(board, 4, 16, 8) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 6, 11, 9) == 0 );
assert( gamma_move(board, 6, 4, 20) == 1 );
assert( gamma_move(board, 1, 3, 16) == 0 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 2, 21, 5) == 0 );
assert( gamma_move(board, 2, 8, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 19, 2) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 4, 17, 8) == 0 );
assert( gamma_golden_move(board, 4, 17, 11) == 0 );
assert( gamma_move(board, 5, 16, 17) == 0 );
assert( gamma_move(board, 6, 21, 5) == 0 );
assert( gamma_move(board, 6, 19, 5) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 14, 13) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 12, 21) == 0 );
assert( gamma_golden_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 18, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 64 );


char* board367838415 = gamma_board(board);
assert( board367838415 != NULL );
assert( strcmp(board367838415, 
"433.3..44412.3.5561..\n"
"4.16....5.565153.....\n"
"51..6..24.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.3..52321\n"
"3134335.11.33212.4356\n"
"124.6.1.516.1613.533.\n"
".3141..525633.5..2362\n"
".32...2.42.1.55514.2.\n"
"..56.2445...33.4142.3\n"
"..265552234514424153.\n"
"1.6...112.2112.52.143\n"
"3..5614.223353.6.21.2\n"
"145.642526632..35412.\n"
".415.551.215.6.1335.6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"62.26.44.525641112621\n"
"13241514431..2.4.1.44\n"
"343.235232513.4..2213\n"
".5.6636.14624.3.65451\n"
"436433..2526645424115\n") == 0);
free(board367838415);
board367838415 = NULL;
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 14, 16) == 0 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 6, 22, 12) == 0 );
assert( gamma_move(board, 6, 19, 12) == 1 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 17, 18) == 0 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_move(board, 3, 6, 17) == 0 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 5, 10, 17) == 0 );
assert( gamma_move(board, 5, 7, 16) == 1 );
assert( gamma_move(board, 6, 14, 15) == 0 );
assert( gamma_move(board, 6, 4, 4) == 0 );
assert( gamma_move(board, 1, 19, 16) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 16, 2) == 1 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_free_fields(board, 2) == 126 );
assert( gamma_move(board, 3, 4, 22) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 21, 9) == 0 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_move(board, 6, 14, 15) == 0 );
assert( gamma_move(board, 6, 17, 10) == 1 );
assert( gamma_free_fields(board, 6) == 125 );
assert( gamma_move(board, 1, 14, 10) == 1 );


char* board936639638 = gamma_board(board);
assert( board936639638 != NULL );
assert( strcmp(board936639638, 
"433.3..44412.3.5561..\n"
"4.16....5.565153.....\n"
"51..6..24.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.3..52321\n"
"3134335511.33212.4356\n"
"124.6.1.516.1613.533.\n"
".3141..525633.5..2362\n"
".32...2.42.1.55514.2.\n"
"..56.2445...33.414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6.21.2\n"
"145.642526632..35412.\n"
".415.551.215.6.1335.6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"62.26.44.525641112621\n"
"13241514431..2.4.1.44\n"
"343.235232513.4.22213\n"
".5.6636.14624.3.65451\n"
"436433..2526645424115\n") == 0);
free(board936639638);
board936639638 = NULL;


char* board170291623 = gamma_board(board);
assert( board170291623 != NULL );
assert( strcmp(board170291623, 
"433.3..44412.3.5561..\n"
"4.16....5.565153.....\n"
"51..6..24.54.3.566.56\n"
".2.....541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.3..52321\n"
"3134335511.33212.4356\n"
"124.6.1.516.1613.533.\n"
".3141..525633.5..2362\n"
".32...2.42.1.55514.2.\n"
"..56.2445...33.414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6.21.2\n"
"145.642526632..35412.\n"
".415.551.215.6.1335.6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"62.26.44.525641112621\n"
"13241514431..2.4.1.44\n"
"343.235232513.4.22213\n"
".5.6636.14624.3.65451\n"
"436433..2526645424115\n") == 0);
free(board170291623);
board170291623 = NULL;
assert( gamma_move(board, 3, 19, 6) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 5, 4) == 1 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 2, 20) == 1 );
assert( gamma_move(board, 6, 21, 16) == 0 );
assert( gamma_move(board, 6, 15, 0) == 0 );
assert( gamma_move(board, 1, 20, 22) == 1 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 2, 14, 22) == 1 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 4, 13, 18) == 0 );
assert( gamma_move(board, 5, 22, 12) == 0 );
assert( gamma_free_fields(board, 5) == 120 );
assert( gamma_move(board, 6, 17, 21) == 1 );
assert( gamma_move(board, 6, 15, 22) == 0 );
assert( gamma_move(board, 1, 5, 21) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 3, 20, 5) == 0 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 17, 12) == 0 );
assert( gamma_golden_move(board, 5, 19, 19) == 0 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 6, 9, 16) == 0 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 15, 20) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 11, 3) == 1 );
assert( gamma_move(board, 5, 5, 19) == 1 );
assert( gamma_move(board, 6, 6, 16) == 0 );
assert( gamma_golden_move(board, 6, 18, 20) == 0 );
assert( gamma_move(board, 1, 14, 15) == 0 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 18, 17) == 0 );
assert( gamma_move(board, 4, 22, 6) == 0 );
assert( gamma_move(board, 4, 2, 2) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 14, 16) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 16, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_move(board, 5, 5, 20) == 1 );
assert( gamma_move(board, 6, 14, 6) == 0 );
assert( gamma_move(board, 6, 15, 13) == 0 );
assert( gamma_move(board, 1, 18, 2) == 0 );
assert( gamma_move(board, 1, 17, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 14) == 1 );
assert( gamma_move(board, 2, 2, 19) == 1 );
assert( gamma_move(board, 3, 7, 19) == 0 );
assert( gamma_move(board, 4, 20, 3) == 0 );
assert( gamma_move(board, 5, 21, 20) == 0 );
assert( gamma_move(board, 6, 14, 0) == 0 );
assert( gamma_move(board, 1, 18, 19) == 0 );
assert( gamma_move(board, 2, 16, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 63 );
assert( gamma_free_fields(board, 2) == 113 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 5, 21, 7) == 0 );
assert( gamma_move(board, 6, 14, 15) == 0 );
assert( gamma_move(board, 3, 16, 9) == 1 );
assert( gamma_move(board, 4, 18, 2) == 0 );
assert( gamma_move(board, 4, 17, 5) == 0 );
assert( gamma_move(board, 5, 21, 4) == 0 );
assert( gamma_move(board, 5, 9, 16) == 0 );
assert( gamma_busy_fields(board, 6) == 56 );
assert( gamma_move(board, 1, 14, 17) == 1 );
assert( gamma_move(board, 2, 17, 15) == 0 );
assert( gamma_move(board, 3, 9, 19) == 0 );


char* board648290831 = gamma_board(board);
assert( board648290831 != NULL );
assert( strcmp(board648290831, 
"433.3..44412.325561.1\n"
"4.16.1..5.565153.6...\n"
"515.65.24.54.3.566.56\n"
".22..5.541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.31.52321\n"
"3134335511.33212.4356\n"
"124.6.1.516.1613.533.\n"
".31412.525633.5..2362\n"
".32...2.42.1.55514.2.\n"
"..56.2445...33.414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..35412.\n"
".415.551.215.6.1335.6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"62.26444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4.22213\n"
".5.6636.14624.3.65451\n"
"436433..2526645424115\n") == 0);
free(board648290831);
board648290831 = NULL;
assert( gamma_move(board, 4, 17, 5) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 5, 10, 17) == 0 );
assert( gamma_move(board, 6, 20, 8) == 1 );
assert( gamma_move(board, 1, 4, 21) == 1 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 3, 15, 17) == 1 );
assert( gamma_golden_move(board, 3, 11, 15) == 0 );


char* board852760722 = gamma_board(board);
assert( board852760722 != NULL );
assert( strcmp(board852760722, 
"433.3..44412.325561.1\n"
"4.1611..5.565153.6...\n"
"515.65.24.54.3.566.56\n"
".22..5.541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.31352321\n"
"3134335511.33212.4356\n"
"124.6.1.516.1613.533.\n"
".31412.525633.5..2362\n"
".32...2.42.1.55514.2.\n"
"..56.2445...33.414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.215.6.1335.6\n"
"5613534113.5.3654..11\n"
".26461..3643235623616\n"
"62.26444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4.22213\n"
".5.6636.14624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board852760722);
board852760722 = NULL;
assert( gamma_move(board, 4, 20, 18) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_free_fields(board, 6) == 107 );
assert( gamma_move(board, 1, 21, 18) == 0 );
assert( gamma_busy_fields(board, 1) == 69 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_move(board, 3, 1, 22) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 19, 14) == 0 );
assert( gamma_move(board, 5, 3, 16) == 0 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 21, 18) == 0 );
assert( gamma_move(board, 1, 19, 3) == 0 );
assert( gamma_move(board, 2, 6, 17) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 6, 22) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 22, 3) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 6, 20, 6) == 0 );
assert( gamma_move(board, 6, 0, 5) == 1 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 19, 4) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 3, 12, 7) == 1 );
assert( gamma_move(board, 4, 21, 20) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 6, 19, 4) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 1, 18, 22) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_free_fields(board, 2) == 103 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_free_fields(board, 3) == 103 );
assert( gamma_move(board, 4, 14, 12) == 1 );
assert( gamma_move(board, 4, 11, 16) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_move(board, 6, 15, 20) == 0 );
assert( gamma_move(board, 6, 6, 16) == 0 );
assert( gamma_move(board, 1, 19, 6) == 0 );
assert( gamma_move(board, 1, 16, 5) == 0 );
assert( gamma_move(board, 2, 19, 20) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 3, 14, 20) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_free_fields(board, 4) == 101 );
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 5, 17, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 67 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_free_fields(board, 1) == 101 );
assert( gamma_move(board, 2, 19, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 16, 10) == 0 );
assert( gamma_move(board, 3, 5, 13) == 1 );
assert( gamma_move(board, 4, 13, 12) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 5, 6, 4) == 0 );
assert( gamma_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 6, 10, 10) == 0 );
assert( gamma_move(board, 1, 15, 16) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 2, 15, 2) == 1 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 3, 2, 16) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_golden_move(board, 5, 3, 1) == 0 );
assert( gamma_golden_move(board, 6, 0, 0) == 0 );
assert( gamma_move(board, 1, 21, 1) == 0 );
assert( gamma_move(board, 2, 6, 17) == 0 );
assert( gamma_move(board, 2, 13, 17) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 71 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 4, 19, 5) == 0 );
assert( gamma_move(board, 6, 20, 9) == 0 );
assert( gamma_move(board, 6, 0, 1) == 1 );
assert( gamma_move(board, 1, 19, 19) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 1, 22) == 0 );
assert( gamma_move(board, 5, 3, 3) == 0 );
assert( gamma_move(board, 6, 1, 13) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 1, 18, 8) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 2, 13, 14) == 1 );
assert( gamma_move(board, 3, 13, 17) == 0 );
assert( gamma_move(board, 4, 11, 16) == 0 );
assert( gamma_free_fields(board, 4) == 97 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );


char* board983605024 = gamma_board(board);
assert( board983605024 != NULL );
assert( strcmp(board983605024, 
"433.3.344412.325561.1\n"
"4.1611..5.565153.6...\n"
"515.65.24.54.33566.56\n"
".22..5.541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.31352321\n"
"3134335511.33212.4356\n"
"124.6.1.516.1613.533.\n"
".31412.52563325..2362\n"
".32..32.42.1.55514.2.\n"
"..5622445...334414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"5613534113.5.3654..11\n"
"626461..3643235623616\n"
"62.26444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4222213\n"
"65.6636.14624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board983605024);
board983605024 = NULL;
assert( gamma_move(board, 1, 13, 18) == 0 );
assert( gamma_free_fields(board, 1) == 97 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 71 );
assert( gamma_move(board, 4, 2, 19) == 0 );
assert( gamma_move(board, 5, 8, 20) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 15, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 59 );
assert( gamma_golden_move(board, 6, 2, 20) == 0 );
assert( gamma_move(board, 1, 22, 5) == 0 );
assert( gamma_move(board, 1, 16, 16) == 1 );
assert( gamma_move(board, 2, 18, 12) == 0 );
assert( gamma_golden_move(board, 2, 10, 2) == 0 );


char* board194181015 = gamma_board(board);
assert( board194181015 != NULL );
assert( strcmp(board194181015, 
"433.3.344412.325561.1\n"
"4.1611..5.565153.6...\n"
"515.65.24.54.33566.56\n"
".22..5.541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.31352321\n"
"3134335511.3321214356\n"
"124.6.1.516.1613.533.\n"
".31412.52563325..2362\n"
".32..32.42.1.55514.2.\n"
"..5622445...334414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"5613534113.5.3654..11\n"
"626461..3643235623616\n"
"62.26444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4222213\n"
"65.6636.14624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board194181015);
board194181015 = NULL;
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 22, 12) == 0 );
assert( gamma_move(board, 4, 10, 16) == 1 );
assert( gamma_busy_fields(board, 4) == 55 );


char* board777362513 = gamma_board(board);
assert( board777362513 != NULL );
assert( strcmp(board777362513, 
"433.3.344412.325561.1\n"
"4.1611..5.565153.6...\n"
"515.65.24.54.33566.56\n"
".22..5.541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.31352321\n"
"313433551143321214356\n"
"124.6.1.516.1613.533.\n"
".31412.52563325..2362\n"
".32..32.42.1.55514.2.\n"
"..5622445...334414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"5613534113.5.3654..11\n"
"626461..3643235623616\n"
"62.26444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4222213\n"
"65.6636.14624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board777362513);
board777362513 = NULL;
assert( gamma_move(board, 5, 14, 16) == 0 );
assert( gamma_move(board, 5, 12, 10) == 0 );
assert( gamma_move(board, 6, 19, 22) == 1 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_free_fields(board, 1) == 94 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 71 );


char* board588549798 = gamma_board(board);
assert( board588549798 != NULL );
assert( strcmp(board588549798, 
"433.3.344412.32556161\n"
"4.1611..5.565153.6...\n"
"515.65.24.54.33566.56\n"
".22..5.541663.56..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.31352321\n"
"313433551143321214356\n"
"124.6.1.516.1613.533.\n"
".31412.52563325..2362\n"
".32..32.42.1.55514.2.\n"
"..5622445...334414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"5613534113.5.3654..11\n"
"626461..3643235623616\n"
"62.26444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4222213\n"
"65.6636.14624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board588549798);
board588549798 = NULL;
assert( gamma_move(board, 4, 19, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 21, 19) == 0 );
assert( gamma_move(board, 6, 20, 9) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 14, 15) == 0 );
assert( gamma_move(board, 2, 0, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 5, 14, 16) == 0 );
assert( gamma_busy_fields(board, 5) == 67 );
assert( gamma_move(board, 6, 14, 16) == 0 );
assert( gamma_move(board, 6, 13, 19) == 1 );
assert( gamma_free_fields(board, 6) == 91 );
assert( gamma_move(board, 1, 20, 21) == 1 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 5, 11, 20) == 0 );
assert( gamma_move(board, 5, 16, 18) == 0 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 6, 12, 22) == 1 );
assert( gamma_busy_fields(board, 6) == 62 );


char* board836848854 = gamma_board(board);
assert( board836848854 != NULL );
assert( strcmp(board836848854, 
"433.3.344412632556161\n"
"4.1611..5.565153.6..1\n"
"515.65.24.54.33566.56\n"
".22..5.541663656..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.31352321\n"
"313433551143321214356\n"
"124.6.1.516.1613.533.\n"
".31412.52563325..2362\n"
"232..32.42.1.55514.2.\n"
"..5622445...334414263\n"
"..265552234514424153.\n"
"1.6...112.21121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"5613534113.5.3654..11\n"
"626461..3643235623616\n"
"62326444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4222213\n"
"65.6636.14624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board836848854);
board836848854 = NULL;
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 4, 14, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 55 );
assert( gamma_move(board, 5, 14, 16) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 6, 10, 9) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 22, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_free_fields(board, 3) == 89 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 17, 8) == 0 );
assert( gamma_move(board, 4, 0, 12) == 1 );
assert( gamma_busy_fields(board, 4) == 56 );
assert( gamma_move(board, 5, 8, 9) == 0 );
assert( gamma_move(board, 6, 15, 5) == 0 );
assert( gamma_move(board, 3, 20, 6) == 0 );
assert( gamma_move(board, 4, 9, 10) == 1 );
assert( gamma_move(board, 4, 13, 18) == 0 );
assert( gamma_busy_fields(board, 4) == 57 );
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 5, 17, 18) == 0 );
assert( gamma_move(board, 6, 15, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 62 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 19, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 67 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_move(board, 5, 13, 18) == 0 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 6, 2, 3) == 0 );
assert( gamma_free_fields(board, 6) == 87 );
assert( gamma_move(board, 1, 1, 17) == 0 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 19, 16) == 0 );
assert( gamma_move(board, 4, 16, 14) == 1 );
assert( gamma_move(board, 5, 19, 3) == 0 );
assert( gamma_move(board, 6, 10, 22) == 0 );
assert( gamma_move(board, 6, 7, 1) == 1 );
assert( gamma_free_fields(board, 6) == 85 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 15, 16) == 0 );
assert( gamma_move(board, 3, 19, 4) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 21) == 1 );
assert( gamma_move(board, 6, 20, 12) == 0 );
assert( gamma_move(board, 6, 17, 16) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_golden_move(board, 1, 22, 15) == 0 );


char* board795498676 = gamma_board(board);
assert( board795498676 != NULL );
assert( strcmp(board795498676, 
"433.3.344412632556161\n"
"4.1611..54565153.6..1\n"
"515.65.24.54.33566.56\n"
".22..5.541663656..24.\n"
"13.3.523.563.23211565\n"
"66125.66.216.31352321\n"
"313433551143321214356\n"
"124.6.1.516.1613.533.\n"
".31412.52563325.42362\n"
"232..32.42.1.55514.2.\n"
"4.5622445...334414263\n"
"..265552234514424153.\n"
"1.6...112421121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"5613534113.5.3654..11\n"
"626461..3643235623616\n"
"62326444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4222213\n"
"65.6636614624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board795498676);
board795498676 = NULL;
assert( gamma_busy_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 4, 10, 15) == 0 );
assert( gamma_move(board, 5, 20, 9) == 0 );
assert( gamma_move(board, 5, 14, 13) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_move(board, 1, 19, 17) == 0 );
assert( gamma_golden_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 17, 5) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 3, 18, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 4, 12, 17) == 1 );
assert( gamma_move(board, 5, 7, 13) == 1 );
assert( gamma_move(board, 6, 18, 12) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 18, 17) == 0 );
assert( gamma_move(board, 2, 21, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 21, 18) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 17, 6) == 1 );
assert( gamma_free_fields(board, 5) == 81 );
assert( gamma_move(board, 6, 17, 8) == 0 );
assert( gamma_move(board, 6, 18, 15) == 0 );
assert( gamma_move(board, 1, 8, 16) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 19, 16) == 0 );
assert( gamma_move(board, 4, 10, 18) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 21, 18) == 0 );
assert( gamma_move(board, 6, 16, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 63 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_move(board, 1, 10, 6) == 1 );
assert( gamma_busy_fields(board, 1) == 73 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 3, 15) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 10, 19) == 0 );
assert( gamma_move(board, 6, 20, 6) == 0 );
assert( gamma_move(board, 6, 4, 18) == 1 );
assert( gamma_busy_fields(board, 6) == 64 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 4, 6, 21) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_move(board, 6, 19, 20) == 0 );
assert( gamma_move(board, 1, 15, 20) == 0 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 17, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_move(board, 5, 5, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 69 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 74 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 2, 20, 14) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_free_fields(board, 4) == 75 );
assert( gamma_move(board, 5, 13, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 19, 4) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_free_fields(board, 3) == 75 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 4, 16, 9) == 0 );
assert( gamma_move(board, 5, 8, 14) == 0 );


char* board364016563 = gamma_board(board);
assert( board364016563 != NULL );
assert( strcmp(board364016563, 
"433.3.344412632556161\n"
"4.16114.54565153.6..1\n"
"515.65.24.54.33566.56\n"
".22..5.541663656..24.\n"
"13.36523.563.23211565\n"
"66125.66.216431352321\n"
"313433551143321214356\n"
"12446.1.516.1613.533.\n"
".31412.52563325.42362\n"
"232..32542.1.55514.2.\n"
"4.56224451..334414263\n"
"..265552234514424153.\n"
"116...112421121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"561353411315.36545.11\n"
"626461..3643235623616\n"
"62326444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4222213\n"
"65.6636614624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board364016563);
board364016563 = NULL;
assert( gamma_move(board, 6, 16, 21) == 1 );
assert( gamma_move(board, 6, 1, 17) == 0 );
assert( gamma_move(board, 1, 17, 8) == 0 );
assert( gamma_move(board, 2, 13, 17) == 0 );
assert( gamma_move(board, 3, 3, 16) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 5, 11, 18) == 0 );
assert( gamma_move(board, 5, 8, 19) == 0 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 6, 11, 16) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 22, 5) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 18, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 68 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_move(board, 4, 20, 6) == 0 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 5, 11, 22) == 0 );
assert( gamma_free_fields(board, 6) == 73 );
assert( gamma_move(board, 1, 18, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 19, 20) == 0 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 17, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 11, 17) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 1, 20, 6) == 0 );
assert( gamma_move(board, 1, 13, 22) == 0 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 3, 15, 14) == 1 );


char* board849187517 = gamma_board(board);
assert( board849187517 != NULL );
assert( strcmp(board849187517, 
"433.3.344412632556161\n"
"4.16114.5456515366..1\n"
"515.65.24.54.33566.56\n"
".22..5.541663656..24.\n"
"13.36523.563.23211565\n"
"66125.66.216431352321\n"
"313433551143321214356\n"
"12446.1.516.1613.533.\n"
"231412.52563325342362\n"
"232..32542.1.55514.2.\n"
"4.56224451..334414263\n"
"..265552234514424153.\n"
"116..3112421121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"561353411315.36545211\n"
"626461..3643235623616\n"
"62326444.525641112621\n"
"132415144315.2.4.1.44\n"
"343.235232513.4222213\n"
"65.6636614624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board849187517);
board849187517 = NULL;
assert( gamma_move(board, 4, 7, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 62 );
assert( gamma_move(board, 5, 9, 19) == 0 );
assert( gamma_move(board, 5, 15, 20) == 0 );
assert( gamma_free_fields(board, 6) == 70 );
assert( gamma_move(board, 1, 12, 3) == 1 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 2, 18, 0) == 0 );
assert( gamma_free_fields(board, 2) == 69 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 3, 20, 10) == 0 );
assert( gamma_move(board, 4, 12, 17) == 0 );
assert( gamma_move(board, 4, 11, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 62 );
assert( gamma_move(board, 5, 14, 19) == 0 );
assert( gamma_move(board, 6, 6, 22) == 0 );
assert( gamma_free_fields(board, 6) == 69 );
assert( gamma_move(board, 1, 19, 3) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 75 );
assert( gamma_move(board, 3, 3, 18) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 3, 18) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 15, 7) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 20, 10) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board402387604 = gamma_board(board);
assert( board402387604 != NULL );
assert( strcmp(board402387604, 
"433.3.344412632556161\n"
"4.16114.5456515366..1\n"
"515.65.24.54.33566.56\n"
".22..5.541663656..24.\n"
"13.36523.563.23211565\n"
"66125.66.216431352321\n"
"313433551143321214356\n"
"12446.1.516.1613.533.\n"
"231412.52563325342362\n"
"232..32542.1.55514.2.\n"
"4156224451..334414263\n"
"..265552234514424153.\n"
"116.43112421121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"561353411315.36545211\n"
"626461..3643235623616\n"
"62326444.525641112621\n"
"13241514431512.4.1.44\n"
"343.235232513.4222213\n"
"65.6636614624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board402387604);
board402387604 = NULL;
assert( gamma_move(board, 5, 10, 2) == 0 );


char* board566538258 = gamma_board(board);
assert( board566538258 != NULL );
assert( strcmp(board566538258, 
"433.3.344412632556161\n"
"4.16114.5456515366..1\n"
"515.65.24.54.33566.56\n"
".22..5.541663656..24.\n"
"13.36523.563.23211565\n"
"66125.66.216431352321\n"
"313433551143321214356\n"
"12446.1.516.1613.533.\n"
"231412.52563325342362\n"
"232..32542.1.55514.2.\n"
"4156224451..334414263\n"
"..265552234514424153.\n"
"116.43112421121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"561353411315.36545211\n"
"626461..3643235623616\n"
"62326444.525641112621\n"
"13241514431512.4.1.44\n"
"343.235232513.4222213\n"
"65.6636614624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board566538258);
board566538258 = NULL;
assert( gamma_move(board, 6, 19, 20) == 0 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 18, 11) == 0 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 4, 16, 8) == 0 );
assert( gamma_move(board, 5, 15, 20) == 0 );
assert( gamma_free_fields(board, 5) == 67 );
assert( gamma_move(board, 6, 20, 14) == 0 );
assert( gamma_move(board, 1, 22, 5) == 0 );
assert( gamma_move(board, 3, 18, 8) == 0 );
assert( gamma_move(board, 3, 13, 17) == 0 );


char* board501328391 = gamma_board(board);
assert( board501328391 != NULL );
assert( strcmp(board501328391, 
"433.3.344412632556161\n"
"4.16114.5456515366..1\n"
"515.65.24.54.33566.56\n"
".22..5.541663656..24.\n"
"13.36523.563.23211565\n"
"66125.66.216431352321\n"
"313433551143321214356\n"
"12446.1.516.1613.533.\n"
"231412.52563325342362\n"
"232..32542.1.55514.2.\n"
"4156224451..334414263\n"
"..265552234514424153.\n"
"116.43112421121526143\n"
"3..5614.223353.6321.2\n"
"145.642526632..354126\n"
".415.551.21536.1335.6\n"
"561353411315.36545211\n"
"626461..3643235623616\n"
"62326444.525641112621\n"
"13241514431512.4.1.44\n"
"343.235232513.4222213\n"
"65.6636614624.3.65451\n"
"436433.32526645424115\n") == 0);
free(board501328391);
board501328391 = NULL;
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 11, 20) == 0 );
assert( gamma_move(board, 6, 19, 3) == 0 );
assert( gamma_move(board, 6, 1, 6) == 0 );


gamma_delete(board);

    return 0;
}
