#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 107956999
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 11, 8, 20);
assert( board != NULL );


assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_move(board, 3, 11, 3) == 1 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_move(board, 4, 12, 5) == 1 );
assert( gamma_move(board, 5, 10, 1) == 1 );
assert( gamma_move(board, 5, 10, 0) == 1 );
assert( gamma_free_fields(board, 5) == 147 );


char* board255176171 = gamma_board(board);
assert( board255176171 != NULL );
assert( strcmp(board255176171, 
"..............\n"
"..............\n"
"......1.......\n"
"..............\n"
"..............\n"
"............4.\n"
"..............\n"
"...........3..\n"
"..............\n"
".......2..5...\n"
"...4......5...\n") == 0);
free(board255176171);
board255176171 = NULL;
assert( gamma_move(board, 6, 9, 3) == 1 );
assert( gamma_move(board, 6, 13, 4) == 1 );
assert( gamma_move(board, 7, 5, 7) == 1 );


char* board554038960 = gamma_board(board);
assert( board554038960 != NULL );
assert( strcmp(board554038960, 
"..............\n"
"..............\n"
"......1.......\n"
".....7........\n"
"..............\n"
"............4.\n"
".............6\n"
".........6.3..\n"
"..............\n"
".......2..5...\n"
"...4......5...\n") == 0);
free(board554038960);
board554038960 = NULL;
assert( gamma_move(board, 8, 1, 1) == 1 );
assert( gamma_golden_move(board, 8, 3, 9) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 6) == 1 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_free_fields(board, 5) == 140 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 10, 9) == 1 );
assert( gamma_move(board, 6, 4, 4) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 8, 0) == 1 );
assert( gamma_move(board, 8, 12, 9) == 1 );
assert( gamma_free_fields(board, 8) == 136 );
assert( gamma_move(board, 1, 6, 2) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 5, 10, 5) == 1 );
assert( gamma_move(board, 6, 0, 6) == 1 );
assert( gamma_move(board, 6, 13, 0) == 1 );
assert( gamma_move(board, 7, 10, 0) == 0 );
assert( gamma_move(board, 8, 5, 6) == 1 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 5, 5, 0) == 0 );


char* board362887304 = gamma_board(board);
assert( board362887304 != NULL );
assert( strcmp(board362887304, 
"..............\n"
"..........6.8.\n"
"...3..1....1..\n"
".....7........\n"
"6....8.5..3...\n"
"....4.....5.4.\n"
"....6.1......6\n"
".2.......6.3..\n"
"5.....1.......\n"
".8.....2..5...\n"
".1.4.2..7.5..6\n") == 0);
free(board362887304);
board362887304 = NULL;
assert( gamma_move(board, 6, 7, 3) == 1 );
assert( gamma_move(board, 6, 3, 7) == 1 );
assert( gamma_golden_move(board, 6, 5, 12) == 0 );
assert( gamma_move(board, 7, 9, 2) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 5) == 1 );
assert( gamma_move(board, 8, 8, 3) == 1 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 6, 5, 3) == 1 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_move(board, 8, 6, 3) == 1 );
assert( gamma_move(board, 1, 4, 9) == 1 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_move(board, 4, 5, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 5) == 1 );
assert( gamma_move(board, 6, 8, 13) == 0 );
assert( gamma_move(board, 6, 12, 1) == 1 );
assert( gamma_move(board, 7, 10, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 4 );
assert( gamma_move(board, 8, 7, 6) == 0 );
assert( gamma_move(board, 8, 2, 8) == 1 );
assert( gamma_golden_move(board, 8, 9, 4) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_move(board, 6, 3, 8) == 0 );
assert( gamma_move(board, 6, 1, 6) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 2) == 1 );
assert( gamma_move(board, 7, 13, 1) == 1 );
assert( gamma_move(board, 8, 0, 10) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 5, 7, 6) == 0 );
assert( gamma_move(board, 6, 9, 2) == 0 );
assert( gamma_move(board, 6, 13, 5) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 12, 2) == 1 );
assert( gamma_move(board, 7, 7, 10) == 1 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 13, 8) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 5, 1, 9) == 1 );
assert( gamma_move(board, 6, 9, 13) == 0 );
assert( gamma_move(board, 7, 4, 12) == 0 );
assert( gamma_move(board, 7, 9, 10) == 1 );
assert( gamma_move(board, 8, 7, 2) == 0 );
assert( gamma_move(board, 8, 4, 8) == 1 );


char* board832079737 = gamma_board(board);
assert( board832079737 != NULL );
assert( strcmp(board832079737, 
"8..3...7.7....\n"
".5..1..1.46.8.\n"
"..838.1.3..1.2\n"
"...6.7.1..3...\n"
"66..28.5..3...\n"
".8..4.13.55.46\n"
"...3641......6\n"
".214.68686.3..\n"
"57..3.14.7..7.\n"
".8.....2..5.67\n"
"71.4.22.7.5..6\n") == 0);
free(board832079737);
board832079737 = NULL;
assert( gamma_move(board, 1, 11, 7) == 1 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_free_fields(board, 5) == 83 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board696268293 = gamma_board(board);
assert( board696268293 != NULL );
assert( strcmp(board696268293, 
"8..3...7.7....\n"
".5..1.21.46.8.\n"
"..838.1.3..1.2\n"
"...6.7.1..31..\n"
"66..28.5..3...\n"
".8..4.13.55.46\n"
"...3641......6\n"
".214.68686.3..\n"
"57..3.14.7..7.\n"
".8.....2..5.67\n"
"71.4.22.7.5..6\n") == 0);
free(board696268293);
board696268293 = NULL;
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 6, 3, 9) == 1 );
assert( gamma_move(board, 7, 10, 12) == 0 );
assert( gamma_move(board, 8, 0, 9) == 1 );


char* board476444659 = gamma_board(board);
assert( board476444659 != NULL );
assert( strcmp(board476444659, 
"8..3...7.7....\n"
"85.61.21.46.8.\n"
"..838.1.3..1.2\n"
"...6.7.1..31..\n"
"66..28.5..3...\n"
".8..4.13.55.46\n"
"...3641......6\n"
".214.68686.3..\n"
"57..3.14.7..7.\n"
".8.....2..5.67\n"
"71.4.22.7.5..6\n") == 0);
free(board476444659);
board476444659 = NULL;
assert( gamma_move(board, 1, 8, 7) == 1 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 5, 11, 5) == 1 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_free_fields(board, 6) == 77 );
assert( gamma_move(board, 7, 9, 13) == 0 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 8, 12) == 0 );
assert( gamma_move(board, 8, 6, 4) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_free_fields(board, 3) == 75 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board904815799 = gamma_board(board);
assert( board904815799 != NULL );
assert( strcmp(board904815799, 
"8..3...7.7....\n"
"85.61.21.46.8.\n"
"..838.1.33.1.2\n"
"...6.7.11.31..\n"
"66..28.5..3...\n"
".8..4.13.55546\n"
"..23641...3..6\n"
".214.68686.3..\n"
"57..3.14.7..7.\n"
".8..2..2..5.67\n"
"71.4.22.7.5..6\n") == 0);
free(board904815799);
board904815799 = NULL;
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_move(board, 5, 5, 2) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board382244835 = gamma_board(board);
assert( board382244835 != NULL );
assert( strcmp(board382244835, 
"8..3...7.7....\n"
"85.61.21.46.8.\n"
"..838.1.33.1.2\n"
"...6.7.11.31..\n"
"66..28.5..3...\n"
".8..4.13.55546\n"
"..23641...3..6\n"
".214.68686.3..\n"
"57..3514.7..7.\n"
".8..2..2..5.67\n"
"71.4.22.7.5..6\n") == 0);
free(board382244835);
board382244835 = NULL;
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_free_fields(board, 6) == 74 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 8, 1, 6) == 0 );
assert( gamma_move(board, 8, 11, 0) == 1 );
assert( gamma_free_fields(board, 8) == 73 );
assert( gamma_move(board, 1, 11, 10) == 1 );
assert( gamma_golden_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 3, 1, 10) == 1 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 5, 6, 7) == 1 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 8, 8, 10) == 1 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_free_fields(board, 1) == 68 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 5, 7, 7) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_move(board, 7, 7, 4) == 1 );
assert( gamma_free_fields(board, 7) == 65 );
assert( gamma_move(board, 8, 7, 12) == 0 );
assert( gamma_move(board, 8, 6, 3) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );


char* board320784935 = gamma_board(board);
assert( board320784935 != NULL );
assert( strcmp(board320784935, 
"83.3...787.1..\n"
"85.61.21.46.8.\n"
"..83841.33.1.2\n"
"...6.7511.31..\n"
"66..28.5..3...\n"
".8..4.13255546\n"
"..236417..3.16\n"
"4214.68686.3..\n"
"57..3514.7..7.\n"
".8..2..2..5.67\n"
"71.4.22.7.58.6\n") == 0);
free(board320784935);
board320784935 = NULL;
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_move(board, 5, 6, 10) == 1 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 6, 11, 9) == 1 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 4, 5, 10) == 1 );
assert( gamma_move(board, 5, 6, 13) == 0 );
assert( gamma_move(board, 5, 8, 9) == 1 );
assert( gamma_move(board, 6, 3, 1) == 1 );


char* board826350723 = gamma_board(board);
assert( board826350723 != NULL );
assert( strcmp(board826350723, 
"83.3.4578741..\n"
"85.61.2154668.\n"
"..83841.33.1.2\n"
"...6.7511.31..\n"
"66..28.5..3...\n"
".8..4.13255546\n"
"..236417..3.16\n"
"4214.68686.3..\n"
"57..3514.7..7.\n"
".8.62..2..5.67\n"
"71.4.22.7.58.6\n") == 0);
free(board826350723);
board826350723 = NULL;
assert( gamma_move(board, 8, 6, 2) == 0 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 1, 3, 6) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 11) == 0 );
assert( gamma_move(board, 7, 0, 9) == 0 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_free_fields(board, 7) == 57 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_move(board, 4, 8, 1) == 1 );
assert( gamma_golden_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 6, 8, 10) == 0 );


char* board894983785 = gamma_board(board);
assert( board894983785 != NULL );
assert( strcmp(board894983785, 
"83.3.4578741..\n"
"85.61.2154668.\n"
"..83841.3341.2\n"
"...6.7511.31..\n"
"66.12835..3...\n"
".8..4.13255546\n"
"..236417..3.16\n"
"4214.68686.3..\n"
"57..3514.7..7.\n"
".8.62..24.5.67\n"
"71.4.2227.58.6\n") == 0);
free(board894983785);
board894983785 = NULL;
assert( gamma_move(board, 7, 8, 7) == 0 );
assert( gamma_move(board, 7, 11, 2) == 1 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_golden_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_free_fields(board, 2) == 52 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_move(board, 5, 1, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 2, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 5, 1) == 1 );
assert( gamma_move(board, 8, 13, 6) == 1 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_free_fields(board, 8) == 49 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_free_fields(board, 5) == 49 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_free_fields(board, 6) == 49 );
assert( gamma_move(board, 7, 2, 2) == 1 );
assert( gamma_golden_move(board, 7, 6, 4) == 1 );
assert( gamma_move(board, 8, 10, 0) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 6, 4, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_move(board, 7, 9, 5) == 0 );
assert( gamma_move(board, 7, 8, 2) == 1 );
assert( gamma_golden_move(board, 7, 3, 0) == 0 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 13 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 13, 7) == 1 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 5, 8, 12) == 0 );
assert( gamma_move(board, 6, 0, 8) == 1 );
assert( gamma_move(board, 7, 8, 7) == 0 );
assert( gamma_move(board, 8, 6, 6) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_move(board, 5, 2, 1) == 1 );
assert( gamma_move(board, 6, 8, 12) == 0 );
assert( gamma_move(board, 6, 10, 9) == 0 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_free_fields(board, 7) == 41 );
assert( gamma_move(board, 8, 6, 5) == 0 );
assert( gamma_move(board, 8, 10, 9) == 0 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 1, 3, 3) == 0 );


char* board476009246 = gamma_board(board);
assert( board476009246 != NULL );
assert( strcmp(board476009246, 
"83.3.4578741..\n"
"85.61.2154668.\n"
"6.83841.3341.2\n"
"...6.7511.31.3\n"
"66.12835..32.8\n"
".8..4113255546\n"
"4.236477..3.16\n"
"4214668686.3..\n"
"577.351477.77.\n"
".85627.24.5.67\n"
"7134.2227.58.6\n") == 0);
free(board476009246);
board476009246 = NULL;
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 6, 4, 7) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 10, 13) == 0 );
assert( gamma_move(board, 7, 13, 7) == 0 );
assert( gamma_move(board, 8, 1, 9) == 0 );
assert( gamma_move(board, 8, 4, 6) == 0 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 12, 7) == 1 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 5, 12, 3) == 1 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 7, 8, 12) == 0 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_move(board, 1, 12, 0) == 1 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_free_fields(board, 4) == 33 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 6, 0, 8) == 0 );


char* board579225864 = gamma_board(board);
assert( board579225864 != NULL );
assert( strcmp(board579225864, 
"83.3.4578741..\n"
"85.61421546682\n"
"6.83841.3341.2\n"
"...667511.3143\n"
"66.12835..32.8\n"
".84.4113255546\n"
"4.236477..3.16\n"
"4214668686.35.\n"
"577.351477.77.\n"
".85627.24.5.67\n"
"7134.2227.5816\n") == 0);
free(board579225864);
board579225864 = NULL;
assert( gamma_busy_fields(board, 7) == 15 );


char* board874775891 = gamma_board(board);
assert( board874775891 != NULL );
assert( strcmp(board874775891, 
"83.3.4578741..\n"
"85.61421546682\n"
"6.83841.3341.2\n"
"...667511.3143\n"
"66.12835..32.8\n"
".84.4113255546\n"
"4.236477..3.16\n"
"4214668686.35.\n"
"577.351477.77.\n"
".85627.24.5.67\n"
"7134.2227.5816\n") == 0);
free(board874775891);
board874775891 = NULL;
assert( gamma_move(board, 8, 10, 4) == 0 );
assert( gamma_free_fields(board, 8) == 33 );
assert( gamma_move(board, 1, 1, 0) == 0 );


char* board130833223 = gamma_board(board);
assert( board130833223 != NULL );
assert( strcmp(board130833223, 
"83.3.4578741..\n"
"85.61421546682\n"
"6.83841.3341.2\n"
"...667511.3143\n"
"66.12835..32.8\n"
".84.4113255546\n"
"4.236477..3.16\n"
"4214668686.35.\n"
"577.351477.77.\n"
".85627.24.5.67\n"
"7134.2227.5816\n") == 0);
free(board130833223);
board130833223 = NULL;
assert( gamma_move(board, 2, 6, 9) == 0 );


char* board304406821 = gamma_board(board);
assert( board304406821 != NULL );
assert( strcmp(board304406821, 
"83.3.4578741..\n"
"85.61421546682\n"
"6.83841.3341.2\n"
"...667511.3143\n"
"66.12835..32.8\n"
".84.4113255546\n"
"4.236477..3.16\n"
"4214668686.35.\n"
"577.351477.77.\n"
".85627.24.5.67\n"
"7134.2227.5816\n") == 0);
free(board304406821);
board304406821 = NULL;
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_free_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_free_fields(board, 4) == 33 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 8, 2, 8) == 0 );
assert( gamma_move(board, 8, 9, 4) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_free_fields(board, 3) == 32 );
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 5, 13, 10) == 1 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_free_fields(board, 6) == 30 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 8, 1, 7) == 1 );
assert( gamma_move(board, 8, 7, 10) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 5, 9, 4) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_free_fields(board, 6) == 29 );
assert( gamma_free_fields(board, 7) == 29 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_golden_move(board, 7, 2, 12) == 0 );
assert( gamma_move(board, 8, 3, 10) == 0 );
assert( gamma_move(board, 8, 9, 7) == 1 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 5, 4, 11) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_move(board, 6, 0, 8) == 0 );
assert( gamma_move(board, 7, 8, 4) == 1 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_move(board, 8, 7, 2) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 7, 10, 2) == 1 );
assert( gamma_move(board, 8, 9, 2) == 0 );
assert( gamma_move(board, 8, 12, 5) == 0 );
assert( gamma_busy_fields(board, 8) == 16 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 1, 8) == 1 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 9, 10) == 1 );
assert( gamma_move(board, 5, 10, 12) == 0 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 7, 9, 5) == 0 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_move(board, 8, 2, 2) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 5, 9, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_free_fields(board, 5) == 24 );
assert( gamma_move(board, 6, 4, 0) == 1 );
assert( gamma_move(board, 8, 1, 9) == 0 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_move(board, 7, 8, 12) == 0 );
assert( gamma_move(board, 8, 1, 9) == 0 );
assert( gamma_move(board, 8, 12, 1) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 8, 7) == 0 );
assert( gamma_move(board, 8, 7, 2) == 0 );
assert( gamma_busy_fields(board, 8) == 16 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 11) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_free_fields(board, 6) == 19 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_move(board, 8, 1, 0) == 0 );
assert( gamma_busy_fields(board, 8) == 16 );
assert( gamma_golden_move(board, 8, 0, 13) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_move(board, 6, 5, 9) == 0 );
assert( gamma_move(board, 6, 11, 1) == 1 );
assert( gamma_free_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 8, 7) == 0 );
assert( gamma_move(board, 7, 8, 8) == 0 );
assert( gamma_move(board, 8, 2, 13) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 1, 8, 10) == 0 );


char* board734439671 = gamma_board(board);
assert( board734439671 != NULL );
assert( strcmp(board734439671, 
"8363.4578441.5\n"
"85461421546682\n"
"6183841.3341.2\n"
".8.66751183143\n"
"66.128352.32.8\n"
".84.4113255546\n"
"44236477783.16\n"
"4214668686.35.\n"
"5771351477777.\n"
".85627624.5667\n"
"71346222755816\n") == 0);
free(board734439671);
board734439671 = NULL;
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 4, 13, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 6, 3, 7) == 0 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 7, 4, 6) == 0 );
assert( gamma_move(board, 8, 6, 0) == 0 );
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_free_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 3, 11, 4) == 1 );
assert( gamma_move(board, 4, 1, 5) == 0 );


gamma_delete(board);

    return 0;
}
