#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 122618624
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 15, 3, 40);
assert( board != NULL );


assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 1, 4, 14) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 14) == 1 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 1, 13, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 4 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 2, 7, 6) == 1 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 2 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 1, 1, 6) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_move(board, 2, 1, 9) == 1 );


char* board594907167 = gamma_board(board);
assert( board594907167 != NULL );
assert( strcmp(board594907167, 
"....1..3....21\n"
"..............\n"
"..............\n"
"..2....1......\n"
"1............1\n"
".2...3........\n"
".3............\n"
"......2.......\n"
".1.....2.32..1\n"
"....2.........\n"
".....11.......\n"
"......2..1....\n"
"....3.........\n"
".3............\n"
"..............\n") == 0);
free(board594907167);
board594907167 = NULL;
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_free_fields(board, 1) == 184 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 2, 1, 12) == 1 );


char* board722860018 = gamma_board(board);
assert( board722860018 != NULL );
assert( strcmp(board722860018, 
"....1..3....21\n"
"..............\n"
".2............\n"
"..2..3.1......\n"
"1............1\n"
".2...3........\n"
".3............\n"
"......2.......\n"
".1.....2.32..1\n"
"....2.........\n"
"1....11.......\n"
"......2..1....\n"
"....3.........\n"
"23............\n"
"..............\n") == 0);
free(board722860018);
board722860018 = NULL;
assert( gamma_move(board, 3, 6, 4) == 0 );


char* board173496488 = gamma_board(board);
assert( board173496488 != NULL );
assert( strcmp(board173496488, 
"....1..3....21\n"
"..............\n"
".2............\n"
"..2..3.1......\n"
"1............1\n"
".2...3........\n"
".3............\n"
"......2.......\n"
".1.....2.32..1\n"
"....2.........\n"
"1....11.......\n"
"......2..1....\n"
"....3.........\n"
"23............\n"
"..............\n") == 0);
free(board173496488);
board173496488 = NULL;
assert( gamma_move(board, 1, 8, 11) == 1 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 3, 11, 4) == 1 );
assert( gamma_move(board, 1, 7, 13) == 1 );
assert( gamma_move(board, 1, 3, 4) == 1 );
assert( gamma_move(board, 2, 11, 13) == 1 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_free_fields(board, 3) == 175 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 14) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 1, 11, 7) == 1 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 7, 8) == 1 );
assert( gamma_move(board, 2, 5, 13) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 1, 12, 8) == 1 );
assert( gamma_move(board, 2, 12, 0) == 1 );
assert( gamma_move(board, 3, 10, 14) == 1 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_free_fields(board, 1) == 160 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_move(board, 2, 10, 7) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 5, 12) == 1 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_move(board, 2, 11, 9) == 1 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 13, 12) == 1 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 3, 12, 10) == 1 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_free_fields(board, 1) == 150 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_move(board, 3, 6, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_free_fields(board, 3) == 144 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 9, 8) == 1 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_free_fields(board, 3) == 141 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_free_fields(board, 1) == 141 );
assert( gamma_move(board, 2, 9, 13) == 1 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 1, 9, 0) == 1 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 1, 13, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_move(board, 2, 13, 2) == 1 );
assert( gamma_move(board, 3, 4, 3) == 1 );
assert( gamma_move(board, 3, 3, 12) == 1 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_free_fields(board, 2) == 130 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 1, 12, 13) == 1 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_free_fields(board, 2) == 127 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 1, 9, 10) == 1 );
assert( gamma_move(board, 3, 6, 0) == 1 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_move(board, 1, 5, 14) == 1 );
assert( gamma_busy_fields(board, 1) == 30 );


char* board313279591 = gamma_board(board);
assert( board313279591 != NULL );
assert( strcmp(board313279591, 
".2..1133..3.21\n"
"1.3..2.1.2.21.\n"
".2.3.33......2\n"
"132..3.11.....\n"
"12.21....1..31\n"
".23.33.....2..\n"
".3.3..22.2..1.\n"
"...33.2...21..\n"
".1.....2.32.31\n"
"...12..1......\n"
"13.1.113...31.\n"
"..113.2..12..1\n"
"1.2.3.3...2..2\n"
"23.3.....2....\n"
"33....3..1..2.\n") == 0);
free(board313279591);
board313279591 = NULL;
assert( gamma_move(board, 2, 11, 11) == 1 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_free_fields(board, 2) == 120 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 2, 10, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board796517002 = gamma_board(board);
assert( board796517002 != NULL );
assert( strcmp(board796517002, 
".2..1133..3.21\n"
"1.3..2.1.2.21.\n"
".2.3.33...2..2\n"
"132..3.11..2..\n"
"12.21....1..31\n"
".23.33.....2..\n"
".3.3..22.2..1.\n"
"...33.2...21..\n"
".1...2.2.32131\n"
".2.12..1......\n"
"13.1.113...31.\n"
"..113.2..12..1\n"
"1.2.3.3...2..2\n"
"23.3.....2....\n"
"33....3..1..2.\n") == 0);
free(board796517002);
board796517002 = NULL;
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_free_fields(board, 2) == 114 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 1, 11, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 8, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_free_fields(board, 2) == 107 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 1, 12, 9) == 1 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_free_fields(board, 1) == 105 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 7, 9) == 1 );
assert( gamma_move(board, 2, 5, 2) == 1 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 3) == 1 );
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 2, 13, 11) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_golden_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 2, 10, 11) == 1 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 2, 7, 12) == 1 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_free_fields(board, 3) == 89 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_free_fields(board, 3) == 87 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_free_fields(board, 1) == 86 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_golden_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 1, 2, 12) == 1 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 38 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 13, 9) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );


char* board274375215 = gamma_board(board);
assert( board274375215 != NULL );
assert( strcmp(board274375215, 
".2..1133..3.21\n"
"113..2.112.211\n"
".213.332..23.2\n"
"132..3.11.22.2\n"
"12.21..1.1..31\n"
".23.33.222.211\n"
"33.33.22.2.31.\n"
"...33.212121..\n"
".1..32.2.32131\n"
"12.122.1......\n"
"13.1.1132..31.\n"
"33113.2..12121\n"
"122.323.3.2..2\n"
"23.3...2.2.1..\n"
"33...232.1.22.\n") == 0);
free(board274375215);
board274375215 = NULL;
assert( gamma_move(board, 3, 10, 8) == 1 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 49 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 8, 14) == 1 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 49 );
assert( gamma_free_fields(board, 2) == 77 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_free_fields(board, 3) == 76 );
assert( gamma_move(board, 1, 4, 12) == 1 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_free_fields(board, 3) == 73 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 3, 13, 4) == 1 );
assert( gamma_free_fields(board, 3) == 72 );
assert( gamma_move(board, 2, 4, 4) == 1 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 46 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 1, 13, 13) == 0 );
assert( gamma_golden_move(board, 1, 8, 7) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 1, 5, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 7, 2) == 1 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );


char* board638720171 = gamma_board(board);
assert( board638720171 != NULL );
assert( strcmp(board638720171, 
".2..11331.3.21\n"
"113..2.1123211\n"
".2131332..23.2\n"
"132..3.11.22.2\n"
"12.212.1.1..31\n"
".23.33.222.211\n"
"33.33122.2331.\n"
"...33.211121..\n"
".1..3232.32131\n"
"12.122213.3...\n"
"13.121132.1313\n"
"33113.2..12121\n"
"122.32333.2..2\n"
"23.3...2.2.1..\n"
"33...23231.22.\n") == 0);
free(board638720171);
board638720171 = NULL;
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 46 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_free_fields(board, 2) == 65 );
assert( gamma_golden_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );


char* board788407547 = gamma_board(board);
assert( board788407547 != NULL );
assert( strcmp(board788407547, 
".2..11331.3.21\n"
"113..2.1123211\n"
".2131332..23.2\n"
"132..3.11.22.2\n"
"12.212.1.1..31\n"
".23.33.222.211\n"
"33.33122.2331.\n"
"...33.211121..\n"
".1.23232.32131\n"
"12.122213.3...\n"
"13.121132.1313\n"
"33113.2..12121\n"
"122.32333.2..2\n"
"23.3...2.2.1..\n"
"33...23231.22.\n") == 0);
free(board788407547);
board788407547 = NULL;
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_free_fields(board, 1) == 64 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_free_fields(board, 2) == 64 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 2, 11, 2) == 1 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_free_fields(board, 3) == 63 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_golden_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 4, 13) == 1 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 3, 14, 11) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 2, 5, 3) == 1 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_golden_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 1, 8, 8) == 1 );
assert( gamma_move(board, 1, 6, 3) == 0 );


char* board367505088 = gamma_board(board);
assert( board367505088 != NULL );
assert( strcmp(board367505088, 
".2..11331.3.21\n"
"113.32.1123211\n"
"12131332..23.2\n"
"1321.3.11322.2\n"
"12.212.1.1..31\n"
".23.33.222.211\n"
"33.3312212331.\n"
"22.33.211121..\n"
"21.23232.32131\n"
"12.122213.3...\n"
"133121132.1313\n"
"3311322..12121\n"
"122.32333.22.2\n"
"23.3...2.221..\n"
"331..23231.22.\n") == 0);
free(board367505088);
board367505088 = NULL;
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_free_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 49 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 13, 8) == 1 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_golden_move(board, 3, 8, 12) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 2, 2, 14) == 1 );
assert( gamma_golden_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 3, 3, 13) == 1 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 53 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 53 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );


char* board164273159 = gamma_board(board);
assert( board164273159 != NULL );
assert( strcmp(board164273159, 
".22.11331.3.21\n"
"113332.1123211\n"
"12131332..2312\n"
"1321.3.11322.2\n"
"12.212.1.1..31\n"
".23.33.222.211\n"
"33.33122123312\n"
"22.33.211121..\n"
"21.23232.32131\n"
"12.122213.3...\n"
"133121132.1313\n"
"3311322..12121\n"
"122.32333.22.2\n"
"23.3...2.221..\n"
"331..23231.22.\n") == 0);
free(board164273159);
board164273159 = NULL;
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_golden_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_free_fields(board, 3) == 47 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_free_fields(board, 1) == 47 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_free_fields(board, 2) == 46 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 1, 13, 1) == 1 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 8, 3) == 1 );


char* board305504390 = gamma_board(board);
assert( board305504390 != NULL );
assert( strcmp(board305504390, 
".22211331.3.21\n"
"113332.1123211\n"
"12131332..2312\n"
"1321.3.11322.2\n"
"12.212.1.1..31\n"
"123.33.222.211\n"
"33.33122123312\n"
"22.33.211121..\n"
"21.23232.32131\n"
"12.122213.32..\n"
"133121132.1313\n"
"3311322.212121\n"
"122.32333.22.2\n"
"23.3...2.221.1\n"
"331..23231.22.\n") == 0);
free(board305504390);
board305504390 = NULL;
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 55 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 62 );
assert( gamma_free_fields(board, 2) == 42 );
assert( gamma_golden_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board125608394 = gamma_board(board);
assert( board125608394 != NULL );
assert( strcmp(board125608394, 
".22211331.3.21\n"
"113332.1123211\n"
"12131332..2312\n"
"1321.3.11322.2\n"
"12.212.1.1..31\n"
"123.33.222.211\n"
"33.33122123312\n"
"22.33.211121..\n"
"21.23232.32131\n"
"12.122213.32..\n"
"133121132.1313\n"
"3311322.212121\n"
"122132333.22.2\n"
"23.3...2.221.1\n"
"331..23231.22.\n") == 0);
free(board125608394);
board125608394 = NULL;
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_free_fields(board, 1) == 42 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 13, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_golden_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_golden_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_free_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_golden_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_golden_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 1) == 1 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_free_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 1, 11, 14) == 1 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 63 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_free_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 57 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 63 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_golden_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board906601103 = gamma_board(board);
assert( board906601103 != NULL );
assert( strcmp(board906601103, 
".22211331.3121\n"
"113332.1123211\n"
"12131332..2312\n"
"1321.3.11322.2\n"
"12.21221.1..31\n"
"123.33.222.211\n"
"33.33122123312\n"
"22.332211121..\n"
"21.23232.32131\n"
"12.122213.32..\n"
"133121132.1313\n"
"3311322.212121\n"
"122132333.22.2\n"
"23.33..33221.1\n"
"331..23231.22.\n") == 0);
free(board906601103);
board906601103 = NULL;
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 2, 13, 7) == 1 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_free_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board280024033 = gamma_board(board);
assert( board280024033 != NULL );
assert( strcmp(board280024033, 
".22211331.3121\n"
"113332.1123211\n"
"12131332..2312\n"
"1321.3.11322.2\n"
"12.21221.1..31\n"
"123.33.222.211\n"
"33.33122123312\n"
"22.332211121.2\n"
"21.23232.32131\n"
"12.122213.32..\n"
"133121132.1313\n"
"3311322.212121\n"
"122132333322.2\n"
"23333..33221.1\n"
"331..23231.22.\n") == 0);
free(board280024033);
board280024033 = NULL;
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 64 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 57 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_free_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_free_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 2, 13, 14) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_free_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_golden_move(board, 3, 1, 0) == 0 );
assert( gamma_free_fields(board, 1) == 31 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 58 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 10, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 57 );
assert( gamma_free_fields(board, 1) == 30 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 65 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_free_fields(board, 3) == 30 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );


char* board167928275 = gamma_board(board);
assert( board167928275 != NULL );
assert( strcmp(board167928275, 
".22211331.3121\n"
"11333211123211\n"
"12131332..2312\n"
"1321.3.11322.2\n"
"12.21221.13.31\n"
"123.332222.211\n"
"33.33122123312\n"
"22.332211121.2\n"
"21.23232.32131\n"
"12.122213.323.\n"
"133121132.1313\n"
"3311322.212121\n"
"122132333322.2\n"
"23333..33221.1\n"
"331..23231.22.\n") == 0);
free(board167928275);
board167928275 = NULL;
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_free_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 57 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 6, 1) == 1 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );


gamma_delete(board);

    return 0;
}
