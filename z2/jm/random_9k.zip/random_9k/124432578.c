#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 124432578
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 16, 3, 46);
assert( board != NULL );


assert( gamma_busy_fields(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_move(board, 2, 11, 14) == 1 );
assert( gamma_move(board, 2, 16, 1) == 1 );
assert( gamma_move(board, 3, 9, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 2, 16, 14) == 1 );
assert( gamma_move(board, 3, 4, 1) == 1 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_free_fields(board, 2) == 274 );
assert( gamma_move(board, 3, 6, 8) == 1 );
assert( gamma_move(board, 1, 12, 13) == 1 );
assert( gamma_move(board, 1, 17, 15) == 1 );
assert( gamma_move(board, 2, 9, 13) == 1 );
assert( gamma_move(board, 2, 10, 9) == 1 );
assert( gamma_move(board, 3, 6, 11) == 1 );
assert( gamma_move(board, 1, 17, 2) == 1 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 15, 12) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 8, 16) == 0 );
assert( gamma_move(board, 1, 14, 7) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 15) == 1 );
assert( gamma_move(board, 3, 8, 16) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 1, 8, 10) == 1 );


char* board164313551 = gamma_board(board);
assert( board164313551 != NULL );
assert( strcmp(board164313551, 
".........2.......1\n"
".2.......3.2....2.\n"
"..1......2..1.....\n"
"...............3..\n"
"......3...1.......\n"
"........1.........\n"
"..........23......\n"
"......3...........\n"
"....1.........1...\n"
"..2...............\n"
"1.................\n"
".2.2..1...........\n"
"..2...............\n"
".................1\n"
"....3...........2.\n"
".3................\n") == 0);
free(board164313551);
board164313551 = NULL;
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 3, 14, 3) == 1 );
assert( gamma_move(board, 1, 7, 15) == 1 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_free_fields(board, 1) == 253 );
assert( gamma_move(board, 2, 11, 2) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_free_fields(board, 3) == 251 );
assert( gamma_move(board, 1, 11, 7) == 1 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_move(board, 2, 2, 14) == 1 );
assert( gamma_free_fields(board, 2) == 248 );


char* board777920650 = gamma_board(board);
assert( board777920650 != NULL );
assert( strcmp(board777920650, 
".......1.2.......1\n"
".22......3.2....2.\n"
"..1......2..1.....\n"
"...............3..\n"
"......3...1.......\n"
"........1.........\n"
"..........23......\n"
"......3...........\n"
"....1....1.1..1...\n"
"..2......2........\n"
"1.2...............\n"
".2.2..1...2.......\n"
".32...........3...\n"
".......2...2.....1\n"
"....3...........2.\n"
".3.3..............\n") == 0);
free(board777920650);
board777920650 = NULL;
assert( gamma_move(board, 1, 11, 11) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board855253488 = gamma_board(board);
assert( board855253488 != NULL );
assert( strcmp(board855253488, 
".......1.2.......1\n"
".22......3.2....2.\n"
"..1......2..1.....\n"
"...............3..\n"
"......3...11......\n"
"........1.........\n"
"..........23......\n"
"......3...........\n"
"....1....1.1..1...\n"
"..2......2........\n"
"1.2...............\n"
".2.2..1...2.......\n"
".32...........3...\n"
".......2...2.....1\n"
"....3...........2.\n"
".3.3..............\n") == 0);
free(board855253488);
board855253488 = NULL;
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 10, 10) == 1 );
assert( gamma_free_fields(board, 3) == 246 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_golden_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 2, 13, 6) == 1 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 1, 12, 2) == 1 );
assert( gamma_move(board, 2, 7, 13) == 1 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_move(board, 1, 5, 6) == 1 );
assert( gamma_move(board, 1, 12, 5) == 1 );
assert( gamma_move(board, 2, 4, 16) == 0 );
assert( gamma_free_fields(board, 2) == 235 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 2, 17, 1) == 1 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_free_fields(board, 2) == 233 );


char* board565560491 = gamma_board(board);
assert( board565560491 != NULL );
assert( strcmp(board565560491, 
".......1.2.......1\n"
".22......3.2....2.\n"
"..1....2.2..1.....\n"
"1...3..........3..\n"
"......3...112.....\n"
"........1.3.......\n"
".........323......\n"
"......3...........\n"
"....1....1.1..1...\n"
"..2..1...2...2....\n"
"1.2.........1.....\n"
".2.2..1...2.......\n"
".321..........3...\n"
".......2...21....1\n"
"....1..23.......22\n"
".3.3..............\n") == 0);
free(board565560491);
board565560491 = NULL;
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 1, 6, 1) == 1 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_free_fields(board, 3) == 231 );
assert( gamma_golden_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_free_fields(board, 2) == 229 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 3, 4, 13) == 1 );
assert( gamma_move(board, 1, 15, 8) == 1 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 1, 12, 1) == 1 );
assert( gamma_golden_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 1, 16, 12) == 1 );
assert( gamma_free_fields(board, 1) == 219 );
assert( gamma_move(board, 2, 15, 16) == 0 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_free_fields(board, 1) == 216 );
assert( gamma_move(board, 2, 12, 12) == 1 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_move(board, 1, 3, 6) == 1 );
assert( gamma_move(board, 1, 12, 0) == 1 );
assert( gamma_golden_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 1, 15) == 1 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 1, 5, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_move(board, 3, 11, 6) == 1 );
assert( gamma_free_fields(board, 3) == 203 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_free_fields(board, 1) == 203 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 13, 10) == 1 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 16, 8) == 1 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_golden_move(board, 2, 9, 11) == 0 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 3, 16, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_golden_move(board, 1, 12, 15) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_move(board, 3, 10, 0) == 1 );
assert( gamma_move(board, 1, 8, 4) == 1 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 13, 13) == 1 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 29 );


char* board419746520 = gamma_board(board);
assert( board419746520 != NULL );
assert( strcmp(board419746520, 
".2.....1.2.......1\n"
".222.....3.2....2.\n"
".3113..2.2..13....\n"
"1...31......2..31.\n"
"......3...112.....\n"
"3....23.1.3..3....\n"
".1...3...323......\n"
"......3..3.....11.\n"
"....1..221.1..1...\n"
"..21.1..22.3.2....\n"
"1221....3...1.....\n"
".2.2.31.1.2.......\n"
".321...13...3.3...\n"
"....21.2...21....1\n"
".1..1.1233..1...22\n"
".3.3....3.3.1.....\n") == 0);
free(board419746520);
board419746520 = NULL;
assert( gamma_move(board, 3, 0, 5) == 0 );


char* board970728287 = gamma_board(board);
assert( board970728287 != NULL );
assert( strcmp(board970728287, 
".2.....1.2.......1\n"
".222.....3.2....2.\n"
".3113..2.2..13....\n"
"1...31......2..31.\n"
"......3...112.....\n"
"3....23.1.3..3....\n"
".1...3...323......\n"
"......3..3.....11.\n"
"....1..221.1..1...\n"
"..21.1..22.3.2....\n"
"1221....3...1.....\n"
".2.2.31.1.2.......\n"
".321...13...3.3...\n"
"....21.2...21....1\n"
".1..1.1233..1...22\n"
".3.3....3.3.1.....\n") == 0);
free(board970728287);
board970728287 = NULL;
assert( gamma_move(board, 1, 12, 7) == 1 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 2, 12, 14) == 1 );
assert( gamma_free_fields(board, 2) == 191 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 1, 13, 3) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_free_fields(board, 3) == 188 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 3, 12, 9) == 1 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 2, 13, 17) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 1, 15, 6) == 1 );
assert( gamma_move(board, 2, 16, 7) == 1 );
assert( gamma_move(board, 2, 13, 5) == 1 );
assert( gamma_move(board, 3, 2, 16) == 0 );
assert( gamma_move(board, 3, 4, 15) == 1 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_free_fields(board, 1) == 180 );
assert( gamma_move(board, 2, 13, 2) == 1 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 38 );
assert( gamma_move(board, 3, 3, 17) == 0 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 17, 6) == 1 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 15) == 1 );
assert( gamma_move(board, 3, 11, 5) == 1 );
assert( gamma_move(board, 1, 9, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_free_fields(board, 1) == 174 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_golden_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_free_fields(board, 2) == 173 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 13, 16) == 0 );
assert( gamma_move(board, 2, 6, 15) == 1 );
assert( gamma_move(board, 3, 15, 2) == 1 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_free_fields(board, 2) == 170 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 1, 6, 12) == 1 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 16, 4) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 14, 8) == 1 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 3, 5, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 15, 16) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );


char* board334326919 = gamma_board(board);
assert( board334326919 != NULL );
assert( strcmp(board334326919, 
".2..3.21.2.3.....1\n"
".222.3...3122...2.\n"
".3113..2.2..13....\n"
"1...311.2...2..31.\n"
"......3...112.....\n"
"3..3.23.1.3..3....\n"
".1...3...3233.....\n"
"......3..3....211.\n"
"....1.2221.11.1.2.\n"
"..21.11322.3.2.1.1\n"
"1221....3..312....\n"
".2.2331.1.2.....3.\n"
".321...13...313...\n"
".2..21.2...212.3.1\n"
".1..1.1233..1...22\n"
".313....3.3.1.....\n") == 0);
free(board334326919);
board334326919 = NULL;
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_free_fields(board, 1) == 165 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_free_fields(board, 2) == 165 );


char* board201929019 = gamma_board(board);
assert( board201929019 != NULL );
assert( strcmp(board201929019, 
".2..3.21.2.3.....1\n"
".222.3...3122...2.\n"
".3113..2.2..13....\n"
"1...311.2...2..31.\n"
"......3...112.....\n"
"3..3123.1.3..3....\n"
".1...3...3233.....\n"
"......3..3....211.\n"
"....1.2221.11.1.2.\n"
"..21.11322.3.2.1.1\n"
"1221....3..312....\n"
".2.2331.1.2.....3.\n"
".321...13...313...\n"
".2..21.2...212.3.1\n"
".1..1.1233..1...22\n"
".313....3.3.1.....\n") == 0);
free(board201929019);
board201929019 = NULL;
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_golden_move(board, 3, 8, 16) == 0 );
assert( gamma_move(board, 1, 13, 11) == 1 );
assert( gamma_free_fields(board, 1) == 164 );
assert( gamma_golden_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 3, 7, 17) == 0 );
assert( gamma_move(board, 3, 9, 12) == 1 );


char* board633450315 = gamma_board(board);
assert( board633450315 != NULL );
assert( strcmp(board633450315, 
".2..3.21.2.3.....1\n"
".222.3...3122...2.\n"
".3113..2.2..13....\n"
"1...311.23..2..31.\n"
"......3...1121....\n"
"3..3123.1.3..3....\n"
".1...3...3233.....\n"
"......3..3....211.\n"
"....1.2221.11.1.2.\n"
"..21.11322.3.2.1.1\n"
"1221....3..312....\n"
".2.2331.1.2.....3.\n"
".321...13...313...\n"
".2..21.2...212.3.1\n"
".1..1.1233..1...22\n"
".313....3.3.1.....\n") == 0);
free(board633450315);
board633450315 = NULL;
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 2, 7, 9) == 1 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 40 );


char* board794716319 = gamma_board(board);
assert( board794716319 != NULL );
assert( strcmp(board794716319, 
".2..3.21.2.3.....1\n"
".222.3...3122...2.\n"
".3113..2.2..13....\n"
"1...311.23..2..31.\n"
"......3...1121....\n"
"3..3123.1.3..3....\n"
".1...3.2.3233.....\n"
"......3..3....211.\n"
"....1.2221.11.1.2.\n"
"..21.11322.3.2.1.1\n"
"1221....3..312....\n"
".2.2331.1.2.....3.\n"
".321...13...313...\n"
".2..21.2...212.3.1\n"
".1..1.1233..1...22\n"
".313....3.3.1.....\n") == 0);
free(board794716319);
board794716319 = NULL;
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 2, 14, 0) == 1 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_free_fields(board, 3) == 160 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_golden_move(board, 2, 8, 9) == 0 );


char* board991720336 = gamma_board(board);
assert( board991720336 != NULL );
assert( strcmp(board991720336, 
".2..3.21.2.3.....1\n"
".222.3...3122...2.\n"
".3113..2.2..13....\n"
"1...311.23..2..31.\n"
"......3...1121....\n"
"3..3123.1.3..3....\n"
".1...3.2.3233.....\n"
"......3..3....211.\n"
"....1.2221.11.1.2.\n"
"..21.11322.3.2.1.1\n"
"1221.1..3..312....\n"
".2.2331.1.2.....3.\n"
"1321...13...313...\n"
".2..21.2...212.3.1\n"
".1..1.1233..1...22\n"
".313....3.3.1.2...\n") == 0);
free(board991720336);
board991720336 = NULL;
assert( gamma_move(board, 3, 14, 6) == 1 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 42 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 0) == 1 );
assert( gamma_move(board, 3, 17, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 13, 15) == 1 );
assert( gamma_busy_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_free_fields(board, 2) == 154 );
assert( gamma_golden_move(board, 2, 3, 13) == 1 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 3, 13, 0) == 1 );
assert( gamma_golden_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_golden_move(board, 2, 6, 5) == 0 );


char* board861600417 = gamma_board(board);
assert( board861600417 != NULL );
assert( strcmp(board861600417, 
".2..3.21.2.3.1...1\n"
".222.3...31221..2.\n"
".3123..2.2..13....\n"
"1...311.23..2..31.\n"
"......3...1121....\n"
"3..3123.1.3..3....\n"
".1...3.2.3233.....\n"
"......3..3....211.\n"
"....1.2221.11.1.23\n"
"..21.11322.3.231.1\n"
"1221.1..3..312....\n"
".2.2331.1.2.....3.\n"
"1321...13...313...\n"
".2..21.2...212.3.1\n"
".1..1.1233..1...22\n"
".313....3.33132...\n") == 0);
free(board861600417);
board861600417 = NULL;
assert( gamma_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 45 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 2, 3, 15) == 1 );
assert( gamma_move(board, 2, 11, 13) == 1 );
assert( gamma_move(board, 3, 3, 16) == 0 );
assert( gamma_move(board, 1, 11, 16) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 14, 4) == 1 );
assert( gamma_golden_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_free_fields(board, 3) == 148 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_move(board, 3, 2, 15) == 1 );
assert( gamma_free_fields(board, 3) == 146 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );


char* board162423341 = gamma_board(board);
assert( board162423341 != NULL );
assert( strcmp(board162423341, 
".2323.21.2.3.1...1\n"
".222.3...31221..2.\n"
".3123..2.2.213....\n"
"1...311.23..2..31.\n"
"......3...1121....\n"
"3..3123.1.3..3....\n"
".1...312.3233.....\n"
"......3.33....211.\n"
"....1.2221.11.1.23\n"
"..21.11322.3.231.1\n"
"1221.1..3..312....\n"
".2.2331.1.2...2.3.\n"
"13211..13...313...\n"
".2..21.2...212.3.1\n"
".1..1.1233..1...22\n"
".313....3.33132...\n") == 0);
free(board162423341);
board162423341 = NULL;
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_move(board, 2, 15, 15) == 1 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 2, 11, 3) == 1 );
assert( gamma_move(board, 3, 17, 0) == 1 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 1, 10, 1) == 1 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 6, 15) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 17, 12) == 1 );
assert( gamma_move(board, 3, 16, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_move(board, 3, 10, 2) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_free_fields(board, 3) == 138 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_move(board, 1, 16, 11) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 12, 11) == 0 );


char* board936600579 = gamma_board(board);
assert( board936600579 != NULL );
assert( strcmp(board936600579, 
".2323.21.2.3.1.2.1\n"
".222.3...31221..2.\n"
".3123..232.213....\n"
"1...311.23..2..312\n"
"......3...1121..1.\n"
"3..3123.1.3..3....\n"
".1...312.3233.....\n"
"......3.33....211.\n"
"....1.2221.11.1.23\n"
"..21.11322.3.231.1\n"
"1221.1..3..312....\n"
".2.2331.1.2...2.3.\n"
"13211..13..2313...\n"
".2..21.2..3212.331\n"
".1..1.12331.1...22\n"
".313....3.33132..3\n") == 0);
free(board936600579);
board936600579 = NULL;
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 3, 17, 13) == 1 );


char* board783717991 = gamma_board(board);
assert( board783717991 != NULL );
assert( strcmp(board783717991, 
".2323.21.2.3.1.2.1\n"
".222.3...31221..2.\n"
".3123..232.213...3\n"
"1...311.23..2..312\n"
"......3...1121..1.\n"
"3..312331.3..3....\n"
".1...312.3233.....\n"
"......3.33....211.\n"
"....1.2221.11.1.23\n"
"..21.11322.3.231.1\n"
"1221.1..3..312....\n"
".2.2331.1.2...2.3.\n"
"13211..13..2313...\n"
".2..21.2..3212.331\n"
".1..1.12331.1...22\n"
".313....3233132..3\n") == 0);
free(board783717991);
board783717991 = NULL;
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_golden_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 14, 2) == 1 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 1, 11, 15) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 3, 15, 0) == 1 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 1, 9, 11) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_golden_move(board, 2, 6, 14) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 54 );
assert( gamma_move(board, 1, 5, 7) == 1 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 2, 14, 15) == 1 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_golden_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 1, 9, 17) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_free_fields(board, 2) == 124 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 1, 11, 10) == 1 );
assert( gamma_move(board, 1, 9, 5) == 1 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 56 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 2, 12, 10) == 1 );
assert( gamma_free_fields(board, 2) == 120 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board312114678 = gamma_board(board);
assert( board312114678 != NULL );
assert( strcmp(board312114678, 
".2323.21.2.3.122.1\n"
".22233...31221..2.\n"
".3123..232.213...3\n"
"1...311.23..2..312\n"
"..2...3..11121..1.\n"
"3..312331.3123....\n"
".1.2.312.3233.....\n"
"...2..3.33....211.\n"
"....112221.11.1.23\n"
"..21.11322.3.231.1\n"
"1221.1..31.312....\n"
".2.2331.1.2...2.3.\n"
"13211..13..2313...\n"
"12..21.2..32122331\n"
".1..1.12331.1...22\n"
"23133...32331323.3\n") == 0);
free(board312114678);
board312114678 = NULL;
assert( gamma_move(board, 1, 14, 14) == 1 );
assert( gamma_move(board, 1, 17, 9) == 1 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 15) == 1 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 2, 14, 12) == 1 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 3, 6, 13) == 1 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_move(board, 3, 12, 8) == 1 );
assert( gamma_move(board, 1, 5, 17) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_free_fields(board, 3) == 111 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 60 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 1, 13, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 61 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 10, 16) == 0 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_move(board, 2, 6, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 60 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 15) == 1 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 1, 3, 17) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 2, 14, 15) == 0 );


char* board206347861 = gamma_board(board);
assert( board206347861 != NULL );
assert( strcmp(board206347861, 
".2323321.233.122.1\n"
".22233...312211.2.\n"
".3123.3232.213...3\n"
"1...311.23..2.2312\n"
".32...31.11121..1.\n"
"3..312331.3123....\n"
".1.2.31223233....1\n"
"...2..3.33..31211.\n"
"....112221.11.1.23\n"
"..21.11322.3.231.1\n"
"1221.1..31.312....\n"
".2.2331.1.2...2.3.\n"
"13211..132.2313...\n"
"12..21.2..32122331\n"
".1..1.12331.1...22\n"
"23133.1.32331323.3\n") == 0);
free(board206347861);
board206347861 = NULL;
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 3, 14, 17) == 0 );
assert( gamma_move(board, 3, 15, 5) == 1 );
assert( gamma_move(board, 1, 13, 13) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 17, 6) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );


char* board893436009 = gamma_board(board);
assert( board893436009 != NULL );
assert( strcmp(board893436009, 
".2323321.233.122.1\n"
".22233...312211.2.\n"
".3123.3232.213...3\n"
"1...311.23..2.2312\n"
".32...31.11121..1.\n"
"3..312331.3123....\n"
".1.2.31223233....1\n"
"...2..3.33..31211.\n"
"....112221.11.1.23\n"
"..21.11322.3.231.1\n"
"1221.1..31.312.3..\n"
".2.2331.1.2...2.3.\n"
"13211..132.2313...\n"
"12..21.2..32122331\n"
".1..1.12331.1...22\n"
"23133.1.32331323.3\n") == 0);
free(board893436009);
board893436009 = NULL;
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_move(board, 1, 14, 9) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_golden_move(board, 2, 9, 9) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 1, 17, 12) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_golden_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_free_fields(board, 3) == 100 );
assert( gamma_move(board, 1, 3, 16) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 3, 10, 17) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 2, 12, 12) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 62 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 3, 12, 12) == 0 );
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 3, 17, 2) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_golden_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 2, 14, 11) == 1 );
assert( gamma_move(board, 2, 10, 7) == 1 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 1, 17, 15) == 0 );


char* board739628232 = gamma_board(board);
assert( board739628232 != NULL );
assert( strcmp(board739628232, 
"22323321.233.122.1\n"
".22233...312211.2.\n"
".3123.3232.213...3\n"
"1...311.23..2.2312\n"
".32...31.111212.1.\n"
"3..312331.3123....\n"
".1.2.31223233.1..1\n"
"...2..3.33..31211.\n"
"....112221211.1.23\n"
".321.11322.3.231.1\n"
"1221.1..311312.3..\n"
".222331.1.2...2.3.\n"
"13211..132.2313...\n"
"121221.22232122331\n"
".1..1.12331.1...22\n"
"23133.1.32331323.3\n") == 0);
free(board739628232);
board739628232 = NULL;
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 16, 13) == 1 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 65 );
assert( gamma_free_fields(board, 1) == 93 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 9, 15) == 0 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_golden_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_free_fields(board, 3) == 93 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 3, 17, 5) == 1 );
assert( gamma_move(board, 1, 5, 13) == 1 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 1, 13, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 67 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 15, 16) == 0 );
assert( gamma_move(board, 3, 16, 15) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_move(board, 1, 5, 1) == 1 );
assert( gamma_free_fields(board, 1) == 87 );


char* board218164522 = gamma_board(board);
assert( board218164522 != NULL );
assert( strcmp(board218164522, 
"22323321.233.12231\n"
".22233...312211.2.\n"
".312313232.213..33\n"
"1...311.23..212312\n"
".32...31.111212.1.\n"
"3..312331.3123....\n"
".1.2.31223233.1..1\n"
"...2..3.33..31211.\n"
"....112221211.1.23\n"
".321.11322.3.231.1\n"
"1221.1..311312.3.3\n"
".222331.122...2.3.\n"
"13211..132.2313...\n"
"121221.22232122331\n"
".1..1112331.1...22\n"
"23133.1.32331323.3\n") == 0);
free(board218164522);
board218164522 = NULL;
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_free_fields(board, 2) == 86 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 66 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );


char* board797197714 = gamma_board(board);
assert( board797197714 != NULL );
assert( strcmp(board797197714, 
"22323321.233.12231\n"
".22233...312211.2.\n"
".312313232.213..33\n"
"1...311.23..212312\n"
".32...31.111212.1.\n"
"3..312331.3123....\n"
".1.2.31223233.1..1\n"
"...2..3.33..31211.\n"
"..3.112221211.1.23\n"
".321.11322.3.231.1\n"
"1221.1..311312.3.3\n"
".222331.1222..2.3.\n"
"13211..132.2313...\n"
"121221.22232122331\n"
".1..1112331.1...22\n"
"23133.1.32331323.3\n") == 0);
free(board797197714);
board797197714 = NULL;
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 16, 13) == 0 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_move(board, 2, 10, 15) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );


char* board996405183 = gamma_board(board);
assert( board996405183 != NULL );
assert( strcmp(board996405183, 
"22323321.233.12231\n"
".22233...312211.2.\n"
".312313232.213..33\n"
"1...311.23..212312\n"
".32...31.111212.1.\n"
"3..312331.3123....\n"
".1.2.31223233.1..1\n"
"...2..3.33..31211.\n"
"..3.112221211.1.23\n"
".321.11322.3.231.1\n"
"1221.1..311312.3.3\n"
".222331.1222..2.3.\n"
"13211..132.2313...\n"
"121221.22232122331\n"
".1..1112331.1...22\n"
"23133.1.32331323.3\n") == 0);
free(board996405183);
board996405183 = NULL;
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 15, 11) == 1 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 69 );
assert( gamma_move(board, 3, 16, 9) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 69 );
assert( gamma_free_fields(board, 2) == 83 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 69 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_free_fields(board, 3) == 49 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 70 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_free_fields(board, 2) == 81 );
assert( gamma_move(board, 3, 15, 1) == 1 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_busy_fields(board, 1) == 70 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 3, 13, 9) == 1 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 1, 17, 6) == 0 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_busy_fields(board, 3) == 71 );
assert( gamma_move(board, 1, 11, 11) == 0 );
assert( gamma_move(board, 2, 13, 13) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 1, 16, 0) == 1 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 14, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 71 );
assert( gamma_free_fields(board, 3) == 75 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 2, 8, 14) == 1 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 15) == 0 );
assert( gamma_golden_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 2, 10, 17) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_free_fields(board, 3) == 43 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 72 );
assert( gamma_free_fields(board, 2) == 72 );
assert( gamma_move(board, 3, 9, 15) == 0 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 17, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 17, 7) == 0 );
assert( gamma_free_fields(board, 1) == 72 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_move(board, 1, 14, 1) == 1 );
assert( gamma_move(board, 2, 9, 16) == 0 );
assert( gamma_move(board, 2, 12, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 73 );


char* board859616413 = gamma_board(board);
assert( board859616413 != NULL );
assert( strcmp(board859616413, 
"22323321.233.12231\n"
"122233.32312211.2.\n"
".312313232.213..33\n"
"11..311.23..212312\n"
"232..331.11121231.\n"
"3..312331.3123....\n"
".1.2.3122323331..1\n"
"...2..3.33..31211.\n"
"..3.112221211.1.23\n"
".321311322.32231.1\n"
"1221.1..311312.3.3\n"
".222331.1222..2.3.\n"
"132111.132.2313...\n"
"121221.22232122331\n"
".1..111233121.1322\n"
"23133.1.3233132313\n") == 0);
free(board859616413);
board859616413 = NULL;
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 74 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 2, 14, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 3, 16, 12) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_free_fields(board, 1) == 69 );
assert( gamma_move(board, 2, 8, 17) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 3, 10, 14) == 0 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 1, 14, 17) == 0 );
assert( gamma_move(board, 2, 14, 13) == 1 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_free_fields(board, 1) == 68 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_free_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 73 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 8, 17) == 0 );
assert( gamma_move(board, 3, 17, 10) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_free_fields(board, 3) == 40 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_move(board, 3, 10, 8) == 1 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_free_fields(board, 2) == 66 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 73 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 73 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 73 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_free_fields(board, 3) == 38 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 17, 9) == 0 );
assert( gamma_move(board, 2, 14, 10) == 1 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 1, 16, 11) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 77 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 13, 13) == 0 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_move(board, 2, 17, 7) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_move(board, 2, 13, 15) == 0 );
assert( gamma_move(board, 3, 2, 15) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 3, 16, 13) == 0 );
assert( gamma_move(board, 3, 16, 3) == 1 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 15, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 79 );
assert( gamma_move(board, 3, 10, 16) == 0 );
assert( gamma_free_fields(board, 3) == 60 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 17, 4) == 1 );
assert( gamma_golden_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 12, 14) == 0 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 76 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 3, 16, 7) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 2, 7, 6) == 0 );


char* board818726071 = gamma_board(board);
assert( board818726071 != NULL );
assert( strcmp(board818726071, 
"22323321.233.12231\n"
"122233.32312211.2.\n"
".312313232.2132.33\n"
"112.311.23..212312\n"
"232..331211121231.\n"
"3..312331.312322..\n"
"11.2.3122323331..1\n"
"...22.3.333.31211.\n"
"..3.112221211.1.23\n"
".321311322.32231.1\n"
"1221.12.311312.3.3\n"
".222331.12221.2.31\n"
"132111.132.2313.3.\n"
"121221.22232122331\n"
".1..111233121.1322\n"
"2313321.3233132313\n") == 0);
free(board818726071);
board818726071 = NULL;
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 15, 8) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_move(board, 1, 12, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 77 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 14, 15) == 0 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 74 );
assert( gamma_move(board, 1, 11, 17) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_free_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 81 );
assert( gamma_free_fields(board, 2) == 56 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 75 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 10, 17) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 77 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 8, 17) == 0 );
assert( gamma_free_fields(board, 3) == 55 );


char* board965547892 = gamma_board(board);
assert( board965547892 != NULL );
assert( strcmp(board965547892, 
"22323321.233.12231\n"
"122233.32312211.2.\n"
".312313232.2132.33\n"
"112.311.23..212312\n"
"232..331211121231.\n"
"3..312331.312322..\n"
"11.2.3122323331..1\n"
"...22.3.333.31211.\n"
"..3.112221211.1.23\n"
".321311322.32231.1\n"
"1221.12.311312.3.3\n"
".222331.12221.2.31\n"
"1321111132.2313.3.\n"
"121221.22232122331\n"
".1..111233121.1322\n"
"231332133233132313\n") == 0);
free(board965547892);
board965547892 = NULL;
assert( gamma_move(board, 1, 6, 6) == 0 );


char* board105584696 = gamma_board(board);
assert( board105584696 != NULL );
assert( strcmp(board105584696, 
"22323321.233.12231\n"
"122233.32312211.2.\n"
".312313232.2132.33\n"
"112.311.23..212312\n"
"232..331211121231.\n"
"3..312331.312322..\n"
"11.2.3122323331..1\n"
"...22.3.333.31211.\n"
"..3.112221211.1.23\n"
".321311322.32231.1\n"
"1221.12.311312.3.3\n"
".222331.12221.2.31\n"
"1321111132.2313.3.\n"
"121221.22232122331\n"
".1..111233121.1322\n"
"231332133233132313\n") == 0);
free(board105584696);
board105584696 = NULL;
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 3, 3, 17) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 1, 16, 15) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 2, 6, 16) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 17, 13) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 1, 16, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );


char* board771460268 = gamma_board(board);
assert( board771460268 != NULL );
assert( strcmp(board771460268, 
"22323321.233.12231\n"
"122233.32312211.2.\n"
".312313232.2132.33\n"
"112.311.23..212312\n"
"232..331211121231.\n"
"3..312331.312322..\n"
"11.2.3122323331..1\n"
"...22.3.333.31211.\n"
"..3.112221211.1.23\n"
".321311322.32231.1\n"
"1221.12.311312.313\n"
".222331312221.2.31\n"
"1321111132.2313.3.\n"
"121221.22232122331\n"
".1..111233121.1322\n"
"231332133233132313\n") == 0);
free(board771460268);
board771460268 = NULL;
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_golden_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 76 );
assert( gamma_busy_fields(board, 1) == 78 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 16, 9) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 11, 17) == 0 );
assert( gamma_move(board, 2, 9, 9) == 0 );


char* board859351348 = gamma_board(board);
assert( board859351348 != NULL );
assert( strcmp(board859351348, 
"22323321.233.12231\n"
"122233.32312211.2.\n"
".312313232.2132.33\n"
"112.311.23..212312\n"
"232..331211121231.\n"
"3..312331.312322..\n"
"11.2.3122323331..1\n"
"...22.3.333.31211.\n"
"..3.112221211.1.23\n"
".321311322.32231.1\n"
"1221.12.311312.313\n"
".222331312221.2.31\n"
"1321111132.2313.3.\n"
"121221.22232122331\n"
".1..111233121.1322\n"
"231332133233132313\n") == 0);
free(board859351348);
board859351348 = NULL;
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 15, 11) == 0 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 1, 14, 14) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 78 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board884306130 = gamma_board(board);
assert( board884306130 != NULL );
assert( strcmp(board884306130, 
"22323321.233.12231\n"
"122233.32312211.2.\n"
".312313232.2132.33\n"
"112.311.23..212312\n"
"232..331211121231.\n"
"3..312331.312322..\n"
"11.2.3122323331..1\n"
"...22.3.333.31211.\n"
"..3.112221211.1.23\n"
".321311322.32231.1\n"
"1221.12.311312.313\n"
".222331312221.2.31\n"
"1321111132.2313.3.\n"
"121221.22232122331\n"
".1..111233121.1322\n"
"231332133233132313\n") == 0);
free(board884306130);
board884306130 = NULL;
assert( gamma_move(board, 2, 17, 13) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 15, 8) == 0 );
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_golden_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 8, 17) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 1, 11, 8) == 1 );


char* board664457219 = gamma_board(board);
assert( board664457219 != NULL );
assert( strcmp(board664457219, 
"22323321.233.12231\n"
"122233.32312211.2.\n"
".312313232.2132.33\n"
"112.311.23..212312\n"
"232..331211121231.\n"
"3..312331.312322..\n"
"11.2.3122323331..1\n"
"...22.3.333131211.\n"
"..3.112221211.1.23\n"
".321311322.32231.1\n"
"1221.12.311312.313\n"
".222331312221.2.31\n"
"1321111132.2313.3.\n"
"121221.22232122331\n"
".1..111233121.1322\n"
"231332133233132313\n") == 0);
free(board664457219);
board664457219 = NULL;
assert( gamma_move(board, 2, 11, 14) == 0 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );


gamma_delete(board);

    return 0;
}
