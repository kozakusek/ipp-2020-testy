#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 137539638
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(9, 16, 7, 19);
assert( board != NULL );


assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_move(board, 1, 1, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_free_fields(board, 2) == 140 );
assert( gamma_move(board, 3, 6, 15) == 1 );
assert( gamma_move(board, 4, 5, 0) == 1 );
assert( gamma_move(board, 4, 3, 14) == 1 );
assert( gamma_move(board, 5, 6, 11) == 1 );


char* board406845532 = gamma_board(board);
assert( board406845532 != NULL );
assert( strcmp(board406845532, 
"......3..\n"
"...4.....\n"
".........\n"
".........\n"
"......5..\n"
".........\n"
".2.......\n"
"11.......\n"
".........\n"
".........\n"
".........\n"
".........\n"
".........\n"
".......2.\n"
".........\n"
".....4...\n") == 0);
free(board406845532);
board406845532 = NULL;
assert( gamma_move(board, 6, 0, 1) == 1 );
assert( gamma_busy_fields(board, 6) == 1 );
assert( gamma_move(board, 7, 2, 12) == 1 );
assert( gamma_free_fields(board, 7) == 134 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 2, 7, 5) == 1 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_move(board, 3, 1, 10) == 1 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_move(board, 5, 6, 15) == 0 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_move(board, 6, 4, 4) == 1 );
assert( gamma_move(board, 7, 4, 7) == 1 );
assert( gamma_move(board, 7, 4, 4) == 0 );
assert( gamma_move(board, 1, 1, 14) == 1 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_free_fields(board, 3) == 122 );
assert( gamma_move(board, 4, 2, 6) == 1 );
assert( gamma_free_fields(board, 5) == 121 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 4, 2) == 1 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_free_fields(board, 3) == 117 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 4) == 1 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 5, 6, 13) == 1 );
assert( gamma_move(board, 6, 2, 4) == 1 );
assert( gamma_move(board, 6, 5, 1) == 1 );
assert( gamma_busy_fields(board, 6) == 5 );
assert( gamma_golden_move(board, 6, 7, 4) == 0 );
assert( gamma_move(board, 7, 8, 1) == 1 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 2, 15, 8) == 0 );
assert( gamma_free_fields(board, 2) == 111 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_free_fields(board, 3) == 110 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 4, 5, 12) == 1 );
assert( gamma_move(board, 5, 0, 7) == 1 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 7, 3, 8) == 1 );
assert( gamma_move(board, 7, 3, 1) == 1 );
assert( gamma_move(board, 1, 7, 15) == 1 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_free_fields(board, 2) == 105 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 2) == 1 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_move(board, 6, 1, 1) == 1 );
assert( gamma_move(board, 7, 11, 2) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_free_fields(board, 3) == 100 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 3, 11) == 1 );


char* board324819732 = gamma_board(board);
assert( board324819732 != NULL );
assert( strcmp(board324819732, 
"......31.\n"
"31.4.....\n"
"......5..\n"
"..72.4...\n"
"...4..5..\n"
".3.......\n"
".2.......\n"
"1137.....\n"
"54..7...4\n"
"..4..5.1.\n"
".....4.2.\n"
"3.6.6.4.3\n"
"......1..\n"
".2.56..22\n"
"66.7.6..7\n"
"2..3.4...\n") == 0);
free(board324819732);
board324819732 = NULL;
assert( gamma_move(board, 5, 6, 12) == 1 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 6, 13, 3) == 0 );
assert( gamma_move(board, 7, 3, 8) == 0 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_free_fields(board, 1) == 96 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 1, 12) == 1 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_move(board, 6, 11, 5) == 0 );
assert( gamma_move(board, 7, 5, 3) == 1 );
assert( gamma_move(board, 7, 7, 12) == 1 );
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_move(board, 5, 8, 5) == 0 );


char* board717508022 = gamma_board(board);
assert( board717508022 != NULL );
assert( strcmp(board717508022, 
"2.....31.\n"
"31.4.....\n"
"......5..\n"
".472.457.\n"
"...4..5..\n"
".3.......\n"
".24..4...\n"
"1137.....\n"
"54..7...4\n"
".54..511.\n"
".....4.22\n"
"3.6.6.4.3\n"
".....71..\n"
".2.56..22\n"
"66.7.6..7\n"
"2..3.4.1.\n") == 0);
free(board717508022);
board717508022 = NULL;
assert( gamma_move(board, 6, 4, 3) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 8, 3) == 1 );
assert( gamma_golden_move(board, 7, 12, 3) == 0 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_free_fields(board, 1) == 85 );
assert( gamma_move(board, 2, 1, 15) == 1 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 14, 7) == 0 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 7 );


char* board673581049 = gamma_board(board);
assert( board673581049 != NULL );
assert( strcmp(board673581049, 
"22....31.\n"
"31.4.....\n"
"......5.3\n"
".472.457.\n"
"...4..5..\n"
".3.......\n"
".24..4...\n"
"1137..1..\n"
"54..7...4\n"
".54..511.\n"
".....4.22\n"
"3.6.6.4.3\n"
"....671.7\n"
".2.56..22\n"
"66.7.6..7\n"
"2..3.4.1.\n") == 0);
free(board673581049);
board673581049 = NULL;
assert( gamma_move(board, 7, 15, 3) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 15, 8) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_move(board, 5, 0, 9) == 1 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_move(board, 6, 3, 13) == 1 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 2, 4, 10) == 1 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_free_fields(board, 4) == 80 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 5, 2, 12) == 0 );
assert( gamma_move(board, 6, 9, 7) == 0 );
assert( gamma_move(board, 7, 10, 5) == 0 );
assert( gamma_move(board, 7, 7, 8) == 1 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_golden_move(board, 7, 11, 6) == 0 );


char* board501755673 = gamma_board(board);
assert( board501755673 != NULL );
assert( strcmp(board501755673, 
"22....31.\n"
"31.4.....\n"
"...6..5.3\n"
".472.457.\n"
"...4..5..\n"
".3..2....\n"
"524..4...\n"
"1137..17.\n"
"54..7...4\n"
".54..511.\n"
".....4.22\n"
"3.6.6.4.3\n"
"....671.7\n"
".2.56..22\n"
"66.7.6..7\n"
"2..3.4.1.\n") == 0);
free(board501755673);
board501755673 = NULL;
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_free_fields(board, 1) == 79 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 0, 13) == 1 );
assert( gamma_free_fields(board, 3) == 78 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 5, 2, 15) == 1 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_move(board, 7, 11, 1) == 0 );
assert( gamma_move(board, 7, 4, 4) == 0 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );


char* board394241682 = gamma_board(board);
assert( board394241682 != NULL );
assert( strcmp(board394241682, 
"225...31.\n"
"31.4.....\n"
"2..6..5.3\n"
".472.457.\n"
"...4..5..\n"
".3..2....\n"
"524..4...\n"
"1137..174\n"
"54..7...4\n"
"254..511.\n"
".....4.22\n"
"3.6.6.4.3\n"
"....671.7\n"
".2.561.22\n"
"66.7.6..7\n"
"2..3.4.1.\n") == 0);
free(board394241682);
board394241682 = NULL;
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_move(board, 5, 0, 12) == 1 );
assert( gamma_move(board, 6, 7, 11) == 1 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 8, 14) == 1 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 5, 0, 5) == 1 );
assert( gamma_busy_fields(board, 5) == 11 );
assert( gamma_move(board, 6, 5, 9) == 0 );
assert( gamma_move(board, 6, 2, 1) == 1 );
assert( gamma_move(board, 7, 14, 7) == 0 );
assert( gamma_move(board, 7, 1, 13) == 1 );
assert( gamma_free_fields(board, 7) == 65 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_move(board, 6, 6, 2) == 1 );
assert( gamma_free_fields(board, 6) == 59 );
assert( gamma_move(board, 7, 13, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_free_fields(board, 7) == 59 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_busy_fields(board, 5) == 11 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_golden_move(board, 7, 4, 2) == 1 );


char* board455604277 = gamma_board(board);
assert( board455604277 != NULL );
assert( strcmp(board455604277, 
"225...31.\n"
"31.4....3\n"
"27.6..5.3\n"
"5472.457.\n"
"...4..564\n"
"33..2.2..\n"
"524..42..\n"
"1137..174\n"
"54..7...4\n"
"254..511.\n"
"5....4.22\n"
"3.6.6.4.3\n"
"....671.7\n"
".24571622\n"
"666746.47\n"
"2.13.4211\n") == 0);
free(board455604277);
board455604277 = NULL;
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_move(board, 5, 3, 7) == 1 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 9, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 4, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 5, 2, 3) == 1 );
assert( gamma_move(board, 6, 13, 7) == 0 );
assert( gamma_move(board, 7, 5, 2) == 0 );
assert( gamma_move(board, 7, 3, 3) == 1 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_move(board, 6, 0, 13) == 0 );
assert( gamma_move(board, 6, 1, 5) == 1 );
assert( gamma_move(board, 7, 3, 7) == 0 );
assert( gamma_move(board, 7, 5, 9) == 0 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 5, 4, 5) == 1 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_move(board, 6, 11, 5) == 0 );
assert( gamma_move(board, 7, 2, 11) == 1 );
assert( gamma_move(board, 7, 3, 4) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 3, 15) == 1 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 5, 6, 4) == 0 );
assert( gamma_move(board, 6, 10, 3) == 0 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 7, 12, 4) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 4, 6) == 1 );


char* board268647976 = gamma_board(board);
assert( board268647976 != NULL );
assert( strcmp(board268647976, 
"2253..31.\n"
"31.4....3\n"
"27.6..5.3\n"
"5472.457.\n"
"..74..564\n"
"33..2.2.2\n"
"524..42..\n"
"1137..174\n"
"54.57...4\n"
"254.1511.\n"
"56..54.22\n"
"3.646.4.3\n"
"3.57671.7\n"
"224571622\n"
"666746.47\n"
"2.1344211\n") == 0);
free(board268647976);
board268647976 = NULL;
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 4, 1, 3) == 1 );


char* board706908840 = gamma_board(board);
assert( board706908840 != NULL );
assert( strcmp(board706908840, 
"2253..31.\n"
"31.4....3\n"
"27.6..5.3\n"
"5472.457.\n"
"..74..564\n"
"33..2.2.2\n"
"524..42..\n"
"1137..174\n"
"54.57...4\n"
"254.1511.\n"
"56..54.22\n"
"3.646.4.3\n"
"3457671.7\n"
"224571622\n"
"666746.47\n"
"2.1344211\n") == 0);
free(board706908840);
board706908840 = NULL;
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 7, 10) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_move(board, 6, 7, 15) == 0 );
assert( gamma_move(board, 7, 3, 12) == 0 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 4, 7, 9) == 1 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 7, 6, 1) == 1 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 5, 15) == 1 );
assert( gamma_move(board, 7, 6, 7) == 1 );
assert( gamma_move(board, 7, 4, 9) == 1 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_free_fields(board, 2) == 36 );
assert( gamma_move(board, 4, 2, 13) == 1 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 3, 7) == 0 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 7, 4, 7) == 0 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 5, 0, 14) == 0 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_move(board, 6, 3, 9) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_move(board, 7, 5, 11) == 1 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 4, 14, 6) == 0 );
assert( gamma_move(board, 4, 4, 14) == 1 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 15, 8) == 0 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 7, 3, 14) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_golden_move(board, 1, 1, 2) == 1 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 5, 2, 7) == 1 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 2, 1, 11) == 1 );
assert( gamma_move(board, 2, 0, 8) == 0 );


char* board916474681 = gamma_board(board);
assert( board916474681 != NULL );
assert( strcmp(board916474681, 
"2253.631.\n"
"31.44...3\n"
"2746..5.3\n"
"5472.457.\n"
".274.7564\n"
"33..2.252\n"
"52467424.\n"
"1137..174\n"
"54557.734\n"
"254.1511.\n"
"56.154.22\n"
"3.64624.3\n"
"3457671.7\n"
"214571622\n"
"666746747\n"
"2.1344211\n") == 0);
free(board916474681);
board916474681 = NULL;
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 6, 14, 7) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 13, 5) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_free_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_free_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 4, 4) == 0 );
assert( gamma_move(board, 5, 7, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_free_fields(board, 5) == 28 );
assert( gamma_move(board, 6, 1, 11) == 0 );
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 7, 12, 8) == 0 );
assert( gamma_free_fields(board, 7) == 28 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_free_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 5, 14) == 1 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 7, 4, 15) == 1 );
assert( gamma_move(board, 7, 2, 8) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 3, 15) == 0 );


char* board589508907 = gamma_board(board);
assert( board589508907 != NULL );
assert( strcmp(board589508907, 
"22537631.\n"
"31.444..3\n"
"2746..5.3\n"
"5472.457.\n"
".274.7564\n"
"33.12.252\n"
"52467424.\n"
"1137..174\n"
"54557.734\n"
"254.1511.\n"
"56.154.22\n"
"3.64624.3\n"
"3457671.7\n"
"214571622\n"
"666746747\n"
"2.1344211\n") == 0);
free(board589508907);
board589508907 = NULL;
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_free_fields(board, 4) == 17 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 7, 5, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 18 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 6, 3, 13) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );


char* board487369565 = gamma_board(board);
assert( board487369565 != NULL );
assert( strcmp(board487369565, 
"22537631.\n"
"31.444..3\n"
"2746..5.3\n"
"5472.457.\n"
".274.7564\n"
"33.12.252\n"
"52467424.\n"
"1137..174\n"
"54557.734\n"
"254.1511.\n"
"56.154.22\n"
"3.64624.3\n"
"3457671.7\n"
"214571622\n"
"666746747\n"
"2.1344211\n") == 0);
free(board487369565);
board487369565 = NULL;
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_free_fields(board, 4) == 17 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 4) == 0 );
assert( gamma_move(board, 5, 4, 15) == 0 );
assert( gamma_move(board, 6, 11, 0) == 0 );
assert( gamma_move(board, 7, 5, 5) == 0 );
assert( gamma_move(board, 7, 1, 2) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_golden_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );


char* board710156850 = gamma_board(board);
assert( board710156850 != NULL );
assert( strcmp(board710156850, 
"22537631.\n"
"31.444..3\n"
"2746..5.3\n"
"5472.457.\n"
".274.7564\n"
"33.12.252\n"
"52467424.\n"
"1137..174\n"
"54557.734\n"
"254.1511.\n"
"56.154.22\n"
"3.64624.3\n"
"3457671.7\n"
"214571622\n"
"626746747\n"
"2.1344211\n") == 0);
free(board710156850);
board710156850 = NULL;
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_move(board, 6, 8, 12) == 1 );
assert( gamma_move(board, 1, 8, 15) == 1 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_free_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 7, 0, 3) == 0 );
assert( gamma_free_fields(board, 7) == 23 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );


char* board944292614 = gamma_board(board);
assert( board944292614 != NULL );
assert( strcmp(board944292614, 
"225376311\n"
"31.444..3\n"
"2746..5.3\n"
"5472.4576\n"
".274.7564\n"
"33.12.252\n"
"52467424.\n"
"1137..174\n"
"54557.734\n"
"254.1511.\n"
"56.154.22\n"
"3.64624.3\n"
"3457671.7\n"
"214571622\n"
"626746747\n"
"2.1344211\n") == 0);
free(board944292614);
board944292614 = NULL;
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 6, 0, 11) == 1 );
assert( gamma_free_fields(board, 6) == 22 );
assert( gamma_move(board, 7, 3, 4) == 0 );
assert( gamma_free_fields(board, 7) == 22 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_golden_move(board, 5, 5, 3) == 1 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 6, 14) == 1 );
assert( gamma_free_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_golden_move(board, 5, 1, 7) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 13, 7) == 0 );
assert( gamma_move(board, 7, 0, 14) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 5, 5, 13) == 1 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 1, 0) == 1 );
assert( gamma_move(board, 7, 14, 7) == 0 );
assert( gamma_move(board, 7, 1, 13) == 0 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


gamma_delete(board);

    return 0;
}
