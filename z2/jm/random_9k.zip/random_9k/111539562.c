#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 111539562
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(22, 16, 4, 59);
assert( board != NULL );


assert( gamma_move(board, 1, 14, 4) == 1 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_move(board, 2, 11, 20) == 0 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 2 );
assert( gamma_move(board, 4, 2, 1) == 1 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_move(board, 1, 0, 15) == 1 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 2, 13, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 3, 15, 5) == 1 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 1, 15, 12) == 1 );
assert( gamma_move(board, 1, 15, 11) == 1 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 20, 15) == 1 );
assert( gamma_move(board, 3, 21, 15) == 1 );
assert( gamma_move(board, 3, 18, 14) == 1 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_free_fields(board, 1) == 334 );
assert( gamma_move(board, 2, 5, 19) == 0 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 3, 14, 11) == 1 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_move(board, 4, 15, 2) == 1 );
assert( gamma_move(board, 1, 13, 17) == 0 );
assert( gamma_free_fields(board, 1) == 330 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 4, 17, 10) == 1 );
assert( gamma_move(board, 4, 3, 13) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 21, 6) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 2, 17, 8) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 9, 6) == 1 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 1, 14, 7) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 17, 8) == 0 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_move(board, 4, 13, 11) == 1 );
assert( gamma_move(board, 1, 12, 3) == 1 );
assert( gamma_golden_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 2, 10, 5) == 1 );


char* board508837585 = gamma_board(board);
assert( board508837585 != NULL );
assert( strcmp(board508837585, 
"1...................23\n"
"..................3...\n"
"...4..................\n"
"...............1......\n"
".............431......\n"
".................4....\n"
"2....3.1..............\n"
".....3...3.1.....2....\n"
"......3.......1.......\n"
".........4...........1\n"
"...3......2....3......\n"
"....3.......121.......\n"
".....4......1.........\n"
"........2......4......\n"
".24.......2...........\n"
".2.3..4...............\n") == 0);
free(board508837585);
board508837585 = NULL;
assert( gamma_move(board, 3, 17, 13) == 1 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 4, 20, 3) == 1 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 2, 21, 15) == 0 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 4, 0, 11) == 1 );
assert( gamma_move(board, 4, 9, 14) == 1 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_golden_move(board, 2, 5, 3) == 1 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 3, 14, 2) == 1 );
assert( gamma_move(board, 4, 7, 12) == 1 );
assert( gamma_move(board, 1, 11, 3) == 1 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_move(board, 3, 18, 13) == 1 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 1, 14, 19) == 0 );
assert( gamma_golden_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 11, 17) == 0 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 2, 8, 21) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_golden_move(board, 2, 3, 20) == 0 );
assert( gamma_move(board, 3, 8, 20) == 0 );


char* board595047633 = gamma_board(board);
assert( board595047633 != NULL );
assert( strcmp(board595047633, 
"1...................23\n"
"......3..4........3...\n"
"...4.............33...\n"
".......42......1......\n"
"4............431......\n"
".................4....\n"
"2....3.1..............\n"
"...3.3...3.1.....2....\n"
"..2.1.3.......1.......\n"
".....3...4...........1\n"
"...3...3..2....3......\n"
"....3....1..121.......\n"
".3...2.....11.......4.\n"
"........2.....34......\n"
".24.......22..........\n"
".2.3..4...............\n") == 0);
free(board595047633);
board595047633 = NULL;
assert( gamma_move(board, 4, 8, 4) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 1, 15, 7) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_move(board, 3, 17, 11) == 1 );
assert( gamma_free_fields(board, 3) == 292 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 1, 5, 12) == 1 );
assert( gamma_move(board, 1, 20, 1) == 1 );
assert( gamma_move(board, 2, 13, 20) == 0 );
assert( gamma_move(board, 2, 19, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 4, 16) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 4, 4, 15) == 1 );
assert( gamma_move(board, 1, 5, 20) == 0 );
assert( gamma_move(board, 1, 19, 4) == 1 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_golden_move(board, 2, 14, 18) == 0 );
assert( gamma_move(board, 3, 1, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 6) == 1 );
assert( gamma_move(board, 4, 13, 10) == 1 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 1, 18, 5) == 1 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_move(board, 4, 11, 0) == 1 );
assert( gamma_move(board, 1, 15, 6) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 16) == 0 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 3, 14, 1) == 1 );
assert( gamma_move(board, 4, 1, 15) == 1 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_move(board, 2, 7, 18) == 0 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 4, 12, 1) == 1 );
assert( gamma_free_fields(board, 4) == 269 );
assert( gamma_golden_move(board, 4, 13, 17) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_free_fields(board, 1) == 269 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_move(board, 3, 10, 15) == 1 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 2, 9, 18) == 0 );
assert( gamma_free_fields(board, 2) == 260 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_free_fields(board, 3) == 259 );
assert( gamma_move(board, 4, 3, 16) == 0 );
assert( gamma_move(board, 4, 20, 10) == 1 );
assert( gamma_move(board, 1, 12, 9) == 1 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 3, 10, 12) == 1 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 4, 2, 12) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_free_fields(board, 1) == 254 );
assert( gamma_move(board, 2, 9, 16) == 0 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_free_fields(board, 2) == 253 );
assert( gamma_golden_move(board, 2, 5, 3) == 0 );


char* board926952206 = gamma_board(board);
assert( board926952206 != NULL );
assert( strcmp(board926952206, 
"14..4.....3.........23\n"
"......3..4........3...\n"
".1.4.............33...\n"
"..4.31.42.3....1......\n"
"4.....43..1..431.3.2..\n"
"4.........2..4...4..4.\n"
"2.2..3.1.2..12........\n"
"...3.3...3.1.....2....\n"
"..2.1.3.......11......\n"
"..2.43...4...1.1.....1\n"
".3.3.3.3..2....3..1...\n"
"4...3...41..121....1..\n"
"13...2.....11.......4.\n"
"....2..22.4.3.34......\n"
".24.....2.224.3.....1.\n"
".2.33.4....4..........\n") == 0);
free(board926952206);
board926952206 = NULL;
assert( gamma_move(board, 3, 15, 16) == 0 );
assert( gamma_move(board, 3, 18, 15) == 1 );
assert( gamma_free_fields(board, 3) == 252 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 14, 15) == 1 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 20, 8) == 1 );
assert( gamma_move(board, 4, 8, 18) == 0 );
assert( gamma_move(board, 4, 3, 15) == 1 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 9, 13) == 1 );
assert( gamma_move(board, 2, 2, 15) == 1 );
assert( gamma_move(board, 2, 17, 0) == 1 );
assert( gamma_move(board, 3, 14, 13) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_golden_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 1, 18, 7) == 1 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_move(board, 2, 11, 11) == 1 );
assert( gamma_move(board, 3, 3, 17) == 0 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_free_fields(board, 4) == 240 );
assert( gamma_move(board, 1, 13, 11) == 0 );


char* board768230082 = gamma_board(board);
assert( board768230082 != NULL );
assert( strcmp(board768230082, 
"14244.....3...4...3.23\n"
"......3..4........3...\n"
".1.4.....1....3..33...\n"
"..4.31.42.3....1......\n"
"4.....43..12.431.3.2..\n"
"4.........2..4...4..4.\n"
"2.2..3.1.2..12........\n"
"...3.3...3.1.....2..3.\n"
"2.2.1.3.......11..1...\n"
"..2.43...4...1.1.....1\n"
"43.3.3.3..2....3..1...\n"
"4...3...41..121....1..\n"
"13.1.2.....11.......4.\n"
"....2..22.4.3.34......\n"
".24.....2.224.3.....1.\n"
".2.33.4....4.....2....\n") == 0);
free(board768230082);
board768230082 = NULL;
assert( gamma_move(board, 2, 5, 14) == 1 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 3, 19, 13) == 1 );
assert( gamma_free_fields(board, 3) == 238 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 4, 1, 1) == 1 );
assert( gamma_move(board, 1, 11, 9) == 1 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_move(board, 3, 6, 16) == 0 );
assert( gamma_move(board, 3, 10, 0) == 1 );
assert( gamma_move(board, 4, 7, 14) == 1 );
assert( gamma_free_fields(board, 4) == 234 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_move(board, 1, 5, 15) == 1 );
assert( gamma_move(board, 2, 2, 19) == 0 );
assert( gamma_move(board, 2, 17, 0) == 0 );
assert( gamma_move(board, 3, 13, 12) == 1 );
assert( gamma_move(board, 3, 18, 3) == 1 );
assert( gamma_move(board, 4, 12, 19) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_free_fields(board, 1) == 229 );
assert( gamma_move(board, 2, 14, 12) == 1 );
assert( gamma_move(board, 2, 1, 11) == 1 );
assert( gamma_move(board, 3, 5, 13) == 1 );
assert( gamma_move(board, 3, 20, 7) == 1 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_move(board, 1, 15, 19) == 0 );
assert( gamma_move(board, 2, 20, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 12, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_free_fields(board, 4) == 222 );
assert( gamma_move(board, 1, 15, 13) == 1 );
assert( gamma_move(board, 2, 21, 9) == 1 );
assert( gamma_golden_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 4, 11) == 1 );
assert( gamma_move(board, 3, 5, 9) == 0 );


char* board791422688 = gamma_board(board);
assert( board791422688 != NULL );
assert( strcmp(board791422688, 
"142441....3...4...3.23\n"
".....234.4........3...\n"
".1.4.3...1..3.31.333..\n"
"..4.31.42.3..321....2.\n"
"42..3243..12.431.3.2..\n"
"4...1.....2..4...4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1.....2..3.\n"
"2.2.1.3.......11..1.3.\n"
"..2.43...4...1.1.....1\n"
"43.3.3.3..2....3..1...\n"
"4...3...41..121....1..\n"
"13.1.2.....11.....3.4.\n"
"....2..22.4.3.34......\n"
".44.....2.224.3.....1.\n"
".2.33.4...34.....2....\n") == 0);
free(board791422688);
board791422688 = NULL;
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 1, 11, 5) == 1 );
assert( gamma_move(board, 1, 21, 14) == 1 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 4, 7, 16) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_free_fields(board, 1) == 215 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 16, 8) == 1 );
assert( gamma_move(board, 4, 10, 15) == 0 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 1, 14, 15) == 0 );


char* board943824648 = gamma_board(board);
assert( board943824648 != NULL );
assert( strcmp(board943824648, 
"142441....3...4...3.23\n"
".....234.4........3..1\n"
".1.4.3...1..3.31.333..\n"
"..4.31.42.3.1321....2.\n"
"42..3243..12.431.3.2..\n"
"4...1.....2..4...4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1....32..3.\n"
"222.1.3.......11..1.3.\n"
"..2.43...43..1.1.....1\n"
"4313.3.3..21...3..1...\n"
"4...3...41..121....1..\n"
"13.1.2.....11.....3.4.\n"
"....2..22.4.3.34......\n"
".44.....2.224.3.....1.\n"
".2.33.4...34.....2....\n") == 0);
free(board943824648);
board943824648 = NULL;
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 1, 14, 10) == 1 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 2, 12, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 34 );


char* board503019598 = gamma_board(board);
assert( board503019598 != NULL );
assert( strcmp(board503019598, 
"142441....3...4...3.23\n"
".....234.4........3..1\n"
".1.4.3...1..3.31.333..\n"
"..4.31.42.3.1321....2.\n"
"42..3243..12.431.3.2..\n"
"4...1.....2..41..4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1....32..3.\n"
"222.1.3.....2.11..1.3.\n"
"..2.43...43..1.1.....1\n"
"4313.3.3..21...3..1...\n"
"4...3...41..121....1..\n"
"13.1.2.....11.....3.4.\n"
"....2..22.4.3.34......\n"
".44...2.2.224.3.....1.\n"
".2.33.4...34.....2....\n") == 0);
free(board503019598);
board503019598 = NULL;
assert( gamma_move(board, 3, 6, 15) == 1 );
assert( gamma_golden_move(board, 3, 9, 21) == 0 );
assert( gamma_move(board, 4, 3, 15) == 0 );
assert( gamma_move(board, 1, 16, 14) == 1 );
assert( gamma_move(board, 2, 3, 7) == 1 );
assert( gamma_move(board, 2, 15, 8) == 1 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 3, 21, 15) == 0 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_move(board, 2, 13, 7) == 1 );
assert( gamma_move(board, 3, 21, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 44 );
assert( gamma_move(board, 4, 1, 1) == 0 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_free_fields(board, 1) == 203 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 17, 5) == 1 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 4, 14, 4) == 0 );


char* board260785332 = gamma_board(board);
assert( board260785332 != NULL );
assert( strcmp(board260785332, 
"1424413...3...4...3.23\n"
"2....234.4......1.3..1\n"
".1.4.3...1..3.31.333..\n"
"..4.31.42.3.1321....2.\n"
"42..3243..12.431.3.2..\n"
"4...1.....2..41..4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1...232..3.\n"
"22221.3.....2211..1.3.\n"
"..2.43...43..1.1.....1\n"
"4313.3.3..21...3.41...\n"
"4...3...41..121....1..\n"
"13.1.2.....11.....3.4.\n"
"....2..22.4.3.34......\n"
".441..2.23224.3.....1.\n"
".2.33.4...34.....2...3\n") == 0);
free(board260785332);
board260785332 = NULL;
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 1, 13, 8) == 1 );


char* board818946262 = gamma_board(board);
assert( board818946262 != NULL );
assert( strcmp(board818946262, 
"1424413...3...4...3.23\n"
"2....234.4......1.3..1\n"
"11.4.3...1..3.31.333..\n"
"..4.31.42.3.1321....2.\n"
"42..3243..12.431.3.2..\n"
"4...1.....2..41..4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1.1.232..3.\n"
"22221.3.....2211..1.3.\n"
"..2.43...43..1.1.....1\n"
"4313.3.3..21...3.41...\n"
"4...3...41..121....1..\n"
"13.1.2.....11.....3.4.\n"
"....2..22.4.3.34......\n"
".441..2.23224.3.....1.\n"
".2.33.4...34.....2...3\n") == 0);
free(board818946262);
board818946262 = NULL;
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 38 );
assert( gamma_golden_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_golden_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 16, 6) == 1 );
assert( gamma_free_fields(board, 4) == 196 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 9, 17) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );


char* board840338887 = gamma_board(board);
assert( board840338887 != NULL );
assert( strcmp(board840338887, 
"1424413...3...4...3.23\n"
"2....234.4......1.3..1\n"
"11.4.3...1..3.31.333..\n"
"..4.31.42.3.1321....2.\n"
"42..3243..12.431.3.2..\n"
"4...1.....2..41..4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1.1.232..3.\n"
"22221.3.....2211..1.3.\n"
"..2.43...43..1.14....1\n"
"4313.3.3..21...3.41...\n"
"4...3...41..121....1..\n"
"13.3.2.....11.....3.4.\n"
"....2..22.4.3.34......\n"
".441..2.23224.3.....1.\n"
".2.33.4...34.....2...3\n") == 0);
free(board840338887);
board840338887 = NULL;
assert( gamma_move(board, 4, 1, 14) == 1 );
assert( gamma_move(board, 4, 19, 12) == 1 );
assert( gamma_free_fields(board, 4) == 194 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 10) == 1 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 2, 4, 20) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_golden_move(board, 2, 12, 12) == 0 );
assert( gamma_move(board, 3, 7, 21) == 0 );
assert( gamma_move(board, 3, 19, 3) == 1 );
assert( gamma_move(board, 4, 5, 4) == 1 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 4, 19, 1) == 1 );


char* board988242205 = gamma_board(board);
assert( board988242205 != NULL );
assert( strcmp(board988242205, 
"1424413...3...4...3.23\n"
"24...234.4......1.3..1\n"
"11.4.3...1..3.31.333..\n"
"..4.31.42.3.1321...42.\n"
"42..3243..12.431.3.2..\n"
"4...1.....22.41..4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1.1.232..3.\n"
"22221.3.....2211..1.3.\n"
"..2.43...43..1.14....1\n"
"4313.3.3..21...3.41...\n"
"4...34..41..121....1..\n"
"13.3.2.....11.....334.\n"
"....2..22.4.3.34......\n"
".441..2.23224.3....41.\n"
".2.33.4...34.....2...3\n") == 0);
free(board988242205);
board988242205 = NULL;
assert( gamma_move(board, 2, 17, 7) == 1 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 11, 21) == 0 );


char* board986237238 = gamma_board(board);
assert( board986237238 != NULL );
assert( strcmp(board986237238, 
"1424413...3...4...3.23\n"
"24...234.4......1.3..1\n"
"11.4.3...1..3.31.333..\n"
"..4.31.42.3.1321...42.\n"
"42..3243..12.431.3.2..\n"
"4...1.....22.41..4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1.1.232..3.\n"
"22221.3.....2211.21.3.\n"
"..2.43...43..1.14....1\n"
"4313.3.3..21...3.41...\n"
"4...34..41..121....1..\n"
"13.3.2.....11.....334.\n"
"....2..22.4.3.34......\n"
".441..2.23224.3....41.\n"
".2.33.4...34.....2...3\n") == 0);
free(board986237238);
board986237238 = NULL;
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 3, 13, 13) == 1 );
assert( gamma_move(board, 3, 8, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_free_fields(board, 1) == 187 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 3, 14, 5) == 1 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );


char* board338875038 = gamma_board(board);
assert( board338875038 != NULL );
assert( strcmp(board338875038, 
"1424413...3...4...3.23\n"
"24...234.4......1.3..1\n"
"11.4.3...1..3331.333..\n"
"2.4.31.42.3.1321...42.\n"
"42..3243..12.431.3.2..\n"
"4...1.....22.41..4..4.\n"
"2.21.3.1.2.112.......2\n"
"..43.3...3.1.1.232..3.\n"
"22221.3.....2211.21.3.\n"
"..2.43...43..1.14....1\n"
"4313.3.3..21..33.41...\n"
"4...34..41..121....1..\n"
"13.3.2.....11.....334.\n"
"....2..22.4.3.34......\n"
".441..2.23224.3....41.\n"
".2.33.4...34.....2...3\n") == 0);
free(board338875038);
board338875038 = NULL;
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 20, 13) == 1 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_free_fields(board, 3) == 185 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 21, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_move(board, 1, 18, 1) == 1 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_move(board, 2, 17, 10) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 12, 21) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 20, 10) == 0 );


char* board185422800 = gamma_board(board);
assert( board185422800 != NULL );
assert( strcmp(board185422800, 
"1424413...3...4...3.23\n"
"24...234.4......1.3..1\n"
"11.4.3...1..3331.3333.\n"
"2.4.31.42.3.1321...42.\n"
"42..3243..12.431.3.2..\n"
"4...1.....22.41..4..4.\n"
"2.21.3.1.2.112.......2\n"
"1.43.3...3.1.1.232..3.\n"
"22221.3.....2211.21.3.\n"
"..2.43...43..1.14....1\n"
"4313.3.3..21..33.41...\n"
"4...34..41..121....1..\n"
"13.3.2.....11.....334.\n"
"....2..22.4.3.34......\n"
".441..2.23224.3...1414\n"
".2.33.4...34.....2...3\n") == 0);
free(board185422800);
board185422800 = NULL;
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_move(board, 3, 3, 17) == 0 );
assert( gamma_move(board, 4, 13, 2) == 1 );
assert( gamma_move(board, 4, 20, 12) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 6, 19) == 0 );
assert( gamma_move(board, 4, 13, 13) == 0 );
assert( gamma_move(board, 1, 19, 14) == 1 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 3, 6, 8) == 1 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 15, 15) == 1 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 45 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 4, 14) == 1 );
assert( gamma_free_fields(board, 4) == 174 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 16, 9) == 1 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 3, 19, 11) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 20, 0) == 1 );
assert( gamma_move(board, 4, 7, 15) == 1 );
assert( gamma_move(board, 1, 3, 21) == 0 );
assert( gamma_move(board, 1, 18, 7) == 0 );
assert( gamma_free_fields(board, 1) == 170 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 20, 3) == 0 );
assert( gamma_golden_move(board, 2, 5, 18) == 0 );
assert( gamma_move(board, 3, 14, 8) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 20, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_golden_move(board, 3, 8, 17) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_free_fields(board, 4) == 168 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_move(board, 1, 18, 11) == 1 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 2, 21, 5) == 1 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 52 );
assert( gamma_free_fields(board, 3) == 166 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_free_fields(board, 1) == 166 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 4, 7, 16) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 15, 9) == 1 );
assert( gamma_move(board, 2, 10, 16) == 0 );
assert( gamma_move(board, 2, 20, 12) == 0 );
assert( gamma_move(board, 3, 10, 21) == 0 );
assert( gamma_move(board, 4, 6, 19) == 0 );
assert( gamma_move(board, 1, 21, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 46 );


char* board432884199 = gamma_board(board);
assert( board432884199 != NULL );
assert( strcmp(board432884199, 
"14244134..3...42..3.23\n"
"24..4234.4......1.31.1\n"
"11.4.3...1..3331.3333.\n"
"2.4.31.42.3.1321...42.\n"
"42..3243..12.431.312..\n"
"4...12....22.41..4..4.\n"
"2.21.3.1.2.112.11....2\n"
"1.43233..3.1.13232..3.\n"
"2222123.....2211.21.3.\n"
"..2.43...43..1.14....1\n"
"4313.3.3..21..33.41..2\n"
"42..34..41..121....1..\n"
"13.3.22....11.....334.\n"
"....2..22.4.3434......\n"
".441..2.23224.3...1414\n"
".2.33.4...34.....2..43\n") == 0);
free(board432884199);
board432884199 = NULL;
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 3, 15, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 16, 14) == 0 );
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_move(board, 4, 16, 12) == 1 );
assert( gamma_move(board, 4, 16, 7) == 1 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 46 );
assert( gamma_golden_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 6, 18) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );


char* board159024645 = gamma_board(board);
assert( board159024645 != NULL );
assert( strcmp(board159024645, 
"14244134..3...42..3.23\n"
"24..4234.4......1.31.1\n"
"11.4.3...1..3331.3333.\n"
"2.4.31.42.3.13214..42.\n"
"42..3243..12.431.312..\n"
"4...12....22.41..4..4.\n"
"2.21.3.1.2.112.11....2\n"
"1.43233..3.1.13232..3.\n"
"2222123.....2211421.3.\n"
"..2.43...43.31.14....1\n"
"4313.3.3..21..33.41..2\n"
"42..34.241..121....1..\n"
"13.3.22....11.....334.\n"
"....2..22.4.3434......\n"
".441..2.23224.3...1414\n"
".2.33.4...34.....2..43\n") == 0);
free(board159024645);
board159024645 = NULL;
assert( gamma_move(board, 4, 7, 8) == 1 );
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );


char* board198176936 = gamma_board(board);
assert( board198176936 != NULL );
assert( strcmp(board198176936, 
"14244134..3...42..3.23\n"
"24..4234.4......1.31.1\n"
"11.4.3...1..3331.3333.\n"
"2.4.31.42.3.13214..42.\n"
"42..3243..12.431.312..\n"
"4...12....22.41..4..4.\n"
"2.21.3.1.2.112.11....2\n"
"1.432334.3.1.13232..3.\n"
"2222123.....2211421.3.\n"
"..2.43...43.31.14....1\n"
"4313.3.3..21..33.41..2\n"
"42..34.241.4121....1..\n"
"1323.22....11.....334.\n"
"....2..22.4.3434......\n"
".441..2.23224.3...1414\n"
".2.33.4...34.....2..43\n") == 0);
free(board198176936);
board198176936 = NULL;
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 4, 20, 8) == 0 );
assert( gamma_golden_move(board, 4, 10, 17) == 0 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 10, 8) == 1 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 3, 16) == 0 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 2, 9, 19) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 0, 19) == 0 );
assert( gamma_busy_fields(board, 3) == 54 );


char* board820646774 = gamma_board(board);
assert( board820646774 != NULL );
assert( strcmp(board820646774, 
"14244134..3...42..3.23\n"
"24..4234.4......1.31.1\n"
"11.4.3...1..3331.3333.\n"
"2.4.31.42.3.13214..42.\n"
"42..3243..12.431.312..\n"
"4...12....22.41..4..4.\n"
"2.21.3.1.2.112.11....2\n"
"1.432334.331.13232..3.\n"
"2222123.....2211421.3.\n"
"..2.43...43.31.14....1\n"
"4313.3.3..21..33.41..2\n"
"42..34.241.4121....1..\n"
"1323.22....11.....334.\n"
"....2..22.4.3434......\n"
".441..2.23224.3...1414\n"
".2.33.4...34.....2..43\n") == 0);
free(board820646774);
board820646774 = NULL;
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 3, 11, 16) == 0 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_free_fields(board, 3) == 155 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 21, 5) == 0 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 1, 21, 8) == 1 );
assert( gamma_free_fields(board, 1) == 153 );
assert( gamma_move(board, 2, 21, 9) == 0 );


char* board471736198 = gamma_board(board);
assert( board471736198 != NULL );
assert( strcmp(board471736198, 
"14244134..3...42..3.23\n"
"24..4234.4......1.31.1\n"
"11.4.3...1..3331.3333.\n"
"2.4.31.4213.13214..42.\n"
"42..3243..12.431.312..\n"
"4..112....22.41..4..4.\n"
"2.21.3.1.2.112.11....2\n"
"1.432334.331.13232..31\n"
"2222123.....2211421.3.\n"
"..2.43...43.31.14....1\n"
"4313.3.3..21..33.41..2\n"
"42..34.241.4121....1..\n"
"1323.22....11.....334.\n"
"....2..22.4.3434......\n"
"1441..2.23224.3...1414\n"
".2.33.4...34.....2..43\n") == 0);
free(board471736198);
board471736198 = NULL;
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 45 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 50 );
assert( gamma_free_fields(board, 1) == 153 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 51 );
assert( gamma_free_fields(board, 2) == 152 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_free_fields(board, 3) == 152 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_free_fields(board, 4) == 152 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_move(board, 3, 2, 18) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 10, 7) == 1 );


char* board713058173 = gamma_board(board);
assert( board713058173 != NULL );
assert( strcmp(board713058173, 
"14244134..3...42..3.23\n"
"24..4234.41.....1.31.1\n"
"11.4.3...12.3331.3333.\n"
"2.4.31.4213.13214..42.\n"
"42..3243..12.431.312..\n"
"4..112....22.41..4..4.\n"
"2.21.3.1.2.112.11....2\n"
"1.432334.331.13232..31\n"
"2222123...4.2211421.3.\n"
"..2.43...43.31.14....1\n"
"4313.3.3..21..33.41..2\n"
"42..34.241.4121....1..\n"
"1323.22....11.....334.\n"
"....2..22.4.3434......\n"
"1441..2.23224.3...1414\n"
".2.33.4...34.....2..43\n") == 0);
free(board713058173);
board713058173 = NULL;
assert( gamma_move(board, 1, 17, 11) == 0 );
assert( gamma_move(board, 1, 16, 0) == 1 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 16, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 11, 21) == 0 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 2, 11, 20) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 2, 10, 21) == 0 );
assert( gamma_move(board, 3, 17, 5) == 0 );
assert( gamma_move(board, 3, 16, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 1, 10, 18) == 0 );
assert( gamma_move(board, 2, 18, 7) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_golden_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_move(board, 4, 12, 11) == 1 );
assert( gamma_free_fields(board, 4) == 144 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 18, 5) == 0 );
assert( gamma_move(board, 3, 13, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 14, 16) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 4, 19, 14) == 0 );
assert( gamma_move(board, 1, 15, 16) == 0 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 3, 12, 10) == 1 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 4, 20, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 48 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 2, 20, 4) == 1 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 2, 18) == 0 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 60 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_free_fields(board, 4) == 138 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 17, 4) == 1 );
assert( gamma_move(board, 2, 6, 20) == 0 );
assert( gamma_move(board, 4, 6, 17) == 0 );
assert( gamma_move(board, 4, 2, 13) == 1 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_move(board, 4, 2, 16) == 0 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_free_fields(board, 1) == 133 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_move(board, 2, 21, 4) == 1 );
assert( gamma_move(board, 3, 16, 12) == 0 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 1, 2, 18) == 0 );
assert( gamma_move(board, 2, 3, 21) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board471579068 = gamma_board(board);
assert( board471579068 != NULL );
assert( strcmp(board471579068, 
"14244134..3...42..3.23\n"
"24.34234.41.....1.31.1\n"
"1144.3...12.3331.3333.\n"
"2.4.31.4213.13214..42.\n"
"424.3243..1244312312..\n"
"4..112....22341..4..4.\n"
"2.21.3.1.2.112.11....2\n"
"1.4323342331.13232..31\n"
"2222123...4.2211421.3.\n"
"..2.433..43.31.14....1\n"
"4313.3.32321..33.41..2\n"
"42..343241.4121.31.122\n"
"1323.22....113....334.\n"
"4...2..22.4.3434......\n"
"1441..2.23224.3...1414\n"
".2.33.4...34....12..43\n") == 0);
free(board471579068);
board471579068 = NULL;
assert( gamma_move(board, 3, 9, 17) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 4, 8, 19) == 0 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_move(board, 1, 20, 10) == 0 );
assert( gamma_move(board, 1, 9, 15) == 1 );
assert( gamma_move(board, 2, 2, 19) == 0 );
assert( gamma_move(board, 2, 17, 14) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 4, 17, 11) == 0 );
assert( gamma_move(board, 4, 14, 0) == 1 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 11, 7) == 1 );
assert( gamma_move(board, 3, 16, 12) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_move(board, 2, 9, 10) == 1 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 52 );
assert( gamma_move(board, 1, 8, 19) == 0 );
assert( gamma_move(board, 2, 6, 14) == 0 );
assert( gamma_golden_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 52 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 14, 20) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 1, 20, 1) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 14, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 60 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_golden_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 2, 18) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_free_fields(board, 4) == 124 );
assert( gamma_golden_move(board, 4, 15, 2) == 0 );
assert( gamma_move(board, 1, 3, 21) == 0 );
assert( gamma_move(board, 2, 6, 17) == 0 );
assert( gamma_busy_fields(board, 2) == 60 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_free_fields(board, 4) == 124 );
assert( gamma_golden_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 1, 18, 8) == 1 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 4, 9, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_free_fields(board, 1) == 122 );
assert( gamma_move(board, 2, 2, 19) == 0 );
assert( gamma_move(board, 2, 21, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 15, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 62 );
assert( gamma_free_fields(board, 3) == 121 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 21) == 0 );
assert( gamma_busy_fields(board, 4) == 53 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 10, 18) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_free_fields(board, 3) == 121 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );


char* board483039686 = gamma_board(board);
assert( board483039686 != NULL );
assert( strcmp(board483039686, 
"14244134.13...42..3.23\n"
"24.34234.41..1..1231.1\n"
"1144.3...12.3331.3333.\n"
"2.4.31.4213.13214..42.\n"
"424.3243..1244312312..\n"
"4..112...222341..4..4.\n"
"2.21.3.1.2.112.11....2\n"
"1.4323342331.132321.31\n"
"2222123...422211421.3.\n"
"..2.433..43.31.14....1\n"
"4313.3.32321..33.41..2\n"
"42..343241.4121.31.122\n"
"1323.22....1132...334.\n"
"4..42..22.4.3434......\n"
"1441..2.23224.33..1414\n"
".2.33.4..434..4.12..43\n") == 0);
free(board483039686);
board483039686 = NULL;
assert( gamma_move(board, 4, 10, 18) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_free_fields(board, 4) == 121 );
assert( gamma_move(board, 1, 5, 19) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 14, 9) == 1 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 1, 15, 14) == 1 );
assert( gamma_move(board, 2, 10, 15) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_move(board, 3, 21, 11) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 18, 3) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 0, 18) == 0 );
assert( gamma_move(board, 3, 10, 15) == 0 );
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_move(board, 1, 14, 20) == 0 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_free_fields(board, 1) == 114 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 2, 2, 10) == 1 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 21, 14) == 0 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_move(board, 2, 6, 13) == 1 );
assert( gamma_move(board, 2, 19, 12) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 14, 14) == 1 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 63 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 56 );
assert( gamma_move(board, 1, 16, 10) == 1 );
assert( gamma_move(board, 2, 19, 7) == 1 );
assert( gamma_free_fields(board, 2) == 108 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 64 );
assert( gamma_move(board, 4, 6, 17) == 0 );
assert( gamma_move(board, 4, 13, 14) == 0 );


char* board961203718 = gamma_board(board);
assert( board961203718 != NULL );
assert( strcmp(board961203718, 
"14244134.13...42..3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.3333.\n"
"2.4.31.4213.13214..42.\n"
"42443243..1244312312.3\n"
"4.2112...222341.14..4.\n"
"2.21.3.1.2.112311....2\n"
"1.4323342331.132321.31\n"
"2222123...42221142123.\n"
"..2.433..43.31.14....1\n"
"4313.3.32321..33.41..2\n"
"42..343241.4121.31.122\n"
"13232221...1132...334.\n"
"4..424.22.4.3434......\n"
"1441..2.23224.33..1414\n"
"12.33.4..434..4.12..43\n") == 0);
free(board961203718);
board961203718 = NULL;
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 2, 15, 3) == 1 );
assert( gamma_move(board, 3, 8, 15) == 1 );
assert( gamma_free_fields(board, 3) == 105 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_free_fields(board, 4) == 104 );
assert( gamma_move(board, 1, 10, 12) == 0 );


char* board613369654 = gamma_board(board);
assert( board613369654 != NULL );
assert( strcmp(board613369654, 
"14244134313...42..3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.3333.\n"
"2.4.31.4213.13214..42.\n"
"42443243..1244312312.3\n"
"4.2112...222341.14..4.\n"
"2.21.3.1.2.112311....2\n"
"1.4323342331.132321.31\n"
"2222123...42221142123.\n"
"..2.433..43.31.14....1\n"
"4313.3.32321..33.41..2\n"
"42..343241.4121.31.122\n"
"13232221...11322..334.\n"
"4.2424.22.4.3434......\n"
"1441..2423224.33..1414\n"
"12.33.4..434..4.12..43\n") == 0);
free(board613369654);
board613369654 = NULL;
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 4, 0, 19) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 21, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 18, 12) == 1 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 57 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 57 );
assert( gamma_move(board, 1, 15, 11) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 2, 17, 14) == 0 );
assert( gamma_move(board, 3, 8, 19) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 1, 10, 18) == 0 );
assert( gamma_move(board, 2, 6, 14) == 0 );
assert( gamma_move(board, 3, 4, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 67 );
assert( gamma_move(board, 4, 15, 16) == 0 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 2, 21) == 0 );
assert( gamma_move(board, 2, 15, 14) == 0 );
assert( gamma_move(board, 3, 0, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 68 );
assert( gamma_golden_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 1, 10, 18) == 0 );
assert( gamma_move(board, 1, 8, 11) == 1 );
assert( gamma_free_fields(board, 1) == 100 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 3, 15, 4) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_move(board, 4, 10, 19) == 0 );
assert( gamma_move(board, 4, 15, 13) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_golden_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 2, 6, 14) == 0 );
assert( gamma_move(board, 2, 20, 9) == 1 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_free_fields(board, 3) == 96 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_move(board, 4, 0, 0) == 0 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 18, 2) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 4, 10, 7) == 0 );


char* board774476238 = gamma_board(board);
assert( board774476238 != NULL );
assert( strcmp(board774476238, 
"14244134313...42..3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.3333.\n"
"2.4.3124213.13214.342.\n"
"424432431.1244312312.3\n"
"4.2112...222341.14..4.\n"
"2.2133.1.2.112311...22\n"
"1.4323342331.132321.31\n"
"2222123...42221142123.\n"
"3.2.133..43.31.14....1\n"
"4313.3.32321..33.41..2\n"
"42..343241.4121331.122\n"
"13232221...11322..334.\n"
"4.2424.22.443434..2...\n"
"14413.2423224.33..1414\n"
"12.33.4..434..4.12..43\n") == 0);
free(board774476238);
board774476238 = NULL;
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 15, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 18) == 0 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_move(board, 4, 5, 20) == 0 );


char* board790408203 = gamma_board(board);
assert( board790408203 != NULL );
assert( strcmp(board790408203, 
"14244134313...42..3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.3333.\n"
"2.4.3124213313214.342.\n"
"424432431.1244312312.3\n"
"4.2112...222341.14..4.\n"
"2.2133.1.2.112311...22\n"
"1.4323342331.132321.31\n"
"2222123...42221142123.\n"
"3.2.133..43.31.14....1\n"
"4313.3.32321..33.41..2\n"
"42..343241.4121331.122\n"
"13232221...11322..334.\n"
"4.2424.22.443434..2...\n"
"14413.2423224.33..1414\n"
"12.33.4..434..4.12..43\n") == 0);
free(board790408203);
board790408203 = NULL;
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 2, 10, 18) == 0 );
assert( gamma_move(board, 2, 15, 13) == 0 );
assert( gamma_golden_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 3, 9, 17) == 0 );
assert( gamma_move(board, 3, 18, 7) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 4, 9, 19) == 0 );
assert( gamma_move(board, 2, 18, 3) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 4, 7, 14) == 0 );


char* board716357905 = gamma_board(board);
assert( board716357905 != NULL );
assert( strcmp(board716357905, 
"14244134313...42..3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.3333.\n"
"2.4.3124213313214.342.\n"
"424432431.1244312312.3\n"
"4.2112...222341.14..4.\n"
"2.2133.1.2.112311...22\n"
"1.4323342331.132321.31\n"
"2222123...42221142123.\n"
"3.2.133..43.31.14....1\n"
"4313.3.32321..33.41..2\n"
"42..343241.4121331.122\n"
"13232221...11322..334.\n"
"4.2424.22.443434..2...\n"
"14413.2423224.33..1414\n"
"12.33.4..434..4.12..43\n") == 0);
free(board716357905);
board716357905 = NULL;
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 4, 10, 19) == 0 );
assert( gamma_move(board, 4, 20, 2) == 1 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 62 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 3, 16) == 0 );
assert( gamma_move(board, 4, 5, 12) == 0 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 69 );
assert( gamma_move(board, 3, 20, 12) == 0 );
assert( gamma_move(board, 4, 21, 10) == 1 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 16, 15) == 1 );
assert( gamma_move(board, 2, 21, 12) == 1 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 13, 21) == 0 );
assert( gamma_move(board, 3, 8, 6) == 1 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 4, 8, 15) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_move(board, 4, 10, 19) == 0 );
assert( gamma_move(board, 1, 18, 10) == 1 );
assert( gamma_golden_move(board, 1, 9, 9) == 0 );
assert( gamma_golden_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 3, 21) == 0 );
assert( gamma_move(board, 4, 21, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 59 );
assert( gamma_free_fields(board, 4) == 85 );
assert( gamma_move(board, 1, 20, 5) == 1 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_golden_move(board, 1, 3, 15) == 0 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_golden_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 14, 20) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 1, 16, 3) == 1 );
assert( gamma_move(board, 2, 10, 19) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 7) == 1 );
assert( gamma_move(board, 4, 13, 0) == 1 );
assert( gamma_free_fields(board, 1) == 81 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_free_fields(board, 2) == 81 );


char* board462965291 = gamma_board(board);
assert( board462965291 != NULL );
assert( strcmp(board462965291, 
"14244134313...421.3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.3333.\n"
"2.4.3124213313214.3422\n"
"424432431.1244312312.3\n"
"4.2112...222341.141.44\n"
"2.2133.1.2.112311...22\n"
"1.4323342331.132321.31\n"
"22221234..42221142123.\n"
"3.2.133.343.31.14....1\n"
"4313.3.32321..33.41.12\n"
"42.234324134121331.122\n"
"13232221...113221.334.\n"
"4.2424.22.443434..2.4.\n"
"14413.2423224.33..1414\n"
"12.33.4..434.44.12..43\n") == 0);
free(board462965291);
board462965291 = NULL;
assert( gamma_move(board, 3, 13, 16) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 61 );
assert( gamma_move(board, 1, 21, 5) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 17, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 71 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 4, 20, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 13, 16) == 0 );
assert( gamma_golden_move(board, 1, 11, 21) == 0 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 17) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 74 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_move(board, 2, 18, 2) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 15, 17) == 0 );
assert( gamma_move(board, 3, 21, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 74 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_free_fields(board, 3) == 80 );


char* board480227026 = gamma_board(board);
assert( board480227026 != NULL );
assert( strcmp(board480227026, 
"14244134313...421.3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.3333.\n"
"2.4.3124213313214.3422\n"
"424432431.1244312312.3\n"
"4.2112...222341.141.44\n"
"2.2133.1.2.112311...22\n"
"1.4323342331.132321.31\n"
"22221234..42221142123.\n"
"3.2.133.343.31.14....1\n"
"4313.3.32321..33.41.12\n"
"42.234324134121331.122\n"
"13232221...113221.334.\n"
"4.2424.22.443434..2.4.\n"
"14413.2423224.33..1414\n"
"12.33.4.3434.44.12..43\n") == 0);
free(board480227026);
board480227026 = NULL;
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 4, 1, 8) == 1 );
assert( gamma_move(board, 1, 18, 1) == 0 );
assert( gamma_free_fields(board, 1) == 79 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 11, 20) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 74 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 14, 20) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 21) == 0 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 4, 20, 3) == 0 );
assert( gamma_golden_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_move(board, 1, 16, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 67 );
assert( gamma_move(board, 2, 2, 21) == 0 );
assert( gamma_busy_fields(board, 2) == 71 );


char* board707543757 = gamma_board(board);
assert( board707543757 != NULL );
assert( strcmp(board707543757, 
"14244134313...421.3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.3333.\n"
"2.4.3124213313214.3422\n"
"424432431.1244312312.3\n"
"4.2112...222341.141.44\n"
"2.2133.1.2.112311...22\n"
"144323342331.132321.31\n"
"22221234..42221142123.\n"
"3.2.133.343.31.14....1\n"
"4313.3.32321..33.41.12\n"
"42.234324134121331.122\n"
"13232221...113221.334.\n"
"4.2424.22.443434..2.4.\n"
"14413.2423224.331.1414\n"
"12.33.4.3434.44.12..43\n") == 0);
free(board707543757);
board707543757 = NULL;
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 4, 6, 20) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 62 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_free_fields(board, 3) == 78 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 6, 18) == 0 );
assert( gamma_move(board, 2, 18, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 3, 6, 5) == 1 );
assert( gamma_free_fields(board, 3) == 77 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 62 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 3, 10, 19) == 0 );
assert( gamma_free_fields(board, 3) == 77 );
assert( gamma_move(board, 4, 3, 17) == 0 );
assert( gamma_move(board, 1, 9, 19) == 0 );
assert( gamma_move(board, 1, 20, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 75 );
assert( gamma_move(board, 4, 16, 5) == 1 );
assert( gamma_golden_move(board, 4, 5, 20) == 0 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_free_fields(board, 1) == 76 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 20, 1) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 19, 1) == 0 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_free_fields(board, 4) == 75 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 64 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 67 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 18, 0) == 1 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_free_fields(board, 4) == 72 );
assert( gamma_move(board, 1, 12, 17) == 0 );
assert( gamma_free_fields(board, 1) == 72 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 3, 21, 13) == 1 );
assert( gamma_move(board, 4, 0, 19) == 0 );
assert( gamma_move(board, 1, 17, 9) == 1 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 2, 15, 13) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 71 );
assert( gamma_move(board, 3, 15, 17) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 14, 20) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 21, 9) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 19, 9) == 1 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 20, 15) == 0 );
assert( gamma_golden_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_free_fields(board, 4) == 69 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 17, 10) == 0 );
assert( gamma_free_fields(board, 1) == 69 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 4, 10, 15) == 0 );
assert( gamma_move(board, 1, 21, 2) == 1 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_free_fields(board, 1) == 68 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 72 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 3, 21, 2) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 1, 2, 17) == 0 );
assert( gamma_move(board, 2, 14, 20) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );


char* board360281199 = gamma_board(board);
assert( board360281199 != NULL );
assert( strcmp(board360281199, 
"14244134313...421.3.23\n"
"24.34234.41..1411231.1\n"
"1144.32..12.3331.33333\n"
"2.4.3124213313214.3422\n"
"424432431.1244312312.3\n"
"4.2112...222341.141.44\n"
"2.2133.1.231123111.222\n"
"144323342331.132321.31\n"
"22221234..42221142123.\n"
"3.2.133.343.31.14....1\n"
"4313.3332321..33441.12\n"
"42.234324134121331.122\n"
"13232221...113221.334.\n"
"4.2424422.443434..2.41\n"
"14413.2423224.331.1414\n"
"12.3334.3434.44.123.43\n") == 0);
free(board360281199);
board360281199 = NULL;
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 2, 13, 14) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 19, 3) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 6, 18) == 0 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 20, 12) == 0 );
assert( gamma_move(board, 3, 10, 3) == 1 );
assert( gamma_move(board, 3, 20, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 21, 3) == 1 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 73 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 4, 10, 19) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 10, 19) == 0 );
assert( gamma_move(board, 1, 18, 3) == 0 );
assert( gamma_move(board, 2, 20, 0) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 3, 12, 15) == 1 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 4, 18) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 75 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 6, 17) == 0 );
assert( gamma_move(board, 1, 4, 13) == 1 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 10, 19) == 0 );
assert( gamma_free_fields(board, 3) == 60 );
assert( gamma_move(board, 4, 13, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 65 );
assert( gamma_move(board, 1, 9, 18) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 13, 16) == 0 );
assert( gamma_move(board, 2, 17, 1) == 1 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_free_fields(board, 3) == 59 );
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 2, 19, 2) == 1 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 6, 20) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 20, 15) == 0 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 4, 8, 3) == 1 );
assert( gamma_free_fields(board, 4) == 56 );
assert( gamma_move(board, 1, 15, 19) == 0 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 15, 17) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );


char* board147528580 = gamma_board(board);
assert( board147528580 != NULL );
assert( strcmp(board147528580, 
"14244134313.3.421.3.23\n"
"24.34234.41..1411231.1\n"
"1144132..12.3331.33333\n"
"2.4.3124213313214.3422\n"
"424432431.1244312312.3\n"
"4221121..222341.141.44\n"
"2.213321.231123111.222\n"
"144323342331.132321.31\n"
"22221234..42221142123.\n"
"3.22133.343.31.14....1\n"
"4313.3332321..33441.12\n"
"42.234324134121331.122\n"
"132322214.3113221.3344\n"
"442424422.443434..2241\n"
"14413.2423224.33121414\n"
"12.3334.3434.44.123.43\n") == 0);
free(board147528580);
board147528580 = NULL;
assert( gamma_move(board, 2, 17, 11) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 20, 11) == 1 );
assert( gamma_move(board, 4, 8, 19) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 71 );
assert( gamma_free_fields(board, 1) == 55 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 21, 7) == 1 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 4, 4, 18) == 0 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 19) == 0 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 20, 9) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 82 );
assert( gamma_move(board, 1, 0, 19) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 12, 12) == 0 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 71 );


char* board503701572 = gamma_board(board);
assert( board503701572 != NULL );
assert( strcmp(board503701572, 
"14244134313.3.421.3.23\n"
"24.34234.41..1411231.1\n"
"1144132..12.3331.33333\n"
"2.4.3124213313214.3422\n"
"424432431.124431231233\n"
"4221121..222341.141.44\n"
"2.213321.231123111.222\n"
"144323342331.132321.31\n"
"22221234..422211421232\n"
"3.22133.343.31.14....1\n"
"4313.3332321..33441.12\n"
"42.234324134121331.122\n"
"132322214.3113221.3344\n"
"4424244222443434..2241\n"
"14413.2423224.33121414\n"
"12.3334.3434.44.123.43\n") == 0);
free(board503701572);
board503701572 = NULL;
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 21, 6) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 15, 17) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 3, 3, 12) == 1 );


char* board831333456 = gamma_board(board);
assert( board831333456 != NULL );
assert( strcmp(board831333456, 
"14244134313.3.421.3.23\n"
"24.34234.41..1411231.1\n"
"1144132..12.3331.33333\n"
"2.433124213313214.3422\n"
"424432431.124431231233\n"
"4221121..222341.141.44\n"
"2.213321.231123111.222\n"
"144323342331.132321.31\n"
"22221234..422211421232\n"
"3.22133.343.31.14....1\n"
"4313.3332321..33441.12\n"
"42.234324134121331.122\n"
"132322214.3113221.3344\n"
"4424244222443434..2241\n"
"14413.2423224.33121414\n"
"12.3334.3434.44.123.43\n") == 0);
free(board831333456);
board831333456 = NULL;
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_free_fields(board, 4) == 52 );


char* board742336010 = gamma_board(board);
assert( board742336010 != NULL );
assert( strcmp(board742336010, 
"14244134313.3.421.3.23\n"
"24.34234.41..1411231.1\n"
"1144132..12.3331.33333\n"
"2.433124213313214.3422\n"
"424432431.124431231233\n"
"4221121..222341.141.44\n"
"2.213321.231123111.222\n"
"144323342331.132321.31\n"
"22221234..422211421232\n"
"3.22133.343.31.14....1\n"
"4313.3332321..33441.12\n"
"42.234324134121331.122\n"
"132322214.3113221.3344\n"
"4424244222443434..2241\n"
"14413.2423224.33121414\n"
"12.3334.3434.44.123.43\n") == 0);
free(board742336010);
board742336010 = NULL;
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 6, 19) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 17, 14) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 8, 19) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 67 );


gamma_delete(board);

    return 0;
}
