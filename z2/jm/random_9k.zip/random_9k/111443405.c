#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 111443405
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 18, 9, 25);
assert( board != NULL );


assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_free_fields(board, 2) == 322 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_move(board, 5, 5, 11) == 1 );
assert( gamma_move(board, 6, 15, 2) == 1 );
assert( gamma_move(board, 6, 4, 10) == 1 );
assert( gamma_move(board, 7, 15, 17) == 1 );
assert( gamma_move(board, 8, 11, 9) == 1 );
assert( gamma_move(board, 9, 4, 8) == 1 );
assert( gamma_move(board, 9, 4, 13) == 1 );
assert( gamma_move(board, 1, 17, 16) == 1 );
assert( gamma_move(board, 1, 11, 12) == 1 );
assert( gamma_move(board, 2, 5, 16) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 3, 13, 7) == 1 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_move(board, 4, 0, 16) == 1 );
assert( gamma_busy_fields(board, 4) == 2 );
assert( gamma_move(board, 5, 9, 2) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 11, 5) == 1 );
assert( gamma_move(board, 6, 7, 7) == 1 );
assert( gamma_move(board, 7, 7, 5) == 1 );
assert( gamma_move(board, 7, 2, 13) == 1 );
assert( gamma_move(board, 8, 9, 4) == 1 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_move(board, 9, 15, 16) == 1 );
assert( gamma_move(board, 9, 1, 13) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_move(board, 2, 13, 6) == 1 );
assert( gamma_move(board, 4, 11, 15) == 1 );
assert( gamma_move(board, 4, 17, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_move(board, 5, 7, 4) == 1 );
assert( gamma_move(board, 6, 4, 10) == 0 );
assert( gamma_move(board, 6, 4, 14) == 1 );
assert( gamma_move(board, 7, 10, 9) == 1 );
assert( gamma_move(board, 7, 2, 1) == 1 );
assert( gamma_busy_fields(board, 7) == 5 );
assert( gamma_move(board, 8, 4, 15) == 1 );
assert( gamma_move(board, 9, 0, 8) == 1 );
assert( gamma_move(board, 9, 10, 12) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_move(board, 3, 17, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 4, 10, 6) == 1 );
assert( gamma_move(board, 5, 16, 8) == 1 );
assert( gamma_move(board, 5, 4, 4) == 1 );
assert( gamma_move(board, 6, 0, 11) == 1 );
assert( gamma_move(board, 7, 6, 12) == 1 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 6 );


char* board358110544 = gamma_board(board);
assert( board358110544 != NULL );
assert( strcmp(board358110544, 
"...............7..\n"
"4....2.........9.1\n"
"....8......4......\n"
"3...6.............\n"
".97.9.............\n"
"......7...91......\n"
"6.1..5............\n"
"....6.............\n"
".....1....78.....4\n"
"9...9...........5.\n"
".......6.....3...3\n"
".....5.1124..2....\n"
"...3...7...6......\n"
"..545..5.8........\n"
".....4............\n"
".........5.....6..\n"
"..7...............\n"
"7..3.......2......\n") == 0);
free(board358110544);
board358110544 = NULL;
assert( gamma_move(board, 2, 5, 13) == 1 );
assert( gamma_move(board, 2, 2, 0) == 1 );
assert( gamma_move(board, 3, 15, 8) == 1 );
assert( gamma_move(board, 5, 10, 1) == 1 );
assert( gamma_free_fields(board, 5) == 270 );
assert( gamma_move(board, 6, 14, 11) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board174251641 = gamma_board(board);
assert( board174251641 != NULL );
assert( strcmp(board174251641, 
"...............7..\n"
"4....2.........9.1\n"
"....8......4......\n"
"3...6.............\n"
".97.92............\n"
"......7...91......\n"
"6.1..5........6...\n"
"....6.............\n"
".....1....78.....4\n"
"9...9..........35.\n"
".......6.....3...3\n"
".....5.1124..2....\n"
"...3...7...6......\n"
"..545..5.8........\n"
".....4............\n"
".........5.....6..\n"
"..7.......5.......\n"
"7.23.......2......\n") == 0);
free(board174251641);
board174251641 = NULL;
assert( gamma_move(board, 7, 9, 15) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );


char* board931287678 = gamma_board(board);
assert( board931287678 != NULL );
assert( strcmp(board931287678, 
"...............7..\n"
"4....2.........9.1\n"
"....8....7.4......\n"
"3...6.............\n"
".97.92............\n"
"......7...91......\n"
"6.1..5........6...\n"
"....6.............\n"
".....1....78.....4\n"
"9...9..........35.\n"
".......6.....3...3\n"
".....5.1124..2....\n"
"...3...7...6......\n"
"..545..5.8........\n"
".....4............\n"
".........5.....6..\n"
"..7.......5.......\n"
"7.23.......2......\n") == 0);
free(board931287678);
board931287678 = NULL;
assert( gamma_move(board, 8, 2, 17) == 1 );
assert( gamma_move(board, 8, 3, 13) == 1 );
assert( gamma_busy_fields(board, 8) == 5 );
assert( gamma_move(board, 9, 11, 0) == 0 );
assert( gamma_move(board, 9, 3, 11) == 1 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_free_fields(board, 2) == 264 );
assert( gamma_move(board, 3, 11, 16) == 1 );
assert( gamma_free_fields(board, 3) == 263 );
assert( gamma_move(board, 5, 13, 5) == 1 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 1, 1) == 1 );
assert( gamma_move(board, 7, 11, 16) == 0 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 9, 14, 7) == 1 );
assert( gamma_move(board, 9, 6, 16) == 1 );
assert( gamma_free_fields(board, 9) == 259 );
assert( gamma_move(board, 1, 5, 10) == 1 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 2, 17, 3) == 1 );
assert( gamma_move(board, 3, 14, 1) == 1 );
assert( gamma_move(board, 4, 0, 13) == 1 );
assert( gamma_move(board, 5, 14, 8) == 1 );
assert( gamma_move(board, 6, 2, 12) == 1 );
assert( gamma_move(board, 6, 17, 13) == 1 );
assert( gamma_move(board, 7, 10, 7) == 1 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_move(board, 8, 6, 6) == 1 );
assert( gamma_move(board, 9, 12, 3) == 1 );
assert( gamma_move(board, 1, 14, 10) == 1 );
assert( gamma_move(board, 1, 3, 12) == 1 );
assert( gamma_move(board, 2, 15, 6) == 1 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_free_fields(board, 3) == 243 );
assert( gamma_move(board, 4, 7, 16) == 1 );
assert( gamma_move(board, 5, 1, 11) == 1 );
assert( gamma_move(board, 6, 6, 4) == 1 );
assert( gamma_move(board, 7, 9, 0) == 1 );
assert( gamma_move(board, 8, 3, 6) == 1 );
assert( gamma_move(board, 9, 3, 8) == 0 );
assert( gamma_move(board, 9, 15, 12) == 1 );
assert( gamma_move(board, 1, 7, 16) == 0 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_move(board, 2, 17, 8) == 1 );
assert( gamma_move(board, 3, 11, 10) == 1 );
assert( gamma_move(board, 4, 1, 14) == 1 );
assert( gamma_move(board, 4, 8, 16) == 1 );
assert( gamma_move(board, 5, 8, 14) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 15, 5) == 1 );
assert( gamma_free_fields(board, 6) == 230 );
assert( gamma_move(board, 7, 8, 9) == 1 );
assert( gamma_move(board, 8, 9, 14) == 1 );
assert( gamma_move(board, 8, 1, 9) == 1 );
assert( gamma_move(board, 9, 11, 12) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 5, 14) == 1 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 4, 2, 10) == 1 );
assert( gamma_move(board, 5, 4, 6) == 1 );
assert( gamma_free_fields(board, 5) == 223 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 7, 10, 15) == 1 );
assert( gamma_move(board, 7, 14, 3) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 2, 14) == 1 );
assert( gamma_move(board, 8, 2, 8) == 1 );
assert( gamma_golden_move(board, 8, 16, 17) == 0 );
assert( gamma_move(board, 9, 15, 4) == 1 );
assert( gamma_move(board, 1, 3, 15) == 1 );
assert( gamma_move(board, 2, 16, 9) == 1 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 4, 13, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 5, 4) == 1 );
assert( gamma_move(board, 5, 9, 17) == 1 );
assert( gamma_move(board, 6, 12, 8) == 1 );
assert( gamma_move(board, 6, 3, 7) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 10) == 1 );
assert( gamma_move(board, 8, 17, 9) == 0 );
assert( gamma_move(board, 8, 15, 3) == 1 );
assert( gamma_move(board, 9, 1, 6) == 1 );
assert( gamma_move(board, 9, 8, 7) == 0 );
assert( gamma_busy_fields(board, 9) == 13 );
assert( gamma_move(board, 1, 15, 17) == 0 );
assert( gamma_move(board, 1, 16, 14) == 1 );
assert( gamma_move(board, 2, 12, 0) == 1 );
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_move(board, 3, 14, 12) == 1 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 6, 2, 10) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 14) == 0 );
assert( gamma_move(board, 7, 11, 3) == 1 );
assert( gamma_golden_move(board, 7, 7, 7) == 1 );
assert( gamma_move(board, 8, 6, 13) == 1 );
assert( gamma_move(board, 9, 10, 6) == 0 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_move(board, 2, 5, 17) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 0, 4) == 1 );
assert( gamma_golden_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 6, 17, 11) == 1 );
assert( gamma_free_fields(board, 6) == 197 );
assert( gamma_move(board, 8, 11, 13) == 1 );
assert( gamma_move(board, 9, 4, 0) == 1 );
assert( gamma_busy_fields(board, 9) == 14 );
assert( gamma_golden_move(board, 9, 8, 17) == 0 );
assert( gamma_move(board, 1, 17, 6) == 1 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 4, 11) == 1 );
assert( gamma_move(board, 5, 4, 16) == 1 );
assert( gamma_move(board, 5, 14, 13) == 1 );
assert( gamma_free_fields(board, 5) == 190 );
assert( gamma_move(board, 6, 14, 3) == 0 );
assert( gamma_move(board, 7, 12, 7) == 1 );
assert( gamma_move(board, 7, 17, 1) == 1 );
assert( gamma_move(board, 8, 14, 14) == 1 );
assert( gamma_move(board, 1, 15, 14) == 1 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_move(board, 3, 15, 0) == 1 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 2, 14) == 0 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_free_fields(board, 5) == 184 );
assert( gamma_move(board, 6, 11, 10) == 0 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_free_fields(board, 6) == 184 );
assert( gamma_move(board, 7, 10, 10) == 1 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 4, 17) == 1 );
assert( gamma_move(board, 8, 5, 1) == 1 );
assert( gamma_move(board, 9, 9, 7) == 1 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 2, 17, 8) == 0 );
assert( gamma_move(board, 3, 10, 8) == 1 );
assert( gamma_move(board, 4, 3, 17) == 1 );
assert( gamma_free_fields(board, 4) == 177 );
assert( gamma_golden_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 5, 2, 3) == 1 );
assert( gamma_move(board, 6, 2, 5) == 1 );
assert( gamma_move(board, 6, 10, 4) == 1 );
assert( gamma_move(board, 7, 5, 5) == 1 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 1, 4) == 1 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 2, 16, 1) == 1 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_move(board, 5, 1, 12) == 1 );
assert( gamma_move(board, 6, 6, 14) == 1 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 21 );
assert( gamma_move(board, 8, 11, 16) == 0 );
assert( gamma_move(board, 9, 10, 15) == 0 );
assert( gamma_move(board, 9, 5, 17) == 0 );
assert( gamma_busy_fields(board, 9) == 15 );
assert( gamma_move(board, 1, 1, 15) == 1 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 4, 12, 10) == 1 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_move(board, 6, 3, 1) == 1 );
assert( gamma_move(board, 6, 3, 14) == 1 );
assert( gamma_move(board, 7, 16, 2) == 1 );
assert( gamma_move(board, 7, 9, 11) == 1 );
assert( gamma_move(board, 8, 10, 9) == 0 );
assert( gamma_move(board, 8, 9, 4) == 0 );
assert( gamma_move(board, 9, 15, 13) == 1 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 1, 9, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 5) == 1 );
assert( gamma_move(board, 5, 10, 15) == 0 );
assert( gamma_move(board, 6, 6, 9) == 1 );
assert( gamma_move(board, 7, 4, 12) == 1 );
assert( gamma_move(board, 8, 15, 13) == 0 );
assert( gamma_move(board, 9, 2, 12) == 0 );
assert( gamma_move(board, 9, 11, 1) == 1 );
assert( gamma_free_fields(board, 9) == 153 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 2, 9, 15) == 0 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 3, 16, 9) == 0 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 5, 14, 13) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 6, 4, 11) == 0 );
assert( gamma_move(board, 7, 12, 6) == 1 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 15, 12) == 0 );
assert( gamma_move(board, 9, 4, 11) == 0 );
assert( gamma_move(board, 9, 2, 17) == 0 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_move(board, 1, 15, 17) == 0 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 3, 3, 16) == 1 );
assert( gamma_golden_move(board, 3, 14, 16) == 0 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_free_fields(board, 4) == 148 );
assert( gamma_move(board, 5, 1, 2) == 1 );
assert( gamma_move(board, 5, 12, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 7, 3) == 1 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_move(board, 7, 4, 16) == 0 );
assert( gamma_move(board, 8, 13, 16) == 1 );
assert( gamma_move(board, 8, 5, 2) == 1 );
assert( gamma_golden_move(board, 8, 0, 3) == 0 );
assert( gamma_move(board, 9, 9, 12) == 1 );
assert( gamma_busy_fields(board, 9) == 18 );
assert( gamma_move(board, 1, 9, 15) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 11, 7) == 1 );
assert( gamma_move(board, 5, 15, 0) == 0 );
assert( gamma_move(board, 6, 14, 13) == 0 );
assert( gamma_move(board, 6, 14, 14) == 0 );
assert( gamma_free_fields(board, 6) == 141 );
assert( gamma_move(board, 7, 9, 4) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_move(board, 8, 6, 4) == 0 );
assert( gamma_move(board, 9, 6, 15) == 1 );
assert( gamma_move(board, 9, 3, 12) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 10, 16) == 1 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 3, 15, 9) == 1 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 5, 12, 5) == 1 );
assert( gamma_move(board, 5, 3, 9) == 1 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 7, 12, 10) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_move(board, 9, 16, 10) == 1 );
assert( gamma_move(board, 9, 5, 5) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 16, 0) == 1 );
assert( gamma_move(board, 3, 7, 15) == 1 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 4, 1, 1) == 0 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_move(board, 6, 7, 11) == 1 );
assert( gamma_move(board, 6, 15, 3) == 0 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 8, 7, 2) == 1 );
assert( gamma_move(board, 8, 0, 1) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 4, 14) == 0 );
assert( gamma_move(board, 1, 9, 10) == 1 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 17) == 1 );
assert( gamma_move(board, 5, 5, 17) == 0 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 6, 12, 16) == 1 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_move(board, 8, 1, 6) == 0 );
assert( gamma_move(board, 8, 1, 15) == 0 );
assert( gamma_busy_fields(board, 8) == 22 );
assert( gamma_move(board, 9, 11, 17) == 1 );
assert( gamma_move(board, 9, 14, 6) == 1 );
assert( gamma_move(board, 1, 2, 16) == 1 );
assert( gamma_move(board, 1, 6, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 23 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_move(board, 3, 4, 14) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_free_fields(board, 3) == 122 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 5, 14) == 0 );
assert( gamma_move(board, 7, 16, 16) == 1 );
assert( gamma_move(board, 8, 11, 10) == 0 );
assert( gamma_move(board, 9, 13, 12) == 1 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_golden_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 14, 12) == 0 );
assert( gamma_move(board, 5, 10, 17) == 1 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_free_fields(board, 6) == 119 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_golden_move(board, 7, 6, 4) == 0 );
assert( gamma_move(board, 8, 11, 11) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 16, 1) == 0 );
assert( gamma_move(board, 9, 7, 9) == 1 );
assert( gamma_busy_fields(board, 9) == 23 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 2, 16, 8) == 0 );
assert( gamma_move(board, 2, 13, 13) == 1 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 4, 17) == 0 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_move(board, 6, 11, 8) == 1 );
assert( gamma_free_fields(board, 6) == 115 );
assert( gamma_move(board, 7, 10, 6) == 0 );
assert( gamma_move(board, 8, 1, 7) == 1 );
assert( gamma_move(board, 8, 2, 15) == 1 );
assert( gamma_move(board, 9, 14, 12) == 0 );
assert( gamma_move(board, 9, 7, 7) == 0 );
assert( gamma_busy_fields(board, 9) == 23 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 13, 1) == 1 );
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_move(board, 7, 4, 3) == 1 );
assert( gamma_move(board, 8, 16, 17) == 1 );
assert( gamma_move(board, 8, 14, 16) == 1 );
assert( gamma_move(board, 9, 3, 5) == 0 );
assert( gamma_move(board, 9, 13, 9) == 0 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_move(board, 2, 16, 11) == 1 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 17, 13) == 0 );
assert( gamma_move(board, 4, 4, 17) == 0 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_free_fields(board, 4) == 107 );
assert( gamma_move(board, 5, 3, 16) == 0 );
assert( gamma_move(board, 5, 6, 11) == 1 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_move(board, 7, 17, 3) == 0 );
assert( gamma_move(board, 8, 6, 11) == 0 );
assert( gamma_move(board, 8, 7, 2) == 0 );
assert( gamma_move(board, 9, 2, 2) == 1 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 1, 17, 8) == 0 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 17, 7) == 0 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 6, 15, 12) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 10, 14) == 0 );
assert( gamma_move(board, 7, 2, 8) == 0 );
assert( gamma_move(board, 8, 3, 11) == 0 );
assert( gamma_move(board, 8, 12, 3) == 0 );
assert( gamma_move(board, 9, 1, 4) == 0 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 12, 6) == 1 );


char* board252142090 = gamma_board(board);
assert( board252142090 != NULL );
assert( strcmp(board252142090, 
"..8482..4559...78.\n"
"4.1352944.23688971\n"
".1818.93.774......\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.939..\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...366.5352\n"
"48.63..73975739..3\n"
"19.85581124.1292.1\n"
"2463.7.74..655.6..\n"
"58545565.86.5..9..\n"
"..5.74462.179.78.2\n"
"559..818.5.....67.\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224.32.\n") == 0);
free(board252142090);
board252142090 = NULL;
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );


char* board481910050 = gamma_board(board);
assert( board481910050 != NULL );
assert( strcmp(board481910050, 
"..8482..4559...78.\n"
"4.1352944.23688971\n"
".1818.93.774......\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.939..\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...366.5352\n"
"48.63..73975739..3\n"
"19.85581124.1292.1\n"
"2463.7.74..655.6..\n"
"58545565.86.5..9..\n"
"..5.74462.179.78.2\n"
"559..818.5.....67.\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224.32.\n") == 0);
free(board481910050);
board481910050 = NULL;
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_move(board, 4, 7, 16) == 0 );
assert( gamma_move(board, 6, 17, 2) == 1 );
assert( gamma_move(board, 6, 17, 3) == 0 );
assert( gamma_move(board, 7, 2, 10) == 0 );
assert( gamma_move(board, 8, 10, 16) == 0 );
assert( gamma_move(board, 8, 0, 14) == 0 );
assert( gamma_move(board, 9, 6, 7) == 1 );
assert( gamma_move(board, 9, 4, 6) == 0 );


char* board456754330 = gamma_board(board);
assert( board456754330 != NULL );
assert( strcmp(board456754330, 
"..8482..4559...78.\n"
"4.1352944.23688971\n"
".1818.93.774......\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.939..\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...366.5352\n"
"48.63.973975739..3\n"
"19.85581124.1292.1\n"
"2463.7.74..655.6..\n"
"58545565.86.5..9..\n"
"..5.74462.179.78.2\n"
"559..818.5.....676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224.32.\n") == 0);
free(board456754330);
board456754330 = NULL;
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );


char* board786720930 = gamma_board(board);
assert( board786720930 != NULL );
assert( strcmp(board786720930, 
"..8482..4559...78.\n"
"4.1352944.23688971\n"
".1818.93.774......\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.939..\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...366.5352\n"
"48.63.973975739..3\n"
"19.85581124.1292.1\n"
"2463.7.74..655.6..\n"
"58545565.86.5..9..\n"
"..5.74462.179.78.2\n"
"559..818.5.....676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224.32.\n") == 0);
free(board786720930);
board786720930 = NULL;
assert( gamma_move(board, 2, 7, 16) == 0 );
assert( gamma_free_fields(board, 2) == 102 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 3, 16, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_free_fields(board, 5) == 102 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_move(board, 7, 3, 16) == 0 );
assert( gamma_move(board, 8, 5, 17) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 5, 16) == 0 );
assert( gamma_move(board, 9, 17, 8) == 0 );
assert( gamma_move(board, 2, 16, 1) == 0 );
assert( gamma_move(board, 2, 10, 15) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 5, 10, 17) == 0 );
assert( gamma_move(board, 5, 8, 16) == 0 );
assert( gamma_move(board, 6, 14, 13) == 0 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_move(board, 7, 11, 1) == 0 );
assert( gamma_move(board, 8, 15, 12) == 0 );
assert( gamma_move(board, 8, 14, 16) == 0 );
assert( gamma_move(board, 9, 7, 15) == 0 );
assert( gamma_move(board, 1, 14, 0) == 1 );
assert( gamma_move(board, 1, 13, 17) == 1 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 14, 13) == 0 );
assert( gamma_move(board, 3, 16, 12) == 1 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_golden_move(board, 4, 16, 11) == 0 );
assert( gamma_move(board, 5, 14, 4) == 1 );
assert( gamma_busy_fields(board, 5) == 29 );
assert( gamma_move(board, 6, 7, 16) == 0 );
assert( gamma_move(board, 7, 9, 4) == 0 );
assert( gamma_move(board, 8, 1, 6) == 0 );
assert( gamma_move(board, 9, 13, 9) == 0 );
assert( gamma_golden_move(board, 9, 15, 3) == 1 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 17, 15) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 29 );
assert( gamma_move(board, 6, 10, 15) == 0 );
assert( gamma_move(board, 7, 5, 9) == 0 );
assert( gamma_move(board, 8, 0, 17) == 1 );
assert( gamma_move(board, 8, 3, 14) == 0 );
assert( gamma_move(board, 9, 3, 3) == 1 );
assert( gamma_move(board, 9, 2, 14) == 0 );
assert( gamma_golden_move(board, 9, 0, 15) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 1, 13, 8) == 1 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 15, 13) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 5, 2, 17) == 0 );
assert( gamma_move(board, 6, 4, 13) == 0 );
assert( gamma_move(board, 6, 9, 3) == 1 );
assert( gamma_move(board, 7, 15, 12) == 0 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_move(board, 8, 2, 1) == 0 );
assert( gamma_move(board, 9, 2, 16) == 0 );
assert( gamma_busy_fields(board, 9) == 27 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 5, 14, 2) == 1 );
assert( gamma_move(board, 5, 4, 4) == 0 );
assert( gamma_move(board, 6, 14, 7) == 0 );


char* board590962709 = gamma_board(board);
assert( board590962709 != NULL );
assert( strcmp(board590962709, 
"8.8482..4559.1.78.\n"
"4.1352944.23688971\n"
".1818.93.774.....4\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.9393.\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739..3\n"
"19.85581124.1292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5.59..\n"
"..59744626179.79.2\n"
"559..818.5....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board590962709);
board590962709 = NULL;
assert( gamma_move(board, 7, 3, 16) == 0 );
assert( gamma_move(board, 7, 3, 16) == 0 );
assert( gamma_move(board, 8, 10, 8) == 0 );
assert( gamma_move(board, 8, 10, 12) == 0 );
assert( gamma_move(board, 9, 6, 2) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );


char* board208707213 = gamma_board(board);
assert( board208707213 != NULL );
assert( strcmp(board208707213, 
"8.8482..4559.1.78.\n"
"4.1352944.23688971\n"
".1818.93.774.....4\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.9393.\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739..3\n"
"19.85581124.1292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5.59..\n"
"..59744626179.79.2\n"
"559..818.5....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board208707213);
board208707213 = NULL;
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 5, 15, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 30 );
assert( gamma_move(board, 6, 12, 17) == 1 );
assert( gamma_move(board, 7, 11, 10) == 0 );
assert( gamma_move(board, 7, 1, 2) == 0 );


char* board185163891 = gamma_board(board);
assert( board185163891 != NULL );
assert( strcmp(board185163891, 
"8.8482..455961.78.\n"
"4.1352944.23688971\n"
".1818.93.774.....4\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.9393.\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739..3\n"
"19.85581124.1292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5.59..\n"
"..59744626179.79.2\n"
"559..818.5....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board185163891);
board185163891 = NULL;
assert( gamma_move(board, 8, 15, 15) == 1 );


char* board711094099 = gamma_board(board);
assert( board711094099 != NULL );
assert( strcmp(board711094099, 
"8.8482..455961.78.\n"
"4.1352944.23688971\n"
".1818.93.774...8.4\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.9393.\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739..3\n"
"19.85581124.1292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5.59..\n"
"..59744626179.79.2\n"
"559..818.5....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board711094099);
board711094099 = NULL;
assert( gamma_move(board, 9, 2, 6) == 1 );
assert( gamma_move(board, 9, 12, 6) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 1, 16, 7) == 1 );
assert( gamma_free_fields(board, 1) == 26 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 3) == 0 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 26 );
assert( gamma_move(board, 8, 3, 11) == 0 );
assert( gamma_move(board, 8, 12, 15) == 0 );
assert( gamma_move(board, 9, 14, 13) == 0 );


char* board751571217 = gamma_board(board);
assert( board751571217 != NULL );
assert( strcmp(board751571217, 
"8.8482..455961.78.\n"
"4.1352944.23688971\n"
".1818.93.774...8.4\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.9393.\n"
"65194556.7.8..6.26\n"
"474.61.3.1734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739.13\n"
"19985581124.1292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5.59..\n"
"..59744626179.79.2\n"
"559..818.5....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board751571217);
board751571217 = NULL;
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 4, 15, 16) == 0 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_golden_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 5, 3, 2) == 1 );
assert( gamma_move(board, 5, 16, 2) == 0 );
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 7, 9, 7) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 8, 14) == 0 );
assert( gamma_move(board, 9, 5, 9) == 0 );
assert( gamma_move(board, 9, 8, 10) == 1 );
assert( gamma_golden_move(board, 9, 15, 7) == 0 );


char* board753863150 = gamma_board(board);
assert( board753863150 != NULL );
assert( strcmp(board753863150, 
"8.8482..455961.78.\n"
"4.1352944.23688971\n"
"21818.93.774...8.4\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.9393.\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"28.5.1697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739.13\n"
"19985581124.1292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5.59..\n"
"..59744626179.79.2\n"
"5595.818.5....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board753863150);
board753863150 = NULL;
assert( gamma_move(board, 1, 8, 2) == 1 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 3, 17, 15) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 4, 9) == 1 );
assert( gamma_move(board, 5, 14, 13) == 0 );
assert( gamma_move(board, 5, 13, 16) == 0 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 8, 4, 13) == 0 );
assert( gamma_move(board, 8, 11, 13) == 0 );
assert( gamma_busy_fields(board, 8) == 28 );
assert( gamma_move(board, 9, 4, 0) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 15, 13) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board284960076 = gamma_board(board);
assert( board284960076 != NULL );
assert( strcmp(board284960076, 
"8.8482..455961.78.\n"
"4.1352944.23688971\n"
"21818.93.774...8.4\n"
"3486616.58....811.\n"
"4378928...28.259.6\n"
".5617.7..991.9393.\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"28.541697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739.13\n"
"19985581124.1292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5.59..\n"
"..59744626179.79.2\n"
"5595.81815....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board284960076);
board284960076 = NULL;
assert( gamma_move(board, 5, 7, 16) == 0 );
assert( gamma_move(board, 7, 14, 3) == 0 );
assert( gamma_move(board, 8, 1, 6) == 0 );
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_move(board, 9, 15, 13) == 0 );
assert( gamma_move(board, 1, 17, 6) == 0 );
assert( gamma_move(board, 2, 13, 15) == 1 );
assert( gamma_move(board, 2, 16, 13) == 1 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_free_fields(board, 3) == 80 );
assert( gamma_golden_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 4, 12, 17) == 0 );
assert( gamma_move(board, 6, 3, 16) == 0 );
assert( gamma_move(board, 6, 15, 13) == 0 );
assert( gamma_free_fields(board, 6) == 80 );
assert( gamma_move(board, 7, 5, 14) == 0 );
assert( gamma_move(board, 8, 2, 11) == 0 );
assert( gamma_move(board, 8, 3, 3) == 0 );
assert( gamma_move(board, 9, 11, 6) == 1 );
assert( gamma_busy_fields(board, 9) == 30 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_move(board, 2, 15, 8) == 0 );
assert( gamma_move(board, 2, 5, 15) == 1 );
assert( gamma_move(board, 3, 17, 12) == 1 );
assert( gamma_move(board, 4, 14, 17) == 1 );
assert( gamma_move(board, 4, 13, 4) == 1 );
assert( gamma_free_fields(board, 4) == 75 );
assert( gamma_move(board, 5, 16, 1) == 0 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 7, 14, 12) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_move(board, 8, 3, 12) == 0 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 16, 9) == 0 );
assert( gamma_move(board, 5, 10, 13) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_free_fields(board, 5) == 75 );
assert( gamma_move(board, 6, 6, 16) == 0 );
assert( gamma_move(board, 7, 10, 15) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_move(board, 9, 1, 6) == 0 );
assert( gamma_move(board, 9, 16, 16) == 0 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 4, 7, 12) == 1 );
assert( gamma_move(board, 5, 17, 6) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_move(board, 6, 14, 17) == 0 );
assert( gamma_move(board, 7, 4, 16) == 0 );
assert( gamma_move(board, 7, 2, 5) == 0 );
assert( gamma_move(board, 8, 2, 12) == 0 );
assert( gamma_free_fields(board, 8) == 23 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 7, 2) == 0 );
assert( gamma_move(board, 9, 9, 2) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 1, 17) == 0 );
assert( gamma_move(board, 3, 12, 13) == 1 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 5, 11, 15) == 0 );
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_golden_move(board, 5, 1, 3) == 0 );
assert( gamma_move(board, 7, 11, 15) == 0 );
assert( gamma_move(board, 8, 8, 9) == 0 );
assert( gamma_move(board, 8, 7, 4) == 0 );
assert( gamma_free_fields(board, 8) == 22 );
assert( gamma_move(board, 9, 11, 13) == 0 );
assert( gamma_move(board, 9, 9, 14) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );


char* board419191669 = gamma_board(board);
assert( board419191669 != NULL );
assert( strcmp(board419191669, 
"8.8482..455961478.\n"
"4.1352944.23688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"4378928...28325926\n"
".5617.74.991.93933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"28.541697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739.13\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595.81815....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board419191669);
board419191669 = NULL;
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 9, 15) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 5, 17, 17) == 1 );
assert( gamma_move(board, 5, 12, 16) == 0 );
assert( gamma_free_fields(board, 5) == 72 );


char* board924710151 = gamma_board(board);
assert( board924710151 != NULL );
assert( strcmp(board924710151, 
"8.8482..4559614785\n"
"4.1352944.23688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"4378928...28325926\n"
".5617.74.991.93933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"28.541697478.2.324\n"
"93829.1...36615352\n"
"48.63.973975739.13\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595.81815....5676\n"
"8776.8..1.59.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board924710151);
board924710151 = NULL;
assert( gamma_move(board, 6, 12, 12) == 1 );
assert( gamma_move(board, 6, 11, 7) == 0 );
assert( gamma_move(board, 7, 8, 8) == 1 );
assert( gamma_move(board, 8, 15, 12) == 0 );
assert( gamma_busy_fields(board, 8) == 28 );
assert( gamma_move(board, 9, 10, 3) == 0 );
assert( gamma_move(board, 9, 17, 2) == 0 );
assert( gamma_move(board, 1, 6, 15) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 29 );
assert( gamma_free_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 5, 15, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 32 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 6, 9, 1) == 1 );
assert( gamma_move(board, 7, 15, 4) == 0 );
assert( gamma_move(board, 8, 14, 13) == 0 );
assert( gamma_move(board, 8, 17, 9) == 0 );
assert( gamma_free_fields(board, 8) == 21 );
assert( gamma_move(board, 9, 7, 8) == 1 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 9, 16) == 1 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_free_fields(board, 3) == 67 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 5, 3, 7) == 0 );


char* board950748158 = gamma_board(board);
assert( board950748158 != NULL );
assert( strcmp(board950748158, 
"8.8482..4559614785\n"
"4.1352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"4378928...28325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"28.541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739.13\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595.81815....5676\n"
"8776.8..1659.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board950748158);
board950748158 = NULL;
assert( gamma_move(board, 6, 10, 6) == 0 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_golden_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 8, 6, 11) == 0 );
assert( gamma_golden_move(board, 8, 8, 0) == 0 );
assert( gamma_move(board, 9, 13, 12) == 0 );
assert( gamma_move(board, 9, 2, 9) == 1 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_move(board, 2, 15, 7) == 1 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 5, 11, 12) == 0 );
assert( gamma_free_fields(board, 5) == 65 );
assert( gamma_move(board, 6, 11, 12) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_move(board, 8, 9, 2) == 0 );
assert( gamma_move(board, 8, 7, 8) == 0 );
assert( gamma_move(board, 9, 6, 16) == 0 );
assert( gamma_move(board, 9, 9, 13) == 1 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );


char* board903333022 = gamma_board(board);
assert( board903333022 != NULL );
assert( strcmp(board903333022, 
"8.8482..4559614785\n"
"4.1352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"4378928..928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595.81815....5676\n"
"8776.8..1659.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board903333022);
board903333022 = NULL;
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 3, 15, 15) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 4, 3, 16) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 7, 15, 8) == 0 );
assert( gamma_move(board, 7, 11, 10) == 0 );
assert( gamma_free_fields(board, 7) == 64 );
assert( gamma_move(board, 8, 3, 13) == 0 );
assert( gamma_move(board, 9, 6, 5) == 0 );
assert( gamma_golden_move(board, 9, 10, 14) == 0 );
assert( gamma_move(board, 1, 15, 14) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_free_fields(board, 3) == 64 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_move(board, 5, 11, 15) == 0 );
assert( gamma_move(board, 6, 17, 1) == 0 );
assert( gamma_move(board, 6, 10, 14) == 0 );
assert( gamma_move(board, 7, 15, 9) == 0 );
assert( gamma_golden_move(board, 7, 16, 3) == 0 );
assert( gamma_move(board, 8, 2, 2) == 0 );
assert( gamma_move(board, 8, 15, 4) == 0 );
assert( gamma_move(board, 9, 4, 11) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_free_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 17, 4) == 0 );


char* board428095986 = gamma_board(board);
assert( board428095986 != NULL );
assert( strcmp(board428095986, 
"8.8482..4559614785\n"
"4.1352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"4378928..928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595.81815....5676\n"
"8776.8..1659.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board428095986);
board428095986 = NULL;
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 15, 8) == 0 );
assert( gamma_move(board, 7, 13, 8) == 0 );
assert( gamma_move(board, 7, 11, 3) == 0 );
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_move(board, 8, 4, 2) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 0, 17) == 0 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_free_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 4, 10, 17) == 0 );
assert( gamma_move(board, 4, 6, 1) == 0 );


char* board643569417 = gamma_board(board);
assert( board643569417 != NULL );
assert( strcmp(board643569417, 
"8.8482..4559614785\n"
"4.1352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"4378928..928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"8776.8..1659.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board643569417);
board643569417 = NULL;
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_move(board, 5, 6, 16) == 0 );
assert( gamma_move(board, 6, 10, 15) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );


char* board899596063 = gamma_board(board);
assert( board899596063 != NULL );
assert( strcmp(board899596063, 
"8.8482..4559614785\n"
"4.1352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"4378928..928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"8776.8..1659.43.27\n"
"71239.2.27.224132.\n") == 0);
free(board899596063);
board899596063 = NULL;
assert( gamma_move(board, 7, 7, 1) == 1 );
assert( gamma_move(board, 9, 10, 2) == 0 );
assert( gamma_move(board, 1, 15, 16) == 0 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_move(board, 2, 16, 17) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 5, 10, 17) == 0 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_golden_move(board, 6, 10, 11) == 0 );
assert( gamma_move(board, 7, 15, 12) == 0 );
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_move(board, 9, 10, 17) == 0 );
assert( gamma_move(board, 9, 9, 12) == 0 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 4, 15) == 0 );
assert( gamma_move(board, 5, 15, 15) == 0 );
assert( gamma_busy_fields(board, 5) == 32 );
assert( gamma_move(board, 6, 13, 7) == 0 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 8, 9, 12) == 0 );
assert( gamma_move(board, 8, 15, 7) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 11, 12) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 5, 14, 17) == 0 );
assert( gamma_move(board, 5, 4, 1) == 1 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_free_fields(board, 6) == 18 );
assert( gamma_move(board, 7, 5, 17) == 0 );
assert( gamma_move(board, 7, 1, 16) == 1 );
assert( gamma_move(board, 8, 17, 1) == 0 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_move(board, 1, 8, 17) == 0 );
assert( gamma_move(board, 2, 4, 16) == 0 );
assert( gamma_move(board, 2, 12, 12) == 0 );
assert( gamma_golden_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 5, 15, 1) == 1 );
assert( gamma_move(board, 6, 11, 15) == 0 );
assert( gamma_move(board, 6, 8, 16) == 0 );
assert( gamma_move(board, 7, 10, 15) == 0 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_move(board, 8, 16, 6) == 0 );
assert( gamma_move(board, 8, 7, 13) == 1 );


char* board940551264 = gamma_board(board);
assert( board940551264 != NULL );
assert( strcmp(board940551264, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board940551264);
board940551264 = NULL;
assert( gamma_move(board, 9, 12, 0) == 0 );
assert( gamma_free_fields(board, 9) == 22 );
assert( gamma_free_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 13, 17) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 5, 13, 11) == 0 );
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 7, 7, 9) == 0 );
assert( gamma_busy_fields(board, 7) == 29 );
assert( gamma_move(board, 8, 5, 17) == 0 );
assert( gamma_move(board, 8, 7, 4) == 0 );
assert( gamma_move(board, 9, 15, 16) == 0 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );


char* board441313116 = gamma_board(board);
assert( board441313116 != NULL );
assert( strcmp(board441313116, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board441313116);
board441313116 = NULL;
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 4, 17, 3) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );


char* board855824898 = gamma_board(board);
assert( board855824898 != NULL );
assert( strcmp(board855824898, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board855824898);
board855824898 = NULL;
assert( gamma_move(board, 7, 12, 15) == 0 );
assert( gamma_free_fields(board, 7) == 17 );
assert( gamma_golden_move(board, 7, 5, 3) == 0 );
assert( gamma_move(board, 8, 3, 16) == 0 );


char* board304664801 = gamma_board(board);
assert( board304664801 != NULL );
assert( strcmp(board304664801, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board304664801);
board304664801 = NULL;
assert( gamma_move(board, 9, 5, 9) == 0 );
assert( gamma_move(board, 9, 3, 6) == 0 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );


char* board766580705 = gamma_board(board);
assert( board766580705 != NULL );
assert( strcmp(board766580705, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.774.2.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board766580705);
board766580705 = NULL;
assert( gamma_move(board, 2, 15, 12) == 0 );
assert( gamma_move(board, 2, 16, 15) == 0 );
assert( gamma_move(board, 3, 14, 12) == 0 );
assert( gamma_move(board, 3, 12, 15) == 1 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );


char* board883563162 = gamma_board(board);
assert( board883563162 != NULL );
assert( strcmp(board883563162, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.77432.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board883563162);
board883563162 = NULL;
assert( gamma_move(board, 6, 12, 0) == 0 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 5, 4) == 0 );
assert( gamma_move(board, 7, 11, 8) == 0 );


char* board140534070 = gamma_board(board);
assert( board140534070 != NULL );
assert( strcmp(board140534070, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.77432.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474.61.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board140534070);
board140534070 = NULL;
assert( gamma_move(board, 8, 5, 16) == 0 );
assert( gamma_move(board, 8, 0, 14) == 0 );
assert( gamma_move(board, 9, 12, 5) == 0 );
assert( gamma_move(board, 9, 12, 4) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 12) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_move(board, 5, 10, 15) == 0 );
assert( gamma_move(board, 6, 15, 8) == 0 );
assert( gamma_move(board, 6, 15, 0) == 0 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 7, 13, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 29 );
assert( gamma_move(board, 8, 12, 0) == 0 );
assert( gamma_move(board, 9, 2, 11) == 0 );
assert( gamma_move(board, 9, 1, 6) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 4, 3, 10) == 1 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 5, 17, 10) == 0 );
assert( gamma_move(board, 6, 5, 16) == 0 );
assert( gamma_move(board, 6, 13, 7) == 0 );
assert( gamma_move(board, 7, 3, 9) == 0 );
assert( gamma_move(board, 7, 0, 17) == 0 );
assert( gamma_move(board, 8, 4, 7) == 0 );


char* board438850107 = gamma_board(board);
assert( board438850107 != NULL );
assert( strcmp(board438850107, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.77432.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474461.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board438850107);
board438850107 = NULL;
assert( gamma_move(board, 9, 13, 14) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );


char* board637354220 = gamma_board(board);
assert( board637354220 != NULL );
assert( strcmp(board637354220, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.77432.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474461.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board637354220);
board637354220 = NULL;
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 3, 4, 16) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 5, 6, 16) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 5, 17) == 0 );
assert( gamma_move(board, 7, 10, 17) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 0, 7) == 0 );
assert( gamma_move(board, 8, 3, 6) == 0 );
assert( gamma_move(board, 9, 16, 15) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 17, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 5, 10, 17) == 0 );
assert( gamma_move(board, 6, 5, 10) == 0 );
assert( gamma_golden_move(board, 6, 9, 17) == 0 );
assert( gamma_move(board, 7, 15, 16) == 0 );
assert( gamma_move(board, 7, 17, 10) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 17, 7) == 0 );
assert( gamma_move(board, 9, 17, 1) == 0 );
assert( gamma_move(board, 9, 2, 1) == 0 );
assert( gamma_move(board, 1, 4, 16) == 0 );
assert( gamma_move(board, 1, 15, 14) == 0 );


char* board118473153 = gamma_board(board);
assert( board118473153 != NULL );
assert( strcmp(board118473153, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.77432.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474461.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815....5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board118473153);
board118473153 = NULL;
assert( gamma_move(board, 2, 17, 17) == 0 );
assert( gamma_move(board, 3, 15, 8) == 0 );
assert( gamma_move(board, 3, 17, 17) == 0 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 2, 2) == 0 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 6, 5, 16) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 9, 14) == 0 );
assert( gamma_move(board, 8, 9, 13) == 0 );
assert( gamma_move(board, 9, 6, 13) == 0 );
assert( gamma_golden_move(board, 9, 13, 14) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_golden_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 4, 17, 1) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_free_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 13, 8) == 0 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_free_fields(board, 7) == 17 );
assert( gamma_move(board, 8, 11, 10) == 0 );
assert( gamma_move(board, 8, 11, 7) == 0 );
assert( gamma_move(board, 9, 5, 3) == 0 );
assert( gamma_move(board, 9, 12, 13) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 3, 16) == 0 );
assert( gamma_move(board, 6, 8, 17) == 0 );
assert( gamma_move(board, 6, 8, 12) == 0 );
assert( gamma_move(board, 7, 7, 5) == 0 );
assert( gamma_move(board, 8, 5, 17) == 0 );
assert( gamma_move(board, 8, 17, 14) == 0 );
assert( gamma_move(board, 9, 6, 12) == 0 );
assert( gamma_move(board, 1, 11, 15) == 0 );
assert( gamma_move(board, 1, 3, 17) == 0 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 4, 4, 17) == 0 );
assert( gamma_move(board, 5, 4, 16) == 0 );
assert( gamma_move(board, 6, 11, 13) == 0 );
assert( gamma_move(board, 6, 3, 15) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 7, 9, 12) == 0 );
assert( gamma_move(board, 8, 5, 9) == 0 );
assert( gamma_move(board, 8, 1, 4) == 0 );
assert( gamma_move(board, 9, 11, 8) == 0 );
assert( gamma_move(board, 9, 12, 2) == 1 );
assert( gamma_move(board, 1, 1, 16) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_move(board, 3, 11, 13) == 0 );


char* board486030878 = gamma_board(board);
assert( board486030878 != NULL );
assert( strcmp(board486030878, 
"8.8482..4559614785\n"
"471352944223688971\n"
"21818293.77432.8.4\n"
"3486616.58....811.\n"
"43789288.928325926\n"
".5617.74.991693933\n"
"65194556.7.8..6.26\n"
"474461.391734.1.9.\n"
"289541697478.2.324\n"
"93829.197.36615352\n"
"48.63.973975739213\n"
"1998558112491292.1\n"
"2463.7474..655.6..\n"
"58545565.86.5459..\n"
"..59744626179.79.2\n"
"5595881815..9.5676\n"
"877658.71659.43527\n"
"71239.2.27.224132.\n") == 0);
free(board486030878);
board486030878 = NULL;
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 15, 14) == 0 );
assert( gamma_move(board, 5, 7, 14) == 1 );
assert( gamma_move(board, 6, 6, 15) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 10, 3) == 0 );
assert( gamma_move(board, 7, 8, 13) == 0 );
assert( gamma_busy_fields(board, 7) == 29 );
assert( gamma_golden_move(board, 7, 17, 10) == 0 );
assert( gamma_move(board, 8, 17, 7) == 0 );
assert( gamma_move(board, 9, 1, 15) == 0 );
assert( gamma_move(board, 9, 10, 6) == 0 );


gamma_delete(board);

    return 0;
}
