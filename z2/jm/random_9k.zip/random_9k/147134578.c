#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 147134578
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 56, 3, 22);
assert( board != NULL );


assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 0, 24) == 1 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 3, 0, 49) == 1 );
assert( gamma_move(board, 3, 0, 28) == 1 );
assert( gamma_busy_fields(board, 3) == 2 );
assert( gamma_move(board, 1, 0, 39) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );
assert( gamma_move(board, 2, 23, 0) == 0 );
assert( gamma_move(board, 2, 0, 53) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 51, 0) == 0 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 0, 24) == 0 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_move(board, 2, 0, 28) == 0 );
assert( gamma_move(board, 3, 51, 0) == 0 );
assert( gamma_move(board, 3, 0, 26) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_free_fields(board, 1) == 47 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 3, 0, 35) == 1 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 1, 0, 41) == 1 );
assert( gamma_move(board, 2, 33, 0) == 0 );
assert( gamma_move(board, 2, 0, 47) == 1 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 21, 0) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 1, 0, 34) == 1 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 1, 0, 19) == 1 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_move(board, 2, 0, 18) == 1 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 1, 31, 0) == 0 );
assert( gamma_move(board, 2, 0, 50) == 1 );
assert( gamma_move(board, 2, 0, 10) == 1 );
assert( gamma_move(board, 3, 0, 45) == 1 );
assert( gamma_move(board, 1, 0, 28) == 0 );
assert( gamma_move(board, 1, 0, 34) == 0 );
assert( gamma_free_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 0, 45) == 0 );
assert( gamma_move(board, 3, 0, 19) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 20, 0) == 0 );
assert( gamma_move(board, 2, 0, 33) == 1 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 46) == 1 );
assert( gamma_busy_fields(board, 3) == 7 );
assert( gamma_golden_move(board, 3, 47, 0) == 0 );


char* board944675277 = gamma_board(board);
assert( board944675277 != NULL );
assert( strcmp(board944675277, 
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"3\n"
".\n"
"2\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"1\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"3\n") == 0);
free(board944675277);
board944675277 = NULL;
assert( gamma_move(board, 1, 52, 0) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_golden_move(board, 1, 28, 0) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 0, 30) == 1 );
assert( gamma_move(board, 3, 0, 40) == 1 );
assert( gamma_move(board, 3, 0, 6) == 1 );
assert( gamma_move(board, 1, 0, 29) == 1 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 36, 0) == 0 );
assert( gamma_move(board, 3, 43, 0) == 0 );
assert( gamma_golden_move(board, 3, 53, 0) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );


char* board431252004 = gamma_board(board);
assert( board431252004 != NULL );
assert( strcmp(board431252004, 
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"3\n"
".\n"
"2\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"1\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"3\n") == 0);
free(board431252004);
board431252004 = NULL;
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 2, 0, 43) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 21, 0) == 0 );
assert( gamma_move(board, 3, 0, 16) == 1 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 0, 50) == 0 );
assert( gamma_move(board, 3, 0, 47) == 0 );
assert( gamma_move(board, 3, 0, 48) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 20, 0) == 0 );
assert( gamma_move(board, 2, 0, 51) == 1 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_free_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 31, 0) == 0 );
assert( gamma_move(board, 3, 54, 0) == 0 );
assert( gamma_move(board, 2, 32, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board603864459 = gamma_board(board);
assert( board603864459 != NULL );
assert( strcmp(board603864459, 
".\n"
".\n"
"2\n"
".\n"
"2\n"
"2\n"
"3\n"
"3\n"
"2\n"
"3\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"3\n"
"2\n"
"1\n"
"1\n"
"1\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
"3\n") == 0);
free(board603864459);
board603864459 = NULL;
assert( gamma_move(board, 3, 52, 0) == 0 );
assert( gamma_move(board, 3, 0, 38) == 1 );
assert( gamma_move(board, 1, 25, 0) == 0 );
assert( gamma_move(board, 2, 0, 54) == 1 );
assert( gamma_free_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 3, 0, 49) == 0 );
assert( gamma_move(board, 1, 0, 23) == 1 );
assert( gamma_golden_move(board, 1, 43, 0) == 0 );
assert( gamma_move(board, 2, 0, 49) == 0 );
assert( gamma_move(board, 3, 52, 0) == 0 );
assert( gamma_move(board, 3, 0, 48) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 0, 53) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 27, 0) == 0 );
assert( gamma_move(board, 3, 0, 40) == 0 );
assert( gamma_move(board, 1, 20, 0) == 0 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_move(board, 2, 37, 0) == 0 );
assert( gamma_move(board, 2, 0, 38) == 0 );
assert( gamma_move(board, 3, 32, 0) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_move(board, 2, 0, 26) == 0 );
assert( gamma_move(board, 3, 32, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_move(board, 1, 36, 0) == 0 );
assert( gamma_move(board, 2, 32, 0) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 32) == 1 );
assert( gamma_move(board, 3, 0, 50) == 0 );
assert( gamma_move(board, 1, 0, 34) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 0, 46) == 0 );
assert( gamma_move(board, 2, 0, 48) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 1, 37, 0) == 0 );
assert( gamma_move(board, 1, 0, 51) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 2, 0, 33) == 0 );
assert( gamma_move(board, 3, 36, 0) == 0 );
assert( gamma_move(board, 3, 0, 18) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 44, 0) == 0 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 1, 17, 0) == 0 );
assert( gamma_move(board, 1, 0, 30) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 31, 0) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_free_fields(board, 2) == 16 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 41) == 0 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 17, 0) == 0 );
assert( gamma_move(board, 1, 27, 0) == 0 );
assert( gamma_move(board, 1, 0, 39) == 0 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_move(board, 3, 20, 0) == 0 );
assert( gamma_move(board, 3, 0, 37) == 1 );
assert( gamma_move(board, 1, 0, 52) == 1 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 17, 0) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 1, 21, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 0, 36) == 1 );
assert( gamma_move(board, 3, 0, 40) == 0 );
assert( gamma_move(board, 3, 0, 24) == 0 );
assert( gamma_free_fields(board, 3) == 12 );
assert( gamma_move(board, 1, 20, 0) == 0 );
assert( gamma_move(board, 2, 22, 0) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 3, 0, 27) == 1 );
assert( gamma_move(board, 1, 44, 0) == 0 );
assert( gamma_move(board, 1, 0, 33) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 44, 0) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 0, 16) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 2, 22, 0) == 0 );
assert( gamma_move(board, 2, 0, 53) == 0 );
assert( gamma_move(board, 3, 25, 0) == 0 );
assert( gamma_move(board, 1, 0, 44) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 54, 0) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 0, 54) == 0 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 1, 20, 0) == 0 );


gamma_delete(board);

    return 0;
}
