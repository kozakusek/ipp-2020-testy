#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 123068407
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(15, 12, 9, 13);
assert( board != NULL );


assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_move(board, 5, 7, 2) == 1 );
assert( gamma_move(board, 5, 6, 5) == 1 );
assert( gamma_golden_move(board, 5, 11, 3) == 0 );
assert( gamma_move(board, 6, 10, 1) == 1 );
assert( gamma_move(board, 7, 8, 12) == 0 );
assert( gamma_move(board, 8, 8, 0) == 1 );
assert( gamma_move(board, 8, 12, 3) == 1 );
assert( gamma_busy_fields(board, 8) == 2 );
assert( gamma_move(board, 9, 6, 4) == 1 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 1 );
assert( gamma_free_fields(board, 4) == 165 );
assert( gamma_move(board, 5, 11, 6) == 1 );
assert( gamma_move(board, 8, 5, 3) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 10, 9) == 1 );
assert( gamma_busy_fields(board, 9) == 2 );
assert( gamma_move(board, 1, 10, 6) == 1 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_move(board, 2, 5, 2) == 1 );
assert( gamma_free_fields(board, 2) == 159 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 4, 12, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 2 );
assert( gamma_move(board, 5, 0, 4) == 1 );
assert( gamma_free_fields(board, 5) == 156 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 11, 8) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 8) == 1 );
assert( gamma_move(board, 7, 4, 0) == 1 );
assert( gamma_move(board, 9, 4, 8) == 1 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 2, 12, 7) == 1 );
assert( gamma_golden_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_golden_move(board, 3, 3, 12) == 0 );
assert( gamma_busy_fields(board, 5) == 4 );


char* board361987087 = gamma_board(board);
assert( board361987087 != NULL );
assert( strcmp(board361987087, 
"...4...........\n"
"...............\n"
"..........9....\n"
"....9....716...\n"
"2....3......2..\n"
"......2...15...\n"
".23.2.5.....3..\n"
"53....9........\n"
".....8....1.8..\n"
"3....2.5.......\n"
".3........6.4..\n"
"....7...8......\n") == 0);
free(board361987087);
board361987087 = NULL;
assert( gamma_move(board, 6, 6, 2) == 1 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_move(board, 7, 4, 8) == 0 );


char* board120967784 = gamma_board(board);
assert( board120967784 != NULL );
assert( strcmp(board120967784, 
"...4...........\n"
"...............\n"
"..........9....\n"
"....9....716...\n"
"2....3......2..\n"
"......2...15...\n"
".23.2.5.....3..\n"
"53....9........\n"
".....8....1.8..\n"
"3....265.......\n"
".3........6.4..\n"
"....7...8......\n") == 0);
free(board120967784);
board120967784 = NULL;
assert( gamma_move(board, 8, 7, 13) == 0 );
assert( gamma_move(board, 9, 1, 7) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 4, 9, 9) == 1 );


char* board573041064 = gamma_board(board);
assert( board573041064 != NULL );
assert( strcmp(board573041064, 
"...4...........\n"
"...............\n"
".........49....\n"
"....9....716...\n"
"29...3......2..\n"
"..2...2...15...\n"
".23.2.5.1...3..\n"
"53..1.9........\n"
".....83...1.8..\n"
"3....265.......\n"
".3.....3..6.4..\n"
"....7...8......\n") == 0);
free(board573041064);
board573041064 = NULL;
assert( gamma_move(board, 6, 10, 0) == 1 );


char* board877210548 = gamma_board(board);
assert( board877210548 != NULL );
assert( strcmp(board877210548, 
"...4...........\n"
"...............\n"
".........49....\n"
"....9....716...\n"
"29...3......2..\n"
"..2...2...15...\n"
".23.2.5.1...3..\n"
"53..1.9........\n"
".....83...1.8..\n"
"3....265.......\n"
".3.....3..6.4..\n"
"....7...8.6....\n") == 0);
free(board877210548);
board877210548 = NULL;
assert( gamma_move(board, 7, 8, 8) == 1 );
assert( gamma_move(board, 7, 2, 10) == 1 );
assert( gamma_move(board, 8, 14, 6) == 1 );
assert( gamma_move(board, 8, 4, 7) == 1 );
assert( gamma_move(board, 9, 0, 9) == 1 );
assert( gamma_move(board, 9, 5, 5) == 1 );
assert( gamma_busy_fields(board, 9) == 6 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 10, 5) == 1 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 4, 3, 6) == 1 );
assert( gamma_move(board, 5, 3, 11) == 0 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 6, 0, 8) == 1 );
assert( gamma_free_fields(board, 7) == 130 );
assert( gamma_move(board, 8, 1, 2) == 1 );
assert( gamma_move(board, 8, 7, 8) == 1 );
assert( gamma_move(board, 9, 13, 6) == 1 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_golden_move(board, 2, 0, 4) == 1 );


char* board475616609 = gamma_board(board);
assert( board475616609 != NULL );
assert( strcmp(board475616609, 
"...4...........\n"
"..7............\n"
"9........49....\n"
"6...9..87716...\n"
"29..83......2..\n"
".524..2.2.15.98\n"
".23.295.1.2.3..\n"
"23..1.9........\n"
".....83...1.8..\n"
"38...265.......\n"
".3..1..3..6.4..\n"
"....7...8.6....\n") == 0);
free(board475616609);
board475616609 = NULL;
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_move(board, 5, 3, 9) == 1 );
assert( gamma_move(board, 6, 11, 11) == 1 );
assert( gamma_move(board, 6, 9, 3) == 1 );
assert( gamma_move(board, 7, 5, 5) == 0 );
assert( gamma_move(board, 7, 11, 4) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 10, 14) == 0 );
assert( gamma_move(board, 8, 13, 4) == 1 );
assert( gamma_move(board, 9, 10, 5) == 0 );
assert( gamma_move(board, 2, 11, 2) == 1 );
assert( gamma_move(board, 2, 10, 11) == 1 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_free_fields(board, 3) == 116 );
assert( gamma_busy_fields(board, 4) == 4 );
assert( gamma_move(board, 5, 11, 9) == 1 );
assert( gamma_move(board, 5, 2, 8) == 1 );
assert( gamma_move(board, 6, 0, 9) == 0 );


char* board801437055 = gamma_board(board);
assert( board801437055 != NULL );
assert( strcmp(board801437055, 
"...4......26...\n"
"..7............\n"
"9..5.....495...\n"
"6.5393.87716...\n"
"29..83......2..\n"
".524..2.2.15.98\n"
".23.295.1.2.3..\n"
"23..1.9....7.8.\n"
".....83..61.8..\n"
"38...265...2...\n"
".3..1..3..6.4..\n"
"....7...8.6....\n") == 0);
free(board801437055);
board801437055 = NULL;
assert( gamma_move(board, 7, 4, 1) == 0 );
assert( gamma_move(board, 7, 6, 11) == 1 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_move(board, 8, 8, 7) == 1 );
assert( gamma_move(board, 8, 8, 2) == 1 );
assert( gamma_move(board, 9, 4, 7) == 0 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_move(board, 1, 13, 8) == 1 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_move(board, 4, 5, 11) == 1 );
assert( gamma_move(board, 4, 14, 10) == 1 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_free_fields(board, 5) == 105 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 6, 4) == 0 );
assert( gamma_move(board, 7, 6, 10) == 1 );
assert( gamma_move(board, 8, 2, 14) == 0 );
assert( gamma_move(board, 9, 14, 5) == 1 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_free_fields(board, 3) == 102 );
assert( gamma_move(board, 4, 2, 1) == 1 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 6, 11, 7) == 1 );
assert( gamma_busy_fields(board, 6) == 8 );
assert( gamma_free_fields(board, 6) == 100 );
assert( gamma_move(board, 7, 7, 3) == 1 );
assert( gamma_move(board, 8, 2, 10) == 0 );
assert( gamma_move(board, 9, 2, 9) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_free_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board523239437 = gamma_board(board);
assert( board523239437 != NULL );
assert( strcmp(board523239437, 
"...4.47...26...\n"
"..7...73......4\n"
"9.95.1..3495...\n"
"6.5393.87716.1.\n"
"29..83..8..62..\n"
".524..2.2.15.98\n"
".23.295.1.2.3.9\n"
"232.1.9....7.8.\n"
".....837.61.8..\n"
"38...2658..2...\n"
".34.1..3..6.4..\n"
"....7...8.6....\n") == 0);
free(board523239437);
board523239437 = NULL;
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_golden_move(board, 6, 11, 11) == 0 );
assert( gamma_move(board, 7, 9, 13) == 0 );
assert( gamma_move(board, 8, 2, 14) == 0 );
assert( gamma_free_fields(board, 8) == 98 );
assert( gamma_move(board, 9, 0, 9) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_golden_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_golden_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 6, 9, 6) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 10) == 0 );
assert( gamma_move(board, 7, 2, 5) == 0 );
assert( gamma_move(board, 8, 11, 0) == 1 );
assert( gamma_move(board, 8, 10, 8) == 0 );
assert( gamma_move(board, 9, 9, 12) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 1, 9, 10) == 1 );
assert( gamma_move(board, 2, 11, 3) == 1 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 6, 6) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_move(board, 7, 7, 5) == 1 );
assert( gamma_move(board, 7, 3, 9) == 0 );
assert( gamma_golden_move(board, 7, 6, 11) == 0 );
assert( gamma_move(board, 9, 9, 1) == 1 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_move(board, 5, 6, 5) == 0 );
assert( gamma_free_fields(board, 5) == 88 );
assert( gamma_move(board, 6, 0, 3) == 1 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 7, 11, 2) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );


char* board442412052 = gamma_board(board);
assert( board442412052 != NULL );
assert( strcmp(board442412052, 
"...4.47...26...\n"
"..7...73.1....4\n"
"9.95.1..3495...\n"
"6.5393.87716.1.\n"
"29..832.8..62..\n"
"5524..2.2615.98\n"
"423.29571.2.3.9\n"
"232.1.9....7.8.\n"
"6....837.6128..\n"
"38...2658..2...\n"
"334.1..3.96.4..\n"
"....7...8.68...\n") == 0);
free(board442412052);
board442412052 = NULL;
assert( gamma_move(board, 8, 9, 6) == 0 );
assert( gamma_move(board, 8, 11, 7) == 0 );
assert( gamma_move(board, 9, 10, 3) == 0 );
assert( gamma_move(board, 9, 0, 0) == 1 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 11, 13) == 0 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 5, 7, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 4) == 1 );
assert( gamma_move(board, 7, 12, 5) == 0 );
assert( gamma_move(board, 8, 2, 9) == 0 );
assert( gamma_move(board, 8, 10, 8) == 0 );
assert( gamma_move(board, 9, 0, 6) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_free_fields(board, 1) == 84 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );


char* board625849202 = gamma_board(board);
assert( board625849202 != NULL );
assert( strcmp(board625849202, 
"...4.47...26...\n"
"..7...73.1....4\n"
"9.9531..3495...\n"
"6.5393.87716.1.\n"
"29..832.8..62..\n"
"5524..2.2615.98\n"
"423.29571.2.3.9\n"
"232.1.9..7.7.8.\n"
"63...837.6128..\n"
"38...2658..2...\n"
"334.1..3.96.4..\n"
"9...7..58.68...\n") == 0);
free(board625849202);
board625849202 = NULL;
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 6, 1, 9) == 1 );
assert( gamma_free_fields(board, 6) == 81 );
assert( gamma_move(board, 7, 0, 2) == 0 );
assert( gamma_move(board, 7, 1, 10) == 1 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 6, 7) == 0 );
assert( gamma_move(board, 8, 4, 10) == 1 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_busy_fields(board, 9) == 11 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_move(board, 1, 9, 2) == 1 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );


char* board477240550 = gamma_board(board);
assert( board477240550 != NULL );
assert( strcmp(board477240550, 
"...4.47...26...\n"
".77.8.73.1....4\n"
"969531..3495...\n"
"6.5393.87716.1.\n"
"29..832.8..62..\n"
"5524..2.2615.98\n"
"423.29571.2.3.9\n"
"232.1.9..7.7.8.\n"
"63...837.6128..\n"
"38...26581.2...\n"
"334.1..3.9614..\n"
"9...7..58.68...\n") == 0);
free(board477240550);
board477240550 = NULL;
assert( gamma_golden_move(board, 4, 9, 3) == 1 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_move(board, 7, 4, 4) == 0 );
assert( gamma_move(board, 8, 6, 3) == 0 );
assert( gamma_free_fields(board, 8) == 77 );
assert( gamma_move(board, 9, 13, 1) == 1 );
assert( gamma_move(board, 9, 1, 5) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_free_fields(board, 1) == 76 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 4, 1, 1) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 6, 13, 9) == 1 );
assert( gamma_move(board, 7, 4, 10) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 2) == 0 );
assert( gamma_move(board, 9, 10, 8) == 0 );
assert( gamma_move(board, 9, 5, 8) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 1, 12, 9) == 1 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 4, 8, 10) == 1 );
assert( gamma_free_fields(board, 4) == 71 );
assert( gamma_golden_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 13) == 0 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 7, 7, 11) == 1 );
assert( gamma_move(board, 7, 7, 3) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 5, 5) == 0 );
assert( gamma_move(board, 8, 13, 5) == 1 );
assert( gamma_busy_fields(board, 8) == 13 );
assert( gamma_golden_move(board, 8, 5, 0) == 0 );
assert( gamma_move(board, 9, 2, 1) == 0 );
assert( gamma_move(board, 9, 0, 1) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_golden_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_golden_move(board, 5, 5, 8) == 1 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 8, 6, 4) == 0 );
assert( gamma_move(board, 8, 2, 0) == 1 );
assert( gamma_free_fields(board, 8) == 22 );
assert( gamma_move(board, 9, 6, 4) == 0 );
assert( gamma_move(board, 9, 11, 10) == 1 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 5, 3, 11) == 0 );
assert( gamma_golden_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 6, 2, 2) == 1 );
assert( gamma_move(board, 7, 4, 10) == 0 );
assert( gamma_free_fields(board, 7) == 65 );
assert( gamma_move(board, 8, 0, 3) == 0 );
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_move(board, 9, 12, 0) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 6, 7, 7) == 1 );
assert( gamma_move(board, 7, 6, 8) == 1 );
assert( gamma_move(board, 7, 6, 1) == 1 );
assert( gamma_move(board, 8, 3, 13) == 0 );
assert( gamma_move(board, 8, 11, 2) == 0 );
assert( gamma_free_fields(board, 8) == 19 );
assert( gamma_move(board, 9, 2, 12) == 0 );
assert( gamma_move(board, 9, 8, 4) == 0 );
assert( gamma_move(board, 1, 1, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 4, 3, 5) == 1 );
assert( gamma_move(board, 5, 0, 12) == 0 );
assert( gamma_move(board, 5, 12, 10) == 1 );
assert( gamma_move(board, 7, 6, 7) == 0 );
assert( gamma_move(board, 7, 3, 2) == 1 );
assert( gamma_free_fields(board, 7) == 57 );
assert( gamma_move(board, 8, 11, 5) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 2, 4) == 0 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_move(board, 6, 3, 8) == 0 );
assert( gamma_move(board, 6, 4, 5) == 0 );
assert( gamma_move(board, 7, 11, 9) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );


char* board300770091 = gamma_board(board);
assert( board300770091 != NULL );
assert( strcmp(board300770091, 
"...4.477..26...\n"
".77.8.7341.95.4\n"
"969531.3349516.\n"
"615395787716.1.\n"
"29..83268..62..\n"
"5524..2.2615.98\n"
"42342957132.389\n"
"232.1.9..7.7.8.\n"
"6333.837.4128..\n"
"3867.26581.2...\n"
"334.1.73.96149.\n"
"9.8.7..58.68...\n") == 0);
free(board300770091);
board300770091 = NULL;
assert( gamma_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 9, 1, 8) == 0 );
assert( gamma_move(board, 9, 11, 10) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_golden_move(board, 2, 8, 12) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 11 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 6, 14, 3) == 1 );
assert( gamma_move(board, 7, 0, 9) == 0 );
assert( gamma_move(board, 7, 2, 9) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 9, 12, 11) == 0 );
assert( gamma_move(board, 9, 10, 2) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_free_fields(board, 3) == 56 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_free_fields(board, 5) == 55 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 7, 14, 10) == 0 );
assert( gamma_move(board, 7, 6, 10) == 0 );
assert( gamma_move(board, 8, 9, 9) == 0 );
assert( gamma_move(board, 8, 13, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 14 );
assert( gamma_move(board, 9, 3, 11) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 6, 0, 10) == 1 );
assert( gamma_move(board, 7, 3, 5) == 0 );
assert( gamma_move(board, 7, 1, 7) == 0 );
assert( gamma_move(board, 8, 1, 5) == 0 );
assert( gamma_move(board, 9, 4, 8) == 0 );
assert( gamma_golden_move(board, 9, 9, 5) == 0 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_move(board, 6, 6, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 3, 3) == 0 );


char* board785796556 = gamma_board(board);
assert( board785796556 != NULL );
assert( strcmp(board785796556, 
"...4.4774.26...\n"
"677.8.7341.95.4\n"
"969531.3349516.\n"
"615395787716.1.\n"
"29..83268..62..\n"
"5524.52.2615.98\n"
"42342957132.389\n"
"2322119..7.7.8.\n"
"6333.837.4128.6\n"
"3867.26581.2...\n"
"334.1.73.96149.\n"
"9.8.7..58.68...\n") == 0);
free(board785796556);
board785796556 = NULL;
assert( gamma_move(board, 9, 1, 8) == 0 );
assert( gamma_move(board, 9, 1, 8) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 11, 11) == 0 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 5, 9, 14) == 0 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 7, 11, 9) == 0 );
assert( gamma_move(board, 8, 12, 0) == 1 );
assert( gamma_move(board, 9, 7, 10) == 0 );
assert( gamma_move(board, 9, 3, 0) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_free_fields(board, 4) == 49 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_move(board, 7, 12, 8) == 1 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_move(board, 8, 6, 4) == 0 );
assert( gamma_move(board, 9, 4, 14) == 0 );
assert( gamma_free_fields(board, 9) == 12 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 4, 5, 6) == 0 );
assert( gamma_move(board, 4, 5, 0) == 1 );
assert( gamma_move(board, 5, 3, 4) == 0 );


char* board229280509 = gamma_board(board);
assert( board229280509 != NULL );
assert( strcmp(board229280509, 
"...4.4774.26...\n"
"677.837341.95.4\n"
"969531.3349516.\n"
"61539578771671.\n"
"29..83268..62..\n"
"5524.52.2615.98\n"
"42342957132.389\n"
"2322119..7.7.8.\n"
"6333.837.4128.6\n"
"3867.26581.2...\n"
"334.1.73.96149.\n"
"9.8.74.58.688..\n") == 0);
free(board229280509);
board229280509 = NULL;
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 4, 10) == 0 );


char* board637157037 = gamma_board(board);
assert( board637157037 != NULL );
assert( strcmp(board637157037, 
"...4.4774.26...\n"
"677.837341.95.4\n"
"969531.3349516.\n"
"61539578771671.\n"
"29..83268..62..\n"
"5524.52.2615.98\n"
"42342957132.389\n"
"2322119..7.7.8.\n"
"6333.837.4128.6\n"
"3867.26581.2...\n"
"334.1.73.96149.\n"
"9.8.74.58.688..\n") == 0);
free(board637157037);
board637157037 = NULL;
assert( gamma_move(board, 9, 9, 14) == 0 );
assert( gamma_move(board, 9, 1, 6) == 0 );
assert( gamma_golden_move(board, 9, 10, 0) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );


char* board425360376 = gamma_board(board);
assert( board425360376 != NULL );
assert( strcmp(board425360376, 
"...4.4774.26...\n"
"677.837341.95.4\n"
"969531.3349516.\n"
"61539578771671.\n"
"29..83268..62..\n"
"5524.52.2615.98\n"
"42342957132.389\n"
"2322119..7.7.8.\n"
"6333.837.4128.6\n"
"3867.26581.2...\n"
"334.1.73.96149.\n"
"9.8.74.58.688..\n") == 0);
free(board425360376);
board425360376 = NULL;
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 6, 11, 0) == 0 );
assert( gamma_move(board, 7, 13, 3) == 1 );
assert( gamma_move(board, 8, 14, 6) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 11, 2) == 0 );
assert( gamma_move(board, 9, 10, 11) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_free_fields(board, 4) == 46 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 1, 8) == 0 );
assert( gamma_move(board, 6, 5, 4) == 0 );
assert( gamma_move(board, 7, 3, 8) == 0 );
assert( gamma_move(board, 8, 3, 4) == 0 );
assert( gamma_move(board, 9, 11, 12) == 0 );


char* board609014797 = gamma_board(board);
assert( board609014797 != NULL );
assert( strcmp(board609014797, 
"...4.4774.26...\n"
"677.837341.95.4\n"
"969531.3349516.\n"
"61539578771671.\n"
"29..83268..62..\n"
"5524.52.2615.98\n"
"42342957132.389\n"
"2322119..7.7.8.\n"
"6333.837.412876\n"
"3867.26581.2...\n"
"334.1.73.96149.\n"
"9.8.74.58.688..\n") == 0);
free(board609014797);
board609014797 = NULL;
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_free_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 6, 13, 3) == 0 );
assert( gamma_golden_move(board, 6, 8, 9) == 0 );
assert( gamma_move(board, 7, 11, 9) == 0 );
assert( gamma_move(board, 7, 2, 6) == 0 );
assert( gamma_move(board, 8, 6, 8) == 0 );
assert( gamma_move(board, 9, 2, 4) == 0 );
assert( gamma_move(board, 9, 13, 11) == 0 );
assert( gamma_move(board, 1, 10, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 5, 6, 11) == 0 );
assert( gamma_move(board, 6, 2, 13) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 8, 3, 4) == 0 );
assert( gamma_move(board, 9, 0, 9) == 0 );
assert( gamma_move(board, 9, 6, 0) == 0 );
assert( gamma_free_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 5, 10, 7) == 1 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 6, 4, 10) == 0 );
assert( gamma_move(board, 7, 7, 3) == 0 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 8, 0, 9) == 0 );
assert( gamma_move(board, 9, 10, 2) == 0 );
assert( gamma_move(board, 9, 3, 8) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 5, 4, 14) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_free_fields(board, 6) == 9 );
assert( gamma_move(board, 7, 11, 13) == 0 );
assert( gamma_free_fields(board, 7) == 18 );
assert( gamma_move(board, 8, 6, 3) == 0 );
assert( gamma_move(board, 8, 11, 3) == 0 );
assert( gamma_move(board, 9, 0, 14) == 0 );
assert( gamma_move(board, 9, 8, 9) == 0 );
assert( gamma_busy_fields(board, 9) == 13 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );


char* board867747038 = gamma_board(board);
assert( board867747038 != NULL );
assert( strcmp(board867747038, 
"...4.4774.26...\n"
"677.837341195.4\n"
"969531.3349516.\n"
"61539578771671.\n"
"29..83268.562..\n"
"5524.52.2615.98\n"
"42342957132.389\n"
"2322119..7.7.8.\n"
"6333.837.412876\n"
"3867.2658142...\n"
"334.1.73.96149.\n"
"9.8.74.58.688..\n") == 0);
free(board867747038);
board867747038 = NULL;
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 13, 8) == 0 );
assert( gamma_move(board, 7, 7, 14) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 3, 3) == 0 );
assert( gamma_move(board, 9, 9, 0) == 1 );
assert( gamma_move(board, 9, 9, 0) == 0 );
assert( gamma_move(board, 1, 11, 14) == 0 );
assert( gamma_free_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_move(board, 5, 11, 12) == 0 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 8, 0, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 15 );
assert( gamma_move(board, 9, 11, 13) == 0 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 16 );
assert( gamma_free_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 7, 10, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 9) == 0 );
assert( gamma_move(board, 8, 13, 8) == 0 );


char* board368656116 = gamma_board(board);
assert( board368656116 != NULL );
assert( strcmp(board368656116, 
"...4.4774.26...\n"
"677.837341195.4\n"
"969531.3349516.\n"
"61539578771671.\n"
"29..83268.562..\n"
"5524.52.2615.98\n"
"42342957132.389\n"
"2322119..7.7.8.\n"
"6333.837.412876\n"
"3867.2658142...\n"
"334.1.73.96149.\n"
"9.8.74.589688..\n") == 0);
free(board368656116);
board368656116 = NULL;


gamma_delete(board);

    return 0;
}
