#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 118793092
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(11, 13, 5, 16);
assert( board != NULL );


assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_move(board, 4, 7, 7) == 1 );
assert( gamma_busy_fields(board, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 1 );
assert( gamma_free_fields(board, 2) == 138 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_move(board, 5, 6, 1) == 1 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 2 );


char* board102507869 = gamma_board(board);
assert( board102507869 != NULL );
assert( strcmp(board102507869, 
"...........\n"
"...4.......\n"
"...........\n"
".......2...\n"
"...........\n"
"...1...4...\n"
".....5.....\n"
"...3.......\n"
"...3.......\n"
"1..........\n"
"...........\n"
"......5....\n"
"...........\n") == 0);
free(board102507869);
board102507869 = NULL;
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 4, 10, 4) == 1 );
assert( gamma_move(board, 5, 10, 8) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_move(board, 2, 4, 11) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 2, 12) == 1 );
assert( gamma_move(board, 5, 5, 12) == 0 );
assert( gamma_move(board, 5, 2, 1) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );


char* board365431019 = gamma_board(board);
assert( board365431019 != NULL );
assert( strcmp(board365431019, 
"..3..2.....\n"
"...42......\n"
"...........\n"
".......2...\n"
"..........5\n"
"...1.3.4...\n"
".....5.....\n"
"...3.......\n"
"...3......4\n"
"1..........\n"
"...........\n"
"..5...5.1..\n"
"...........\n") == 0);
free(board365431019);
board365431019 = NULL;
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_free_fields(board, 1) == 125 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_move(board, 5, 10, 9) == 1 );
assert( gamma_move(board, 5, 0, 7) == 1 );
assert( gamma_move(board, 1, 8, 0) == 1 );


char* board478907352 = gamma_board(board);
assert( board478907352 != NULL );
assert( strcmp(board478907352, 
"..3..2.....\n"
"...42......\n"
"...........\n"
"..1.2..2..5\n"
"4.........5\n"
"5..1.324...\n"
".....5.....\n"
"...3.......\n"
"...3....3.4\n"
"1..........\n"
"...........\n"
"..5...5.1..\n"
"........1..\n") == 0);
free(board478907352);
board478907352 = NULL;
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_free_fields(board, 3) == 116 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_free_fields(board, 4) == 114 );


char* board819707541 = gamma_board(board);
assert( board819707541 != NULL );
assert( strcmp(board819707541, 
"..3..2.....\n"
"...42......\n"
"...........\n"
"..1.2..2.45\n"
"4.2.......5\n"
"5..1.324...\n"
".....5.....\n"
"...3.......\n"
"...3....3.4\n"
"1....4.....\n"
"..2........\n"
"..5...5.1..\n"
"........1..\n") == 0);
free(board819707541);
board819707541 = NULL;
assert( gamma_move(board, 5, 3, 6) == 1 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 5, 2, 10) == 1 );
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 3, 0, 6) == 1 );
assert( gamma_move(board, 4, 4, 0) == 1 );
assert( gamma_move(board, 4, 6, 6) == 1 );
assert( gamma_move(board, 5, 4, 2) == 1 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_free_fields(board, 1) == 103 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board162989957 = gamma_board(board);
assert( board162989957 != NULL );
assert( strcmp(board162989957, 
"..3..2.....\n"
"...42......\n"
"..5....3...\n"
"..1.21.2.45\n"
"4.2.......5\n"
"5..1.324...\n"
"3..5.54....\n"
"..13.......\n"
"...3....3.4\n"
"1....4...1.\n"
"..2.5......\n"
"..5...5.1..\n"
"....42..1..\n") == 0);
free(board162989957);
board162989957 = NULL;
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 2, 10, 11) == 1 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_move(board, 4, 7, 3) == 1 );
assert( gamma_move(board, 5, 7, 5) == 1 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_move(board, 4, 7, 11) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 4) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_free_fields(board, 2) == 95 );
assert( gamma_move(board, 3, 9, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 4, 9, 12) == 1 );


char* board249176758 = gamma_board(board);
assert( board249176758 != NULL );
assert( strcmp(board249176758, 
"..3..2..44.\n"
"...42..4..2\n"
"..5....3...\n"
"..1.21.2.45\n"
"4.2.......5\n"
"5..1.3244..\n"
"3..5.54....\n"
"..13...5...\n"
".4.3.2..334\n"
"1....4.4.1.\n"
"..2.5......\n"
"..5...5.1..\n"
"2...42..1..\n") == 0);
free(board249176758);
board249176758 = NULL;
assert( gamma_move(board, 5, 7, 0) == 1 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 10, 3) == 1 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_move(board, 5, 8, 8) == 1 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_move(board, 1, 1, 11) == 1 );
assert( gamma_free_fields(board, 1) == 85 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 2, 7, 12) == 1 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 5, 6, 8) == 1 );
assert( gamma_move(board, 1, 7, 1) == 1 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 5, 1, 5) == 1 );


char* board562327821 = gamma_board(board);
assert( board562327821 != NULL );
assert( strcmp(board562327821, 
"..3..2.244.\n"
".1.42..4..2\n"
"..5....3...\n"
"..1.21.2.45\n"
"4.2...5.5.5\n"
"5..1.3244..\n"
"3..5.54....\n"
".513...5...\n"
"24.3.2..334\n"
"1..5.4.4.13\n"
"..225......\n"
"1.5...511.3\n"
"23..42.51..\n") == 0);
free(board562327821);
board562327821 = NULL;
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 2, 4, 6) == 1 );


char* board964908861 = gamma_board(board);
assert( board964908861 != NULL );
assert( strcmp(board964908861, 
"..3..2.244.\n"
".1.42..4..2\n"
"..5....3...\n"
"..1.21.2.45\n"
"4.22..5.5.5\n"
"5..1.3244..\n"
"3..5254....\n"
".513...5...\n"
"24.3.2..334\n"
"1..5.4.4.13\n"
"..225......\n"
"1.5...511.3\n"
"23..42.51..\n") == 0);
free(board964908861);
board964908861 = NULL;
assert( gamma_move(board, 4, 8, 3) == 1 );
assert( gamma_move(board, 4, 4, 12) == 1 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_free_fields(board, 1) == 73 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_golden_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_free_fields(board, 3) == 71 );
assert( gamma_move(board, 4, 12, 10) == 0 );
assert( gamma_move(board, 4, 10, 6) == 1 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 16 );


char* board160481054 = gamma_board(board);
assert( board160481054 != NULL );
assert( strcmp(board160481054, 
"..3.42.244.\n"
".1.42..4..2\n"
"..5....3...\n"
"..1.21.2.45\n"
"4522..5.5.5\n"
"5..1.3244..\n"
"3..5254...4\n"
".513.1.5..3\n"
"24.3.2..334\n"
"1..5.4.2413\n"
"..225......\n"
"1.5...511.3\n"
"23..42.51.2\n") == 0);
free(board160481054);
board160481054 = NULL;
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_free_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_free_fields(board, 5) == 69 );
assert( gamma_golden_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_free_fields(board, 3) == 68 );
assert( gamma_move(board, 4, 9, 1) == 1 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );


char* board593909501 = gamma_board(board);
assert( board593909501 != NULL );
assert( strcmp(board593909501, 
"..3.42.244.\n"
".1.42..4..2\n"
"..5....3...\n"
"..1.21.2.45\n"
"4522..5.5.5\n"
"5..113244..\n"
"3..5254...4\n"
".513.1.5..3\n"
"24.3.2..334\n"
"1..5.4.2413\n"
"..225......\n"
"1.5...51143\n"
"23..42.51.2\n") == 0);
free(board593909501);
board593909501 = NULL;
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 6, 9) == 1 );


char* board900133575 = gamma_board(board);
assert( board900133575 != NULL );
assert( strcmp(board900133575, 
"..3.42.244.\n"
".1.42..4..2\n"
"..5....3...\n"
"..1.2132.45\n"
"4522..5.5.5\n"
"5..113244..\n"
"3..5254...4\n"
".513.1.5..3\n"
"24.3.2..334\n"
"1..5.4.2413\n"
"..225......\n"
"1.5...51143\n"
"23..42.51.2\n") == 0);
free(board900133575);
board900133575 = NULL;
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 5, 1, 9) == 1 );
assert( gamma_move(board, 1, 7, 10) == 0 );


char* board712594859 = gamma_board(board);
assert( board712594859 != NULL );
assert( strcmp(board712594859, 
"..3.42.244.\n"
".1.42..4..2\n"
"..5....3...\n"
"451.2132.45\n"
"4522..5.5.5\n"
"5..113244..\n"
"3..5254...4\n"
".513.1.5..3\n"
"24.3.2..334\n"
"1..5.4.2413\n"
"..225......\n"
"1.5...51143\n"
"23..42.51.2\n") == 0);
free(board712594859);
board712594859 = NULL;
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_free_fields(board, 4) == 63 );
assert( gamma_move(board, 5, 6, 4) == 1 );


char* board163046396 = gamma_board(board);
assert( board163046396 != NULL );
assert( strcmp(board163046396, 
"..3.42.244.\n"
".1.42..4..2\n"
"..5....3...\n"
"451.2132.45\n"
"4522..5.5.5\n"
"5..113244..\n"
"3..5254...4\n"
".513.1.5..3\n"
"24.3.25.334\n"
"1..5.4.2413\n"
"..225......\n"
"135...51143\n"
"23..42.51.2\n") == 0);
free(board163046396);
board163046396 = NULL;
assert( gamma_move(board, 1, 6, 2) == 1 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_golden_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 5, 1, 11) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );


char* board182531857 = gamma_board(board);
assert( board182531857 != NULL );
assert( strcmp(board182531857, 
"..3.42.244.\n"
".1.42..4..2\n"
".45....3...\n"
"451.2132.45\n"
"4522..5.5.5\n"
"5..113244..\n"
"3..5254...4\n"
".513.1.5..3\n"
"24.3.25.334\n"
"1..5.4.2413\n"
"..225.1....\n"
"135...51143\n"
"233.42.51.2\n") == 0);
free(board182531857);
board182531857 = NULL;
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_free_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 7, 2) == 1 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_free_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 2, 4, 10) == 1 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board958380591 = gamma_board(board);
assert( board958380591 != NULL );
assert( strcmp(board958380591, 
".13.42.244.\n"
".1.42..4..2\n"
".45.2..3...\n"
"451.2132245\n"
"4522..5.5.5\n"
"5..113244..\n"
"3..5254...4\n"
".513.1.5..3\n"
"24.3.25.334\n"
"1..5.4.2413\n"
"..225.13...\n"
"1353..51143\n"
"233.42.51.2\n") == 0);
free(board958380591);
board958380591 = NULL;
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_golden_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_free_fields(board, 5) == 22 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 5, 2, 8) == 0 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 8, 8) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 6, 5) == 1 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 5, 11, 8) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 2, 9, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_free_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 4, 1) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_free_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 2, 8) == 0 );


char* board417737009 = gamma_board(board);
assert( board417737009 != NULL );
assert( strcmp(board417737009, 
"113.422244.\n"
".1242..4..2\n"
".4512.33.2.\n"
"45132132245\n"
"4522.35.515\n"
"5..113244.3\n"
"3..525431.4\n"
"3513.135..3\n"
"24.3125.334\n"
"111514.2413\n"
"..225.13...\n"
"13535.51143\n"
"233.42.51.2\n") == 0);
free(board417737009);
board417737009 = NULL;
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 5, 5, 12) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_free_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_golden_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_free_fields(board, 5) == 11 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 5, 2, 8) == 0 );
assert( gamma_free_fields(board, 5) == 11 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 3, 12) == 1 );
assert( gamma_free_fields(board, 1) == 17 );


char* board582874756 = gamma_board(board);
assert( board582874756 != NULL );
assert( strcmp(board582874756, 
"1131422244.\n"
".1242..4..2\n"
".4512.33.2.\n"
"45132132245\n"
"4522.35.515\n"
"5..113244.3\n"
"3..525431.4\n"
"3513.135..3\n"
"24.3125.334\n"
"111514.2413\n"
"..225.13...\n"
"13535.51143\n"
"233442.51.2\n") == 0);
free(board582874756);
board582874756 = NULL;
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );


char* board389394600 = gamma_board(board);
assert( board389394600 != NULL );
assert( strcmp(board389394600, 
"1131422244.\n"
".1242..4..2\n"
".4512.33.2.\n"
"45132132245\n"
"4522.35.515\n"
"5..113244.3\n"
"3..525431.4\n"
"3513.135..3\n"
"24.3125.334\n"
"111514.2413\n"
"..225.13...\n"
"13535.51143\n"
"233442.51.2\n") == 0);
free(board389394600);
board389394600 = NULL;
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 5, 10) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_free_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 6, 11) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_free_fields(board, 5) == 11 );
assert( gamma_golden_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );


char* board350705689 = gamma_board(board);
assert( board350705689 != NULL );
assert( strcmp(board350705689, 
"1131422244.\n"
".1242.344.2\n"
".4512133.2.\n"
"45132132245\n"
"4522.35.515\n"
"5..113244.3\n"
"3..525431.4\n"
"3513.135..3\n"
"24.3125.334\n"
"111514.2413\n"
"..225.13...\n"
"13535.51143\n"
"233442.51.2\n") == 0);
free(board350705689);
board350705689 = NULL;
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_free_fields(board, 4) == 29 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_free_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_free_fields(board, 3) == 12 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_golden_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_free_fields(board, 3) == 12 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 19 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_free_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_golden_move(board, 5, 8, 2) == 0 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_free_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );


char* board650544912 = gamma_board(board);
assert( board650544912 != NULL );
assert( strcmp(board650544912, 
"1131422244.\n"
".12422344.2\n"
"44512133.24\n"
"45132132245\n"
"4522.35.515\n"
"5..113244.3\n"
"3..525431.4\n"
"3513.135.33\n"
"24.3125.334\n"
"111514.2413\n"
"..225.13.32\n"
"13535.51143\n"
"233442251.2\n") == 0);
free(board650544912);
board650544912 = NULL;
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );


gamma_delete(board);

    return 0;
}
