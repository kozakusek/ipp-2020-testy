#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 133055159
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(2, 5, 6, 4);
assert( board != NULL );


assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 5, 1, 2) == 1 );
assert( gamma_move(board, 5, 1, 3) == 1 );
assert( gamma_move(board, 6, 1, 4) == 1 );


char* board597986852 = gamma_board(board);
assert( board597986852 != NULL );
assert( strcmp(board597986852, 
".6\n"
".5\n"
".5\n"
"..\n"
"12\n") == 0);
free(board597986852);
board597986852 = NULL;
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_golden_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );


char* board722445458 = gamma_board(board);
assert( board722445458 != NULL );
assert( strcmp(board722445458, 
".6\n"
".5\n"
".5\n"
"..\n"
"12\n") == 0);
free(board722445458);
board722445458 = NULL;
assert( gamma_move(board, 6, 0, 1) == 1 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_free_fields(board, 6) == 4 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );


char* board712622407 = gamma_board(board);
assert( board712622407 != NULL );
assert( strcmp(board712622407, 
".6\n"
".5\n"
".5\n"
"62\n"
"12\n") == 0);
free(board712622407);
board712622407 = NULL;
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 5, 1, 1) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 2, 2, 0) == 0 );


gamma_delete(board);

    return 0;
}
