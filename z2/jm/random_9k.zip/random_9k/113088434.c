#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 113088434
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(10, 17, 8, 14);
assert( board != NULL );


assert( gamma_free_fields(board, 1) == 170 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 4, 7, 7) == 1 );
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_free_fields(board, 4) == 166 );
assert( gamma_free_fields(board, 5) == 166 );
assert( gamma_golden_move(board, 6, 7, 7) == 1 );
assert( gamma_move(board, 7, 0, 1) == 1 );
assert( gamma_free_fields(board, 7) == 165 );
assert( gamma_move(board, 8, 5, 0) == 1 );
assert( gamma_move(board, 1, 2, 15) == 1 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_busy_fields(board, 3) == 3 );
assert( gamma_golden_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 5, 4, 3) == 1 );
assert( gamma_move(board, 6, 12, 0) == 0 );
assert( gamma_move(board, 6, 7, 11) == 1 );
assert( gamma_move(board, 7, 0, 9) == 1 );
assert( gamma_move(board, 7, 4, 15) == 1 );
assert( gamma_move(board, 8, 8, 0) == 1 );
assert( gamma_move(board, 8, 5, 12) == 1 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 1, 4, 0) == 1 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 4, 9, 4) == 1 );


char* board756449392 = gamma_board(board);
assert( board756449392 != NULL );
assert( strcmp(board756449392, 
"..........\n"
"..1.7.....\n"
"..........\n"
"..........\n"
".....8....\n"
".......6..\n"
"4......3..\n"
"7...2..3..\n"
"..........\n"
"....5..6..\n"
"..3.......\n"
"..........\n"
".4.......4\n"
".32.5.....\n"
"1.........\n"
"7.........\n"
"....18..8.\n") == 0);
free(board756449392);
board756449392 = NULL;
assert( gamma_move(board, 5, 4, 14) == 1 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_free_fields(board, 5) == 146 );
assert( gamma_move(board, 6, 10, 6) == 0 );
assert( gamma_move(board, 6, 3, 11) == 1 );
assert( gamma_move(board, 7, 2, 5) == 1 );
assert( gamma_move(board, 7, 7, 6) == 1 );
assert( gamma_free_fields(board, 7) == 143 );
assert( gamma_move(board, 8, 3, 6) == 1 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_move(board, 4, 9, 11) == 1 );
assert( gamma_move(board, 5, 3, 8) == 1 );
assert( gamma_move(board, 5, 2, 10) == 1 );
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_move(board, 6, 0, 7) == 1 );
assert( gamma_move(board, 7, 9, 6) == 1 );
assert( gamma_move(board, 7, 9, 13) == 1 );
assert( gamma_move(board, 8, 9, 11) == 0 );
assert( gamma_move(board, 8, 9, 9) == 1 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );


char* board865679082 = gamma_board(board);
assert( board865679082 != NULL );
assert( strcmp(board865679082, 
"..........\n"
"..1.7.....\n"
"....5.....\n"
".........7\n"
".....8....\n"
"...6...6.4\n"
"4.5....3..\n"
"7...2..328\n"
"...5......\n"
"6...5..6..\n"
"5.38...7.7\n"
"..7.......\n"
"34.......4\n"
".32.5.....\n"
"1.........\n"
"7.........\n"
"....18..8.\n") == 0);
free(board865679082);
board865679082 = NULL;
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 7) == 1 );


char* board333706800 = gamma_board(board);
assert( board333706800 != NULL );
assert( strcmp(board333706800, 
"..........\n"
"..1.7.....\n"
"....5.....\n"
".........7\n"
".....8....\n"
"...6...6.4\n"
"4.5....3..\n"
"7...2..328\n"
"...5......\n"
"6.6.5..6..\n"
"5.38...7.7\n"
"..7.......\n"
"34.......4\n"
".32.5.....\n"
"1.........\n"
"7.........\n"
"....18..8.\n") == 0);
free(board333706800);
board333706800 = NULL;
assert( gamma_move(board, 8, 11, 0) == 0 );


char* board252350290 = gamma_board(board);
assert( board252350290 != NULL );
assert( strcmp(board252350290, 
"..........\n"
"..1.7.....\n"
"....5.....\n"
".........7\n"
".....8....\n"
"...6...6.4\n"
"4.5....3..\n"
"7...2..328\n"
"...5......\n"
"6.6.5..6..\n"
"5.38...7.7\n"
"..7.......\n"
"34.......4\n"
".32.5.....\n"
"1.........\n"
"7.........\n"
"....18..8.\n") == 0);
free(board252350290);
board252350290 = NULL;
assert( gamma_move(board, 1, 5, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_free_fields(board, 3) == 131 );
assert( gamma_move(board, 4, 4, 5) == 1 );


char* board565662466 = gamma_board(board);
assert( board565662466 != NULL );
assert( strcmp(board565662466, 
"..........\n"
"..1.7.....\n"
"....5.....\n"
".........7\n"
".....8....\n"
"...6...6.4\n"
"4.5....3..\n"
"7...2..328\n"
"...5.1....\n"
"6.6.5..6..\n"
"5.38...7.7\n"
"..7.4.....\n"
"34.......4\n"
".32.5.....\n"
"1.........\n"
"7.........\n"
"....18..8.\n") == 0);
free(board565662466);
board565662466 = NULL;
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 5, 5, 3) == 1 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_move(board, 6, 2, 9) == 1 );
assert( gamma_move(board, 7, 7, 6) == 0 );
assert( gamma_move(board, 8, 10, 3) == 0 );
assert( gamma_move(board, 8, 6, 8) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 9, 5) == 1 );


char* board110094033 = gamma_board(board);
assert( board110094033 != NULL );
assert( strcmp(board110094033, 
"..........\n"
"..1.7.....\n"
"....5.....\n"
".........7\n"
".....8....\n"
"...6...6.4\n"
"4.5....3..\n"
"7.6.2..328\n"
"...5.18...\n"
"6.6.5..6..\n"
"5.38...7.7\n"
"..7.4....1\n"
"34.......4\n"
".32.55....\n"
"1.........\n"
"7.........\n"
"....18..8.\n") == 0);
free(board110094033);
board110094033 = NULL;
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 3, 5, 10) == 1 );


char* board937408738 = gamma_board(board);
assert( board937408738 != NULL );
assert( strcmp(board937408738, 
"..........\n"
"..1.7.....\n"
"....5.....\n"
".........7\n"
".....8....\n"
"...6...6.4\n"
"4.5..3.3..\n"
"7.6.2..328\n"
"...5.18...\n"
"6.6.5..6..\n"
"5.38...7.7\n"
"..7.4....1\n"
"34.......4\n"
".32.55....\n"
"1.........\n"
"7.........\n"
"....18..8.\n") == 0);
free(board937408738);
board937408738 = NULL;
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 5, 0, 3) == 1 );
assert( gamma_move(board, 5, 0, 15) == 1 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_move(board, 6, 8, 2) == 1 );
assert( gamma_move(board, 6, 8, 16) == 1 );
assert( gamma_move(board, 7, 10, 3) == 0 );
assert( gamma_free_fields(board, 7) == 121 );
assert( gamma_move(board, 8, 3, 2) == 1 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board765499792 = gamma_board(board);
assert( board765499792 != NULL );
assert( strcmp(board765499792, 
"........6.\n"
"5.1.7.....\n"
"....5.....\n"
".........7\n"
".....8....\n"
"1..6...6.4\n"
"4.5..3.3..\n"
"7.6.2..328\n"
"...5.18...\n"
"6.6.5..6..\n"
"5.38...7.7\n"
"..7.4....1\n"
"34.......4\n"
"532.55....\n"
"1..8....6.\n"
"7.........\n"
"....18..8.\n") == 0);
free(board765499792);
board765499792 = NULL;
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 2, 15) == 0 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_move(board, 4, 4, 12) == 1 );


char* board260770244 = gamma_board(board);
assert( board260770244 != NULL );
assert( strcmp(board260770244, 
"........6.\n"
"5.1.7.....\n"
"....5.....\n"
".........7\n"
"....48....\n"
"1..6...6.4\n"
"4.5..3.3..\n"
"7.6.2..328\n"
"...5.18...\n"
"6.6.5..6..\n"
"5.38...7.7\n"
"..7.4....1\n"
"34.......4\n"
"532.55....\n"
"1..8....6.\n"
"7.........\n"
"....18..8.\n") == 0);
free(board260770244);
board260770244 = NULL;
assert( gamma_move(board, 6, 9, 1) == 1 );
assert( gamma_move(board, 6, 7, 10) == 0 );
assert( gamma_move(board, 7, 5, 1) == 1 );
assert( gamma_move(board, 8, 12, 0) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 5, 4, 1) == 1 );
assert( gamma_free_fields(board, 6) == 115 );
assert( gamma_move(board, 7, 2, 8) == 1 );
assert( gamma_move(board, 8, 4, 6) == 1 );
assert( gamma_move(board, 8, 3, 15) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 1, 6) == 1 );
assert( gamma_move(board, 2, 8, 16) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_free_fields(board, 4) == 111 );
assert( gamma_move(board, 5, 0, 5) == 1 );
assert( gamma_move(board, 6, 4, 2) == 1 );
assert( gamma_move(board, 6, 1, 5) == 1 );
assert( gamma_free_fields(board, 6) == 108 );
assert( gamma_move(board, 7, 1, 0) == 1 );
assert( gamma_move(board, 7, 9, 8) == 1 );
assert( gamma_move(board, 8, 13, 2) == 0 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_free_fields(board, 3) == 105 );
assert( gamma_move(board, 4, 6, 7) == 1 );
assert( gamma_move(board, 4, 3, 16) == 1 );


char* board684494469 = gamma_board(board);
assert( board684494469 != NULL );
assert( strcmp(board684494469, 
"...4....6.\n"
"5.187.....\n"
"....5.....\n"
".........7\n"
"....48....\n"
"1..6...6.4\n"
"4.5..3.3..\n"
"7.612..328\n"
"..75.18..7\n"
"6.6.5.46..\n"
"51388..7.7\n"
"567.4....1\n"
"34.......4\n"
"532.55....\n"
"1..86...6.\n"
"7...57...6\n"
".7..18..8.\n") == 0);
free(board684494469);
board684494469 = NULL;
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 6, 15, 1) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 14, 5) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 1, 6, 15) == 1 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );


char* board140708721 = gamma_board(board);
assert( board140708721 != NULL );
assert( strcmp(board140708721, 
"...4....6.\n"
"5.187.1...\n"
"....5.....\n"
".........7\n"
"....48....\n"
"1..6...6.4\n"
"4.5..3.3..\n"
"7.612..328\n"
"..75.18..7\n"
"6.6.5.46..\n"
"51388..7.7\n"
"567.4....1\n"
"34.......4\n"
"532.55....\n"
"1..86...6.\n"
"7...57...6\n"
".7..18..8.\n") == 0);
free(board140708721);
board140708721 = NULL;
assert( gamma_move(board, 5, 14, 5) == 0 );
assert( gamma_move(board, 5, 1, 16) == 1 );
assert( gamma_move(board, 6, 4, 2) == 0 );
assert( gamma_move(board, 7, 10, 4) == 0 );
assert( gamma_move(board, 8, 4, 6) == 0 );
assert( gamma_move(board, 8, 3, 4) == 1 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_free_fields(board, 3) == 98 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 4, 2, 12) == 1 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_golden_move(board, 5, 2, 0) == 0 );
assert( gamma_golden_move(board, 6, 10, 0) == 0 );
assert( gamma_move(board, 7, 5, 13) == 1 );
assert( gamma_free_fields(board, 7) == 96 );
assert( gamma_move(board, 8, 7, 13) == 1 );
assert( gamma_free_fields(board, 8) == 95 );
assert( gamma_move(board, 1, 9, 14) == 1 );


char* board886297123 = gamma_board(board);
assert( board886297123 != NULL );
assert( strcmp(board886297123, 
".5.4....6.\n"
"5.187.1...\n"
"....5....1\n"
"..1..7.8.7\n"
"..4.48....\n"
"1..6...6.4\n"
"4.5..3.3..\n"
"7.612..328\n"
"..75.18..7\n"
"6.6.5.46..\n"
"51388..7.7\n"
"567.4....1\n"
"34.8.....4\n"
"532.55....\n"
"1..86...6.\n"
"7.3.57...6\n"
".7..18..8.\n") == 0);
free(board886297123);
board886297123 = NULL;
assert( gamma_free_fields(board, 2) == 94 );
assert( gamma_move(board, 3, 6, 0) == 1 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 5, 7, 14) == 1 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 7, 0, 16) == 1 );
assert( gamma_move(board, 7, 0, 15) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 4, 10) == 1 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_free_fields(board, 1) == 89 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 16, 9) == 0 );
assert( gamma_move(board, 4, 3, 15) == 0 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 1, 2) == 1 );
assert( gamma_move(board, 6, 4, 6) == 0 );
assert( gamma_move(board, 6, 2, 16) == 1 );
assert( gamma_move(board, 7, 4, 8) == 1 );
assert( gamma_move(board, 7, 7, 4) == 0 );
assert( gamma_move(board, 8, 4, 8) == 0 );
assert( gamma_move(board, 1, 16, 6) == 0 );
assert( gamma_move(board, 1, 6, 15) == 0 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 4, 7, 3) == 1 );


char* board347576669 = gamma_board(board);
assert( board347576669 != NULL );
assert( strcmp(board347576669, 
"7564....6.\n"
"5.187.1...\n"
"....5..5.1\n"
"..1..7.8.7\n"
"..4.48....\n"
"1..6...6.4\n"
"4.5.83.3..\n"
"7.612..328\n"
"..75718..7\n"
"6.6.5.463.\n"
"51388..7.7\n"
"567.4....1\n"
"34.8.....4\n"
"532.55.4..\n"
"15.86...6.\n"
"7.3.57..26\n"
".7..183.8.\n") == 0);
free(board347576669);
board347576669 = NULL;
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 6, 6, 10) == 1 );
assert( gamma_free_fields(board, 6) == 83 );
assert( gamma_move(board, 7, 14, 2) == 0 );
assert( gamma_move(board, 8, 0, 9) == 0 );
assert( gamma_move(board, 8, 8, 9) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 2, 1, 11) == 1 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_free_fields(board, 3) == 79 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 16, 5) == 0 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_free_fields(board, 4) == 79 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 6, 1, 10) == 1 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 16, 7) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 0, 16) == 0 );
assert( gamma_move(board, 4, 8, 13) == 1 );
assert( gamma_move(board, 4, 3, 8) == 0 );


char* board876313971 = gamma_board(board);
assert( board876313971 != NULL );
assert( strcmp(board876313971, 
"7564....6.\n"
"5.187.1...\n"
"....5..5.1\n"
"..1..7.847\n"
"1.4.48....\n"
"12.6...6.4\n"
"465.8363..\n"
"7.612..328\n"
"3.75718..7\n"
"6.6.5.463.\n"
"51388..7.7\n"
"567.4.1..1\n"
"34.8.....4\n"
"532.55.4..\n"
"15.86...6.\n"
"7.3.57..26\n"
".7..183.8.\n") == 0);
free(board876313971);
board876313971 = NULL;
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 7, 14, 2) == 0 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_free_fields(board, 2) == 75 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 4, 8, 4) == 1 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_golden_move(board, 5, 8, 4) == 1 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 6, 9, 16) == 1 );
assert( gamma_move(board, 7, 13, 4) == 0 );
assert( gamma_move(board, 7, 6, 15) == 0 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_move(board, 8, 0, 8) == 0 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 7, 15, 9) == 0 );
assert( gamma_move(board, 7, 8, 14) == 0 );
assert( gamma_move(board, 8, 15, 1) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );


char* board269036884 = gamma_board(board);
assert( board269036884 != NULL );
assert( strcmp(board269036884, 
"7564....66\n"
"5.187.1...\n"
"....5..5.1\n"
"1.1..7.847\n"
"1.4.48....\n"
"12.6...6.4\n"
"465.8363..\n"
"7.612..328\n"
"3.75718..7\n"
"6.6.5.463.\n"
"51388.17.7\n"
"567.431..1\n"
"3458....54\n"
"532.55.4..\n"
"15.86...6.\n"
"7.3.57..26\n"
".7..183.8.\n") == 0);
free(board269036884);
board269036884 = NULL;
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 14, 2) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 6, 11, 2) == 0 );


char* board463443673 = gamma_board(board);
assert( board463443673 != NULL );
assert( strcmp(board463443673, 
"7564....66\n"
"5.187.1...\n"
"....5..5.1\n"
"1.1..7.847\n"
"1.4.48....\n"
"12.6...6.4\n"
"465.8363..\n"
"7.612..328\n"
"3.75718..7\n"
"6.6.5.463.\n"
"51388.17.7\n"
"567.431..1\n"
"3458....54\n"
"532.55.4..\n"
"15.86...6.\n"
"7.3.57..26\n"
".7..183.8.\n") == 0);
free(board463443673);
board463443673 = NULL;
assert( gamma_move(board, 7, 0, 3) == 0 );


char* board750928392 = gamma_board(board);
assert( board750928392 != NULL );
assert( strcmp(board750928392, 
"7564....66\n"
"5.187.1...\n"
"....5..5.1\n"
"1.1..7.847\n"
"1.4.48....\n"
"12.6...6.4\n"
"465.8363..\n"
"7.612..328\n"
"3.75718..7\n"
"6.6.5.463.\n"
"51388.17.7\n"
"567.431..1\n"
"3458....54\n"
"532.55.4..\n"
"15.86...6.\n"
"7.3.57..26\n"
".7..183.8.\n") == 0);
free(board750928392);
board750928392 = NULL;
assert( gamma_move(board, 8, 1, 3) == 0 );
assert( gamma_move(board, 8, 2, 14) == 1 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_free_fields(board, 3) == 69 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 5, 5, 12) == 0 );


char* board857958288 = gamma_board(board);
assert( board857958288 != NULL );
assert( strcmp(board857958288, 
"7564....66\n"
"5.187.1...\n"
"..8.5..5.1\n"
"1.11.7.847\n"
"1.4.48....\n"
"12.6...6.4\n"
"465.8363..\n"
"7.612..328\n"
"3.75718..7\n"
"6.6.5.463.\n"
"51388.17.7\n"
"567.431..1\n"
"3458....54\n"
"532.55.4..\n"
"15.86...6.\n"
"7.3.57..26\n"
".7..183.8.\n") == 0);
free(board857958288);
board857958288 = NULL;
assert( gamma_move(board, 6, 4, 15) == 0 );
assert( gamma_move(board, 7, 9, 11) == 0 );
assert( gamma_move(board, 7, 7, 5) == 1 );
assert( gamma_free_fields(board, 7) == 19 );
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_golden_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 5, 16) == 1 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 6, 15, 9) == 0 );
assert( gamma_move(board, 7, 6, 15) == 0 );
assert( gamma_move(board, 7, 9, 11) == 0 );
assert( gamma_move(board, 8, 14, 3) == 0 );
assert( gamma_golden_move(board, 8, 9, 4) == 1 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_golden_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 4, 9, 15) == 1 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_free_fields(board, 6) == 19 );
assert( gamma_move(board, 7, 7, 9) == 0 );
assert( gamma_move(board, 7, 7, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 8, 9, 6) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_move(board, 5, 11, 8) == 0 );
assert( gamma_move(board, 6, 10, 3) == 0 );
assert( gamma_move(board, 7, 1, 12) == 0 );
assert( gamma_move(board, 8, 3, 0) == 1 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_free_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_move(board, 5, 16, 4) == 0 );
assert( gamma_free_fields(board, 5) == 21 );
assert( gamma_move(board, 6, 3, 8) == 0 );


char* board903143746 = gamma_board(board);
assert( board903143746 != NULL );
assert( strcmp(board903143746, 
"7564.3..66\n"
"5.187.1..4\n"
"..8.5..5.1\n"
"1.11.7.847\n"
"1.4.48....\n"
"12.6...6.4\n"
"465.8363..\n"
"7.612.4328\n"
"3.75718..7\n"
"6.6.5.463.\n"
"51388.17.7\n"
"567.4317.1\n"
"3458...158\n"
"532.55.4..\n"
"15.86...6.\n"
"733.57..26\n"
"17.8183.8.\n") == 0);
free(board903143746);
board903143746 = NULL;
assert( gamma_move(board, 8, 14, 8) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_free_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_move(board, 6, 7, 16) == 1 );
assert( gamma_move(board, 7, 10, 9) == 0 );
assert( gamma_move(board, 8, 9, 8) == 0 );
assert( gamma_move(board, 8, 4, 2) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 6 );
assert( gamma_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_move(board, 5, 2, 8) == 0 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_move(board, 8, 12, 9) == 0 );
assert( gamma_move(board, 8, 5, 12) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 3, 14) == 0 );


char* board107585255 = gamma_board(board);
assert( board107585255 != NULL );
assert( strcmp(board107585255, 
"7564.3.666\n"
"5.187.1..4\n"
"..825..5.1\n"
"1.11.7.847\n"
"1.4.48....\n"
"12.6...6.4\n"
"465.8363..\n"
"7.612.4328\n"
"3.75718.37\n"
"6.6.5.463.\n"
"51388.17.7\n"
"567.4317.1\n"
"3458...158\n"
"532.55.4..\n"
"15.86...6.\n"
"733.57..26\n"
"17.8183.8.\n") == 0);
free(board107585255);
board107585255 = NULL;
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 7, 14, 5) == 0 );
assert( gamma_move(board, 7, 1, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 8, 12, 7) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_golden_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 7, 1, 14) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 6 );
assert( gamma_free_fields(board, 2) == 57 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 4, 11) == 1 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 5, 3, 15) == 0 );
assert( gamma_free_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 4, 16) == 0 );
assert( gamma_move(board, 7, 6, 7) == 0 );
assert( gamma_free_fields(board, 7) == 15 );
assert( gamma_move(board, 8, 10, 3) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_free_fields(board, 2) == 56 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );


char* board389132049 = gamma_board(board);
assert( board389132049 != NULL );
assert( strcmp(board389132049, 
"7564.3.666\n"
"5.187.1..4\n"
"..825..5.1\n"
"1.11.7.847\n"
"1.4.48....\n"
"12.64..6.4\n"
"465.8363..\n"
"7.612.4328\n"
"3.75718.37\n"
"646.5.463.\n"
"51388.17.7\n"
"567.4317.1\n"
"3458...158\n"
"532.55.4..\n"
"15.86...6.\n"
"733.57..26\n"
"17.8183.8.\n") == 0);
free(board389132049);
board389132049 = NULL;
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_move(board, 6, 8, 14) == 0 );
assert( gamma_move(board, 7, 1, 7) == 0 );
assert( gamma_move(board, 7, 3, 6) == 0 );
assert( gamma_move(board, 8, 2, 9) == 0 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 5, 15, 7) == 0 );
assert( gamma_move(board, 6, 3, 3) == 0 );
assert( gamma_free_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 1, 6) == 0 );
assert( gamma_golden_move(board, 7, 10, 7) == 0 );
assert( gamma_move(board, 8, 13, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 15 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_golden_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_golden_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 5, 1, 11) == 0 );
assert( gamma_move(board, 6, 9, 16) == 0 );
assert( gamma_move(board, 7, 10, 8) == 0 );
assert( gamma_move(board, 7, 9, 11) == 0 );
assert( gamma_move(board, 8, 3, 2) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_free_fields(board, 3) == 56 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_free_fields(board, 4) == 56 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 7, 3, 14) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 9, 7) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );


char* board731121397 = gamma_board(board);
assert( board731121397 != NULL );
assert( strcmp(board731121397, 
"7564.3.666\n"
"5.187.1..4\n"
"..825..5.1\n"
"1.11.7.847\n"
"1.4.48....\n"
"12.64..6.4\n"
"465.8363..\n"
"7.612.4328\n"
"3.75718.37\n"
"646.5.463.\n"
"51388.17.7\n"
"567.4317.1\n"
"3458...158\n"
"532.55.4..\n"
"15.86...6.\n"
"733.57..26\n"
"17.8183.8.\n") == 0);
free(board731121397);
board731121397 = NULL;
assert( gamma_move(board, 6, 14, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 16 );


char* board420413879 = gamma_board(board);
assert( board420413879 != NULL );
assert( strcmp(board420413879, 
"7564.3.666\n"
"5.187.1..4\n"
"..825..5.1\n"
"1.11.7.847\n"
"1.4.48....\n"
"12.64..6.4\n"
"465.8363..\n"
"7.612.4328\n"
"3.75718.37\n"
"646.5.463.\n"
"51388.17.7\n"
"567.4317.1\n"
"3458...158\n"
"532.55.4..\n"
"15.86...6.\n"
"733.57..26\n"
"17.8183.8.\n") == 0);
free(board420413879);
board420413879 = NULL;
assert( gamma_move(board, 7, 9, 1) == 0 );
assert( gamma_free_fields(board, 7) == 15 );
assert( gamma_move(board, 8, 9, 1) == 0 );
assert( gamma_move(board, 8, 4, 12) == 0 );
assert( gamma_busy_fields(board, 8) == 15 );
assert( gamma_free_fields(board, 8) == 19 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 6, 9, 9) == 0 );
assert( gamma_golden_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 7, 13, 6) == 0 );
assert( gamma_free_fields(board, 7) == 15 );
assert( gamma_move(board, 8, 6, 8) == 0 );
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_golden_move(board, 8, 13, 0) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 7, 14, 8) == 0 );
assert( gamma_move(board, 8, 16, 4) == 0 );
assert( gamma_move(board, 8, 3, 11) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 4, 7, 15) == 1 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 6, 13, 6) == 0 );
assert( gamma_move(board, 6, 4, 13) == 0 );
assert( gamma_move(board, 7, 3, 0) == 0 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_move(board, 8, 7, 0) == 1 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_free_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_free_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 15, 1) == 0 );
assert( gamma_move(board, 8, 2, 2) == 1 );
assert( gamma_move(board, 8, 1, 9) == 0 );
assert( gamma_golden_move(board, 8, 6, 0) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 5, 5, 16) == 0 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_free_fields(board, 5) == 15 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_free_fields(board, 6) == 15 );
assert( gamma_move(board, 7, 12, 6) == 0 );
assert( gamma_move(board, 8, 1, 7) == 0 );
assert( gamma_move(board, 8, 9, 11) == 0 );
assert( gamma_golden_move(board, 8, 8, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );


char* board619544279 = gamma_board(board);
assert( board619544279 != NULL );
assert( strcmp(board619544279, 
"7564.3.666\n"
"5.187.14.4\n"
"3.825..5.1\n"
"1.11.7.847\n"
"1.4248....\n"
"12.64..6.4\n"
"465.8363..\n"
"7.612.4328\n"
"3.75718.37\n"
"646.5.463.\n"
"51388.17.7\n"
"567.431731\n"
"34584..158\n"
"532.55.4.2\n"
"15886...6.\n"
"733.57..26\n"
"17.818388.\n") == 0);
free(board619544279);
board619544279 = NULL;
assert( gamma_move(board, 5, 13, 4) == 0 );
assert( gamma_move(board, 6, 11, 2) == 0 );
assert( gamma_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 7, 3, 8) == 0 );


char* board867528765 = gamma_board(board);
assert( board867528765 != NULL );
assert( strcmp(board867528765, 
"7564.3.666\n"
"5.187.14.4\n"
"3.825..5.1\n"
"1.11.7.847\n"
"1.4248....\n"
"12.64..6.4\n"
"465.8363..\n"
"7.612.4328\n"
"3.75718.37\n"
"646.5.463.\n"
"51388.17.7\n"
"567.431731\n"
"34584..158\n"
"532.55.4.2\n"
"15886...6.\n"
"733.57..26\n"
"17.818388.\n") == 0);
free(board867528765);
board867528765 = NULL;
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_move(board, 1, 12, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );


gamma_delete(board);

    return 0;
}
