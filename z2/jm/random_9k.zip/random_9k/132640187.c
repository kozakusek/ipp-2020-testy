#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 132640187
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 15, 5, 28);
assert( board != NULL );


assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_free_fields(board, 2) == 178 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_move(board, 4, 8, 0) == 1 );
assert( gamma_move(board, 5, 10, 0) == 1 );
assert( gamma_move(board, 5, 5, 13) == 1 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_free_fields(board, 3) == 169 );


char* board652291120 = gamma_board(board);
assert( board652291120 != NULL );
assert( strcmp(board652291120, 
"............\n"
".....5......\n"
"............\n"
"............\n"
"............\n"
"............\n"
"......1.....\n"
"3...........\n"
"2...3.......\n"
"...1........\n"
"..32........\n"
"............\n"
"............\n"
"........1...\n"
"........4.5.\n") == 0);
free(board652291120);
board652291120 = NULL;
assert( gamma_move(board, 4, 10, 11) == 1 );
assert( gamma_free_fields(board, 4) == 168 );
assert( gamma_golden_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 5, 3, 11) == 1 );
assert( gamma_move(board, 5, 8, 14) == 1 );
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_golden_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 5, 4, 14) == 1 );
assert( gamma_move(board, 5, 10, 8) == 1 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 1, 1, 8) == 1 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_move(board, 2, 0, 10) == 1 );
assert( gamma_move(board, 3, 9, 14) == 1 );
assert( gamma_move(board, 3, 11, 3) == 1 );
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_free_fields(board, 1) == 152 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 5, 11, 5) == 1 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_free_fields(board, 4) == 146 );
assert( gamma_move(board, 5, 8, 8) == 1 );
assert( gamma_move(board, 5, 11, 7) == 1 );
assert( gamma_move(board, 1, 3, 5) == 0 );


char* board582403893 = gamma_board(board);
assert( board582403893 != NULL );
assert( strcmp(board582403893, 
"....5...53..\n"
".....5......\n"
"............\n"
"...5......4.\n"
"2...........\n"
"............\n"
".1....1.5.5.\n"
"3..........5\n"
"23..3...4...\n"
"3..12......5\n"
"..32...1..24\n"
"......4....3\n"
"..2......2..\n"
"1.......12..\n"
"...4....4.5.\n") == 0);
free(board582403893);
board582403893 = NULL;
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 2, 1, 13) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_golden_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 4, 9, 11) == 1 );
assert( gamma_free_fields(board, 4) == 136 );
assert( gamma_move(board, 5, 4, 4) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 2, 3, 6) == 1 );


char* board104878344 = gamma_board(board);
assert( board104878344 != NULL );
assert( strcmp(board104878344, 
"....5...53..\n"
".2...5......\n"
"......3.....\n"
"...5.....44.\n"
"2...........\n"
"............\n"
".1....1.5.5.\n"
"34.........5\n"
"23.23.2.4...\n"
"3..12......5\n"
"..325..1..24\n"
"......4...23\n"
"2.2......2..\n"
"1....2..323.\n"
"...4....4.5.\n") == 0);
free(board104878344);
board104878344 = NULL;
assert( gamma_move(board, 3, 10, 11) == 0 );


char* board202217136 = gamma_board(board);
assert( board202217136 != NULL );
assert( strcmp(board202217136, 
"....5...53..\n"
".2...5......\n"
"......3.....\n"
"...5.....44.\n"
"2...........\n"
"............\n"
".1....1.5.5.\n"
"34.........5\n"
"23.23.2.4...\n"
"3..12......5\n"
"..325..1..24\n"
"......4...23\n"
"2.2......2..\n"
"1....2..323.\n"
"...4....4.5.\n") == 0);
free(board202217136);
board202217136 = NULL;
assert( gamma_move(board, 5, 2, 12) == 1 );
assert( gamma_move(board, 5, 8, 13) == 1 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 9, 10) == 1 );


char* board618580857 = gamma_board(board);
assert( board618580857 != NULL );
assert( strcmp(board618580857, 
"....5...53..\n"
".2...5..5...\n"
"..5...3.....\n"
"...5.....44.\n"
"2........4..\n"
"............\n"
".1....1.5.5.\n"
"34...2.....5\n"
"23.23.2.4...\n"
"3..12......5\n"
"..325..1..24\n"
"......4...23\n"
"2.2......2..\n"
"1....2..323.\n"
"...4....4.5.\n") == 0);
free(board618580857);
board618580857 = NULL;
assert( gamma_move(board, 5, 0, 9) == 1 );
assert( gamma_move(board, 5, 3, 10) == 1 );
assert( gamma_move(board, 1, 8, 11) == 1 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 2, 1, 12) == 1 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_move(board, 5, 5, 10) == 1 );
assert( gamma_free_fields(board, 5) == 122 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 4, 4, 9) == 1 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 5, 1, 2) == 1 );
assert( gamma_golden_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 6, 14) == 1 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 2, 7, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 5, 10, 6) == 1 );
assert( gamma_move(board, 5, 7, 13) == 1 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 4, 11, 13) == 1 );
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_move(board, 5, 6, 7) == 1 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 7, 14) == 1 );
assert( gamma_move(board, 2, 4, 10) == 1 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 11) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board127033630 = gamma_board(board);
assert( board127033630 != NULL );
assert( strcmp(board127033630, 
"....5.4153..\n"
".2...5.55..4\n"
".25...3.....\n"
"13.5..4.144.\n"
"2..525...42.\n"
"5..34.12.1..\n"
".1..4.1.515.\n"
"343..25....5\n"
"23.23.2.4.5.\n"
"3..12......5\n"
".4325..1..24\n"
".....14...23\n"
"252......2.1\n"
"1....2..323.\n"
"...4....4.5.\n") == 0);
free(board127033630);
board127033630 = NULL;
assert( gamma_move(board, 5, 3, 8) == 1 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 5, 7, 3) == 1 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 2, 7, 10) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 4, 8, 5) == 1 );
assert( gamma_move(board, 5, 4, 0) == 1 );
assert( gamma_golden_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 13) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_golden_move(board, 3, 13, 5) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 5, 1, 9) == 1 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 2, 3, 1) == 1 );
assert( gamma_move(board, 3, 1, 14) == 1 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_golden_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 5, 5, 8) == 1 );
assert( gamma_move(board, 5, 7, 6) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 1, 11, 11) == 1 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_free_fields(board, 4) == 80 );
assert( gamma_move(board, 5, 0, 8) == 1 );
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 11, 12) == 1 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 6, 2) == 1 );
assert( gamma_move(board, 5, 11, 0) == 1 );
assert( gamma_move(board, 1, 1, 6) == 0 );


char* board396637034 = gamma_board(board);
assert( board396637034 != NULL );
assert( strcmp(board396637034, 
".3..5.4153..\n"
"52...5.55..4\n"
".25...3....2\n"
"13.5..4.1441\n"
"2..525.2.42.\n"
"55.34.1234..\n"
"51.5451.515.\n"
"343..251...5\n"
"23.232254.5.\n"
"3..12..342.5\n"
".4325..1..24\n"
"..2..145..23\n"
"252..45..2.1\n"
"1..222..323.\n"
"2..45...4.55\n") == 0);
free(board396637034);
board396637034 = NULL;
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_free_fields(board, 2) == 76 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 5, 5) == 1 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 5, 14, 3) == 0 );
assert( gamma_move(board, 5, 4, 12) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );


char* board196935114 = gamma_board(board);
assert( board196935114 != NULL );
assert( strcmp(board196935114, 
".3..5.4153..\n"
"52...5.55..4\n"
".25.5.3....2\n"
"13.5..4.1441\n"
"2.3525.2.424\n"
"55.34.1234..\n"
"51.5451.515.\n"
"343..251...5\n"
"23.232254.5.\n"
"3..1251342.5\n"
".4325..1..24\n"
"..24.145..23\n"
"2523.45..2.1\n"
"1..222..323.\n"
"2..45...4.55\n") == 0);
free(board196935114);
board196935114 = NULL;
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_free_fields(board, 3) == 69 );
assert( gamma_golden_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 5, 11, 14) == 1 );
assert( gamma_move(board, 1, 10, 1) == 0 );


char* board447341032 = gamma_board(board);
assert( board447341032 != NULL );
assert( strcmp(board447341032, 
".3..5.4153.5\n"
"52...5.55..4\n"
".25.5.3....2\n"
"13.5..4.1441\n"
"2.3525.2.424\n"
"55.34.1234..\n"
"51.5451.515.\n"
"343..251...5\n"
"23.232254.5.\n"
"3..1251342.5\n"
".4325..1..24\n"
"..24.145..23\n"
"2523.45..241\n"
"1..222..323.\n"
"2..45...4.55\n") == 0);
free(board447341032);
board447341032 = NULL;
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 11, 7) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 5, 5, 10) == 0 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_golden_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 33 );
assert( gamma_golden_move(board, 5, 5, 6) == 1 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_move(board, 1, 8, 12) == 1 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_move(board, 4, 10, 12) == 1 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 11, 13) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_golden_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 1, 5, 14) == 1 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );


char* board181954934 = gamma_board(board);
assert( board181954934 != NULL );
assert( strcmp(board181954934, 
"23..514153.5\n"
"52...5.55..4\n"
".25.5.3.1.42\n"
"1315..4.1441\n"
"2.3525.2.424\n"
"55534.1234..\n"
"51.5451.515.\n"
"343..251...5\n"
"23.23525435.\n"
"3..1251342.5\n"
".4325..1..24\n"
"..242145..23\n"
"2523.451.241\n"
"12.2223.323.\n"
"22.45...4.55\n") == 0);
free(board181954934);
board181954934 = NULL;
assert( gamma_busy_fields(board, 4) == 22 );


char* board916568289 = gamma_board(board);
assert( board916568289 != NULL );
assert( strcmp(board916568289, 
"23..514153.5\n"
"52...5.55..4\n"
".25.5.3.1.42\n"
"1315..4.1441\n"
"2.3525.2.424\n"
"55534.1234..\n"
"51.5451.515.\n"
"343..251...5\n"
"23.23525435.\n"
"3..1251342.5\n"
".4325..1..24\n"
"..242145..23\n"
"2523.451.241\n"
"12.2223.323.\n"
"22.45...4.55\n") == 0);
free(board916568289);
board916568289 = NULL;
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_golden_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_free_fields(board, 1) == 52 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 4, 1, 3) == 1 );
assert( gamma_move(board, 5, 4, 2) == 1 );
assert( gamma_busy_fields(board, 5) == 35 );
assert( gamma_free_fields(board, 5) == 49 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_golden_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_golden_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 11, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 4, 11, 6) == 1 );
assert( gamma_golden_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 5, 10, 11) == 0 );
assert( gamma_busy_fields(board, 5) == 35 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 3, 3, 13) == 1 );
assert( gamma_move(board, 4, 13, 10) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_free_fields(board, 5) == 46 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_move(board, 1, 8, 7) == 1 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_free_fields(board, 3) == 43 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_move(board, 5, 6, 14) == 0 );
assert( gamma_busy_fields(board, 5) == 35 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_free_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_free_fields(board, 4) == 42 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 5, 6, 5) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 9, 12) == 1 );


char* board640206332 = gamma_board(board);
assert( board640206332 != NULL );
assert( strcmp(board640206332, 
"23..514153.5\n"
"52.3.5.55..4\n"
".25.5.3.1242\n"
"1315..4.1441\n"
"1.3525.2.424\n"
"55534.1234..\n"
"51.545115151\n"
"343..2511..5\n"
"23.235254354\n"
"3..1251342.5\n"
".4325..12224\n"
".4242145.323\n"
"252354512221\n"
"12.2223.3233\n"
"22145.1.4.55\n") == 0);
free(board640206332);
board640206332 = NULL;
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 5, 3, 7) == 1 );
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 4, 8, 3) == 1 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );


char* board376274755 = gamma_board(board);
assert( board376274755 != NULL );
assert( strcmp(board376274755, 
"23..514153.5\n"
"52.3.5.55..4\n"
".25.5.3.1242\n"
"1315..4.1441\n"
"1.3525.2.424\n"
"55534.1234..\n"
"51.545115151\n"
"3435.2511..5\n"
"23.235254354\n"
"3..1251342.5\n"
".4325..12224\n"
".42421454323\n"
"252354512221\n"
"12.2223.3233\n"
"22145.1.4.55\n") == 0);
free(board376274755);
board376274755 = NULL;
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 5, 13, 10) == 0 );
assert( gamma_busy_fields(board, 5) == 36 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board919434480 = gamma_board(board);
assert( board919434480 != NULL );
assert( strcmp(board919434480, 
"23..514153.5\n"
"52.3.5.55..4\n"
".25.5.3.1242\n"
"1315..4.1441\n"
"1.3525.2.424\n"
"55534.1234..\n"
"51.545115151\n"
"3435.2511..5\n"
"23.235254354\n"
"3..1251342.5\n"
".4325..12224\n"
".42421454323\n"
"252354512221\n"
"12.2223.3233\n"
"22145.1.4.55\n") == 0);
free(board919434480);
board919434480 = NULL;
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 11, 11) == 0 );
assert( gamma_move(board, 4, 14, 2) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_free_fields(board, 4) == 37 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 5, 4, 11) == 1 );


char* board539582489 = gamma_board(board);
assert( board539582489 != NULL );
assert( strcmp(board539582489, 
"23..514153.5\n"
"52.3.5.55..4\n"
".25.5.3.1242\n"
"13155.4.1441\n"
"1.3525.2.424\n"
"55534.1234..\n"
"51.545115151\n"
"3435.2511..5\n"
"23.235254354\n"
"3..1251342.5\n"
".4325.112224\n"
".42421454323\n"
"252354512221\n"
"12.2223.3233\n"
"22145.1.4.55\n") == 0);
free(board539582489);
board539582489 = NULL;
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_golden_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_free_fields(board, 5) == 36 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_free_fields(board, 4) == 36 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 37 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 7, 1) == 1 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 38 );
assert( gamma_free_fields(board, 5) == 34 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_golden_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 5, 8, 10) == 1 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );


char* board148138070 = gamma_board(board);
assert( board148138070 != NULL );
assert( strcmp(board148138070, 
"23..514153.5\n"
"5233.5.55..4\n"
".25.5.3.1242\n"
"13155.4.1441\n"
"1.3525.25424\n"
"55534.1234..\n"
"51.545115151\n"
"3435.2511..5\n"
"23.235254354\n"
"3.41251342.5\n"
".4325.112224\n"
".42421454323\n"
"252354512221\n"
"12.222353233\n"
"22145.1.4.55\n") == 0);
free(board148138070);
board148138070 = NULL;
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_free_fields(board, 5) == 21 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_free_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 9, 11) == 0 );


char* board234099320 = gamma_board(board);
assert( board234099320 != NULL );
assert( strcmp(board234099320, 
"23..514153.5\n"
"5233.5.55..4\n"
".25.5.3.1242\n"
"13155.4.1441\n"
"1.3525.25424\n"
"55534.1234..\n"
"51.545115151\n"
"3435.2511..5\n"
"23.235254354\n"
"3.41251342.5\n"
".4325.112224\n"
".42421454323\n"
"252354512221\n"
"12.222353233\n"
"2214551.4.55\n") == 0);
free(board234099320);
board234099320 = NULL;
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_move(board, 5, 5, 4) == 1 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_golden_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_free_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_move(board, 5, 14, 2) == 0 );
assert( gamma_move(board, 1, 13, 10) == 0 );


char* board167568873 = gamma_board(board);
assert( board167568873 != NULL );
assert( strcmp(board167568873, 
"23..514153.5\n"
"5233.5.55..4\n"
".25.5.3.1242\n"
"13155.431441\n"
"1.3525.25424\n"
"5553441234..\n"
"51.545115151\n"
"3435.2511..5\n"
"23.235254354\n"
"3.41251342.5\n"
".43255112224\n"
".42421454323\n"
"252354512221\n"
"12.222353233\n"
"2214551.4.55\n") == 0);
free(board167568873);
board167568873 = NULL;
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );


char* board391568690 = gamma_board(board);
assert( board391568690 != NULL );
assert( strcmp(board391568690, 
"23..514153.5\n"
"5233.5.55..4\n"
".25.5.3.1242\n"
"13155.431441\n"
"1.3525.25424\n"
"5553441234..\n"
"51.545115151\n"
"3435.2511..5\n"
"23.235254354\n"
"3.41251342.5\n"
".43255112224\n"
".42421454323\n"
"252354512221\n"
"12.222353233\n"
"2214551.4.55\n") == 0);
free(board391568690);
board391568690 = NULL;
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_free_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_free_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 4, 10, 10) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 5, 8, 1) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 4, 5, 12) == 1 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 1, 7, 12) == 1 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_golden_move(board, 4, 0, 0) == 0 );
assert( gamma_move(board, 5, 0, 4) == 1 );
assert( gamma_move(board, 5, 11, 2) == 0 );


gamma_delete(board);

    return 0;
}
