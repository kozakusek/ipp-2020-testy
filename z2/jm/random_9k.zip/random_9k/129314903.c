#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 129314903
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 170, 7, 24);
assert( board != NULL );


assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 1, 0, 91) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );
assert( gamma_move(board, 2, 25, 0) == 0 );
assert( gamma_move(board, 2, 0, 88) == 1 );
assert( gamma_move(board, 3, 76, 0) == 0 );
assert( gamma_free_fields(board, 3) == 168 );
assert( gamma_move(board, 4, 98, 0) == 0 );
assert( gamma_move(board, 5, 0, 165) == 1 );
assert( gamma_move(board, 5, 0, 138) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 83, 0) == 0 );
assert( gamma_move(board, 6, 0, 1) == 1 );
assert( gamma_move(board, 7, 0, 106) == 1 );
assert( gamma_move(board, 1, 0, 152) == 1 );
assert( gamma_move(board, 1, 0, 20) == 1 );
assert( gamma_move(board, 2, 75, 0) == 0 );
assert( gamma_move(board, 2, 0, 53) == 1 );
assert( gamma_move(board, 3, 35, 0) == 0 );
assert( gamma_move(board, 3, 0, 37) == 1 );
assert( gamma_move(board, 4, 31, 0) == 0 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 143, 0) == 0 );
assert( gamma_move(board, 6, 128, 0) == 0 );
assert( gamma_move(board, 7, 141, 0) == 0 );
assert( gamma_move(board, 7, 0, 147) == 1 );
assert( gamma_move(board, 2, 0, 56) == 1 );
assert( gamma_move(board, 2, 0, 55) == 1 );
assert( gamma_golden_move(board, 2, 0, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 142) == 1 );
assert( gamma_free_fields(board, 4) == 155 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_move(board, 5, 0, 168) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_free_fields(board, 5) == 153 );
assert( gamma_move(board, 6, 0, 54) == 1 );
assert( gamma_golden_move(board, 7, 37, 0) == 0 );
assert( gamma_move(board, 1, 0, 54) == 0 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 2, 0, 86) == 1 );
assert( gamma_move(board, 3, 0, 121) == 1 );
assert( gamma_move(board, 3, 0, 105) == 1 );
assert( gamma_move(board, 4, 0, 45) == 1 );
assert( gamma_move(board, 4, 0, 137) == 1 );
assert( gamma_free_fields(board, 4) == 146 );
assert( gamma_move(board, 5, 156, 0) == 0 );
assert( gamma_move(board, 5, 0, 67) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 33, 0) == 0 );
assert( gamma_move(board, 6, 0, 133) == 1 );


char* board872684176 = gamma_board(board);
assert( board872684176 != NULL );
assert( strcmp(board872684176, 
".\n"
"5\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
"2\n") == 0);
free(board872684176);
board872684176 = NULL;
assert( gamma_move(board, 7, 132, 0) == 0 );
assert( gamma_move(board, 7, 0, 115) == 1 );
assert( gamma_free_fields(board, 7) == 143 );
assert( gamma_move(board, 1, 0, 36) == 1 );
assert( gamma_move(board, 2, 60, 0) == 0 );


char* board247007589 = gamma_board(board);
assert( board247007589 != NULL );
assert( strcmp(board247007589, 
".\n"
"5\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
"2\n") == 0);
free(board247007589);
board247007589 = NULL;
assert( gamma_move(board, 3, 49, 0) == 0 );
assert( gamma_move(board, 3, 0, 145) == 1 );
assert( gamma_move(board, 4, 80, 0) == 0 );
assert( gamma_move(board, 4, 0, 116) == 1 );
assert( gamma_move(board, 5, 109, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_free_fields(board, 5) == 140 );


char* board702311106 = gamma_board(board);
assert( board702311106 != NULL );
assert( strcmp(board702311106, 
".\n"
"5\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
"2\n") == 0);
free(board702311106);
board702311106 = NULL;
assert( gamma_move(board, 6, 34, 0) == 0 );
assert( gamma_free_fields(board, 6) == 140 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 154, 0) == 0 );
assert( gamma_move(board, 7, 0, 33) == 1 );
assert( gamma_move(board, 1, 63, 0) == 0 );
assert( gamma_move(board, 2, 156, 0) == 0 );
assert( gamma_move(board, 3, 29, 0) == 0 );
assert( gamma_move(board, 4, 131, 0) == 0 );
assert( gamma_move(board, 4, 0, 12) == 1 );
assert( gamma_move(board, 5, 50, 0) == 0 );
assert( gamma_move(board, 5, 0, 28) == 1 );
assert( gamma_move(board, 6, 118, 0) == 0 );
assert( gamma_move(board, 6, 0, 150) == 1 );
assert( gamma_move(board, 7, 76, 0) == 0 );
assert( gamma_move(board, 1, 17, 0) == 0 );
assert( gamma_move(board, 2, 102, 0) == 0 );
assert( gamma_move(board, 2, 0, 117) == 1 );
assert( gamma_move(board, 3, 0, 166) == 1 );
assert( gamma_move(board, 3, 0, 120) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 156, 0) == 0 );
assert( gamma_move(board, 5, 0, 168) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 44, 0) == 0 );
assert( gamma_move(board, 6, 0, 110) == 1 );
assert( gamma_busy_fields(board, 6) == 5 );
assert( gamma_move(board, 7, 78, 0) == 0 );
assert( gamma_move(board, 1, 24, 0) == 0 );
assert( gamma_free_fields(board, 2) == 132 );
assert( gamma_move(board, 3, 0, 100) == 1 );
assert( gamma_move(board, 3, 0, 97) == 1 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 48, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 5, 39, 0) == 0 );
assert( gamma_move(board, 5, 0, 166) == 0 );
assert( gamma_move(board, 6, 126, 0) == 0 );
assert( gamma_move(board, 6, 0, 117) == 0 );
assert( gamma_move(board, 7, 0, 160) == 1 );
assert( gamma_move(board, 1, 124, 0) == 0 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_move(board, 2, 85, 0) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_free_fields(board, 2) == 127 );
assert( gamma_move(board, 3, 0, 113) == 1 );
assert( gamma_move(board, 3, 0, 138) == 0 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 148, 0) == 0 );
assert( gamma_move(board, 7, 0, 92) == 1 );
assert( gamma_move(board, 7, 0, 98) == 1 );
assert( gamma_move(board, 1, 25, 0) == 0 );
assert( gamma_move(board, 2, 129, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 46, 0) == 0 );
assert( gamma_move(board, 3, 0, 70) == 1 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 78, 0) == 0 );
assert( gamma_move(board, 5, 0, 142) == 0 );
assert( gamma_move(board, 5, 0, 45) == 0 );
assert( gamma_move(board, 6, 125, 0) == 0 );
assert( gamma_move(board, 6, 0, 50) == 1 );
assert( gamma_move(board, 7, 41, 0) == 0 );
assert( gamma_move(board, 7, 0, 47) == 1 );
assert( gamma_move(board, 1, 73, 0) == 0 );
assert( gamma_move(board, 2, 101, 0) == 0 );
assert( gamma_move(board, 2, 0, 86) == 0 );
assert( gamma_move(board, 3, 146, 0) == 0 );
assert( gamma_golden_move(board, 3, 36, 0) == 0 );
assert( gamma_move(board, 4, 0, 44) == 1 );
assert( gamma_golden_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 5, 0, 90) == 1 );
assert( gamma_move(board, 6, 60, 0) == 0 );
assert( gamma_move(board, 7, 30, 0) == 0 );
assert( gamma_move(board, 7, 0, 47) == 0 );
assert( gamma_move(board, 1, 17, 0) == 0 );
assert( gamma_move(board, 2, 111, 0) == 0 );
assert( gamma_move(board, 3, 0, 128) == 1 );
assert( gamma_move(board, 3, 0, 144) == 1 );
assert( gamma_move(board, 4, 61, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 21, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 82, 0) == 0 );
assert( gamma_move(board, 6, 0, 54) == 0 );
assert( gamma_free_fields(board, 6) == 117 );
assert( gamma_move(board, 7, 0, 76) == 1 );
assert( gamma_move(board, 1, 0, 50) == 0 );
assert( gamma_move(board, 1, 0, 108) == 1 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 38, 0) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 4, 83, 0) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );


char* board416018125 = gamma_board(board);
assert( board416018125 != NULL );
assert( strcmp(board416018125, 
".\n"
"5\n"
".\n"
"3\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"3\n"
"3\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"2\n"
"4\n"
"7\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
".\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"1\n"
"5\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board416018125);
board416018125 = NULL;
assert( gamma_move(board, 6, 101, 0) == 0 );
assert( gamma_move(board, 7, 134, 0) == 0 );
assert( gamma_move(board, 1, 84, 0) == 0 );
assert( gamma_move(board, 1, 0, 63) == 1 );
assert( gamma_move(board, 2, 72, 0) == 0 );
assert( gamma_move(board, 3, 75, 0) == 0 );
assert( gamma_move(board, 3, 0, 93) == 1 );
assert( gamma_move(board, 4, 0, 138) == 0 );
assert( gamma_move(board, 5, 0, 95) == 1 );
assert( gamma_move(board, 6, 0, 66) == 1 );
assert( gamma_move(board, 6, 0, 4) == 1 );
assert( gamma_move(board, 7, 139, 0) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_move(board, 1, 0, 43) == 1 );
assert( gamma_move(board, 2, 75, 0) == 0 );
assert( gamma_move(board, 2, 0, 146) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 0, 15) == 1 );
assert( gamma_move(board, 4, 0, 24) == 1 );
assert( gamma_move(board, 4, 0, 81) == 1 );
assert( gamma_move(board, 5, 0, 122) == 1 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_move(board, 6, 148, 0) == 0 );
assert( gamma_move(board, 6, 0, 69) == 1 );
assert( gamma_move(board, 7, 99, 0) == 0 );
assert( gamma_move(board, 1, 0, 78) == 1 );
assert( gamma_move(board, 2, 40, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 140, 0) == 0 );
assert( gamma_free_fields(board, 3) == 102 );
assert( gamma_move(board, 4, 129, 0) == 0 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 5, 0, 16) == 1 );
assert( gamma_move(board, 6, 0, 54) == 0 );
assert( gamma_move(board, 6, 0, 33) == 0 );
assert( gamma_move(board, 7, 0, 20) == 0 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 1, 158, 0) == 0 );
assert( gamma_move(board, 1, 0, 163) == 1 );


char* board186797841 = gamma_board(board);
assert( board186797841 != NULL );
assert( strcmp(board186797841, 
".\n"
"5\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
"3\n"
".\n"
".\n"
"2\n"
"4\n"
"7\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
".\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"7\n"
"3\n"
".\n"
"5\n"
".\n"
"3\n"
"7\n"
"1\n"
"5\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board186797841);
board186797841 = NULL;
assert( gamma_move(board, 2, 0, 169) == 1 );
assert( gamma_move(board, 2, 0, 156) == 1 );
assert( gamma_move(board, 3, 40, 0) == 0 );
assert( gamma_free_fields(board, 3) == 98 );
assert( gamma_golden_move(board, 3, 76, 0) == 0 );
assert( gamma_move(board, 4, 0, 99) == 1 );
assert( gamma_move(board, 4, 0, 33) == 0 );
assert( gamma_move(board, 5, 34, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board212150025 = gamma_board(board);
assert( board212150025 != NULL );
assert( strcmp(board212150025, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
"3\n"
".\n"
".\n"
"2\n"
"4\n"
"7\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
".\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
".\n"
"5\n"
".\n"
"3\n"
"7\n"
"1\n"
"5\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board212150025);
board212150025 = NULL;
assert( gamma_move(board, 7, 0, 97) == 0 );
assert( gamma_move(board, 7, 0, 123) == 1 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 30) == 1 );
assert( gamma_move(board, 1, 0, 86) == 0 );
assert( gamma_move(board, 2, 0, 142) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_golden_move(board, 3, 81, 0) == 0 );
assert( gamma_move(board, 4, 75, 0) == 0 );
assert( gamma_move(board, 4, 0, 150) == 0 );
assert( gamma_free_fields(board, 4) == 95 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 134, 0) == 0 );
assert( gamma_move(board, 5, 0, 154) == 1 );
assert( gamma_move(board, 6, 87, 0) == 0 );
assert( gamma_move(board, 7, 72, 0) == 0 );


char* board697957204 = gamma_board(board);
assert( board697957204 != NULL );
assert( strcmp(board697957204, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"5\n"
".\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
".\n"
"2\n"
"4\n"
"7\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
".\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
".\n"
"5\n"
".\n"
"3\n"
"7\n"
"1\n"
"5\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board697957204);
board697957204 = NULL;
assert( gamma_move(board, 1, 0, 72) == 1 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 84, 0) == 0 );
assert( gamma_move(board, 2, 0, 155) == 1 );
assert( gamma_free_fields(board, 3) == 92 );
assert( gamma_move(board, 6, 149, 0) == 0 );
assert( gamma_move(board, 6, 0, 29) == 1 );
assert( gamma_move(board, 7, 109, 0) == 0 );
assert( gamma_move(board, 7, 0, 30) == 0 );
assert( gamma_busy_fields(board, 7) == 10 );
assert( gamma_move(board, 1, 0, 102) == 1 );
assert( gamma_move(board, 2, 41, 0) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 114, 0) == 0 );
assert( gamma_move(board, 5, 96, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 11 );
assert( gamma_move(board, 6, 111, 0) == 0 );
assert( gamma_move(board, 6, 0, 162) == 1 );
assert( gamma_move(board, 1, 87, 0) == 0 );
assert( gamma_move(board, 1, 0, 122) == 0 );
assert( gamma_move(board, 2, 17, 0) == 0 );
assert( gamma_move(board, 2, 0, 64) == 1 );
assert( gamma_move(board, 3, 26, 0) == 0 );
assert( gamma_move(board, 4, 0, 153) == 1 );
assert( gamma_move(board, 5, 73, 0) == 0 );
assert( gamma_move(board, 5, 0, 44) == 0 );
assert( gamma_move(board, 6, 159, 0) == 0 );
assert( gamma_move(board, 6, 0, 70) == 0 );
assert( gamma_move(board, 7, 13, 0) == 0 );
assert( gamma_move(board, 7, 0, 30) == 0 );
assert( gamma_move(board, 1, 161, 0) == 0 );
assert( gamma_move(board, 1, 0, 89) == 1 );
assert( gamma_move(board, 2, 0, 118) == 1 );
assert( gamma_move(board, 3, 119, 0) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 41, 0) == 0 );
assert( gamma_move(board, 5, 119, 0) == 0 );
assert( gamma_move(board, 5, 0, 136) == 1 );
assert( gamma_move(board, 6, 0, 94) == 1 );
assert( gamma_move(board, 6, 0, 98) == 0 );
assert( gamma_move(board, 7, 84, 0) == 0 );
assert( gamma_move(board, 1, 158, 0) == 0 );
assert( gamma_move(board, 1, 0, 114) == 1 );
assert( gamma_move(board, 3, 0, 91) == 0 );
assert( gamma_move(board, 4, 0, 104) == 1 );
assert( gamma_free_fields(board, 4) == 81 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 73, 0) == 0 );
assert( gamma_move(board, 6, 71, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_move(board, 7, 101, 0) == 0 );
assert( gamma_move(board, 7, 0, 80) == 1 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 1, 68, 0) == 0 );
assert( gamma_move(board, 1, 0, 118) == 0 );
assert( gamma_move(board, 2, 0, 164) == 1 );


char* board581962529 = gamma_board(board);
assert( board581962529 != NULL );
assert( strcmp(board581962529, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"6\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"5\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
"2\n"
"2\n"
"4\n"
"7\n"
"1\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
".\n"
"7\n"
"3\n"
"4\n"
".\n"
"1\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
".\n"
"5\n"
"6\n"
"3\n"
"7\n"
"1\n"
"5\n"
"1\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board581962529);
board581962529 = NULL;
assert( gamma_move(board, 4, 77, 0) == 0 );
assert( gamma_move(board, 4, 0, 72) == 0 );
assert( gamma_move(board, 5, 112, 0) == 0 );
assert( gamma_move(board, 5, 0, 39) == 1 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 0, 88) == 0 );
assert( gamma_golden_move(board, 6, 30, 0) == 0 );
assert( gamma_move(board, 7, 0, 91) == 0 );
assert( gamma_move(board, 1, 0, 73) == 1 );
assert( gamma_move(board, 2, 149, 0) == 0 );
assert( gamma_move(board, 2, 0, 118) == 0 );
assert( gamma_move(board, 3, 0, 29) == 0 );
assert( gamma_move(board, 4, 35, 0) == 0 );
assert( gamma_move(board, 4, 0, 115) == 0 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 7, 26, 0) == 0 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 1, 60, 0) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 0, 42) == 1 );
assert( gamma_move(board, 3, 0, 76) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 143) == 1 );
assert( gamma_move(board, 5, 0, 92) == 0 );
assert( gamma_move(board, 5, 0, 70) == 0 );


char* board352892446 = gamma_board(board);
assert( board352892446 != NULL );
assert( strcmp(board352892446, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"6\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"5\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
"2\n"
"2\n"
"4\n"
"7\n"
"1\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
".\n"
"7\n"
"3\n"
"4\n"
".\n"
"1\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
".\n"
"5\n"
"6\n"
"3\n"
"7\n"
"1\n"
"5\n"
"1\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
"2\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board352892446);
board352892446 = NULL;
assert( gamma_move(board, 6, 126, 0) == 0 );
assert( gamma_move(board, 6, 0, 60) == 1 );
assert( gamma_move(board, 7, 101, 0) == 0 );
assert( gamma_move(board, 1, 0, 115) == 0 );
assert( gamma_move(board, 1, 0, 136) == 0 );
assert( gamma_move(board, 2, 41, 0) == 0 );
assert( gamma_move(board, 2, 0, 107) == 1 );
assert( gamma_move(board, 3, 0, 168) == 0 );
assert( gamma_move(board, 4, 61, 0) == 0 );
assert( gamma_move(board, 4, 0, 147) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 140, 0) == 0 );


char* board496935472 = gamma_board(board);
assert( board496935472 != NULL );
assert( strcmp(board496935472, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"6\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"5\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
"2\n"
"2\n"
"4\n"
"7\n"
"1\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
"2\n"
"7\n"
"3\n"
"4\n"
".\n"
"1\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
".\n"
"5\n"
"6\n"
"3\n"
"7\n"
"1\n"
"5\n"
"1\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"1\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
"2\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board496935472);
board496935472 = NULL;
assert( gamma_move(board, 6, 127, 0) == 0 );
assert( gamma_move(board, 7, 65, 0) == 0 );
assert( gamma_move(board, 7, 0, 67) == 0 );
assert( gamma_move(board, 1, 0, 44) == 0 );
assert( gamma_move(board, 2, 0, 121) == 0 );


char* board396127195 = gamma_board(board);
assert( board396127195 != NULL );
assert( strcmp(board396127195, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"6\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"5\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
"2\n"
"2\n"
"4\n"
"7\n"
"1\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
"2\n"
"7\n"
"3\n"
"4\n"
".\n"
"1\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
".\n"
"5\n"
"6\n"
"3\n"
"7\n"
"1\n"
"5\n"
"1\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"1\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
"2\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board396127195);
board396127195 = NULL;
assert( gamma_move(board, 3, 119, 0) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_golden_move(board, 4, 106, 0) == 0 );
assert( gamma_move(board, 5, 0, 10) == 1 );
assert( gamma_move(board, 5, 0, 110) == 0 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_move(board, 6, 129, 0) == 0 );
assert( gamma_move(board, 6, 0, 162) == 0 );
assert( gamma_move(board, 7, 127, 0) == 0 );
assert( gamma_move(board, 1, 31, 0) == 0 );
assert( gamma_move(board, 1, 0, 63) == 0 );
assert( gamma_move(board, 2, 0, 56) == 0 );
assert( gamma_move(board, 3, 32, 0) == 0 );
assert( gamma_free_fields(board, 3) == 72 );
assert( gamma_move(board, 4, 0, 139) == 1 );
assert( gamma_move(board, 4, 0, 41) == 1 );
assert( gamma_move(board, 5, 0, 107) == 0 );
assert( gamma_move(board, 5, 0, 96) == 1 );
assert( gamma_free_fields(board, 5) == 69 );
assert( gamma_move(board, 6, 130, 0) == 0 );
assert( gamma_move(board, 7, 0, 74) == 1 );
assert( gamma_move(board, 1, 140, 0) == 0 );
assert( gamma_move(board, 2, 0, 156) == 0 );
assert( gamma_move(board, 3, 0, 132) == 1 );
assert( gamma_move(board, 3, 0, 136) == 0 );
assert( gamma_move(board, 4, 0, 57) == 1 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 5, 61, 0) == 0 );
assert( gamma_move(board, 5, 0, 63) == 0 );
assert( gamma_move(board, 6, 21, 0) == 0 );
assert( gamma_move(board, 7, 0, 61) == 1 );
assert( gamma_move(board, 1, 157, 0) == 0 );
assert( gamma_move(board, 1, 0, 133) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 40, 0) == 0 );
assert( gamma_move(board, 3, 0, 62) == 1 );
assert( gamma_move(board, 3, 0, 50) == 0 );


char* board412296101 = gamma_board(board);
assert( board412296101 != NULL );
assert( strcmp(board412296101, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"6\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"5\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
"4\n"
"4\n"
".\n"
".\n"
"4\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
"2\n"
"2\n"
"4\n"
"7\n"
"1\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
"2\n"
"7\n"
"3\n"
"4\n"
".\n"
"1\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
"5\n"
"5\n"
"6\n"
"3\n"
"7\n"
"1\n"
"5\n"
"1\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
"7\n"
"1\n"
"1\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"1\n"
"3\n"
"7\n"
"6\n"
".\n"
".\n"
"4\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
"2\n"
"4\n"
".\n"
"5\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
"5\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board412296101);
board412296101 = NULL;
assert( gamma_move(board, 4, 131, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_free_fields(board, 5) == 64 );
assert( gamma_move(board, 6, 0, 14) == 1 );
assert( gamma_move(board, 7, 159, 0) == 0 );
assert( gamma_move(board, 1, 35, 0) == 0 );
assert( gamma_move(board, 2, 0, 162) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 131, 0) == 0 );
assert( gamma_move(board, 3, 0, 147) == 0 );
assert( gamma_move(board, 4, 159, 0) == 0 );
assert( gamma_move(board, 5, 0, 107) == 0 );
assert( gamma_move(board, 5, 0, 161) == 1 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 7, 0, 161) == 0 );
assert( gamma_move(board, 1, 84, 0) == 0 );
assert( gamma_move(board, 2, 18, 0) == 0 );
assert( gamma_free_fields(board, 2) == 62 );


char* board465745725 = gamma_board(board);
assert( board465745725 != NULL );
assert( strcmp(board465745725, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"6\n"
"5\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"5\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
"4\n"
"4\n"
".\n"
".\n"
"4\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
"2\n"
"2\n"
"4\n"
"7\n"
"1\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"1\n"
"2\n"
"7\n"
"3\n"
"4\n"
".\n"
"1\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
"5\n"
"5\n"
"6\n"
"3\n"
"7\n"
"1\n"
"5\n"
"1\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
"7\n"
"1\n"
"1\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"1\n"
"3\n"
"7\n"
"6\n"
".\n"
".\n"
"4\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"4\n"
"1\n"
"2\n"
"4\n"
".\n"
"5\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"3\n"
"6\n"
".\n"
"4\n"
"1\n"
"5\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board465745725);
board465745725 = NULL;
assert( gamma_move(board, 3, 87, 0) == 0 );
assert( gamma_move(board, 3, 0, 111) == 1 );
assert( gamma_move(board, 4, 18, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 7, 46, 0) == 0 );
assert( gamma_move(board, 1, 68, 0) == 0 );
assert( gamma_move(board, 2, 149, 0) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 0, 105) == 0 );
assert( gamma_move(board, 4, 0, 90) == 0 );
assert( gamma_move(board, 4, 0, 108) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 64) == 0 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 7, 119, 0) == 0 );
assert( gamma_free_fields(board, 7) == 61 );
assert( gamma_golden_move(board, 1, 88, 0) == 0 );
assert( gamma_move(board, 2, 124, 0) == 0 );
assert( gamma_move(board, 3, 25, 0) == 0 );
assert( gamma_move(board, 4, 119, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 101, 0) == 0 );
assert( gamma_move(board, 5, 0, 94) == 0 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_move(board, 6, 0, 102) == 0 );
assert( gamma_move(board, 7, 0, 76) == 0 );
assert( gamma_free_fields(board, 7) == 61 );
assert( gamma_move(board, 1, 149, 0) == 0 );
assert( gamma_move(board, 2, 0, 84) == 1 );
assert( gamma_move(board, 2, 0, 17) == 1 );
assert( gamma_move(board, 3, 0, 165) == 0 );
assert( gamma_move(board, 3, 0, 30) == 0 );
assert( gamma_move(board, 4, 68, 0) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 159, 0) == 0 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 7, 3, 0) == 0 );
assert( gamma_move(board, 7, 0, 103) == 1 );
assert( gamma_free_fields(board, 7) == 58 );
assert( gamma_move(board, 1, 129, 0) == 0 );
assert( gamma_move(board, 1, 0, 23) == 1 );
assert( gamma_move(board, 2, 0, 121) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 0, 143) == 0 );
assert( gamma_move(board, 4, 19, 0) == 0 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 5, 0, 168) == 0 );
assert( gamma_move(board, 6, 48, 0) == 0 );
assert( gamma_move(board, 6, 0, 46) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 68, 0) == 0 );
assert( gamma_move(board, 7, 0, 127) == 1 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 2, 0, 99) == 0 );
assert( gamma_move(board, 2, 0, 53) == 0 );
assert( gamma_move(board, 3, 135, 0) == 0 );
assert( gamma_move(board, 4, 0, 160) == 0 );
assert( gamma_move(board, 5, 21, 0) == 0 );
assert( gamma_move(board, 6, 68, 0) == 0 );
assert( gamma_move(board, 6, 0, 80) == 0 );
assert( gamma_move(board, 7, 0, 154) == 0 );
assert( gamma_move(board, 2, 40, 0) == 0 );
assert( gamma_move(board, 2, 0, 88) == 0 );
assert( gamma_move(board, 3, 0, 143) == 0 );
assert( gamma_move(board, 3, 0, 165) == 0 );
assert( gamma_move(board, 4, 0, 80) == 0 );
assert( gamma_move(board, 4, 0, 112) == 1 );
assert( gamma_move(board, 5, 130, 0) == 0 );
assert( gamma_move(board, 5, 0, 78) == 0 );
assert( gamma_move(board, 6, 0, 49) == 1 );
assert( gamma_free_fields(board, 6) == 53 );
assert( gamma_golden_move(board, 6, 46, 0) == 0 );


char* board636650941 = gamma_board(board);
assert( board636650941 != NULL );
assert( strcmp(board636650941, 
"2\n"
"5\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"6\n"
"5\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"5\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
"4\n"
"4\n"
".\n"
".\n"
"4\n"
"5\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
".\n"
".\n"
"3\n"
"7\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
"2\n"
"2\n"
"4\n"
"7\n"
"1\n"
"3\n"
"4\n"
"3\n"
"6\n"
".\n"
"1\n"
"2\n"
"7\n"
"3\n"
"4\n"
"7\n"
"1\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
"5\n"
"5\n"
"6\n"
"3\n"
"7\n"
"1\n"
"5\n"
"1\n"
"2\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"1\n"
".\n"
"7\n"
".\n"
"7\n"
"1\n"
"1\n"
".\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"1\n"
"3\n"
"7\n"
"6\n"
".\n"
".\n"
"4\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
"6\n"
".\n"
"7\n"
"6\n"
"4\n"
"4\n"
"1\n"
"2\n"
"4\n"
".\n"
"5\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
"5\n"
"3\n"
"6\n"
".\n"
"4\n"
"1\n"
"5\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board636650941);
board636650941 = NULL;
assert( gamma_move(board, 7, 130, 0) == 0 );
assert( gamma_move(board, 7, 0, 166) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 131, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 0, 72) == 0 );
assert( gamma_move(board, 2, 0, 150) == 0 );
assert( gamma_move(board, 3, 158, 0) == 0 );
assert( gamma_move(board, 4, 26, 0) == 0 );
assert( gamma_move(board, 4, 0, 64) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 40, 0) == 0 );
assert( gamma_move(board, 6, 0, 73) == 0 );
assert( gamma_move(board, 6, 0, 135) == 1 );
assert( gamma_move(board, 7, 149, 0) == 0 );
assert( gamma_free_fields(board, 7) == 52 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 58, 0) == 0 );
assert( gamma_move(board, 1, 0, 72) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 155) == 0 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_move(board, 5, 71, 0) == 0 );
assert( gamma_move(board, 5, 0, 27) == 1 );
assert( gamma_move(board, 6, 25, 0) == 0 );
assert( gamma_move(board, 6, 0, 108) == 0 );
assert( gamma_move(board, 7, 38, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 92) == 0 );
assert( gamma_move(board, 1, 0, 54) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 134, 0) == 0 );
assert( gamma_move(board, 2, 0, 64) == 0 );
assert( gamma_move(board, 3, 167, 0) == 0 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 4, 0, 90) == 0 );
assert( gamma_move(board, 4, 0, 17) == 0 );
assert( gamma_move(board, 5, 0, 60) == 0 );
assert( gamma_move(board, 6, 34, 0) == 0 );
assert( gamma_move(board, 7, 77, 0) == 0 );
assert( gamma_move(board, 7, 0, 22) == 1 );
assert( gamma_move(board, 1, 68, 0) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 0, 16) == 0 );
assert( gamma_free_fields(board, 2) == 48 );
assert( gamma_move(board, 3, 0, 67) == 0 );
assert( gamma_move(board, 4, 0, 46) == 0 );
assert( gamma_move(board, 4, 0, 31) == 1 );
assert( gamma_move(board, 5, 58, 0) == 0 );
assert( gamma_move(board, 6, 0, 77) == 1 );
assert( gamma_move(board, 7, 0, 167) == 1 );
assert( gamma_move(board, 1, 65, 0) == 0 );
assert( gamma_free_fields(board, 1) == 45 );
assert( gamma_move(board, 3, 85, 0) == 0 );
assert( gamma_move(board, 4, 52, 0) == 0 );
assert( gamma_move(board, 5, 125, 0) == 0 );
assert( gamma_move(board, 6, 19, 0) == 0 );
assert( gamma_move(board, 6, 0, 164) == 0 );
assert( gamma_move(board, 7, 158, 0) == 0 );
assert( gamma_move(board, 1, 71, 0) == 0 );
assert( gamma_move(board, 2, 35, 0) == 0 );
assert( gamma_move(board, 2, 0, 86) == 0 );
assert( gamma_move(board, 3, 158, 0) == 0 );
assert( gamma_move(board, 3, 0, 168) == 0 );
assert( gamma_move(board, 5, 148, 0) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_move(board, 6, 0, 94) == 0 );
assert( gamma_move(board, 7, 0, 40) == 1 );
assert( gamma_move(board, 7, 0, 13) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 83, 0) == 0 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 134, 0) == 0 );
assert( gamma_free_fields(board, 5) == 42 );
assert( gamma_move(board, 6, 65, 0) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 18, 0) == 0 );
assert( gamma_move(board, 1, 38, 0) == 0 );
assert( gamma_move(board, 2, 101, 0) == 0 );
assert( gamma_move(board, 2, 0, 42) == 0 );
assert( gamma_move(board, 3, 0, 49) == 0 );
assert( gamma_free_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 21, 0) == 0 );
assert( gamma_move(board, 4, 0, 106) == 0 );
assert( gamma_move(board, 5, 0, 160) == 0 );
assert( gamma_move(board, 7, 0, 71) == 1 );
assert( gamma_move(board, 7, 0, 131) == 1 );


char* board130726465 = gamma_board(board);
assert( board130726465 != NULL );
assert( strcmp(board130726465, 
"2\n"
"5\n"
"7\n"
"3\n"
"5\n"
"2\n"
"1\n"
"6\n"
"5\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
"5\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"7\n"
"2\n"
"3\n"
"3\n"
"4\n"
"4\n"
".\n"
".\n"
"4\n"
"5\n"
"4\n"
"5\n"
"6\n"
".\n"
"6\n"
"3\n"
"7\n"
".\n"
".\n"
"3\n"
"7\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
"3\n"
"3\n"
".\n"
"2\n"
"2\n"
"4\n"
"7\n"
"1\n"
"3\n"
"4\n"
"3\n"
"6\n"
".\n"
"1\n"
"2\n"
"7\n"
"3\n"
"4\n"
"7\n"
"1\n"
".\n"
"3\n"
"4\n"
"7\n"
"3\n"
"5\n"
"5\n"
"6\n"
"3\n"
"7\n"
"1\n"
"5\n"
"1\n"
"2\n"
".\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"1\n"
"6\n"
"7\n"
".\n"
"7\n"
"1\n"
"1\n"
"7\n"
"3\n"
"6\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"1\n"
"3\n"
"7\n"
"6\n"
".\n"
".\n"
"4\n"
"2\n"
"2\n"
"6\n"
"2\n"
".\n"
".\n"
"6\n"
"6\n"
".\n"
"7\n"
"6\n"
"4\n"
"4\n"
"1\n"
"2\n"
"4\n"
"7\n"
"5\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
"4\n"
"1\n"
"6\n"
"5\n"
"5\n"
".\n"
".\n"
"4\n"
"1\n"
"7\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
"5\n"
"3\n"
"6\n"
"7\n"
"4\n"
"1\n"
"5\n"
"3\n"
"4\n"
"1\n"
"5\n"
"1\n"
"6\n"
".\n"
"2\n"
"6\n"
"2\n") == 0);
free(board130726465);
board130726465 = NULL;
assert( gamma_move(board, 1, 0, 115) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 58, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 59, 0) == 0 );
assert( gamma_move(board, 4, 0, 33) == 0 );
assert( gamma_move(board, 5, 148, 0) == 0 );
assert( gamma_move(board, 5, 0, 49) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 7, 0, 73) == 0 );
assert( gamma_move(board, 7, 0, 109) == 1 );
assert( gamma_move(board, 1, 87, 0) == 0 );
assert( gamma_move(board, 1, 0, 127) == 0 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 3, 0, 34) == 1 );
assert( gamma_move(board, 4, 65, 0) == 0 );


gamma_delete(board);

    return 0;
}
