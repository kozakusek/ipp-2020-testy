#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 103334816
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 6, 9, 12);
assert( board != NULL );


assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 2, 13, 0) == 1 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 4, 9, 2) == 1 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 5, 3, 11) == 0 );
assert( gamma_move(board, 5, 10, 0) == 1 );
assert( gamma_free_fields(board, 5) == 94 );
assert( gamma_golden_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 7, 4, 2) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 11, 3) == 1 );
assert( gamma_move(board, 8, 0, 3) == 1 );
assert( gamma_move(board, 9, 5, 3) == 1 );
assert( gamma_free_fields(board, 9) == 90 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 15, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 15, 5) == 1 );
assert( gamma_move(board, 5, 3, 10) == 0 );
assert( gamma_move(board, 5, 12, 0) == 1 );
assert( gamma_move(board, 6, 0, 11) == 0 );


char* board403270500 = gamma_board(board);
assert( board403270500 != NULL );
assert( strcmp(board403270500, 
"..3..1.........4.\n"
"4.......3......2.\n"
"8....9.....8.....\n"
"....7....4.......\n"
"............2....\n"
"..........5.52...\n") == 0);
free(board403270500);
board403270500 = NULL;
assert( gamma_move(board, 7, 8, 2) == 1 );
assert( gamma_move(board, 8, 0, 5) == 1 );
assert( gamma_free_fields(board, 8) == 85 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 0, 14) == 0 );
assert( gamma_move(board, 9, 4, 4) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 4, 12, 5) == 1 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 4 );
assert( gamma_move(board, 5, 3, 15) == 0 );
assert( gamma_move(board, 5, 7, 5) == 1 );
assert( gamma_move(board, 6, 2, 13) == 0 );
assert( gamma_free_fields(board, 6) == 79 );
assert( gamma_move(board, 7, 2, 5) == 0 );
assert( gamma_golden_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 8, 14, 3) == 1 );
assert( gamma_move(board, 9, 4, 14) == 0 );
assert( gamma_move(board, 9, 11, 5) == 1 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 2, 15, 1) == 1 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 4, 2, 4) == 1 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 6, 2, 7) == 0 );
assert( gamma_move(board, 7, 4, 6) == 0 );
assert( gamma_move(board, 7, 15, 3) == 1 );
assert( gamma_golden_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 8, 1, 13) == 0 );
assert( gamma_move(board, 8, 5, 2) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 4, 7) == 0 );
assert( gamma_move(board, 9, 14, 0) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_golden_move(board, 9, 5, 6) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 2, 12, 3) == 1 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 4, 16, 0) == 1 );
assert( gamma_move(board, 5, 9, 0) == 1 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 2, 1) == 1 );
assert( gamma_move(board, 7, 9, 1) == 1 );
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_move(board, 9, 3, 16) == 0 );
assert( gamma_move(board, 9, 11, 5) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 3 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_free_fields(board, 2) == 64 );
assert( gamma_golden_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 4, 16) == 0 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 7, 1, 11) == 0 );
assert( gamma_move(board, 7, 5, 0) == 1 );
assert( gamma_move(board, 8, 1, 1) == 1 );
assert( gamma_move(board, 9, 1, 8) == 0 );
assert( gamma_move(board, 9, 4, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 5, 4, 0) == 1 );
assert( gamma_move(board, 6, 12, 1) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 3, 6) == 0 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_free_fields(board, 7) == 58 );
assert( gamma_move(board, 8, 1, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 6 );
assert( gamma_free_fields(board, 8) == 58 );
assert( gamma_move(board, 9, 9, 4) == 1 );
assert( gamma_move(board, 9, 4, 1) == 0 );
assert( gamma_busy_fields(board, 9) == 6 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_free_fields(board, 1) == 57 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board484773006 = gamma_board(board);
assert( board484773006 != NULL );
assert( strcmp(board484773006, 
"823..1153..94..4.\n"
"4.4.93..39.....2.\n"
"8...99.....82.87.\n"
"....784.74.......\n"
".87.4....7..2..2.\n"
".1.357...55.529.4\n") == 0);
free(board484773006);
board484773006 = NULL;
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_move(board, 4, 7, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 4, 16) == 0 );
assert( gamma_golden_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 6, 6, 0) == 1 );
assert( gamma_move(board, 7, 4, 12) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 12, 4) == 1 );
assert( gamma_move(board, 9, 2, 15) == 0 );
assert( gamma_move(board, 9, 5, 4) == 0 );


char* board802170292 = gamma_board(board);
assert( board802170292 != NULL );
assert( strcmp(board802170292, 
"823..1153..94..4.\n"
"4.4.93..39..8..2.\n"
"8...99.....82.87.\n"
"....784.74.......\n"
".87.4....74.2..2.\n"
".1.35764.55.529.4\n") == 0);
free(board802170292);
board802170292 = NULL;
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 3 );
assert( gamma_golden_move(board, 1, 5, 2) == 1 );


char* board569315895 = gamma_board(board);
assert( board569315895 != NULL );
assert( strcmp(board569315895, 
"823..1153..94..4.\n"
"4.4.93..39..8..2.\n"
"8...99.....82.87.\n"
"....714.74.......\n"
".87.4....74.2..2.\n"
".1.35764.55.529.4\n") == 0);
free(board569315895);
board569315895 = NULL;
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_move(board, 5, 1, 13) == 0 );
assert( gamma_free_fields(board, 5) == 53 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 7, 4, 13) == 0 );
assert( gamma_move(board, 8, 2, 16) == 0 );
assert( gamma_move(board, 8, 1, 2) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 5, 10) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 1, 12, 2) == 1 );
assert( gamma_golden_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_golden_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 5, 9, 3) == 1 );
assert( gamma_move(board, 6, 10, 3) == 1 );
assert( gamma_move(board, 7, 2, 14) == 0 );
assert( gamma_move(board, 8, 3, 3) == 1 );
assert( gamma_move(board, 8, 0, 2) == 1 );
assert( gamma_move(board, 9, 1, 7) == 0 );
assert( gamma_busy_fields(board, 9) == 6 );
assert( gamma_free_fields(board, 9) == 45 );
assert( gamma_golden_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 14, 2) == 1 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 5, 7, 3) == 1 );
assert( gamma_move(board, 6, 4, 11) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 1, 2) == 0 );
assert( gamma_free_fields(board, 7) == 43 );
assert( gamma_move(board, 8, 12, 2) == 0 );
assert( gamma_move(board, 8, 3, 3) == 0 );
assert( gamma_move(board, 9, 9, 3) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_golden_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 2, 16, 4) == 1 );
assert( gamma_move(board, 3, 10, 2) == 1 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 5, 13, 3) == 1 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 6, 0, 15) == 0 );
assert( gamma_move(board, 6, 14, 5) == 1 );
assert( gamma_free_fields(board, 6) == 39 );
assert( gamma_move(board, 7, 15, 5) == 0 );
assert( gamma_move(board, 8, 6, 0) == 0 );
assert( gamma_move(board, 8, 0, 3) == 0 );
assert( gamma_move(board, 9, 3, 6) == 0 );
assert( gamma_busy_fields(board, 9) == 6 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 7 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 2) == 0 );
assert( gamma_move(board, 6, 3, 4) == 1 );
assert( gamma_move(board, 7, 7, 2) == 1 );
assert( gamma_move(board, 8, 4, 10) == 0 );
assert( gamma_move(board, 9, 2, 2) == 1 );
assert( gamma_move(board, 9, 2, 0) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_free_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 9, 1) == 0 );


char* board801001520 = gamma_board(board);
assert( board801001520 != NULL );
assert( strcmp(board801001520, 
"823..1153..94.64.\n"
"4.4693..39..8..22\n"
"82.899.535682587.\n"
"88947147743.1.4..\n"
".87.4....74.2..2.\n"
".1935764.55.529.4\n") == 0);
free(board801001520);
board801001520 = NULL;
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 5, 16, 2) == 1 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_move(board, 8, 0, 11) == 0 );
assert( gamma_free_fields(board, 8) == 33 );


char* board722701113 = gamma_board(board);
assert( board722701113 != NULL );
assert( strcmp(board722701113, 
"823..1153..94.64.\n"
"4.4693..39..8..22\n"
"82.899.535682587.\n"
"88947147743.1.4.5\n"
".87.4....74.2..2.\n"
".1935764.55.529.4\n") == 0);
free(board722701113);
board722701113 = NULL;
assert( gamma_move(board, 9, 4, 11) == 0 );
assert( gamma_move(board, 9, 16, 2) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_golden_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_free_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 5, 16, 4) == 0 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 7, 15, 5) == 0 );
assert( gamma_free_fields(board, 7) == 32 );
assert( gamma_move(board, 9, 1, 5) == 0 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 3, 2) == 0 );
assert( gamma_move(board, 7, 5, 16) == 0 );
assert( gamma_busy_fields(board, 7) == 7 );
assert( gamma_free_fields(board, 7) == 32 );
assert( gamma_move(board, 8, 5, 13) == 0 );
assert( gamma_move(board, 8, 7, 1) == 1 );
assert( gamma_move(board, 9, 5, 16) == 0 );
assert( gamma_free_fields(board, 9) == 31 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board475743785 = gamma_board(board);
assert( board475743785 != NULL );
assert( strcmp(board475743785, 
"823.31153..94.64.\n"
"4.4693..39..8..22\n"
"82.899.535682587.\n"
"88947147743.1.4.5\n"
".87.4..8.74.2..2.\n"
".1935764.552529.4\n") == 0);
free(board475743785);
board475743785 = NULL;
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_golden_move(board, 6, 0, 2) == 1 );
assert( gamma_move(board, 8, 4, 10) == 0 );
assert( gamma_move(board, 8, 10, 3) == 0 );
assert( gamma_move(board, 9, 1, 0) == 0 );
assert( gamma_move(board, 9, 11, 3) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_free_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_free_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 5, 16) == 0 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 3, 0) == 0 );
assert( gamma_free_fields(board, 7) == 30 );
assert( gamma_move(board, 8, 1, 5) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 13, 1) == 1 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 3, 1) == 1 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_move(board, 5, 15, 1) == 0 );
assert( gamma_move(board, 6, 4, 14) == 0 );


char* board893398033 = gamma_board(board);
assert( board893398033 != NULL );
assert( strcmp(board893398033, 
"823.31153..94.64.\n"
"4.4693..39..8..22\n"
"82.899.535682587.\n"
"68947147743.1.4.5\n"
".8724..8.74.29.2.\n"
".1935764.552529.4\n") == 0);
free(board893398033);
board893398033 = NULL;
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_golden_move(board, 8, 0, 16) == 0 );
assert( gamma_move(board, 9, 3, 6) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 5, 14, 4) == 1 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_busy_fields(board, 7) == 7 );
assert( gamma_golden_move(board, 7, 1, 2) == 1 );
assert( gamma_move(board, 8, 4, 7) == 0 );


char* board407773133 = gamma_board(board);
assert( board407773133 != NULL );
assert( strcmp(board407773133, 
"823.31153..94.64.\n"
"4.4693..39..8.522\n"
"82.899.535682587.\n"
"67947147743.1.4.5\n"
".8724..8.74.29.2.\n"
".1935764.552529.4\n") == 0);
free(board407773133);
board407773133 = NULL;
assert( gamma_move(board, 9, 2, 11) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );


char* board270121799 = gamma_board(board);
assert( board270121799 != NULL );
assert( strcmp(board270121799, 
"823.31153..94.64.\n"
"4.4693..39..8.522\n"
"82.899.535682587.\n"
"67947147743.1.4.5\n"
".8724..8.74.29.2.\n"
".1935764.552529.4\n") == 0);
free(board270121799);
board270121799 = NULL;
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_free_fields(board, 5) == 27 );
assert( gamma_move(board, 6, 4, 6) == 0 );
assert( gamma_move(board, 7, 4, 6) == 0 );
assert( gamma_move(board, 8, 2, 11) == 0 );
assert( gamma_move(board, 9, 1, 16) == 0 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_free_fields(board, 2) == 26 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 6, 10, 3) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_golden_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 7, 16, 5) == 1 );
assert( gamma_move(board, 8, 0, 4) == 0 );
assert( gamma_busy_fields(board, 8) == 8 );
assert( gamma_move(board, 9, 0, 15) == 0 );
assert( gamma_move(board, 9, 9, 0) == 0 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_free_fields(board, 2) == 25 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 6, 4, 5) == 0 );
assert( gamma_move(board, 6, 4, 3) == 0 );


gamma_delete(board);

    return 0;
}
