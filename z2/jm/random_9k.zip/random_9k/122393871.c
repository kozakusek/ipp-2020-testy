#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 122393871
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(15, 13, 6, 27);
assert( board != NULL );


assert( gamma_move(board, 1, 11, 7) == 1 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_move(board, 4, 11, 6) == 1 );
assert( gamma_move(board, 5, 2, 6) == 1 );
assert( gamma_move(board, 6, 8, 0) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_free_fields(board, 4) == 184 );
assert( gamma_move(board, 5, 4, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 6, 1, 3) == 1 );
assert( gamma_move(board, 6, 9, 1) == 1 );


char* board327095683 = gamma_board(board);
assert( board327095683 != NULL );
assert( strcmp(board327095683, 
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"..2.2..........\n"
"...........1...\n"
"..5........4...\n"
"...3.....3.....\n"
"......2........\n"
".6...4.........\n"
"....4..........\n"
".........6.....\n"
"....5...6......\n") == 0);
free(board327095683);
board327095683 = NULL;
assert( gamma_move(board, 1, 13, 11) == 1 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 4, 9, 8) == 1 );
assert( gamma_move(board, 5, 3, 6) == 1 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 6, 12, 4) == 1 );
assert( gamma_move(board, 6, 14, 4) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 11, 5) == 1 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 2, 11, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board920989045 = gamma_board(board);
assert( board920989045 != NULL );
assert( strcmp(board920989045, 
"...............\n"
"...1.........1.\n"
"...............\n"
"....3......2...\n"
"..2.2....4.....\n"
"...........1...\n"
"..55.......4...\n"
"...3.....3.1...\n"
"......2.....6.6\n"
".6...4.2.......\n"
"....4..........\n"
".........6.....\n"
"....5...6......\n") == 0);
free(board920989045);
board920989045 = NULL;
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 5, 3, 2) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 6, 9, 10) == 1 );


char* board187096926 = gamma_board(board);
assert( board187096926 != NULL );
assert( strcmp(board187096926, 
"...............\n"
"...1....4....1.\n"
".........6.....\n"
"....3......2...\n"
"..2.2....4.....\n"
"...........1...\n"
"..55.......4...\n"
"...3.3...3.1...\n"
"......2.....6.6\n"
".6...4.2.......\n"
"...54..........\n"
".........6.....\n"
"....5...6......\n") == 0);
free(board187096926);
board187096926 = NULL;
assert( gamma_move(board, 1, 13, 9) == 1 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_move(board, 4, 2, 12) == 1 );
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_move(board, 5, 0, 13) == 0 );
assert( gamma_move(board, 5, 3, 8) == 1 );
assert( gamma_move(board, 6, 12, 6) == 1 );
assert( gamma_free_fields(board, 6) == 162 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_busy_fields(board, 1) == 6 );


char* board561705333 = gamma_board(board);
assert( board561705333 != NULL );
assert( strcmp(board561705333, 
"..4............\n"
"...1....4....1.\n"
".........6.....\n"
"....3......2.1.\n"
"..252....4.....\n"
"1..........1...\n"
"..55.......46..\n"
"...3.3...3.1...\n"
"......2.....6.6\n"
".6...4.2.......\n"
"...54..........\n"
".........64....\n"
"....5...6......\n") == 0);
free(board561705333);
board561705333 = NULL;
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_free_fields(board, 2) == 161 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 4, 4, 6) == 1 );
assert( gamma_move(board, 5, 11, 1) == 1 );
assert( gamma_move(board, 6, 10, 9) == 1 );
assert( gamma_move(board, 6, 12, 8) == 1 );


char* board519606413 = gamma_board(board);
assert( board519606413 != NULL );
assert( strcmp(board519606413, 
"..4............\n"
"...1....4....1.\n"
".........6.....\n"
"....3.....62.1.\n"
"..252....4..6..\n"
"1..........1...\n"
"..554......46..\n"
"...3.3...3.1...\n"
"......2.....6.6\n"
".6...4.2.......\n"
"...54..........\n"
".........645...\n"
"....5...6......\n") == 0);
free(board519606413);
board519606413 = NULL;
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_move(board, 5, 12, 3) == 1 );
assert( gamma_move(board, 6, 1, 6) == 1 );
assert( gamma_move(board, 6, 6, 6) == 1 );
assert( gamma_move(board, 1, 14, 6) == 1 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 3, 10, 10) == 1 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 6, 4, 5) == 1 );
assert( gamma_move(board, 6, 2, 3) == 1 );
assert( gamma_free_fields(board, 6) == 143 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_golden_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 5, 11, 2) == 1 );
assert( gamma_move(board, 5, 13, 6) == 1 );
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 2, 11, 11) == 1 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_free_fields(board, 3) == 132 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 12) == 1 );
assert( gamma_move(board, 4, 13, 0) == 1 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 6, 13, 11) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 2, 4, 1) == 1 );


char* board933231387 = gamma_board(board);
assert( board933231387 != NULL );
assert( strcmp(board933231387, 
".14........4...\n"
"...1.3..4..2.1.\n"
".......3.63....\n"
"..4.3.....62.1.\n"
".3252....4..6..\n"
"1........1.1...\n"
".6554.6..2.4651\n"
"24.3631.1311...\n"
"......21....6.6\n"
".66..4.2....5..\n"
".4.54..4...5...\n"
"2...2....645...\n"
"....5...6....4.\n") == 0);
free(board933231387);
board933231387 = NULL;
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 5, 13, 12) == 1 );
assert( gamma_move(board, 6, 2, 5) == 1 );


char* board342819350 = gamma_board(board);
assert( board342819350 != NULL );
assert( strcmp(board342819350, 
".14........4.5.\n"
".3.1.3..4..2.1.\n"
".......3.63....\n"
"..4.3.....62.1.\n"
".3252....4..6..\n"
"1........1.1...\n"
".6554.6..2.4651\n"
"2463631.1311...\n"
"......21....6.6\n"
".66..4.23...5..\n"
".4.54..4...5...\n"
"2...2....645...\n"
"....5...6....4.\n") == 0);
free(board342819350);
board342819350 = NULL;
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_free_fields(board, 4) == 121 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 6, 12, 5) == 1 );
assert( gamma_move(board, 6, 6, 7) == 1 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 2, 7, 12) == 1 );
assert( gamma_golden_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 4, 11, 3) == 1 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_move(board, 6, 7, 4) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 6, 1, 8) == 0 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 3, 8, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_move(board, 4, 13, 4) == 1 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 14, 5) == 1 );
assert( gamma_move(board, 4, 12, 11) == 1 );
assert( gamma_move(board, 5, 1, 12) == 0 );
assert( gamma_move(board, 5, 4, 4) == 1 );


char* board130366728 = gamma_board(board);
assert( board130366728 != NULL );
assert( strcmp(board130366728, 
".14....2...4.5.\n"
".3.1.3..4..241.\n"
".......3.63....\n"
"4.4.3.....62.1.\n"
".3252....4..6..\n"
"1.....6..141...\n"
".6554.6.22.4651\n"
"2463631.13116.3\n"
"....5.21....646\n"
".66..4.23..45..\n"
".4154..4...5...\n"
"2...2....642...\n"
"3...5.1.6.2..4.\n") == 0);
free(board130366728);
board130366728 = NULL;
assert( gamma_move(board, 6, 6, 8) == 1 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_free_fields(board, 2) == 107 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 5, 12, 11) == 0 );
assert( gamma_move(board, 6, 5, 7) == 1 );
assert( gamma_move(board, 6, 14, 3) == 1 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 14, 2) == 1 );
assert( gamma_move(board, 3, 11, 4) == 1 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 5, 8, 8) == 1 );
assert( gamma_move(board, 6, 3, 4) == 1 );
assert( gamma_move(board, 6, 13, 2) == 1 );
assert( gamma_golden_move(board, 6, 0, 13) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 5, 10, 3) == 1 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 4, 10) == 1 );
assert( gamma_move(board, 1, 9, 2) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 2, 10, 3) == 0 );


char* board280832485 = gamma_board(board);
assert( board280832485 != NULL );
assert( strcmp(board280832485, 
".14....2...4.5.\n"
".3.1.3..4..241.\n"
"....6..3.63....\n"
"4.4.3.....62.1.\n"
".3252.6.54..6..\n"
"1....66..141...\n"
".6554.6.22.4651\n"
"2463631.13116.3\n"
"1..65.21...3646\n"
".66..4.23.545.6\n"
".41541.4.1.5.63\n"
"2...2..4.642...\n"
"3...5.1.6.2..4.\n") == 0);
free(board280832485);
board280832485 = NULL;
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 9, 3) == 1 );
assert( gamma_golden_move(board, 4, 5, 12) == 0 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 6, 10, 12) == 1 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_free_fields(board, 1) == 92 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_move(board, 3, 13, 1) == 1 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 6, 12, 7) == 1 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );


char* board676034417 = gamma_board(board);
assert( board676034417 != NULL );
assert( strcmp(board676034417, 
".14....2..64.5.\n"
".3.1.3..4..241.\n"
"...16..3.63....\n"
"4.4.3.....62.1.\n"
".3252.6.54.26..\n"
"1....66..1416..\n"
".6554.6.2224651\n"
"2463631.13116.3\n"
"1..65.21...3646\n"
"166..4.234545.6\n"
".41541.4.1.5.63\n"
"2...2..4.642.3.\n"
"3...5.1.6.2..4.\n") == 0);
free(board676034417);
board676034417 = NULL;
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 5, 9) == 1 );
assert( gamma_move(board, 6, 11, 9) == 0 );
assert( gamma_move(board, 6, 3, 1) == 1 );
assert( gamma_golden_move(board, 6, 11, 3) == 1 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 1, 14, 1) == 1 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 5, 1, 10) == 1 );
assert( gamma_move(board, 6, 7, 7) == 1 );


char* board723693504 = gamma_board(board);
assert( board723693504 != NULL );
assert( strcmp(board723693504, 
".14....2..64.5.\n"
".3.1.3..4..241.\n"
".5.16..3.63....\n"
"4.4.35....62.1.\n"
".3252.6.54.26..\n"
"1....666.1416..\n"
".6554.6.2224651\n"
"2463631.13116.3\n"
"1..65.21...3646\n"
"166..4.234565.6\n"
".41541.4.1.5.63\n"
"2..62..4.642.31\n"
"3...5.1.6.2..4.\n") == 0);
free(board723693504);
board723693504 = NULL;
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 3, 13) == 0 );
assert( gamma_move(board, 6, 13, 5) == 1 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_free_fields(board, 1) == 80 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 12, 14) == 0 );
assert( gamma_free_fields(board, 3) == 80 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 6, 10, 11) == 1 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_free_fields(board, 6) == 79 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 5, 0, 12) == 1 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 6, 11, 8) == 0 );
assert( gamma_move(board, 1, 8, 7) == 1 );
assert( gamma_free_fields(board, 1) == 76 );
assert( gamma_move(board, 2, 7, 5) == 1 );
assert( gamma_move(board, 3, 10, 2) == 1 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 6, 3, 3) == 1 );
assert( gamma_move(board, 6, 7, 9) == 1 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 8, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board792207474 = gamma_board(board);
assert( board792207474 != NULL );
assert( strcmp(board792207474, 
"514....21.64.5.\n"
".3.1.3..4.6241.\n"
".5.16..3.63....\n"
"4.4.35.6..62.1.\n"
".3252.6.54.26..\n"
"1....66611416..\n"
".6554.6.2224651\n"
"246363121311663\n"
"1..65.21...3646\n"
"1666.4.234565.6\n"
".41541.4.135.63\n"
"2..62..4.642.31\n"
"3..1511.6.2..4.\n") == 0);
free(board792207474);
board792207474 = NULL;
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_golden_move(board, 3, 3, 11) == 1 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 9, 4) == 1 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 6, 10, 8) == 1 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 3, 12, 10) == 1 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 5, 10, 11) == 0 );
assert( gamma_move(board, 6, 9, 12) == 1 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 9, 11) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_busy_fields(board, 6) == 33 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_move(board, 1, 4, 12) == 1 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 5, 14, 8) == 1 );
assert( gamma_move(board, 6, 13, 11) == 0 );
assert( gamma_move(board, 6, 1, 12) == 0 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 8, 4) == 1 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_busy_fields(board, 6) == 34 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_free_fields(board, 4) == 56 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 9) == 1 );
assert( gamma_free_fields(board, 5) == 55 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 6, 1, 0) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_free_fields(board, 5) == 53 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 14, 12) == 1 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 4, 12, 10) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 6, 11, 0) == 0 );
assert( gamma_move(board, 6, 5, 12) == 1 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 3, 3, 12) == 1 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 7, 14) == 0 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_move(board, 5, 13, 12) == 0 );
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_move(board, 6, 3, 12) == 0 );
assert( gamma_free_fields(board, 6) == 48 );


char* board970988253 = gamma_board(board);
assert( board970988253 != NULL );
assert( strcmp(board970988253, 
"514316.21664.52\n"
".3.3.3..446241.\n"
".5616.23.63.3..\n"
"4.4.35.6.562.1.\n"
".325236.54626.5\n"
"14..566611416..\n"
".6554.612224651\n"
"246363121311663\n"
"1..65.2145.3646\n"
"166644.234565.6\n"
"441541.4.135.63\n"
"25.62..4.642.31\n"
"36.1511.6.21.4.\n") == 0);
free(board970988253);
board970988253 = NULL;
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 4, 14, 10) == 1 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_free_fields(board, 1) == 46 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 12) == 0 );
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 3) == 0 );
assert( gamma_move(board, 6, 13, 12) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 2, 14, 7) == 1 );
assert( gamma_golden_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_golden_move(board, 5, 12, 5) == 1 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_golden_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 6, 5, 6) == 1 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 12, 12) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );


char* board198736297 = gamma_board(board);
assert( board198736297 != NULL );
assert( strcmp(board198736297, 
"514316.21664252\n"
"3333.341446241.\n"
".5616.23.63.3.4\n"
"444.35.6.562.1.\n"
"2325236.54626.5\n"
"14..566611416.2\n"
".65546612224651\n"
"246363121311563\n"
"1..65.214513646\n"
"166644.234565.6\n"
"441541.4.135.63\n"
"25.62..4.642.31\n"
"36.151126.21.4.\n") == 0);
free(board198736297);
board198736297 = NULL;
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 6, 6, 3) == 1 );
assert( gamma_golden_move(board, 6, 2, 11) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_free_fields(board, 3) == 35 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 1) == 1 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 11, 14) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 6, 1, 12) == 0 );
assert( gamma_free_fields(board, 6) == 34 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 1, 1) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_move(board, 5, 2, 8) == 0 );
assert( gamma_move(board, 6, 8, 13) == 0 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 30 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 10) == 0 );
assert( gamma_free_fields(board, 5) == 32 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 37 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_golden_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 11, 14) == 0 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 11, 14) == 0 );
assert( gamma_move(board, 2, 13, 10) == 1 );


char* board261971766 = gamma_board(board);
assert( board261971766 != NULL );
assert( strcmp(board261971766, 
"514316.21664252\n"
"3333.341446241.\n"
".5616.23.63.324\n"
"444.35.6.562.1.\n"
"2325236.54626.5\n"
"143.566611416.2\n"
".65516612224651\n"
"246363121311563\n"
"1..65.214513646\n"
"1666446234565.6\n"
"441541.4.135.63\n"
"25.62.441642.31\n"
"36.151126.21.4.\n") == 0);
free(board261971766);
board261971766 = NULL;
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 5, 2, 2) == 0 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 1, 11, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );


char* board224570796 = gamma_board(board);
assert( board224570796 != NULL );
assert( strcmp(board224570796, 
"514316.21664252\n"
"3333.341446241.\n"
".5616.23.63.324\n"
"444.35.6.562.1.\n"
"2325236.54626.5\n"
"143.566611416.2\n"
".65516612224651\n"
"246363121311563\n"
"1..65.214513646\n"
"1666446234565.6\n"
"441541.4.135.63\n"
"25.62.441642.31\n"
"36.151126.21.4.\n") == 0);
free(board224570796);
board224570796 = NULL;
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 3, 12, 0) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_golden_move(board, 4, 1, 3) == 1 );
assert( gamma_move(board, 5, 12, 1) == 1 );
assert( gamma_move(board, 6, 8, 13) == 0 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_move(board, 5, 9, 12) == 0 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_golden_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 4, 5, 10) == 1 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_move(board, 6, 3, 9) == 1 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 4, 2, 4) == 1 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 6, 0, 14) == 0 );
assert( gamma_move(board, 6, 7, 10) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_free_fields(board, 1) == 24 );


char* board927191013 = gamma_board(board);
assert( board927191013 != NULL );
assert( strcmp(board927191013, 
"514316321664252\n"
"3333.341446241.\n"
".5616423.63.324\n"
"444635.6.562.1.\n"
"2325236.54626.5\n"
"143.566611416.2\n"
".65516612224651\n"
"246363121311563\n"
"1.465.214513646\n"
"1466446234565.6\n"
"441541.4.135.63\n"
"25.62.441642531\n"
"363151126.2134.\n") == 0);
free(board927191013);
board927191013 = NULL;
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 3, 0, 6) == 1 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 31 );
assert( gamma_move(board, 5, 11, 14) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 9, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_move(board, 5, 9, 12) == 0 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 6, 9, 12) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_free_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 5, 5, 6) == 0 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 6, 11, 10) == 1 );


char* board698611678 = gamma_board(board);
assert( board698611678 != NULL );
assert( strcmp(board698611678, 
"514316321664252\n"
"3333.341446241.\n"
".5616423.636324\n"
"444635.6.562.1.\n"
"2325236.54626.5\n"
"143.566611416.2\n"
"365516612224651\n"
"246363121311563\n"
"1.465.214513646\n"
"1466446234565.6\n"
"441541.4.135.63\n"
"25.62.441642531\n"
"363151126.2134.\n") == 0);
free(board698611678);
board698611678 = NULL;
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 12) == 0 );
assert( gamma_move(board, 3, 13, 7) == 1 );
assert( gamma_free_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_move(board, 5, 13, 7) == 0 );


char* board301934945 = gamma_board(board);
assert( board301934945 != NULL );
assert( strcmp(board301934945, 
"514316321664252\n"
"3333.341446241.\n"
".5616423.636324\n"
"444635.6.562.1.\n"
"2325236.54626.5\n"
"143.56661141632\n"
"365516612224651\n"
"246363121311563\n"
"1.465.214513646\n"
"1466446234565.6\n"
"441541.4.135.63\n"
"25.62.441642531\n"
"363151126.2134.\n") == 0);
free(board301934945);
board301934945 = NULL;
assert( gamma_move(board, 6, 9, 14) == 0 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_free_fields(board, 6) == 21 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 8, 9) == 1 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );


char* board283111759 = gamma_board(board);
assert( board283111759 != NULL );
assert( strcmp(board283111759, 
"514316321664252\n"
"3333.341446241.\n"
".5616423.636324\n"
"444635.61562.1.\n"
"2325236.54626.5\n"
"143.56661141632\n"
"365516612224651\n"
"246363121311563\n"
"1.465.214513646\n"
"1466446234565.6\n"
"441541.4.135.63\n"
"25.62.441642531\n"
"363151126.2134.\n") == 0);
free(board283111759);
board283111759 = NULL;
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_free_fields(board, 5) == 20 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 11, 14) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_move(board, 6, 13, 8) == 1 );
assert( gamma_free_fields(board, 6) == 19 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 5, 13, 11) == 0 );
assert( gamma_move(board, 5, 1, 10) == 0 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 9, 14) == 0 );


char* board995693513 = gamma_board(board);
assert( board995693513 != NULL );
assert( strcmp(board995693513, 
"514316321664252\n"
"3333.341446241.\n"
".5616423.636324\n"
"444635.61562.1.\n"
"2325236.5462665\n"
"143.56661141632\n"
"365516612224651\n"
"246363121311563\n"
"1.465.214513646\n"
"1466446234565.6\n"
"441541.4.135.63\n"
"25.62.441642531\n"
"363151126.2134.\n") == 0);
free(board995693513);
board995693513 = NULL;
assert( gamma_move(board, 5, 11, 14) == 0 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 6, 3, 13) == 0 );
assert( gamma_move(board, 6, 9, 4) == 0 );


gamma_delete(board);

    return 0;
}
