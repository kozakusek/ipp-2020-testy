#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 109823000
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(3, 100, 3, 94);
assert( board != NULL );


assert( gamma_move(board, 1, 2, 88) == 1 );
assert( gamma_move(board, 1, 1, 50) == 1 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_free_fields(board, 1) == 298 );
assert( gamma_move(board, 2, 83, 0) == 0 );
assert( gamma_move(board, 3, 21, 2) == 0 );
assert( gamma_move(board, 1, 69, 1) == 0 );
assert( gamma_move(board, 2, 42, 1) == 0 );
assert( gamma_move(board, 3, 69, 2) == 0 );
assert( gamma_move(board, 3, 2, 98) == 1 );
assert( gamma_move(board, 1, 2, 88) == 0 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_move(board, 2, 29, 2) == 0 );
assert( gamma_move(board, 3, 39, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 1 );
assert( gamma_move(board, 1, 65, 0) == 0 );
assert( gamma_move(board, 1, 2, 59) == 1 );
assert( gamma_busy_fields(board, 1) == 4 );
assert( gamma_golden_move(board, 1, 98, 2) == 0 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_free_fields(board, 2) == 294 );
assert( gamma_move(board, 3, 0, 41) == 1 );
assert( gamma_move(board, 1, 48, 1) == 0 );
assert( gamma_move(board, 2, 46, 1) == 0 );
assert( gamma_move(board, 3, 48, 0) == 0 );
assert( gamma_move(board, 3, 0, 26) == 1 );
assert( gamma_move(board, 1, 94, 2) == 0 );
assert( gamma_move(board, 2, 2, 44) == 1 );
assert( gamma_move(board, 3, 90, 1) == 0 );
assert( gamma_move(board, 3, 2, 93) == 1 );
assert( gamma_free_fields(board, 3) == 290 );


char* board259840167 = gamma_board(board);
assert( board259840167 != NULL );
assert( strcmp(board259840167, 
"...\n"
"..3\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..3\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n") == 0);
free(board259840167);
board259840167 = NULL;
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 1, 6) == 1 );
assert( gamma_free_fields(board, 1) == 289 );
assert( gamma_move(board, 2, 90, 2) == 0 );
assert( gamma_move(board, 2, 1, 92) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 62, 0) == 0 );
assert( gamma_move(board, 1, 79, 0) == 0 );
assert( gamma_move(board, 1, 2, 26) == 1 );
assert( gamma_move(board, 2, 59, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_move(board, 3, 0, 98) == 1 );
assert( gamma_move(board, 3, 2, 68) == 1 );
assert( gamma_move(board, 1, 2, 93) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_move(board, 2, 0, 42) == 1 );
assert( gamma_move(board, 3, 53, 1) == 0 );
assert( gamma_move(board, 1, 54, 2) == 0 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 47, 2) == 0 );
assert( gamma_golden_move(board, 3, 92, 1) == 0 );
assert( gamma_move(board, 1, 0, 94) == 1 );
assert( gamma_move(board, 2, 1, 89) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 72, 2) == 0 );
assert( gamma_move(board, 1, 55, 2) == 0 );
assert( gamma_move(board, 1, 2, 15) == 1 );
assert( gamma_move(board, 2, 27, 2) == 0 );
assert( gamma_free_fields(board, 2) == 279 );
assert( gamma_move(board, 3, 44, 1) == 0 );
assert( gamma_free_fields(board, 3) == 279 );
assert( gamma_move(board, 1, 0, 82) == 1 );
assert( gamma_move(board, 2, 22, 1) == 0 );
assert( gamma_move(board, 2, 1, 48) == 1 );
assert( gamma_move(board, 3, 1, 96) == 1 );
assert( gamma_move(board, 2, 96, 2) == 0 );
assert( gamma_move(board, 3, 1, 69) == 1 );
assert( gamma_move(board, 3, 0, 65) == 1 );
assert( gamma_move(board, 1, 1, 36) == 1 );
assert( gamma_move(board, 2, 1, 36) == 0 );
assert( gamma_move(board, 3, 19, 0) == 0 );
assert( gamma_move(board, 3, 0, 41) == 0 );
assert( gamma_move(board, 1, 1, 80) == 1 );
assert( gamma_move(board, 1, 1, 87) == 1 );
assert( gamma_move(board, 2, 53, 2) == 0 );
assert( gamma_move(board, 2, 1, 7) == 1 );


char* board173244114 = gamma_board(board);
assert( board173244114 != NULL );
assert( strcmp(board173244114, 
"...\n"
"3.3\n"
"...\n"
".3.\n"
"...\n"
"1..\n"
"..3\n"
".2.\n"
"...\n"
"...\n"
".2.\n"
"..1\n"
".1.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
".1.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".3.\n"
"..3\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"2..\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3.1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"..3\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".2.\n"
"11.\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board173244114);
board173244114 = NULL;
assert( gamma_move(board, 3, 35, 2) == 0 );
assert( gamma_move(board, 3, 1, 85) == 1 );
assert( gamma_golden_move(board, 3, 0, 0) == 1 );
assert( gamma_golden_move(board, 2, 85, 1) == 0 );
assert( gamma_move(board, 3, 27, 1) == 0 );
assert( gamma_move(board, 3, 2, 86) == 1 );
assert( gamma_move(board, 1, 0, 54) == 1 );
assert( gamma_move(board, 1, 0, 50) == 1 );
assert( gamma_move(board, 2, 2, 10) == 1 );
assert( gamma_move(board, 3, 1, 79) == 1 );
assert( gamma_move(board, 3, 2, 28) == 1 );
assert( gamma_move(board, 1, 55, 0) == 0 );
assert( gamma_move(board, 2, 57, 2) == 0 );
assert( gamma_move(board, 2, 0, 89) == 1 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 1, 0, 74) == 1 );
assert( gamma_move(board, 1, 1, 27) == 1 );
assert( gamma_free_fields(board, 1) == 260 );
assert( gamma_move(board, 2, 1, 94) == 1 );
assert( gamma_move(board, 3, 1, 43) == 1 );
assert( gamma_move(board, 1, 76, 2) == 0 );
assert( gamma_move(board, 1, 2, 91) == 1 );
assert( gamma_move(board, 2, 1, 27) == 0 );
assert( gamma_move(board, 3, 79, 0) == 0 );
assert( gamma_move(board, 1, 2, 54) == 1 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 2, 41, 2) == 0 );
assert( gamma_move(board, 2, 2, 35) == 1 );
assert( gamma_move(board, 3, 22, 0) == 0 );
assert( gamma_move(board, 1, 1, 34) == 1 );
assert( gamma_move(board, 2, 59, 1) == 0 );
assert( gamma_move(board, 2, 1, 58) == 1 );
assert( gamma_golden_move(board, 2, 43, 1) == 0 );
assert( gamma_move(board, 3, 78, 1) == 0 );
assert( gamma_move(board, 3, 0, 84) == 1 );
assert( gamma_move(board, 1, 70, 2) == 0 );
assert( gamma_move(board, 1, 2, 64) == 1 );
assert( gamma_move(board, 2, 56, 2) == 0 );
assert( gamma_golden_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 39, 1) == 0 );
assert( gamma_move(board, 3, 2, 96) == 1 );
assert( gamma_move(board, 1, 2, 33) == 1 );
assert( gamma_move(board, 1, 0, 55) == 1 );
assert( gamma_move(board, 2, 28, 1) == 0 );
assert( gamma_move(board, 2, 0, 98) == 0 );
assert( gamma_move(board, 3, 55, 1) == 0 );
assert( gamma_move(board, 3, 1, 42) == 1 );
assert( gamma_move(board, 1, 76, 1) == 0 );
assert( gamma_move(board, 2, 0, 97) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 3, 1, 67) == 1 );


char* board457310453 = gamma_board(board);
assert( board457310453 != NULL );
assert( strcmp(board457310453, 
"...\n"
"3.3\n"
"2..\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".2.\n"
"..1\n"
"...\n"
"22.\n"
"..1\n"
".1.\n"
"..3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
"...\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".3.\n"
"..3\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
".2.\n"
"...\n"
"...\n"
"1..\n"
"1.1\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"...\n"
"..2\n"
".3.\n"
"23.\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".1.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..3\n"
".1.\n"
"3.1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"..3\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".2.\n"
"11.\n"
"..1\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board457310453);
board457310453 = NULL;
assert( gamma_move(board, 1, 1, 39) == 1 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 1, 1, 68) == 1 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 54) == 1 );
assert( gamma_move(board, 3, 2, 25) == 1 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 50, 0) == 0 );
assert( gamma_move(board, 1, 51, 1) == 0 );
assert( gamma_move(board, 2, 0, 17) == 1 );
assert( gamma_move(board, 2, 0, 46) == 1 );
assert( gamma_move(board, 3, 64, 0) == 0 );
assert( gamma_move(board, 3, 1, 81) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_free_fields(board, 1) == 236 );
assert( gamma_move(board, 2, 0, 40) == 1 );
assert( gamma_move(board, 2, 2, 72) == 1 );
assert( gamma_move(board, 3, 1, 87) == 0 );
assert( gamma_move(board, 3, 2, 49) == 1 );
assert( gamma_golden_move(board, 3, 94, 0) == 0 );
assert( gamma_move(board, 1, 61, 1) == 0 );
assert( gamma_move(board, 1, 2, 63) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 2, 24) == 1 );


char* board600098070 = gamma_board(board);
assert( board600098070 != NULL );
assert( strcmp(board600098070, 
"...\n"
"3.3\n"
"2..\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".2.\n"
"..1\n"
"...\n"
"22.\n"
"..1\n"
".1.\n"
"..3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"..1\n"
".2.\n"
"...\n"
"...\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"..3\n"
".2.\n"
"...\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"23.\n"
"3..\n"
"2..\n"
".1.\n"
"...\n"
"...\n"
".1.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..3\n"
".1.\n"
"3.1\n"
"..3\n"
"..2\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"..1\n"
"...\n"
"1.3\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".2.\n"
"11.\n"
"..1\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board600098070);
board600098070 = NULL;
assert( gamma_move(board, 3, 52, 1) == 0 );
assert( gamma_move(board, 3, 2, 58) == 1 );
assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_move(board, 2, 32, 2) == 0 );
assert( gamma_move(board, 2, 1, 13) == 1 );
assert( gamma_move(board, 3, 40, 2) == 0 );
assert( gamma_move(board, 1, 91, 0) == 0 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_free_fields(board, 1) == 228 );
assert( gamma_golden_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 77, 1) == 0 );
assert( gamma_move(board, 2, 2, 22) == 1 );


char* board778613399 = gamma_board(board);
assert( board778613399 != NULL );
assert( strcmp(board778613399, 
"...\n"
"3.3\n"
"2..\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".2.\n"
"..1\n"
"...\n"
"22.\n"
"..1\n"
".1.\n"
"..3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"..1\n"
".23\n"
"...\n"
"...\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"..3\n"
".2.\n"
"...\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"23.\n"
"3..\n"
"2..\n"
".1.\n"
"...\n"
"...\n"
".1.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..3\n"
".1.\n"
"3.1\n"
"..3\n"
"..2\n"
"...\n"
"..2\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"..1\n"
"...\n"
"123\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".21\n"
"11.\n"
"..1\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board778613399);
board778613399 = NULL;
assert( gamma_move(board, 3, 25, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 1, 6, 2) == 0 );


char* board608285991 = gamma_board(board);
assert( board608285991 != NULL );
assert( strcmp(board608285991, 
"...\n"
"3.3\n"
"2..\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".2.\n"
"..1\n"
"...\n"
"22.\n"
"..1\n"
".1.\n"
"..3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"..1\n"
".23\n"
"...\n"
"...\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"...\n"
"11.\n"
"..3\n"
".2.\n"
"...\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"23.\n"
"3..\n"
"2..\n"
".1.\n"
"...\n"
"...\n"
".1.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..3\n"
".1.\n"
"3.1\n"
"..3\n"
"..2\n"
"...\n"
"..2\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"..1\n"
"...\n"
"123\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".21\n"
"11.\n"
"..1\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board608285991);
board608285991 = NULL;
assert( gamma_move(board, 2, 1, 51) == 1 );
assert( gamma_move(board, 2, 1, 80) == 0 );
assert( gamma_move(board, 3, 61, 2) == 0 );
assert( gamma_move(board, 1, 74, 1) == 0 );
assert( gamma_move(board, 1, 2, 42) == 1 );
assert( gamma_move(board, 2, 1, 43) == 0 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_golden_move(board, 2, 54, 0) == 0 );
assert( gamma_move(board, 3, 1, 38) == 1 );


char* board808419889 = gamma_board(board);
assert( board808419889 != NULL );
assert( strcmp(board808419889, 
"...\n"
"3.3\n"
"2..\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".2.\n"
"..1\n"
"...\n"
"22.\n"
"..1\n"
".1.\n"
"..3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"..1\n"
".23\n"
"...\n"
"...\n"
"1..\n"
"131\n"
"...\n"
"...\n"
".2.\n"
"11.\n"
"..3\n"
".2.\n"
"...\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
".1.\n"
".3.\n"
"...\n"
".1.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..3\n"
".1.\n"
"3.1\n"
"..3\n"
"..2\n"
"...\n"
"..2\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"..1\n"
"...\n"
"123\n"
"..2\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".21\n"
"11.\n"
"..1\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board808419889);
board808419889 = NULL;
assert( gamma_move(board, 1, 0, 51) == 1 );
assert( gamma_move(board, 1, 0, 75) == 1 );
assert( gamma_golden_move(board, 1, 86, 2) == 0 );
assert( gamma_move(board, 2, 2, 50) == 1 );
assert( gamma_move(board, 3, 20, 0) == 0 );
assert( gamma_move(board, 1, 2, 21) == 1 );
assert( gamma_move(board, 1, 2, 97) == 1 );
assert( gamma_busy_fields(board, 1) == 34 );
assert( gamma_free_fields(board, 1) == 218 );
assert( gamma_move(board, 2, 0, 39) == 1 );
assert( gamma_move(board, 3, 74, 1) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 1, 40, 1) == 0 );
assert( gamma_golden_move(board, 1, 58, 2) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 64, 1) == 0 );
assert( gamma_move(board, 3, 1, 18) == 1 );
assert( gamma_move(board, 1, 2, 42) == 0 );
assert( gamma_move(board, 2, 1, 34) == 0 );
assert( gamma_move(board, 3, 87, 2) == 0 );
assert( gamma_move(board, 1, 95, 1) == 0 );
assert( gamma_move(board, 1, 1, 15) == 1 );
assert( gamma_move(board, 2, 66, 1) == 0 );
assert( gamma_move(board, 2, 0, 37) == 1 );
assert( gamma_golden_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 1, 38, 2) == 0 );
assert( gamma_move(board, 1, 2, 93) == 0 );
assert( gamma_move(board, 2, 21, 1) == 0 );
assert( gamma_move(board, 2, 2, 88) == 0 );
assert( gamma_move(board, 3, 1, 25) == 1 );
assert( gamma_move(board, 3, 1, 11) == 1 );


char* board159108441 = gamma_board(board);
assert( board159108441 != NULL );
assert( strcmp(board159108441, 
"...\n"
"3.3\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".2.\n"
"..1\n"
"...\n"
"22.\n"
"..1\n"
".1.\n"
"..3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"...\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"..1\n"
".23\n"
"...\n"
"...\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"12.\n"
"112\n"
"..3\n"
".2.\n"
"...\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
"21.\n"
".3.\n"
"2..\n"
".1.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..3\n"
".1.\n"
"3.1\n"
".33\n"
"..2\n"
"...\n"
"..2\n"
"..1\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
".11\n"
"...\n"
"123\n"
"..2\n"
".3.\n"
"..2\n"
"...\n"
".3.\n"
".21\n"
"11.\n"
"..1\n"
"..2\n"
"...\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board159108441);
board159108441 = NULL;
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 2, 1, 81) == 0 );
assert( gamma_move(board, 2, 2, 73) == 1 );
assert( gamma_move(board, 3, 81, 0) == 0 );
assert( gamma_move(board, 3, 2, 56) == 1 );
assert( gamma_move(board, 1, 48, 2) == 0 );
assert( gamma_move(board, 2, 52, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 0, 27) == 1 );


char* board465057596 = gamma_board(board);
assert( board465057596 != NULL );
assert( strcmp(board465057596, 
"...\n"
"3.3\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".2.\n"
"..1\n"
"...\n"
"22.\n"
"..1\n"
".1.\n"
"..3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..2\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"..1\n"
".23\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"12.\n"
"112\n"
"..3\n"
".2.\n"
"...\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
"21.\n"
".3.\n"
"2..\n"
".1.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..3\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"...\n"
"..2\n"
"..1\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
".11\n"
"...\n"
"123\n"
"..2\n"
".3.\n"
"..2\n"
"...\n"
".3.\n"
".21\n"
"11.\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board465057596);
board465057596 = NULL;
assert( gamma_move(board, 1, 18, 0) == 0 );
assert( gamma_free_fields(board, 1) == 206 );
assert( gamma_golden_move(board, 1, 68, 2) == 0 );
assert( gamma_move(board, 3, 2, 33) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 1, 57, 2) == 0 );
assert( gamma_move(board, 1, 0, 28) == 1 );
assert( gamma_move(board, 2, 23, 2) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 1, 2, 26) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_golden_move(board, 1, 96, 1) == 0 );
assert( gamma_move(board, 2, 2, 75) == 1 );
assert( gamma_move(board, 2, 2, 61) == 1 );
assert( gamma_golden_move(board, 2, 68, 2) == 0 );
assert( gamma_move(board, 3, 22, 0) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 2, 66, 1) == 0 );
assert( gamma_move(board, 2, 1, 42) == 0 );
assert( gamma_move(board, 3, 1, 39) == 0 );
assert( gamma_move(board, 3, 0, 60) == 1 );
assert( gamma_move(board, 1, 31, 1) == 0 );
assert( gamma_move(board, 2, 34, 0) == 0 );
assert( gamma_move(board, 3, 1, 23) == 1 );
assert( gamma_move(board, 3, 2, 30) == 1 );
assert( gamma_move(board, 1, 1, 94) == 0 );
assert( gamma_move(board, 2, 47, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 57, 1) == 0 );
assert( gamma_move(board, 3, 0, 36) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 78, 0) == 0 );
assert( gamma_move(board, 1, 0, 97) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 2, 98) == 0 );
assert( gamma_move(board, 2, 1, 88) == 1 );
assert( gamma_golden_move(board, 2, 98, 0) == 0 );
assert( gamma_move(board, 3, 69, 0) == 0 );
assert( gamma_free_fields(board, 3) == 197 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_move(board, 2, 47, 2) == 0 );
assert( gamma_move(board, 2, 1, 89) == 0 );
assert( gamma_busy_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 2, 92) == 1 );
assert( gamma_free_fields(board, 3) == 195 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 29, 1) == 0 );
assert( gamma_move(board, 2, 2, 21) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 1, 1, 89) == 0 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 46) == 0 );
assert( gamma_move(board, 2, 1, 73) == 1 );


char* board378918651 = gamma_board(board);
assert( board378918651 != NULL );
assert( strcmp(board378918651, 
"...\n"
"3.3\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".23\n"
"..1\n"
"...\n"
"22.\n"
".21\n"
".1.\n"
"..3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"..2\n"
"3..\n"
"..1\n"
".23\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"12.\n"
"112\n"
"..3\n"
".2.\n"
"...\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
"21.\n"
".3.\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"..3\n"
"...\n"
"1.3\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
".3.\n"
"..2\n"
"..1\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
".11\n"
"...\n"
"123\n"
".12\n"
".3.\n"
".12\n"
"...\n"
".3.\n"
".21\n"
"11.\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"...\n"
"2..\n") == 0);
free(board378918651);
board378918651 = NULL;
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 3, 0, 51) == 0 );
assert( gamma_move(board, 1, 38, 2) == 0 );
assert( gamma_move(board, 1, 0, 23) == 1 );
assert( gamma_move(board, 2, 0, 28) == 0 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 1, 1, 28) == 1 );
assert( gamma_move(board, 2, 29, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_free_fields(board, 2) == 191 );
assert( gamma_move(board, 3, 66, 2) == 0 );
assert( gamma_move(board, 3, 2, 47) == 1 );
assert( gamma_move(board, 2, 0, 86) == 1 );
assert( gamma_move(board, 3, 2, 88) == 0 );
assert( gamma_move(board, 3, 2, 21) == 0 );


char* board793117372 = gamma_board(board);
assert( board793117372 != NULL );
assert( strcmp(board793117372, 
"...\n"
"3.3\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".23\n"
"..1\n"
"...\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
".3.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"..2\n"
"3..\n"
"..1\n"
".23\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"12.\n"
"112\n"
"..3\n"
".2.\n"
"..3\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
"21.\n"
".3.\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"..3\n"
"...\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"..1\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
".11\n"
"...\n"
"123\n"
".12\n"
".3.\n"
".12\n"
"...\n"
".3.\n"
".21\n"
"11.\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"..3\n"
"2..\n") == 0);
free(board793117372);
board793117372 = NULL;
assert( gamma_move(board, 1, 0, 55) == 0 );
assert( gamma_move(board, 1, 1, 98) == 1 );
assert( gamma_move(board, 2, 1, 90) == 1 );
assert( gamma_move(board, 2, 2, 33) == 0 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 48, 2) == 0 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_move(board, 1, 0, 65) == 0 );
assert( gamma_move(board, 1, 0, 67) == 1 );
assert( gamma_move(board, 2, 74, 2) == 0 );
assert( gamma_move(board, 3, 72, 1) == 0 );
assert( gamma_free_fields(board, 3) == 185 );
assert( gamma_move(board, 1, 1, 42) == 0 );
assert( gamma_move(board, 2, 85, 0) == 0 );
assert( gamma_move(board, 1, 1, 78) == 1 );


char* board974457913 = gamma_board(board);
assert( board974457913 != NULL );
assert( strcmp(board974457913, 
"...\n"
"313\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".23\n"
"..1\n"
".2.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
".1.\n"
"...\n"
"...\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
"13.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"..2\n"
"3..\n"
"..1\n"
".23\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"12.\n"
"112\n"
"..3\n"
".2.\n"
"..3\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
"21.\n"
".3.\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"..3\n"
"...\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"..1\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
".11\n"
"..3\n"
"123\n"
".12\n"
".3.\n"
".12\n"
"...\n"
".3.\n"
".21\n"
"11.\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"..3\n"
"2..\n") == 0);
free(board974457913);
board974457913 = NULL;
assert( gamma_move(board, 2, 72, 0) == 0 );
assert( gamma_move(board, 3, 57, 2) == 0 );
assert( gamma_move(board, 3, 2, 44) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 40, 2) == 0 );
assert( gamma_move(board, 2, 2, 47) == 0 );
assert( gamma_move(board, 3, 0, 27) == 0 );


char* board924664652 = gamma_board(board);
assert( board924664652 != NULL );
assert( strcmp(board924664652, 
"...\n"
"313\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".23\n"
"..1\n"
".2.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"3..\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
".1.\n"
"...\n"
"...\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
"13.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"..2\n"
"3..\n"
"..1\n"
".23\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"12.\n"
"112\n"
"..3\n"
".2.\n"
"..3\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
"21.\n"
".3.\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"..3\n"
"...\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"..1\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
".11\n"
"..3\n"
"123\n"
".12\n"
".3.\n"
".12\n"
"...\n"
".3.\n"
".21\n"
"11.\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"..3\n"
"2..\n") == 0);
free(board924664652);
board924664652 = NULL;
assert( gamma_move(board, 1, 94, 2) == 0 );
assert( gamma_move(board, 2, 48, 2) == 0 );
assert( gamma_free_fields(board, 2) == 184 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 48, 2) == 0 );
assert( gamma_move(board, 3, 0, 77) == 1 );
assert( gamma_move(board, 1, 72, 0) == 0 );
assert( gamma_move(board, 1, 2, 61) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_golden_move(board, 1, 86, 2) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 40 );
assert( gamma_move(board, 1, 53, 1) == 0 );
assert( gamma_move(board, 3, 1, 84) == 1 );
assert( gamma_move(board, 3, 0, 50) == 0 );
assert( gamma_move(board, 1, 0, 58) == 1 );
assert( gamma_free_fields(board, 1) == 181 );
assert( gamma_move(board, 2, 79, 0) == 0 );
assert( gamma_move(board, 3, 1, 47) == 1 );
assert( gamma_free_fields(board, 3) == 180 );


char* board566097257 = gamma_board(board);
assert( board566097257 != NULL );
assert( strcmp(board566097257, 
"...\n"
"313\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".23\n"
"..1\n"
".2.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"33.\n"
"...\n"
"1..\n"
".3.\n"
".1.\n"
".3.\n"
".1.\n"
"3..\n"
"...\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
"13.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"..2\n"
"3..\n"
"..1\n"
"123\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
"...\n"
"12.\n"
"112\n"
"..3\n"
".2.\n"
".33\n"
"2..\n"
"...\n"
"..2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
"21.\n"
".3.\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"..3\n"
"...\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"..1\n"
"...\n"
"...\n"
".3.\n"
"2..\n"
"...\n"
".11\n"
"..3\n"
"123\n"
".12\n"
".3.\n"
".12\n"
"...\n"
".3.\n"
".21\n"
"11.\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"..3\n"
"2..\n") == 0);
free(board566097257);
board566097257 = NULL;
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_golden_move(board, 1, 73, 1) == 0 );
assert( gamma_move(board, 2, 51, 2) == 0 );
assert( gamma_move(board, 2, 2, 45) == 1 );
assert( gamma_move(board, 3, 66, 1) == 0 );
assert( gamma_move(board, 1, 0, 81) == 1 );
assert( gamma_move(board, 2, 1, 52) == 1 );
assert( gamma_move(board, 2, 2, 18) == 1 );
assert( gamma_move(board, 3, 2, 75) == 0 );
assert( gamma_move(board, 3, 2, 49) == 0 );
assert( gamma_golden_move(board, 3, 68, 1) == 0 );
assert( gamma_move(board, 1, 0, 44) == 1 );


char* board231793566 = gamma_board(board);
assert( board231793566 != NULL );
assert( strcmp(board231793566, 
"...\n"
"313\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".23\n"
"..1\n"
".2.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"33.\n"
"...\n"
"1..\n"
"13.\n"
".1.\n"
".3.\n"
".1.\n"
"3..\n"
"...\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"...\n"
"...\n"
".3.\n"
".13\n"
"13.\n"
"...\n"
"3..\n"
"..1\n"
"..1\n"
"...\n"
"..2\n"
"3..\n"
"..1\n"
"123\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
".2.\n"
"12.\n"
"112\n"
"..3\n"
".2.\n"
".33\n"
"2..\n"
"..2\n"
"1.2\n"
".3.\n"
"231\n"
"3..\n"
"2..\n"
"21.\n"
".3.\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"..3\n"
"...\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"..1\n"
"...\n"
"...\n"
".32\n"
"2..\n"
"...\n"
".11\n"
"..3\n"
"123\n"
".12\n"
".3.\n"
".12\n"
"...\n"
".3.\n"
".21\n"
"11.\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"..3\n"
"2..\n") == 0);
free(board231793566);
board231793566 = NULL;
assert( gamma_move(board, 2, 46, 1) == 0 );
assert( gamma_move(board, 3, 74, 1) == 0 );
assert( gamma_move(board, 1, 82, 1) == 0 );
assert( gamma_move(board, 2, 0, 41) == 0 );
assert( gamma_move(board, 3, 75, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 32, 1) == 0 );
assert( gamma_free_fields(board, 1) == 175 );
assert( gamma_move(board, 2, 49, 0) == 0 );
assert( gamma_move(board, 2, 1, 61) == 1 );
assert( gamma_free_fields(board, 2) == 174 );
assert( gamma_busy_fields(board, 3) == 42 );
assert( gamma_move(board, 1, 1, 71) == 1 );
assert( gamma_golden_move(board, 1, 61, 1) == 0 );
assert( gamma_move(board, 2, 20, 1) == 0 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 57, 1) == 0 );
assert( gamma_move(board, 3, 0, 58) == 0 );
assert( gamma_move(board, 1, 48, 2) == 0 );
assert( gamma_move(board, 2, 41, 1) == 0 );
assert( gamma_move(board, 3, 1, 28) == 0 );
assert( gamma_move(board, 3, 0, 42) == 0 );
assert( gamma_move(board, 1, 34, 2) == 0 );
assert( gamma_move(board, 2, 1, 41) == 1 );
assert( gamma_move(board, 2, 0, 28) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 20, 0) == 0 );
assert( gamma_move(board, 1, 2, 54) == 0 );
assert( gamma_busy_fields(board, 1) == 48 );
assert( gamma_move(board, 2, 88, 0) == 0 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 40 );
assert( gamma_move(board, 3, 95, 0) == 0 );
assert( gamma_move(board, 3, 0, 71) == 1 );
assert( gamma_move(board, 1, 24, 1) == 0 );
assert( gamma_move(board, 3, 20, 0) == 0 );
assert( gamma_move(board, 1, 93, 0) == 0 );
assert( gamma_move(board, 1, 0, 21) == 1 );
assert( gamma_move(board, 2, 17, 2) == 0 );
assert( gamma_move(board, 2, 1, 85) == 0 );
assert( gamma_move(board, 3, 59, 0) == 0 );
assert( gamma_move(board, 1, 53, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 49 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 70, 0) == 0 );
assert( gamma_move(board, 3, 0, 15) == 1 );
assert( gamma_move(board, 3, 2, 51) == 1 );
assert( gamma_move(board, 1, 2, 39) == 1 );
assert( gamma_move(board, 1, 2, 81) == 1 );
assert( gamma_move(board, 2, 2, 98) == 0 );
assert( gamma_move(board, 3, 2, 29) == 1 );
assert( gamma_free_fields(board, 3) == 163 );
assert( gamma_move(board, 1, 40, 1) == 0 );
assert( gamma_move(board, 1, 1, 76) == 1 );
assert( gamma_free_fields(board, 1) == 162 );
assert( gamma_move(board, 2, 32, 1) == 0 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 1, 83) == 1 );
assert( gamma_move(board, 2, 31, 2) == 0 );
assert( gamma_move(board, 2, 0, 64) == 1 );


char* board432810158 = gamma_board(board);
assert( board432810158 != NULL );
assert( strcmp(board432810158, 
"...\n"
"313\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".23\n"
"..1\n"
".2.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"33.\n"
".1.\n"
"1..\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"3..\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"31.\n"
"...\n"
".3.\n"
".13\n"
"13.\n"
"...\n"
"3..\n"
"2.1\n"
"..1\n"
"...\n"
".22\n"
"3..\n"
"..1\n"
"123\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"..3\n"
".2.\n"
".33\n"
"2..\n"
"..2\n"
"1.2\n"
".3.\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
".3.\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"..3\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
"...\n"
"...\n"
".32\n"
"2..\n"
"...\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
".12\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"..3\n"
"2..\n") == 0);
free(board432810158);
board432810158 = NULL;
assert( gamma_move(board, 3, 0, 43) == 1 );


char* board627285025 = gamma_board(board);
assert( board627285025 != NULL );
assert( strcmp(board627285025, 
"...\n"
"313\n"
"2.1\n"
".33\n"
"...\n"
"12.\n"
"..3\n"
".23\n"
"..1\n"
".2.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"33.\n"
".1.\n"
"1..\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"3..\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"31.\n"
"...\n"
".3.\n"
".13\n"
"13.\n"
"...\n"
"3..\n"
"2.1\n"
"..1\n"
"...\n"
".22\n"
"3..\n"
"..1\n"
"123\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"..3\n"
".2.\n"
".33\n"
"2..\n"
"..2\n"
"1.2\n"
"33.\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
".3.\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
"..1\n"
"...\n"
"...\n"
"..3\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
"...\n"
"...\n"
".32\n"
"2..\n"
"...\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
".12\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
"..3\n"
"2..\n") == 0);
free(board627285025);
board627285025 = NULL;
assert( gamma_move(board, 1, 1, 16) == 1 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 1, 50) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 1, 32, 2) == 0 );
assert( gamma_move(board, 1, 1, 91) == 1 );
assert( gamma_free_fields(board, 1) == 155 );
assert( gamma_move(board, 2, 1, 63) == 1 );
assert( gamma_move(board, 3, 33, 0) == 0 );
assert( gamma_move(board, 1, 80, 2) == 0 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 2, 0, 67) == 0 );
assert( gamma_move(board, 3, 49, 0) == 0 );
assert( gamma_move(board, 3, 2, 26) == 0 );
assert( gamma_move(board, 1, 21, 1) == 0 );
assert( gamma_move(board, 1, 1, 84) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 1, 43) == 0 );
assert( gamma_move(board, 3, 32, 0) == 0 );
assert( gamma_move(board, 1, 1, 64) == 1 );
assert( gamma_move(board, 1, 2, 66) == 1 );
assert( gamma_busy_fields(board, 1) == 58 );
assert( gamma_move(board, 2, 77, 1) == 0 );
assert( gamma_move(board, 2, 2, 43) == 1 );
assert( gamma_move(board, 3, 59, 1) == 0 );
assert( gamma_move(board, 3, 1, 47) == 0 );
assert( gamma_move(board, 1, 1, 33) == 1 );
assert( gamma_move(board, 2, 1, 95) == 1 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 1, 0, 97) == 0 );
assert( gamma_move(board, 2, 0, 90) == 1 );
assert( gamma_move(board, 2, 2, 38) == 1 );
assert( gamma_move(board, 3, 92, 0) == 0 );
assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_move(board, 1, 0, 71) == 0 );
assert( gamma_move(board, 2, 99, 2) == 0 );
assert( gamma_move(board, 2, 0, 38) == 1 );
assert( gamma_busy_fields(board, 2) == 47 );
assert( gamma_move(board, 3, 34, 0) == 0 );
assert( gamma_move(board, 3, 0, 92) == 1 );
assert( gamma_move(board, 1, 57, 0) == 0 );
assert( gamma_move(board, 1, 0, 84) == 0 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 99, 2) == 0 );
assert( gamma_move(board, 3, 0, 16) == 1 );
assert( gamma_move(board, 1, 2, 70) == 1 );
assert( gamma_move(board, 1, 1, 30) == 1 );
assert( gamma_move(board, 2, 57, 1) == 0 );
assert( gamma_move(board, 2, 2, 67) == 1 );
assert( gamma_move(board, 3, 1, 89) == 0 );


char* board252372166 = gamma_board(board);
assert( board252372166 != NULL );
assert( strcmp(board252372166, 
"...\n"
"313\n"
"2.1\n"
".33\n"
".2.\n"
"12.\n"
"..3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"33.\n"
".1.\n"
"1..\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"3..\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"31.\n"
"..1\n"
".3.\n"
".13\n"
"132\n"
"..1\n"
"3..\n"
"211\n"
".21\n"
"...\n"
".22\n"
"3..\n"
"..1\n"
"123\n"
"...\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"..3\n"
".2.\n"
".33\n"
"2..\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
".11\n"
"...\n"
"...\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
"...\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board252372166);
board252372166 = NULL;
assert( gamma_move(board, 1, 23, 2) == 0 );
assert( gamma_move(board, 1, 1, 36) == 0 );
assert( gamma_move(board, 2, 2, 32) == 1 );
assert( gamma_move(board, 2, 2, 63) == 0 );
assert( gamma_move(board, 3, 2, 30) == 0 );
assert( gamma_move(board, 3, 2, 57) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 2, 0, 27) == 0 );
assert( gamma_move(board, 3, 1, 95) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 1, 44, 1) == 0 );
assert( gamma_move(board, 1, 2, 22) == 0 );
assert( gamma_move(board, 2, 83, 2) == 0 );
assert( gamma_move(board, 2, 1, 46) == 1 );
assert( gamma_move(board, 3, 48, 2) == 0 );
assert( gamma_move(board, 3, 1, 78) == 0 );


char* board851818411 = gamma_board(board);
assert( board851818411 != NULL );
assert( strcmp(board851818411, 
"...\n"
"313\n"
"2.1\n"
".33\n"
".2.\n"
"12.\n"
"..3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"33.\n"
".1.\n"
"1..\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"3..\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"31.\n"
"..1\n"
".3.\n"
".13\n"
"132\n"
"..1\n"
"3..\n"
"211\n"
".21\n"
"...\n"
".22\n"
"3..\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"..3\n"
".2.\n"
".33\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"...\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
"...\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
"..1\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board851818411);
board851818411 = NULL;
assert( gamma_move(board, 1, 44, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 82) == 1 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 55, 1) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 84, 2) == 0 );
assert( gamma_move(board, 3, 30, 0) == 0 );
assert( gamma_move(board, 1, 2, 98) == 0 );
assert( gamma_busy_fields(board, 1) == 62 );
assert( gamma_move(board, 2, 52, 2) == 0 );
assert( gamma_move(board, 3, 0, 47) == 1 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 37, 1) == 0 );
assert( gamma_move(board, 1, 1, 20) == 1 );
assert( gamma_move(board, 2, 0, 43) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 3, 0, 75) == 0 );
assert( gamma_free_fields(board, 3) == 132 );
assert( gamma_move(board, 1, 60, 2) == 0 );
assert( gamma_move(board, 2, 1, 66) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 0, 62) == 1 );
assert( gamma_busy_fields(board, 3) == 54 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 2, 2, 45) == 0 );


char* board788017480 = gamma_board(board);
assert( board788017480 != NULL );
assert( strcmp(board788017480, 
"...\n"
"313\n"
"2.1\n"
".33\n"
".2.\n"
"12.\n"
"..3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"33.\n"
".1.\n"
"12.\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"3..\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"31.\n"
"..1\n"
".3.\n"
".13\n"
"132\n"
".21\n"
"3..\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"3..\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1..\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"..3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"...\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board788017480);
board788017480 = NULL;
assert( gamma_move(board, 3, 79, 2) == 0 );
assert( gamma_move(board, 1, 0, 98) == 0 );
assert( gamma_move(board, 2, 1, 70) == 1 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 62) == 0 );
assert( gamma_free_fields(board, 3) == 128 );
assert( gamma_move(board, 1, 44, 1) == 0 );
assert( gamma_move(board, 1, 2, 66) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 2, 0, 74) == 0 );
assert( gamma_move(board, 3, 2, 35) == 0 );
assert( gamma_move(board, 3, 2, 55) == 1 );
assert( gamma_busy_fields(board, 3) == 55 );
assert( gamma_move(board, 1, 93, 0) == 0 );
assert( gamma_move(board, 2, 83, 2) == 0 );
assert( gamma_move(board, 3, 95, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 55 );
assert( gamma_move(board, 1, 19, 1) == 0 );
assert( gamma_move(board, 1, 0, 65) == 0 );
assert( gamma_move(board, 2, 2, 98) == 0 );
assert( gamma_move(board, 3, 95, 0) == 0 );
assert( gamma_move(board, 1, 74, 1) == 0 );
assert( gamma_golden_move(board, 1, 43, 1) == 0 );
assert( gamma_move(board, 2, 0, 46) == 0 );
assert( gamma_move(board, 3, 1, 77) == 1 );
assert( gamma_golden_move(board, 3, 41, 1) == 0 );


char* board498405004 = gamma_board(board);
assert( board498405004 != NULL );
assert( strcmp(board498405004, 
"...\n"
"313\n"
"2.1\n"
".33\n"
".2.\n"
"12.\n"
"..3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
".3.\n"
"33.\n"
".1.\n"
"12.\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
"..2\n"
"31.\n"
".21\n"
".3.\n"
".13\n"
"132\n"
".21\n"
"3..\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"3..\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"..3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"31.\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"...\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board498405004);
board498405004 = NULL;
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 0, 31) == 1 );
assert( gamma_free_fields(board, 1) == 125 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_golden_move(board, 2, 96, 1) == 0 );
assert( gamma_move(board, 3, 69, 2) == 0 );
assert( gamma_move(board, 3, 2, 36) == 1 );
assert( gamma_busy_fields(board, 3) == 57 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 95, 0) == 0 );
assert( gamma_move(board, 1, 0, 85) == 1 );
assert( gamma_move(board, 2, 72, 0) == 0 );
assert( gamma_move(board, 2, 0, 96) == 1 );
assert( gamma_move(board, 3, 19, 2) == 0 );
assert( gamma_move(board, 3, 0, 93) == 1 );
assert( gamma_move(board, 1, 88, 0) == 0 );
assert( gamma_move(board, 1, 0, 46) == 0 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_move(board, 3, 1, 20) == 0 );
assert( gamma_move(board, 1, 1, 60) == 1 );
assert( gamma_move(board, 1, 1, 72) == 1 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 2, 56) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 1, 97) == 1 );
assert( gamma_move(board, 1, 76, 2) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 73, 0) == 0 );
assert( gamma_free_fields(board, 2) == 118 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 78, 0) == 0 );
assert( gamma_move(board, 3, 1, 72) == 0 );
assert( gamma_free_fields(board, 3) == 118 );
assert( gamma_move(board, 1, 2, 83) == 1 );
assert( gamma_move(board, 1, 0, 69) == 1 );
assert( gamma_busy_fields(board, 1) == 70 );
assert( gamma_move(board, 2, 0, 49) == 1 );
assert( gamma_move(board, 3, 2, 18) == 0 );
assert( gamma_free_fields(board, 1) == 115 );
assert( gamma_move(board, 2, 55, 1) == 0 );


char* board563686976 = gamma_board(board);
assert( board563686976 != NULL );
assert( strcmp(board563686976, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"3.3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"12.\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
".12\n"
"31.\n"
".21\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"3..\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"1..\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board563686976);
board563686976 = NULL;
assert( gamma_move(board, 3, 29, 1) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 1, 1, 33) == 0 );


char* board175971742 = gamma_board(board);
assert( board175971742 != NULL );
assert( strcmp(board175971742, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"3.3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"12.\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
".12\n"
"31.\n"
".21\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"3..\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"1..\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board175971742);
board175971742 = NULL;
assert( gamma_move(board, 2, 22, 1) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );


char* board810214960 = gamma_board(board);
assert( board810214960 != NULL );
assert( strcmp(board810214960, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"3.3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"12.\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
".12\n"
"31.\n"
".21\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"3..\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"1..\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board810214960);
board810214960 = NULL;
assert( gamma_move(board, 1, 32, 1) == 0 );
assert( gamma_move(board, 2, 95, 2) == 0 );


char* board407873641 = gamma_board(board);
assert( board407873641 != NULL );
assert( strcmp(board407873641, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"3.3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"12.\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
".12\n"
"31.\n"
".21\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"3..\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"1..\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board407873641);
board407873641 = NULL;
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 1, 1, 72) == 0 );
assert( gamma_move(board, 2, 21, 1) == 0 );
assert( gamma_move(board, 2, 0, 81) == 0 );
assert( gamma_move(board, 3, 71, 2) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 1, 48) == 0 );
assert( gamma_move(board, 2, 0, 36) == 0 );
assert( gamma_busy_fields(board, 2) == 56 );


char* board480865448 = gamma_board(board);
assert( board480865448 != NULL );
assert( strcmp(board480865448, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"3.3\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"12.\n"
"131\n"
".1.\n"
".3.\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
".12\n"
"31.\n"
".21\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"3..\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"1..\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
"..2\n"
"13.\n"
"..2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board480865448);
board480865448 = NULL;
assert( gamma_move(board, 3, 24, 0) == 0 );
assert( gamma_move(board, 3, 0, 51) == 0 );
assert( gamma_free_fields(board, 3) == 115 );
assert( gamma_move(board, 1, 71, 2) == 0 );
assert( gamma_move(board, 1, 2, 33) == 0 );
assert( gamma_move(board, 2, 74, 1) == 0 );
assert( gamma_move(board, 2, 1, 93) == 1 );
assert( gamma_move(board, 3, 1, 78) == 0 );
assert( gamma_move(board, 3, 2, 31) == 1 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 0, 70) == 1 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_move(board, 2, 1, 24) == 1 );
assert( gamma_move(board, 2, 2, 79) == 1 );
assert( gamma_move(board, 3, 2, 30) == 0 );
assert( gamma_move(board, 1, 87, 2) == 0 );
assert( gamma_move(board, 2, 20, 0) == 0 );
assert( gamma_move(board, 3, 0, 22) == 1 );
assert( gamma_move(board, 1, 14, 1) == 0 );


char* board895679273 = gamma_board(board);
assert( board895679273 != NULL );
assert( strcmp(board895679273, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"12.\n"
"131\n"
".1.\n"
".32\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"1..\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"3..\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
"..2\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"3.2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".23\n"
"21.\n") == 0);
free(board895679273);
board895679273 = NULL;
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_free_fields(board, 3) == 109 );
assert( gamma_move(board, 1, 18, 0) == 0 );
assert( gamma_golden_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 2, 2, 82) == 1 );
assert( gamma_golden_move(board, 2, 26, 2) == 0 );
assert( gamma_move(board, 3, 0, 44) == 0 );
assert( gamma_move(board, 3, 1, 74) == 1 );
assert( gamma_move(board, 1, 1, 32) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 1, 76) == 0 );
assert( gamma_busy_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 30, 0) == 0 );
assert( gamma_move(board, 1, 48, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 89, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_move(board, 3, 46, 2) == 0 );
assert( gamma_move(board, 1, 2, 67) == 0 );
assert( gamma_golden_move(board, 1, 92, 2) == 0 );
assert( gamma_move(board, 2, 1, 39) == 0 );
assert( gamma_move(board, 2, 1, 65) == 1 );


char* board132153815 = gamma_board(board);
assert( board132153815 != NULL );
assert( strcmp(board132153815, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
".32\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"3.2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
".21\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board132153815);
board132153815 = NULL;
assert( gamma_move(board, 3, 31, 1) == 0 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 1, 1, 50) == 0 );


char* board855710811 = gamma_board(board);
assert( board855710811 != NULL );
assert( strcmp(board855710811, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
".32\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"1.2\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"3.2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board855710811);
board855710811 = NULL;
assert( gamma_move(board, 2, 99, 1) == 0 );
assert( gamma_move(board, 2, 2, 79) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 3, 0, 40) == 0 );
assert( gamma_move(board, 1, 84, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 60 );
assert( gamma_move(board, 3, 27, 2) == 0 );
assert( gamma_move(board, 3, 0, 21) == 0 );
assert( gamma_move(board, 1, 24, 0) == 0 );
assert( gamma_move(board, 1, 1, 44) == 1 );


char* board158611959 = gamma_board(board);
assert( board158611959 != NULL );
assert( strcmp(board158611959, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
".32\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"3.2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board158611959);
board158611959 = NULL;
assert( gamma_move(board, 2, 1, 50) == 0 );
assert( gamma_move(board, 3, 95, 2) == 0 );
assert( gamma_move(board, 3, 1, 87) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 18, 0) == 0 );
assert( gamma_move(board, 3, 0, 79) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 20, 0) == 0 );
assert( gamma_move(board, 1, 1, 38) == 0 );


char* board838963954 = gamma_board(board);
assert( board838963954 != NULL );
assert( strcmp(board838963954, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"2.3\n"
"13.\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"3.2\n"
"1.1\n"
".1.\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board838963954);
board838963954 = NULL;
assert( gamma_move(board, 2, 99, 1) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 60 );
assert( gamma_move(board, 3, 1, 86) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 32, 0) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_free_fields(board, 2) == 101 );
assert( gamma_move(board, 3, 53, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 65 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 2, 20) == 1 );
assert( gamma_busy_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 27, 2) == 0 );
assert( gamma_move(board, 1, 1, 51) == 0 );
assert( gamma_move(board, 2, 0, 79) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 62, 1) == 0 );
assert( gamma_free_fields(board, 3) == 100 );


char* board151860193 = gamma_board(board);
assert( board151860193 != NULL );
assert( strcmp(board151860193, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
".11\n"
"22.\n"
"22.\n"
".21\n"
".1.\n"
"233\n"
"13.\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
"...\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"2..\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"3.2\n"
"1.1\n"
".12\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board151860193);
board151860193 = NULL;
assert( gamma_move(board, 1, 1, 61) == 0 );
assert( gamma_move(board, 2, 2, 87) == 1 );
assert( gamma_move(board, 3, 62, 1) == 0 );
assert( gamma_move(board, 3, 2, 89) == 1 );
assert( gamma_move(board, 1, 77, 2) == 0 );
assert( gamma_move(board, 2, 84, 2) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 1, 1, 30) == 0 );
assert( gamma_free_fields(board, 1) == 98 );
assert( gamma_move(board, 2, 72, 0) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 1, 32) == 0 );
assert( gamma_golden_move(board, 3, 71, 1) == 0 );
assert( gamma_move(board, 1, 1, 53) == 1 );
assert( gamma_move(board, 2, 22, 1) == 0 );
assert( gamma_move(board, 2, 1, 40) == 1 );
assert( gamma_free_fields(board, 2) == 96 );
assert( gamma_move(board, 3, 2, 44) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 62, 2) == 0 );
assert( gamma_free_fields(board, 1) == 96 );
assert( gamma_move(board, 2, 94, 2) == 0 );
assert( gamma_move(board, 2, 1, 64) == 0 );
assert( gamma_move(board, 3, 78, 2) == 0 );
assert( gamma_move(board, 3, 1, 47) == 0 );
assert( gamma_move(board, 1, 30, 0) == 0 );
assert( gamma_free_fields(board, 1) == 96 );
assert( gamma_move(board, 2, 1, 48) == 0 );
assert( gamma_move(board, 3, 72, 0) == 0 );


char* board706095146 = gamma_board(board);
assert( board706095146 != NULL );
assert( strcmp(board706095146, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
".11\n"
"22.\n"
"223\n"
".21\n"
".12\n"
"233\n"
"13.\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
".13\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"..3\n"
"1.3\n"
"131\n"
".1.\n"
".2.\n"
"123\n"
"112\n"
"2.3\n"
".2.\n"
"333\n"
"22.\n"
"..2\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"22.\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
".11\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"31.\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"3.2\n"
"1.1\n"
".12\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board706095146);
board706095146 = NULL;
assert( gamma_move(board, 1, 73, 0) == 0 );
assert( gamma_move(board, 1, 0, 68) == 1 );
assert( gamma_free_fields(board, 1) == 95 );
assert( gamma_move(board, 2, 2, 27) == 1 );
assert( gamma_move(board, 2, 0, 33) == 1 );
assert( gamma_move(board, 3, 2, 81) == 0 );
assert( gamma_move(board, 1, 88, 0) == 0 );
assert( gamma_free_fields(board, 1) == 93 );
assert( gamma_move(board, 2, 99, 1) == 0 );
assert( gamma_move(board, 3, 26, 1) == 0 );
assert( gamma_golden_move(board, 3, 20, 2) == 0 );
assert( gamma_move(board, 2, 90, 2) == 0 );
assert( gamma_move(board, 2, 0, 56) == 1 );
assert( gamma_move(board, 3, 85, 2) == 0 );
assert( gamma_move(board, 1, 85, 2) == 0 );
assert( gamma_move(board, 2, 95, 0) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_free_fields(board, 2) == 92 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 66 );
assert( gamma_move(board, 1, 21, 1) == 0 );
assert( gamma_move(board, 2, 66, 0) == 0 );
assert( gamma_move(board, 2, 0, 48) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 99, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 66 );
assert( gamma_move(board, 1, 19, 0) == 0 );
assert( gamma_move(board, 1, 1, 45) == 1 );
assert( gamma_move(board, 2, 24, 0) == 0 );
assert( gamma_move(board, 2, 1, 89) == 0 );
assert( gamma_move(board, 3, 26, 1) == 0 );
assert( gamma_golden_move(board, 3, 24, 2) == 0 );
assert( gamma_move(board, 1, 26, 1) == 0 );
assert( gamma_move(board, 1, 0, 58) == 0 );
assert( gamma_busy_fields(board, 1) == 77 );
assert( gamma_move(board, 2, 2, 63) == 0 );
assert( gamma_move(board, 3, 0, 60) == 0 );
assert( gamma_move(board, 1, 16, 2) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 3, 65, 2) == 0 );
assert( gamma_move(board, 1, 34, 2) == 0 );
assert( gamma_move(board, 1, 0, 31) == 0 );
assert( gamma_golden_move(board, 1, 55, 2) == 0 );
assert( gamma_move(board, 2, 2, 85) == 1 );
assert( gamma_move(board, 3, 2, 61) == 0 );
assert( gamma_move(board, 1, 72, 0) == 0 );
assert( gamma_move(board, 1, 2, 52) == 1 );
assert( gamma_move(board, 2, 95, 0) == 0 );
assert( gamma_move(board, 3, 1, 22) == 1 );
assert( gamma_busy_fields(board, 3) == 67 );
assert( gamma_move(board, 1, 0, 91) == 1 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 68 );
assert( gamma_move(board, 3, 1, 18) == 0 );
assert( gamma_move(board, 3, 2, 25) == 0 );
assert( gamma_golden_move(board, 3, 63, 2) == 0 );
assert( gamma_move(board, 1, 99, 2) == 0 );
assert( gamma_move(board, 1, 0, 46) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 56) == 1 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_move(board, 2, 77, 2) == 0 );
assert( gamma_move(board, 2, 2, 35) == 0 );


char* board282214151 = gamma_board(board);
assert( board282214151 != NULL );
assert( strcmp(board282214151, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
"111\n"
"22.\n"
"223\n"
".21\n"
".12\n"
"233\n"
"132\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
"113\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"233\n"
"1.3\n"
"131\n"
".1.\n"
".21\n"
"123\n"
"112\n"
"2.3\n"
"22.\n"
"333\n"
"22.\n"
".12\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"22.\n"
"211\n"
"232\n"
"2..\n"
"313\n"
"..2\n"
".1.\n"
"211\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"312\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"332\n"
"1.1\n"
".12\n"
"...\n"
".32\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board282214151);
board282214151 = NULL;
assert( gamma_move(board, 3, 94, 2) == 0 );
assert( gamma_move(board, 3, 0, 46) == 0 );
assert( gamma_move(board, 1, 0, 27) == 0 );
assert( gamma_busy_fields(board, 1) == 79 );
assert( gamma_move(board, 3, 60, 2) == 0 );
assert( gamma_move(board, 3, 1, 87) == 0 );
assert( gamma_move(board, 1, 0, 18) == 1 );
assert( gamma_move(board, 1, 0, 68) == 0 );
assert( gamma_move(board, 2, 1, 35) == 1 );
assert( gamma_move(board, 3, 0, 19) == 1 );
assert( gamma_move(board, 3, 2, 58) == 0 );
assert( gamma_move(board, 1, 57, 0) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );


char* board989254564 = gamma_board(board);
assert( board989254564 != NULL );
assert( strcmp(board989254564, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"12.\n"
"323\n"
"323\n"
"111\n"
"22.\n"
"223\n"
".21\n"
".12\n"
"233\n"
"132\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
"113\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"233\n"
"1.3\n"
"131\n"
".1.\n"
".21\n"
"123\n"
"112\n"
"2.3\n"
"22.\n"
"333\n"
"22.\n"
".12\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"22.\n"
"211\n"
"232\n"
"2..\n"
"313\n"
".22\n"
".1.\n"
"211\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"312\n"
"3.1\n"
".33\n"
".22\n"
"13.\n"
"332\n"
"1.1\n"
".12\n"
"3..\n"
"132\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
".11\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board989254564);
board989254564 = NULL;
assert( gamma_move(board, 1, 1, 82) == 0 );
assert( gamma_move(board, 3, 0, 65) == 0 );
assert( gamma_move(board, 3, 2, 25) == 0 );
assert( gamma_move(board, 1, 2, 81) == 0 );
assert( gamma_move(board, 2, 2, 92) == 0 );
assert( gamma_move(board, 3, 45, 0) == 0 );
assert( gamma_move(board, 3, 0, 22) == 0 );
assert( gamma_busy_fields(board, 3) == 69 );
assert( gamma_move(board, 1, 1, 66) == 0 );
assert( gamma_move(board, 2, 40, 2) == 0 );
assert( gamma_move(board, 3, 1, 21) == 1 );
assert( gamma_move(board, 2, 1, 79) == 0 );
assert( gamma_move(board, 2, 2, 21) == 0 );
assert( gamma_move(board, 3, 78, 0) == 0 );
assert( gamma_move(board, 1, 0, 74) == 0 );
assert( gamma_move(board, 1, 2, 22) == 0 );
assert( gamma_free_fields(board, 1) == 81 );
assert( gamma_move(board, 2, 1, 46) == 0 );
assert( gamma_move(board, 2, 2, 40) == 1 );
assert( gamma_free_fields(board, 2) == 80 );
assert( gamma_move(board, 3, 61, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 70 );
assert( gamma_move(board, 1, 65, 2) == 0 );
assert( gamma_move(board, 1, 2, 54) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 2, 50) == 0 );
assert( gamma_move(board, 3, 0, 23) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 1, 2, 94) == 1 );
assert( gamma_move(board, 2, 99, 2) == 0 );
assert( gamma_move(board, 2, 0, 39) == 0 );
assert( gamma_move(board, 3, 95, 0) == 0 );
assert( gamma_move(board, 1, 1, 35) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 71 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 2, 0, 93) == 0 );
assert( gamma_move(board, 2, 1, 26) == 1 );
assert( gamma_move(board, 1, 25, 0) == 0 );
assert( gamma_move(board, 2, 1, 18) == 0 );
assert( gamma_free_fields(board, 2) == 77 );


char* board504096579 = gamma_board(board);
assert( board504096579 != NULL );
assert( strcmp(board504096579, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"121\n"
"323\n"
"323\n"
"111\n"
"22.\n"
"223\n"
".21\n"
".12\n"
"233\n"
"132\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
"113\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
"..3\n"
"233\n"
"1.3\n"
"131\n"
".1.\n"
".21\n"
"123\n"
"112\n"
"2.3\n"
"22.\n"
"333\n"
"22.\n"
".12\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"222\n"
"211\n"
"232\n"
"2..\n"
"313\n"
".22\n"
".1.\n"
"211\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"312\n"
"321\n"
".33\n"
".22\n"
"13.\n"
"332\n"
"131\n"
".12\n"
"3..\n"
"132\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
"311\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board504096579);
board504096579 = NULL;
assert( gamma_move(board, 1, 1, 48) == 0 );
assert( gamma_move(board, 1, 1, 98) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 78, 2) == 0 );
assert( gamma_move(board, 1, 1, 57) == 1 );
assert( gamma_move(board, 2, 34, 2) == 0 );
assert( gamma_free_fields(board, 2) == 76 );
assert( gamma_move(board, 3, 8, 2) == 0 );


char* board506117259 = gamma_board(board);
assert( board506117259 != NULL );
assert( strcmp(board506117259, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"121\n"
"323\n"
"323\n"
"111\n"
"22.\n"
"223\n"
".21\n"
".12\n"
"233\n"
"132\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
"113\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
"..1\n"
"123\n"
".13\n"
"233\n"
"1.3\n"
"131\n"
".1.\n"
".21\n"
"123\n"
"112\n"
"2.3\n"
"22.\n"
"333\n"
"22.\n"
".12\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"222\n"
"211\n"
"232\n"
"2..\n"
"313\n"
".22\n"
".1.\n"
"211\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"312\n"
"321\n"
".33\n"
".22\n"
"13.\n"
"332\n"
"131\n"
".12\n"
"3..\n"
"132\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
"311\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board506117259);
board506117259 = NULL;
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_free_fields(board, 1) == 76 );
assert( gamma_golden_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 2, 21) == 0 );
assert( gamma_move(board, 3, 65, 2) == 0 );
assert( gamma_move(board, 1, 41, 2) == 0 );
assert( gamma_move(board, 1, 1, 59) == 1 );
assert( gamma_move(board, 2, 78, 2) == 0 );
assert( gamma_move(board, 2, 0, 77) == 0 );
assert( gamma_busy_fields(board, 2) == 71 );
assert( gamma_move(board, 3, 73, 0) == 0 );
assert( gamma_move(board, 3, 2, 83) == 0 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 0, 69) == 0 );
assert( gamma_move(board, 3, 1, 85) == 0 );
assert( gamma_move(board, 1, 1, 57) == 0 );
assert( gamma_move(board, 1, 1, 71) == 0 );
assert( gamma_move(board, 2, 1, 28) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 2, 30) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_move(board, 1, 1, 89) == 0 );
assert( gamma_move(board, 2, 2, 45) == 0 );
assert( gamma_move(board, 3, 80, 0) == 0 );
assert( gamma_move(board, 3, 2, 37) == 1 );
assert( gamma_move(board, 1, 32, 0) == 0 );
assert( gamma_move(board, 3, 76, 0) == 0 );
assert( gamma_move(board, 3, 1, 72) == 0 );
assert( gamma_move(board, 1, 62, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 83 );
assert( gamma_move(board, 2, 65, 2) == 0 );
assert( gamma_move(board, 2, 1, 68) == 0 );
assert( gamma_move(board, 3, 90, 2) == 0 );


char* board323077523 = gamma_board(board);
assert( board323077523 != NULL );
assert( strcmp(board323077523, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"121\n"
"323\n"
"323\n"
"111\n"
"22.\n"
"223\n"
".21\n"
".12\n"
"233\n"
"132\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
"113\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3..\n"
".22\n"
"31.\n"
".11\n"
"123\n"
".13\n"
"233\n"
"1.3\n"
"131\n"
".1.\n"
".21\n"
"123\n"
"112\n"
"2.3\n"
"22.\n"
"333\n"
"22.\n"
".12\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"222\n"
"211\n"
"232\n"
"2.3\n"
"313\n"
".22\n"
".1.\n"
"211\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"312\n"
"321\n"
".33\n"
".22\n"
"13.\n"
"332\n"
"131\n"
".12\n"
"3..\n"
"132\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
"311\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board323077523);
board323077523 = NULL;
assert( gamma_move(board, 2, 88, 0) == 0 );
assert( gamma_move(board, 2, 2, 83) == 0 );
assert( gamma_move(board, 3, 57, 0) == 0 );
assert( gamma_move(board, 3, 2, 62) == 1 );
assert( gamma_move(board, 2, 2, 64) == 0 );
assert( gamma_move(board, 2, 2, 52) == 0 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );


char* board895144028 = gamma_board(board);
assert( board895144028 != NULL );
assert( strcmp(board895144028, 
"...\n"
"313\n"
"231\n"
"233\n"
".2.\n"
"121\n"
"323\n"
"323\n"
"111\n"
"22.\n"
"223\n"
".21\n"
".12\n"
"233\n"
"132\n"
"33.\n"
".11\n"
"122\n"
"131\n"
".1.\n"
"332\n"
".1.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
"113\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3.3\n"
".22\n"
"31.\n"
".11\n"
"123\n"
".13\n"
"233\n"
"1.3\n"
"131\n"
".1.\n"
".21\n"
"123\n"
"112\n"
"2.3\n"
"22.\n"
"333\n"
"22.\n"
".12\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"222\n"
"211\n"
"232\n"
"2.3\n"
"313\n"
".22\n"
".1.\n"
"211\n"
".12\n"
"1.3\n"
".13\n"
"..3\n"
"113\n"
"312\n"
"321\n"
".33\n"
".22\n"
"13.\n"
"332\n"
"131\n"
".12\n"
"3..\n"
"132\n"
"2..\n"
"31.\n"
"311\n"
"3.3\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"2.3\n"
".3.\n"
"321\n"
"112\n"
"..1\n"
"..2\n"
"311\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board895144028);
board895144028 = NULL;
assert( gamma_move(board, 2, 71, 2) == 0 );
assert( gamma_move(board, 1, 41, 2) == 0 );
assert( gamma_move(board, 2, 53, 2) == 0 );
assert( gamma_move(board, 2, 1, 82) == 0 );
assert( gamma_move(board, 3, 99, 1) == 0 );
assert( gamma_move(board, 1, 0, 98) == 0 );
assert( gamma_busy_fields(board, 1) == 83 );
assert( gamma_golden_move(board, 1, 92, 0) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 1, 20) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 2, 43) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 96) == 0 );
assert( gamma_move(board, 1, 20, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 83 );
assert( gamma_golden_move(board, 1, 56, 0) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 3, 0, 83) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 29, 1) == 0 );
assert( gamma_move(board, 2, 90, 2) == 0 );
assert( gamma_move(board, 3, 2, 56) == 0 );
assert( gamma_move(board, 1, 80, 0) == 0 );
assert( gamma_move(board, 2, 1, 69) == 0 );
assert( gamma_golden_move(board, 2, 31, 2) == 0 );
assert( gamma_move(board, 3, 2, 18) == 0 );
assert( gamma_move(board, 3, 1, 5) == 1 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 0, 70) == 0 );
assert( gamma_move(board, 2, 2, 59) == 0 );
assert( gamma_move(board, 2, 2, 47) == 0 );
assert( gamma_move(board, 3, 0, 78) == 1 );
assert( gamma_busy_fields(board, 3) == 76 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 0, 48) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 1, 46) == 0 );
assert( gamma_move(board, 3, 57, 0) == 0 );
assert( gamma_move(board, 3, 2, 63) == 0 );
assert( gamma_move(board, 1, 57, 0) == 0 );
assert( gamma_move(board, 1, 1, 87) == 0 );
assert( gamma_move(board, 2, 0, 83) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 0, 20) == 1 );
assert( gamma_move(board, 1, 1, 19) == 1 );
assert( gamma_move(board, 2, 74, 2) == 0 );
assert( gamma_move(board, 3, 2, 68) == 0 );
assert( gamma_golden_move(board, 3, 63, 2) == 0 );
assert( gamma_move(board, 1, 99, 1) == 0 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_free_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 1, 99, 2) == 0 );
assert( gamma_golden_move(board, 1, 94, 1) == 0 );
assert( gamma_move(board, 2, 35, 0) == 0 );
assert( gamma_move(board, 3, 78, 2) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 1, 90, 2) == 0 );
assert( gamma_move(board, 2, 62, 1) == 0 );
assert( gamma_move(board, 3, 2, 49) == 0 );
assert( gamma_move(board, 3, 1, 93) == 0 );
assert( gamma_move(board, 1, 1, 34) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 25, 0) == 0 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_golden_move(board, 2, 25, 1) == 0 );
assert( gamma_move(board, 3, 0, 95) == 1 );
assert( gamma_move(board, 1, 2, 34) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 23, 2) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 1, 31) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 32, 0) == 0 );
assert( gamma_move(board, 1, 1, 39) == 0 );
assert( gamma_move(board, 2, 80, 0) == 0 );
assert( gamma_move(board, 2, 0, 44) == 0 );


char* board180552377 = gamma_board(board);
assert( board180552377 != NULL );
assert( strcmp(board180552377, 
"...\n"
"313\n"
"231\n"
"233\n"
"32.\n"
"121\n"
"323\n"
"323\n"
"111\n"
"22.\n"
"223\n"
".21\n"
".12\n"
"233\n"
"132\n"
"33.\n"
"311\n"
"122\n"
"131\n"
".1.\n"
"332\n"
"31.\n"
"33.\n"
".1.\n"
"1.2\n"
"13.\n"
".22\n"
".12\n"
"31.\n"
"121\n"
"13.\n"
"113\n"
"132\n"
".21\n"
"32.\n"
"211\n"
".21\n"
"3.3\n"
".22\n"
"31.\n"
".11\n"
"123\n"
".13\n"
"233\n"
"1.3\n"
"131\n"
".1.\n"
".21\n"
"123\n"
"112\n"
"2.3\n"
"22.\n"
"333\n"
"22.\n"
".12\n"
"112\n"
"332\n"
"231\n"
"32.\n"
"222\n"
"211\n"
"232\n"
"2.3\n"
"313\n"
".22\n"
".11\n"
"211\n"
".12\n"
"133\n"
".13\n"
"..3\n"
"113\n"
"312\n"
"321\n"
".33\n"
".22\n"
"13.\n"
"332\n"
"131\n"
"312\n"
"31.\n"
"132\n"
"2..\n"
"31.\n"
"311\n"
"323\n"
"123\n"
".12\n"
".3.\n"
"112\n"
"223\n"
".3.\n"
"321\n"
"112\n"
".31\n"
"..2\n"
"311\n"
"1..\n"
".13\n"
"21.\n") == 0);
free(board180552377);
board180552377 = NULL;
assert( gamma_move(board, 3, 72, 0) == 0 );
assert( gamma_move(board, 3, 0, 38) == 0 );
assert( gamma_busy_fields(board, 3) == 79 );
assert( gamma_golden_move(board, 3, 71, 1) == 0 );
assert( gamma_move(board, 1, 0, 68) == 0 );
assert( gamma_move(board, 2, 2, 99) == 1 );
assert( gamma_move(board, 3, 29, 0) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 85 );
assert( gamma_move(board, 2, 45, 0) == 0 );
assert( gamma_move(board, 2, 2, 64) == 0 );
assert( gamma_move(board, 3, 1, 66) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 2, 75) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 71, 2) == 0 );
assert( gamma_move(board, 3, 1, 95) == 0 );
assert( gamma_move(board, 3, 0, 52) == 1 );
assert( gamma_free_fields(board, 3) == 61 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 2, 0) == 1 );
assert( gamma_free_fields(board, 2) == 60 );
assert( gamma_move(board, 3, 1, 82) == 0 );
assert( gamma_move(board, 1, 99, 1) == 0 );
assert( gamma_move(board, 1, 1, 89) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 87, 0) == 0 );
assert( gamma_move(board, 1, 1, 19) == 0 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 72, 0) == 0 );
assert( gamma_move(board, 2, 1, 74) == 0 );
assert( gamma_move(board, 3, 1, 82) == 0 );


gamma_delete(board);

    return 0;
}
