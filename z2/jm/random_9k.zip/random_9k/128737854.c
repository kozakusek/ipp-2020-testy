#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 128737854
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(10, 10, 9, 10);
assert( board != NULL );


assert( gamma_move(board, 1, 2, 8) == 1 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_move(board, 4, 9, 3) == 1 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_move(board, 6, 9, 4) == 1 );
assert( gamma_move(board, 6, 0, 8) == 1 );
assert( gamma_free_fields(board, 6) == 93 );
assert( gamma_move(board, 7, 8, 5) == 1 );
assert( gamma_move(board, 8, 1, 5) == 1 );
assert( gamma_golden_move(board, 8, 3, 9) == 0 );
assert( gamma_move(board, 9, 3, 6) == 1 );
assert( gamma_move(board, 9, 7, 0) == 1 );
assert( gamma_busy_fields(board, 9) == 2 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_free_fields(board, 2) == 88 );
assert( gamma_move(board, 3, 6, 5) == 1 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 5, 7) == 1 );
assert( gamma_move(board, 6, 7, 1) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_move(board, 7, 9, 4) == 0 );
assert( gamma_move(board, 8, 9, 7) == 1 );
assert( gamma_move(board, 9, 6, 7) == 1 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 2, 2) == 1 );


char* board638722288 = gamma_board(board);
assert( board638722288 != NULL );
assert( strcmp(board638722288, 
".....14..2\n"
"6.1.......\n"
".2...59..8\n"
".3.9.....2\n"
".8....3.7.\n"
".........6\n"
"..3......4\n"
"..4.......\n"
".......62.\n"
".5.....9..\n") == 0);
free(board638722288);
board638722288 = NULL;
assert( gamma_move(board, 5, 8, 6) == 1 );
assert( gamma_move(board, 5, 5, 2) == 1 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 6, 9, 7) == 0 );
assert( gamma_move(board, 7, 8, 8) == 1 );
assert( gamma_move(board, 7, 7, 4) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 0, 4) == 1 );
assert( gamma_move(board, 9, 7, 2) == 1 );
assert( gamma_move(board, 1, 3, 1) == 1 );


char* board766298519 = gamma_board(board);
assert( board766298519 != NULL );
assert( strcmp(board766298519, 
".....14..2\n"
"6.1.....7.\n"
".2...59..8\n"
".3.9....52\n"
".8....3.7.\n"
"8......7.6\n"
"..3......4\n"
"..4..5.9..\n"
"...1...62.\n"
".5.....9..\n") == 0);
free(board766298519);
board766298519 = NULL;
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_free_fields(board, 3) == 68 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_move(board, 7, 0, 5) == 1 );
assert( gamma_move(board, 7, 9, 5) == 1 );


char* board499662580 = gamma_board(board);
assert( board499662580 != NULL );
assert( strcmp(board499662580, 
".....14..2\n"
"6.1.....7.\n"
".2...59..8\n"
".3.9....52\n"
"78.3..3.77\n"
"8......7.6\n"
"..3.....24\n"
"..4..5.9..\n"
"...1...62.\n"
".5.....9..\n") == 0);
free(board499662580);
board499662580 = NULL;
assert( gamma_move(board, 9, 9, 3) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 2, 4, 7) == 1 );
assert( gamma_free_fields(board, 2) == 63 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 7) == 1 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 6, 7, 3) == 1 );
assert( gamma_move(board, 6, 9, 9) == 0 );
assert( gamma_move(board, 7, 5, 7) == 0 );
assert( gamma_move(board, 8, 0, 6) == 1 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_move(board, 9, 0, 4) == 0 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_free_fields(board, 1) == 58 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_free_fields(board, 7) == 57 );
assert( gamma_move(board, 8, 9, 4) == 0 );
assert( gamma_move(board, 8, 5, 5) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 0, 0) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 6, 3, 3) == 1 );
assert( gamma_move(board, 7, 6, 6) == 1 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 9, 1) == 1 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_move(board, 9, 5, 4) == 0 );
assert( gamma_move(board, 9, 3, 2) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 6, 8) == 1 );
assert( gamma_move(board, 5, 6, 1) == 1 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 7, 6, 6) == 0 );
assert( gamma_free_fields(board, 7) == 45 );
assert( gamma_move(board, 8, 8, 9) == 1 );
assert( gamma_move(board, 8, 7, 9) == 1 );
assert( gamma_move(board, 9, 6, 3) == 1 );
assert( gamma_move(board, 9, 6, 3) == 0 );


char* board316469073 = gamma_board(board);
assert( board316469073 != NULL );
assert( strcmp(board316469073, 
"1...214882\n"
"6.1...4.7.\n"
"22..2595.8\n"
"83.9..7152\n"
"78.3.83.77\n"
"8..41217.6\n"
"..36..9624\n"
"2.49.5.9..\n"
"...1..5628\n"
"95.....9..\n") == 0);
free(board316469073);
board316469073 = NULL;
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 2, 5, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 6, 0, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_free_fields(board, 7) == 40 );
assert( gamma_move(board, 8, 4, 8) == 0 );
assert( gamma_move(board, 8, 9, 2) == 1 );
assert( gamma_move(board, 9, 7, 3) == 0 );
assert( gamma_move(board, 9, 4, 4) == 0 );
assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_free_fields(board, 3) == 38 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_move(board, 7, 1, 5) == 0 );
assert( gamma_move(board, 7, 4, 5) == 1 );
assert( gamma_golden_move(board, 7, 9, 7) == 1 );
assert( gamma_move(board, 8, 3, 4) == 0 );
assert( gamma_move(board, 8, 9, 3) == 0 );
assert( gamma_move(board, 9, 9, 3) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 9, 0) == 1 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_free_fields(board, 5) == 34 );
assert( gamma_move(board, 6, 4, 2) == 1 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 7, 1, 9) == 1 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_free_fields(board, 7) == 32 );
assert( gamma_move(board, 8, 6, 2) == 1 );
assert( gamma_move(board, 9, 0, 5) == 0 );
assert( gamma_move(board, 9, 8, 6) == 0 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_golden_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 7, 0, 2) == 0 );
assert( gamma_move(board, 8, 1, 0) == 0 );
assert( gamma_move(board, 8, 2, 1) == 1 );
assert( gamma_move(board, 9, 5, 4) == 0 );
assert( gamma_move(board, 9, 8, 7) == 1 );
assert( gamma_free_fields(board, 9) == 26 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_free_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_move(board, 9, 3, 4) == 0 );
assert( gamma_move(board, 9, 4, 6) == 1 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );


char* board596063736 = gamma_board(board);
assert( board596063736 != NULL );
assert( strcmp(board596063736, 
"17..214882\n"
"6.1.4.4.7.\n"
"22..259597\n"
"83.9957152\n"
"78.3783.77\n"
"8..41217.6\n"
"4236.29624\n"
"21496589.8\n"
".5811.5628\n"
"95.....9.3\n") == 0);
free(board596063736);
board596063736 = NULL;
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_move(board, 5, 2, 0) == 1 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 6, 5, 8) == 1 );
assert( gamma_move(board, 7, 7, 3) == 0 );
assert( gamma_move(board, 8, 2, 8) == 0 );
assert( gamma_move(board, 9, 2, 4) == 1 );
assert( gamma_move(board, 9, 7, 3) == 0 );
assert( gamma_golden_move(board, 9, 0, 1) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 9, 8) == 1 );


char* board198247262 = gamma_board(board);
assert( board198247262 != NULL );
assert( strcmp(board198247262, 
"17..214882\n"
"6.1.464.72\n"
"22..259597\n"
"83.9957152\n"
"78.3783.77\n"
"8.941217.6\n"
"4236.29624\n"
"21496589.8\n"
".5811.5628\n"
"955....9.3\n") == 0);
free(board198247262);
board198247262 = NULL;
assert( gamma_free_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );


char* board960553210 = gamma_board(board);
assert( board960553210 != NULL );
assert( strcmp(board960553210, 
"17..214882\n"
"6.1.464.72\n"
"22..259597\n"
"83.9957152\n"
"78.3783.77\n"
"8.941217.6\n"
"4236.29624\n"
"21496589.8\n"
".5811.5628\n"
"955....9.3\n") == 0);
free(board960553210);
board960553210 = NULL;
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 7, 8, 3) == 0 );
assert( gamma_move(board, 7, 3, 5) == 0 );
assert( gamma_golden_move(board, 7, 9, 8) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 4, 3) == 1 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 6, 0, 3) == 0 );


char* board606514855 = gamma_board(board);
assert( board606514855 != NULL );
assert( strcmp(board606514855, 
"173.214882\n"
"6.1.464.72\n"
"22..259597\n"
"83.9957152\n"
"78.3783.77\n"
"8.941217.6\n"
"4236329624\n"
"21496589.8\n"
".5811.5628\n"
"955....9.3\n") == 0);
free(board606514855);
board606514855 = NULL;
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 8, 5, 7) == 0 );
assert( gamma_move(board, 8, 1, 7) == 0 );


char* board885117088 = gamma_board(board);
assert( board885117088 != NULL );
assert( strcmp(board885117088, 
"173.214882\n"
"6.1.464.72\n"
"22..259597\n"
"83.9957152\n"
"78.3783.77\n"
"8.941217.6\n"
"4236329624\n"
"21496589.8\n"
".5811.5628\n"
"955....9.3\n") == 0);
free(board885117088);
board885117088 = NULL;
assert( gamma_move(board, 9, 6, 2) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 7 );
assert( gamma_golden_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_golden_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 5, 3, 7) == 1 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_move(board, 7, 9, 0) == 0 );
assert( gamma_move(board, 7, 7, 6) == 0 );
assert( gamma_move(board, 9, 1, 8) == 1 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_move(board, 7, 8, 9) == 0 );
assert( gamma_move(board, 8, 9, 8) == 0 );
assert( gamma_move(board, 9, 0, 4) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 5, 2, 5) == 1 );
assert( gamma_move(board, 6, 3, 2) == 0 );
assert( gamma_move(board, 7, 8, 7) == 0 );
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_move(board, 8, 7, 2) == 0 );
assert( gamma_move(board, 9, 1, 0) == 0 );
assert( gamma_move(board, 1, 8, 2) == 1 );
assert( gamma_free_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board276089843 = gamma_board(board);
assert( board276089843 != NULL );
assert( strcmp(board276089843, 
"173.214382\n"
"691.464.72\n"
"22.5259597\n"
"83.9957152\n"
"7853783.77\n"
"8.941217.6\n"
"4236329624\n"
"2149658918\n"
".5811.5628\n"
"955....9.3\n") == 0);
free(board276089843);
board276089843 = NULL;
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_free_fields(board, 3) == 15 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 7, 4) == 1 );


char* board891093168 = gamma_board(board);
assert( board891093168 != NULL );
assert( strcmp(board891093168, 
"173.214382\n"
"691.464.72\n"
"22.5259597\n"
"83.9957152\n"
"7853783.77\n"
"8.941214.6\n"
"4236329624\n"
"2149658918\n"
".5811.5628\n"
"955....9.3\n") == 0);
free(board891093168);
board891093168 = NULL;
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 6, 8, 3) == 0 );


char* board207115832 = gamma_board(board);
assert( board207115832 != NULL );
assert( strcmp(board207115832, 
"173.214382\n"
"691.464.72\n"
"22.5259597\n"
"83.9957152\n"
"7853783.77\n"
"8.941214.6\n"
"4236329624\n"
"2149658918\n"
".5811.5628\n"
"955....9.3\n") == 0);
free(board207115832);
board207115832 = NULL;
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 9, 3) == 0 );
assert( gamma_move(board, 8, 9, 8) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 9) == 0 );


char* board179633422 = gamma_board(board);
assert( board179633422 != NULL );
assert( strcmp(board179633422, 
"173.214382\n"
"691.464.72\n"
"22.5259597\n"
"83.9957152\n"
"7853783.77\n"
"8.941214.6\n"
"4236329624\n"
"2149658918\n"
".5811.5628\n"
"955....9.3\n") == 0);
free(board179633422);
board179633422 = NULL;
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_free_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 7, 5, 8) == 0 );
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_move(board, 9, 1, 5) == 0 );
assert( gamma_free_fields(board, 9) == 5 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 8 );


char* board523965640 = gamma_board(board);
assert( board523965640 != NULL );
assert( strcmp(board523965640, 
"173.214382\n"
"691.464.72\n"
"22.5259597\n"
"83.9957152\n"
"7853783.77\n"
"8.941214.6\n"
"4236329624\n"
"2149658918\n"
".5811.5628\n"
"955..5.9.3\n") == 0);
free(board523965640);
board523965640 = NULL;
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_move(board, 7, 4, 9) == 0 );
assert( gamma_move(board, 8, 3, 3) == 0 );
assert( gamma_move(board, 9, 1, 0) == 0 );
assert( gamma_move(board, 9, 0, 9) == 0 );


char* board116532422 = gamma_board(board);
assert( board116532422 != NULL );
assert( strcmp(board116532422, 
"173.214382\n"
"691.464.72\n"
"22.5259597\n"
"83.9957152\n"
"7853783.77\n"
"8.941214.6\n"
"4236329624\n"
"2149658918\n"
".5811.5628\n"
"955..5.9.3\n") == 0);
free(board116532422);
board116532422 = NULL;
assert( gamma_move(board, 1, 1, 5) == 0 );


gamma_delete(board);

    return 0;
}
