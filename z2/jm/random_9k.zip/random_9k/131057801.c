#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 131057801
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 13, 7, 16);
assert( board != NULL );


assert( gamma_move(board, 1, 6, 11) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_move(board, 3, 12, 0) == 1 );
assert( gamma_free_fields(board, 3) == 178 );
assert( gamma_move(board, 4, 12, 3) == 1 );
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 5, 7, 3) == 1 );
assert( gamma_free_fields(board, 5) == 175 );
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_move(board, 6, 7, 8) == 1 );
assert( gamma_busy_fields(board, 7) == 0 );
assert( gamma_move(board, 1, 5, 8) == 1 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 3, 13, 0) == 1 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_busy_fields(board, 4) == 3 );
assert( gamma_move(board, 5, 0, 11) == 1 );
assert( gamma_move(board, 6, 1, 1) == 1 );
assert( gamma_move(board, 6, 1, 2) == 1 );
assert( gamma_free_fields(board, 6) == 165 );
assert( gamma_move(board, 7, 4, 4) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_move(board, 2, 5, 9) == 1 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_free_fields(board, 3) == 160 );
assert( gamma_golden_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 4, 3, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board636615023 = gamma_board(board);
assert( board636615023 != NULL );
assert( strcmp(board636615023, 
"...2..........\n"
"5....21.......\n"
"..............\n"
"...1.2........\n"
".....126...1..\n"
".............4\n"
"..............\n"
"...42.........\n"
"....7.1....4..\n"
".......5....4.\n"
".6............\n"
".6............\n"
"...3........33\n") == 0);
free(board636615023);
board636615023 = NULL;
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 5, 4, 3) == 1 );
assert( gamma_free_fields(board, 5) == 157 );
assert( gamma_move(board, 6, 4, 0) == 1 );
assert( gamma_move(board, 6, 2, 7) == 1 );
assert( gamma_move(board, 7, 4, 12) == 1 );
assert( gamma_move(board, 1, 7, 1) == 1 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_move(board, 4, 12, 6) == 1 );
assert( gamma_move(board, 5, 3, 10) == 1 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 6, 3, 8) == 1 );
assert( gamma_move(board, 6, 11, 3) == 1 );
assert( gamma_move(board, 7, 3, 0) == 0 );
assert( gamma_move(board, 7, 4, 1) == 1 );
assert( gamma_move(board, 2, 12, 12) == 1 );
assert( gamma_move(board, 3, 1, 5) == 1 );
assert( gamma_move(board, 3, 5, 5) == 1 );


char* board593778103 = gamma_board(board);
assert( board593778103 != NULL );
assert( strcmp(board593778103, 
"...27.......2.\n"
"5.2..21.......\n"
"...54.........\n"
"...1.2........\n"
"...6.126...1..\n"
"..6.5........4\n"
"............4.\n"
".3.423........\n"
"....7.1....4..\n"
"....5..5...64.\n"
".6.....2......\n"
".6..7..1......\n"
"...36.......33\n") == 0);
free(board593778103);
board593778103 = NULL;
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_move(board, 5, 5, 13) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 11, 11) == 1 );
assert( gamma_busy_fields(board, 7) == 4 );
assert( gamma_free_fields(board, 7) == 140 );
assert( gamma_move(board, 1, 8, 8) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 5, 10, 11) == 1 );
assert( gamma_move(board, 6, 4, 13) == 0 );
assert( gamma_golden_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 7, 13, 6) == 1 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_free_fields(board, 2) == 130 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 3, 8, 6) == 1 );
assert( gamma_move(board, 4, 12, 1) == 1 );
assert( gamma_move(board, 5, 4, 8) == 1 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_golden_move(board, 5, 5, 5) == 1 );
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_move(board, 7, 12, 1) == 0 );
assert( gamma_move(board, 7, 12, 10) == 1 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 2, 12, 2) == 1 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 9, 0) == 1 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 7) == 1 );
assert( gamma_move(board, 6, 2, 13) == 0 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 3, 13, 1) == 1 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 12, 8) == 1 );
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_move(board, 6, 10, 8) == 1 );
assert( gamma_move(board, 7, 11, 3) == 0 );
assert( gamma_move(board, 7, 12, 11) == 0 );
assert( gamma_move(board, 1, 4, 9) == 1 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 5, 9, 9) == 1 );
assert( gamma_golden_move(board, 6, 1, 13) == 0 );


char* board141538587 = gamma_board(board);
assert( board141538587 != NULL );
assert( strcmp(board141538587, 
"...27.......2.\n"
"5.2..211..572.\n"
"...54..1...47.\n"
"...112...5....\n"
".3.651261.615.\n"
"..6.5..5.....4\n"
"...3....33..47\n"
".32425........\n"
"..3.7.1....4..\n"
"..445..5..164.\n"
".6.....22...2.\n"
"26..7.61....43\n"
"..436.2..3..33\n") == 0);
free(board141538587);
board141538587 = NULL;
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 7, 3, 3) == 0 );
assert( gamma_free_fields(board, 7) == 109 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_free_fields(board, 3) == 107 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_move(board, 6, 11, 0) == 1 );
assert( gamma_move(board, 6, 13, 5) == 1 );
assert( gamma_move(board, 7, 6, 1) == 0 );
assert( gamma_move(board, 7, 9, 3) == 1 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );


char* board585510055 = gamma_board(board);
assert( board585510055 != NULL );
assert( strcmp(board585510055, 
"...27.......2.\n"
"5.2..211..572.\n"
"1..54..1...47.\n"
"...112...5....\n"
".3.651261.615.\n"
"..6.5..5.....4\n"
"...3....33..47\n"
".32425.......6\n"
"..3.7.1....4..\n"
".1445..5.7164.\n"
".6....422.2.2.\n"
"26..7.61....43\n"
"..436.2..3.633\n") == 0);
free(board585510055);
board585510055 = NULL;
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_free_fields(board, 5) == 101 );
assert( gamma_move(board, 6, 5, 9) == 0 );
assert( gamma_move(board, 6, 4, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 11 );


char* board366278642 = gamma_board(board);
assert( board366278642 != NULL );
assert( strcmp(board366278642, 
"...27.......2.\n"
"5.2..211..572.\n"
"1..54..1...47.\n"
".3.112...5....\n"
".3.651261.615.\n"
"..6.5..5.....4\n"
"...3....33..47\n"
".32425.......6\n"
"..3.7.1....4..\n"
".1445..5.7164.\n"
".6....422.2.2.\n"
"26..7.61....43\n"
"..436.2..3.633\n") == 0);
free(board366278642);
board366278642 = NULL;
assert( gamma_move(board, 7, 6, 10) == 1 );
assert( gamma_move(board, 7, 13, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 11 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 7, 3, 5) == 0 );
assert( gamma_busy_fields(board, 7) == 8 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 3, 10, 2) == 0 );


char* board109160284 = gamma_board(board);
assert( board109160284 != NULL );
assert( strcmp(board109160284, 
"...27...2...2.\n"
"5.2..211..572.\n"
"1..54.71...47.\n"
"234112...5....\n"
".3.651261.615.\n"
"..6.5..5.....4\n"
"...3....33..47\n"
".32425.......6\n"
"..3.7.1....4..\n"
".1445..5.7164.\n"
".62...422.2.2.\n"
"26..7.61....43\n"
"..436.2..3.633\n") == 0);
free(board109160284);
board109160284 = NULL;
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_golden_move(board, 4, 0, 12) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 6, 7, 0) == 1 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_move(board, 7, 9, 11) == 1 );
assert( gamma_move(board, 7, 11, 8) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 4, 6, 12) == 1 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );


char* board444491744 = gamma_board(board);
assert( board444491744 != NULL );
assert( strcmp(board444491744, 
"...27.4.2...2.\n"
"5.2..211.7572.\n"
"1..54.71...47.\n"
"234112...5....\n"
".3.651261.615.\n"
"..6.5..5.....4\n"
"...3....33..47\n"
".32425.......6\n"
"..3.7.1....4..\n"
".1445..5.7164.\n"
".62...42222.2.\n"
"26..7461....43\n"
"..436.26.3.633\n") == 0);
free(board444491744);
board444491744 = NULL;
assert( gamma_move(board, 6, 2, 3) == 0 );
assert( gamma_move(board, 7, 10, 9) == 1 );
assert( gamma_move(board, 7, 11, 7) == 1 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_golden_move(board, 1, 9, 2) == 1 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 5, 5, 6) == 1 );
assert( gamma_move(board, 6, 11, 13) == 0 );
assert( gamma_move(board, 6, 9, 11) == 0 );


char* board611056467 = gamma_board(board);
assert( board611056467 != NULL );
assert( strcmp(board611056467, 
"...27.4.2...2.\n"
"5.2..211.7572.\n"
"1..54.71...47.\n"
"234112...57...\n"
".3.651261.615.\n"
"..6.5..5...7.4\n"
"...3.5..33..47\n"
".32425.......6\n"
"..3.731....4..\n"
".1445..5.7164.\n"
".62...42212.2.\n"
"26..7461....43\n"
"..436.26.3.633\n") == 0);
free(board611056467);
board611056467 = NULL;
assert( gamma_move(board, 7, 10, 9) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_free_fields(board, 1) == 87 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 9, 12) == 1 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 9, 5) == 1 );


char* board138731116 = gamma_board(board);
assert( board138731116 != NULL );
assert( strcmp(board138731116, 
"...27.4.23..2.\n"
"5.2..211.7572.\n"
"1..54.71...47.\n"
"234112...57...\n"
".3.651261.615.\n"
"..6.5..5...7.4\n"
"...3.5..33..47\n"
".32425...5...6\n"
"..3.731....4..\n"
".1445..5.7164.\n"
".62...42212.2.\n"
"26..7461....43\n"
"..436.26.3.633\n") == 0);
free(board138731116);
board138731116 = NULL;
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 6, 6, 9) == 1 );
assert( gamma_move(board, 7, 12, 10) == 0 );


char* board189853444 = gamma_board(board);
assert( board189853444 != NULL );
assert( strcmp(board189853444, 
"...27.4.23..2.\n"
"5.2..211.7572.\n"
"1..54.71...47.\n"
"2341126..57...\n"
".3.651261.615.\n"
"..6.5..5...7.4\n"
"...3.5..33..47\n"
".32425...5...6\n"
"..3.731....4..\n"
".1445..5.7164.\n"
".62...42212.2.\n"
"26..7461....43\n"
"..436.26.3.633\n") == 0);
free(board189853444);
board189853444 = NULL;
assert( gamma_move(board, 1, 10, 10) == 1 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_golden_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );


char* board559757585 = gamma_board(board);
assert( board559757585 != NULL );
assert( strcmp(board559757585, 
"...27.4.23..2.\n"
"5.2..211.7572.\n"
"1..54.71..147.\n"
"2341126..57...\n"
".3.651261.615.\n"
"..6.5..5...7.4\n"
"...3.5..33..47\n"
".32425...5...6\n"
"..3.731....4..\n"
".1445..5.7164.\n"
".62...42212.2.\n"
"26..7461....43\n"
"..436.26.3.633\n") == 0);
free(board559757585);
board559757585 = NULL;
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 9, 0) == 1 );
assert( gamma_move(board, 6, 9, 8) == 1 );
assert( gamma_move(board, 6, 0, 3) == 1 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_free_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 6, 6, 10) == 0 );
assert( gamma_move(board, 7, 9, 1) == 1 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 10, 5) == 1 );
assert( gamma_move(board, 7, 9, 13) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 3, 10, 12) == 1 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 7, 7, 9) == 1 );
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_free_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 12, 11) == 0 );
assert( gamma_move(board, 5, 13, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_move(board, 6, 2, 3) == 0 );


char* board237811716 = gamma_board(board);
assert( board237811716 != NULL );
assert( strcmp(board237811716, 
"...27.4.233.2.\n"
"5.2..211.7572.\n"
"14.54.71..147.\n"
"23411267.57...\n"
".3.65126166155\n"
"..6.5..5...7.4\n"
"...3.51.33..47\n"
".32425...56..6\n"
"..3.7313...4..\n"
"61445..517164.\n"
".62...42212.2.\n"
"26..7461.7..43\n"
"..436526.4.633\n") == 0);
free(board237811716);
board237811716 = NULL;
assert( gamma_free_fields(board, 7) == 71 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_free_fields(board, 1) == 71 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_free_fields(board, 5) == 71 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 6, 13, 7) == 0 );
assert( gamma_move(board, 7, 4, 10) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_free_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 6, 9, 4) == 1 );
assert( gamma_move(board, 6, 2, 12) == 1 );
assert( gamma_move(board, 7, 8, 2) == 0 );
assert( gamma_move(board, 7, 9, 0) == 0 );


char* board682768745 = gamma_board(board);
assert( board682768745 != NULL );
assert( strcmp(board682768745, 
"..627.4.233.2.\n"
"5.2..211.7572.\n"
"14.54.71..147.\n"
"23411267.57...\n"
".3.65126166155\n"
"..6.5..5...7.4\n"
"...3.51.33..47\n"
".32425...56..6\n"
"..3.7313.6.4..\n"
"61445..517164.\n"
".62...42212.2.\n"
"26..7461.7.143\n"
"..436526.4.633\n") == 0);
free(board682768745);
board682768745 = NULL;
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_golden_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 5, 5, 10) == 1 );


char* board612513792 = gamma_board(board);
assert( board612513792 != NULL );
assert( strcmp(board612513792, 
"..627.4.233.2.\n"
"5.2..211.7572.\n"
"14.54571..147.\n"
"23411267.57...\n"
".3.65126166155\n"
"..6.5..5...7.4\n"
"...3.51.33..47\n"
".32425...56..6\n"
"..3.7313.6.4..\n"
"61445..517164.\n"
".62...42212.2.\n"
"26..7461.7.143\n"
"..436526.4.633\n") == 0);
free(board612513792);
board612513792 = NULL;
assert( gamma_move(board, 6, 10, 12) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_free_fields(board, 1) == 66 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_golden_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 6, 12, 7) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_move(board, 7, 10, 9) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_free_fields(board, 3) == 66 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 7, 10, 8) == 0 );
assert( gamma_busy_fields(board, 7) == 13 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_golden_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 2, 13, 11) == 1 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_move(board, 7, 12, 3) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_free_fields(board, 1) == 62 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 6, 9, 11) == 0 );
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 7, 5, 7) == 1 );
assert( gamma_golden_move(board, 7, 2, 7) == 1 );
assert( gamma_move(board, 1, 12, 5) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_golden_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 4, 10) == 0 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_move(board, 6, 4, 3) == 0 );
assert( gamma_move(board, 7, 0, 10) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 3, 0, 12) == 1 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_golden_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_free_fields(board, 7) == 57 );
assert( gamma_free_fields(board, 1) == 57 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 11, 6) == 1 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_free_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_free_fields(board, 4) == 54 );
assert( gamma_move(board, 5, 5, 11) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 7, 7, 12) == 1 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 4, 1) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 1, 8, 9) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_free_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 4, 4, 10) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 6, 10, 6) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 12, 1) == 0 );
assert( gamma_move(board, 7, 5, 7) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_free_fields(board, 6) == 49 );
assert( gamma_move(board, 7, 4, 13) == 0 );
assert( gamma_move(board, 7, 6, 7) == 1 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );


char* board219967902 = gamma_board(board);
assert( board219967902 != NULL );
assert( strcmp(board219967902, 
"3.627247233.2.\n"
"5.2..211.75722\n"
"14.54571..147.\n"
"23411267157...\n"
"33.65126366155\n"
"..7.5775...7.4\n"
"...3.511336547\n"
".324251..56.16\n"
"3.337313.6.4..\n"
"614451.517164.\n"
"262..442212.2.\n"
"26..7461.7.143\n"
"..43652634.633\n") == 0);
free(board219967902);
board219967902 = NULL;
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_free_fields(board, 3) == 48 );
assert( gamma_move(board, 4, 2, 10) == 1 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );


char* board370644510 = gamma_board(board);
assert( board370644510 != NULL );
assert( strcmp(board370644510, 
"3.627247233.2.\n"
"5.2..211.75722\n"
"14454571..147.\n"
"23411267157...\n"
"33.65126366155\n"
"..7.5775...7.4\n"
"...3.511336547\n"
".324251..56.16\n"
"3.337313.6.4..\n"
"614451.517164.\n"
"262..442212.2.\n"
"26..7461.7.143\n"
"..43652634.633\n") == 0);
free(board370644510);
board370644510 = NULL;
assert( gamma_move(board, 6, 9, 13) == 0 );
assert( gamma_move(board, 6, 2, 9) == 0 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 17 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 4, 10, 4) == 1 );
assert( gamma_free_fields(board, 4) == 46 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 7, 1, 2) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 5, 4, 11) == 1 );
assert( gamma_free_fields(board, 5) == 45 );
assert( gamma_move(board, 6, 1, 0) == 1 );
assert( gamma_move(board, 7, 1, 2) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 4, 4, 6) == 1 );
assert( gamma_move(board, 5, 4, 13) == 0 );
assert( gamma_move(board, 6, 1, 5) == 0 );
assert( gamma_move(board, 7, 11, 3) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_golden_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 7, 12, 11) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 5, 6, 6) == 0 );
assert( gamma_move(board, 5, 2, 8) == 1 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 13) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );


char* board707423041 = gamma_board(board);
assert( board707423041 != NULL );
assert( strcmp(board707423041, 
"3.627247233.2.\n"
"5.2.5211.75722\n"
"14454571..147.\n"
"23411267157...\n"
"33565126366155\n"
"..7.5775...7.4\n"
"...34511336547\n"
".324251..56.16\n"
"3.337313.644..\n"
"614451.517164.\n"
"262..442212.2.\n"
"26..7461.7.143\n"
".643652634.633\n") == 0);
free(board707423041);
board707423041 = NULL;
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 4, 1, 1) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 5, 3, 7) == 1 );
assert( gamma_free_fields(board, 5) == 11 );
assert( gamma_move(board, 6, 6, 3) == 1 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 22 );
assert( gamma_free_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_free_fields(board, 5) == 10 );
assert( gamma_move(board, 6, 1, 1) == 0 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_golden_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 7, 12, 2) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_move(board, 5, 12, 11) == 0 );
assert( gamma_move(board, 5, 13, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 6, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 17 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );


char* board856977442 = gamma_board(board);
assert( board856977442 != NULL );
assert( strcmp(board856977442, 
"3.627247233.2.\n"
"5.2.5211.75722\n"
"14454571..147.\n"
"234112671573..\n"
"33565126366155\n"
"..755775...7.4\n"
"...34511336547\n"
".3242514.56.16\n"
"3.337313.644..\n"
"6144516517164.\n"
"262..442212.2.\n"
"26..7461.7.143\n"
".643652634.633\n") == 0);
free(board856977442);
board856977442 = NULL;
assert( gamma_move(board, 5, 11, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_free_fields(board, 5) == 10 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 7, 2, 7) == 0 );
assert( gamma_free_fields(board, 7) == 13 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_free_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_golden_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_move(board, 7, 7, 9) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );


char* board329983932 = gamma_board(board);
assert( board329983932 != NULL );
assert( strcmp(board329983932, 
"3.627247233.2.\n"
"5.2.5211.75722\n"
"14454571..147.\n"
"234112671573..\n"
"33565126366155\n"
"..755775...7.4\n"
"...34511336547\n"
".3242514.56.16\n"
"31337313.644..\n"
"6144516517164.\n"
"262..442212.2.\n"
"26..7461.7.143\n"
"3643652634.633\n") == 0);
free(board329983932);
board329983932 = NULL;
assert( gamma_move(board, 6, 12, 13) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_busy_fields(board, 7) == 17 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_free_fields(board, 2) == 13 );


char* board101380454 = gamma_board(board);
assert( board101380454 != NULL );
assert( strcmp(board101380454, 
"3.627247233.2.\n"
"5.2.5211.75722\n"
"14454571..147.\n"
"234112671573..\n"
"33565126366155\n"
"..755775...7.4\n"
"...34511336547\n"
".3242514.56.16\n"
"31337313.644..\n"
"6144516517164.\n"
"262..442212.2.\n"
"26..7461.7.143\n"
"3643652634.633\n") == 0);
free(board101380454);
board101380454 = NULL;
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 5, 8, 10) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 7, 12, 13) == 0 );
assert( gamma_move(board, 7, 7, 9) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 5, 12, 10) == 0 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 9, 13) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 2, 13, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 7, 11, 7) == 0 );
assert( gamma_free_fields(board, 7) == 13 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_golden_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 6, 4, 2) == 0 );
assert( gamma_move(board, 7, 10, 2) == 0 );


gamma_delete(board);

    return 0;
}
