#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 145419611
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(11, 15, 3, 34);
assert( board != NULL );


assert( gamma_move(board, 1, 4, 9) == 1 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 3, 10, 8) == 1 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_move(board, 1, 4, 8) == 1 );
assert( gamma_free_fields(board, 1) == 160 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_move(board, 2, 9, 14) == 1 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_free_fields(board, 1) == 158 );
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_golden_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 1, 9, 6) == 1 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 1, 7, 14) == 1 );
assert( gamma_free_fields(board, 1) == 149 );
assert( gamma_move(board, 2, 4, 13) == 1 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_free_fields(board, 1) == 144 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_golden_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_golden_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 1, 5, 7) == 1 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_golden_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 3, 14) == 0 );


char* board115911652 = gamma_board(board);
assert( board115911652 != NULL );
assert( strcmp(board115911652, 
"...2...1.2.\n"
"...22.1.3.2\n"
".1..2......\n"
".....1.....\n"
".....23....\n"
"33.31......\n"
"....1.1.2.3\n"
"....31..3..\n"
".....3...1.\n"
".....1.....\n"
"..........2\n"
"3......2...\n"
"..2.1.2.2..\n"
"...........\n"
"...12..3...\n") == 0);
free(board115911652);
board115911652 = NULL;
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_free_fields(board, 1) == 122 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 1, 10, 10) == 1 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_move(board, 2, 7, 10) == 1 );
assert( gamma_golden_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 3, 1, 14) == 1 );


char* board183764149 = gamma_board(board);
assert( board183764149 != NULL );
assert( strcmp(board183764149, 
".3.2...1.2.\n"
"...22.1.3.2\n"
".1..2......\n"
"2....1.....\n"
".....232..1\n"
"33231......\n"
"....1.1.2.3\n"
"....31.33..\n"
".....3...1.\n"
".....11....\n"
"......3...2\n"
"3......2...\n"
"2.2.1.2.2.2\n"
".1.........\n"
"3..12..3...\n") == 0);
free(board183764149);
board183764149 = NULL;
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_golden_move(board, 3, 11, 5) == 0 );


char* board690921549 = gamma_board(board);
assert( board690921549 != NULL );
assert( strcmp(board690921549, 
".3.2...1.2.\n"
"...22.1.3.2\n"
".1..2.2....\n"
"2....1.....\n"
".....232.31\n"
"33231....3.\n"
"....1.1.2.3\n"
"....31.33..\n"
".....3...1.\n"
".....11....\n"
"......3...2\n"
"3....1.2...\n"
"2.2.1.2.2.2\n"
".1.........\n"
"3..12..3...\n") == 0);
free(board690921549);
board690921549 = NULL;
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 2, 3, 11) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 2, 0, 10) == 1 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_free_fields(board, 1) == 105 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 7, 1) == 1 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 1, 6, 14) == 1 );
assert( gamma_golden_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_move(board, 3, 4, 11) == 1 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_golden_move(board, 1, 12, 4) == 0 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 5, 2) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 1, 9, 13) == 1 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_free_fields(board, 2) == 84 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_golden_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 1, 6, 1) == 1 );
assert( gamma_move(board, 1, 10, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 29 );


char* board224982078 = gamma_board(board);
assert( board224982078 != NULL );
assert( strcmp(board224982078, 
".3.2..11.2.\n"
"...22.1.312\n"
".1..2.2..11\n"
"2..231.....\n"
"2....232231\n"
"33231..3.3.\n"
"....1.1.2.3\n"
"1...31.33..\n"
".....3...1.\n"
"22...11..2.\n"
".22.1.3...2\n"
"32..11.21..\n"
"222112212.2\n"
".1....113..\n"
"33312.23..1\n") == 0);
free(board224982078);
board224982078 = NULL;
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board908992947 = gamma_board(board);
assert( board908992947 != NULL );
assert( strcmp(board908992947, 
".3.2..11.2.\n"
"...22.1.312\n"
".1..2.2..11\n"
"2..231.....\n"
"2....232231\n"
"33231..3.3.\n"
"....1.1.2.3\n"
"1...31.33..\n"
".....3...1.\n"
"22...11..2.\n"
".22.1.3...2\n"
"32..11321..\n"
"222112212.2\n"
".1....113..\n"
"33312.23..1\n") == 0);
free(board908992947);
board908992947 = NULL;
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_free_fields(board, 3) == 81 );


char* board950739957 = gamma_board(board);
assert( board950739957 != NULL );
assert( strcmp(board950739957, 
".3.2..11.2.\n"
"...22.1.312\n"
".1..2.2..11\n"
"2..231.....\n"
"2....232231\n"
"33231..3.3.\n"
"....1.1.2.3\n"
"1...31.33..\n"
".....3...1.\n"
"22...11..2.\n"
".22.1.3...2\n"
"32..11321..\n"
"222112212.2\n"
".1....113..\n"
"33312.23..1\n") == 0);
free(board950739957);
board950739957 = NULL;
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_free_fields(board, 1) == 81 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 5, 11) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 5, 8) == 1 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_golden_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_free_fields(board, 3) == 75 );


char* board844736464 = gamma_board(board);
assert( board844736464 != NULL );
assert( strcmp(board844736464, 
".3.2..11.2.\n"
"...22.1.312\n"
".1..2.2..11\n"
"2..231.....\n"
"2....232231\n"
"33231..3.3.\n"
"....121.2.3\n"
"13..31.33..\n"
".....32..1.\n"
"22...11..2.\n"
".22.1.3...2\n"
"32.2113212.\n"
"222112212.2\n"
".1....113.2\n"
"33312.23..1\n") == 0);
free(board844736464);
board844736464 = NULL;
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 1, 10) == 1 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 30 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );


char* board302924451 = gamma_board(board);
assert( board302924451 != NULL );
assert( strcmp(board302924451, 
".3.23.11.2.\n"
"...22.1.312\n"
".1..2.2..11\n"
"2..231.....\n"
"23...232231\n"
"33231..3.3.\n"
"....121.2.3\n"
"13..31.33..\n"
".....32..1.\n"
"22...11..2.\n"
".22.1.3...2\n"
"32.2113212.\n"
"222112212.2\n"
".1....113.2\n"
"33312123..1\n") == 0);
free(board302924451);
board302924451 = NULL;
assert( gamma_move(board, 1, 1, 11) == 1 );


char* board596694183 = gamma_board(board);
assert( board596694183 != NULL );
assert( strcmp(board596694183, 
".3.23.11.2.\n"
"...22.1.312\n"
".1..2.2..11\n"
"21.231.....\n"
"23...232231\n"
"33231..3.3.\n"
"....121.2.3\n"
"13..31.33..\n"
".....32..1.\n"
"22...11..2.\n"
".22.1.3...2\n"
"32.2113212.\n"
"222112212.2\n"
".1....113.2\n"
"33312123..1\n") == 0);
free(board596694183);
board596694183 = NULL;
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_free_fields(board, 2) == 71 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_free_fields(board, 3) == 70 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 3, 5, 13) == 1 );


char* board424899157 = gamma_board(board);
assert( board424899157 != NULL );
assert( strcmp(board424899157, 
".3.23.11.2.\n"
"...2231.312\n"
".1..2.2..11\n"
"21.231.....\n"
"23...232231\n"
"33231..3.3.\n"
"....121.2.3\n"
"13..31.33..\n"
".....32..1.\n"
"22...11..2.\n"
".22.1.3.3.2\n"
"32.2113212.\n"
"222112212.2\n"
".1....113.2\n"
"33312123..1\n") == 0);
free(board424899157);
board424899157 = NULL;
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_golden_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_free_fields(board, 2) == 63 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_move(board, 3, 8, 12) == 1 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_free_fields(board, 1) == 61 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 1, 3, 8) == 1 );
assert( gamma_free_fields(board, 1) == 60 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_free_fields(board, 3) == 60 );
assert( gamma_golden_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_golden_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 3, 8, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 3, 5) == 1 );


char* board250843030 = gamma_board(board);
assert( board250843030 != NULL );
assert( strcmp(board250843030, 
"13.23.1132.\n"
"...2231.312\n"
".12.222.311\n"
"21.231.....\n"
"23...232231\n"
"33231..323.\n"
"...1121.2.3\n"
"132.31333..\n"
"23...32..1.\n"
"22.1211.22.\n"
"12221.3.3.2\n"
"32.21132121\n"
"222112212.2\n"
"31....113.2\n"
"33312123..1\n") == 0);
free(board250843030);
board250843030 = NULL;
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 45 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_golden_move(board, 2, 7, 9) == 1 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_golden_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 1, 5, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 1, 10) == 0 );


char* board734459756 = gamma_board(board);
assert( board734459756 != NULL );
assert( strcmp(board734459756, 
"13.23.1132.\n"
".3.2231.312\n"
".12.222.311\n"
"21.231...3.\n"
"23...232231\n"
"332313.223.\n"
"...1121.2.3\n"
"132.313331.\n"
"23...32..1.\n"
"22.1211.22.\n"
"1222123.3.2\n"
"32.21132121\n"
"22211221232\n"
"31.111113.2\n"
"333121231.1\n") == 0);
free(board734459756);
board734459756 = NULL;
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 3, 6, 9) == 1 );
assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_golden_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_free_fields(board, 2) == 39 );
assert( gamma_golden_move(board, 2, 12, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );


char* board450029755 = gamma_board(board);
assert( board450029755 != NULL );
assert( strcmp(board450029755, 
"13.23.1132.\n"
".3.2231.312\n"
".12.222.311\n"
"21.231...3.\n"
"23...232231\n"
"3323133223.\n"
"...1121.2.3\n"
"1321313331.\n"
"233..32..1.\n"
"22.1211.22.\n"
"1222123.3.2\n"
"32.21132121\n"
"22211221232\n"
"31.111113.2\n"
"333121231.1\n") == 0);
free(board450029755);
board450029755 = NULL;
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 47 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 38 );
assert( gamma_free_fields(board, 3) == 38 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 47 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 48 );
assert( gamma_busy_fields(board, 3) == 38 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 42 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_golden_move(board, 1, 7, 1) == 0 );
assert( gamma_golden_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 48 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_free_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_free_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_free_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_free_fields(board, 3) == 32 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_golden_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_free_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 1, 2, 1) == 1 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_free_fields(board, 3) == 31 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 2, 0, 13) == 1 );
assert( gamma_free_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 7, 12) == 1 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 10, 11) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 43 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 5, 14) == 1 );
assert( gamma_golden_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_golden_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 44 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_free_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_free_fields(board, 3) == 23 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_free_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );


gamma_delete(board);

    return 0;
}
