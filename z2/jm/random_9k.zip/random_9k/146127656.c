#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 146127656
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(7, 17, 8, 15);
assert( board != NULL );


assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_free_fields(board, 1) == 118 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 3, 3, 15) == 1 );


char* board740727075 = gamma_board(board);
assert( board740727075 != NULL );
assert( strcmp(board740727075, 
".......\n"
"...3...\n"
".......\n"
".......\n"
".......\n"
".......\n"
".......\n"
".......\n"
".......\n"
"...1...\n"
".......\n"
".......\n"
".......\n"
".......\n"
"....2..\n"
".......\n"
".......\n") == 0);
free(board740727075);
board740727075 = NULL;
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 5, 15, 1) == 0 );
assert( gamma_move(board, 5, 5, 9) == 1 );
assert( gamma_move(board, 6, 13, 6) == 0 );
assert( gamma_move(board, 7, 5, 3) == 1 );
assert( gamma_move(board, 7, 3, 6) == 1 );
assert( gamma_move(board, 8, 16, 6) == 0 );
assert( gamma_move(board, 8, 0, 1) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 2, 1, 15) == 1 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 4, 4, 15) == 1 );
assert( gamma_move(board, 5, 4, 6) == 1 );
assert( gamma_move(board, 6, 1, 11) == 1 );
assert( gamma_move(board, 7, 5, 1) == 1 );
assert( gamma_move(board, 8, 9, 3) == 0 );
assert( gamma_move(board, 8, 6, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 1 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 3, 0, 8) == 1 );


char* board312281066 = gamma_board(board);
assert( board312281066 != NULL );
assert( strcmp(board312281066, 
".......\n"
".2.34..\n"
".......\n"
".......\n"
".......\n"
".6..1..\n"
".......\n"
".....5.\n"
"3......\n"
"...1...\n"
"...75..\n"
"1......\n"
"....1..\n"
".....74\n"
"....21.\n"
"8....72\n"
".......\n") == 0);
free(board312281066);
board312281066 = NULL;
assert( gamma_move(board, 4, 1, 12) == 1 );
assert( gamma_move(board, 4, 4, 14) == 1 );
assert( gamma_busy_fields(board, 4) == 4 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 6) == 1 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 4, 2) == 0 );
assert( gamma_move(board, 7, 2, 3) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_golden_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_free_fields(board, 2) == 95 );


char* board164758909 = gamma_board(board);
assert( board164758909 != NULL );
assert( strcmp(board164758909, 
".......\n"
".2.34..\n"
"....4..\n"
".......\n"
".4.....\n"
".6..1..\n"
".......\n"
".....5.\n"
"3......\n"
"...1...\n"
"..575..\n"
"1......\n"
"1...1..\n"
"..7..74\n"
"....21.\n"
"8....72\n"
".......\n") == 0);
free(board164758909);
board164758909 = NULL;
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_golden_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_move(board, 6, 1, 4) == 1 );
assert( gamma_move(board, 7, 2, 7) == 1 );


char* board987475648 = gamma_board(board);
assert( board987475648 != NULL );
assert( strcmp(board987475648, 
".......\n"
".2.34..\n"
"....4..\n"
".......\n"
".4.....\n"
".6..1..\n"
".......\n"
".....5.\n"
"3......\n"
"..71...\n"
"..575..\n"
"1......\n"
"16..1..\n"
"..75.74\n"
"....21.\n"
"8....72\n"
".......\n") == 0);
free(board987475648);
board987475648 = NULL;
assert( gamma_move(board, 8, 4, 8) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 3, 3, 13) == 1 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 6, 1, 3) == 1 );
assert( gamma_move(board, 6, 1, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_move(board, 7, 0, 1) == 0 );
assert( gamma_move(board, 7, 1, 15) == 0 );
assert( gamma_move(board, 8, 1, 14) == 1 );
assert( gamma_busy_fields(board, 8) == 3 );
assert( gamma_free_fields(board, 8) == 84 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 2, 5, 15) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 4, 14, 2) == 0 );
assert( gamma_move(board, 4, 1, 16) == 1 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_move(board, 8, 16, 3) == 0 );
assert( gamma_move(board, 8, 1, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 3 );


char* board926930771 = gamma_board(board);
assert( board926930771 != NULL );
assert( strcmp(board926930771, 
".4.....\n"
".2.342.\n"
".8..4..\n"
"...3...\n"
".4.....\n"
".6..1..\n"
".......\n"
".....5.\n"
"3...8..\n"
"..71...\n"
"..575..\n"
"1.4....\n"
"16..1..\n"
".675.74\n"
"5.4.21.\n"
"8.2..72\n"
"...3...\n") == 0);
free(board926930771);
board926930771 = NULL;
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_move(board, 4, 3, 1) == 1 );
assert( gamma_move(board, 4, 4, 9) == 1 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_move(board, 6, 3, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_move(board, 7, 12, 2) == 0 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_move(board, 8, 12, 0) == 0 );
assert( gamma_free_fields(board, 8) == 77 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 5, 13, 4) == 0 );
assert( gamma_free_fields(board, 5) == 74 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 7, 1, 2) == 1 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 2, 7) == 0 );
assert( gamma_move(board, 8, 2, 10) == 1 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_move(board, 1, 3, 8) == 1 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_move(board, 7, 3, 4) == 1 );
assert( gamma_move(board, 8, 14, 5) == 0 );
assert( gamma_move(board, 8, 2, 12) == 1 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_golden_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_free_fields(board, 4) == 65 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_free_fields(board, 5) == 65 );
assert( gamma_move(board, 6, 5, 15) == 0 );
assert( gamma_move(board, 6, 6, 11) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 6, 6) == 1 );
assert( gamma_move(board, 7, 3, 2) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 6) == 1 );
assert( gamma_move(board, 8, 3, 7) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 4, 1) == 1 );
assert( gamma_golden_move(board, 3, 5, 2) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 0, 13) == 1 );
assert( gamma_free_fields(board, 4) == 59 );
assert( gamma_move(board, 5, 3, 5) == 1 );
assert( gamma_free_fields(board, 5) == 58 );
assert( gamma_move(board, 6, 15, 6) == 0 );
assert( gamma_move(board, 6, 1, 7) == 1 );
assert( gamma_busy_fields(board, 6) == 5 );
assert( gamma_move(board, 7, 10, 6) == 0 );
assert( gamma_move(board, 7, 5, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 8, 10, 4) == 0 );
assert( gamma_move(board, 8, 3, 13) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_golden_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 15, 2) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );


char* board819616069 = gamma_board(board);
assert( board819616069 != NULL );
assert( strcmp(board819616069, 
".4.....\n"
".2.342.\n"
"38..4..\n"
"4.23...\n"
".48....\n"
".6.11.6\n"
"..8....\n"
"..3.45.\n"
"3.218..\n"
".671...\n"
".857537\n"
"1.454..\n"
"16.71..\n"
".675.74\n"
"574723.\n"
"8.24372\n"
"...3.21\n") == 0);
free(board819616069);
board819616069 = NULL;
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_golden_move(board, 8, 7, 1) == 0 );
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 3, 6, 8) == 1 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board906952002 = gamma_board(board);
assert( board906952002 != NULL );
assert( strcmp(board906952002, 
".4.....\n"
".2.342.\n"
"38..4..\n"
"4.23...\n"
".48....\n"
".6.11.6\n"
"..8....\n"
"..3.45.\n"
"3.218.3\n"
".671...\n"
".857537\n"
"1.454.2\n"
"16.71..\n"
".675.74\n"
"574723.\n"
"8.24372\n"
"...3221\n") == 0);
free(board906952002);
board906952002 = NULL;
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 6, 16, 3) == 0 );
assert( gamma_move(board, 7, 0, 1) == 0 );
assert( gamma_free_fields(board, 7) == 54 );
assert( gamma_move(board, 8, 4, 5) == 0 );
assert( gamma_move(board, 8, 0, 0) == 1 );
assert( gamma_golden_move(board, 8, 3, 3) == 1 );
assert( gamma_move(board, 1, 3, 16) == 1 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 4, 1, 1) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_golden_move(board, 5, 4, 1) == 1 );
assert( gamma_move(board, 6, 15, 2) == 0 );
assert( gamma_move(board, 6, 1, 14) == 0 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 6, 4) == 1 );
assert( gamma_free_fields(board, 8) == 49 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 5, 4, 13) == 1 );
assert( gamma_free_fields(board, 5) == 48 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 3, 0) == 0 );
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 16, 2) == 0 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_free_fields(board, 8) == 48 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 0, 16) == 1 );


char* board610125536 = gamma_board(board);
assert( board610125536 != NULL );
assert( strcmp(board610125536, 
"44.1...\n"
".2.342.\n"
"38..4..\n"
"4.235..\n"
".48....\n"
".6.11.6\n"
"..8....\n"
"..3.45.\n"
"3.218.3\n"
".671...\n"
".857537\n"
"15454.2\n"
"16.71.8\n"
".678.74\n"
"574723.\n"
"8424572\n"
"8..3221\n") == 0);
free(board610125536);
board610125536 = NULL;
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 6, 0, 15) == 1 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 7, 3, 8) == 0 );
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_move(board, 8, 5, 0) == 0 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_golden_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 4, 1, 8) == 1 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_move(board, 6, 14, 5) == 0 );
assert( gamma_free_fields(board, 6) == 44 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_move(board, 7, 1, 6) == 0 );
assert( gamma_move(board, 8, 12, 4) == 0 );
assert( gamma_move(board, 8, 6, 11) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 1, 3, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_free_fields(board, 2) == 43 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_golden_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 6, 1, 9) == 1 );
assert( gamma_move(board, 6, 2, 14) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_move(board, 7, 0, 10) == 1 );
assert( gamma_free_fields(board, 7) == 40 );
assert( gamma_move(board, 8, 15, 2) == 0 );
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_move(board, 6, 15, 6) == 0 );
assert( gamma_move(board, 8, 10, 1) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_golden_move(board, 2, 1, 0) == 0 );


char* board941744040 = gamma_board(board);
assert( board941744040 != NULL );
assert( strcmp(board941744040, 
"44.1...\n"
"62.342.\n"
"386.4..\n"
"4.235..\n"
".481...\n"
".6.11.6\n"
"7.8....\n"
"463.45.\n"
"34218.3\n"
"1671...\n"
".857537\n"
"15454.2\n"
"16.71.8\n"
".678.74\n"
"574723.\n"
"8424572\n"
"8..3221\n") == 0);
free(board941744040);
board941744040 = NULL;
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 5, 4, 4) == 0 );
assert( gamma_move(board, 6, 13, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 16, 6) == 0 );
assert( gamma_move(board, 7, 0, 0) == 0 );
assert( gamma_move(board, 8, 8, 5) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );


char* board812492356 = gamma_board(board);
assert( board812492356 != NULL );
assert( strcmp(board812492356, 
"44.1...\n"
"62.342.\n"
"386.4..\n"
"4.235..\n"
".481...\n"
".6.11.6\n"
"7.8....\n"
"463.45.\n"
"34218.3\n"
"1671...\n"
".857537\n"
"15454.2\n"
"16.71.8\n"
".678.74\n"
"574723.\n"
"8424572\n"
"8..3221\n") == 0);
free(board812492356);
board812492356 = NULL;
assert( gamma_move(board, 1, 5, 13) == 1 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_golden_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 4, 5, 12) == 1 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_move(board, 5, 6, 9) == 1 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 6, 3, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 8 );
assert( gamma_free_fields(board, 6) == 36 );
assert( gamma_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 7, 4, 5) == 0 );
assert( gamma_move(board, 8, 6, 0) == 0 );
assert( gamma_move(board, 8, 2, 6) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_free_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_golden_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 14, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 0, 11) == 1 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 6, 3, 3) == 0 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 7, 3, 10) == 1 );
assert( gamma_move(board, 8, 0, 11) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_free_fields(board, 1) == 34 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_move(board, 5, 5, 7) == 1 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_move(board, 6, 4, 15) == 0 );


char* board606116558 = gamma_board(board);
assert( board606116558 != NULL );
assert( strcmp(board606116558, 
"44.1...\n"
"62.342.\n"
"386.4..\n"
"4.2351.\n"
".481.4.\n"
"56411.6\n"
"7.87...\n"
"463.455\n"
"34218.3\n"
"1671.5.\n"
".852537\n"
"15454.2\n"
"16.71.8\n"
".678.74\n"
"574723.\n"
"8424572\n"
"8..3221\n") == 0);
free(board606116558);
board606116558 = NULL;
assert( gamma_move(board, 7, 3, 10) == 0 );
assert( gamma_move(board, 8, 6, 0) == 0 );
assert( gamma_move(board, 8, 3, 5) == 0 );
assert( gamma_busy_fields(board, 8) == 9 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 16, 6) == 0 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_move(board, 6, 13, 6) == 0 );
assert( gamma_move(board, 6, 3, 16) == 0 );
assert( gamma_move(board, 7, 6, 14) == 1 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 8, 13, 6) == 0 );
assert( gamma_move(board, 8, 3, 5) == 0 );


char* board469117483 = gamma_board(board);
assert( board469117483 != NULL );
assert( strcmp(board469117483, 
"44.1...\n"
"62.342.\n"
"386.4.7\n"
"4.2351.\n"
".48124.\n"
"56411.6\n"
"7.87...\n"
"463.455\n"
"34218.3\n"
"1671.5.\n"
".852537\n"
"15454.2\n"
"16.71.8\n"
".678.74\n"
"574723.\n"
"8424572\n"
"8..3221\n") == 0);
free(board469117483);
board469117483 = NULL;
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 0, 16) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_free_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 6, 12) == 1 );
assert( gamma_free_fields(board, 6) == 28 );
assert( gamma_move(board, 7, 4, 14) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 5, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 9 );
assert( gamma_golden_move(board, 8, 8, 6) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_move(board, 7, 14, 5) == 0 );
assert( gamma_golden_move(board, 7, 8, 4) == 0 );
assert( gamma_move(board, 8, 5, 13) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_free_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 6, 16, 5) == 0 );
assert( gamma_move(board, 6, 4, 15) == 0 );
assert( gamma_busy_fields(board, 6) == 9 );
assert( gamma_move(board, 7, 13, 6) == 0 );
assert( gamma_move(board, 8, 10, 5) == 0 );
assert( gamma_move(board, 8, 1, 2) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_free_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_free_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 6, 13) == 1 );
assert( gamma_move(board, 5, 6, 6) == 0 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 2, 5) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_free_fields(board, 3) == 25 );
assert( gamma_golden_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_free_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 10, 6) == 0 );
assert( gamma_move(board, 5, 4, 11) == 0 );
assert( gamma_move(board, 6, 11, 5) == 0 );
assert( gamma_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 8, 14, 3) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_move(board, 6, 7, 6) == 0 );
assert( gamma_move(board, 6, 0, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 10 );


gamma_delete(board);

    return 0;
}
