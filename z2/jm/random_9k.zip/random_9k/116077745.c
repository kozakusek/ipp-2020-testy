#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 116077745
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(7, 10, 9, 6);
assert( board != NULL );


assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_free_fields(board, 2) == 66 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_move(board, 3, 0, 6) == 1 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 4, 4, 0) == 1 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 5, 9) == 1 );
assert( gamma_move(board, 6, 2, 7) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 4) == 0 );
assert( gamma_move(board, 8, 2, 2) == 1 );
assert( gamma_free_fields(board, 8) == 59 );
assert( gamma_move(board, 9, 4, 2) == 1 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 4, 5, 0) == 1 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 6, 4, 7) == 1 );
assert( gamma_move(board, 6, 5, 9) == 0 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_move(board, 8, 4, 9) == 1 );
assert( gamma_move(board, 9, 4, 5) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );


char* board978259326 = gamma_board(board);
assert( board978259326 != NULL );
assert( strcmp(board978259326, 
"2..186.\n"
"....2..\n"
"..6.6..\n"
"3.....1\n"
"..3.3..\n"
".......\n"
".2...4.\n"
"5.8.9..\n"
"....1..\n"
"....44.\n") == 0);
free(board978259326);
board978259326 = NULL;
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 7, 2, 3) == 1 );
assert( gamma_free_fields(board, 7) == 50 );


char* board341330183 = gamma_board(board);
assert( board341330183 != NULL );
assert( strcmp(board341330183, 
"2..186.\n"
"....2..\n"
"..6.6..\n"
"3.....1\n"
"..3.3..\n"
".......\n"
".27..4.\n"
"5.8.9..\n"
"....1..\n"
"....44.\n") == 0);
free(board341330183);
board341330183 = NULL;
assert( gamma_move(board, 8, 2, 1) == 1 );
assert( gamma_move(board, 8, 4, 3) == 1 );
assert( gamma_move(board, 9, 0, 5) == 1 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 5, 6, 1) == 1 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_move(board, 7, 2, 7) == 0 );
assert( gamma_free_fields(board, 7) == 42 );
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_move(board, 8, 3, 4) == 1 );
assert( gamma_golden_move(board, 9, 0, 4) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 4 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 6, 3, 1) == 1 );
assert( gamma_move(board, 7, 6, 3) == 1 );
assert( gamma_move(board, 7, 1, 8) == 1 );


char* board420954952 = gamma_board(board);
assert( board420954952 != NULL );
assert( strcmp(board420954952, 
"2..186.\n"
".7.22.1\n"
"..6.6.3\n"
"3.....1\n"
"9.3.3..\n"
"...8...\n"
".27.847\n"
"5.8.9..\n"
"..86145\n"
"7...44.\n") == 0);
free(board420954952);
board420954952 = NULL;
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_free_fields(board, 8) == 37 );
assert( gamma_move(board, 9, 1, 6) == 1 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_free_fields(board, 2) == 35 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board936465132 = gamma_board(board);
assert( board936465132 != NULL );
assert( strcmp(board936465132, 
"2..186.\n"
".7.22.1\n"
"..6.6.3\n"
"39....1\n"
"9.3.3..\n"
"..28...\n"
".27.847\n"
"5.8.9..\n"
"..86145\n"
"7...44.\n") == 0);
free(board936465132);
board936465132 = NULL;
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 6, 1) == 0 );
assert( gamma_move(board, 1, 5, 6) == 1 );
assert( gamma_move(board, 1, 5, 7) == 1 );
assert( gamma_move(board, 2, 7, 3) == 0 );


char* board748164959 = gamma_board(board);
assert( board748164959 != NULL );
assert( strcmp(board748164959, 
"2..186.\n"
".7.22.1\n"
"..6.613\n"
"39...11\n"
"9.3.3..\n"
"..28...\n"
".27.847\n"
"5.8.9..\n"
"..86145\n"
"7...44.\n") == 0);
free(board748164959);
board748164959 = NULL;
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 5, 3, 1) == 0 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 7, 3, 7) == 1 );
assert( gamma_move(board, 8, 0, 9) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );


char* board239837895 = gamma_board(board);
assert( board239837895 != NULL );
assert( strcmp(board239837895, 
"2..186.\n"
".7.22.1\n"
"..67613\n"
"39...11\n"
"9.3.33.\n"
"..28...\n"
".274847\n"
"5.8.9..\n"
"..86145\n"
"7...44.\n") == 0);
free(board239837895);
board239837895 = NULL;
assert( gamma_move(board, 9, 2, 6) == 1 );


char* board531200524 = gamma_board(board);
assert( board531200524 != NULL );
assert( strcmp(board531200524, 
"2..186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"9.3.33.\n"
"..28...\n"
".274847\n"
"5.8.9..\n"
"..86145\n"
"7...44.\n") == 0);
free(board531200524);
board531200524 = NULL;
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_free_fields(board, 5) == 27 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 0) == 0 );
assert( gamma_move(board, 8, 9, 1) == 0 );
assert( gamma_move(board, 8, 1, 2) == 1 );
assert( gamma_busy_fields(board, 8) == 6 );
assert( gamma_golden_move(board, 8, 2, 0) == 0 );
assert( gamma_move(board, 9, 3, 8) == 0 );
assert( gamma_free_fields(board, 9) == 26 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 9) == 0 );


char* board910881123 = gamma_board(board);
assert( board910881123 != NULL );
assert( strcmp(board910881123, 
"2..186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"9.3.33.\n"
"..284..\n"
".274847\n"
"588.9..\n"
"..86145\n"
"72..44.\n") == 0);
free(board910881123);
board910881123 = NULL;
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 4, 4) == 0 );
assert( gamma_move(board, 6, 0, 1) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 3, 4) == 1 );
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_move(board, 9, 2, 6) == 0 );


char* board193987887 = gamma_board(board);
assert( board193987887 != NULL );
assert( strcmp(board193987887, 
"2..186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"9.3.33.\n"
"..264..\n"
".274847\n"
"588.9..\n"
"6.86145\n"
"72..44.\n") == 0);
free(board193987887);
board193987887 = NULL;
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );


char* board309850670 = gamma_board(board);
assert( board309850670 != NULL );
assert( strcmp(board309850670, 
"2..186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"9.3.33.\n"
"..264..\n"
".274847\n"
"588.9..\n"
"6.86145\n"
"721.44.\n") == 0);
free(board309850670);
board309850670 = NULL;
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 6 );
assert( gamma_move(board, 5, 8, 2) == 0 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 6, 2, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 7, 6, 5) == 1 );
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_move(board, 8, 1, 0) == 0 );
assert( gamma_busy_fields(board, 8) == 5 );
assert( gamma_move(board, 9, 4, 1) == 0 );
assert( gamma_golden_move(board, 9, 2, 0) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 1) == 0 );


char* board463194143 = gamma_board(board);
assert( board463194143 != NULL );
assert( strcmp(board463194143, 
"2..186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"9.3.337\n"
"..264..\n"
".274847\n"
"588.9..\n"
"6.86145\n"
"729.44.\n") == 0);
free(board463194143);
board463194143 = NULL;
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_free_fields(board, 4) == 22 );


char* board486938696 = gamma_board(board);
assert( board486938696 != NULL );
assert( strcmp(board486938696, 
"24.186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"9.3.337\n"
"..264..\n"
".274847\n"
"588.9..\n"
"6.86145\n"
"729.44.\n") == 0);
free(board486938696);
board486938696 = NULL;
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 3, 2) == 1 );
assert( gamma_move(board, 6, 4, 5) == 0 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_move(board, 7, 0, 9) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 1) == 0 );
assert( gamma_move(board, 8, 2, 0) == 0 );
assert( gamma_move(board, 9, 1, 1) == 1 );
assert( gamma_move(board, 9, 1, 0) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 6, 3, 7) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 7, 2, 9) == 0 );
assert( gamma_move(board, 8, 3, 0) == 1 );
assert( gamma_move(board, 9, 5, 1) == 0 );
assert( gamma_move(board, 9, 1, 5) == 1 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_free_fields(board, 2) == 5 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 6 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_move(board, 8, 6, 4) == 1 );
assert( gamma_move(board, 8, 0, 5) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 8, 0) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_free_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_move(board, 8, 6, 4) == 0 );
assert( gamma_move(board, 8, 4, 0) == 0 );
assert( gamma_move(board, 9, 8, 0) == 0 );
assert( gamma_move(board, 9, 6, 8) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );


char* board115166713 = gamma_board(board);
assert( board115166713 != NULL );
assert( strcmp(board115166713, 
"24.186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"993.337\n"
"2.264.8\n"
".274847\n"
"58859..\n"
"6986145\n"
"729844.\n") == 0);
free(board115166713);
board115166713 = NULL;
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 7, 2, 4) == 0 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_move(board, 8, 4, 4) == 0 );
assert( gamma_free_fields(board, 8) == 16 );
assert( gamma_move(board, 9, 8, 5) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );


char* board506273487 = gamma_board(board);
assert( board506273487 != NULL );
assert( strcmp(board506273487, 
"24.186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"993.337\n"
"2.264.8\n"
".274847\n"
"58859..\n"
"6986145\n"
"729844.\n") == 0);
free(board506273487);
board506273487 = NULL;
assert( gamma_move(board, 2, 3, 0) == 0 );


char* board251428087 = gamma_board(board);
assert( board251428087 != NULL );
assert( strcmp(board251428087, 
"24.186.\n"
".7.22.1\n"
"..67613\n"
"399..11\n"
"993.337\n"
"2.264.8\n"
".274847\n"
"58859..\n"
"6986145\n"
"729844.\n") == 0);
free(board251428087);
board251428087 = NULL;
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );


gamma_delete(board);

    return 0;
}
