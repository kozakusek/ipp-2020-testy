#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 144412899
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(11, 18, 4, 29);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_move(board, 4, 7, 9) == 1 );
assert( gamma_move(board, 1, 10, 12) == 1 );
assert( gamma_move(board, 1, 1, 14) == 1 );
assert( gamma_golden_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 2, 9, 17) == 1 );
assert( gamma_move(board, 3, 0, 13) == 1 );
assert( gamma_move(board, 3, 8, 11) == 1 );
assert( gamma_move(board, 4, 6, 8) == 1 );
assert( gamma_move(board, 4, 2, 1) == 1 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 11) == 1 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 2, 9, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 4, 4, 15) == 1 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 3, 8, 16) == 1 );
assert( gamma_move(board, 4, 3, 5) == 1 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_move(board, 1, 16, 2) == 0 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_move(board, 3, 16, 4) == 0 );
assert( gamma_free_fields(board, 3) == 175 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 4, 8, 2) == 1 );
assert( gamma_move(board, 1, 5, 12) == 1 );
assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 1, 9, 15) == 1 );


char* board687745522 = gamma_board(board);
assert( board687745522 != NULL );
assert( strcmp(board687745522, 
".........2.\n"
"........3..\n"
"....4....1.\n"
".1..3......\n"
"3........2.\n"
".....1....1\n"
"...1.1..32.\n"
"...........\n"
"12..2..4...\n"
"......4....\n"
"....12.....\n"
".43......3.\n"
"...4..2....\n"
"...........\n"
".........3.\n"
"......2.4..\n"
".14........\n"
"...........\n") == 0);
free(board687745522);
board687745522 = NULL;
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 2, 4, 13) == 1 );
assert( gamma_free_fields(board, 3) == 165 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_free_fields(board, 2) == 164 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 4, 15, 1) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 17, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 10 );
assert( gamma_move(board, 3, 17, 3) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_free_fields(board, 4) == 163 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_move(board, 2, 8, 13) == 1 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_free_fields(board, 3) == 162 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_move(board, 4, 3, 9) == 1 );
assert( gamma_move(board, 1, 10, 2) == 1 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 4, 7, 4) == 1 );
assert( gamma_golden_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 1, 10, 9) == 1 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 8, 6) == 1 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_move(board, 3, 10, 3) == 1 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 1, 10, 17) == 1 );
assert( gamma_move(board, 2, 10, 5) == 1 );
assert( gamma_move(board, 2, 0, 16) == 1 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_free_fields(board, 1) == 132 );
assert( gamma_move(board, 2, 17, 0) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_free_fields(board, 2) == 132 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 4, 9, 1) == 1 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 3, 1, 16) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_free_fields(board, 4) == 124 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_move(board, 1, 17, 7) == 0 );
assert( gamma_move(board, 2, 16, 10) == 0 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 4, 7, 17) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_free_fields(board, 1) == 119 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_free_fields(board, 2) == 118 );
assert( gamma_move(board, 3, 0, 10) == 0 );


char* board980353780 = gamma_board(board);
assert( board980353780 != NULL );
assert( strcmp(board980353780, 
".......4.21\n"
"23......3..\n"
"....4....1.\n"
".1..3......\n"
"3...2...22.\n"
"...2.1....1\n"
"..41.1..321\n"
"4....2....4\n"
"12.42..4.21\n"
"1....44....\n"
".21.122...3\n"
".43.....33.\n"
".2.43.23..2\n"
".2.43..4321\n"
"4.41..41.33\n"
"....312.431\n"
".14...3..4.\n"
"..4..2.13..\n") == 0);
free(board980353780);
board980353780 = NULL;
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 4, 10, 0) == 1 );
assert( gamma_move(board, 4, 0, 12) == 1 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 8, 10) == 1 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_golden_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 2, 8, 14) == 1 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_move(board, 2, 3, 12) == 0 );


char* board934548578 = gamma_board(board);
assert( board934548578 != NULL );
assert( strcmp(board934548578, 
".......4.21\n"
"23......3..\n"
"....4....1.\n"
".1..3...2..\n"
"3...2.1.22.\n"
"4..2.1....1\n"
"..41.1..321\n"
"4....2..3.4\n"
"12.42..4.21\n"
"1....44.2..\n"
".21.122...3\n"
".43.1...33.\n"
".2.43423.22\n"
".2.43..4321\n"
"4.41..41.33\n"
"...4312.431\n"
".14...3..4.\n"
"..4..2.13.4\n") == 0);
free(board934548578);
board934548578 = NULL;
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 3, 4, 16) == 1 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_free_fields(board, 4) == 105 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 2, 7, 17) == 0 );
assert( gamma_free_fields(board, 2) == 104 );
assert( gamma_golden_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_free_fields(board, 3) == 103 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 4, 6, 15) == 1 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 2, 2, 14) == 1 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 0, 17) == 1 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_move(board, 4, 1, 3) == 1 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 2, 7, 11) == 1 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );


char* board493275096 = gamma_board(board);
assert( board493275096 != NULL );
assert( strcmp(board493275096, 
"2......4.21\n"
"23..3...3..\n"
"....4.4..1.\n"
".12.3..32.1\n"
"3...2.1.22.\n"
"4..2.1....1\n"
"..41.1.2321\n"
"4....2..3.4\n"
"12.42..4.21\n"
"1....44.2..\n"
"321.122..13\n"
".43.1...33.\n"
".2243423.22\n"
".2.43..4321\n"
"4441..41.33\n"
"2..4312.431\n"
".14.4.3.344\n"
"..4..2213.4\n") == 0);
free(board493275096);
board493275096 = NULL;
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 9, 14) == 1 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_golden_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_free_fields(board, 2) == 87 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_move(board, 1, 17, 5) == 0 );
assert( gamma_move(board, 2, 9, 8) == 1 );
assert( gamma_move(board, 2, 4, 17) == 1 );
assert( gamma_free_fields(board, 2) == 83 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 4, 5, 6) == 1 );


char* board363783138 = gamma_board(board);
assert( board363783138 != NULL );
assert( strcmp(board363783138, 
"2...2..4.21\n"
"23..3...3..\n"
"....4.4..1.\n"
".1223..3221\n"
"3...2.1.22.\n"
"43.2.1....1\n"
"..41.1.2321\n"
"4....2..3.4\n"
"12.42..4.21\n"
"1....44.22.\n"
"321.122..13\n"
".43.14..33.\n"
".2243423.22\n"
".2.43..4321\n"
"4441..41.33\n"
"2..4312.431\n"
"214.4.34344\n"
"..4.3221324\n") == 0);
free(board363783138);
board363783138 = NULL;
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_move(board, 2, 3, 16) == 1 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_free_fields(board, 3) == 77 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_golden_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 9, 17) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 1, 8, 17) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 5, 17) == 1 );
assert( gamma_free_fields(board, 2) == 73 );
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_busy_fields(board, 4) == 31 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_free_fields(board, 1) == 70 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 10, 16) == 1 );
assert( gamma_free_fields(board, 2) == 69 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 3, 10, 15) == 1 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_free_fields(board, 2) == 68 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 4, 7, 12) == 1 );
assert( gamma_move(board, 1, 5, 1) == 1 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board245197462 = gamma_board(board);
assert( board245197462 != NULL );
assert( strcmp(board245197462, 
"2...22.4121\n"
"23.23...3.2\n"
"....4.4..13\n"
"11223..3221\n"
"33..2.1322.\n"
"43.2.1.4..1\n"
"..41.1.2321\n"
"4...42..3.4\n"
"12242..4.21\n"
"1....441221\n"
"321.122..13\n"
".432143.33.\n"
".2243423.22\n"
".2.43..4321\n"
"4441..41133\n"
"2.24312.431\n"
"214.4134344\n"
"1.4.3221324\n") == 0);
free(board245197462);
board245197462 = NULL;
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 2, 7, 16) == 1 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 17, 6) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 4, 0, 15) == 1 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_golden_move(board, 1, 16, 10) == 0 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 1, 15) == 1 );
assert( gamma_golden_move(board, 2, 4, 1) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 4, 8, 11) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 1, 5, 16) == 1 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_free_fields(board, 2) == 39 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 4, 6, 10) == 1 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 4, 16) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_move(board, 1, 6, 17) == 1 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 4, 5, 14) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board858819538 = gamma_board(board);
assert( board858819538 != NULL );
assert( strcmp(board858819538, 
"2...2214121\n"
"23.231.23.2\n"
"42..4.4..13\n"
"112234.3221\n"
"33..2.1322.\n"
"43.2.1.4..1\n"
"..41.1.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"1....441221\n"
"321.122.413\n"
".432143333.\n"
".2243423.22\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board858819538);
board858819538 = NULL;
assert( gamma_move(board, 1, 16, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 4, 1, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );


char* board325149982 = gamma_board(board);
assert( board325149982 != NULL );
assert( strcmp(board325149982, 
"2...2214121\n"
"23.231.23.2\n"
"42..4.4..13\n"
"112234.3221\n"
"33..2.1322.\n"
"43.2.1.4..1\n"
"..41.1.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"14...441221\n"
"321.122.413\n"
".432143333.\n"
".2243423.22\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board325149982);
board325149982 = NULL;
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 15, 8) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_free_fields(board, 2) == 35 );


char* board828584455 = gamma_board(board);
assert( board828584455 != NULL );
assert( strcmp(board828584455, 
"2...2214121\n"
"23.231.23.2\n"
"42..4.4..13\n"
"112234.3221\n"
"33..2.1322.\n"
"43.2.1.4..1\n"
"..41.1.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"14...441221\n"
"321.122.413\n"
".432143333.\n"
".2243423.22\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board828584455);
board828584455 = NULL;
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_free_fields(board, 1) == 51 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 4, 11) == 1 );
assert( gamma_free_fields(board, 3) == 50 );


char* board224175450 = gamma_board(board);
assert( board224175450 != NULL );
assert( strcmp(board224175450, 
"2...2214121\n"
"23.231.23.2\n"
"42..4.4..13\n"
"112234.3221\n"
"33..2.1322.\n"
"43.2.1.4..1\n"
"..4131.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"14...441221\n"
"321.122.413\n"
".432143333.\n"
".2243423.22\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board224175450);
board224175450 = NULL;
assert( gamma_move(board, 4, 7, 17) == 0 );
assert( gamma_move(board, 4, 3, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 5, 15) == 1 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_free_fields(board, 2) == 34 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_golden_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 8, 16) == 0 );
assert( gamma_move(board, 3, 3, 9) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );


char* board182770975 = gamma_board(board);
assert( board182770975 != NULL );
assert( strcmp(board182770975, 
"2...2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.1322.\n"
"43.2.1.4..1\n"
"..4131.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"14...441221\n"
"321.122.413\n"
".432143333.\n"
"32243423.22\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board182770975);
board182770975 = NULL;
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_golden_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 1, 6, 17) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_free_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_golden_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 6, 17) == 0 );


char* board590057872 = gamma_board(board);
assert( board590057872 != NULL );
assert( strcmp(board590057872, 
"2...2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"..4131.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"14...441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board590057872);
board590057872 = NULL;
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_golden_move(board, 2, 16, 1) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 3, 16) == 0 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_golden_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 45 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_golden_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 6) == 0 );


char* board665529401 = gamma_board(board);
assert( board665529401 != NULL );
assert( strcmp(board665529401, 
"2...2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"1.4131.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"14...441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board665529401);
board665529401 = NULL;
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 17, 2) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 9, 13) == 0 );


char* board926241995 = gamma_board(board);
assert( board926241995 != NULL );
assert( strcmp(board926241995, 
"2...2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"1.4131.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"14...441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board926241995);
board926241995 = NULL;
assert( gamma_move(board, 4, 8, 16) == 0 );


char* board361947131 = gamma_board(board);
assert( board361947131 != NULL );
assert( strcmp(board361947131, 
"2...2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"1.4131.2321\n"
"4...424.3.4\n"
"12242..4.21\n"
"14...441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board361947131);
board361947131 = NULL;
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 3, 10, 16) == 0 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_free_fields(board, 4) == 44 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 10, 15) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 1, 6, 17) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 3, 8) == 1 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_free_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );


char* board536795871 = gamma_board(board);
assert( board536795871 != NULL );
assert( strcmp(board536795871, 
"2...2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"1.413122321\n"
"41..424.3.4\n"
"12242..4.21\n"
"14.1.441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board536795871);
board536795871 = NULL;
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 6, 15) == 0 );


char* board336531660 = gamma_board(board);
assert( board336531660 != NULL );
assert( strcmp(board336531660, 
"2...2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"1.413122321\n"
"41..424.3.4\n"
"12242..4.21\n"
"14.1.441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board336531660);
board336531660 = NULL;
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 10, 15) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 3, 17, 2) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_free_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_free_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_free_fields(board, 1) == 18 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_golden_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 4, 16, 2) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_golden_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 4, 2, 17) == 1 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board744364661 = gamma_board(board);
assert( board744364661 != NULL );
assert( strcmp(board744364661, 
"2.4.2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"1.413122321\n"
"41..424.3.4\n"
"12242..4.21\n"
"14.1.441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board744364661);
board744364661 = NULL;
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 4, 1, 1) == 0 );


char* board585496391 = gamma_board(board);
assert( board585496391 != NULL );
assert( strcmp(board585496391, 
"2.4.2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"112234.3221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"1.413122321\n"
"41..424.3.4\n"
"12242..4.21\n"
"14.1.441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board585496391);
board585496391 = NULL;
assert( gamma_move(board, 1, 1, 16) == 0 );
assert( gamma_move(board, 1, 8, 10) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_free_fields(board, 4) == 29 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_free_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_free_fields(board, 4) == 29 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );


char* board440590198 = gamma_board(board);
assert( board440590198 != NULL );
assert( strcmp(board440590198, 
"2.4.2214121\n"
"23.231.23.2\n"
"42..414..13\n"
"11223433221\n"
"33..2.13223\n"
"43.2.1.4..1\n"
"1.413122321\n"
"41..424.3.4\n"
"12242..4.21\n"
"14.1.441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board440590198);
board440590198 = NULL;
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 0) == 0 );
assert( gamma_golden_move(board, 4, 16, 4) == 0 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_free_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_free_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 4, 2, 16) == 1 );
assert( gamma_free_fields(board, 4) == 28 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_busy_fields(board, 4) == 39 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board802225554 = gamma_board(board);
assert( board802225554 != NULL );
assert( strcmp(board802225554, 
"2.4.2214121\n"
"234231.23.2\n"
"42..414..13\n"
"11223433221\n"
"33..2.13223\n"
"43.231.4.11\n"
"1.413122321\n"
"41..424.3.4\n"
"122424.4.21\n"
"14.1.441221\n"
"321.1223413\n"
".432143333.\n"
"32243423122\n"
"32.43..4321\n"
"4441..41133\n"
"2324312.431\n"
"214.2134344\n"
"1.4.3221324\n") == 0);
free(board802225554);
board802225554 = NULL;
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 46 );
assert( gamma_free_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 39 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_move(board, 2, 9, 17) == 0 );
assert( gamma_move(board, 3, 15, 8) == 0 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 1, 17, 3) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 8, 17) == 0 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 5, 17) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 5, 6) == 0 );


gamma_delete(board);

    return 0;
}
