#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 124916328
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(5, 15, 9, 6);
assert( board != NULL );


assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );


char* board632005851 = gamma_board(board);
assert( board632005851 != NULL );
assert( strcmp(board632005851, 
".....\n"
".....\n"
".....\n"
".....\n"
".....\n"
"1....\n"
".....\n"
".....\n"
".....\n"
".....\n"
".....\n"
".....\n"
".....\n"
".....\n"
".....\n") == 0);
free(board632005851);
board632005851 = NULL;
assert( gamma_move(board, 2, 2, 0) == 1 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_golden_move(board, 7, 3, 0) == 0 );
assert( gamma_move(board, 8, 4, 14) == 1 );
assert( gamma_move(board, 8, 1, 13) == 1 );
assert( gamma_move(board, 9, 1, 4) == 1 );
assert( gamma_move(board, 9, 1, 10) == 1 );
assert( gamma_free_fields(board, 9) == 67 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_free_fields(board, 1) == 66 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 5, 4, 3) == 1 );
assert( gamma_move(board, 5, 2, 5) == 1 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_move(board, 7, 1, 11) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 4, 9) == 1 );
assert( gamma_move(board, 8, 4, 0) == 1 );
assert( gamma_move(board, 9, 14, 3) == 0 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_move(board, 4, 3, 13) == 1 );
assert( gamma_golden_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_move(board, 5, 3, 8) == 1 );


char* board358776457 = gamma_board(board);
assert( board358776457 != NULL );
assert( strcmp(board358776457, 
"....8\n"
".8.4.\n"
".....\n"
".7.1.\n"
".9.2.\n"
"1...8\n"
"..35.\n"
"..3..\n"
".....\n"
"2.5..\n"
".9...\n"
"4...5\n"
"4....\n"
".....\n"
"7.2.8\n") == 0);
free(board358776457);
board358776457 = NULL;
assert( gamma_move(board, 6, 12, 2) == 0 );
assert( gamma_move(board, 7, 2, 9) == 1 );
assert( gamma_move(board, 7, 3, 1) == 1 );
assert( gamma_move(board, 8, 1, 6) == 1 );
assert( gamma_move(board, 9, 1, 1) == 1 );
assert( gamma_move(board, 9, 0, 3) == 0 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 4 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 4, 0, 12) == 1 );
assert( gamma_move(board, 4, 2, 14) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_free_fields(board, 4) == 45 );
assert( gamma_golden_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 4, 12) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_move(board, 6, 14, 1) == 0 );
assert( gamma_move(board, 6, 2, 5) == 0 );
assert( gamma_move(board, 7, 0, 0) == 0 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_move(board, 8, 14, 3) == 0 );
assert( gamma_move(board, 9, 0, 14) == 1 );
assert( gamma_free_fields(board, 1) == 43 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 3, 0) == 1 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 4, 1, 12) == 1 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_move(board, 5, 2, 11) == 1 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 6, 4, 5) == 0 );
assert( gamma_move(board, 7, 2, 10) == 1 );
assert( gamma_move(board, 7, 4, 7) == 1 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_move(board, 9, 1, 9) == 0 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_golden_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 1, 2) == 1 );
assert( gamma_move(board, 6, 4, 14) == 0 );
assert( gamma_move(board, 7, 4, 0) == 0 );
assert( gamma_move(board, 8, 0, 1) == 1 );


char* board868204546 = gamma_board(board);
assert( board868204546 != NULL );
assert( strcmp(board868204546, 
"9.4.8\n"
".814.\n"
"44..5\n"
"3751.\n"
".972.\n"
"117.8\n"
"..35.\n"
"..3.7\n"
".8...\n"
"2.5.3\n"
".9...\n"
"4..55\n"
"45.1.\n"
"89.7.\n"
"7.228\n") == 0);
free(board868204546);
board868204546 = NULL;
assert( gamma_move(board, 9, 2, 2) == 1 );
assert( gamma_move(board, 9, 1, 9) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_golden_move(board, 2, 8, 2) == 0 );


char* board442297621 = gamma_board(board);
assert( board442297621 != NULL );
assert( strcmp(board442297621, 
"9.4.8\n"
".814.\n"
"44..5\n"
"3751.\n"
".972.\n"
"11728\n"
"..35.\n"
"..3.7\n"
".8...\n"
"2.5.3\n"
".9...\n"
"4..55\n"
"4591.\n"
"89.7.\n"
"7.228\n") == 0);
free(board442297621);
board442297621 = NULL;
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_golden_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 5, 0, 11) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 7, 13, 4) == 0 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 2) == 0 );
assert( gamma_move(board, 8, 4, 14) == 0 );
assert( gamma_move(board, 9, 0, 1) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_free_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 8, 4, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 6 );
assert( gamma_golden_move(board, 8, 13, 2) == 0 );
assert( gamma_move(board, 9, 4, 3) == 0 );
assert( gamma_busy_fields(board, 9) == 5 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 6, 1, 3) == 1 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_free_fields(board, 7) == 28 );
assert( gamma_move(board, 8, 2, 4) == 0 );
assert( gamma_move(board, 8, 0, 6) == 1 );
assert( gamma_move(board, 9, 0, 11) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_golden_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_free_fields(board, 2) == 27 );


char* board583524211 = gamma_board(board);
assert( board583524211 != NULL );
assert( strcmp(board583524211, 
"9.4.8\n"
".814.\n"
"44..5\n"
"3751.\n"
".972.\n"
"11728\n"
".335.\n"
"..3.7\n"
"88...\n"
"2.5.3\n"
".9...\n"
"46255\n"
"4591.\n"
"89.7.\n"
"7.228\n") == 0);
free(board583524211);
board583524211 = NULL;
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_free_fields(board, 4) == 27 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 7, 4, 11) == 1 );
assert( gamma_move(board, 8, 3, 11) == 0 );
assert( gamma_move(board, 9, 2, 14) == 0 );
assert( gamma_move(board, 1, 2, 4) == 1 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 4, 3, 7) == 1 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_free_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 12, 2) == 0 );
assert( gamma_free_fields(board, 6) == 23 );
assert( gamma_move(board, 7, 2, 7) == 0 );
assert( gamma_move(board, 8, 13, 0) == 0 );
assert( gamma_move(board, 9, 4, 12) == 0 );
assert( gamma_move(board, 9, 1, 8) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board755145838 = gamma_board(board);
assert( board755145838 != NULL );
assert( strcmp(board755145838, 
"9.4.8\n"
".814.\n"
"44..5\n"
"37517\n"
".972.\n"
"11728\n"
".335.\n"
"..347\n"
"88...\n"
"2.5.3\n"
".91.1\n"
"46255\n"
"4591.\n"
"89.7.\n"
"7.228\n") == 0);
free(board755145838);
board755145838 = NULL;
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 5, 14, 3) == 0 );
assert( gamma_move(board, 5, 1, 7) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 6, 3, 13) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_move(board, 7, 1, 5) == 0 );
assert( gamma_move(board, 8, 8, 0) == 0 );
assert( gamma_move(board, 8, 4, 11) == 0 );
assert( gamma_move(board, 9, 2, 4) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 5, 0, 14) == 0 );
assert( gamma_move(board, 6, 1, 7) == 1 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_move(board, 8, 3, 11) == 0 );
assert( gamma_free_fields(board, 8) == 10 );
assert( gamma_move(board, 9, 1, 14) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );


char* board869985097 = gamma_board(board);
assert( board869985097 != NULL );
assert( strcmp(board869985097, 
"994.8\n"
".814.\n"
"44..5\n"
"37517\n"
".972.\n"
"11728\n"
".335.\n"
".6347\n"
"88...\n"
"2.5.3\n"
".91.1\n"
"46255\n"
"4591.\n"
"89.7.\n"
"7.228\n") == 0);
free(board869985097);
board869985097 = NULL;
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_free_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_move(board, 7, 10, 4) == 0 );
assert( gamma_free_fields(board, 7) == 6 );
assert( gamma_move(board, 8, 2, 4) == 0 );
assert( gamma_move(board, 8, 1, 14) == 0 );
assert( gamma_move(board, 9, 0, 4) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_free_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 8, 0) == 0 );


char* board970087406 = gamma_board(board);
assert( board970087406 != NULL );
assert( strcmp(board970087406, 
"994.8\n"
".814.\n"
"44..5\n"
"37517\n"
".972.\n"
"11728\n"
".335.\n"
".6347\n"
"88...\n"
"2.523\n"
"991.1\n"
"46255\n"
"4591.\n"
"89.7.\n"
"7.228\n") == 0);
free(board970087406);
board970087406 = NULL;
assert( gamma_move(board, 4, 4, 6) == 1 );


char* board875451588 = gamma_board(board);
assert( board875451588 != NULL );
assert( strcmp(board875451588, 
"994.8\n"
".814.\n"
"44..5\n"
"37517\n"
".972.\n"
"11728\n"
".335.\n"
".6347\n"
"88..4\n"
"2.523\n"
"991.1\n"
"46255\n"
"4591.\n"
"89.7.\n"
"7.228\n") == 0);
free(board875451588);
board875451588 = NULL;
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_move(board, 8, 10, 0) == 0 );
assert( gamma_move(board, 9, 10, 4) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_free_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_move(board, 6, 12, 2) == 0 );
assert( gamma_move(board, 6, 3, 10) == 0 );
assert( gamma_move(board, 7, 12, 3) == 0 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_move(board, 8, 12, 3) == 0 );
assert( gamma_move(board, 9, 12, 2) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 2, 3, 14) == 1 );


char* board775633657 = gamma_board(board);
assert( board775633657 != NULL );
assert( strcmp(board775633657, 
"99428\n"
".814.\n"
"44..5\n"
"37517\n"
".972.\n"
"11728\n"
".335.\n"
".6347\n"
"88..4\n"
"2.523\n"
"991.1\n"
"46255\n"
"4591.\n"
"89.7.\n"
"7.228\n") == 0);
free(board775633657);
board775633657 = NULL;
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_free_fields(board, 6) == 17 );


gamma_delete(board);

    return 0;
}
