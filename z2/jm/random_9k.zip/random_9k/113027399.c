#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 113027399
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(15, 16, 3, 40);
assert( board != NULL );


assert( gamma_move(board, 1, 8, 7) == 1 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 14, 2) == 1 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_move(board, 3, 10, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 1 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_golden_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_move(board, 1, 14, 10) == 1 );
assert( gamma_move(board, 2, 14, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 3 );
assert( gamma_move(board, 1, 3, 15) == 1 );
assert( gamma_move(board, 1, 12, 8) == 1 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 6 );
assert( gamma_move(board, 3, 5, 13) == 1 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 2, 12, 13) == 1 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 3, 0, 12) == 1 );


char* board523952708 = gamma_board(board);
assert( board523952708 != NULL );
assert( strcmp(board523952708, 
"...1...........\n"
"3..............\n"
".....3......2.2\n"
"3..............\n"
"...............\n"
"1....2..2.....1\n"
".3.2...........\n"
"............1..\n"
"........1......\n"
"1...1..........\n"
"...............\n"
"............1..\n"
"...............\n"
"..............2\n"
"..3............\n"
"..1.......32...\n") == 0);
free(board523952708);
board523952708 = NULL;
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_move(board, 3, 5, 14) == 1 );
assert( gamma_move(board, 1, 13, 1) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_free_fields(board, 2) == 213 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 3, 4, 15) == 1 );
assert( gamma_move(board, 1, 13, 2) == 1 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 5, 3) == 1 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 3, 9, 7) == 1 );
assert( gamma_move(board, 1, 8, 13) == 1 );
assert( gamma_golden_move(board, 1, 13, 14) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_free_fields(board, 2) == 203 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 2, 10, 5) == 1 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 1, 3, 4) == 1 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 3, 3, 13) == 1 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 8, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 7, 12) == 1 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_move(board, 2, 9, 10) == 1 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_free_fields(board, 3) == 184 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_golden_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 13, 13) == 1 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 1, 10, 12) == 1 );
assert( gamma_golden_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_free_fields(board, 2) == 176 );
assert( gamma_golden_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_free_fields(board, 3) == 175 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 1, 1, 5) == 1 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_move(board, 3, 0, 15) == 1 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 3, 13, 11) == 1 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 1, 9, 11) == 1 );
assert( gamma_move(board, 2, 4, 11) == 1 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_free_fields(board, 2) == 163 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 1, 7, 14) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 14, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_move(board, 3, 14, 8) == 1 );
assert( gamma_move(board, 1, 11, 3) == 1 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_free_fields(board, 2) == 154 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 15, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_move(board, 1, 14, 11) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 1, 4, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 34 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 2, 14, 14) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_golden_move(board, 3, 11, 3) == 1 );
assert( gamma_move(board, 1, 6, 7) == 1 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_free_fields(board, 1) == 144 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 12, 0) == 1 );
assert( gamma_move(board, 3, 4, 5) == 1 );


char* board625191741 = gamma_board(board);
assert( board625191741 != NULL );
assert( strcmp(board625191741, 
"3..13..........\n"
"3...33.1...3..2\n"
"1..313.31.2.212\n"
"31.2..33..1...2\n"
"2..12...211..31\n"
"1..2.23.22....1\n"
".332....2......\n"
"12.3.....1.21.3\n"
"..1..211133....\n"
"13321....3.1...\n"
"31.13.21.32....\n"
".1.1........1..\n"
"..32.2...2.3...\n"
"..3.21.......12\n"
"..31....3.2..1.\n"
"2211...2..323..\n") == 0);
free(board625191741);
board625191741 = NULL;
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 14, 4) == 1 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 2) == 1 );
assert( gamma_move(board, 1, 4, 12) == 1 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 2, 9, 14) == 1 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 1, 14, 1) == 1 );
assert( gamma_move(board, 1, 5, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_golden_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_free_fields(board, 2) == 132 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 3, 4, 4) == 1 );


char* board433662390 = gamma_board(board);
assert( board433662390 != NULL );
assert( strcmp(board433662390, 
"3..131.........\n"
"3...33.1.2.3..2\n"
"1..313.31.2.212\n"
"31.21.33..1...2\n"
"2..12...211..31\n"
"1..2.23.22....1\n"
".332....2......\n"
"12.3.....1.21.3\n"
"..1..211133....\n"
"13321.2..3.1...\n"
"31.13.21.32....\n"
".1.13.......1.2\n"
"..32.2...2.3...\n"
"..3.213......12\n"
".331...33.2..11\n"
"2211...2..323..\n") == 0);
free(board433662390);
board433662390 = NULL;
assert( gamma_move(board, 1, 6, 1) == 1 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 36 );
assert( gamma_move(board, 3, 12, 12) == 1 );
assert( gamma_move(board, 3, 6, 15) == 1 );
assert( gamma_free_fields(board, 3) == 125 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 3, 14) == 1 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_golden_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 40 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board704956839 = gamma_board(board);
assert( board704956839 != NULL );
assert( strcmp(board704956839, 
"3..1313........\n"
"3..133.1.2.3..2\n"
"1..313.31.2.212\n"
"31.21.33..1.3.2\n"
"2..12...211.231\n"
"1..2.23.22....1\n"
".3322...2......\n"
"12.3.....1.21.3\n"
"..1..211133....\n"
"13321.2..3.1...\n"
"31.13321.32....\n"
".1.13.......1.2\n"
"..32.2...2.3...\n"
"..3.213......12\n"
".331..133.2..11\n"
"2211...2..323..\n") == 0);
free(board704956839);
board704956839 = NULL;
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 5, 12) == 1 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 41 );


char* board500541140 = gamma_board(board);
assert( board500541140 != NULL );
assert( strcmp(board500541140, 
"3..1313........\n"
"3..133.1.2.3..2\n"
"1..313.31.2.212\n"
"31.21333..1.3.2\n"
"2..12...211.231\n"
"1..2.23.22....1\n"
".3322...2......\n"
"12.3.....1.21.3\n"
"..1..211133....\n"
"13321.2..3.1...\n"
"31.13321.32....\n"
".1.13.......1.2\n"
"..32.2...2.3...\n"
"..3.213......12\n"
".331..133.2..11\n"
"2211...2..323..\n") == 0);
free(board500541140);
board500541140 = NULL;
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 2, 1, 15) == 1 );
assert( gamma_golden_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 43 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_free_fields(board, 2) == 117 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_free_fields(board, 2) == 117 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 1, 10, 2) == 1 );


char* board856999466 = gamma_board(board);
assert( board856999466 != NULL );
assert( strcmp(board856999466, 
"32.1313........\n"
"3..133.1.2.3..2\n"
"1..313.31.2.212\n"
"31.21333.11.3.2\n"
"2.3122..211.231\n"
"1..2.23.22....1\n"
".3322...2..3...\n"
"12.3.....1.21.3\n"
"..1..211133....\n"
"13321.2..3.1...\n"
"31.13321.32....\n"
".1.13.......1.2\n"
"..32.2...2.3...\n"
"..3.213...1..12\n"
".331..133.2..11\n"
"2211...2..323..\n") == 0);
free(board856999466);
board856999466 = NULL;
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_golden_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 3, 13, 3) == 1 );
assert( gamma_move(board, 1, 12, 7) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 3, 11, 10) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_move(board, 1, 11, 11) == 1 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 40 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 5, 11) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );


char* board209282888 = gamma_board(board);
assert( board209282888 != NULL );
assert( strcmp(board209282888, 
"32.1313........\n"
"3..133.1.2.3..2\n"
"1..313.31.2.212\n"
"31.21333.11.3.2\n"
"2.3122..2111231\n"
"1..2.23.22.3..1\n"
".3322.1.2233...\n"
"12.3.....1.21.3\n"
"..1.3211133.1..\n"
"1332132..3.1...\n"
"31.13321.32....\n"
".1.13.......1.2\n"
"..32.2...2.3.3.\n"
"..3.213...1..12\n"
".331.2133.2..11\n"
"2211...2..323..\n") == 0);
free(board209282888);
board209282888 = NULL;
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 6, 14) == 1 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 1, 11, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 15, 14) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_golden_move(board, 3, 5, 6) == 0 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 2, 11, 14) == 0 );


char* board499805822 = gamma_board(board);
assert( board499805822 != NULL );
assert( strcmp(board499805822, 
"32.1313....1...\n"
"3..13321.2.3..2\n"
"1..313.31.2.212\n"
"31.21333.11.3.2\n"
"2.3122..2111231\n"
"1..2.23.22.3..1\n"
".3322.1.2233...\n"
"12.3.....1.21.3\n"
"..1.3211133.1..\n"
"1332132..3.1...\n"
"31.13321.32....\n"
".1.13.......1.2\n"
"..32.2...2.3.3.\n"
"..3.213...1..12\n"
".331.2133.2..11\n"
"2211...2..323..\n") == 0);
free(board499805822);
board499805822 = NULL;
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 1, 6, 11) == 1 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_free_fields(board, 3) == 101 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 8, 15) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 4, 0) == 1 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_free_fields(board, 1) == 99 );
assert( gamma_move(board, 2, 14, 6) == 1 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_move(board, 3, 10, 3) == 1 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );


char* board715191010 = gamma_board(board);
assert( board715191010 != NULL );
assert( strcmp(board715191010, 
"32.1313.3..1...\n"
"3..13321.2.3..2\n"
"1.3313.31.2.212\n"
"31.21333.11.3.2\n"
"2.31221.2111231\n"
"1..2.23.2223..1\n"
".3322.132233...\n"
"12.3.....1.21.3\n"
"..133211133.1..\n"
"1332132.23.1..2\n"
"31.13321.32....\n"
".1.13.......1.2\n"
"..32.2...233.3.\n"
"..3.213...1..12\n"
".331.2133.2..11\n"
"22111..2..323..\n") == 0);
free(board715191010);
board715191010 = NULL;
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 8, 8) == 1 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_golden_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_free_fields(board, 3) == 91 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 1, 13, 9) == 1 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_free_fields(board, 2) == 90 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_free_fields(board, 3) == 90 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 53 );
assert( gamma_move(board, 2, 13, 0) == 1 );
assert( gamma_golden_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 54 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 10) == 1 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_free_fields(board, 2) == 84 );
assert( gamma_move(board, 3, 13, 8) == 1 );
assert( gamma_free_fields(board, 3) == 83 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 12, 2) == 1 );
assert( gamma_golden_move(board, 2, 9, 13) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 1, 12, 14) == 1 );
assert( gamma_move(board, 2, 13, 14) == 1 );
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_move(board, 3, 12, 11) == 0 );


char* board103423594 = gamma_board(board);
assert( board103423594 != NULL );
assert( strcmp(board103423594, 
"32.1313.3..1...\n"
"3..13321.2.3122\n"
"1.3313.31.2.212\n"
"31.21333211.3.2\n"
"2.31221.2111231\n"
"1..2123.22232.1\n"
".3322.132233.1.\n"
"12.3....11.2133\n"
"3.13321113331..\n"
"1332132123.1.12\n"
"31.13321.32....\n"
".1.13.....1.1.2\n"
"..3212...233.3.\n"
".33.213...1.212\n"
".331.2133.2..11\n"
"22111..2..2232.\n") == 0);
free(board103423594);
board103423594 = NULL;
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_free_fields(board, 1) == 77 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 57 );
assert( gamma_free_fields(board, 1) == 75 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 1, 4, 8) == 1 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 15, 9) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 14, 7) == 1 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 13, 14) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_golden_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board175450885 = gamma_board(board);
assert( board175450885 != NULL );
assert( strcmp(board175450885, 
"32.1313.3..1...\n"
"3..13321.2.3122\n"
"1.3313.31.2.212\n"
"31.21333211.3.2\n"
"2.31221.2111231\n"
"1..2123.22232.1\n"
".3322.132233.1.\n"
"12.313..11.2133\n"
"3.13321113331.3\n"
"1332132123.1.12\n"
"31.13321.322...\n"
".1.13.....1.1.2\n"
"..3212...233.3.\n"
".33.213...1.212\n"
".331.2133.2..11\n"
"22111..2..2232.\n") == 0);
free(board175450885);
board175450885 = NULL;
assert( gamma_move(board, 1, 12, 11) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 1, 8, 2) == 1 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 13, 5) == 1 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 8, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 15, 12) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_free_fields(board, 2) == 71 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 15) == 1 );
assert( gamma_busy_fields(board, 3) == 59 );
assert( gamma_free_fields(board, 3) == 70 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );


char* board570094580 = gamma_board(board);
assert( board570094580 != NULL );
assert( strcmp(board570094580, 
"3231313.3..1...\n"
"3..13321.2.3122\n"
"1.3313.31.2.212\n"
"31.21333211.3.2\n"
"2.31221.2111231\n"
"1..2123.22232.1\n"
".3322.132233.1.\n"
"12.313..11.2133\n"
"3.13321113331.3\n"
"1332132123.1.12\n"
"31.13321.322.2.\n"
".1.13.....1.1.2\n"
"..3212...233.3.\n"
".33.213.1.1.212\n"
".331.2133.2..11\n"
"22111..2..2232.\n") == 0);
free(board570094580);
board570094580 = NULL;
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 1, 3, 12) == 0 );


char* board876167179 = gamma_board(board);
assert( board876167179 != NULL );
assert( strcmp(board876167179, 
"3231313.3..1...\n"
"3..13321.2.3122\n"
"1.3313.31.2.212\n"
"31.21333211.3.2\n"
"2.31221.2111231\n"
"1..2123.22232.1\n"
".3322313223321.\n"
"12.313.111.2133\n"
"3.13321113331.3\n"
"1332132123.1.12\n"
"31.13321.322.2.\n"
".1.13.....1.1.2\n"
"..3212...233.3.\n"
".33.213.1.13212\n"
".331.2133.2..11\n"
"22111..2..2232.\n") == 0);
free(board876167179);
board876167179 = NULL;
assert( gamma_move(board, 2, 15, 13) == 0 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 2, 15, 12) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 3, 6, 13) == 1 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 60 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 62 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 60 );
assert( gamma_free_fields(board, 1) == 63 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_free_fields(board, 1) == 61 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );


char* board221017164 = gamma_board(board);
assert( board221017164 != NULL );
assert( strcmp(board221017164, 
"3231313.3..1...\n"
"3..13321.2.3122\n"
"1.3313331.2.212\n"
"31.21333211.3.2\n"
"2.31221.2111231\n"
"1..2123.22232.1\n"
".3322313223321.\n"
"12.313.111.2133\n"
"3.13321113331.3\n"
"1332132123.1.12\n"
"31213321.322.2.\n"
".1.131....1.1.2\n"
"..3212...233.3.\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"22111..2.22232.\n") == 0);
free(board221017164);
board221017164 = NULL;
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_free_fields(board, 1) == 61 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board818723727 = gamma_board(board);
assert( board818723727 != NULL );
assert( strcmp(board818723727, 
"3231313.3..1...\n"
"3..13321.2.3122\n"
"1.3313331.2.212\n"
"31.21333211.3.2\n"
"2.31221.2111231\n"
"1..2123.22232.1\n"
".3322313223321.\n"
"12.313.111.2133\n"
"3.13321113331.3\n"
"1332132123.1.12\n"
"31213321.322.2.\n"
".1.1312...1.1.2\n"
"..3212...233.3.\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"22111..2.22232.\n") == 0);
free(board818723727);
board818723727 = NULL;
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 14, 14) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_golden_move(board, 3, 5, 2) == 0 );
assert( gamma_golden_move(board, 1, 12, 14) == 0 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_free_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_free_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 13, 3) == 0 );


char* board885133302 = gamma_board(board);
assert( board885133302 != NULL );
assert( strcmp(board885133302, 
"3231313.3..1...\n"
"3..13321.2.3122\n"
"1.3313331.2.212\n"
"31.21333211.3.2\n"
"2.31221.2111231\n"
"1..2123.22232.1\n"
".3322313223321.\n"
"12.313.111.2133\n"
"3.13321113331.3\n"
"1332132123.1.12\n"
"31213321.322.2.\n"
"31.1312...1.1.2\n"
"..3212...233.3.\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"22111..2.22232.\n") == 0);
free(board885133302);
board885133302 = NULL;
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 57 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 13, 15) == 1 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 15, 9) == 0 );
assert( gamma_move(board, 2, 14, 0) == 1 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_free_fields(board, 1) == 55 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 15, 14) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_free_fields(board, 3) == 54 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 65 );
assert( gamma_free_fields(board, 3) == 54 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 3, 14, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 63 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_move(board, 1, 10, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_free_fields(board, 2) == 51 );


char* board794655557 = gamma_board(board);
assert( board794655557 != NULL );
assert( strcmp(board794655557, 
"3231313.3.11.2.\n"
"3..13321.2.3122\n"
"1.3313331.2.212\n"
"31.21333211.3.2\n"
"2331221.2111231\n"
"11.2123.22232.1\n"
"13322313223321.\n"
"12.313.111.2133\n"
"3313321113331.3\n"
"1332132123.1.12\n"
"31213321.322.2.\n"
"31.1312...1.1.2\n"
"..3212...233.33\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"22111..2.222322\n") == 0);
free(board794655557);
board794655557 = NULL;
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );


char* board911375540 = gamma_board(board);
assert( board911375540 != NULL );
assert( strcmp(board911375540, 
"3231313.3.11.2.\n"
"3..13321.2.3122\n"
"1.3313331.2.212\n"
"31.21333211.3.2\n"
"2331221.2111231\n"
"11.2123.22232.1\n"
"13322313223321.\n"
"12.313.111.2133\n"
"3313321113331.3\n"
"1332132123.1.12\n"
"31213321.322.2.\n"
"31.1312...1.1.2\n"
"..3212...233333\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"22111..2.222322\n") == 0);
free(board911375540);
board911375540 = NULL;
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 2, 8, 3) == 1 );


char* board913399895 = gamma_board(board);
assert( board913399895 != NULL );
assert( strcmp(board913399895, 
"3231313.3.11.2.\n"
"3..13321.2.3122\n"
"1.3313331.2.212\n"
"31.21333211.3.2\n"
"2331221.2111231\n"
"11.2123.22232.1\n"
"13322313223321.\n"
"12.313.111.2133\n"
"3313321113331.3\n"
"1332132123.1.12\n"
"31213321.322.2.\n"
"31.1312...1.1.2\n"
"..3212..2233333\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"22111..2.222322\n") == 0);
free(board913399895);
board913399895 = NULL;
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_free_fields(board, 3) == 49 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 65 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 67 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 2, 10, 14) == 1 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 67 );


char* board775936999 = gamma_board(board);
assert( board775936999 != NULL );
assert( strcmp(board775936999, 
"3231313.3.11.2.\n"
"3..13321.223122\n"
"1.3313331.2.212\n"
"31.21333211.3.2\n"
"233122112111231\n"
"11.2123.22232.1\n"
"13322313223321.\n"
"12.313.11112133\n"
"3313321113331.3\n"
"1332132123.1.12\n"
"312133211322.2.\n"
"31.1312...1.1.2\n"
"..3212..2233333\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"22111..2.222322\n") == 0);
free(board775936999);
board775936999 = NULL;
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 12) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 68 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 2, 13, 7) == 1 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_golden_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 14, 15) == 1 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 2, 1, 13) == 1 );
assert( gamma_free_fields(board, 2) == 38 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 68 );
assert( gamma_move(board, 2, 11, 15) == 0 );


char* board981845464 = gamma_board(board);
assert( board981845464 != NULL );
assert( strcmp(board981845464, 
"3231313.3.11.23\n"
"3..13321.223122\n"
"123313331.2.212\n"
"31.213332113322\n"
"233122112111231\n"
"1132123.22232.1\n"
"13322313223321.\n"
"12.313.11112133\n"
"331332111333123\n"
"1332132123.1.12\n"
"312133211322.2.\n"
"31.1312...1.1.2\n"
"..3212..2233333\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"221111.2.222322\n") == 0);
free(board981845464);
board981845464 = NULL;
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 3, 3, 9) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_free_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 15) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 70 );
assert( gamma_free_fields(board, 3) == 37 );


char* board100379782 = gamma_board(board);
assert( board100379782 != NULL );
assert( strcmp(board100379782, 
"3231313.3.11.23\n"
"3..13321.223122\n"
"123313331.2.212\n"
"31.213332113322\n"
"233122112111231\n"
"1132123.22232.1\n"
"13322313223321.\n"
"12.313.11112133\n"
"331332111333123\n"
"1332132123.1.12\n"
"312133211322.2.\n"
"31.1312...1.1.2\n"
".23212..2233333\n"
".33.213.1.13212\n"
".331.2133.22.11\n"
"221111.2.222322\n") == 0);
free(board100379782);
board100379782 = NULL;
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_free_fields(board, 1) == 37 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 70 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_free_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 65 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 1, 12, 1) == 1 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_free_fields(board, 1) == 35 );


char* board688598290 = gamma_board(board);
assert( board688598290 != NULL );
assert( strcmp(board688598290, 
"3231313.3.11.23\n"
"3..13321.223122\n"
"123313331.2.212\n"
"31.213332113322\n"
"233122112111231\n"
"1132123.22232.1\n"
"13322313223321.\n"
"12.313.11112133\n"
"331332111333123\n"
"1332132123.1.12\n"
"312133211322.2.\n"
"31.1312...1.1.2\n"
".23212..2233333\n"
".33.213.1.13212\n"
".331.2133.22111\n"
"221111.21222322\n") == 0);
free(board688598290);
board688598290 = NULL;
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 14, 14) == 0 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 9, 13) == 1 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_free_fields(board, 2) == 34 );
assert( gamma_busy_fields(board, 3) == 70 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 71 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 6, 14) == 0 );


char* board411616920 = gamma_board(board);
assert( board411616920 != NULL );
assert( strcmp(board411616920, 
"3231313.3.11.23\n"
"3..13321.223122\n"
"12331333112.212\n"
"31.213332113322\n"
"233122112111231\n"
"1132123.22232.1\n"
"13322313223321.\n"
"12.313.11112133\n"
"331332111333123\n"
"1332132123.1.12\n"
"312133211322.2.\n"
"31.1312...1.1.2\n"
".23212..2233333\n"
".33.213.1.13212\n"
".331.2133.22111\n"
"221111.21222322\n") == 0);
free(board411616920);
board411616920 = NULL;
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 2, 11, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );


char* board586952470 = gamma_board(board);
assert( board586952470 != NULL );
assert( strcmp(board586952470, 
"3231313.3.11.23\n"
"3..13321.223122\n"
"123313331122212\n"
"31.213332113322\n"
"233122112111231\n"
"1132123.22232.1\n"
"13322313223321.\n"
"12.313.11112133\n"
"331332111333123\n"
"1332132123.1.12\n"
"312133211322.2.\n"
"31.1312...1.1.2\n"
".23212..2233333\n"
".33.213.1.13212\n"
".331.2133.22111\n"
"221111.21222322\n") == 0);
free(board586952470);
board586952470 = NULL;
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_free_fields(board, 3) == 32 );
assert( gamma_golden_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 14, 11) == 0 );
assert( gamma_free_fields(board, 3) == 32 );


gamma_delete(board);

    return 0;
}
