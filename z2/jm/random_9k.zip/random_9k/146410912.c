#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 146410912
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(18, 8, 4, 37);
assert( board != NULL );


assert( gamma_move(board, 1, 3, 6) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 4, 3, 5) == 1 );


char* board246309877 = gamma_board(board);
assert( board246309877 != NULL );
assert( strcmp(board246309877, 
"..................\n"
"...1..............\n"
"...4..............\n"
"...2..............\n"
"..................\n"
"3.................\n"
"..................\n"
"..................\n") == 0);
free(board246309877);
board246309877 = NULL;
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 4, 9, 7) == 1 );
assert( gamma_free_fields(board, 4) == 137 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 2, 16, 5) == 1 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 4, 7, 14) == 0 );
assert( gamma_move(board, 4, 9, 5) == 1 );
assert( gamma_move(board, 2, 4, 7) == 1 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_move(board, 3, 6, 0) == 1 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );


char* board450936539 = gamma_board(board);
assert( board450936539 != NULL );
assert( strcmp(board450936539, 
"....2..1.4........\n"
"...1......3.......\n"
"3..4...1.4......2.\n"
"...2.3............\n"
"..................\n"
"3.................\n"
"....2.............\n"
"......3..2........\n") == 0);
free(board450936539);
board450936539 = NULL;
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 1, 16, 0) == 1 );
assert( gamma_free_fields(board, 1) == 123 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 2) == 1 );
assert( gamma_move(board, 2, 14, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_move(board, 3, 17, 5) == 1 );
assert( gamma_free_fields(board, 3) == 116 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 4, 16, 4) == 1 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 16, 7) == 1 );
assert( gamma_move(board, 2, 7, 3) == 1 );


char* board974176782 = gamma_board(board);
assert( board974176782 != NULL );
assert( strcmp(board974176782, 
"4...2..1.4......2.\n"
"...1......3.......\n"
"3..4...1.4.2..2.23\n"
"..32.3..........4.\n"
"4..1...2..........\n"
"34..4........2....\n"
"....2.............\n"
".1..3.3..2......1.\n") == 0);
free(board974176782);
board974176782 = NULL;
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 6, 2) == 1 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 3, 13, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 1, 10, 7) == 1 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 3, 12, 4) == 1 );
assert( gamma_move(board, 4, 5, 15) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_golden_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 6, 17) == 0 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 3, 13, 6) == 1 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 1, 4, 5) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );


char* board525077612 = gamma_board(board);
assert( board525077612 != NULL );
assert( strcmp(board525077612, 
"4...2..1.41.....2.\n"
"...1......3..3....\n"
"3.441.11.4.2..2.23\n"
"..32.3......3...4.\n"
"4..1...2..........\n"
"34.34.3......2....\n"
"....2..3.2...3....\n"
"21..3.3..2......1.\n") == 0);
free(board525077612);
board525077612 = NULL;
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_free_fields(board, 4) == 100 );
assert( gamma_move(board, 1, 3, 16) == 0 );
assert( gamma_move(board, 1, 16, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_free_fields(board, 3) == 99 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board186321276 = gamma_board(board);
assert( board186321276 != NULL );
assert( strcmp(board186321276, 
"4...2..1.41.....2.\n"
"...1......3..3....\n"
"3.441.11.4.2..2.23\n"
"..32.3......3...4.\n"
"4..1...2..........\n"
"34.34.3....4.2....\n"
"....2..3.23..3....\n"
"21..3.3..2......1.\n") == 0);
free(board186321276);
board186321276 = NULL;
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 3, 7, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 6, 7) == 1 );
assert( gamma_move(board, 4, 11, 1) == 1 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 3) == 1 );
assert( gamma_move(board, 3, 2, 6) == 1 );


char* board137690355 = gamma_board(board);
assert( board137690355 != NULL );
assert( strcmp(board137690355, 
"4...2.41.41.....2.\n"
"..31......3..3....\n"
"3.441.11.4.2..2.23\n"
"..32.3......3...4.\n"
"4..1.2.2..........\n"
"34.34.33...4.2....\n"
"....2..3.234.3....\n"
"21..3.3..2......1.\n") == 0);
free(board137690355);
board137690355 = NULL;
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 14, 1) == 1 );
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 4, 9, 4) == 1 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 1, 15, 2) == 1 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 4, 17, 4) == 1 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 1, 14, 0) == 1 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 4, 9, 6) == 1 );
assert( gamma_free_fields(board, 4) == 86 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_free_fields(board, 3) == 85 );


char* board252146495 = gamma_board(board);
assert( board252146495 != NULL );
assert( strcmp(board252146495, 
"4...2.41.41.....2.\n"
"..31.....43..3....\n"
"3.441.11.4.2..2.23\n"
"..32.3...4..3...44\n"
"4..1.2.2..........\n"
"34.34.33...4.2.1..\n"
"....2..3.234.34...\n"
"21..3.33.21...1.1.\n") == 0);
free(board252146495);
board252146495 = NULL;
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 1, 15, 3) == 1 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 16, 3) == 1 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 5, 1) == 1 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_free_fields(board, 4) == 80 );
assert( gamma_move(board, 1, 6, 1) == 1 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 5, 12) == 0 );
assert( gamma_free_fields(board, 4) == 77 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_free_fields(board, 3) == 77 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_free_fields(board, 4) == 77 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 1, 15, 7) == 1 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 15, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_free_fields(board, 3) == 73 );
assert( gamma_move(board, 4, 6, 17) == 0 );
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 1, 15, 0) == 1 );
assert( gamma_move(board, 3, 0, 2) == 0 );


char* board174425242 = gamma_board(board);
assert( board174425242 != NULL );
assert( strcmp(board174425242, 
"4...2.41.41..4.12.\n"
".3311....43..3....\n"
"3.441.11.4.2..2423\n"
".332.3.1.4..3...44\n"
"4..112.22......12.\n"
"34134.33...4.2.1..\n"
"....2113.234.34...\n"
"21..3.33.21...111.\n") == 0);
free(board174425242);
board174425242 = NULL;
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_free_fields(board, 4) == 69 );
assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );


char* board845388367 = gamma_board(board);
assert( board845388367 != NULL );
assert( strcmp(board845388367, 
"4..12.41.41..4.12.\n"
".3311....43..3....\n"
"3.441.11.4.2..2423\n"
".332.3.1.4.43...44\n"
"4..112.22......12.\n"
"34134.33...4.2.1..\n"
"....2113.234.34...\n"
"21..3.33.21...111.\n") == 0);
free(board845388367);
board845388367 = NULL;
assert( gamma_move(board, 1, 3, 17) == 0 );
assert( gamma_move(board, 2, 17, 7) == 1 );
assert( gamma_move(board, 3, 15, 4) == 1 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 4, 12, 0) == 1 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_free_fields(board, 2) == 65 );


char* board486004151 = gamma_board(board);
assert( board486004151 != NULL );
assert( strcmp(board486004151, 
"4..12.41.41..4.122\n"
".3311....43..3....\n"
"3.441.11.4.2..2423\n"
".332.3.1.4.43..344\n"
"4..112.22......12.\n"
"34134.33...4.2.1..\n"
"....2113.234.34...\n"
"21..3.33.21.4.111.\n") == 0);
free(board486004151);
board486004151 = NULL;
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 15, 1) == 1 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 3, 1) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 1, 14, 2) == 1 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 2, 12, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 6, 6) == 1 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_move(board, 1, 14, 7) == 1 );
assert( gamma_move(board, 3, 6, 17) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 13, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_free_fields(board, 1) == 55 );
assert( gamma_move(board, 2, 12, 2) == 1 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 17, 3) == 1 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_golden_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 1, 16, 5) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_free_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 4, 9, 2) == 1 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_golden_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 6, 17) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );


char* board750217993 = gamma_board(board);
assert( board750217993 != NULL );
assert( strcmp(board750217993, 
"4..12.41.41..41122\n"
".331134..43..3....\n"
"32441.11.432212423\n"
".33233.1.4.43..344\n"
"4.2112.22......121\n"
"34134.33.4.42211..\n"
"...32113.234.341..\n"
"21..3.33.21.4.111.\n") == 0);
free(board750217993);
board750217993 = NULL;
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 2, 17, 7) == 0 );
assert( gamma_free_fields(board, 2) == 50 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 1, 17, 7) == 0 );
assert( gamma_free_fields(board, 1) == 50 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 3, 16, 2) == 1 );
assert( gamma_move(board, 3, 10, 3) == 1 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_golden_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 11, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 17, 7) == 0 );
assert( gamma_move(board, 4, 6, 17) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board825395895 = gamma_board(board);
assert( board825395895 != NULL );
assert( strcmp(board825395895, 
"42.12.41.41..41122\n"
".331134..43..3....\n"
"32441.11.432212423\n"
"333233.1.4.43..344\n"
"4.2112.22.3....121\n"
"34134323.4.422113.\n"
".1.32113.234.341..\n"
"21..3.33.2144.111.\n") == 0);
free(board825395895);
board825395895 = NULL;
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_golden_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_free_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 15, 6) == 1 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );


char* board809565426 = gamma_board(board);
assert( board809565426 != NULL );
assert( strcmp(board809565426, 
"42.12.41.41..41122\n"
".331134..431.3.4..\n"
"32441.11.432212423\n"
"333233.1.4.43..344\n"
"4.2112.22.3....121\n"
"34134323.4.422113.\n"
".1332113.234.341..\n"
"21.13.33.2144.111.\n") == 0);
free(board809565426);
board809565426 = NULL;
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 30 );
assert( gamma_move(board, 2, 1, 17) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_free_fields(board, 2) == 39 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_free_fields(board, 4) == 39 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_free_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_free_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_move(board, 2, 12, 3) == 1 );
assert( gamma_move(board, 3, 8, 6) == 1 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 11, 7) == 1 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 2, 16, 1) == 1 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_free_fields(board, 1) == 34 );
assert( gamma_move(board, 2, 1, 17) == 0 );
assert( gamma_move(board, 2, 2, 0) == 1 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_golden_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 6, 17) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_golden_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 16, 5) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 17, 4) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );


char* board490393901 = gamma_board(board);
assert( board490393901 != NULL );
assert( strcmp(board490393901, 
"44.12.414414.41122\n"
".331134.3431.3.4..\n"
"32441411.432212423\n"
"333233.1.4.43..344\n"
"4.2112.22.3.2..121\n"
"34134323.4.422113.\n"
".1332113.234.3412.\n"
"21213.33.2144.111.\n") == 0);
free(board490393901);
board490393901 = NULL;
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_golden_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 16, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_free_fields(board, 4) == 30 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 0, 17) == 0 );
assert( gamma_free_fields(board, 4) == 30 );
assert( gamma_move(board, 1, 14, 3) == 1 );
assert( gamma_move(board, 2, 0, 17) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 4, 14) == 0 );


char* board811409302 = gamma_board(board);
assert( board811409302 != NULL );
assert( strcmp(board811409302, 
"44.12.414414.41122\n"
".331134.3431.3.4..\n"
"32441411.432212423\n"
"333233.1.4.43..344\n"
"4.211242213.2.1121\n"
"34134323.4.422113.\n"
".1332113.234.3412.\n"
"21213.33.2144.111.\n") == 0);
free(board811409302);
board811409302 = NULL;
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 8, 1) == 1 );
assert( gamma_move(board, 1, 1, 17) == 0 );
assert( gamma_move(board, 2, 6, 17) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 4, 8, 0) == 1 );
assert( gamma_free_fields(board, 4) == 27 );
assert( gamma_golden_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_golden_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 31 );


char* board840576214 = gamma_board(board);
assert( board840576214 != NULL );
assert( strcmp(board840576214, 
"44112.414414.41122\n"
".331134.3431.3.4..\n"
"32441411.432212423\n"
"333233.1.4.43..344\n"
"4.211242213.2.1121\n"
"34134323.4.422113.\n"
".13321134234.3412.\n"
"21213.3342144.111.\n") == 0);
free(board840576214);
board840576214 = NULL;
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 14, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 1, 7) == 0 );


char* board523318285 = gamma_board(board);
assert( board523318285 != NULL );
assert( strcmp(board523318285, 
"44112.414414.41122\n"
".331134.3431.3.4..\n"
"32441411.432212423\n"
"333233.1.4.43.2344\n"
"4.211242213.2.1121\n"
"34134323.4.422113.\n"
".13321134234.3412.\n"
"21213.3342144.111.\n") == 0);
free(board523318285);
board523318285 = NULL;


gamma_delete(board);

    return 0;
}
