#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 110888793
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 179, 7, 25);
assert( board != NULL );


assert( gamma_move(board, 1, 149, 0) == 0 );
assert( gamma_move(board, 1, 0, 38) == 1 );
assert( gamma_move(board, 2, 0, 55) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 4, 176, 0) == 0 );
assert( gamma_move(board, 4, 0, 19) == 1 );
assert( gamma_move(board, 5, 148, 0) == 0 );
assert( gamma_move(board, 5, 0, 87) == 1 );
assert( gamma_busy_fields(board, 5) == 1 );
assert( gamma_move(board, 6, 168, 0) == 0 );
assert( gamma_move(board, 6, 0, 46) == 1 );
assert( gamma_move(board, 7, 148, 0) == 0 );
assert( gamma_move(board, 7, 0, 88) == 1 );
assert( gamma_move(board, 1, 98, 0) == 0 );
assert( gamma_free_fields(board, 1) == 172 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 171, 0) == 0 );
assert( gamma_move(board, 2, 0, 131) == 1 );
assert( gamma_move(board, 3, 28, 0) == 0 );
assert( gamma_golden_move(board, 3, 38, 0) == 0 );
assert( gamma_move(board, 4, 174, 0) == 0 );
assert( gamma_move(board, 5, 74, 0) == 0 );
assert( gamma_move(board, 6, 0, 176) == 1 );
assert( gamma_move(board, 6, 0, 114) == 1 );


char* board333958972 = gamma_board(board);
assert( board333958972 != NULL );
assert( strcmp(board333958972, 
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board333958972);
board333958972 = NULL;
assert( gamma_move(board, 2, 0, 73) == 1 );
assert( gamma_move(board, 3, 0, 37) == 1 );
assert( gamma_move(board, 3, 0, 132) == 1 );
assert( gamma_move(board, 4, 170, 0) == 0 );
assert( gamma_move(board, 4, 0, 13) == 1 );
assert( gamma_free_fields(board, 4) == 165 );
assert( gamma_move(board, 5, 0, 97) == 1 );
assert( gamma_move(board, 6, 0, 165) == 1 );
assert( gamma_move(board, 6, 0, 17) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 119, 0) == 0 );
assert( gamma_free_fields(board, 7) == 162 );
assert( gamma_move(board, 1, 0, 32) == 1 );
assert( gamma_move(board, 1, 0, 138) == 1 );
assert( gamma_move(board, 2, 40, 0) == 0 );
assert( gamma_move(board, 2, 0, 79) == 1 );
assert( gamma_move(board, 3, 166, 0) == 0 );
assert( gamma_move(board, 3, 0, 132) == 0 );
assert( gamma_move(board, 4, 111, 0) == 0 );
assert( gamma_move(board, 4, 0, 140) == 1 );
assert( gamma_golden_move(board, 4, 38, 0) == 0 );
assert( gamma_move(board, 5, 0, 29) == 1 );


char* board350277814 = gamma_board(board);
assert( board350277814 != NULL );
assert( strcmp(board350277814, 
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board350277814);
board350277814 = NULL;
assert( gamma_move(board, 7, 0, 29) == 0 );
assert( gamma_move(board, 1, 95, 0) == 0 );
assert( gamma_move(board, 2, 0, 164) == 1 );
assert( gamma_move(board, 3, 0, 30) == 1 );
assert( gamma_move(board, 3, 0, 73) == 0 );
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_move(board, 5, 106, 0) == 0 );
assert( gamma_move(board, 5, 0, 56) == 1 );
assert( gamma_move(board, 6, 0, 63) == 1 );
assert( gamma_move(board, 6, 0, 36) == 1 );
assert( gamma_move(board, 7, 0, 130) == 1 );
assert( gamma_move(board, 1, 0, 50) == 1 );
assert( gamma_move(board, 2, 0, 50) == 0 );
assert( gamma_move(board, 3, 20, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_move(board, 4, 28, 0) == 0 );
assert( gamma_move(board, 4, 0, 154) == 1 );
assert( gamma_move(board, 5, 162, 0) == 0 );
assert( gamma_move(board, 6, 144, 0) == 0 );
assert( gamma_move(board, 7, 116, 0) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 1, 0, 72) == 1 );
assert( gamma_move(board, 2, 95, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 150, 0) == 0 );
assert( gamma_move(board, 3, 0, 67) == 1 );
assert( gamma_move(board, 4, 0, 70) == 1 );
assert( gamma_move(board, 5, 59, 0) == 0 );
assert( gamma_move(board, 5, 0, 154) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 169) == 1 );
assert( gamma_move(board, 6, 0, 25) == 1 );
assert( gamma_move(board, 7, 148, 0) == 0 );
assert( gamma_move(board, 7, 0, 77) == 1 );
assert( gamma_free_fields(board, 1) == 142 );
assert( gamma_move(board, 2, 68, 0) == 0 );
assert( gamma_move(board, 2, 0, 93) == 1 );
assert( gamma_golden_move(board, 2, 88, 0) == 0 );
assert( gamma_move(board, 3, 129, 0) == 0 );


char* board417293008 = gamma_board(board);
assert( board417293008 != NULL );
assert( strcmp(board417293008, 
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
"5\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"6\n"
".\n"
".\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board417293008);
board417293008 = NULL;
assert( gamma_move(board, 4, 23, 0) == 0 );
assert( gamma_move(board, 5, 144, 0) == 0 );
assert( gamma_move(board, 5, 0, 81) == 1 );
assert( gamma_move(board, 6, 0, 41) == 1 );
assert( gamma_move(board, 7, 0, 100) == 1 );
assert( gamma_move(board, 1, 177, 0) == 0 );
assert( gamma_move(board, 2, 0, 41) == 0 );
assert( gamma_move(board, 3, 76, 0) == 0 );
assert( gamma_move(board, 3, 0, 61) == 1 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 4, 0, 42) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 44, 0) == 0 );
assert( gamma_move(board, 7, 119, 0) == 0 );
assert( gamma_golden_move(board, 7, 38, 0) == 0 );
assert( gamma_move(board, 1, 151, 0) == 0 );
assert( gamma_move(board, 1, 0, 132) == 0 );
assert( gamma_move(board, 2, 144, 0) == 0 );
assert( gamma_move(board, 2, 0, 24) == 1 );
assert( gamma_move(board, 3, 0, 137) == 1 );
assert( gamma_free_fields(board, 4) == 134 );
assert( gamma_move(board, 5, 86, 0) == 0 );
assert( gamma_move(board, 6, 45, 0) == 0 );
assert( gamma_move(board, 6, 0, 28) == 1 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 0, 22) == 1 );
assert( gamma_move(board, 2, 0, 35) == 1 );
assert( gamma_move(board, 3, 0, 166) == 1 );
assert( gamma_move(board, 3, 0, 36) == 0 );
assert( gamma_move(board, 4, 147, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_free_fields(board, 5) == 130 );
assert( gamma_golden_move(board, 5, 131, 0) == 0 );
assert( gamma_move(board, 6, 151, 0) == 0 );
assert( gamma_move(board, 7, 0, 30) == 0 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_move(board, 1, 162, 0) == 0 );
assert( gamma_move(board, 2, 26, 0) == 0 );
assert( gamma_move(board, 2, 0, 80) == 1 );
assert( gamma_move(board, 3, 153, 0) == 0 );
assert( gamma_move(board, 4, 160, 0) == 0 );
assert( gamma_free_fields(board, 5) == 128 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 32) == 0 );
assert( gamma_busy_fields(board, 7) == 5 );
assert( gamma_free_fields(board, 7) == 128 );
assert( gamma_move(board, 1, 94, 0) == 0 );
assert( gamma_move(board, 1, 0, 88) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 118) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 1, 0) == 0 );


char* board309011290 = gamma_board(board);
assert( board309011290 != NULL );
assert( strcmp(board309011290, 
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
"5\n"
"6\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
"6\n"
".\n"
".\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n") == 0);
free(board309011290);
board309011290 = NULL;
assert( gamma_move(board, 5, 0, 115) == 1 );
assert( gamma_move(board, 6, 112, 0) == 0 );
assert( gamma_move(board, 6, 0, 138) == 0 );
assert( gamma_move(board, 7, 157, 0) == 0 );
assert( gamma_move(board, 7, 0, 95) == 1 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_free_fields(board, 1) == 125 );
assert( gamma_move(board, 2, 0, 144) == 1 );
assert( gamma_free_fields(board, 3) == 124 );
assert( gamma_move(board, 4, 98, 0) == 0 );
assert( gamma_move(board, 4, 0, 101) == 1 );
assert( gamma_move(board, 6, 74, 0) == 0 );


char* board673503045 = gamma_board(board);
assert( board673503045 != NULL );
assert( strcmp(board673503045, 
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"5\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"2\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
"5\n"
"6\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
"6\n"
".\n"
".\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n") == 0);
free(board673503045);
board673503045 = NULL;
assert( gamma_move(board, 7, 143, 0) == 0 );
assert( gamma_move(board, 1, 0, 139) == 1 );
assert( gamma_move(board, 1, 0, 173) == 1 );
assert( gamma_free_fields(board, 1) == 121 );
assert( gamma_move(board, 2, 112, 0) == 0 );
assert( gamma_move(board, 2, 0, 90) == 1 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_free_fields(board, 2) == 120 );
assert( gamma_move(board, 3, 0, 110) == 1 );
assert( gamma_move(board, 4, 45, 0) == 0 );
assert( gamma_move(board, 4, 0, 98) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 74) == 1 );
assert( gamma_move(board, 6, 0, 97) == 0 );
assert( gamma_move(board, 6, 0, 53) == 1 );
assert( gamma_move(board, 7, 119, 0) == 0 );
assert( gamma_move(board, 7, 0, 108) == 1 );


char* board806876276 = gamma_board(board);
assert( board806876276 != NULL );
assert( strcmp(board806876276, 
".\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"5\n"
"6\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
"7\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
".\n"
"7\n"
".\n"
".\n"
"5\n"
"2\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
"5\n"
"6\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
"6\n"
".\n"
".\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n") == 0);
free(board806876276);
board806876276 = NULL;
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 1, 0, 85) == 1 );
assert( gamma_move(board, 2, 153, 0) == 0 );
assert( gamma_move(board, 2, 0, 118) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board785103407 = gamma_board(board);
assert( board785103407 != NULL );
assert( strcmp(board785103407, 
".\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"5\n"
"6\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
"7\n"
"5\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
".\n"
"7\n"
".\n"
".\n"
"5\n"
"2\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
"5\n"
"6\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
"6\n"
".\n"
".\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n") == 0);
free(board785103407);
board785103407 = NULL;
assert( gamma_move(board, 4, 26, 0) == 0 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 6, 0, 14) == 0 );
assert( gamma_move(board, 7, 136, 0) == 0 );
assert( gamma_move(board, 1, 133, 0) == 0 );
assert( gamma_move(board, 1, 0, 172) == 1 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 3, 91, 0) == 0 );
assert( gamma_move(board, 3, 0, 78) == 1 );


char* board818200739 = gamma_board(board);
assert( board818200739 != NULL );
assert( strcmp(board818200739, 
".\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"5\n"
"6\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
"7\n"
"5\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
".\n"
".\n"
"5\n"
"2\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
"5\n"
"6\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
"6\n"
".\n"
".\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n") == 0);
free(board818200739);
board818200739 = NULL;
assert( gamma_move(board, 4, 162, 0) == 0 );
assert( gamma_move(board, 4, 0, 17) == 0 );
assert( gamma_golden_move(board, 4, 163, 0) == 0 );
assert( gamma_move(board, 5, 0, 126) == 1 );
assert( gamma_move(board, 6, 58, 0) == 0 );
assert( gamma_move(board, 6, 0, 137) == 0 );
assert( gamma_move(board, 7, 0, 44) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 145, 0) == 0 );
assert( gamma_move(board, 2, 123, 0) == 0 );
assert( gamma_move(board, 2, 0, 177) == 1 );
assert( gamma_move(board, 3, 0, 97) == 0 );
assert( gamma_move(board, 3, 0, 22) == 0 );
assert( gamma_free_fields(board, 3) == 109 );
assert( gamma_move(board, 4, 0, 150) == 1 );
assert( gamma_move(board, 4, 0, 56) == 0 );
assert( gamma_move(board, 5, 0, 16) == 1 );
assert( gamma_move(board, 5, 0, 130) == 0 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_move(board, 6, 0, 117) == 1 );
assert( gamma_move(board, 6, 0, 173) == 0 );
assert( gamma_move(board, 7, 0, 38) == 0 );
assert( gamma_move(board, 1, 49, 0) == 0 );
assert( gamma_move(board, 2, 94, 0) == 0 );
assert( gamma_move(board, 2, 0, 167) == 1 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 3, 0, 136) == 1 );
assert( gamma_free_fields(board, 3) == 103 );
assert( gamma_move(board, 4, 175, 0) == 0 );
assert( gamma_move(board, 4, 0, 26) == 1 );
assert( gamma_move(board, 5, 128, 0) == 0 );
assert( gamma_move(board, 5, 0, 164) == 0 );
assert( gamma_move(board, 6, 0, 142) == 1 );
assert( gamma_move(board, 7, 0, 10) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 111, 0) == 0 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 2, 0, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 32, 0) == 0 );
assert( gamma_move(board, 4, 84, 0) == 0 );
assert( gamma_move(board, 4, 0, 33) == 1 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 6, 51, 0) == 0 );
assert( gamma_move(board, 6, 0, 37) == 0 );
assert( gamma_move(board, 7, 0, 28) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 0, 108) == 0 );
assert( gamma_move(board, 2, 0, 115) == 0 );
assert( gamma_move(board, 2, 0, 46) == 0 );
assert( gamma_free_fields(board, 2) == 97 );
assert( gamma_move(board, 3, 0, 113) == 1 );
assert( gamma_move(board, 3, 0, 116) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_free_fields(board, 4) == 95 );
assert( gamma_move(board, 5, 76, 0) == 0 );
assert( gamma_move(board, 5, 0, 38) == 0 );
assert( gamma_free_fields(board, 7) == 95 );
assert( gamma_move(board, 1, 0, 120) == 1 );
assert( gamma_move(board, 1, 0, 43) == 1 );
assert( gamma_move(board, 2, 83, 0) == 0 );
assert( gamma_move(board, 2, 0, 95) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 48, 0) == 0 );
assert( gamma_move(board, 4, 0, 59) == 1 );
assert( gamma_move(board, 4, 0, 30) == 0 );
assert( gamma_move(board, 5, 0, 25) == 0 );
assert( gamma_move(board, 5, 0, 141) == 1 );
assert( gamma_move(board, 6, 159, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 124) == 1 );
assert( gamma_move(board, 7, 0, 52) == 1 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 0, 136) == 0 );
assert( gamma_move(board, 3, 162, 0) == 0 );
assert( gamma_move(board, 3, 0, 64) == 1 );
assert( gamma_move(board, 4, 45, 0) == 0 );
assert( gamma_move(board, 5, 0, 61) == 0 );
assert( gamma_move(board, 5, 0, 142) == 0 );
assert( gamma_move(board, 6, 0, 51) == 1 );
assert( gamma_move(board, 7, 111, 0) == 0 );
assert( gamma_move(board, 1, 0, 169) == 0 );
assert( gamma_move(board, 2, 0, 19) == 0 );
assert( gamma_move(board, 3, 0, 133) == 1 );
assert( gamma_move(board, 4, 76, 0) == 0 );
assert( gamma_move(board, 5, 0, 66) == 1 );
assert( gamma_move(board, 6, 0, 113) == 0 );
assert( gamma_golden_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 7, 163, 0) == 0 );
assert( gamma_move(board, 1, 160, 0) == 0 );
assert( gamma_move(board, 1, 0, 103) == 1 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_golden_move(board, 2, 78, 0) == 0 );
assert( gamma_move(board, 3, 0, 140) == 0 );
assert( gamma_move(board, 4, 0, 177) == 0 );
assert( gamma_move(board, 5, 149, 0) == 0 );
assert( gamma_move(board, 5, 0, 74) == 0 );
assert( gamma_move(board, 6, 174, 0) == 0 );
assert( gamma_move(board, 7, 125, 0) == 0 );
assert( gamma_move(board, 7, 0, 101) == 0 );
assert( gamma_move(board, 1, 49, 0) == 0 );
assert( gamma_move(board, 1, 0, 33) == 0 );
assert( gamma_move(board, 2, 0, 158) == 1 );
assert( gamma_free_fields(board, 2) == 83 );
assert( gamma_move(board, 3, 92, 0) == 0 );
assert( gamma_move(board, 4, 174, 0) == 0 );
assert( gamma_golden_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 5, 156, 0) == 0 );
assert( gamma_golden_move(board, 5, 28, 0) == 0 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_move(board, 7, 28, 0) == 0 );
assert( gamma_move(board, 1, 0, 89) == 1 );
assert( gamma_move(board, 1, 0, 31) == 1 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 0, 57) == 1 );
assert( gamma_move(board, 4, 104, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 45, 0) == 0 );
assert( gamma_free_fields(board, 5) == 80 );
assert( gamma_move(board, 6, 102, 0) == 0 );
assert( gamma_move(board, 6, 0, 12) == 1 );
assert( gamma_move(board, 7, 178, 0) == 0 );
assert( gamma_move(board, 1, 174, 0) == 0 );
assert( gamma_move(board, 1, 0, 149) == 1 );
assert( gamma_move(board, 2, 148, 0) == 0 );
assert( gamma_move(board, 3, 106, 0) == 0 );
assert( gamma_move(board, 3, 0, 95) == 0 );
assert( gamma_move(board, 4, 178, 0) == 0 );
assert( gamma_move(board, 5, 76, 0) == 0 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 65, 0) == 0 );
assert( gamma_move(board, 6, 0, 162) == 1 );
assert( gamma_golden_move(board, 6, 132, 0) == 0 );
assert( gamma_move(board, 7, 94, 0) == 0 );
assert( gamma_move(board, 7, 0, 42) == 0 );
assert( gamma_move(board, 1, 178, 0) == 0 );
assert( gamma_free_fields(board, 2) == 77 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 3, 0, 174) == 1 );
assert( gamma_move(board, 4, 23, 0) == 0 );
assert( gamma_move(board, 4, 0, 20) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 159, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 159, 0) == 0 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_free_fields(board, 6) == 75 );
assert( gamma_move(board, 7, 91, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 93) == 0 );
assert( gamma_move(board, 2, 119, 0) == 0 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 3, 102, 0) == 0 );
assert( gamma_move(board, 4, 58, 0) == 0 );
assert( gamma_move(board, 4, 0, 173) == 0 );
assert( gamma_move(board, 5, 128, 0) == 0 );
assert( gamma_move(board, 5, 0, 88) == 0 );
assert( gamma_move(board, 6, 92, 0) == 0 );
assert( gamma_move(board, 7, 156, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 84) == 1 );
assert( gamma_free_fields(board, 1) == 74 );
assert( gamma_move(board, 2, 0, 134) == 1 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 141) == 0 );
assert( gamma_move(board, 5, 91, 0) == 0 );
assert( gamma_move(board, 6, 0, 150) == 0 );
assert( gamma_move(board, 6, 0, 133) == 0 );
assert( gamma_move(board, 7, 0, 32) == 0 );
assert( gamma_free_fields(board, 7) == 73 );
assert( gamma_move(board, 1, 160, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 135, 0) == 0 );
assert( gamma_move(board, 2, 0, 75) == 1 );
assert( gamma_free_fields(board, 3) == 72 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 23, 0) == 0 );
assert( gamma_move(board, 4, 0, 139) == 0 );
assert( gamma_move(board, 5, 178, 0) == 0 );
assert( gamma_move(board, 6, 0, 22) == 0 );
assert( gamma_move(board, 7, 60, 0) == 0 );
assert( gamma_move(board, 7, 0, 41) == 0 );
assert( gamma_move(board, 1, 0, 15) == 1 );
assert( gamma_move(board, 1, 0, 158) == 0 );
assert( gamma_free_fields(board, 1) == 71 );
assert( gamma_golden_move(board, 1, 126, 0) == 0 );
assert( gamma_move(board, 3, 0, 34) == 1 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 0, 69) == 1 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_free_fields(board, 5) == 69 );
assert( gamma_move(board, 6, 161, 0) == 0 );
assert( gamma_move(board, 7, 5, 0) == 0 );
assert( gamma_golden_move(board, 7, 33, 0) == 0 );
assert( gamma_move(board, 1, 0, 133) == 0 );
assert( gamma_move(board, 1, 0, 172) == 0 );
assert( gamma_move(board, 2, 0, 71) == 1 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 135, 0) == 0 );
assert( gamma_move(board, 3, 0, 119) == 1 );
assert( gamma_free_fields(board, 3) == 67 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 54, 0) == 0 );
assert( gamma_free_fields(board, 4) == 67 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 6, 0, 93) == 0 );
assert( gamma_move(board, 7, 76, 0) == 0 );
assert( gamma_move(board, 7, 0, 36) == 0 );
assert( gamma_move(board, 1, 18, 0) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 0, 112) == 1 );
assert( gamma_move(board, 3, 48, 0) == 0 );
assert( gamma_move(board, 3, 0, 55) == 0 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 48, 0) == 0 );
assert( gamma_move(board, 4, 0, 116) == 0 );
assert( gamma_move(board, 5, 0, 132) == 0 );
assert( gamma_move(board, 5, 0, 25) == 0 );
assert( gamma_move(board, 6, 40, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 0, 16) == 0 );
assert( gamma_move(board, 1, 109, 0) == 0 );
assert( gamma_move(board, 2, 96, 0) == 0 );
assert( gamma_move(board, 3, 94, 0) == 0 );
assert( gamma_move(board, 3, 0, 115) == 0 );
assert( gamma_move(board, 4, 0, 35) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 171, 0) == 0 );
assert( gamma_move(board, 6, 0, 72) == 0 );
assert( gamma_move(board, 7, 152, 0) == 0 );
assert( gamma_move(board, 7, 0, 124) == 0 );
assert( gamma_golden_move(board, 7, 101, 0) == 0 );
assert( gamma_move(board, 1, 91, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 121, 0) == 0 );
assert( gamma_free_fields(board, 2) == 65 );
assert( gamma_move(board, 3, 0, 113) == 0 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_move(board, 4, 171, 0) == 0 );


char* board704462968 = gamma_board(board);
assert( board704462968 != NULL );
assert( strcmp(board704462968, 
".\n"
"2\n"
"6\n"
".\n"
"3\n"
"1\n"
"1\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
"3\n"
"6\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"6\n"
"5\n"
"4\n"
"1\n"
"1\n"
"3\n"
"3\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"2\n"
"6\n"
"3\n"
"5\n"
"6\n"
"3\n"
"2\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"7\n"
"5\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
".\n"
"2\n"
"5\n"
"2\n"
"1\n"
"2\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"6\n"
".\n"
"3\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
"2\n"
".\n"
"6\n"
"7\n"
"6\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"7\n"
"1\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
"3\n"
"4\n"
"1\n"
"1\n"
"3\n"
"5\n"
"6\n"
".\n"
"4\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
"4\n"
"4\n"
".\n"
"6\n"
"5\n"
"1\n"
"4\n"
"4\n"
"6\n"
"3\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
"2\n"
"7\n") == 0);
free(board704462968);
board704462968 = NULL;
assert( gamma_move(board, 5, 92, 0) == 0 );
assert( gamma_move(board, 5, 0, 170) == 1 );


char* board156016580 = gamma_board(board);
assert( board156016580 != NULL );
assert( strcmp(board156016580, 
".\n"
"2\n"
"6\n"
".\n"
"3\n"
"1\n"
"1\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"3\n"
"6\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"6\n"
"5\n"
"4\n"
"1\n"
"1\n"
"3\n"
"3\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"2\n"
"6\n"
"3\n"
"5\n"
"6\n"
"3\n"
"2\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"7\n"
"5\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
".\n"
"2\n"
"5\n"
"2\n"
"1\n"
"2\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"6\n"
".\n"
"3\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
"2\n"
".\n"
"6\n"
"7\n"
"6\n"
"1\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"7\n"
"1\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
"3\n"
"4\n"
"1\n"
"1\n"
"3\n"
"5\n"
"6\n"
".\n"
"4\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
"4\n"
"4\n"
".\n"
"6\n"
"5\n"
"1\n"
"4\n"
"4\n"
"6\n"
"3\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
"2\n"
"7\n") == 0);
free(board156016580);
board156016580 = NULL;
assert( gamma_move(board, 6, 96, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 81) == 0 );
assert( gamma_move(board, 7, 0, 106) == 1 );
assert( gamma_busy_fields(board, 7) == 12 );
assert( gamma_move(board, 1, 94, 0) == 0 );
assert( gamma_move(board, 2, 96, 0) == 0 );
assert( gamma_move(board, 2, 0, 72) == 0 );
assert( gamma_move(board, 3, 76, 0) == 0 );
assert( gamma_move(board, 3, 0, 55) == 0 );
assert( gamma_golden_move(board, 3, 131, 0) == 0 );
assert( gamma_move(board, 4, 0, 18) == 1 );
assert( gamma_move(board, 5, 58, 0) == 0 );
assert( gamma_move(board, 5, 0, 49) == 1 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 6, 0, 88) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 114) == 0 );
assert( gamma_move(board, 7, 0, 19) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 2, 0, 102) == 1 );
assert( gamma_move(board, 2, 0, 59) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_golden_move(board, 2, 140, 0) == 0 );
assert( gamma_move(board, 3, 121, 0) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 5, 39, 0) == 0 );
assert( gamma_move(board, 5, 0, 177) == 0 );
assert( gamma_move(board, 6, 151, 0) == 0 );
assert( gamma_move(board, 7, 147, 0) == 0 );
assert( gamma_move(board, 7, 0, 70) == 0 );
assert( gamma_move(board, 1, 127, 0) == 0 );


char* board860051227 = gamma_board(board);
assert( board860051227 != NULL );
assert( strcmp(board860051227, 
".\n"
"2\n"
"6\n"
".\n"
"3\n"
"1\n"
"1\n"
".\n"
"5\n"
"6\n"
".\n"
"2\n"
"3\n"
"6\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"6\n"
"5\n"
"4\n"
"1\n"
"1\n"
"3\n"
"3\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"2\n"
"6\n"
"3\n"
"5\n"
"6\n"
"3\n"
"2\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
".\n"
"1\n"
"2\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"7\n"
"5\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
".\n"
"2\n"
"5\n"
"2\n"
"1\n"
"2\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"6\n"
".\n"
"3\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
"2\n"
".\n"
"6\n"
"7\n"
"6\n"
"1\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
"7\n"
"1\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
"3\n"
"4\n"
"1\n"
"1\n"
"3\n"
"5\n"
"6\n"
".\n"
"4\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
"4\n"
"4\n"
"4\n"
"6\n"
"5\n"
"1\n"
"4\n"
"4\n"
"6\n"
"3\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
"2\n"
"7\n") == 0);
free(board860051227);
board860051227 = NULL;
assert( gamma_move(board, 2, 0, 171) == 1 );
assert( gamma_move(board, 3, 39, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 167) == 0 );
assert( gamma_move(board, 5, 0, 104) == 1 );
assert( gamma_move(board, 6, 161, 0) == 0 );


char* board343293471 = gamma_board(board);
assert( board343293471 != NULL );
assert( strcmp(board343293471, 
".\n"
"2\n"
"6\n"
".\n"
"3\n"
"1\n"
"1\n"
"2\n"
"5\n"
"6\n"
".\n"
"2\n"
"3\n"
"6\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"6\n"
"5\n"
"4\n"
"1\n"
"1\n"
"3\n"
"3\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"2\n"
"6\n"
"3\n"
"5\n"
"6\n"
"3\n"
"2\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
"5\n"
"1\n"
"2\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"7\n"
"5\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
".\n"
"2\n"
"5\n"
"2\n"
"1\n"
"2\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"6\n"
".\n"
"3\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
"2\n"
".\n"
"6\n"
"7\n"
"6\n"
"1\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
"7\n"
"1\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
"3\n"
"4\n"
"1\n"
"1\n"
"3\n"
"5\n"
"6\n"
".\n"
"4\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
"4\n"
"4\n"
"4\n"
"6\n"
"5\n"
"1\n"
"4\n"
"4\n"
"6\n"
"3\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
"2\n"
"7\n") == 0);
free(board343293471);
board343293471 = NULL;
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 1, 0, 148) == 1 );
assert( gamma_move(board, 2, 155, 0) == 0 );
assert( gamma_golden_move(board, 2, 95, 0) == 0 );
assert( gamma_move(board, 3, 60, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 0, 103) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 5, 0, 145) == 1 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_move(board, 6, 86, 0) == 0 );
assert( gamma_move(board, 6, 0, 173) == 0 );
assert( gamma_move(board, 7, 125, 0) == 0 );
assert( gamma_move(board, 1, 128, 0) == 0 );
assert( gamma_free_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 45, 0) == 0 );
assert( gamma_move(board, 2, 0, 172) == 0 );
assert( gamma_move(board, 3, 0, 135) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 5, 0, 64) == 0 );
assert( gamma_move(board, 6, 94, 0) == 0 );
assert( gamma_move(board, 6, 0, 24) == 0 );
assert( gamma_move(board, 7, 96, 0) == 0 );
assert( gamma_move(board, 1, 159, 0) == 0 );
assert( gamma_move(board, 1, 0, 156) == 1 );
assert( gamma_move(board, 2, 0, 76) == 1 );
assert( gamma_move(board, 2, 0, 61) == 0 );
assert( gamma_move(board, 3, 178, 0) == 0 );
assert( gamma_move(board, 3, 0, 69) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 5, 47, 0) == 0 );
assert( gamma_move(board, 6, 7, 0) == 0 );


char* board434265527 = gamma_board(board);
assert( board434265527 != NULL );
assert( strcmp(board434265527, 
".\n"
"2\n"
"6\n"
".\n"
"3\n"
"1\n"
"1\n"
"2\n"
"5\n"
"6\n"
".\n"
"2\n"
"3\n"
"6\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
"6\n"
"5\n"
"4\n"
"1\n"
"1\n"
"3\n"
"3\n"
"3\n"
"2\n"
"3\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"2\n"
"6\n"
"3\n"
"5\n"
"6\n"
"3\n"
"2\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
"5\n"
"1\n"
"2\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"1\n"
"7\n"
"5\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
"2\n"
"2\n"
"5\n"
"2\n"
"1\n"
"2\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"6\n"
".\n"
"3\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
"2\n"
".\n"
"6\n"
"7\n"
"6\n"
"1\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
"7\n"
"1\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
"3\n"
"4\n"
"1\n"
"1\n"
"3\n"
"5\n"
"6\n"
".\n"
"4\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
"4\n"
"4\n"
"4\n"
"6\n"
"5\n"
"1\n"
"4\n"
"4\n"
"6\n"
"3\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
"2\n"
"7\n") == 0);
free(board434265527);
board434265527 = NULL;
assert( gamma_move(board, 7, 0, 113) == 0 );
assert( gamma_move(board, 1, 168, 0) == 0 );
assert( gamma_move(board, 1, 0, 173) == 0 );
assert( gamma_free_fields(board, 1) == 53 );
assert( gamma_move(board, 2, 143, 0) == 0 );
assert( gamma_move(board, 2, 0, 27) == 1 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 153, 0) == 0 );
assert( gamma_free_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 123, 0) == 0 );
assert( gamma_move(board, 5, 58, 0) == 0 );
assert( gamma_move(board, 6, 143, 0) == 0 );
assert( gamma_move(board, 7, 45, 0) == 0 );
assert( gamma_move(board, 7, 0, 50) == 0 );
assert( gamma_free_fields(board, 7) == 52 );
assert( gamma_move(board, 1, 128, 0) == 0 );
assert( gamma_move(board, 2, 111, 0) == 0 );
assert( gamma_move(board, 3, 99, 0) == 0 );
assert( gamma_move(board, 4, 151, 0) == 0 );
assert( gamma_move(board, 4, 0, 76) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 0, 91) == 1 );
assert( gamma_move(board, 5, 0, 5) == 1 );
assert( gamma_free_fields(board, 5) == 50 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 6, 0, 31) == 0 );
assert( gamma_move(board, 7, 125, 0) == 0 );


char* board657525571 = gamma_board(board);
assert( board657525571 != NULL );
assert( strcmp(board657525571, 
".\n"
"2\n"
"6\n"
".\n"
"3\n"
"1\n"
"1\n"
"2\n"
"5\n"
"6\n"
".\n"
"2\n"
"3\n"
"6\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
"6\n"
"5\n"
"4\n"
"1\n"
"1\n"
"3\n"
"3\n"
"3\n"
"2\n"
"3\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"2\n"
"6\n"
"3\n"
"5\n"
"6\n"
"3\n"
"2\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
"5\n"
"1\n"
"2\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
"5\n"
"2\n"
"1\n"
"7\n"
"5\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
"2\n"
"2\n"
"5\n"
"2\n"
"1\n"
"2\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"6\n"
".\n"
"3\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
"2\n"
".\n"
"6\n"
"7\n"
"6\n"
"1\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
"7\n"
"1\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
"3\n"
"4\n"
"1\n"
"1\n"
"3\n"
"5\n"
"6\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
"4\n"
"4\n"
"4\n"
"6\n"
"5\n"
"1\n"
"4\n"
"4\n"
"6\n"
"3\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"2\n"
"5\n"
"2\n"
"7\n") == 0);
free(board657525571);
board657525571 = NULL;
assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_move(board, 2, 58, 0) == 0 );
assert( gamma_free_fields(board, 2) == 14 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 58, 0) == 0 );
assert( gamma_move(board, 4, 125, 0) == 0 );
assert( gamma_move(board, 5, 48, 0) == 0 );
assert( gamma_move(board, 5, 0, 138) == 0 );
assert( gamma_free_fields(board, 5) == 50 );
assert( gamma_move(board, 6, 147, 0) == 0 );
assert( gamma_move(board, 6, 0, 112) == 0 );
assert( gamma_move(board, 7, 0, 4) == 1 );


char* board401707796 = gamma_board(board);
assert( board401707796 != NULL );
assert( strcmp(board401707796, 
".\n"
"2\n"
"6\n"
".\n"
"3\n"
"1\n"
"1\n"
"2\n"
"5\n"
"6\n"
".\n"
"2\n"
"3\n"
"6\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
"6\n"
"5\n"
"4\n"
"1\n"
"1\n"
"3\n"
"3\n"
"3\n"
"2\n"
"3\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"2\n"
"6\n"
"3\n"
"5\n"
"6\n"
"3\n"
"2\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
"5\n"
"1\n"
"2\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
"5\n"
"2\n"
"1\n"
"7\n"
"5\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
"2\n"
"2\n"
"5\n"
"2\n"
"1\n"
"2\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"6\n"
".\n"
"3\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
"2\n"
".\n"
"6\n"
"7\n"
"6\n"
"1\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
"7\n"
"1\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
"3\n"
"4\n"
"1\n"
"1\n"
"3\n"
"5\n"
"6\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
"4\n"
"4\n"
"4\n"
"6\n"
"5\n"
"1\n"
"4\n"
"4\n"
"6\n"
"3\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
"7\n"
"2\n"
"5\n"
"2\n"
"7\n") == 0);
free(board401707796);
board401707796 = NULL;
assert( gamma_move(board, 1, 39, 0) == 0 );
assert( gamma_move(board, 1, 0, 164) == 0 );
assert( gamma_move(board, 2, 0, 172) == 0 );
assert( gamma_move(board, 2, 0, 105) == 0 );
assert( gamma_move(board, 3, 151, 0) == 0 );
assert( gamma_move(board, 3, 0, 58) == 1 );
assert( gamma_move(board, 4, 155, 0) == 0 );
assert( gamma_move(board, 5, 163, 0) == 0 );
assert( gamma_move(board, 5, 0, 27) == 0 );
assert( gamma_free_fields(board, 5) == 48 );


char* board765335991 = gamma_board(board);
assert( board765335991 != NULL );
assert( strcmp(board765335991, 
".\n"
"2\n"
"6\n"
".\n"
"3\n"
"1\n"
"1\n"
"2\n"
"5\n"
"6\n"
".\n"
"2\n"
"3\n"
"6\n"
"2\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
"6\n"
"5\n"
"4\n"
"1\n"
"1\n"
"3\n"
"3\n"
"3\n"
"2\n"
"3\n"
"3\n"
"2\n"
"7\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"2\n"
"6\n"
"3\n"
"5\n"
"6\n"
"3\n"
"2\n"
".\n"
"3\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
"5\n"
"1\n"
"2\n"
"4\n"
"7\n"
".\n"
"4\n"
"5\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
"5\n"
"2\n"
"1\n"
"7\n"
"5\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"5\n"
"2\n"
"2\n"
"3\n"
"7\n"
"2\n"
"2\n"
"5\n"
"2\n"
"1\n"
"2\n"
"4\n"
"4\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"6\n"
".\n"
"3\n"
".\n"
"4\n"
"3\n"
"2\n"
"5\n"
"2\n"
".\n"
"6\n"
"7\n"
"6\n"
"1\n"
"5\n"
".\n"
".\n"
"6\n"
".\n"
"7\n"
"1\n"
"4\n"
"6\n"
".\n"
".\n"
"1\n"
"3\n"
"6\n"
"2\n"
"3\n"
"4\n"
"1\n"
"1\n"
"3\n"
"5\n"
"6\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"2\n"
".\n"
"4\n"
"4\n"
"4\n"
"6\n"
"5\n"
"1\n"
"4\n"
"4\n"
"6\n"
"3\n"
"7\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
"7\n"
"2\n"
"5\n"
"2\n"
"7\n") == 0);
free(board765335991);
board765335991 = NULL;
assert( gamma_move(board, 6, 161, 0) == 0 );
assert( gamma_move(board, 7, 127, 0) == 0 );
assert( gamma_move(board, 7, 0, 38) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 2, 0, 48) == 0 );
assert( gamma_move(board, 3, 0, 105) == 1 );
assert( gamma_move(board, 3, 0, 120) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_move(board, 5, 161, 0) == 0 );
assert( gamma_move(board, 5, 0, 48) == 1 );
assert( gamma_move(board, 6, 99, 0) == 0 );
assert( gamma_move(board, 7, 147, 0) == 0 );
assert( gamma_move(board, 1, 161, 0) == 0 );
assert( gamma_move(board, 1, 0, 95) == 0 );
assert( gamma_move(board, 2, 40, 0) == 0 );
assert( gamma_move(board, 2, 0, 120) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 65, 0) == 0 );
assert( gamma_move(board, 3, 0, 51) == 0 );
assert( gamma_move(board, 4, 21, 0) == 0 );
assert( gamma_move(board, 5, 0, 40) == 1 );
assert( gamma_move(board, 5, 0, 113) == 0 );
assert( gamma_move(board, 6, 0, 87) == 0 );
assert( gamma_move(board, 7, 65, 0) == 0 );
assert( gamma_move(board, 1, 155, 0) == 0 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_move(board, 2, 146, 0) == 0 );
assert( gamma_move(board, 3, 39, 0) == 0 );
assert( gamma_move(board, 3, 0, 57) == 0 );
assert( gamma_move(board, 4, 111, 0) == 0 );
assert( gamma_move(board, 6, 96, 0) == 0 );
assert( gamma_move(board, 6, 0, 150) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 157, 0) == 0 );
assert( gamma_move(board, 1, 178, 0) == 0 );
assert( gamma_move(board, 2, 0, 136) == 0 );
assert( gamma_move(board, 2, 0, 22) == 0 );
assert( gamma_move(board, 3, 65, 0) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 0, 77) == 0 );
assert( gamma_move(board, 4, 0, 71) == 0 );
assert( gamma_move(board, 5, 109, 0) == 0 );
assert( gamma_move(board, 6, 0, 32) == 0 );
assert( gamma_move(board, 6, 0, 70) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_free_fields(board, 6) == 44 );
assert( gamma_move(board, 7, 0, 177) == 0 );
assert( gamma_move(board, 7, 0, 76) == 0 );
assert( gamma_move(board, 1, 178, 0) == 0 );
assert( gamma_move(board, 1, 0, 76) == 0 );


gamma_delete(board);

    return 0;
}
