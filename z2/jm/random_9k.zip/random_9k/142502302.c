#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 142502302
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(9, 18, 3, 33);
assert( board != NULL );


assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_free_fields(board, 3) == 160 );
assert( gamma_move(board, 1, 5, 8) == 1 );
assert( gamma_free_fields(board, 1) == 159 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 2, 1, 17) == 1 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 3, 1, 9) == 1 );


char* board140890802 = gamma_board(board);
assert( board140890802 != NULL );
assert( strcmp(board140890802, 
".2.......\n"
".........\n"
".........\n"
".........\n"
".........\n"
".........\n"
".........\n"
".........\n"
".3.......\n"
".....1...\n"
".........\n"
"......2..\n"
"3........\n"
".........\n"
".........\n"
"..1......\n"
".........\n"
".........\n") == 0);
free(board140890802);
board140890802 = NULL;
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 2, 4, 17) == 1 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_golden_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 4, 5) == 1 );


char* board920583271 = gamma_board(board);
assert( board920583271 != NULL );
assert( strcmp(board920583271, 
".2..2....\n"
".........\n"
".........\n"
".........\n"
"......1..\n"
".........\n"
".........\n"
".........\n"
".3.......\n"
".....1...\n"
".........\n"
"......2..\n"
"3..13....\n"
".......2.\n"
".........\n"
"..1.....3\n"
".........\n"
".........\n") == 0);
free(board920583271);
board920583271 = NULL;
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_free_fields(board, 3) == 147 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_golden_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 2, 4, 16) == 1 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_free_fields(board, 3) == 143 );


char* board714597013 = gamma_board(board);
assert( board714597013 != NULL );
assert( strcmp(board714597013, 
".2..2....\n"
"....2....\n"
".........\n"
".........\n"
"......1..\n"
".........\n"
".........\n"
".........\n"
".3..3....\n"
".2...1...\n"
"......3..\n"
"......2..\n"
"3..13....\n"
"2......2.\n"
".....1..1\n"
"..1.....3\n"
".........\n"
".........\n") == 0);
free(board714597013);
board714597013 = NULL;
assert( gamma_move(board, 2, 4, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 3, 2, 1) == 1 );


char* board504923032 = gamma_board(board);
assert( board504923032 != NULL );
assert( strcmp(board504923032, 
".2..2....\n"
"....2....\n"
".........\n"
".........\n"
"......1..\n"
".........\n"
"....2....\n"
".........\n"
".3..3....\n"
".2...1...\n"
"......3..\n"
"......2..\n"
"3..13....\n"
"2......2.\n"
".....1..1\n"
"..1.....3\n"
"..3......\n"
".........\n") == 0);
free(board504923032);
board504923032 = NULL;
assert( gamma_move(board, 1, 6, 4) == 1 );


char* board282328232 = gamma_board(board);
assert( board282328232 != NULL );
assert( strcmp(board282328232, 
".2..2....\n"
"....2....\n"
".........\n"
".........\n"
"......1..\n"
".........\n"
"....2....\n"
".........\n"
".3..3....\n"
".2...1...\n"
"......3..\n"
"......2..\n"
"3..13....\n"
"2.....12.\n"
".....1..1\n"
"..1.....3\n"
"..3......\n"
".........\n") == 0);
free(board282328232);
board282328232 = NULL;
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 12) == 1 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_golden_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 4, 16) == 0 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_move(board, 1, 8, 4) == 1 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_free_fields(board, 3) == 126 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 1, 4, 17) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_golden_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 16, 5) == 0 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_move(board, 2, 8, 17) == 1 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_free_fields(board, 3) == 117 );


char* board332640895 = gamma_board(board);
assert( board332640895 != NULL );
assert( strcmp(board332640895, 
".2..2...2\n"
"....2....\n"
".........\n"
".........\n"
".1....13.\n"
"1......32\n"
"..1.2....\n"
"..1.....2\n"
".32.3....\n"
".2...1...\n"
"2.....3.2\n"
"......3.2\n"
"3..13....\n"
"2....2121\n"
"..3..1..1\n"
"331.13..3\n"
"..3...3.2\n"
"1........\n") == 0);
free(board332640895);
board332640895 = NULL;
assert( gamma_free_fields(board, 1) == 117 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 4, 17) == 0 );


char* board189419444 = gamma_board(board);
assert( board189419444 != NULL );
assert( strcmp(board189419444, 
".2..2...2\n"
"....2....\n"
".........\n"
".........\n"
".1....13.\n"
"1......32\n"
"..1.2....\n"
"..1.....2\n"
".32.3....\n"
".2...1...\n"
"2.....322\n"
"......3.2\n"
"3..13....\n"
"2..2.2121\n"
"..3..1..1\n"
"331.13..3\n"
"..3...3.2\n"
"1........\n") == 0);
free(board189419444);
board189419444 = NULL;
assert( gamma_move(board, 1, 7, 15) == 1 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_move(board, 3, 17, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 2, 0, 0) == 0 );


char* board777473808 = gamma_board(board);
assert( board777473808 != NULL );
assert( strcmp(board777473808, 
".2..2...2\n"
"....2....\n"
".......1.\n"
".........\n"
".1....13.\n"
"1......32\n"
"..1.2....\n"
"..12....2\n"
".32.3....\n"
"22...1...\n"
"2.....322\n"
"......3.2\n"
"3..13....\n"
"2..2.2121\n"
"..3..1..1\n"
"331.13..3\n"
"..3...3.2\n"
"1........\n") == 0);
free(board777473808);
board777473808 = NULL;
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 5, 14) == 1 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 7, 16) == 1 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 1, 1, 11) == 1 );


char* board791607193 = gamma_board(board);
assert( board791607193 != NULL );
assert( strcmp(board791607193, 
".2..2...2\n"
"....2..2.\n"
".......1.\n"
".....1...\n"
".1....13.\n"
"1......32\n"
".1112....\n"
"..12....2\n"
".32.3....\n"
"22...1...\n"
"2.....322\n"
"......3.2\n"
"3..13....\n"
"2..2.2121\n"
"..3..1..1\n"
"331.13..3\n"
"..3.133.2\n"
"1........\n") == 0);
free(board791607193);
board791607193 = NULL;
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 1, 3, 6) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 1, 5, 16) == 1 );
assert( gamma_free_fields(board, 1) == 101 );
assert( gamma_move(board, 2, 6, 17) == 1 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_golden_move(board, 3, 17, 4) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board663351008 = gamma_board(board);
assert( board663351008 != NULL );
assert( strcmp(board663351008, 
".2..2.2.2\n"
"....21.2.\n"
".......1.\n"
".....1...\n"
".1....13.\n"
"13..2.332\n"
".1112....\n"
"..12....2\n"
".32.3....\n"
"22...1...\n"
"2.....322\n"
"...1..3.2\n"
"3..13...2\n"
"2..2.2121\n"
"..3.11..1\n"
"331.13..3\n"
"..3.133.2\n"
"1........\n") == 0);
free(board663351008);
board663351008 = NULL;
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 3, 4, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 1, 4, 16) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_move(board, 1, 5, 7) == 1 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 4, 8) == 1 );
assert( gamma_move(board, 2, 4, 7) == 1 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_free_fields(board, 3) == 88 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 3, 15) == 1 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 1, 4, 16) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 17, 2) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 5, 17) == 1 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 5, 17) == 0 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_free_fields(board, 1) == 83 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_free_fields(board, 2) == 83 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_move(board, 1, 7, 17) == 1 );
assert( gamma_golden_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 3, 17, 3) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 17, 3) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 27 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_golden_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 8, 17) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_free_fields(board, 1) == 71 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_move(board, 3, 16, 2) == 0 );
assert( gamma_free_fields(board, 3) == 71 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 8, 17) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 2, 2, 16) == 1 );
assert( gamma_free_fields(board, 2) == 70 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_golden_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_free_fields(board, 3) == 68 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_free_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 16, 8) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 2, 2, 17) == 1 );
assert( gamma_free_fields(board, 2) == 64 );
assert( gamma_move(board, 3, 8, 16) == 1 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 40 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_move(board, 2, 3, 16) == 1 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_golden_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 3, 3, 17) == 1 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );


char* board395842051 = gamma_board(board);
assert( board395842051 != NULL );
assert( strcmp(board395842051, 
".22322212\n"
"..2221.23\n"
".3.2...1.\n"
"...3.1.3.\n"
".1....13.\n"
"13.22.332\n"
"311121...\n"
"321232..2\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
"..11..332\n"
"3..132..2\n"
"21.2.2121\n"
"323311..1\n"
"331.13..3\n"
"..3.13332\n"
"2.1...13.\n") == 0);
free(board395842051);
board395842051 = NULL;
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 1, 7, 17) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 3, 4, 13) == 1 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 0, 17) == 1 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 4, 16) == 0 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 2, 16) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_free_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_golden_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board872417686 = gamma_board(board);
assert( board872417686 != NULL );
assert( strcmp(board872417686, 
"222322212\n"
"..2221.23\n"
".3.2...1.\n"
"...321.3.\n"
".1..3.13.\n"
"13.22.332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
"..11.2332\n"
"3..132..2\n"
"21.212121\n"
"323311..1\n"
"331.13..3\n"
"..3.13332\n"
"2.1...13.\n") == 0);
free(board872417686);
board872417686 = NULL;
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 8, 14) == 1 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );


char* board741069457 = gamma_board(board);
assert( board741069457 != NULL );
assert( strcmp(board741069457, 
"222322212\n"
"..2221.23\n"
".3.2...1.\n"
"...321.31\n"
".1..3.13.\n"
"13.22.332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
"..11.2332\n"
"3..132..2\n"
"21.212121\n"
"323311..1\n"
"331.13..3\n"
"..3.13332\n"
"211...132\n") == 0);
free(board741069457);
board741069457 = NULL;
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_golden_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 0, 16) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 15, 4) == 0 );


char* board885791839 = gamma_board(board);
assert( board885791839 != NULL );
assert( strcmp(board885791839, 
"222322212\n"
"2.2221.23\n"
".3.2...1.\n"
"...321.31\n"
".1..3.13.\n"
"13.22.332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
"..11.2332\n"
"3..132..2\n"
"21.212121\n"
"323311..1\n"
"331.13..3\n"
"..3.13332\n"
"211...132\n") == 0);
free(board885791839);
board885791839 = NULL;
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 5, 15) == 1 );
assert( gamma_busy_fields(board, 1) == 34 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 1, 1, 6) == 1 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 36 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );


char* board935813885 = gamma_board(board);
assert( board935813885 != NULL );
assert( strcmp(board935813885, 
"222322212\n"
"2.2221.23\n"
".3.2.1.1.\n"
"..3321.31\n"
".1..3.13.\n"
"13.22.332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..132..2\n"
"21.212121\n"
"323311..1\n"
"331.13..3\n"
"..3.13332\n"
"211...132\n") == 0);
free(board935813885);
board935813885 = NULL;
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );


char* board934916332 = gamma_board(board);
assert( board934916332 != NULL );
assert( strcmp(board934916332, 
"222322212\n"
"2.2221.23\n"
".3.2.1.1.\n"
"..3321.31\n"
".13.3.13.\n"
"13.22.332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..132..2\n"
"21.212121\n"
"323311..1\n"
"331.13..3\n"
"..3.13332\n"
"211...132\n") == 0);
free(board934916332);
board934916332 = NULL;
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 39 );


char* board281444220 = gamma_board(board);
assert( board281444220 != NULL );
assert( strcmp(board281444220, 
"222322212\n"
"2.2221.23\n"
".3.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.22.332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..132..2\n"
"21.212121\n"
"323311.31\n"
"331213..3\n"
"..3.13332\n"
"211...132\n") == 0);
free(board281444220);
board281444220 = NULL;
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_golden_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_golden_move(board, 2, 16, 8) == 0 );


char* board801475598 = gamma_board(board);
assert( board801475598 != NULL );
assert( strcmp(board801475598, 
"222322212\n"
"2.2221.23\n"
".3.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.22.332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..132..2\n"
"21.212121\n"
"323311.31\n"
"331213..3\n"
"..3.13332\n"
"211.2.132\n") == 0);
free(board801475598);
board801475598 = NULL;
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 5, 12) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 6, 16) == 1 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_golden_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 40 );
assert( gamma_golden_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_golden_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 3, 1, 16) == 1 );


char* board280648706 = gamma_board(board);
assert( board280648706 != NULL );
assert( strcmp(board280648706, 
"222322212\n"
"232221123\n"
"23.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.223332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..132..2\n"
"21.212121\n"
"323311.31\n"
"331213..3\n"
"..3.13332\n"
"211.2.132\n") == 0);
free(board280648706);
board280648706 = NULL;
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );


char* board888782954 = gamma_board(board);
assert( board888782954 != NULL );
assert( strcmp(board888782954, 
"222322212\n"
"232221123\n"
"23.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.223332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..132..2\n"
"21.212121\n"
"323311.31\n"
"331213..3\n"
"..3.13332\n"
"211.2.132\n") == 0);
free(board888782954);
board888782954 = NULL;
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_free_fields(board, 2) == 36 );
assert( gamma_move(board, 3, 0, 4) == 0 );


char* board653144775 = gamma_board(board);
assert( board653144775 != NULL );
assert( strcmp(board653144775, 
"222322212\n"
"232221123\n"
"23.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.223332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..132..2\n"
"21.212121\n"
"323311.31\n"
"331213..3\n"
"..3.13332\n"
"211.2.132\n") == 0);
free(board653144775);
board653144775 = NULL;
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_golden_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );


char* board775798098 = gamma_board(board);
assert( board775798098 != NULL );
assert( strcmp(board775798098, 
"222322212\n"
"232221123\n"
"23.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.223332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..132..2\n"
"21.212121\n"
"323311.31\n"
"331213..3\n"
"..3.13332\n"
"211.2.132\n") == 0);
free(board775798098);
board775798098 = NULL;
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_free_fields(board, 2) == 36 );
assert( gamma_golden_move(board, 2, 16, 6) == 0 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 1, 0, 17) == 0 );
assert( gamma_move(board, 1, 2, 4) == 1 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 41 );


char* board689984178 = gamma_board(board);
assert( board689984178 != NULL );
assert( strcmp(board689984178, 
"222322212\n"
"232221123\n"
"23.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.223332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..1321.2\n"
"211212121\n"
"323311.31\n"
"331213..3\n"
"..3.13332\n"
"211.2.132\n") == 0);
free(board689984178);
board689984178 = NULL;
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 6, 2) == 1 );


char* board325645219 = gamma_board(board);
assert( board325645219 != NULL );
assert( strcmp(board325645219, 
"222322212\n"
"232221123\n"
"23.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.223332\n"
"311121...\n"
"321232.32\n"
"33213....\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..1321.2\n"
"211212121\n"
"323311.31\n"
"3312133.3\n"
"..3.13332\n"
"211.2.132\n") == 0);
free(board325645219);
board325645219 = NULL;
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 42 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_golden_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 49 );
assert( gamma_move(board, 3, 8, 16) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_free_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_golden_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_free_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );


char* board609125837 = gamma_board(board);
assert( board609125837 != NULL );
assert( strcmp(board609125837, 
"222322212\n"
"232221123\n"
"23.2.1.1.\n"
"..3321331\n"
".13.3.13.\n"
"13.223332\n"
"311121...\n"
"321232.32\n"
"332131...\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..1321.2\n"
"211212121\n"
"323311.31\n"
"3312133.3\n"
".13.13332\n"
"211.2.132\n") == 0);
free(board609125837);
board609125837 = NULL;
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 8, 17) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 1, 5, 13) == 1 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );


char* board587623132 = gamma_board(board);
assert( board587623132 != NULL );
assert( strcmp(board587623132, 
"222322212\n"
"232221123\n"
"23.2.1.1.\n"
"..3321331\n"
".13.3113.\n"
"13.223332\n"
"311121...\n"
"321232.32\n"
"332131...\n"
"22.2112.2\n"
"222321322\n"
".111.2332\n"
"3..1321.2\n"
"211212121\n"
"323311.31\n"
"3312133.3\n"
".13.13332\n"
"211.2.132\n") == 0);
free(board587623132);
board587623132 = NULL;
assert( gamma_move(board, 1, 6, 15) == 1 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 42 );
assert( gamma_move(board, 2, 15, 8) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 3, 3) == 0 );


gamma_delete(board);

    return 0;
}
