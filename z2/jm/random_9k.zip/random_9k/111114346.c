#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 111114346
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(16, 18, 9, 26);
assert( board != NULL );


assert( gamma_move(board, 1, 16, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 13) == 1 );
assert( gamma_move(board, 3, 14, 13) == 1 );
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_move(board, 5, 13, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 1 );
assert( gamma_move(board, 7, 2, 13) == 1 );
assert( gamma_move(board, 7, 3, 2) == 1 );
assert( gamma_move(board, 8, 13, 11) == 1 );
assert( gamma_move(board, 9, 10, 4) == 1 );
assert( gamma_move(board, 1, 10, 2) == 1 );
assert( gamma_move(board, 1, 4, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 4, 15, 11) == 1 );


char* board278105187 = gamma_board(board);
assert( board278105187 != NULL );
assert( strcmp(board278105187, 
"................\n"
"................\n"
"................\n"
"....1...........\n"
"..7..........23.\n"
".3..............\n"
".............8.4\n"
"................\n"
"................\n"
"................\n"
"................\n"
"................\n"
".....3..........\n"
"..........9.....\n"
"................\n"
"...7......1.....\n"
"..........4.....\n"
".............5..\n") == 0);
free(board278105187);
board278105187 = NULL;
assert( gamma_move(board, 5, 9, 0) == 1 );
assert( gamma_move(board, 5, 9, 9) == 1 );
assert( gamma_move(board, 6, 7, 13) == 1 );
assert( gamma_move(board, 6, 8, 15) == 1 );
assert( gamma_move(board, 7, 1, 9) == 1 );
assert( gamma_move(board, 7, 5, 10) == 1 );
assert( gamma_free_fields(board, 7) == 269 );
assert( gamma_move(board, 8, 13, 11) == 0 );
assert( gamma_busy_fields(board, 8) == 1 );
assert( gamma_move(board, 9, 13, 6) == 1 );
assert( gamma_move(board, 1, 2, 4) == 1 );
assert( gamma_move(board, 1, 7, 17) == 1 );


char* board667655486 = gamma_board(board);
assert( board667655486 != NULL );
assert( strcmp(board667655486, 
".......1........\n"
"................\n"
"........6.......\n"
"....1...........\n"
"..7....6.....23.\n"
".3..............\n"
".............8.4\n"
".....7..........\n"
".7.......5......\n"
"................\n"
"................\n"
".............9..\n"
".....3..........\n"
"..1.......9.....\n"
"................\n"
"...7......1.....\n"
"..........4.....\n"
".........5...5..\n") == 0);
free(board667655486);
board667655486 = NULL;
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_move(board, 4, 15, 10) == 1 );
assert( gamma_move(board, 5, 7, 12) == 1 );
assert( gamma_move(board, 5, 2, 2) == 1 );
assert( gamma_move(board, 6, 14, 12) == 1 );
assert( gamma_move(board, 6, 15, 8) == 1 );
assert( gamma_move(board, 7, 1, 0) == 1 );
assert( gamma_move(board, 8, 2, 13) == 0 );
assert( gamma_move(board, 9, 14, 10) == 1 );
assert( gamma_busy_fields(board, 9) == 3 );
assert( gamma_move(board, 1, 11, 6) == 1 );


char* board679868643 = gamma_board(board);
assert( board679868643 != NULL );
assert( strcmp(board679868643, 
".......1........\n"
"................\n"
"........6.......\n"
"....1...........\n"
"..7....6.....23.\n"
".3.....5......6.\n"
".............8.4\n"
".....7........94\n"
".7.......5......\n"
"........2......6\n"
"................\n"
"...........1.9..\n"
".....3..........\n"
"..1.......9.....\n"
"................\n"
"..57......1.....\n"
"..........4.....\n"
".7.......5...5..\n") == 0);
free(board679868643);
board679868643 = NULL;
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_free_fields(board, 2) == 257 );
assert( gamma_move(board, 3, 5, 15) == 1 );
assert( gamma_golden_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 4, 17, 8) == 0 );
assert( gamma_move(board, 4, 4, 12) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 5, 3, 8) == 1 );
assert( gamma_move(board, 5, 4, 9) == 1 );
assert( gamma_move(board, 6, 14, 4) == 1 );
assert( gamma_move(board, 6, 4, 0) == 1 );
assert( gamma_move(board, 7, 13, 4) == 1 );
assert( gamma_move(board, 7, 6, 17) == 1 );
assert( gamma_move(board, 8, 16, 15) == 0 );
assert( gamma_move(board, 9, 15, 1) == 1 );
assert( gamma_move(board, 9, 6, 2) == 1 );
assert( gamma_free_fields(board, 9) == 247 );
assert( gamma_move(board, 1, 9, 15) == 1 );
assert( gamma_move(board, 2, 6, 15) == 1 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 5, 7, 1) == 1 );
assert( gamma_move(board, 6, 11, 7) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 5, 10) == 0 );
assert( gamma_move(board, 8, 4, 5) == 1 );
assert( gamma_busy_fields(board, 8) == 2 );
assert( gamma_move(board, 9, 4, 6) == 1 );
assert( gamma_golden_move(board, 9, 15, 6) == 0 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 2, 5, 13) == 1 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 4, 11, 1) == 1 );


char* board399489398 = gamma_board(board);
assert( board399489398 != NULL );
assert( strcmp(board399489398, 
"......71........\n"
"................\n"
".....32.61......\n"
"....1...........\n"
"..7..2.6.....23.\n"
".3..4..5......6.\n"
"3............8.4\n"
".....7........94\n"
".7..5....5......\n"
"...5....3......6\n"
"...........6....\n"
"....9......1.9..\n"
"....83.3........\n"
"..1.......9..76.\n"
"...2...1....3...\n"
"..57..9...1.....\n"
".......5.344...9\n"
".7..6....5...5..\n") == 0);
free(board399489398);
board399489398 = NULL;
assert( gamma_move(board, 5, 12, 5) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 14) == 0 );


char* board480021752 = gamma_board(board);
assert( board480021752 != NULL );
assert( strcmp(board480021752, 
"......71........\n"
"................\n"
".....32.61......\n"
"....1...........\n"
"..7..2.6.....23.\n"
".3..4..5......6.\n"
"3............8.4\n"
".....7........94\n"
".7..5....5......\n"
"...5....3......6\n"
"...........6....\n"
"....9......1.9..\n"
"....83.3....5...\n"
"..1.......9..76.\n"
"...2...1....3...\n"
"..57..9...1.....\n"
".......5.344...9\n"
".7..6....5...5..\n") == 0);
free(board480021752);
board480021752 = NULL;
assert( gamma_move(board, 7, 8, 9) == 1 );
assert( gamma_move(board, 7, 0, 9) == 1 );
assert( gamma_move(board, 8, 3, 4) == 1 );
assert( gamma_move(board, 9, 2, 17) == 1 );
assert( gamma_move(board, 9, 5, 6) == 1 );
assert( gamma_move(board, 1, 17, 14) == 0 );
assert( gamma_move(board, 1, 3, 12) == 1 );
assert( gamma_golden_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 2, 9, 7) == 1 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 3, 14, 0) == 1 );
assert( gamma_move(board, 3, 15, 0) == 1 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 5, 12, 15) == 1 );
assert( gamma_move(board, 5, 11, 4) == 1 );
assert( gamma_move(board, 6, 9, 14) == 1 );
assert( gamma_move(board, 7, 4, 9) == 0 );
assert( gamma_move(board, 7, 5, 2) == 1 );
assert( gamma_free_fields(board, 7) == 218 );
assert( gamma_move(board, 8, 5, 17) == 1 );
assert( gamma_move(board, 8, 5, 1) == 1 );
assert( gamma_move(board, 9, 10, 4) == 0 );


char* board533157966 = gamma_board(board);
assert( board533157966 != NULL );
assert( strcmp(board533157966, 
"..9..871........\n"
"................\n"
".....32.61..5...\n"
"....1....6......\n"
"..7..2.6.....23.\n"
".3.14..5......6.\n"
"3.......2....8.4\n"
".....7........94\n"
"77..5...75......\n"
"...5....3......6\n"
".........2.6....\n"
"....99.....1.9..\n"
"....83.3....5...\n"
"..18......95.76.\n"
"...2...1....3...\n"
"..57.79...1.....\n"
".....8.5.344...9\n"
".7..6....5...533\n") == 0);
free(board533157966);
board533157966 = NULL;
assert( gamma_move(board, 1, 14, 9) == 1 );
assert( gamma_move(board, 1, 10, 17) == 1 );


char* board713780368 = gamma_board(board);
assert( board713780368 != NULL );
assert( strcmp(board713780368, 
"..9..871..1.....\n"
"................\n"
".....32.61..5...\n"
"....1....6......\n"
"..7..2.6.....23.\n"
".3.14..5......6.\n"
"3.......2....8.4\n"
".....7........94\n"
"77..5...75....1.\n"
"...5....3......6\n"
".........2.6....\n"
"....99.....1.9..\n"
"....83.3....5...\n"
"..18......95.76.\n"
"...2...1....3...\n"
"..57.79...1.....\n"
".....8.5.344...9\n"
".7..6....5...533\n") == 0);
free(board713780368);
board713780368 = NULL;
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 14, 15) == 1 );
assert( gamma_move(board, 3, 5, 16) == 1 );
assert( gamma_free_fields(board, 4) == 211 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 6, 10, 0) == 1 );
assert( gamma_move(board, 6, 14, 15) == 0 );
assert( gamma_free_fields(board, 6) == 209 );
assert( gamma_move(board, 7, 15, 11) == 0 );
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_move(board, 8, 3, 12) == 0 );
assert( gamma_move(board, 9, 1, 2) == 1 );
assert( gamma_move(board, 9, 13, 3) == 1 );
assert( gamma_move(board, 1, 7, 15) == 1 );
assert( gamma_move(board, 1, 14, 1) == 1 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 8, 6) == 1 );
assert( gamma_move(board, 3, 12, 4) == 1 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 5, 12, 6) == 1 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_free_fields(board, 5) == 200 );
assert( gamma_move(board, 6, 3, 11) == 1 );


char* board232851677 = gamma_board(board);
assert( board232851677 != NULL );
assert( strcmp(board232851677, 
"..9..871..1.....\n"
".....3..........\n"
".....32161..5.3.\n"
"....1....6......\n"
"..7..2.6.....23.\n"
".3.14..5......6.\n"
"3..6....2....8.4\n"
".....7........94\n"
"775.5.2.75....1.\n"
"...5....3......6\n"
".........246....\n"
"....99..3..159..\n"
"....83.3....5...\n"
"..18......95376.\n"
"...2...1....39..\n"
".957.79...1.....\n"
".....8.5.344..19\n"
"57..6....56..533\n") == 0);
free(board232851677);
board232851677 = NULL;
assert( gamma_move(board, 7, 5, 11) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 15, 10) == 0 );


char* board380551899 = gamma_board(board);
assert( board380551899 != NULL );
assert( strcmp(board380551899, 
"..9..871..1.....\n"
".....3..........\n"
".....32161..5.3.\n"
"....1....6......\n"
"..7..2.6.....23.\n"
".3.14..5......6.\n"
"3..6.7..2....8.4\n"
".....7........94\n"
"775.5.2.75....1.\n"
"...5....3......6\n"
".........246....\n"
"....99..3..159..\n"
"....83.3....5...\n"
"..18......95376.\n"
"...2...1....39..\n"
".957.79...1.....\n"
".....8.5.344..19\n"
"57..6....56..533\n") == 0);
free(board380551899);
board380551899 = NULL;
assert( gamma_move(board, 9, 11, 10) == 1 );
assert( gamma_move(board, 9, 7, 15) == 0 );
assert( gamma_move(board, 1, 5, 14) == 1 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 4, 15) == 1 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 4, 13, 13) == 0 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 6, 9, 15) == 0 );
assert( gamma_move(board, 7, 12, 6) == 0 );
assert( gamma_move(board, 7, 15, 4) == 1 );
assert( gamma_move(board, 8, 8, 5) == 1 );
assert( gamma_move(board, 8, 9, 8) == 1 );
assert( gamma_busy_fields(board, 8) == 7 );
assert( gamma_move(board, 9, 0, 2) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 2, 14, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 9 );
assert( gamma_golden_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 3, 11, 3) == 1 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_golden_move(board, 5, 1, 9) == 1 );
assert( gamma_move(board, 6, 1, 2) == 0 );
assert( gamma_move(board, 7, 2, 14) == 1 );
assert( gamma_move(board, 7, 0, 8) == 1 );
assert( gamma_move(board, 8, 3, 1) == 1 );
assert( gamma_move(board, 9, 16, 6) == 0 );
assert( gamma_move(board, 1, 2, 12) == 1 );
assert( gamma_move(board, 1, 3, 17) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 9, 11) == 1 );
assert( gamma_move(board, 4, 6, 12) == 1 );
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 7, 8, 7) == 1 );
assert( gamma_move(board, 7, 2, 10) == 1 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_move(board, 8, 4, 5) == 0 );
assert( gamma_move(board, 9, 0, 6) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 1, 8, 15) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_move(board, 3, 4, 16) == 1 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board729827712 = gamma_board(board);
assert( board729827712 != NULL );
assert( strcmp(board729827712, 
"..91.871..1.....\n"
"....33..........\n"
"2...332161..5.3.\n"
"..7.11...6......\n"
"..7..2.6.....23.\n"
".3114.45......6.\n"
"3..6.7..24...8.4\n"
"..7..7.....9..94\n"
"755.5.2.25....1.\n"
"7..5....38.....6\n"
"2.......7246..2.\n"
"9...99..3..159..\n"
"....83.38...5...\n"
"..18..2.3.953767\n"
"...2...1...339..\n"
"5957.79...14....\n"
"...8.8.5.344..19\n"
"57..6....56..533\n") == 0);
free(board729827712);
board729827712 = NULL;
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_move(board, 4, 8, 16) == 1 );
assert( gamma_move(board, 5, 11, 11) == 1 );
assert( gamma_move(board, 5, 2, 7) == 1 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 11, 13) == 1 );
assert( gamma_move(board, 6, 12, 4) == 0 );
assert( gamma_move(board, 7, 4, 6) == 0 );
assert( gamma_move(board, 8, 5, 13) == 0 );
assert( gamma_move(board, 8, 1, 5) == 1 );
assert( gamma_move(board, 9, 4, 1) == 1 );
assert( gamma_move(board, 1, 3, 0) == 1 );
assert( gamma_move(board, 2, 17, 8) == 0 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_free_fields(board, 2) == 164 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 6, 17, 14) == 0 );
assert( gamma_move(board, 7, 8, 10) == 1 );
assert( gamma_move(board, 7, 15, 2) == 1 );
assert( gamma_move(board, 8, 16, 2) == 0 );
assert( gamma_move(board, 8, 3, 13) == 1 );
assert( gamma_golden_move(board, 8, 4, 10) == 0 );
assert( gamma_move(board, 9, 7, 3) == 0 );
assert( gamma_move(board, 9, 13, 12) == 1 );
assert( gamma_free_fields(board, 9) == 159 );
assert( gamma_move(board, 1, 14, 17) == 1 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_free_fields(board, 3) == 157 );
assert( gamma_move(board, 4, 14, 15) == 0 );
assert( gamma_move(board, 5, 16, 6) == 0 );
assert( gamma_move(board, 5, 9, 6) == 1 );
assert( gamma_free_fields(board, 5) == 156 );
assert( gamma_move(board, 6, 15, 8) == 0 );
assert( gamma_move(board, 6, 3, 6) == 1 );
assert( gamma_free_fields(board, 6) == 155 );
assert( gamma_move(board, 7, 10, 10) == 1 );
assert( gamma_move(board, 7, 10, 16) == 1 );
assert( gamma_move(board, 9, 10, 3) == 1 );
assert( gamma_move(board, 9, 10, 14) == 1 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_move(board, 2, 13, 15) == 1 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 5, 12, 10) == 1 );
assert( gamma_move(board, 5, 2, 12) == 0 );
assert( gamma_move(board, 6, 5, 8) == 1 );
assert( gamma_move(board, 7, 0, 2) == 0 );
assert( gamma_move(board, 7, 6, 5) == 1 );


char* board382098131 = gamma_board(board);
assert( board382098131 != NULL );
assert( strcmp(board382098131, 
"..91.871..1...1.\n"
"....33..4.7.....\n"
"2...332161..523.\n"
"..7.113..69.....\n"
"..78.2.6..36.23.\n"
".3114.45.....96.\n"
"3..6.7..24.5.8.4\n"
"..7..7..7.795.94\n"
"75525.2.25..2.1.\n"
"7..5.6..38.....6\n"
"2.5.....7246..2.\n"
"9..699..35.159..\n"
".8..83738...5...\n"
".418..2.3.953767\n"
"...2...1..9339..\n"
"5957.79...14...7\n"
"...898.5.344..19\n"
"57.16....56..533\n") == 0);
free(board382098131);
board382098131 = NULL;
assert( gamma_move(board, 9, 6, 11) == 1 );
assert( gamma_move(board, 9, 4, 10) == 1 );
assert( gamma_free_fields(board, 9) == 144 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 2, 0) == 1 );


char* board457072916 = gamma_board(board);
assert( board457072916 != NULL );
assert( strcmp(board457072916, 
"..91.871..1...1.\n"
"....33..4.7.....\n"
"2...332161..523.\n"
"..7.113..69.....\n"
"..78.2.6..36.23.\n"
".3114.45.....96.\n"
"3..6.79.24.5.8.4\n"
"..7.97..7.795.94\n"
"75525.2.25..2.1.\n"
"7..5.6..38.....6\n"
"2.5.....7246..2.\n"
"9..699..35.159..\n"
".8..83738...5...\n"
".418..2.3.953767\n"
"...2...1..9339..\n"
"5957.79...14...7\n"
"...898.5.344..19\n"
"57216....56..533\n") == 0);
free(board457072916);
board457072916 = NULL;
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_move(board, 5, 4, 4) == 1 );
assert( gamma_move(board, 6, 16, 14) == 0 );
assert( gamma_move(board, 6, 3, 10) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 15) == 0 );
assert( gamma_move(board, 7, 6, 11) == 0 );
assert( gamma_move(board, 8, 10, 12) == 1 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_free_fields(board, 3) == 137 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_free_fields(board, 6) == 137 );
assert( gamma_move(board, 7, 13, 12) == 0 );
assert( gamma_move(board, 8, 7, 3) == 0 );
assert( gamma_move(board, 9, 10, 13) == 0 );
assert( gamma_move(board, 9, 14, 17) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 8, 12) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 5, 10, 13) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 0, 14) == 1 );
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_move(board, 7, 12, 5) == 0 );
assert( gamma_move(board, 7, 2, 14) == 0 );
assert( gamma_move(board, 8, 2, 5) == 1 );
assert( gamma_move(board, 9, 8, 10) == 0 );
assert( gamma_move(board, 9, 5, 3) == 1 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_golden_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 2, 16, 3) == 0 );
assert( gamma_free_fields(board, 2) == 130 );
assert( gamma_move(board, 3, 13, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 5, 10, 9) == 1 );
assert( gamma_move(board, 6, 10, 6) == 1 );
assert( gamma_move(board, 6, 15, 1) == 0 );
assert( gamma_move(board, 7, 13, 16) == 1 );
assert( gamma_move(board, 8, 14, 16) == 1 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_move(board, 9, 3, 2) == 0 );
assert( gamma_golden_move(board, 9, 13, 3) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_free_fields(board, 1) == 125 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 5, 10, 13) == 0 );
assert( gamma_move(board, 5, 10, 5) == 1 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_move(board, 6, 0, 15) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 7, 11, 9) == 1 );
assert( gamma_move(board, 8, 7, 10) == 1 );
assert( gamma_move(board, 9, 14, 1) == 0 );
assert( gamma_move(board, 9, 6, 3) == 1 );
assert( gamma_move(board, 1, 16, 12) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 6, 4, 12) == 0 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 7, 0, 5) == 1 );
assert( gamma_move(board, 8, 12, 8) == 1 );
assert( gamma_move(board, 8, 7, 14) == 1 );
assert( gamma_free_fields(board, 8) == 118 );
assert( gamma_move(board, 9, 7, 6) == 1 );
assert( gamma_busy_fields(board, 9) == 21 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_move(board, 5, 13, 1) == 1 );
assert( gamma_move(board, 8, 1, 0) == 0 );
assert( gamma_move(board, 8, 2, 14) == 0 );


char* board536044123 = gamma_board(board);
assert( board536044123 != NULL );
assert( strcmp(board536044123, 
"..91.871..1...1.\n"
"....33..4.7..78.\n"
"23..332161..523.\n"
"6.7.1138.69.....\n"
".178.2.6..36.23.\n"
".3114.452.83.96.\n"
"3..6.79.24.5.8.4\n"
"..7697287.795.94\n"
"75525.2.25572.1.\n"
"7.35.6..38..83.6\n"
"2.5.....7246..2.\n"
"9..699.9356159..\n"
"788183738.5.5...\n"
".4185.213.953767\n"
"...2.991..9339..\n"
"5957.79...14...7\n"
"...898.5.344.519\n"
"57216.4..56..533\n") == 0);
free(board536044123);
board536044123 = NULL;
assert( gamma_move(board, 1, 17, 9) == 0 );
assert( gamma_move(board, 1, 4, 17) == 1 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 3, 15) == 1 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 6, 0, 12) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 16, 15) == 0 );
assert( gamma_move(board, 7, 15, 7) == 1 );
assert( gamma_move(board, 8, 2, 9) == 0 );
assert( gamma_move(board, 9, 10, 1) == 0 );
assert( gamma_move(board, 9, 15, 16) == 1 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 2, 15, 6) == 1 );
assert( gamma_free_fields(board, 2) == 108 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_move(board, 4, 17, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 5, 9, 16) == 1 );
assert( gamma_move(board, 6, 11, 12) == 0 );
assert( gamma_move(board, 6, 9, 5) == 1 );
assert( gamma_free_fields(board, 6) == 105 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 8, 7, 12) == 0 );
assert( gamma_move(board, 9, 3, 14) == 1 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_free_fields(board, 1) == 104 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 5, 5, 11) == 0 );
assert( gamma_move(board, 6, 7, 12) == 0 );
assert( gamma_move(board, 6, 11, 16) == 1 );
assert( gamma_move(board, 8, 10, 9) == 0 );
assert( gamma_move(board, 8, 8, 11) == 0 );
assert( gamma_golden_move(board, 9, 0, 0) == 1 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 3, 14, 3) == 1 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 5, 12, 2) == 1 );
assert( gamma_move(board, 6, 15, 0) == 0 );
assert( gamma_move(board, 6, 2, 9) == 0 );
assert( gamma_move(board, 7, 9, 8) == 0 );
assert( gamma_move(board, 8, 9, 15) == 0 );
assert( gamma_move(board, 9, 3, 8) == 0 );
assert( gamma_move(board, 9, 4, 5) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 4, 14, 5) == 1 );
assert( gamma_free_fields(board, 4) == 99 );
assert( gamma_move(board, 5, 11, 14) == 1 );
assert( gamma_move(board, 5, 1, 17) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_move(board, 8, 2, 7) == 0 );
assert( gamma_move(board, 8, 14, 0) == 0 );


char* board255715427 = gamma_board(board);
assert( board255715427 != NULL );
assert( strcmp(board255715427, 
".5911871..1...1.\n"
"....33..4576.789\n"
"23.3332161..523.\n"
"6.791138.695....\n"
".178.2.6..36.23.\n"
"63114.452.83.96.\n"
"3..6.79.24.5.8.4\n"
"..7697287.795.94\n"
"75525.2.25572.1.\n"
"7.35.6..38..83.6\n"
"2.5.....7246..27\n"
"9..69929356159.2\n"
"78818373865.5.4.\n"
".4185.213.953767\n"
"...2.991..93393.\n"
"5957.79.3.145..7\n"
"...898.5.344.519\n"
"97216.4..56..533\n") == 0);
free(board255715427);
board255715427 = NULL;
assert( gamma_move(board, 9, 16, 6) == 0 );
assert( gamma_move(board, 9, 4, 4) == 0 );
assert( gamma_move(board, 2, 17, 0) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 4, 16, 6) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 5, 17, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 27 );
assert( gamma_move(board, 6, 11, 0) == 1 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_move(board, 7, 10, 5) == 0 );
assert( gamma_move(board, 8, 13, 6) == 0 );
assert( gamma_move(board, 8, 6, 17) == 0 );
assert( gamma_move(board, 9, 10, 14) == 0 );
assert( gamma_move(board, 9, 1, 1) == 1 );
assert( gamma_free_fields(board, 9) == 95 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_free_fields(board, 1) == 95 );
assert( gamma_move(board, 2, 14, 4) == 0 );


char* board853656786 = gamma_board(board);
assert( board853656786 != NULL );
assert( strcmp(board853656786, 
".5911871..1...1.\n"
"....33..4576.789\n"
"23.3332161..523.\n"
"6.791138.695....\n"
".178.2.6..36.23.\n"
"63114.452.83.96.\n"
"3..6.79.24.5.8.4\n"
"..7697287.795.94\n"
"75525.2.25572.1.\n"
"7.35.6..38..83.6\n"
"2.5.....7246..27\n"
"9..69929356159.2\n"
"78818373865.5.4.\n"
".4185.213.953767\n"
"...2.991..93393.\n"
"5957.79.3.145..7\n"
".9.898.5.344.519\n"
"97216.4..566.533\n") == 0);
free(board853656786);
board853656786 = NULL;
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 12) == 0 );
assert( gamma_move(board, 5, 13, 9) == 1 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 5, 14) == 0 );
assert( gamma_golden_move(board, 7, 2, 1) == 0 );


char* board463195043 = gamma_board(board);
assert( board463195043 != NULL );
assert( strcmp(board463195043, 
".5911871..1...1.\n"
"....33..4576.789\n"
"23.3332161..523.\n"
"6.791138.695....\n"
".178.2.6..36.23.\n"
"63114.452.83.96.\n"
"3..6.79.24.5.8.4\n"
"..7697287.795.94\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5.....7246..27\n"
"9..69929356159.2\n"
"78818373865.5.4.\n"
".4185.213.953767\n"
"...2.991..93393.\n"
"5957.79.3.145..7\n"
".9.898.5.344.519\n"
"97216.4..566.533\n") == 0);
free(board463195043);
board463195043 = NULL;
assert( gamma_move(board, 8, 11, 1) == 0 );


char* board632839518 = gamma_board(board);
assert( board632839518 != NULL );
assert( strcmp(board632839518, 
".5911871..1...1.\n"
"....33..4576.789\n"
"23.3332161..523.\n"
"6.791138.695....\n"
".178.2.6..36.23.\n"
"63114.452.83.96.\n"
"3..6.79.24.5.8.4\n"
"..7697287.795.94\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5.....7246..27\n"
"9..69929356159.2\n"
"78818373865.5.4.\n"
".4185.213.953767\n"
"...2.991..93393.\n"
"5957.79.3.145..7\n"
".9.898.5.344.519\n"
"97216.4..566.533\n") == 0);
free(board632839518);
board632839518 = NULL;
assert( gamma_move(board, 9, 16, 7) == 0 );
assert( gamma_move(board, 9, 13, 8) == 0 );
assert( gamma_move(board, 1, 10, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_free_fields(board, 2) == 93 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 17, 13) == 0 );
assert( gamma_move(board, 5, 15, 2) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 7, 3, 12) == 0 );
assert( gamma_golden_move(board, 7, 15, 5) == 0 );
assert( gamma_move(board, 8, 12, 15) == 0 );
assert( gamma_move(board, 9, 2, 14) == 0 );
assert( gamma_move(board, 1, 9, 15) == 0 );
assert( gamma_golden_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_move(board, 5, 4, 5) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 1, 14) == 1 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_move(board, 8, 4, 17) == 0 );
assert( gamma_move(board, 9, 10, 0) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );


char* board700934274 = gamma_board(board);
assert( board700934274 != NULL );
assert( strcmp(board700934274, 
".5911871..1...1.\n"
"....33..4576.789\n"
"23.33321611.523.\n"
"67791138.695....\n"
".178.2.6..36.23.\n"
"63114.452.83.96.\n"
"3..6.79.24.5.8.4\n"
"..7697287.795.94\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5.....7246..27\n"
"9..69929356159.2\n"
"78818373865.5.4.\n"
".4185.213.953767\n"
"...2.991..93393.\n"
"5957.79.3.145..7\n"
".9.898.5.344.519\n"
"97216.4..566.533\n") == 0);
free(board700934274);
board700934274 = NULL;
assert( gamma_move(board, 2, 17, 13) == 0 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 7, 15, 15) == 1 );
assert( gamma_move(board, 8, 13, 2) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 8, 13) == 1 );
assert( gamma_move(board, 9, 13, 4) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 10, 16) == 0 );
assert( gamma_move(board, 3, 17, 8) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_golden_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 5, 15, 14) == 1 );
assert( gamma_move(board, 6, 15, 15) == 0 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_move(board, 7, 10, 7) == 0 );
assert( gamma_move(board, 8, 3, 15) == 0 );
assert( gamma_move(board, 8, 13, 10) == 1 );
assert( gamma_move(board, 9, 3, 1) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 2, 3, 12) == 0 );


char* board969366164 = gamma_board(board);
assert( board969366164 != NULL );
assert( strcmp(board969366164, 
".5911871..1...1.\n"
"....33..4576.789\n"
"23.33321611.5237\n"
"67791138.695...5\n"
".178.2.69.36.23.\n"
"63114.452.83.96.\n"
"3..6.79.24.5.8.4\n"
"..7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5.....7246..27\n"
"9..69929356159.2\n"
"78818373865.5.4.\n"
".4185.213.953767\n"
"...2.991..93393.\n"
"5957.79.3.1458.7\n"
".9.898.5.344.519\n"
"97216.4..566.533\n") == 0);
free(board969366164);
board969366164 = NULL;
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 6, 2, 7) == 0 );
assert( gamma_golden_move(board, 6, 9, 10) == 0 );
assert( gamma_move(board, 7, 11, 6) == 0 );
assert( gamma_move(board, 7, 3, 12) == 0 );
assert( gamma_move(board, 8, 8, 8) == 0 );
assert( gamma_move(board, 9, 7, 4) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 12, 11) == 1 );
assert( gamma_free_fields(board, 1) == 85 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 17, 11) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 5, 15) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 8, 1) == 1 );
assert( gamma_busy_fields(board, 7) == 26 );
assert( gamma_move(board, 8, 14, 2) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 0, 11) == 0 );
assert( gamma_move(board, 9, 12, 16) == 1 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 1, 5, 17) == 0 );
assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_free_fields(board, 3) == 82 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 5, 8, 14) == 1 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_golden_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 6, 15, 2) == 0 );
assert( gamma_move(board, 6, 7, 6) == 0 );
assert( gamma_move(board, 7, 5, 8) == 0 );
assert( gamma_move(board, 8, 6, 16) == 1 );
assert( gamma_move(board, 9, 16, 0) == 0 );
assert( gamma_move(board, 9, 2, 11) == 1 );
assert( gamma_busy_fields(board, 9) == 28 );
assert( gamma_free_fields(board, 9) == 79 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_free_fields(board, 1) == 79 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 5, 4) == 1 );


char* board154663092 = gamma_board(board);
assert( board154663092 != NULL );
assert( strcmp(board154663092, 
".5911871..1...1.\n"
"....338.45769789\n"
"23.33321611.5237\n"
"677911385695...5\n"
".178.2.69.36.23.\n"
"63114.452.83.96.\n"
"3.96.79.24.518.4\n"
"..7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5.....7246.427\n"
"9..69929356159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"...2.991..93393.\n"
"5957.79.3.145887\n"
".9.898.57344.519\n"
"97216.4..566.533\n") == 0);
free(board154663092);
board154663092 = NULL;
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_move(board, 5, 7, 16) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 13, 15) == 0 );
assert( gamma_move(board, 6, 14, 4) == 0 );
assert( gamma_move(board, 7, 17, 15) == 0 );
assert( gamma_move(board, 7, 7, 7) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 15, 3) == 1 );
assert( gamma_move(board, 8, 12, 7) == 1 );
assert( gamma_move(board, 9, 1, 15) == 0 );
assert( gamma_move(board, 9, 6, 3) == 0 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 1 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_free_fields(board, 3) == 73 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 8, 3) == 1 );
assert( gamma_move(board, 4, 2, 15) == 1 );
assert( gamma_free_fields(board, 4) == 71 );
assert( gamma_move(board, 5, 12, 12) == 0 );
assert( gamma_move(board, 7, 15, 7) == 0 );
assert( gamma_move(board, 7, 1, 3) == 1 );
assert( gamma_move(board, 8, 12, 13) == 1 );
assert( gamma_move(board, 9, 5, 14) == 0 );
assert( gamma_move(board, 9, 11, 11) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 17, 8) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 5, 8, 17) == 0 );
assert( gamma_move(board, 6, 16, 0) == 0 );
assert( gamma_move(board, 7, 10, 9) == 0 );
assert( gamma_move(board, 8, 1, 6) == 1 );
assert( gamma_move(board, 9, 2, 14) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 2, 11, 15) == 1 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 3, 4, 15) == 0 );
assert( gamma_free_fields(board, 3) == 66 );
assert( gamma_move(board, 4, 15, 14) == 0 );
assert( gamma_move(board, 5, 14, 12) == 0 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 7, 13, 15) == 0 );
assert( gamma_move(board, 8, 9, 0) == 0 );
assert( gamma_move(board, 9, 12, 9) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );


char* board645408837 = gamma_board(board);
assert( board645408837 != NULL );
assert( strcmp(board645408837, 
".5911871..1...1.\n"
"....338.45769789\n"
"2343332161125237\n"
"677911385695...5\n"
".178.2.69.36823.\n"
"63114.452.83.96.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5....772468427\n"
"98369929356159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.3.145887\n"
".9.898.57344.519\n"
"97216.4..566.533\n") == 0);
free(board645408837);
board645408837 = NULL;
assert( gamma_move(board, 2, 12, 9) == 0 );


char* board996648523 = gamma_board(board);
assert( board996648523 != NULL );
assert( strcmp(board996648523, 
".5911871..1...1.\n"
"....338.45769789\n"
"2343332161125237\n"
"677911385695...5\n"
".178.2.69.36823.\n"
"63114.452.83.96.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5....772468427\n"
"98369929356159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.3.145887\n"
".9.898.57344.519\n"
"97216.4..566.533\n") == 0);
free(board996648523);
board996648523 = NULL;
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_golden_move(board, 4, 11, 0) == 1 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 5, 1, 16) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );


char* board835720424 = gamma_board(board);
assert( board835720424 != NULL );
assert( strcmp(board835720424, 
".5911871..1...1.\n"
".5..338.45769789\n"
"2343332161125237\n"
"677911385695...5\n"
".178.2.69.36823.\n"
"63114.452.83.96.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5....772468427\n"
"98369929356159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.3.145887\n"
".9.898.57344.519\n"
"97216.4..564.533\n") == 0);
free(board835720424);
board835720424 = NULL;
assert( gamma_move(board, 6, 8, 8) == 0 );
assert( gamma_move(board, 7, 14, 13) == 0 );
assert( gamma_busy_fields(board, 7) == 28 );
assert( gamma_move(board, 8, 1, 9) == 0 );
assert( gamma_move(board, 9, 12, 2) == 0 );
assert( gamma_move(board, 9, 11, 2) == 0 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_free_fields(board, 5) == 29 );
assert( gamma_move(board, 6, 13, 15) == 0 );
assert( gamma_move(board, 6, 14, 14) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 14, 7) == 0 );
assert( gamma_move(board, 7, 0, 3) == 0 );
assert( gamma_golden_move(board, 7, 8, 6) == 1 );
assert( gamma_move(board, 8, 3, 9) == 0 );
assert( gamma_busy_fields(board, 8) == 24 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 16, 3) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_free_fields(board, 3) == 63 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_golden_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 7, 11, 1) == 0 );
assert( gamma_free_fields(board, 7) == 63 );
assert( gamma_move(board, 8, 17, 15) == 0 );
assert( gamma_move(board, 8, 10, 9) == 0 );
assert( gamma_move(board, 9, 11, 7) == 0 );
assert( gamma_move(board, 9, 14, 4) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 17, 0) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 6, 17, 15) == 0 );
assert( gamma_move(board, 7, 13, 6) == 0 );
assert( gamma_busy_fields(board, 7) == 29 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 13, 15) == 0 );
assert( gamma_move(board, 9, 3, 13) == 0 );


char* board121422031 = gamma_board(board);
assert( board121422031 != NULL );
assert( strcmp(board121422031, 
".5911871..1...1.\n"
".5..338.45769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452.83196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5....772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.3.145887\n"
".9.898.57344.519\n"
"97216.4.3564.533\n") == 0);
free(board121422031);
board121422031 = NULL;
assert( gamma_move(board, 1, 17, 13) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 3, 4, 17) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 5, 13, 15) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 6, 11, 14) == 0 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 7, 6, 4) == 0 );
assert( gamma_move(board, 8, 17, 12) == 0 );
assert( gamma_move(board, 8, 12, 6) == 0 );
assert( gamma_free_fields(board, 8) == 62 );
assert( gamma_move(board, 9, 9, 5) == 0 );
assert( gamma_move(board, 9, 10, 4) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 2, 13, 15) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board438431037 = gamma_board(board);
assert( board438431037 != NULL );
assert( strcmp(board438431037, 
".5911871..1...1.\n"
".5..338.45769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452.83196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5....772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.3.145887\n"
".9.898.57344.519\n"
"97216.4.3564.533\n") == 0);
free(board438431037);
board438431037 = NULL;
assert( gamma_move(board, 4, 2, 1) == 1 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 5, 6, 7) == 0 );


char* board357872548 = gamma_board(board);
assert( board357872548 != NULL );
assert( strcmp(board357872548, 
".5911871..1...1.\n"
".5..338.45769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452.83196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..83.6\n"
"2.5....772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.3.145887\n"
".94898.57344.519\n"
"97216.4.3564.533\n") == 0);
free(board357872548);
board357872548 = NULL;
assert( gamma_move(board, 6, 8, 11) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_move(board, 8, 2, 7) == 0 );
assert( gamma_move(board, 9, 8, 10) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_move(board, 2, 14, 8) == 1 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 4, 16, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 5, 13) == 0 );
assert( gamma_move(board, 7, 10, 15) == 0 );
assert( gamma_move(board, 8, 2, 4) == 0 );
assert( gamma_free_fields(board, 8) == 60 );
assert( gamma_move(board, 9, 9, 15) == 0 );
assert( gamma_move(board, 9, 13, 8) == 0 );
assert( gamma_free_fields(board, 9) == 60 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_move(board, 3, 17, 12) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 10, 10) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 5, 11, 14) == 0 );
assert( gamma_move(board, 5, 3, 17) == 0 );
assert( gamma_move(board, 6, 2, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );


char* board891326290 = gamma_board(board);
assert( board891326290 != NULL );
assert( strcmp(board891326290, 
".5911871..1...1.\n"
".5..338.45769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452.83196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..8326\n"
"2.5....772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.3.145887\n"
".94898.57344.519\n"
"97216.4.3564.533\n") == 0);
free(board891326290);
board891326290 = NULL;
assert( gamma_move(board, 7, 14, 12) == 0 );
assert( gamma_golden_move(board, 7, 8, 14) == 0 );
assert( gamma_move(board, 8, 16, 2) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 8, 1) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 9, 15) == 0 );
assert( gamma_move(board, 2, 9, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_free_fields(board, 9) == 59 );
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_free_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 13, 10) == 0 );


char* board507671140 = gamma_board(board);
assert( board507671140 != NULL );
assert( strcmp(board507671140, 
".5911871..1...1.\n"
".5..338.45769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.6..38..8326\n"
"2.5....772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.3.145887\n"
".94898.57344.519\n"
"97216.4.3564.533\n") == 0);
free(board507671140);
board507671140 = NULL;
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 16, 3) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 5, 9, 17) == 1 );
assert( gamma_move(board, 6, 9, 2) == 1 );
assert( gamma_move(board, 9, 6, 15) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_golden_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_move(board, 4, 6, 8) == 1 );
assert( gamma_free_fields(board, 4) == 55 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_move(board, 6, 13, 16) == 0 );
assert( gamma_move(board, 7, 14, 14) == 0 );
assert( gamma_move(board, 7, 7, 14) == 0 );
assert( gamma_busy_fields(board, 7) == 29 );
assert( gamma_move(board, 8, 0, 14) == 0 );
assert( gamma_move(board, 8, 10, 7) == 0 );


char* board566590353 = gamma_board(board);
assert( board566590353 != NULL );
assert( strcmp(board566590353, 
".5911871.51...1.\n"
".5..338.45769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.64.38..8326\n"
"235....772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"97216.4.3564.533\n") == 0);
free(board566590353);
board566590353 = NULL;
assert( gamma_move(board, 9, 10, 9) == 0 );
assert( gamma_golden_possible(board, 9) == 0 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 2, 5, 0) == 1 );


char* board340849837 = gamma_board(board);
assert( board340849837 != NULL );
assert( strcmp(board340849837, 
".5911871.51...1.\n"
".5..338.45769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.2557251.\n"
"7.35.64.38..8326\n"
"235....772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"9721624.3564.533\n") == 0);
free(board340849837);
board340849837 = NULL;
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 17, 0) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 32 );
assert( gamma_move(board, 6, 8, 11) == 0 );
assert( gamma_golden_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 7, 8, 4) == 0 );
assert( gamma_move(board, 8, 16, 2) == 0 );
assert( gamma_move(board, 8, 15, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 24 );
assert( gamma_move(board, 9, 1, 0) == 0 );
assert( gamma_free_fields(board, 9) == 53 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_free_fields(board, 1) == 53 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 15, 9) == 1 );
assert( gamma_golden_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 5, 0, 12) == 0 );
assert( gamma_move(board, 6, 8, 10) == 0 );
assert( gamma_move(board, 7, 6, 0) == 0 );
assert( gamma_move(board, 7, 3, 2) == 0 );
assert( gamma_move(board, 8, 10, 12) == 0 );
assert( gamma_move(board, 9, 1, 6) == 0 );
assert( gamma_move(board, 1, 7, 16) == 1 );
assert( gamma_golden_move(board, 1, 6, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 3, 13, 13) == 0 );
assert( gamma_free_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 5, 9, 16) == 0 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_move(board, 6, 1, 16) == 0 );
assert( gamma_move(board, 7, 10, 9) == 0 );
assert( gamma_move(board, 7, 8, 6) == 0 );
assert( gamma_golden_move(board, 7, 2, 2) == 0 );
assert( gamma_move(board, 9, 11, 10) == 0 );
assert( gamma_busy_fields(board, 9) == 28 );
assert( gamma_move(board, 2, 8, 16) == 0 );


char* board209507743 = gamma_board(board);
assert( board209507743 != NULL );
assert( strcmp(board209507743, 
".5911871.51...1.\n"
".5..338145769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.25572513\n"
"7.35.64.38..8326\n"
"235..3.772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"9721624.3564.533\n") == 0);
free(board209507743);
board209507743 = NULL;
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_golden_move(board, 5, 11, 15) == 0 );
assert( gamma_move(board, 8, 5, 0) == 0 );
assert( gamma_move(board, 8, 11, 4) == 0 );
assert( gamma_move(board, 9, 7, 6) == 0 );
assert( gamma_busy_fields(board, 9) == 28 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board424419171 = gamma_board(board);
assert( board424419171 != NULL );
assert( strcmp(board424419171, 
".5911871.51...1.\n"
".5..338145769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3.96.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.25572513\n"
"7335.64.38..8326\n"
"235..3.772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.9914.933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"9721624.3564.533\n") == 0);
free(board424419171);
board424419171 = NULL;
assert( gamma_move(board, 5, 16, 2) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 6, 7, 15) == 0 );
assert( gamma_move(board, 6, 9, 14) == 0 );
assert( gamma_free_fields(board, 6) == 50 );
assert( gamma_move(board, 7, 15, 14) == 0 );
assert( gamma_busy_fields(board, 7) == 29 );
assert( gamma_move(board, 8, 16, 0) == 0 );
assert( gamma_free_fields(board, 8) == 50 );
assert( gamma_move(board, 9, 0, 12) == 0 );
assert( gamma_move(board, 9, 1, 11) == 1 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_free_fields(board, 3) == 48 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 4, 8, 16) == 0 );


char* board953363170 = gamma_board(board);
assert( board953363170 != NULL );
assert( strcmp(board953363170, 
".5911871.51...1.\n"
".5..338145769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3996.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.25572513\n"
"7335.64.38..8326\n"
"235..3.772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.99141933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"9721624.3564.533\n") == 0);
free(board953363170);
board953363170 = NULL;
assert( gamma_move(board, 5, 17, 15) == 0 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );


char* board531355718 = gamma_board(board);
assert( board531355718 != NULL );
assert( strcmp(board531355718, 
".5911871.51...1.\n"
".5..338145769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3996.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.25572513\n"
"7335.64.38..8326\n"
"235..3.772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.99141933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"9721624.3564.533\n") == 0);
free(board531355718);
board531355718 = NULL;
assert( gamma_move(board, 8, 2, 2) == 0 );
assert( gamma_move(board, 9, 17, 13) == 0 );
assert( gamma_move(board, 9, 1, 11) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 2, 6, 17) == 0 );


char* board510568020 = gamma_board(board);
assert( board510568020 != NULL );
assert( strcmp(board510568020, 
".5911871.51...1.\n"
".5..338145769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3996.79.24.518.4\n"
"3.7697287.795894\n"
"75525.2.25572513\n"
"7335.64.38..8326\n"
"235..3.772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.99141933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"9721624.3564.533\n") == 0);
free(board510568020);
board510568020 = NULL;
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 4, 10, 11) == 1 );
assert( gamma_move(board, 5, 6, 14) == 0 );
assert( gamma_move(board, 6, 10, 7) == 0 );


char* board397445706 = gamma_board(board);
assert( board397445706 != NULL );
assert( strcmp(board397445706, 
".5911871.51...1.\n"
".5..338145769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3996.79.244518.4\n"
"3.7697287.795894\n"
"75525.2.25572513\n"
"7335.64.38..8326\n"
"235..3.772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.99141933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"9721624.3564.533\n") == 0);
free(board397445706);
board397445706 = NULL;
assert( gamma_move(board, 7, 13, 9) == 0 );


char* board476990960 = gamma_board(board);
assert( board476990960 != NULL );
assert( strcmp(board476990960, 
".5911871.51...1.\n"
".5..338145769789\n"
"2343332161125237\n"
"677911385695..65\n"
".178.2.69.36823.\n"
"63114.452283196.\n"
"3996.79.244518.4\n"
"3.7697287.795894\n"
"75525.2.25572513\n"
"7335.64.38..8326\n"
"235..3.772468427\n"
"98369929756159.2\n"
"78818373865.5.4.\n"
".41852213.953767\n"
"27.2.99141933938\n"
"5957.79.36145887\n"
".94898.57344.519\n"
"9721624.3564.533\n") == 0);
free(board476990960);
board476990960 = NULL;
assert( gamma_move(board, 9, 0, 15) == 0 );
assert( gamma_move(board, 9, 9, 11) == 0 );
assert( gamma_move(board, 1, 17, 13) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 4, 15, 12) == 1 );
assert( gamma_free_fields(board, 4) == 46 );
assert( gamma_move(board, 5, 14, 12) == 0 );
assert( gamma_move(board, 5, 12, 14) == 1 );
assert( gamma_move(board, 6, 14, 16) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_busy_fields(board, 7) == 29 );
assert( gamma_move(board, 8, 17, 12) == 0 );
assert( gamma_move(board, 8, 5, 9) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 1, 0) == 0 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 7, 12) == 0 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 7, 2, 13) == 0 );
assert( gamma_free_fields(board, 7) == 43 );
assert( gamma_move(board, 8, 17, 12) == 0 );
assert( gamma_busy_fields(board, 8) == 25 );
assert( gamma_move(board, 9, 13, 0) == 0 );
assert( gamma_move(board, 9, 10, 4) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 2, 9, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 27 );
assert( gamma_free_fields(board, 2) == 42 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 4, 9, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 6, 14, 16) == 0 );
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_free_fields(board, 6) == 42 );
assert( gamma_move(board, 7, 3, 4) == 0 );
assert( gamma_move(board, 8, 10, 1) == 0 );
assert( gamma_move(board, 8, 13, 15) == 0 );
assert( gamma_move(board, 9, 8, 4) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 2, 15, 17) == 1 );
assert( gamma_busy_fields(board, 2) == 28 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 33 );
assert( gamma_move(board, 6, 17, 13) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 29 );
assert( gamma_move(board, 8, 8, 11) == 0 );
assert( gamma_move(board, 8, 0, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 25 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 12, 17) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 13, 4) == 0 );
assert( gamma_move(board, 6, 4, 12) == 0 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_move(board, 7, 8, 10) == 0 );
assert( gamma_move(board, 7, 9, 11) == 0 );
assert( gamma_move(board, 8, 10, 16) == 0 );
assert( gamma_move(board, 8, 13, 8) == 0 );
assert( gamma_move(board, 9, 6, 4) == 0 );
assert( gamma_move(board, 9, 1, 6) == 0 );


gamma_delete(board);

    return 0;
}
