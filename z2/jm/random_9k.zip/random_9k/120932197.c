#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 120932197
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 17, 4, 69);
assert( board != NULL );


assert( gamma_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 3, 10, 15) == 1 );
assert( gamma_move(board, 3, 15, 13) == 1 );
assert( gamma_free_fields(board, 3) == 283 );
assert( gamma_move(board, 4, 10, 5) == 1 );
assert( gamma_move(board, 4, 11, 13) == 1 );
assert( gamma_move(board, 1, 8, 12) == 1 );
assert( gamma_golden_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_golden_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_free_fields(board, 1) == 275 );
assert( gamma_move(board, 2, 15, 5) == 1 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 4, 12, 5) == 1 );
assert( gamma_move(board, 4, 5, 11) == 1 );


char* board160424371 = gamma_board(board);
assert( board160424371 != NULL );
assert( strcmp(board160424371, 
".................\n"
"..........3......\n"
".......3.........\n"
"...........4.1.3.\n"
"2.......1........\n"
"3....4...........\n"
"..1..............\n"
".................\n"
".................\n"
".................\n"
".3...............\n"
"..........4.4..2.\n"
".......2.........\n"
"....4............\n"
"...3.............\n"
".22.........2....\n"
".................\n") == 0);
free(board160424371);
board160424371 = NULL;
assert( gamma_move(board, 1, 9, 1) == 1 );
assert( gamma_move(board, 1, 12, 16) == 1 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 1) == 1 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 1, 2, 12) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_golden_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 4, 0) == 1 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 9, 15) == 1 );
assert( gamma_move(board, 2, 11, 10) == 1 );
assert( gamma_free_fields(board, 2) == 257 );
assert( gamma_move(board, 3, 16, 13) == 1 );
assert( gamma_move(board, 3, 5, 13) == 1 );
assert( gamma_move(board, 4, 16, 1) == 1 );
assert( gamma_move(board, 1, 16, 16) == 1 );
assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 2, 11, 16) == 1 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_move(board, 4, 8, 5) == 1 );
assert( gamma_golden_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 3, 9, 12) == 1 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_free_fields(board, 3) == 245 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 4, 13, 1) == 1 );
assert( gamma_move(board, 1, 14, 11) == 1 );
assert( gamma_move(board, 2, 10, 16) == 1 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_golden_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_move(board, 1, 15, 2) == 1 );
assert( gamma_move(board, 2, 3, 0) == 1 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 14, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 1, 13) == 0 );


char* board370340299 = gamma_board(board);
assert( board370340299 != NULL );
assert( strcmp(board370340299, 
"..........221...1\n"
".3.......23......\n"
".......3.........\n"
".....3..3.34.1.33\n"
"2.1.....13.......\n"
"3....4........1..\n"
"..1........2.....\n"
"2.....1..3.......\n"
".......1.........\n"
"4.........4......\n"
".32.1............\n"
"........4.4.4.12.\n"
"....32.2.........\n"
".2..4.......3....\n"
"...3...........1.\n"
".22....421..24..4\n"
"...24............\n") == 0);
free(board370340299);
board370340299 = NULL;
assert( gamma_move(board, 4, 16, 7) == 1 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_move(board, 1, 14, 4) == 1 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_move(board, 4, 13, 12) == 1 );


char* board880324522 = gamma_board(board);
assert( board880324522 != NULL );
assert( strcmp(board880324522, 
"..........221...1\n"
".3.......23......\n"
".......3.........\n"
".....3..3.34.1.33\n"
"2.1.....13...4...\n"
"3...14..2.....1..\n"
"..1........2.....\n"
"2.....1..3.......\n"
".......1.........\n"
"4.....3...4.....4\n"
".32.1............\n"
"........4.4.4.12.\n"
"....32.2......1..\n"
".2..4.......3....\n"
"...3...........1.\n"
".22....421..24..4\n"
"...24....2.......\n") == 0);
free(board880324522);
board880324522 = NULL;
assert( gamma_move(board, 2, 13, 4) == 1 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 15, 10) == 1 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 16, 10) == 1 );
assert( gamma_golden_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 1, 16, 13) == 0 );
assert( gamma_move(board, 2, 7, 15) == 1 );
assert( gamma_move(board, 3, 10, 12) == 1 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_move(board, 4, 14, 10) == 1 );
assert( gamma_move(board, 1, 10, 10) == 1 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_move(board, 4, 16, 9) == 1 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_move(board, 1, 9, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_free_fields(board, 2) == 212 );
assert( gamma_move(board, 3, 16, 7) == 0 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 1, 13, 2) == 1 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 2, 3, 11) == 1 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 1, 11, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_golden_move(board, 3, 9, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_free_fields(board, 2) == 206 );
assert( gamma_move(board, 3, 15, 8) == 1 );
assert( gamma_move(board, 4, 16, 14) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 1, 10, 9) == 1 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 2, 16, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_move(board, 3, 1, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 11, 11) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 3, 14, 6) == 1 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_free_fields(board, 1) == 196 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 16, 16) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 4, 4, 9) == 1 );
assert( gamma_free_fields(board, 4) == 195 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_free_fields(board, 1) == 194 );
assert( gamma_move(board, 2, 0, 10) == 1 );


char* board595248297 = gamma_board(board);
assert( board595248297 != NULL );
assert( strcmp(board595248297, 
"..........221...1\n"
".3.....2.23......\n"
"2......3........4\n"
"1..1.3..3.34.1.33\n"
"2.1.....133..4...\n"
"3..214..2..42.1..\n"
"2.1.......12..434\n"
"23..4.1.231.....4\n"
"......11.3.....3.\n"
"4.....3...41....4\n"
".32.1...4.....3..\n"
"........4.4.4.12.\n"
"..3.32.2.....21..\n"
".2.14...3...3....\n"
".2.3.........1.1.\n"
".22....421..24..4\n"
".3.241...2.......\n") == 0);
free(board595248297);
board595248297 = NULL;
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 4, 14, 16) == 1 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 15, 12) == 1 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 13, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_golden_move(board, 2, 8, 15) == 0 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_move(board, 1, 12, 0) == 1 );


char* board900899521 = gamma_board(board);
assert( board900899521 != NULL );
assert( strcmp(board900899521, 
"..........221.4.1\n"
".3.....2.23......\n"
"2.3....3........4\n"
"1..1.3..3.34.1.33\n"
"2.1.....133..4.2.\n"
"3..214..2..42.1..\n"
"2.1.......12..434\n"
"23..4.1.231.....4\n"
"..3...11.3.....3.\n"
"4.....3...41.3..4\n"
".32.1...4.....3..\n"
"..4...4.434.4.12.\n"
"..3.32.2.....21..\n"
".2.14...33..3....\n"
".2.3.........1.1.\n"
".22.1..421..24..4\n"
".3.241...2..1....\n") == 0);
free(board900899521);
board900899521 = NULL;
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 2, 14, 1) == 1 );
assert( gamma_move(board, 3, 8, 15) == 1 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_free_fields(board, 3) == 179 );
assert( gamma_move(board, 4, 14, 3) == 1 );
assert( gamma_move(board, 4, 14, 14) == 1 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 3, 15) == 1 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 7, 12) == 1 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_move(board, 4, 3, 8) == 1 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_move(board, 3, 5, 14) == 1 );
assert( gamma_move(board, 3, 13, 10) == 1 );
assert( gamma_move(board, 4, 16, 4) == 1 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 3, 14, 15) == 1 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_golden_move(board, 3, 1, 4) == 0 );


char* board352445376 = gamma_board(board);
assert( board352445376 != NULL );
assert( strcmp(board352445376, 
"..........221.4.1\n"
"23.4...2323...3..\n"
"2.3..333......4.4\n"
"1..1.3..3.34.1.33\n"
"2.1....1133..4.2.\n"
"3..2142.2..42.1..\n"
"2.1.......12.3434\n"
"23..4.1.231.2...4\n"
"..34..11.3.....3.\n"
"4.....3...41.3..4\n"
".32.1...4.....3..\n"
"..4...4.434.4.12.\n"
"..3.32322.3..21.4\n"
".2.14...33..3.4..\n"
".2.3.4......31.1.\n"
".22.12.421..242.4\n"
".3.2411..21.1....\n") == 0);
free(board352445376);
board352445376 = NULL;
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_move(board, 1, 5, 7) == 1 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_free_fields(board, 2) == 156 );
assert( gamma_move(board, 4, 3, 10) == 1 );
assert( gamma_move(board, 1, 15, 15) == 1 );
assert( gamma_move(board, 1, 13, 11) == 1 );
assert( gamma_move(board, 2, 0, 16) == 1 );
assert( gamma_move(board, 2, 7, 10) == 1 );


char* board237167258 = gamma_board(board);
assert( board237167258 != NULL );
assert( strcmp(board237167258, 
"2.........221.4.1\n"
"23.4...2323...31.\n"
"2.3..333......4.4\n"
"1.21.3..3.34.1.33\n"
"2.1....1133..4.2.\n"
"3.12142.2..4211..\n"
"2.14...2..12.3434\n"
"23..4.1.231.2...4\n"
"..34..11.3.....3.\n"
"4....13...41.3..4\n"
".32.1...4.....3..\n"
"..4...4.434.4.12.\n"
"..3.32322.3..21.4\n"
".2.14...33..3.4..\n"
".2.3.4......31.1.\n"
".22.12.421..242.4\n"
".3.2411..21.1....\n") == 0);
free(board237167258);
board237167258 = NULL;
assert( gamma_move(board, 3, 14, 15) == 0 );
assert( gamma_free_fields(board, 3) == 151 );
assert( gamma_move(board, 4, 15, 2) == 0 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 38 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 4, 2, 16) == 1 );
assert( gamma_move(board, 4, 14, 13) == 1 );
assert( gamma_move(board, 1, 15, 11) == 1 );
assert( gamma_free_fields(board, 1) == 144 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 15, 6) == 1 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_free_fields(board, 4) == 143 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 2, 12, 12) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 14) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_busy_fields(board, 2) == 42 );
assert( gamma_move(board, 3, 8, 10) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 15, 14) == 1 );
assert( gamma_move(board, 2, 9, 11) == 1 );
assert( gamma_move(board, 3, 15, 8) == 0 );
assert( gamma_move(board, 3, 12, 12) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 4, 16, 6) == 1 );
assert( gamma_move(board, 1, 4, 12) == 1 );
assert( gamma_move(board, 1, 16, 3) == 1 );
assert( gamma_move(board, 3, 14, 11) == 0 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 2, 2, 2) == 1 );


char* board478984513 = gamma_board(board);
assert( board478984513 != NULL );
assert( strcmp(board478984513, 
"2.4.......221.4.1\n"
"23.4...2323...31.\n"
"2.3..333.2....424\n"
"1321.3..3.34.1433\n"
"2.1.1.21133.24.2.\n"
"3.12142.22.42111.\n"
"2.14...23.12.3434\n"
"23..4.1.231.2...4\n"
"..34..11.3.....3.\n"
"4....13...41.3..4\n"
"132.1...4.....334\n"
".24..243434.4.12.\n"
"..3.32322.3..21.4\n"
".2.143..33..3.4.1\n"
".223.4......31.1.\n"
".22.12.421..242.4\n"
"23.2411.121.1....\n") == 0);
free(board478984513);
board478984513 = NULL;
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 3, 13, 6) == 1 );
assert( gamma_move(board, 4, 5, 10) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 4, 3, 14) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 11, 9) == 1 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 3, 2, 16) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 3, 5) == 1 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 2, 14, 4) == 0 );


char* board931231646 = gamma_board(board);
assert( board931231646 != NULL );
assert( strcmp(board931231646, 
"2.4.......221.4.1\n"
"23.4...2323...31.\n"
"2.34.333.2....424\n"
"1321.3..3.34.1433\n"
"2.1.1.21133.24.2.\n"
"3412142.22.42111.\n"
"2.14.4223.12.3434\n"
"231.4.1.23142...4\n"
"..34..11.3.....3.\n"
"4....13...41.3..4\n"
"132.1...4....3334\n"
".244.243434.4.12.\n"
"1.3.32322.3..21.4\n"
".2.143..33..3.4.1\n"
".22334......31.1.\n"
".22.12.421..242.4\n"
"23.2411.121.1....\n") == 0);
free(board931231646);
board931231646 = NULL;
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 5, 15) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 15, 11) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 10, 6) == 1 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_golden_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 4, 14, 16) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_free_fields(board, 3) == 116 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 4, 14, 15) == 0 );
assert( gamma_free_fields(board, 4) == 116 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_free_fields(board, 1) == 116 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 4, 13, 9) == 1 );
assert( gamma_move(board, 4, 12, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 45 );
assert( gamma_move(board, 4, 11, 16) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 1, 9, 2) == 1 );
assert( gamma_move(board, 1, 16, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 3, 13, 0) == 1 );
assert( gamma_move(board, 3, 15, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 16, 13) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_free_fields(board, 2) == 110 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 3, 8, 16) == 1 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 1, 9, 16) == 1 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_golden_move(board, 1, 6, 15) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 48 );
assert( gamma_move(board, 3, 0, 16) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );


char* board324682868 = gamma_board(board);
assert( board324682868 != NULL );
assert( strcmp(board324682868, 
"2.4.....31221.4.1\n"
"23.4.4.2323...31.\n"
"2.34.333.2....424\n"
"1321.3..3.34.1433\n"
"2.1.1.21133.24.2.\n"
"3412142.22.42111.\n"
"2.14.4223.12.3434\n"
"231.4.1.231424..4\n"
"..34..11.3.....3.\n"
"4...113...41.3..4\n"
"132.1...4.1..3334\n"
".244.243434.4.12.\n"
"1.3.32322.32421.4\n"
".2.143..33..3.4.1\n"
".22334.1.1.431.1.\n"
".22.12.4212.242.4\n"
"23.2411.121.13...\n") == 0);
free(board324682868);
board324682868 = NULL;
assert( gamma_move(board, 4, 16, 6) == 0 );
assert( gamma_move(board, 4, 7, 11) == 1 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 1, 12, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 46 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_free_fields(board, 4) == 103 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 13, 16) == 1 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 4, 12, 10) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 3, 8, 12) == 0 );
assert( gamma_move(board, 4, 16, 0) == 1 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_move(board, 1, 1, 16) == 1 );
assert( gamma_golden_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 46 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_golden_move(board, 2, 12, 8) == 0 );


char* board239368560 = gamma_board(board);
assert( board239368560 != NULL );
assert( strcmp(board239368560, 
"214.....3122124.1\n"
"23.4.4.2323...31.\n"
"2.34.333.2....424\n"
"1321.3..3.3411433\n"
"2.1.1.21133.24.2.\n"
"3412142422.42111.\n"
"2.14.4223.1243434\n"
"231.4.11231424..4\n"
".234..1123.....3.\n"
"4...113...41.3..4\n"
"132.1...4.1..3334\n"
".244.243434.4.12.\n"
"1.3.32322.32421.4\n"
".2.143..33..3.4.1\n"
".22334.1.1.431.1.\n"
".22.1224212.242.4\n"
"23.2411.121.13..4\n") == 0);
free(board239368560);
board239368560 = NULL;
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 4, 3, 7) == 1 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 4, 14) == 1 );
assert( gamma_move(board, 2, 1, 15) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 4, 13, 5) == 1 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 16) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 10, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 48 );
assert( gamma_move(board, 4, 0, 15) == 0 );


char* board750278374 = gamma_board(board);
assert( board750278374 != NULL );
assert( strcmp(board750278374, 
"214.....3122124.1\n"
"23.4.4.2323...31.\n"
"2.341333.2....424\n"
"1321.3..3.3411433\n"
"2.1.1.21133.24.2.\n"
"3412142422.42111.\n"
"2.14.4223.1243434\n"
"231.4.11231424..4\n"
".2343.1123.....3.\n"
"4..4113...41.3..4\n"
"132.1...4.1..3334\n"
".244.243434.4412.\n"
"1.3.32322.32421.4\n"
".2.143..33..3.4.1\n"
".22334.1.1.431.1.\n"
".22.1224212.242.4\n"
"23.2411.121.13..4\n") == 0);
free(board750278374);
board750278374 = NULL;
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_free_fields(board, 3) == 91 );
assert( gamma_move(board, 4, 5, 6) == 1 );
assert( gamma_golden_move(board, 4, 4, 13) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 2, 14, 13) == 0 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_move(board, 4, 13, 15) == 1 );
assert( gamma_move(board, 1, 8, 10) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 2, 16, 12) == 1 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 4, 15, 3) == 1 );
assert( gamma_golden_move(board, 4, 9, 1) == 1 );
assert( gamma_move(board, 1, 8, 16) == 0 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 2, 15, 16) == 1 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_move(board, 1, 2, 16) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 57 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 3, 5, 16) == 1 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_move(board, 2, 14, 8) == 1 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 1, 15, 4) == 1 );
assert( gamma_move(board, 1, 14, 15) == 0 );
assert( gamma_free_fields(board, 1) == 80 );
assert( gamma_move(board, 2, 11, 16) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_free_fields(board, 3) == 80 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 2, 8, 16) == 0 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 3, 16, 11) == 1 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 54 );
assert( gamma_move(board, 1, 14, 12) == 1 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 15, 7) == 1 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 3, 16, 14) == 0 );
assert( gamma_free_fields(board, 3) == 75 );
assert( gamma_move(board, 4, 6, 16) == 1 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_busy_fields(board, 4) == 57 );
assert( gamma_move(board, 1, 16, 13) == 0 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );


char* board100932716 = gamma_board(board);
assert( board100932716 != NULL );
assert( strcmp(board100932716, 
"214..34.312212421\n"
"23.4.4.2323..431.\n"
"22341333.2....424\n"
"1321.3..3.3411433\n"
"2.1.1.21133.24122\n"
"3412142422.421113\n"
"2.14.4223.1243434\n"
"231.4.11231424..4\n"
".2343.1123.2..23.\n"
"4144113...41.3.44\n"
"132.142.4.1..3334\n"
".2444243434.4412.\n"
"1.3.32322.3242114\n"
".2.1432.33..3.441\n"
"422334.1.1.431.1.\n"
".22.1224242.242.4\n"
"23.2411.121.13..4\n") == 0);
free(board100932716);
board100932716 = NULL;
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_free_fields(board, 3) == 71 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 2, 15, 16) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 13, 12) == 0 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 60 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 12) == 1 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 3, 8, 12) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 4, 13, 8) == 1 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_free_fields(board, 1) == 66 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 4, 15, 15) == 0 );
assert( gamma_free_fields(board, 4) == 66 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_free_fields(board, 1) == 65 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 1, 13, 12) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 2, 16) == 0 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 4, 10, 14) == 1 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 4, 15, 13) == 0 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 12, 6) == 1 );
assert( gamma_move(board, 1, 16, 2) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_free_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 0, 11) == 0 );


char* board318259420 = gamma_board(board);
assert( board318259420 != NULL );
assert( strcmp(board318259420, 
"214..34.312212421\n"
"23.4.4.2323..431.\n"
"22341333.24...424\n"
"1321.3.33.3411433\n"
"2.141.21133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"231.4.11231424..4\n"
".2343.1123.2.423.\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
".2444243434.4412.\n"
"1.3.32322.3242114\n"
".211432.33..3.441\n"
"422334.1.1.431.11\n"
".22.1224242.242.4\n"
"23124111121.13..4\n") == 0);
free(board318259420);
board318259420 = NULL;
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_move(board, 2, 6, 16) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 16, 14) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 60 );
assert( gamma_golden_move(board, 2, 5, 2) == 1 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_golden_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_busy_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 4, 16, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 60 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 13) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 5, 9) == 1 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_golden_move(board, 2, 16, 16) == 0 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 14, 2) == 1 );
assert( gamma_move(board, 2, 2, 15) == 1 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_move(board, 4, 15, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_free_fields(board, 2) == 58 );
assert( gamma_free_fields(board, 3) == 58 );
assert( gamma_move(board, 4, 4, 16) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_free_fields(board, 1) == 57 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 63 );


char* board325311368 = gamma_board(board);
assert( board325311368 != NULL );
assert( strcmp(board325311368, 
"214.434.312212421\n"
"2324.4.2323..431.\n"
"22341333.24...424\n"
"1321.3.33.3411433\n"
"2.141.21133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"231.4211231424..4\n"
".2343.1123.2.423.\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
".2444243434.4412.\n"
"1.3.32322.3242114\n"
".211432.33..3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.13..4\n") == 0);
free(board325311368);
board325311368 = NULL;
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 16, 15) == 1 );
assert( gamma_move(board, 2, 9, 13) == 1 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_golden_move(board, 2, 13, 16) == 0 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_move(board, 3, 9, 15) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 4, 10, 3) == 1 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_golden_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_free_fields(board, 3) == 54 );
assert( gamma_move(board, 4, 14, 0) == 1 );
assert( gamma_free_fields(board, 4) == 53 );


char* board976801425 = gamma_board(board);
assert( board976801425 != NULL );
assert( strcmp(board976801425, 
"214.434.312212421\n"
"2324.4.2323..4312\n"
"22341333.24...424\n"
"1321.3.3323411433\n"
"2.141.21133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"231.4211231424..4\n"
".2343.1123.2.423.\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
".2444243434.4412.\n"
"1.3.32322.3242114\n"
".211432.334.3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.134.4\n") == 0);
free(board976801425);
board976801425 = NULL;
assert( gamma_move(board, 1, 9, 15) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 12) == 0 );
assert( gamma_move(board, 3, 16, 14) == 0 );
assert( gamma_move(board, 4, 13, 16) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 4, 3, 16) == 1 );
assert( gamma_move(board, 1, 8, 10) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_move(board, 4, 5, 15) == 0 );
assert( gamma_free_fields(board, 4) == 52 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 3, 16, 16) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_golden_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_free_fields(board, 1) == 50 );
assert( gamma_golden_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_move(board, 3, 8, 12) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 4, 15, 4) == 0 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_free_fields(board, 1) == 50 );
assert( gamma_golden_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 2, 15, 12) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 3, 16, 8) == 1 );
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );


char* board559308625 = gamma_board(board);
assert( board559308625 != NULL );
assert( strcmp(board559308625, 
"2144434.312212421\n"
"2324.4.2323..4312\n"
"22341333.24...424\n"
"1321.3.3323411433\n"
"2.141.21133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"23124211231424..4\n"
".2343.1123.2.4233\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
"12444243434.4412.\n"
"1.3.32322.3242114\n"
".211432.334.3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.134.4\n") == 0);
free(board559308625);
board559308625 = NULL;
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_golden_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 3, 8, 12) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_free_fields(board, 4) == 49 );


char* board799588390 = gamma_board(board);
assert( board799588390 != NULL );
assert( strcmp(board799588390, 
"2144434.312212421\n"
"2324.4.2323..4312\n"
"22341333.24...424\n"
"1321.3.3323411433\n"
"2.141.21133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"23124211231424..4\n"
".2343.1123.2.4233\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
"12444243434.4412.\n"
"1.3.32322.3242114\n"
".211432.334.3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.134.4\n") == 0);
free(board799588390);
board799588390 = NULL;
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_free_fields(board, 4) == 49 );
assert( gamma_golden_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_free_fields(board, 3) == 48 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_golden_move(board, 3, 9, 12) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 9, 4) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 6, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 15, 11) == 0 );
assert( gamma_free_fields(board, 1) == 46 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 4, 16, 4) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 8, 14) == 1 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 4, 1, 12) == 1 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 4, 15, 12) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 16, 6) == 0 );
assert( gamma_free_fields(board, 4) == 44 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 68 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_free_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_free_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );


char* board557035684 = gamma_board(board);
assert( board557035684 != NULL );
assert( strcmp(board557035684, 
"2144434.312212421\n"
"2324.4.2323..4312\n"
"22341333224...424\n"
"1321.333323411433\n"
"24141221133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"23124211231424..4\n"
".2343.1123.2.4233\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
"12444243434.4412.\n"
"1.3.3232243242114\n"
".211432.334.3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.134.4\n") == 0);
free(board557035684);
board557035684 = NULL;
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 4, 14, 12) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );


char* board907705859 = gamma_board(board);
assert( board907705859 != NULL );
assert( strcmp(board907705859, 
"2144434.312212421\n"
"2324.4.2323..4312\n"
"22341333224...424\n"
"1321.333323411433\n"
"24141221133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"23124211231424..4\n"
".2343.1123.2.4233\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
"12444243434.4412.\n"
"1.3.3232243242114\n"
".211432.334.3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.134.4\n") == 0);
free(board907705859);
board907705859 = NULL;
assert( gamma_move(board, 1, 11, 14) == 1 );
assert( gamma_move(board, 1, 16, 7) == 0 );
assert( gamma_free_fields(board, 2) == 43 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_golden_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 15, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_golden_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_free_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 15, 15) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 3, 7, 16) == 1 );


char* board407441926 = gamma_board(board);
assert( board407441926 != NULL );
assert( strcmp(board407441926, 
"21444343312212421\n"
"2324.4.2323..4312\n"
"223413332241..424\n"
"1321.333323411433\n"
"24141221133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"23124211231424..4\n"
".2343.1123.2.4233\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
"1244424343444412.\n"
"1.3.3232243242114\n"
".211432.334.3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.134.4\n") == 0);
free(board407441926);
board407441926 = NULL;
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 16, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 67 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 12, 12) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 15, 12) == 0 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 54 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 12) == 0 );
assert( gamma_free_fields(board, 4) == 41 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 2, 15, 12) == 0 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 4, 16, 11) == 0 );
assert( gamma_move(board, 1, 1, 15) == 0 );
assert( gamma_move(board, 1, 14, 16) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 4, 14, 12) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 68 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 1, 16, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 68 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );


char* board326673759 = gamma_board(board);
assert( board326673759 != NULL );
assert( strcmp(board326673759, 
"21444343312212421\n"
"2324.4.2323..4312\n"
"223413332241..424\n"
"1321.333323411433\n"
"24141221133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"23124211231424..4\n"
"32343.1123.2.4233\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
"1244424343444412.\n"
"1.3.3232243242114\n"
".211432.334.3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.134.4\n") == 0);
free(board326673759);
board326673759 = NULL;
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_move(board, 1, 9, 15) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );


char* board215786150 = gamma_board(board);
assert( board215786150 != NULL );
assert( strcmp(board215786150, 
"21444343312212421\n"
"2324.4.2323..4312\n"
"223413332241..424\n"
"1321.333323411433\n"
"24141221133.24122\n"
"3412142422.421113\n"
"2214.4223.1243434\n"
"23124211231424..4\n"
"32343.1123.2.4233\n"
"41441131..41.3.44\n"
"132.142.4.1.43334\n"
"1244424343444412.\n"
"143.3232243242114\n"
".211432.334.3.441\n"
"422332.1.1.431111\n"
".22.1224242.242.4\n"
"23124111121.134.4\n") == 0);
free(board215786150);
board215786150 = NULL;
assert( gamma_move(board, 3, 16, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 55 );
assert( gamma_move(board, 4, 12, 11) == 0 );
assert( gamma_move(board, 4, 11, 1) == 1 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_golden_move(board, 2, 10, 10) == 0 );


gamma_delete(board);

    return 0;
}
