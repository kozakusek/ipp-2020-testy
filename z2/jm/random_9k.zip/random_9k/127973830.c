#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 127973830
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(15, 17, 3, 114);
assert( board != NULL );


assert( gamma_move(board, 1, 5, 13) == 1 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_free_fields(board, 2) == 253 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 2, 9, 13) == 1 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_golden_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_move(board, 3, 14, 15) == 1 );
assert( gamma_free_fields(board, 3) == 244 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 2, 1, 11) == 1 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_move(board, 3, 11, 11) == 1 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 1, 2, 12) == 1 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );


char* board987472118 = gamma_board(board);
assert( board987472118 != NULL );
assert( strcmp(board987472118, 
"...............\n"
"..............3\n"
"...............\n"
".....1...2.....\n"
"2.1............\n"
".2......2..3...\n"
"...............\n"
".3...3.........\n"
"......1........\n"
"3..............\n"
".....2.........\n"
"..........1....\n"
"...........2...\n"
"......2........\n"
"..1............\n"
".......2.......\n"
"...............\n") == 0);
free(board987472118);
board987472118 = NULL;
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 3, 9, 16) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 5, 10) == 1 );
assert( gamma_move(board, 2, 13, 4) == 1 );


char* board757458245 = gamma_board(board);
assert( board757458245 != NULL );
assert( strcmp(board757458245, 
".........3.....\n"
"..............3\n"
"...............\n"
".....1...2.....\n"
"2.1............\n"
".2......2..3...\n"
".....1.........\n"
".3...3.........\n"
"3.....1........\n"
"3..............\n"
".....2.........\n"
"..........1....\n"
"...........2.2.\n"
"......2........\n"
"..1............\n"
".......2.......\n"
"...............\n") == 0);
free(board757458245);
board757458245 = NULL;


char* board473051807 = gamma_board(board);
assert( board473051807 != NULL );
assert( strcmp(board473051807, 
".........3.....\n"
"..............3\n"
"...............\n"
".....1...2.....\n"
"2.1............\n"
".2......2..3...\n"
".....1.........\n"
".3...3.........\n"
"3.....1........\n"
"3..............\n"
".....2.........\n"
"..........1....\n"
"...........2.2.\n"
"......2........\n"
"..1............\n"
".......2.......\n"
"...............\n") == 0);
free(board473051807);
board473051807 = NULL;
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_move(board, 1, 8, 11) == 0 );


char* board750404916 = gamma_board(board);
assert( board750404916 != NULL );
assert( strcmp(board750404916, 
".........3.....\n"
"..............3\n"
"...............\n"
".....1...2.....\n"
"2.1............\n"
".2......2..3...\n"
".....1.........\n"
".3...3.........\n"
"3.....1........\n"
"3.....3........\n"
".....2.........\n"
"..........1....\n"
"...........2.2.\n"
"......2........\n"
"..1............\n"
".......2.......\n"
"...............\n") == 0);
free(board750404916);
board750404916 = NULL;
assert( gamma_move(board, 2, 13, 1) == 1 );
assert( gamma_move(board, 2, 9, 3) == 1 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 8, 16) == 1 );
assert( gamma_free_fields(board, 3) == 229 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 3, 7, 12) == 1 );
assert( gamma_free_fields(board, 3) == 222 );
assert( gamma_golden_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 1, 11, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_free_fields(board, 2) == 219 );
assert( gamma_move(board, 3, 10, 12) == 1 );
assert( gamma_move(board, 1, 6, 14) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 2, 10, 6) == 1 );
assert( gamma_move(board, 2, 11, 12) == 1 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 11, 6) == 1 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 1, 12, 6) == 1 );
assert( gamma_move(board, 1, 13, 12) == 1 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_golden_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_golden_move(board, 1, 13, 14) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 4, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_golden_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 11, 10) == 1 );
assert( gamma_move(board, 3, 13, 8) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board401820542 = gamma_board(board);
assert( board401820542 != NULL );
assert( strcmp(board401820542, 
"........33.....\n"
"..............3\n"
"......12.......\n"
".....1...2.....\n"
"2.1....3..32.1.\n"
".21.....2..3...\n"
".....1....22...\n"
".3...3.....1...\n"
"3.....1......3.\n"
"3.2...3...3....\n"
".....2....2211.\n"
"..2......31....\n"
"1.........32.2.\n"
"3.....23.21....\n"
".111...........\n"
"....3..2.....2.\n"
".....1.........\n") == 0);
free(board401820542);
board401820542 = NULL;
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_free_fields(board, 2) == 200 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 1, 13, 13) == 1 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_move(board, 3, 5, 12) == 1 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_free_fields(board, 2) == 195 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 1, 13, 0) == 1 );
assert( gamma_move(board, 1, 13, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 7) == 1 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 13, 14) == 1 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_free_fields(board, 3) == 186 );
assert( gamma_move(board, 1, 14, 7) == 1 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_free_fields(board, 2) == 183 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 1, 13, 16) == 1 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_free_fields(board, 2) == 179 );
assert( gamma_move(board, 3, 14, 0) == 1 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 14, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_free_fields(board, 1) == 177 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 1, 15, 13) == 0 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 2, 13, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_golden_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 3, 12, 8) == 1 );
assert( gamma_move(board, 3, 13, 2) == 1 );
assert( gamma_move(board, 1, 5, 8) == 1 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 2, 12, 12) == 1 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_free_fields(board, 3) == 163 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 3, 0, 15) == 1 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_free_fields(board, 2) == 161 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 3, 11, 16) == 1 );
assert( gamma_free_fields(board, 3) == 160 );
assert( gamma_free_fields(board, 1) == 160 );
assert( gamma_golden_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 3, 4, 10) == 1 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 28 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_free_fields(board, 3) == 154 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 1, 8, 2) == 1 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_free_fields(board, 3) == 150 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 10, 2) == 1 );
assert( gamma_move(board, 3, 4, 16) == 1 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 2, 6, 0) == 1 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 40 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 15, 12) == 0 );
assert( gamma_move(board, 2, 1, 16) == 1 );
assert( gamma_move(board, 3, 13, 10) == 1 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 41 );
assert( gamma_free_fields(board, 3) == 144 );
assert( gamma_move(board, 1, 8, 10) == 1 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 2, 12, 14) == 1 );
assert( gamma_move(board, 2, 14, 14) == 1 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_move(board, 3, 10, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 43 );
assert( gamma_move(board, 1, 1, 14) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_free_fields(board, 2) == 137 );
assert( gamma_move(board, 3, 16, 12) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_free_fields(board, 1) == 137 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 1, 11, 7) == 1 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 2, 14, 15) == 0 );
assert( gamma_free_fields(board, 2) == 135 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 43 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 2, 12, 11) == 1 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 34 );
assert( gamma_move(board, 2, 14, 4) == 1 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 10) == 1 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_golden_move(board, 2, 0, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 46 );
assert( gamma_move(board, 1, 14, 9) == 1 );
assert( gamma_move(board, 1, 12, 13) == 1 );
assert( gamma_free_fields(board, 1) == 125 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 47 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 4, 4) == 1 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 11, 2) == 1 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 1, 5, 15) == 1 );


char* board375217642 = gamma_board(board);
assert( board375217642 != NULL );
assert( strcmp(board375217642, 
".2..3...33.3.1.\n"
"33...1........3\n"
".13...12..3.232\n"
"..12.1...2..11.\n"
"2.1.33.3..3221.\n"
"321.....2..32..\n"
".2.131..1322.33\n"
".33.33.3...12.1\n"
"3.22.11.21.233.\n"
"3.2...3...31.21\n"
"..3.222..32211.\n"
".222.....312...\n"
"12..2313..32.22\n"
"333.2.23221..23\n"
"1111...11.32.3.\n"
"2...1232....22.\n"
"1...212..22..13\n") == 0);
free(board375217642);
board375217642 = NULL;
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 2, 7, 13) == 1 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 1, 1, 10) == 0 );


char* board592744014 = gamma_board(board);
assert( board592744014 != NULL );
assert( strcmp(board592744014, 
".2..3...33.3.1.\n"
"33...1........3\n"
".13...12..3.232\n"
"..12.1.2.2..11.\n"
"2.1.33.3..3221.\n"
"321.....2..32..\n"
"12.131..1322.33\n"
".33.33.3...12.1\n"
"3.22.11.21.233.\n"
"3.2...3...31.21\n"
"..3.2221.32211.\n"
".222.....312...\n"
"12..2313..32.22\n"
"333.2.23221..23\n"
"1111...11.32.3.\n"
"2...1232....22.\n"
"1...2123.22..13\n") == 0);
free(board592744014);
board592744014 = NULL;
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_golden_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 1, 8, 16) == 0 );
assert( gamma_free_fields(board, 1) == 117 );
assert( gamma_move(board, 2, 8, 14) == 1 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_move(board, 1, 13, 11) == 1 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );


char* board391924388 = gamma_board(board);
assert( board391924388 != NULL );
assert( strcmp(board391924388, 
".2..3...33.3.1.\n"
"33...1........3\n"
".13...122.3.232\n"
"..12.1.2.2..11.\n"
"2.1.33.3..3221.\n"
"321.....2..321.\n"
"12.131..1322.33\n"
".33.33.3...12.1\n"
"3.22.11.21.233.\n"
"3.2...3...31.21\n"
"..3.2221.32211.\n"
".222.....312...\n"
"12..2313..32.22\n"
"333.2.23221..23\n"
"1111...11.32.3.\n"
"2...1232....22.\n"
"1...2123.22..13\n") == 0);
free(board391924388);
board391924388 = NULL;
assert( gamma_move(board, 3, 9, 4) == 1 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 49 );
assert( gamma_golden_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_golden_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_free_fields(board, 1) == 111 );
assert( gamma_move(board, 2, 7, 8) == 1 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 3, 3, 16) == 1 );


char* board894119451 = gamma_board(board);
assert( board894119451 != NULL );
assert( strcmp(board894119451, 
".2.33...33.3.1.\n"
"33...1........3\n"
".13.2.122.3.232\n"
"..12.1.2.2..11.\n"
"2.1.33.3..3221.\n"
"321.....2..321.\n"
"12.131..1322.33\n"
".33.33.3.3.12.1\n"
"3.23.11221.233.\n"
"3.2...3.2.31.21\n"
"..3.2221.32211.\n"
".222.....312...\n"
"12..2313.332.22\n"
"333.2.23221..23\n"
"11113..11.32.3.\n"
"2...1232....22.\n"
"1...2123.22..13\n") == 0);
free(board894119451);
board894119451 = NULL;
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_free_fields(board, 2) == 108 );
assert( gamma_move(board, 3, 12, 0) == 1 );
assert( gamma_move(board, 1, 4, 5) == 1 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 2, 2, 15) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );


char* board879330867 = gamma_board(board);
assert( board879330867 != NULL );
assert( strcmp(board879330867, 
".2.33...33.3.1.\n"
"332..1........3\n"
".13.2.122.3.232\n"
"..12.1.2.2..11.\n"
"2.1.33.3..3221.\n"
"321.....2..321.\n"
"12.131..1322.33\n"
".33.33.3.3.12.1\n"
"3.23.11221.233.\n"
"3.2...3.2.31.21\n"
"..3.2221.32211.\n"
".2221....312...\n"
"12..2313.332.22\n"
"333.2.23221..23\n"
"11113..11.32.3.\n"
"2...1232....22.\n"
"1...2123.22.313\n") == 0);
free(board879330867);
board879330867 = NULL;
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 3, 2, 16) == 1 );
assert( gamma_move(board, 1, 11, 3) == 1 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 14) == 0 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 56 );
assert( gamma_move(board, 1, 13, 14) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 3, 12, 16) == 1 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_move(board, 3, 12, 14) == 0 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 58 );
assert( gamma_golden_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 6, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 60 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 3, 14, 6) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board187484866 = gamma_board(board);
assert( board187484866 != NULL );
assert( strcmp(board187484866, 
".2333...33.331.\n"
"332..1........3\n"
".13.2.122.33232\n"
"..12.1.2.2..11.\n"
"2.1.33.3..3221.\n"
"321.....2..321.\n"
"12.131..1322.33\n"
".33.3333.3.12.1\n"
"3.23.11221.233.\n"
"322..33.2.31.21\n"
"..3.2221.322113\n"
".2221....312...\n"
"12..23132332.22\n"
"333.2.232211323\n"
"11113..11332.3.\n"
"2..11232...222.\n"
"1...2123.22.313\n") == 0);
free(board187484866);
board187484866 = NULL;
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_free_fields(board, 2) == 92 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 8, 15) == 1 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 3, 5, 16) == 1 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_free_fields(board, 2) == 90 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_free_fields(board, 1) == 89 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 11, 16) == 0 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 3, 5, 14) == 1 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_golden_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_free_fields(board, 2) == 88 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 64 );
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_free_fields(board, 2) == 86 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 3, 6, 13) == 1 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 16, 10) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 8, 16) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 65 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 1, 7, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 2, 7, 11) == 1 );
assert( gamma_free_fields(board, 2) == 80 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 12, 16) == 0 );


char* board280099100 = gamma_board(board);
assert( board280099100 != NULL );
assert( strcmp(board280099100, 
".23333..33.331.\n"
"332..1.11.....3\n"
".13.23122.33232\n"
"..12.132.2..11.\n"
"2.1.33.3..3221.\n"
"321....223.321.\n"
"12.131..1322.33\n"
".3333333.3.12.1\n"
"3.23.11221.233.\n"
"322..3322.31.21\n"
"..3.2221.322113\n"
".2221.1..312...\n"
"12..23132332.22\n"
"333.2.232211323\n"
"11113..11332.3.\n"
"21.112321..222.\n"
"1...2123.222313\n") == 0);
free(board280099100);
board280099100 = NULL;
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_busy_fields(board, 3) == 66 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 66 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 13, 15) == 1 );
assert( gamma_busy_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 8, 16) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_free_fields(board, 2) == 76 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 13, 13) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_move(board, 2, 13, 5) == 1 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 16, 7) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 66 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 50 );
assert( gamma_free_fields(board, 1) == 74 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_free_fields(board, 2) == 73 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 66 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_move(board, 3, 9, 15) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 51 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 2, 13, 13) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_free_fields(board, 1) == 70 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 1, 10, 11) == 1 );


char* board399911701 = gamma_board(board);
assert( board399911701 != NULL );
assert( strcmp(board399911701, 
".23333..33.331.\n"
"332..1.113...13\n"
".13.23122.33232\n"
"..12.132.2..11.\n"
"2.1.33.3..3221.\n"
"321..2.2231321.\n"
"12.131..1322.33\n"
"33333333.3.12.1\n"
"3.23.112211233.\n"
"322..3322131.21\n"
"..3.2221.322113\n"
"22221.1.3312.2.\n"
"12..23132332.22\n"
"333.2.232211323\n"
"11113.211332.3.\n"
"21.112321..222.\n"
"1...2123.222313\n") == 0);
free(board399911701);
board399911701 = NULL;
assert( gamma_move(board, 2, 16, 7) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );


char* board414800555 = gamma_board(board);
assert( board414800555 != NULL );
assert( strcmp(board414800555, 
".23333..33.331.\n"
"332..1.113...13\n"
".13.23122.33232\n"
"..12.132.2..11.\n"
"2.1.33.3..3221.\n"
"321..2.2231321.\n"
"12.131..1322.33\n"
"33333333.3.12.1\n"
"3.23.112211233.\n"
"322..3322131.21\n"
"..3.2221.322113\n"
"22221.1.3312.2.\n"
"12..23132332.22\n"
"333.2.232211323\n"
"11113.211332.3.\n"
"21.112321..222.\n"
"1...2123.222313\n") == 0);
free(board414800555);
board414800555 = NULL;
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_free_fields(board, 2) == 68 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_golden_move(board, 1, 16, 1) == 0 );
assert( gamma_move(board, 2, 3, 11) == 1 );
assert( gamma_golden_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 3, 16, 14) == 0 );


char* board631077359 = gamma_board(board);
assert( board631077359 != NULL );
assert( strcmp(board631077359, 
".23333..33.331.\n"
"332..1.113...13\n"
".13.23122.33232\n"
"..12.132.2..11.\n"
"2.1.33.3..3221.\n"
"3212.2.2231321.\n"
"12.131..1322.33\n"
"33333333.3.12.1\n"
"3.23.112211233.\n"
"322..3322131.21\n"
"..3.2221.322113\n"
"22221.1.3312.2.\n"
"12..23132332.22\n"
"333.2.232211323\n"
"11113.211332.3.\n"
"21.112321..222.\n"
"1...2123.222313\n") == 0);
free(board631077359);
board631077359 = NULL;
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_free_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_free_fields(board, 3) == 67 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 10, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_golden_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_move(board, 3, 8, 16) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 67 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_golden_move(board, 2, 9, 9) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 16, 14) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_golden_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 1, 16, 14) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 2, 9, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 68 );
assert( gamma_move(board, 3, 4, 13) == 1 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 54 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_golden_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 12, 12) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 1, 14, 2) == 1 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 16, 10) == 0 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 1, 10, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 1, 5, 9) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 16, 7) == 0 );
assert( gamma_move(board, 3, 4, 14) == 0 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_free_fields(board, 3) == 59 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 1, 15, 11) == 0 );
assert( gamma_free_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 2, 7, 16) == 1 );
assert( gamma_free_fields(board, 2) == 57 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 1, 8, 15) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 1, 13, 14) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 3, 12, 14) == 0 );


char* board632957890 = gamma_board(board);
assert( board632957890 != NULL );
assert( strcmp(board632957890, 
".23333.233.331.\n"
"332..1.1131..13\n"
".13.23122.33232\n"
"..123132.21.11.\n"
"2.1.3333.23221.\n"
"3212.2.2231321.\n"
"12.131..1322.33\n"
"33333333.3.12.1\n"
"3.23.112211233.\n"
"322..3322131.21\n"
"..3.2221.322113\n"
"2222121.331232.\n"
"12..23132332.22\n"
"333.2.232211323\n"
"11113.211332.31\n"
"21.112321..222.\n"
"11..2123.222313\n") == 0);
free(board632957890);
board632957890 = NULL;
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 56 );
assert( gamma_golden_move(board, 1, 10, 14) == 0 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_free_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 2, 12, 15) == 1 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 74 );
assert( gamma_free_fields(board, 3) == 54 );
assert( gamma_busy_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_free_fields(board, 2) == 54 );
assert( gamma_move(board, 3, 16, 10) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 71 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 14, 12) == 1 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 58 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 2, 1) == 1 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_free_fields(board, 2) == 50 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 59 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_golden_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 16, 10) == 0 );
assert( gamma_move(board, 2, 11, 15) == 1 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 3, 16, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 74 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_free_fields(board, 1) == 49 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 3, 8, 12) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_golden_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_golden_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_golden_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_free_fields(board, 2) == 47 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );


char* board555609518 = gamma_board(board);
assert( board555609518 != NULL );
assert( strcmp(board555609518, 
".23333.233.331.\n"
"332..1.11312213\n"
"113.23122.33232\n"
"..123132.21.11.\n"
"2.1.33333232212\n"
"3212.2.2231321.\n"
"12.1311.1322.33\n"
"33333333.3.12.1\n"
"3.23.112211233.\n"
"322.33322131.21\n"
"..332221.322113\n"
"22221211331232.\n"
"12..23132332.22\n"
"333.2.232211323\n"
"11113.211332.31\n"
"211112321..222.\n"
"11..2123.222313\n") == 0);
free(board555609518);
board555609518 = NULL;
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 11, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 73 );
assert( gamma_move(board, 3, 1, 16) == 0 );
assert( gamma_free_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board474239133 = gamma_board(board);
assert( board474239133 != NULL );
assert( strcmp(board474239133, 
".23333.233.331.\n"
"332..1.11312213\n"
"113.23122.33232\n"
"..123132.21.11.\n"
"2.1.33333232212\n"
"3212.2.2231321.\n"
"12.1311.1322.33\n"
"33333333.3.12.1\n"
"3.23.112211233.\n"
"322.33322131.21\n"
"..332221.322113\n"
"22221211331232.\n"
"12..23132332.22\n"
"333.2.232211323\n"
"11113.211332.31\n"
"211112321..222.\n"
"11..2123.222313\n") == 0);
free(board474239133);
board474239133 = NULL;
assert( gamma_move(board, 3, 13, 9) == 1 );
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 77 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_move(board, 3, 8, 4) == 0 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 61 );
assert( gamma_move(board, 2, 13, 14) == 0 );
assert( gamma_move(board, 3, 4, 15) == 1 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_free_fields(board, 3) == 42 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );


char* board844952829 = gamma_board(board);
assert( board844952829 != NULL );
assert( strcmp(board844952829, 
".23333.233.331.\n"
"332.31.11312213\n"
"113.23122.33232\n"
"..123132.21.11.\n"
"2.1.33333232212\n"
"3212.2.2231321.\n"
"1231311.1322.33\n"
"33333333.3.1231\n"
"3.233112211233.\n"
"322.33322131.21\n"
"..332221.322113\n"
"22221211331232.\n"
"12..23132332.22\n"
"33312.232211323\n"
"11113.211332.31\n"
"211112321..222.\n"
"11..2123.222313\n") == 0);
free(board844952829);
board844952829 = NULL;
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_golden_move(board, 3, 15, 13) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 73 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );


char* board635617451 = gamma_board(board);
assert( board635617451 != NULL );
assert( strcmp(board635617451, 
".23333.233.331.\n"
"332.31.11312213\n"
"113.23122.33232\n"
"..123132.21.11.\n"
"2.1.33333232212\n"
"3212.2.2231321.\n"
"1231311.1322.33\n"
"33333333.3.1231\n"
"3.233112211233.\n"
"322.33322131.21\n"
"..332221.322113\n"
"22221211331232.\n"
"12..23132332.22\n"
"33312.232211323\n"
"11113.211332331\n"
"211112321..222.\n"
"11..2123.222313\n") == 0);
free(board635617451);
board635617451 = NULL;
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 61 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 73 );
assert( gamma_free_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 8, 15) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 73 );
assert( gamma_golden_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 16, 14) == 0 );


char* board823425677 = gamma_board(board);
assert( board823425677 != NULL );
assert( strcmp(board823425677, 
".23333.233.331.\n"
"332.31.11312213\n"
"113.23122.33232\n"
"..123132.21.11.\n"
"2.1.33333232212\n"
"3212.2.2231321.\n"
"1231311.1322.33\n"
"33333333.3.1231\n"
"3.233112211233.\n"
"322.33322131.21\n"
"..332221.322113\n"
"22221211331232.\n"
"12..23132332.22\n"
"33312.232211323\n"
"11113.211332331\n"
"211112321..222.\n"
"11..2123.222313\n") == 0);
free(board823425677);
board823425677 = NULL;
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_free_fields(board, 2) == 40 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );


char* board411062481 = gamma_board(board);
assert( board411062481 != NULL );
assert( strcmp(board411062481, 
".23333.233.331.\n"
"332.31.11312213\n"
"113.23122.33232\n"
"..123132.21.11.\n"
"2.1.33333232212\n"
"3212.2.2231321.\n"
"1231311.1322.33\n"
"33333333.3.1231\n"
"3.233112211233.\n"
"322.33322131.21\n"
"..332221.322113\n"
"22221211331232.\n"
"12..23132332.22\n"
"33312.232211323\n"
"111131211332331\n"
"211112321..222.\n"
"11..2123.222313\n") == 0);
free(board411062481);
board411062481 = NULL;
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_free_fields(board, 3) == 39 );
assert( gamma_golden_move(board, 3, 11, 7) == 0 );


gamma_delete(board);

    return 0;
}
