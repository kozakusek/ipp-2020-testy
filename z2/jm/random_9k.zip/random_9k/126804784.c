#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 126804784
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(14, 10, 9, 11);
assert( board != NULL );


assert( gamma_move(board, 1, 9, 1) == 1 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 1 );


char* board288898596 = gamma_board(board);
assert( board288898596 != NULL );
assert( strcmp(board288898596, 
"..............\n"
"2.............\n"
"..............\n"
"..............\n"
"..............\n"
"..............\n"
"..............\n"
".........3....\n"
".........1....\n"
"..............\n") == 0);
free(board288898596);
board288898596 = NULL;
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_move(board, 4, 12, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 8) == 1 );
assert( gamma_move(board, 5, 7, 4) == 1 );
assert( gamma_move(board, 6, 1, 3) == 1 );
assert( gamma_move(board, 6, 11, 5) == 1 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_move(board, 7, 7, 3) == 1 );
assert( gamma_move(board, 7, 12, 1) == 1 );
assert( gamma_move(board, 8, 5, 9) == 1 );
assert( gamma_move(board, 8, 5, 9) == 0 );
assert( gamma_move(board, 9, 7, 4) == 0 );
assert( gamma_move(board, 9, 9, 5) == 1 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_free_fields(board, 1) == 125 );
assert( gamma_move(board, 2, 7, 9) == 1 );
assert( gamma_free_fields(board, 2) == 124 );


char* board279543506 = gamma_board(board);
assert( board279543506 != NULL );
assert( strcmp(board279543506, 
".....8.2....4.\n"
"2........5....\n"
"..............\n"
"1.............\n"
".........9.6..\n"
"...4...5......\n"
".6.....7......\n"
".........3....\n"
"........11..7.\n"
"..............\n") == 0);
free(board279543506);
board279543506 = NULL;
assert( gamma_move(board, 3, 9, 0) == 1 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_golden_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_move(board, 4, 12, 0) == 1 );
assert( gamma_move(board, 5, 7, 12) == 0 );
assert( gamma_move(board, 5, 10, 1) == 1 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 6, 10, 7) == 1 );
assert( gamma_move(board, 7, 4, 3) == 1 );
assert( gamma_move(board, 8, 5, 4) == 1 );
assert( gamma_move(board, 9, 9, 4) == 1 );
assert( gamma_move(board, 9, 11, 0) == 1 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_move(board, 2, 10, 5) == 1 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_move(board, 5, 2, 2) == 1 );
assert( gamma_move(board, 5, 3, 9) == 1 );
assert( gamma_free_fields(board, 5) == 107 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_move(board, 8, 0, 0) == 1 );
assert( gamma_move(board, 8, 13, 4) == 1 );
assert( gamma_move(board, 9, 4, 3) == 0 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );


char* board733318239 = gamma_board(board);
assert( board733318239 != NULL );
assert( strcmp(board733318239, 
"...5.8.2....4.\n"
"2...4....5....\n"
"..........6...\n"
"1.............\n"
"..1.....3926..\n"
"...41815.9...8\n"
".6..7..7......\n"
"..5.4..2.3....\n"
"........115.7.\n"
"8.......13.94.\n") == 0);
free(board733318239);
board733318239 = NULL;
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 2, 12, 0) == 0 );


char* board942845460 = gamma_board(board);
assert( board942845460 != NULL );
assert( strcmp(board942845460, 
"...5.8.2....4.\n"
"2...4....5....\n"
"..........6...\n"
"1..2..........\n"
"..1.....3926..\n"
"...41815.9...8\n"
".6..7..7......\n"
"..5.4..2.3....\n"
"........115.7.\n"
"8.......13.94.\n") == 0);
free(board942845460);
board942845460 = NULL;
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_free_fields(board, 4) == 101 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 7, 1, 7) == 1 );
assert( gamma_busy_fields(board, 7) == 4 );
assert( gamma_move(board, 8, 6, 5) == 1 );
assert( gamma_free_fields(board, 8) == 99 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 1, 3) == 0 );
assert( gamma_move(board, 9, 8, 6) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 3, 9) == 0 );


char* board567218082 = gamma_board(board);
assert( board567218082 != NULL );
assert( strcmp(board567218082, 
"...5.8.2....4.\n"
"2...4....5....\n"
".7........6...\n"
"13.2....9.....\n"
"..1...8.3926..\n"
"...41815.9...8\n"
".6..7..7......\n"
"..5.4..2.3....\n"
"........115.7.\n"
"8.......13.94.\n") == 0);
free(board567218082);
board567218082 = NULL;
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_move(board, 3, 12, 5) == 1 );
assert( gamma_free_fields(board, 3) == 95 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 6 );
assert( gamma_move(board, 5, 6, 13) == 0 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 7, 0, 3) == 1 );


char* board779968395 = gamma_board(board);
assert( board779968395 != NULL );
assert( strcmp(board779968395, 
"...5.8.2....4.\n"
"2...4....5....\n"
".7........6...\n"
"13.2....9.....\n"
".41...8.39263.\n"
"...41815.9...8\n"
"76..7..7......\n"
"..5.4..233....\n"
"2.......115.7.\n"
"8.......13.94.\n") == 0);
free(board779968395);
board779968395 = NULL;
assert( gamma_move(board, 9, 9, 4) == 0 );
assert( gamma_move(board, 9, 7, 3) == 0 );
assert( gamma_busy_fields(board, 9) == 4 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_free_fields(board, 3) == 91 );
assert( gamma_golden_move(board, 3, 4, 3) == 1 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_free_fields(board, 4) == 90 );
assert( gamma_golden_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_move(board, 7, 3, 2) == 1 );
assert( gamma_move(board, 7, 8, 2) == 0 );
assert( gamma_move(board, 8, 3, 9) == 0 );
assert( gamma_move(board, 9, 5, 5) == 1 );
assert( gamma_move(board, 9, 11, 3) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );


char* board523575394 = gamma_board(board);
assert( board523575394 != NULL );
assert( strcmp(board523575394, 
"...5.8.2....4.\n"
"2...4....5....\n"
".7.....1.16...\n"
"13.2....9.....\n"
".41..98.39263.\n"
"...41815.9...8\n"
"76..3..7...9..\n"
"..574..233.4..\n"
"2.......115.7.\n"
"8.......13.94.\n") == 0);
free(board523575394);
board523575394 = NULL;
assert( gamma_move(board, 2, 13, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_free_fields(board, 5) == 86 );
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 6, 2, 1) == 1 );
assert( gamma_move(board, 7, 2, 6) == 1 );
assert( gamma_move(board, 7, 5, 0) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 8, 3) == 1 );
assert( gamma_move(board, 9, 3, 2) == 0 );
assert( gamma_move(board, 9, 4, 2) == 0 );
assert( gamma_busy_fields(board, 9) == 6 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 3, 13, 2) == 1 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 5, 7, 1) == 1 );
assert( gamma_busy_fields(board, 5) == 6 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 2) == 0 );
assert( gamma_move(board, 6, 8, 4) == 1 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 1, 1) == 1 );
assert( gamma_move(board, 9, 7, 5) == 1 );
assert( gamma_move(board, 9, 7, 3) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_free_fields(board, 1) == 75 );
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 12, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 6, 8, 7) == 1 );
assert( gamma_move(board, 8, 0, 6) == 0 );
assert( gamma_move(board, 8, 11, 8) == 1 );
assert( gamma_move(board, 9, 4, 0) == 1 );
assert( gamma_busy_fields(board, 9) == 8 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 3) == 1 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 7, 8, 3) == 0 );
assert( gamma_move(board, 7, 0, 6) == 0 );
assert( gamma_free_fields(board, 7) == 67 );
assert( gamma_move(board, 8, 6, 5) == 0 );
assert( gamma_move(board, 9, 8, 7) == 0 );
assert( gamma_move(board, 9, 4, 0) == 0 );
assert( gamma_move(board, 1, 1, 8) == 1 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 5, 1, 11) == 0 );
assert( gamma_move(board, 5, 0, 5) == 1 );
assert( gamma_free_fields(board, 5) == 64 );
assert( gamma_move(board, 6, 9, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 6 );
assert( gamma_move(board, 7, 8, 3) == 0 );
assert( gamma_move(board, 7, 8, 9) == 1 );
assert( gamma_move(board, 8, 13, 6) == 1 );
assert( gamma_move(board, 9, 1, 6) == 0 );
assert( gamma_move(board, 9, 13, 9) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 6, 3, 3) == 1 );
assert( gamma_move(board, 7, 9, 7) == 0 );
assert( gamma_move(board, 7, 13, 8) == 1 );
assert( gamma_move(board, 8, 9, 0) == 0 );
assert( gamma_move(board, 9, 8, 3) == 0 );
assert( gamma_move(board, 9, 7, 2) == 0 );
assert( gamma_free_fields(board, 9) == 59 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 10, 9) == 1 );


char* board608462138 = gamma_board(board);
assert( board608462138 != NULL );
assert( strcmp(board608462138, 
"...5.8.27.2349\n"
"21..4....5.8.7\n"
".7.....1616..2\n"
"1372...39....8\n"
"541..98939263.\n"
".3.4181569..18\n"
"76.634.78..94.\n"
"..5743.233.4.3\n"
"286....5115.7.\n"
"8...97.213.94.\n") == 0);
free(board608462138);
board608462138 = NULL;
assert( gamma_move(board, 4, 10, 4) == 1 );
assert( gamma_move(board, 5, 9, 6) == 1 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_move(board, 7, 2, 12) == 0 );
assert( gamma_move(board, 7, 0, 6) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_free_fields(board, 2) == 56 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 6, 6) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 8 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 6, 2, 7) == 1 );
assert( gamma_move(board, 7, 4, 11) == 0 );
assert( gamma_move(board, 8, 4, 0) == 0 );
assert( gamma_move(board, 8, 6, 1) == 1 );
assert( gamma_move(board, 9, 9, 4) == 0 );
assert( gamma_move(board, 9, 0, 8) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 6, 13, 3) == 1 );
assert( gamma_move(board, 7, 2, 12) == 0 );
assert( gamma_move(board, 7, 6, 6) == 0 );
assert( gamma_move(board, 8, 7, 11) == 0 );
assert( gamma_move(board, 9, 1, 5) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 5, 13) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 7, 4) == 0 );


char* board786062576 = gamma_board(board);
assert( board786062576 != NULL );
assert( strcmp(board786062576, 
"...5.8.27.2349\n"
"21..4....5.8.7\n"
".76....1616..2\n"
"1372..4395...8\n"
"541..98939263.\n"
".3.41815694.18\n"
"76.634.78..946\n"
"..5743.233.4.3\n"
"286...85115.7.\n"
"8...97.213.94.\n") == 0);
free(board786062576);
board786062576 = NULL;
assert( gamma_move(board, 9, 1, 5) == 0 );
assert( gamma_golden_move(board, 9, 1, 2) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_free_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 6, 1, 9) == 1 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_free_fields(board, 6) == 50 );
assert( gamma_move(board, 7, 13, 2) == 0 );
assert( gamma_free_fields(board, 7) == 50 );
assert( gamma_move(board, 8, 11, 2) == 0 );
assert( gamma_move(board, 9, 13, 4) == 0 );
assert( gamma_move(board, 9, 8, 6) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 7, 0, 2) == 1 );
assert( gamma_move(board, 7, 10, 0) == 1 );
assert( gamma_move(board, 8, 3, 9) == 0 );
assert( gamma_move(board, 8, 3, 2) == 0 );
assert( gamma_move(board, 9, 10, 6) == 1 );
assert( gamma_move(board, 9, 5, 1) == 1 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_move(board, 6, 7, 4) == 0 );
assert( gamma_free_fields(board, 6) == 44 );
assert( gamma_golden_move(board, 6, 6, 9) == 0 );
assert( gamma_move(board, 7, 8, 12) == 0 );
assert( gamma_move(board, 7, 12, 8) == 1 );
assert( gamma_move(board, 8, 4, 2) == 0 );
assert( gamma_move(board, 9, 8, 5) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_free_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 4, 11, 1) == 1 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_golden_move(board, 6, 4, 5) == 0 );
assert( gamma_free_fields(board, 7) == 42 );
assert( gamma_move(board, 8, 7, 5) == 0 );
assert( gamma_free_fields(board, 8) == 42 );
assert( gamma_move(board, 9, 1, 13) == 0 );
assert( gamma_move(board, 9, 13, 8) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_golden_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );


char* board921517388 = gamma_board(board);
assert( board921517388 != NULL );
assert( strcmp(board921517388, 
".6.5.8.27.2349\n"
"21..4....5.877\n"
"1761...1616..2\n"
"1372..43959..8\n"
"541..98939263.\n"
"23.41815694.18\n"
"76.634.78..946\n"
"7.5743.233.4.3\n"
"286.298511547.\n"
"8...97.213794.\n") == 0);
free(board921517388);
board921517388 = NULL;
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_move(board, 5, 10, 3) == 1 );
assert( gamma_move(board, 6, 3, 2) == 0 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_golden_move(board, 7, 5, 1) == 1 );


char* board328141477 = gamma_board(board);
assert( board328141477 != NULL );
assert( strcmp(board328141477, 
".6.5.8.27.2349\n"
"21..4....5.877\n"
"1761...1616..2\n"
"1372..43959..8\n"
"541..98939263.\n"
"23.41815694.18\n"
"76.634.78.5946\n"
"7.5743.233.4.3\n"
"286.278511547.\n"
"8...97.213794.\n") == 0);
free(board328141477);
board328141477 = NULL;
assert( gamma_move(board, 8, 0, 8) == 0 );
assert( gamma_golden_move(board, 8, 5, 8) == 0 );
assert( gamma_move(board, 9, 9, 6) == 0 );
assert( gamma_move(board, 9, 11, 7) == 1 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );


char* board130370898 = gamma_board(board);
assert( board130370898 != NULL );
assert( strcmp(board130370898, 
".6.5.8.27.2349\n"
"21..4....5.877\n"
"1761...16169.2\n"
"1372..43959..8\n"
"541..98939263.\n"
"23.41815694.18\n"
"76.634.78.5946\n"
"7.5743.233.4.3\n"
"286.278511547.\n"
"8...97.213794.\n") == 0);
free(board130370898);
board130370898 = NULL;
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 5, 4, 11) == 0 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_move(board, 6, 2, 1) == 0 );


char* board900236850 = gamma_board(board);
assert( board900236850 != NULL );
assert( strcmp(board900236850, 
".6.5.8.27.2349\n"
"21..4....5.877\n"
"1761...16169.2\n"
"1372..43959..8\n"
"541..98939263.\n"
"23.41815694.18\n"
"76.634.78.5946\n"
"7.5743.233.4.3\n"
"286.278511547.\n"
"8...97.213794.\n") == 0);
free(board900236850);
board900236850 = NULL;
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_golden_move(board, 7, 5, 2) == 0 );
assert( gamma_move(board, 8, 2, 6) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_free_fields(board, 1) == 12 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 5, 4, 11) == 0 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_move(board, 6, 7, 4) == 0 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 7, 7, 6) == 0 );
assert( gamma_move(board, 7, 8, 6) == 0 );
assert( gamma_move(board, 8, 6, 11) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );


char* board366217467 = gamma_board(board);
assert( board366217467 != NULL );
assert( strcmp(board366217467, 
".655.8.27.2349\n"
"21..4.1..5.877\n"
"1761...16169.2\n"
"1372..43959..8\n"
"541..98939263.\n"
"23.41815694.18\n"
"76.634.78.5946\n"
"7.5743.233.4.3\n"
"286.278511547.\n"
"8...97.213794.\n") == 0);
free(board366217467);
board366217467 = NULL;
assert( gamma_move(board, 9, 6, 12) == 0 );
assert( gamma_move(board, 9, 3, 8) == 1 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_free_fields(board, 3) == 8 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 10, 2) == 1 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 3, 4) == 0 );
assert( gamma_move(board, 8, 3, 2) == 0 );
assert( gamma_move(board, 8, 1, 9) == 0 );
assert( gamma_move(board, 9, 13, 0) == 0 );
assert( gamma_move(board, 9, 9, 2) == 0 );


char* board982869859 = gamma_board(board);
assert( board982869859 != NULL );
assert( strcmp(board982869859, 
".655.8.27.2349\n"
"21.94.1..5.877\n"
"1761...16169.2\n"
"1372..43959..8\n"
"541..98939263.\n"
"23.41815694.18\n"
"76.634.78.5946\n"
"7.5743.23354.3\n"
"286.278511547.\n"
"8...97.213794.\n") == 0);
free(board982869859);
board982869859 = NULL;
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_golden_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 5, 9, 4) == 0 );
assert( gamma_move(board, 6, 5, 8) == 1 );
assert( gamma_busy_fields(board, 6) == 11 );
assert( gamma_move(board, 7, 4, 11) == 0 );
assert( gamma_move(board, 7, 8, 3) == 0 );
assert( gamma_free_fields(board, 7) == 34 );
assert( gamma_move(board, 8, 6, 12) == 0 );
assert( gamma_move(board, 8, 3, 6) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 1, 3) == 0 );
assert( gamma_move(board, 9, 5, 3) == 0 );
assert( gamma_busy_fields(board, 9) == 12 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 11 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_move(board, 7, 6, 5) == 0 );
assert( gamma_move(board, 8, 9, 9) == 1 );
assert( gamma_move(board, 8, 4, 8) == 0 );
assert( gamma_move(board, 9, 0, 2) == 0 );
assert( gamma_move(board, 9, 7, 1) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_golden_move(board, 2, 5, 6) == 0 );


char* board854680900 = gamma_board(board);
assert( board854680900 != NULL );
assert( strcmp(board854680900, 
".655.8.2782349\n"
"21.9461..5.877\n"
"1761...16169.2\n"
"1372..43959..8\n"
"541..98939263.\n"
"23.41815694.18\n"
"76.634.78.5946\n"
"7.5743.23354.3\n"
"286.278511547.\n"
"8...97.213794.\n") == 0);
free(board854680900);
board854680900 = NULL;
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_free_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 5, 11, 6) == 1 );
assert( gamma_move(board, 6, 10, 7) == 0 );
assert( gamma_move(board, 7, 5, 4) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 6, 1) == 0 );
assert( gamma_move(board, 9, 3, 2) == 0 );
assert( gamma_move(board, 9, 7, 4) == 0 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 7, 4, 5) == 1 );
assert( gamma_move(board, 8, 0, 1) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 4, 1) == 0 );


char* board243989201 = gamma_board(board);
assert( board243989201 != NULL );
assert( strcmp(board243989201, 
".655.8.2782349\n"
"21.9461..5.877\n"
"1761...16169.2\n"
"1372..439595.8\n"
"541.798939263.\n"
"23.41815694.18\n"
"76.634.78.5946\n"
"7.5743.23354.3\n"
"286.278511547.\n"
"8...97.213794.\n") == 0);
free(board243989201);
board243989201 = NULL;
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 1, 12, 4) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 2, 12) == 0 );
assert( gamma_move(board, 6, 7, 6) == 0 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_move(board, 7, 12, 5) == 0 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 8, 6, 9) == 1 );
assert( gamma_move(board, 9, 6, 5) == 0 );
assert( gamma_move(board, 9, 13, 0) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_golden_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 5, 13) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 5, 3, 5) == 1 );
assert( gamma_move(board, 6, 2, 8) == 1 );
assert( gamma_move(board, 8, 4, 2) == 0 );
assert( gamma_move(board, 8, 5, 0) == 0 );
assert( gamma_free_fields(board, 8) == 9 );
assert( gamma_move(board, 9, 0, 2) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_free_fields(board, 1) == 6 );
assert( gamma_move(board, 2, 6, 4) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 5, 5, 13) == 0 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_move(board, 7, 0, 3) == 0 );
assert( gamma_move(board, 7, 12, 5) == 0 );
assert( gamma_move(board, 8, 6, 12) == 0 );
assert( gamma_move(board, 8, 2, 7) == 0 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_move(board, 9, 8, 10) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 14 );


gamma_delete(board);

    return 0;
}
