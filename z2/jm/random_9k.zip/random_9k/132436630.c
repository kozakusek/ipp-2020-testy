#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 132436630
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 17, 8, 28);
assert( board != NULL );


assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 2, 10, 16) == 1 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 6) == 1 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 5, 10, 9) == 1 );
assert( gamma_move(board, 6, 14, 1) == 0 );
assert( gamma_move(board, 7, 12, 6) == 0 );
assert( gamma_free_fields(board, 7) == 197 );
assert( gamma_move(board, 8, 10, 4) == 1 );
assert( gamma_free_fields(board, 8) == 196 );
assert( gamma_move(board, 1, 5, 7) == 1 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_move(board, 4, 7, 16) == 1 );
assert( gamma_move(board, 5, 2, 6) == 1 );
assert( gamma_move(board, 5, 8, 1) == 1 );
assert( gamma_move(board, 6, 15, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 0 );
assert( gamma_move(board, 7, 6, 6) == 1 );
assert( gamma_move(board, 7, 11, 15) == 1 );
assert( gamma_free_fields(board, 7) == 186 );
assert( gamma_move(board, 8, 4, 6) == 1 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 10, 13) == 1 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_golden_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_move(board, 5, 11, 6) == 1 );
assert( gamma_free_fields(board, 5) == 179 );
assert( gamma_move(board, 6, 7, 7) == 1 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_move(board, 7, 8, 0) == 1 );
assert( gamma_golden_move(board, 7, 16, 10) == 0 );
assert( gamma_move(board, 8, 1, 10) == 1 );
assert( gamma_move(board, 1, 16, 6) == 0 );
assert( gamma_move(board, 2, 4, 13) == 1 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 6, 16) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 11) == 1 );
assert( gamma_move(board, 4, 4, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 8) == 1 );
assert( gamma_free_fields(board, 6) == 170 );
assert( gamma_move(board, 7, 10, 7) == 1 );
assert( gamma_move(board, 7, 1, 14) == 1 );
assert( gamma_busy_fields(board, 8) == 3 );
assert( gamma_move(board, 1, 9, 6) == 1 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 4, 3, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 11, 0) == 1 );
assert( gamma_move(board, 7, 1, 3) == 1 );
assert( gamma_move(board, 8, 15, 6) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_free_fields(board, 4) == 160 );
assert( gamma_move(board, 5, 1, 11) == 1 );
assert( gamma_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 8, 9, 13) == 1 );
assert( gamma_move(board, 8, 9, 13) == 0 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 7, 16, 1) == 0 );
assert( gamma_move(board, 7, 9, 8) == 1 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_move(board, 1, 8, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_move(board, 2, 9, 9) == 1 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_free_fields(board, 3) == 152 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 5, 4, 5) == 1 );
assert( gamma_move(board, 6, 7, 16) == 0 );
assert( gamma_golden_move(board, 6, 7, 10) == 0 );
assert( gamma_move(board, 7, 10, 2) == 1 );
assert( gamma_move(board, 7, 10, 12) == 1 );
assert( gamma_move(board, 8, 10, 5) == 1 );
assert( gamma_move(board, 1, 8, 11) == 1 );
assert( gamma_move(board, 1, 5, 16) == 1 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_move(board, 5, 5, 8) == 1 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 6, 9, 2) == 0 );
assert( gamma_move(board, 6, 1, 6) == 1 );
assert( gamma_free_fields(board, 6) == 140 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 11, 5) == 1 );
assert( gamma_move(board, 7, 1, 16) == 1 );
assert( gamma_move(board, 8, 9, 10) == 1 );
assert( gamma_move(board, 8, 10, 2) == 0 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_free_fields(board, 3) == 135 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_move(board, 4, 0, 15) == 1 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 6, 4, 9) == 0 );
assert( gamma_move(board, 6, 1, 2) == 1 );
assert( gamma_move(board, 7, 11, 9) == 1 );
assert( gamma_move(board, 8, 8, 4) == 1 );


char* board812795828 = gamma_board(board);
assert( board812795828 != NULL );
assert( strcmp(board812795828, 
".7...134..2.\n"
"4..........7\n"
".7.32.....1.\n"
"....2...184.\n"
"..........7.\n"
".5..4.2.1...\n"
"38....3..8..\n"
"...424...257\n"
"..3..5.5.7..\n"
"24...1.6..7.\n"
"46528.7.21.5\n"
"3.2.511...87\n"
"..24....8.8.\n"
".7.......1..\n"
"46.......37.\n"
".23.....53..\n"
"....454.7..5\n") == 0);
free(board812795828);
board812795828 = NULL;
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 2, 0, 3) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 3, 9, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 3) == 1 );
assert( gamma_move(board, 5, 5, 11) == 1 );
assert( gamma_move(board, 6, 5, 1) == 1 );
assert( gamma_busy_fields(board, 6) == 4 );
assert( gamma_move(board, 7, 10, 6) == 1 );
assert( gamma_move(board, 8, 13, 0) == 0 );
assert( gamma_move(board, 8, 7, 12) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 5, 11, 14) == 1 );
assert( gamma_move(board, 6, 5, 14) == 1 );
assert( gamma_move(board, 6, 2, 3) == 1 );
assert( gamma_move(board, 7, 0, 9) == 1 );
assert( gamma_move(board, 7, 2, 10) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 3, 14) == 0 );
assert( gamma_move(board, 8, 5, 3) == 1 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_golden_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 1, 14) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_golden_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 5, 2, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 11, 5) == 0 );
assert( gamma_move(board, 7, 9, 1) == 0 );
assert( gamma_move(board, 7, 9, 9) == 0 );
assert( gamma_free_fields(board, 7) == 112 );
assert( gamma_move(board, 8, 3, 7) == 1 );
assert( gamma_move(board, 2, 11, 10) == 1 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_free_fields(board, 2) == 109 );
assert( gamma_golden_move(board, 2, 11, 5) == 1 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_move(board, 6, 12, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 12, 3) == 0 );
assert( gamma_move(board, 8, 5, 3) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_golden_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 5, 16, 9) == 0 );
assert( gamma_move(board, 5, 4, 9) == 0 );
assert( gamma_move(board, 6, 12, 0) == 0 );
assert( gamma_move(board, 6, 6, 14) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 2, 7) == 1 );
assert( gamma_move(board, 7, 3, 11) == 1 );
assert( gamma_move(board, 8, 6, 8) == 0 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_move(board, 6, 8, 14) == 1 );
assert( gamma_move(board, 7, 7, 9) == 1 );
assert( gamma_move(board, 7, 4, 5) == 0 );
assert( gamma_free_fields(board, 7) == 101 );
assert( gamma_move(board, 8, 4, 9) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 7, 14) == 1 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 1, 16) == 0 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_move(board, 5, 8, 10) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_free_fields(board, 6) == 95 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 17 );


char* board564729733 = gamma_board(board);
assert( board564729733 != NULL );
assert( strcmp(board564729733, 
".7...134..2.\n"
"4..........7\n"
".73326616315\n"
"....2...184.\n"
"....3..8..7.\n"
".5.7452.1...\n"
"387...3.58.2\n"
"72.424.7.257\n"
"..32.525474.\n"
"247851.62.73\n"
"46528.7.2175\n"
"3.2.511...82\n"
"..24....8.8.\n"
"2765.8...15.\n"
"46.......37.\n"
"323..6..53..\n"
".2..454.7..5\n") == 0);
free(board564729733);
board564729733 = NULL;
assert( gamma_move(board, 8, 7, 11) == 1 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 15, 2) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 3, 9, 14) == 0 );


char* board887912445 = gamma_board(board);
assert( board887912445 != NULL );
assert( strcmp(board887912445, 
".7...134..2.\n"
"4..........7\n"
".73326616315\n"
"....2...184.\n"
"....3..8..7.\n"
".5.745281...\n"
"387...3.58.2\n"
"72.424.7.257\n"
"..32.525474.\n"
"247851.62.73\n"
"46528.7.2175\n"
"3.2.511...82\n"
"..24....8.8.\n"
"276518...15.\n"
"46.......37.\n"
"323..6..53..\n"
".2..454.7..5\n") == 0);
free(board887912445);
board887912445 = NULL;
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 5, 1, 3) == 0 );
assert( gamma_free_fields(board, 5) == 91 );
assert( gamma_move(board, 6, 16, 9) == 0 );
assert( gamma_move(board, 6, 11, 4) == 1 );
assert( gamma_move(board, 7, 2, 7) == 0 );
assert( gamma_move(board, 7, 5, 13) == 1 );
assert( gamma_move(board, 8, 1, 14) == 0 );
assert( gamma_move(board, 8, 0, 0) == 1 );
assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_free_fields(board, 2) == 87 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 4, 0, 16) == 1 );
assert( gamma_move(board, 5, 15, 8) == 0 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_move(board, 6, 2, 9) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 3, 8) == 0 );
assert( gamma_move(board, 7, 5, 12) == 1 );
assert( gamma_busy_fields(board, 7) == 19 );
assert( gamma_move(board, 8, 7, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 12 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 1, 4, 15) == 1 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_free_fields(board, 2) == 81 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 5, 15, 8) == 0 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 0, 2) == 0 );
assert( gamma_move(board, 8, 9, 5) == 1 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 11, 7) == 0 );
assert( gamma_free_fields(board, 2) == 80 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_free_fields(board, 3) == 80 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 9, 7) == 1 );
assert( gamma_move(board, 5, 12, 9) == 0 );
assert( gamma_move(board, 6, 16, 11) == 0 );
assert( gamma_move(board, 7, 11, 9) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 19 );
assert( gamma_move(board, 8, 15, 2) == 0 );
assert( gamma_move(board, 8, 3, 15) == 1 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_golden_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_move(board, 4, 11, 8) == 1 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_move(board, 7, 10, 5) == 0 );
assert( gamma_move(board, 8, 0, 3) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_golden_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 6, 16) == 0 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board509093873 = gamma_board(board);
assert( board509093873 != NULL );
assert( strcmp(board509093873, 
"47...134..2.\n"
"4..81......7\n"
".73326616315\n"
"....27.3184.\n"
"....37.8..7.\n"
".51745281...\n"
"3872..3.5842\n"
"726424.7.257\n"
"..32.5254744\n"
"247851.62473\n"
"46528.7.2175\n"
"3.2.5114.882\n"
"..244...8.86\n"
"276518.3.15.\n"
"46.3.....37.\n"
"323..6..53..\n"
"82..454.7..5\n") == 0);
free(board509093873);
board509093873 = NULL;
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 6, 0, 12) == 1 );
assert( gamma_move(board, 6, 4, 3) == 0 );
assert( gamma_move(board, 7, 14, 0) == 0 );
assert( gamma_move(board, 7, 10, 1) == 1 );
assert( gamma_move(board, 8, 4, 13) == 0 );
assert( gamma_move(board, 8, 8, 7) == 0 );
assert( gamma_free_fields(board, 8) == 72 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 2, 15) == 1 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_golden_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 6, 5, 6) == 1 );


char* board251914032 = gamma_board(board);
assert( board251914032 != NULL );
assert( strcmp(board251914032, 
"47...134..2.\n"
"4.181......7\n"
".73326616315\n"
"....27.3184.\n"
"6...37.8..7.\n"
".51745281...\n"
"3872..3.5842\n"
"726424.7.257\n"
"..32.5254744\n"
"247851.62473\n"
"4652867.2175\n"
"3.2.5114.882\n"
"..244...8.86\n"
"276518.3.15.\n"
"46.3.....37.\n"
"323..6..537.\n"
"82..454.7..5\n") == 0);
free(board251914032);
board251914032 = NULL;
assert( gamma_move(board, 7, 1, 4) == 1 );
assert( gamma_move(board, 7, 10, 14) == 0 );
assert( gamma_move(board, 8, 3, 16) == 1 );
assert( gamma_move(board, 8, 5, 13) == 0 );
assert( gamma_free_fields(board, 8) == 68 );


char* board304372470 = gamma_board(board);
assert( board304372470 != NULL );
assert( strcmp(board304372470, 
"47.8.134..2.\n"
"4.181......7\n"
".73326616315\n"
"....27.3184.\n"
"6...37.8..7.\n"
".51745281...\n"
"3872..3.5842\n"
"726424.7.257\n"
"..32.5254744\n"
"247851.62473\n"
"4652867.2175\n"
"3.2.5114.882\n"
".7244...8.86\n"
"276518.3.15.\n"
"46.3.....37.\n"
"323..6..537.\n"
"82..454.7..5\n") == 0);
free(board304372470);
board304372470 = NULL;
assert( gamma_golden_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 5, 15, 9) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_golden_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 6, 12, 3) == 0 );
assert( gamma_move(board, 6, 8, 15) == 1 );
assert( gamma_move(board, 7, 15, 5) == 0 );
assert( gamma_move(board, 7, 6, 14) == 0 );
assert( gamma_move(board, 8, 8, 0) == 0 );
assert( gamma_move(board, 1, 5, 10) == 1 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_free_fields(board, 2) == 66 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_free_fields(board, 3) == 66 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_free_fields(board, 4) == 66 );
assert( gamma_move(board, 5, 10, 13) == 0 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 3) == 0 );
assert( gamma_move(board, 7, 3, 2) == 0 );
assert( gamma_move(board, 8, 10, 14) == 0 );
assert( gamma_free_fields(board, 8) == 66 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_free_fields(board, 6) == 66 );
assert( gamma_move(board, 7, 11, 6) == 0 );
assert( gamma_move(board, 7, 10, 3) == 0 );
assert( gamma_move(board, 8, 11, 10) == 0 );
assert( gamma_move(board, 8, 5, 0) == 0 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_free_fields(board, 1) == 66 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 5, 3, 10) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 6, 9, 13) == 0 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_move(board, 7, 16, 9) == 0 );
assert( gamma_busy_fields(board, 7) == 21 );
assert( gamma_move(board, 8, 10, 2) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );


char* board570233108 = gamma_board(board);
assert( board570233108 != NULL );
assert( strcmp(board570233108, 
"47.8.134..2.\n"
"4.181...6..7\n"
".73326616315\n"
"....27.3184.\n"
"6...37.8..7.\n"
".51745281...\n"
"3872.13.5842\n"
"726424.7.257\n"
"..32.5254744\n"
"247851.62473\n"
"4652867.2175\n"
"3.2.5114.882\n"
".7244...8.86\n"
"276518.3.15.\n"
"46.3.....37.\n"
"323..6..537.\n"
"82..454.7..5\n") == 0);
free(board570233108);
board570233108 = NULL;
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 3, 9, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_free_fields(board, 4) == 65 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_free_fields(board, 5) == 65 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 21 );
assert( gamma_move(board, 8, 8, 6) == 0 );
assert( gamma_move(board, 8, 6, 1) == 1 );
assert( gamma_golden_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 6, 4, 9) == 0 );
assert( gamma_move(board, 6, 5, 4) == 1 );


char* board417982446 = gamma_board(board);
assert( board417982446 != NULL );
assert( strcmp(board417982446, 
"47.8.134..2.\n"
"4.181...6..7\n"
".73326616315\n"
"....27.3184.\n"
"6...37.8.37.\n"
".51745281...\n"
"3872.13.5842\n"
"726424.7.257\n"
"..32.5254744\n"
"247851.62473\n"
"4652867.2175\n"
"3.2.5114.882\n"
".72446..8.86\n"
"276518.3.15.\n"
"46.3.....37.\n"
"323..68.537.\n"
"82..454.7..5\n") == 0);
free(board417982446);
board417982446 = NULL;
assert( gamma_move(board, 7, 9, 15) == 1 );
assert( gamma_move(board, 8, 7, 6) == 1 );
assert( gamma_move(board, 8, 3, 5) == 1 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_free_fields(board, 2) == 60 );
assert( gamma_golden_move(board, 2, 5, 6) == 0 );


char* board640504639 = gamma_board(board);
assert( board640504639 != NULL );
assert( strcmp(board640504639, 
"47.8.134..2.\n"
"4.181...67.7\n"
".73326616315\n"
"....27.3184.\n"
"6...37.8.37.\n"
".51745281...\n"
"3872.13.5842\n"
"726424.7.257\n"
"..32.5254744\n"
"247851.62473\n"
"465286782175\n"
"3.285114.882\n"
".72446..8.86\n"
"276518.3.15.\n"
"46.3.....37.\n"
"323..68.537.\n"
"82..454.7..5\n") == 0);
free(board640504639);
board640504639 = NULL;
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 8, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 16 );
assert( gamma_golden_move(board, 5, 3, 7) == 1 );
assert( gamma_move(board, 6, 3, 7) == 0 );
assert( gamma_move(board, 7, 13, 3) == 0 );
assert( gamma_move(board, 8, 10, 2) == 0 );
assert( gamma_move(board, 1, 12, 6) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 10, 14) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_free_fields(board, 6) == 60 );
assert( gamma_move(board, 7, 11, 10) == 0 );
assert( gamma_move(board, 7, 5, 7) == 0 );


char* board581803287 = gamma_board(board);
assert( board581803287 != NULL );
assert( strcmp(board581803287, 
"47.8.134..2.\n"
"4.181...67.7\n"
".73326616315\n"
"....27.3184.\n"
"6...37.8.37.\n"
".51745281...\n"
"3872.13.5842\n"
"726424.7.257\n"
"..32.5254744\n"
"247551.62473\n"
"465286782175\n"
"3.285114.882\n"
".72446..8.86\n"
"276518.3.15.\n"
"46.3.....37.\n"
"323..68.537.\n"
"82..454.7..5\n") == 0);
free(board581803287);
board581803287 = NULL;
assert( gamma_move(board, 8, 13, 3) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 4, 11, 15) == 0 );
assert( gamma_move(board, 4, 10, 0) == 1 );
assert( gamma_move(board, 6, 11, 15) == 0 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_free_fields(board, 7) == 59 );
assert( gamma_move(board, 8, 12, 11) == 0 );
assert( gamma_move(board, 8, 8, 14) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 8, 15) == 0 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 3, 2, 16) == 1 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 4, 11, 11) == 1 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 1, 7) == 0 );
assert( gamma_move(board, 7, 5, 8) == 0 );
assert( gamma_move(board, 8, 13, 11) == 0 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_free_fields(board, 2) == 56 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_move(board, 5, 6, 14) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 6, 5, 9) == 0 );
assert( gamma_move(board, 7, 8, 16) == 1 );
assert( gamma_move(board, 7, 6, 14) == 0 );
assert( gamma_move(board, 8, 5, 8) == 0 );
assert( gamma_golden_move(board, 8, 9, 10) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 2, 10, 15) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board200556064 = gamma_board(board);
assert( board200556064 != NULL );
assert( strcmp(board200556064, 
"4738.1347.2.\n"
"4.181...6727\n"
".73326616315\n"
"....27.3184.\n"
"6...37.8.37.\n"
".51745281..4\n"
"3872.1315842\n"
"726424.7.257\n"
"..32.5254744\n"
"247551.62473\n"
"465286782175\n"
"3.285114.882\n"
".72446..8.86\n"
"276518.3.15.\n"
"46.3.....37.\n"
"323..68.537.\n"
"82..454.7.45\n") == 0);
free(board200556064);
board200556064 = NULL;
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_free_fields(board, 4) == 53 );
assert( gamma_move(board, 5, 12, 11) == 0 );
assert( gamma_move(board, 5, 3, 0) == 1 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_move(board, 7, 6, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 12, 8) == 0 );
assert( gamma_move(board, 8, 11, 9) == 0 );
assert( gamma_move(board, 1, 8, 15) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_golden_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 5, 9, 14) == 0 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_move(board, 7, 4, 6) == 0 );
assert( gamma_move(board, 7, 0, 1) == 0 );
assert( gamma_move(board, 8, 1, 11) == 0 );
assert( gamma_move(board, 8, 3, 6) == 0 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_golden_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 4, 15) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 4, 11, 15) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 6, 9, 9) == 0 );
assert( gamma_free_fields(board, 6) == 51 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 23 );
assert( gamma_move(board, 8, 0, 2) == 0 );
assert( gamma_move(board, 8, 4, 8) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 1, 7, 16) == 0 );
assert( gamma_free_fields(board, 1) == 50 );
assert( gamma_move(board, 2, 8, 16) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_free_fields(board, 2) == 50 );
assert( gamma_golden_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 6, 5, 14) == 0 );
assert( gamma_move(board, 8, 4, 7) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_golden_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_move(board, 6, 10, 16) == 0 );
assert( gamma_move(board, 7, 7, 8) == 0 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_move(board, 8, 11, 0) == 0 );
assert( gamma_free_fields(board, 8) == 48 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 3, 9, 16) == 1 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_free_fields(board, 4) == 47 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 5, 10, 12) == 0 );
assert( gamma_move(board, 6, 15, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board880131863 = gamma_board(board);
assert( board880131863 != NULL );
assert( strcmp(board880131863, 
"4738.134732.\n"
"4.181...6727\n"
".73326616315\n"
"...127.3184.\n"
"6...37.8.37.\n"
".51745281..4\n"
"387241315842\n"
"726424.7.257\n"
"..3285254744\n"
"247551.62473\n"
"465286782175\n"
"3.285114.882\n"
".72446..8.86\n"
"276518.3.15.\n"
"44.3.3...37.\n"
"3231.68.537.\n"
"82.5454.7.45\n") == 0);
free(board880131863);
board880131863 = NULL;
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 8, 16, 11) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 11, 15) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 3, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 5, 11, 7) == 0 );
assert( gamma_move(board, 6, 2, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_move(board, 7, 0, 2) == 0 );
assert( gamma_move(board, 7, 6, 12) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_move(board, 7, 5, 6) == 1 );
assert( gamma_move(board, 8, 4, 2) == 1 );
assert( gamma_move(board, 8, 0, 0) == 0 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 1, 12) == 1 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_golden_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_free_fields(board, 6) == 42 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 3, 11) == 0 );
assert( gamma_move(board, 7, 2, 13) == 1 );
assert( gamma_move(board, 8, 2, 6) == 0 );
assert( gamma_busy_fields(board, 8) == 19 );
assert( gamma_move(board, 1, 0, 11) == 1 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 5, 1, 16) == 0 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 7, 8, 12) == 1 );
assert( gamma_move(board, 8, 13, 1) == 0 );
assert( gamma_move(board, 8, 0, 4) == 1 );
assert( gamma_busy_fields(board, 8) == 20 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_free_fields(board, 2) == 38 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_free_fields(board, 5) == 38 );
assert( gamma_move(board, 6, 2, 16) == 0 );
assert( gamma_golden_move(board, 6, 11, 0) == 1 );
assert( gamma_move(board, 7, 4, 9) == 0 );
assert( gamma_move(board, 7, 1, 13) == 1 );


char* board288559467 = gamma_board(board);
assert( board288559467 != NULL );
assert( strcmp(board288559467, 
"4738.134732.\n"
"4.181...6727\n"
".73326616315\n"
".77127.3184.\n"
"62.33778737.\n"
"151745281..4\n"
"387241315842\n"
"726424.7.257\n"
"..3285254744\n"
"247551.62473\n"
"465287782175\n"
"3.285114.882\n"
"872446..8.86\n"
"276518.3.15.\n"
"444383...37.\n"
"3231.68.537.\n"
"82.5454.7.46\n") == 0);
free(board288559467);
board288559467 = NULL;
assert( gamma_move(board, 8, 0, 0) == 0 );
assert( gamma_move(board, 8, 6, 3) == 1 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board760027934 = gamma_board(board);
assert( board760027934 != NULL );
assert( strcmp(board760027934, 
"4738.134732.\n"
"4.181...6727\n"
".73326616315\n"
".77127.3184.\n"
"62.33778737.\n"
"151745281..4\n"
"387241315842\n"
"726424.7.257\n"
"..3285254744\n"
"247551.62473\n"
"465287782175\n"
"3.285114.882\n"
"872446..8.86\n"
"27651883.15.\n"
"444383...37.\n"
"3231.68.537.\n"
"82.5454.7.46\n") == 0);
free(board760027934);
board760027934 = NULL;
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_move(board, 6, 15, 5) == 0 );
assert( gamma_move(board, 6, 3, 9) == 0 );
assert( gamma_move(board, 7, 14, 0) == 0 );
assert( gamma_move(board, 8, 15, 7) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 19 );


char* board711769564 = gamma_board(board);
assert( board711769564 != NULL );
assert( strcmp(board711769564, 
"4738.134732.\n"
"4.181...6727\n"
".73326616315\n"
".77127.3184.\n"
"62.33778737.\n"
"151745281..4\n"
"387241315842\n"
"726424.7.257\n"
"..3285254744\n"
"247551.62473\n"
"465287782175\n"
"3.285114.882\n"
"872446..8.86\n"
"27651883.15.\n"
"444383...37.\n"
"3231.68.537.\n"
"82.5454.7.46\n") == 0);
free(board711769564);
board711769564 = NULL;
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_free_fields(board, 2) == 36 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 5, 1, 2) == 0 );
assert( gamma_free_fields(board, 5) == 36 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_move(board, 7, 2, 2) == 0 );
assert( gamma_move(board, 8, 2, 7) == 0 );
assert( gamma_busy_fields(board, 8) == 21 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 5, 1, 7) == 0 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_golden_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 6, 11, 10) == 0 );
assert( gamma_move(board, 7, 15, 5) == 0 );
assert( gamma_free_fields(board, 7) == 36 );
assert( gamma_move(board, 8, 6, 4) == 1 );
assert( gamma_move(board, 8, 11, 7) == 0 );
assert( gamma_free_fields(board, 8) == 35 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 25 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_move(board, 7, 2, 9) == 0 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 8, 3, 11) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );


char* board977087175 = gamma_board(board);
assert( board977087175 != NULL );
assert( strcmp(board977087175, 
"4738.134732.\n"
"4.181...6727\n"
".73326616315\n"
".77127.3184.\n"
"62.33778737.\n"
"151745281..4\n"
"387241315842\n"
"726424.7.257\n"
"..3285254744\n"
"247551.62473\n"
"465287782175\n"
"3.285114.882\n"
"8724468.8.86\n"
"27651883.15.\n"
"444383...37.\n"
"3231.68.537.\n"
"82.5454.7.46\n") == 0);
free(board977087175);
board977087175 = NULL;
assert( gamma_move(board, 2, 10, 11) == 1 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 6, 2, 13) == 0 );
assert( gamma_move(board, 6, 9, 9) == 0 );
assert( gamma_move(board, 7, 16, 11) == 0 );


char* board635890719 = gamma_board(board);
assert( board635890719 != NULL );
assert( strcmp(board635890719, 
"4738.134732.\n"
"4.181...6727\n"
".73326616315\n"
".77127.3184.\n"
"62.33778737.\n"
"151745281.24\n"
"387241315842\n"
"726424.7.257\n"
"..3285254744\n"
"247551.62473\n"
"465287782175\n"
"3.285114.882\n"
"8724468.8.86\n"
"27651883.15.\n"
"444383...37.\n"
"3231.68.537.\n"
"82.5454.7.46\n") == 0);
free(board635890719);
board635890719 = NULL;
assert( gamma_move(board, 8, 3, 8) == 0 );
assert( gamma_free_fields(board, 8) == 34 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 5, 5, 15) == 1 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 7, 6, 8) == 0 );
assert( gamma_move(board, 7, 5, 0) == 0 );
assert( gamma_move(board, 8, 7, 9) == 0 );
assert( gamma_move(board, 8, 9, 9) == 0 );


gamma_delete(board);

    return 0;
}
