#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 104688723
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 15, 7, 40);
assert( board != NULL );


assert( gamma_move(board, 1, 12, 3) == 1 );
assert( gamma_move(board, 1, 3, 4) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 8) == 1 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 4, 1) == 1 );


char* board506528585 = gamma_board(board);
assert( board506528585 != NULL );
assert( strcmp(board506528585, 
"2................\n"
".................\n"
".................\n"
".................\n"
".................\n"
".................\n"
"..........2......\n"
".................\n"
".................\n"
".................\n"
"...1.............\n"
"............1....\n"
".................\n"
"....3............\n"
".................\n") == 0);
free(board506528585);
board506528585 = NULL;
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 4, 14, 3) == 1 );
assert( gamma_move(board, 5, 5, 10) == 1 );
assert( gamma_move(board, 5, 4, 8) == 1 );
assert( gamma_move(board, 6, 0, 15) == 0 );


char* board963442023 = gamma_board(board);
assert( board963442023 != NULL );
assert( strcmp(board963442023, 
"2................\n"
".................\n"
".................\n"
".................\n"
".....5...........\n"
".................\n"
"....5.....2......\n"
"..4..............\n"
".................\n"
".................\n"
"...1.............\n"
"............1.4..\n"
".................\n"
"....3............\n"
".................\n") == 0);
free(board963442023);
board963442023 = NULL;
assert( gamma_move(board, 7, 14, 14) == 1 );
assert( gamma_move(board, 1, 13, 15) == 0 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_free_fields(board, 1) == 244 );


char* board243528976 = gamma_board(board);
assert( board243528976 != NULL );
assert( strcmp(board243528976, 
"2.............7..\n"
".................\n"
".................\n"
".................\n"
".....5...........\n"
".................\n"
"....5.....2......\n"
"1.4..............\n"
".................\n"
".................\n"
"...1.............\n"
"............1.4..\n"
".................\n"
"....3............\n"
".................\n") == 0);
free(board243528976);
board243528976 = NULL;
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 4) == 1 );
assert( gamma_move(board, 4, 3, 1) == 1 );
assert( gamma_move(board, 5, 9, 7) == 1 );
assert( gamma_move(board, 5, 7, 9) == 1 );
assert( gamma_free_fields(board, 5) == 237 );
assert( gamma_move(board, 6, 4, 0) == 1 );
assert( gamma_move(board, 7, 5, 16) == 0 );
assert( gamma_move(board, 7, 13, 9) == 1 );
assert( gamma_move(board, 1, 5, 0) == 1 );


char* board938876926 = gamma_board(board);
assert( board938876926 != NULL );
assert( strcmp(board938876926, 
"2.............7..\n"
".................\n"
".................\n"
".................\n"
".....5...........\n"
".......5.....7...\n"
"....5.....2......\n"
"1.4......5.......\n"
".................\n"
"...2....2........\n"
"...1......3...4..\n"
"............1.4..\n"
".................\n"
"...43............\n"
"....61...........\n") == 0);
free(board938876926);
board938876926 = NULL;
assert( gamma_move(board, 2, 14, 6) == 1 );
assert( gamma_move(board, 3, 13, 3) == 1 );


char* board514655086 = gamma_board(board);
assert( board514655086 != NULL );
assert( strcmp(board514655086, 
"2.............7..\n"
".................\n"
".................\n"
".................\n"
".....5...........\n"
".......5.....7...\n"
"....5.....2......\n"
"1.4......5.......\n"
"..............2..\n"
"...2....2........\n"
"...1......3...4..\n"
"............134..\n"
".................\n"
"...43............\n"
"....61...........\n") == 0);
free(board514655086);
board514655086 = NULL;
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 4, 7, 4) == 1 );
assert( gamma_move(board, 5, 8, 7) == 1 );
assert( gamma_move(board, 5, 3, 7) == 1 );
assert( gamma_move(board, 6, 4, 13) == 1 );
assert( gamma_busy_fields(board, 7) == 2 );
assert( gamma_move(board, 1, 2, 12) == 1 );
assert( gamma_move(board, 2, 4, 4) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 3, 9, 15) == 0 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 5, 14, 12) == 1 );
assert( gamma_move(board, 6, 2, 1) == 1 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_move(board, 7, 3, 11) == 1 );
assert( gamma_move(board, 1, 14, 12) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 3, 5, 14) == 1 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_move(board, 5, 2, 8) == 1 );
assert( gamma_move(board, 5, 8, 3) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 5, 9) == 1 );
assert( gamma_move(board, 7, 0, 2) == 1 );
assert( gamma_golden_move(board, 7, 13, 4) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 2, 16, 8) == 1 );
assert( gamma_free_fields(board, 3) == 211 );
assert( gamma_move(board, 4, 12, 1) == 1 );
assert( gamma_move(board, 5, 3, 1) == 0 );
assert( gamma_move(board, 5, 11, 1) == 1 );
assert( gamma_busy_fields(board, 5) == 10 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 14, 1) == 1 );
assert( gamma_move(board, 6, 13, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 5 );
assert( gamma_move(board, 7, 11, 6) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 10, 9) == 1 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_move(board, 4, 12, 16) == 0 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_move(board, 6, 6, 13) == 1 );
assert( gamma_move(board, 7, 5, 2) == 1 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 1, 8, 10) == 1 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_move(board, 2, 15, 4) == 1 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 4, 13, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_golden_move(board, 4, 7, 9) == 1 );
assert( gamma_move(board, 5, 7, 14) == 1 );
assert( gamma_move(board, 5, 10, 5) == 1 );
assert( gamma_free_fields(board, 5) == 193 );
assert( gamma_move(board, 7, 13, 10) == 1 );
assert( gamma_move(board, 1, 8, 14) == 1 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 2, 11, 2) == 1 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 4, 7, 10) == 1 );
assert( gamma_free_fields(board, 4) == 188 );
assert( gamma_move(board, 5, 6, 16) == 0 );
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_move(board, 6, 14, 12) == 0 );
assert( gamma_move(board, 6, 5, 8) == 0 );


char* board182733880 = gamma_board(board);
assert( board182733880 != NULL );
assert( strcmp(board182733880, 
"2....3.51.....7..\n"
"...26.6..........\n"
"1.1..2........5..\n"
"...7.............\n"
".....5.41....7...\n"
"..4..6.4.41.27...\n"
"..5.53....2.....2\n"
"1.45...255.......\n"
".3.........7..2..\n"
"...2....2.5......\n"
"3..12..4..3...42.\n"
"......3.5...134..\n"
"7....7.....2.4...\n"
"..643...3..54.6..\n"
"....61.....1.....\n") == 0);
free(board182733880);
board182733880 = NULL;
assert( gamma_move(board, 7, 7, 11) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_free_fields(board, 2) == 185 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 3, 11, 10) == 1 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 12, 11) == 1 );
assert( gamma_move(board, 5, 2, 0) == 1 );
assert( gamma_move(board, 6, 6, 8) == 1 );
assert( gamma_move(board, 7, 13, 8) == 1 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_free_fields(board, 7) == 179 );
assert( gamma_move(board, 1, 15, 2) == 1 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 4, 12, 13) == 1 );
assert( gamma_move(board, 5, 16, 13) == 1 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 6, 9, 15) == 0 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 7, 12, 4) == 1 );
assert( gamma_move(board, 7, 7, 0) == 1 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_golden_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 4, 16, 7) == 1 );
assert( gamma_move(board, 5, 5, 11) == 1 );
assert( gamma_move(board, 5, 9, 2) == 1 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 0, 3) == 0 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 9, 7) == 1 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_free_fields(board, 3) == 169 );


char* board374934617 = gamma_board(board);
assert( board374934617 != NULL );
assert( strcmp(board374934617, 
"2....3.51.....7..\n"
"...26.6.....4...5\n"
"1.1..2........5..\n"
"...7.5.7....5....\n"
".....3.41..3.7...\n"
"..4..6.4.41.27...\n"
"..5.536...2..7..2\n"
"1.45...252......4\n"
".3.......2.7..2..\n"
"...2....2.5......\n"
"3..12..4..3.7.42.\n"
"4..1..3.5...134..\n"
"7.2..7...5.2.4.1.\n"
"..643...3..54.6..\n"
"1.5.61.7...1.....\n") == 0);
free(board374934617);
board374934617 = NULL;
assert( gamma_move(board, 4, 11, 14) == 1 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 9, 3) == 1 );
assert( gamma_move(board, 5, 10, 2) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board767779340 = gamma_board(board);
assert( board767779340 != NULL );
assert( strcmp(board767779340, 
"2....3.51..4..7..\n"
"...26.6.....4...5\n"
"1.1..2........5..\n"
"...7.5.74...5....\n"
".....3.41..3.7...\n"
"..4..6.4.41.27...\n"
"..5.536...2..7..2\n"
"1.45...252......4\n"
".3.......2.7..2..\n"
"...2....2.5......\n"
"3..12..4..3.7.42.\n"
"4..1..3.55..134..\n"
"7.2..7...552.4.1.\n"
"..643...3..54.6..\n"
"1.5.61.7...1.....\n") == 0);
free(board767779340);
board767779340 = NULL;
assert( gamma_move(board, 6, 6, 5) == 1 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_free_fields(board, 7) == 164 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_move(board, 5, 0, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 6, 7, 13) == 1 );
assert( gamma_move(board, 7, 13, 0) == 1 );
assert( gamma_move(board, 1, 15, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 3, 15, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 1, 9, 6) == 0 );
assert( gamma_move(board, 2, 15, 14) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 10, 3) == 1 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 4, 11, 15) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 7, 12, 15) == 0 );
assert( gamma_move(board, 7, 5, 6) == 1 );
assert( gamma_free_fields(board, 7) == 154 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_free_fields(board, 2) == 153 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_move(board, 3, 16, 3) == 1 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_move(board, 7, 9, 15) == 0 );
assert( gamma_move(board, 7, 16, 5) == 1 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 9, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 8, 11) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 5, 8, 2) == 1 );
assert( gamma_move(board, 6, 12, 10) == 1 );
assert( gamma_move(board, 6, 9, 7) == 0 );
assert( gamma_free_fields(board, 6) == 145 );
assert( gamma_move(board, 7, 14, 3) == 0 );
assert( gamma_move(board, 7, 2, 2) == 0 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_free_fields(board, 3) == 144 );
assert( gamma_move(board, 4, 14, 13) == 1 );
assert( gamma_free_fields(board, 4) == 143 );
assert( gamma_move(board, 5, 1, 10) == 1 );
assert( gamma_move(board, 5, 3, 14) == 1 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_move(board, 6, 16, 12) == 1 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_move(board, 1, 11, 16) == 0 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_free_fields(board, 1) == 139 );
assert( gamma_golden_move(board, 1, 8, 2) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 2, 16, 8) == 0 );
assert( gamma_move(board, 3, 7, 12) == 1 );
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 4, 6, 7) == 1 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 5, 14, 3) == 0 );
assert( gamma_move(board, 6, 13, 13) == 1 );
assert( gamma_move(board, 6, 6, 6) == 1 );
assert( gamma_move(board, 7, 12, 14) == 1 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );


char* board883898808 = gamma_board(board);
assert( board883898808 != NULL );
assert( strcmp(board883898808, 
"2..5.3351..47.73.\n"
"...26.66....464.5\n"
"1.1..2.3......5.6\n"
"..37.5.74...5....\n"
".53..3.41..367...\n"
"4.4..6.4241.27...\n"
".55.536.4.2..7.12\n"
"1.45..4252......4\n"
"23...76..2.7..2..\n"
".2.2..642.5.....7\n"
"3..12..4.13.7.42.\n"
"41.1..3.553.134.3\n"
"7.2..7..1552.4.1.\n"
"..643...3..54.6..\n"
"1.5.61.73.11.7...\n") == 0);
free(board883898808);
board883898808 = NULL;
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 12, 15) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );
assert( gamma_busy_fields(board, 5) == 19 );
assert( gamma_free_fields(board, 5) == 131 );
assert( gamma_move(board, 6, 13, 3) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board526892202 = gamma_board(board);
assert( board526892202 != NULL );
assert( strcmp(board526892202, 
"2..5.3351..47.73.\n"
"...26.66....464.5\n"
"1.1..2.3......5.6\n"
"..37.5.74...5....\n"
".53..3.41..367...\n"
"4.4..6.4241.27...\n"
".55.536.4.2..7.12\n"
"1.45..4252......4\n"
"23...76..2.7..2..\n"
".2.2..642.5.....7\n"
"3..12..4.13.7.42.\n"
"41.1..3.553.134.3\n"
"7.2..7..1552.4.1.\n"
"..643...3..54.6..\n"
"1.5.61.73.11.7...\n") == 0);
free(board526892202);
board526892202 = NULL;
assert( gamma_move(board, 7, 6, 2) == 1 );
assert( gamma_golden_move(board, 7, 1, 3) == 1 );
assert( gamma_move(board, 1, 3, 6) == 1 );
assert( gamma_move(board, 2, 1, 13) == 1 );
assert( gamma_free_fields(board, 2) == 128 );
assert( gamma_move(board, 3, 12, 8) == 1 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 15, 8) == 0 );
assert( gamma_move(board, 5, 4, 4) == 0 );
assert( gamma_move(board, 6, 4, 6) == 1 );
assert( gamma_move(board, 7, 1, 11) == 1 );
assert( gamma_move(board, 1, 12, 10) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 15, 3) == 1 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_move(board, 4, 12, 13) == 0 );
assert( gamma_move(board, 4, 16, 2) == 1 );
assert( gamma_move(board, 5, 11, 4) == 1 );
assert( gamma_move(board, 5, 11, 5) == 1 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 6, 16, 1) == 1 );
assert( gamma_free_fields(board, 6) == 119 );
assert( gamma_move(board, 7, 1, 4) == 1 );
assert( gamma_move(board, 1, 15, 5) == 1 );
assert( gamma_move(board, 1, 4, 14) == 1 );
assert( gamma_move(board, 2, 2, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_free_fields(board, 5) == 115 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 8) == 0 );
assert( gamma_move(board, 6, 14, 8) == 1 );
assert( gamma_golden_move(board, 6, 12, 7) == 0 );


char* board238536843 = gamma_board(board);
assert( board238536843 != NULL );
assert( strcmp(board238536843, 
"2..513351..47.73.\n"
".2.26.66....464.5\n"
"1.1..2.3......5.6\n"
".737.5.74...5....\n"
".53..3.41..367...\n"
"4.4..6.4241327...\n"
".55.536.4.2.37612\n"
"1.45..4252......4\n"
"23.1676..2.7..2..\n"
".2.2..642.55...17\n"
"37.12..4.1357.42.\n"
"4721..3.553.13423\n"
"7.2..77.1552.4.14\n"
"..643...3..54.6.6\n"
"1.5.61.73.11.7...\n") == 0);
free(board238536843);
board238536843 = NULL;
assert( gamma_move(board, 7, 0, 16) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_move(board, 4, 14, 2) == 1 );
assert( gamma_move(board, 5, 10, 10) == 1 );


char* board283546425 = gamma_board(board);
assert( board283546425 != NULL );
assert( strcmp(board283546425, 
"2..513351..47.73.\n"
".2.26.66....464.5\n"
"1.1..2.3......5.6\n"
".737.5.74...5....\n"
".53..3.41.5367...\n"
"4.4..6.4241327...\n"
".55.536.4.2.37612\n"
"1.45..4252......4\n"
"23.1676..2.7..2..\n"
".2.2..642.55...17\n"
"37.12..4.1357.42.\n"
"4721..3.553.13423\n"
"7.2..77.1552.4414\n"
"..643...3..54.6.6\n"
"1.5.61.73.11.7...\n") == 0);
free(board283546425);
board283546425 = NULL;
assert( gamma_move(board, 6, 1, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_move(board, 7, 5, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 19 );


char* board455491139 = gamma_board(board);
assert( board455491139 != NULL );
assert( strcmp(board455491139, 
"2..513351..47.73.\n"
".2.26.66....464.5\n"
"1.1..2.3......5.6\n"
".737.5.74...5....\n"
".53..3.41.5367...\n"
"4.4..6.4241327...\n"
".55.536.4.2.37612\n"
"1.45..4252......4\n"
"23.1676..2.7..2..\n"
".2.2..642.55...17\n"
"37.12..4.1357.42.\n"
"4721..3.553.13423\n"
"7.2..77.1552.4414\n"
"..643...3..54.6.6\n"
"1.5.61.73.11.7...\n") == 0);
free(board455491139);
board455491139 = NULL;
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_free_fields(board, 3) == 112 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_free_fields(board, 4) == 112 );
assert( gamma_move(board, 5, 14, 7) == 1 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_move(board, 7, 1, 0) == 1 );
assert( gamma_move(board, 7, 5, 3) == 1 );
assert( gamma_move(board, 1, 7, 1) == 1 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 4, 12, 12) == 1 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 5, 6, 12) == 1 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 6, 2, 14) == 1 );
assert( gamma_move(board, 7, 4, 16) == 0 );


char* board722444331 = gamma_board(board);
assert( board722444331 != NULL );
assert( strcmp(board722444331, 
"2.6513351..47.73.\n"
".2.26.66....464.5\n"
"1.1..253....4.5.6\n"
".737.5.74...5....\n"
".53..3.41.5367...\n"
"4.4..6.4241327...\n"
".55.536.4.2.37612\n"
"1.45..4252....5.4\n"
"23.1676..237..2..\n"
".2.2..642.55...17\n"
"37.12..4.1357.42.\n"
"4721.73.553.13423\n"
"7.2..77.1552.4414\n"
"..643..13..54.6.6\n"
"175.61.73.11.7...\n") == 0);
free(board722444331);
board722444331 = NULL;
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 15, 12) == 1 );
assert( gamma_move(board, 3, 16, 8) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 5, 11, 11) == 1 );
assert( gamma_move(board, 5, 5, 13) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 12, 0) == 1 );
assert( gamma_move(board, 6, 0, 10) == 1 );
assert( gamma_move(board, 7, 7, 8) == 1 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 5, 9, 1) == 1 );
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_move(board, 6, 13, 5) == 1 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 7, 0, 15) == 0 );
assert( gamma_busy_fields(board, 7) == 22 );


char* board984502021 = gamma_board(board);
assert( board984502021 != NULL );
assert( strcmp(board984502021, 
"2.6513351..47.73.\n"
".2.26566....464.5\n"
"1.1..253....4.536\n"
".737.5.74..55....\n"
"653..3.41.5367...\n"
"4.4..6.4241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.1676..237..2..\n"
".2.2..642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721.73.553.13423\n"
"7.2..77.1552.4414\n"
"..643..135.54.6.6\n"
"175.61.73.1167...\n") == 0);
free(board984502021);
board984502021 = NULL;
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 4, 14) == 0 );
assert( gamma_move(board, 3, 16, 14) == 1 );
assert( gamma_move(board, 3, 10, 11) == 1 );


char* board237420117 = gamma_board(board);
assert( board237420117 != NULL );
assert( strcmp(board237420117, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..253....4.536\n"
".737.5.74.355....\n"
"653..3.41.5367...\n"
"4.4..6.4241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.1676..237..2..\n"
".2.2..642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721.73.553.13423\n"
"7.2..77.1552.4414\n"
"..643..135.54.6.6\n"
"175.61.73.1167...\n") == 0);
free(board237420117);
board237420117 = NULL;
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 4, 10, 1) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 6, 6, 8) == 0 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_move(board, 7, 11, 15) == 0 );
assert( gamma_move(board, 7, 1, 6) == 0 );


char* board522434383 = gamma_board(board);
assert( board522434383 != NULL );
assert( strcmp(board522434383, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..253....4.536\n"
".737.5.74.355....\n"
"653..3.41.5367...\n"
"4.4..6.4241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.1676..237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721.73.553.13423\n"
"7.2..77.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board522434383);
board522434383 = NULL;
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 3, 16, 5) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 27 );
assert( gamma_move(board, 6, 16, 12) == 0 );
assert( gamma_move(board, 7, 6, 13) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_move(board, 6, 7, 11) == 0 );


char* board641393503 = gamma_board(board);
assert( board641393503 != NULL );
assert( strcmp(board641393503, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..253....4.536\n"
".737.5.74.355....\n"
"653..3.41.5367...\n"
"4.4..6.4241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.1676..237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721.73.553.13423\n"
"7.2..77.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board641393503);
board641393503 = NULL;
assert( gamma_move(board, 7, 10, 15) == 0 );
assert( gamma_move(board, 7, 10, 0) == 0 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 2, 12, 12) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 5, 12, 12) == 0 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_move(board, 7, 13, 0) == 0 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_move(board, 4, 0, 14) == 0 );


char* board869145356 = gamma_board(board);
assert( board869145356 != NULL );
assert( strcmp(board869145356, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..2534...4.536\n"
".737.5.74.355....\n"
"653..3.41.5367...\n"
"4.4..6.4241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.1676..237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721.73.553.13423\n"
"7.2.177.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board869145356);
board869145356 = NULL;
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 12, 1) == 0 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_move(board, 7, 11, 4) == 0 );
assert( gamma_move(board, 7, 12, 3) == 0 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_golden_move(board, 2, 12, 14) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 5, 16, 11) == 1 );
assert( gamma_free_fields(board, 5) == 87 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 16) == 0 );
assert( gamma_move(board, 4, 7, 6) == 1 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 5, 8, 14) == 0 );


char* board772990022 = gamma_board(board);
assert( board772990022 != NULL );
assert( strcmp(board772990022, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..2534...4.536\n"
".737.5.74.355...5\n"
"653..3.41.5367...\n"
"4.41.644241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.16764.237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721273.553.13423\n"
"7.2.177.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board772990022);
board772990022 = NULL;


char* board868376933 = gamma_board(board);
assert( board868376933 != NULL );
assert( strcmp(board868376933, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..2534...4.536\n"
".737.5.74.355...5\n"
"653..3.41.5367...\n"
"4.41.644241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.16764.237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721273.553.13423\n"
"7.2.177.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board868376933);
board868376933 = NULL;
assert( gamma_free_fields(board, 7) == 85 );
assert( gamma_golden_move(board, 7, 9, 9) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 13, 11) == 1 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 4, 12, 10) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );
assert( gamma_move(board, 5, 4, 9) == 1 );
assert( gamma_move(board, 6, 0, 9) == 0 );
assert( gamma_move(board, 7, 1, 5) == 0 );
assert( gamma_move(board, 7, 10, 10) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );


char* board249269218 = gamma_board(board);
assert( board249269218 != NULL );
assert( strcmp(board249269218, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..2534...4.536\n"
".737.5.74.3553..5\n"
"6533.3.41.5367...\n"
"4.415644241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.16764.237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721273.553.13423\n"
"7.2.177.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board249269218);
board249269218 = NULL;
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_free_fields(board, 2) == 82 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 4, 10, 15) == 0 );
assert( gamma_free_fields(board, 4) == 82 );
assert( gamma_move(board, 5, 6, 12) == 0 );
assert( gamma_free_fields(board, 5) == 82 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 6, 4) == 0 );
assert( gamma_move(board, 6, 2, 7) == 0 );


char* board181784605 = gamma_board(board);
assert( board181784605 != NULL );
assert( strcmp(board181784605, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..2534...4.536\n"
".737.5.74.3553..5\n"
"6533.3.41.5367...\n"
"4.415644241327...\n"
".55.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.16764.237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721273.553.13423\n"
"7.2.177.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board181784605);
board181784605 = NULL;
assert( gamma_move(board, 7, 12, 13) == 0 );
assert( gamma_move(board, 7, 10, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 22 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_move(board, 3, 16, 13) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 16, 10) == 1 );
assert( gamma_free_fields(board, 4) == 80 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 5, 16, 9) == 1 );
assert( gamma_move(board, 6, 12, 4) == 0 );
assert( gamma_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 7, 14, 11) == 1 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );


char* board384644966 = gamma_board(board);
assert( board384644966 != NULL );
assert( strcmp(board384644966, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1..2534...4.536\n"
".737.5.74.35537.5\n"
"6533.3.41.5367..4\n"
"4.415644241327..5\n"
"155.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.16764.237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721273.553.13423\n"
"7.2.177.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board384644966);
board384644966 = NULL;
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 4, 13, 15) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 5, 4, 12) == 1 );
assert( gamma_move(board, 6, 11, 12) == 1 );
assert( gamma_move(board, 6, 1, 8) == 0 );
assert( gamma_move(board, 7, 4, 6) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );


char* board752800263 = gamma_board(board);
assert( board752800263 != NULL );
assert( strcmp(board752800263, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1.52534..64.536\n"
".737.5.74.35537.5\n"
"6533.3.41.5367..4\n"
"4.415644241327..5\n"
"155.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.16764.237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.42.\n"
"4721273.553.13423\n"
"7.2.177.1552.4414\n"
"..643..135454.6.6\n"
"175.61.73.1167...\n") == 0);
free(board752800263);
board752800263 = NULL;
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_move(board, 1, 16, 0) == 1 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 2, 14, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 3, 12, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 4, 16) == 0 );
assert( gamma_move(board, 5, 16, 4) == 1 );
assert( gamma_move(board, 6, 13, 2) == 0 );
assert( gamma_move(board, 6, 13, 13) == 0 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );


char* board594492787 = gamma_board(board);
assert( board594492787 != NULL );
assert( strcmp(board594492787, 
"2.6513351..47.733\n"
".2.26566....464.5\n"
"1.1.52534..64.536\n"
".737.5.74.35537.5\n"
"6533.3.41.5367..4\n"
"4.415644241327..5\n"
"155.53674.2.37612\n"
"1.45..4252....5.4\n"
"23.16764.237..2..\n"
".2.24.642.55.6.17\n"
"37.12..4.1357.425\n"
"4721273.553.13423\n"
"7.2.177.155234414\n"
"..643..135454.6.6\n"
"175.61.73.1167..1\n") == 0);
free(board594492787);
board594492787 = NULL;
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 15, 9) == 1 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 6, 3, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_move(board, 7, 9, 14) == 1 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 15, 1) == 1 );
assert( gamma_free_fields(board, 2) == 69 );
assert( gamma_move(board, 3, 10, 14) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 9, 5) == 1 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 33 );
assert( gamma_move(board, 6, 11, 0) == 0 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_move(board, 7, 3, 7) == 0 );
assert( gamma_move(board, 7, 3, 0) == 1 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_move(board, 1, 11, 14) == 0 );
assert( gamma_free_fields(board, 1) == 65 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_free_fields(board, 2) == 65 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_move(board, 3, 15, 7) == 1 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_golden_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 7, 1, 13) == 0 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_move(board, 5, 16, 7) == 0 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_free_fields(board, 5) == 63 );
assert( gamma_move(board, 6, 10, 9) == 0 );
assert( gamma_move(board, 7, 14, 13) == 0 );
assert( gamma_move(board, 7, 6, 0) == 1 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_free_fields(board, 1) == 61 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 6, 8, 11) == 0 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_busy_fields(board, 7) == 26 );
assert( gamma_golden_possible(board, 7) == 0 );


char* board445470528 = gamma_board(board);
assert( board445470528 != NULL );
assert( strcmp(board445470528, 
"2.65133517347.733\n"
".2.26566....464.5\n"
"111.52534..64.536\n"
".737.5.74.35537.5\n"
"653313.41.5367..4\n"
"4.415644241327.35\n"
"155.53674.2.37612\n"
"1.45..4252....534\n"
"23.16764.237..2..\n"
".2424.642555.6.17\n"
"37.12..4.1357.425\n"
"4721273.553.13423\n"
"7.24177.155234414\n"
"..643..135454.626\n"
"175761773.1167..1\n") == 0);
free(board445470528);
board445470528 = NULL;
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 7, 6) == 0 );
assert( gamma_free_fields(board, 6) == 61 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_free_fields(board, 3) == 61 );
assert( gamma_golden_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_move(board, 4, 16, 5) == 0 );
assert( gamma_move(board, 5, 3, 11) == 0 );
assert( gamma_move(board, 6, 13, 10) == 0 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 26 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 1, 15, 13) == 1 );
assert( gamma_free_fields(board, 1) == 60 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 6, 6, 16) == 0 );
assert( gamma_move(board, 6, 1, 7) == 1 );
assert( gamma_busy_fields(board, 6) == 22 );
assert( gamma_move(board, 7, 2, 4) == 1 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 1, 16, 14) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 11, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 6, 4, 14) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 6, 12) == 0 );
assert( gamma_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 2, 12, 7) == 1 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 5, 2, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 11, 6) == 0 );
assert( gamma_move(board, 6, 9, 10) == 0 );
assert( gamma_move(board, 7, 6, 15) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 4, 5, 12) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 5, 14, 12) == 0 );
assert( gamma_move(board, 6, 7, 10) == 0 );
assert( gamma_move(board, 6, 5, 4) == 1 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 7, 7, 5) == 0 );
assert( gamma_move(board, 1, 12, 12) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_free_fields(board, 4) == 53 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 5, 8, 3) == 0 );
assert( gamma_move(board, 6, 4, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board905464165 = gamma_board(board);
assert( board905464165 != NULL );
assert( strcmp(board905464165, 
"2.65133517347.733\n"
".2.26566....46415\n"
"111.52534..64.536\n"
".737.5.74.35537.5\n"
"65331324135367..4\n"
"4.415644241327.35\n"
"155.5367412.37612\n"
"1645..4252..2.534\n"
"23.16764.237..2..\n"
".2424.642555.6.17\n"
"377126.4.1357.425\n"
"4721273.553.13423\n"
"7.24177.155234414\n"
"..643..135454.626\n"
"175761773.1167..1\n") == 0);
free(board905464165);
board905464165 = NULL;
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 5, 6, 16) == 0 );
assert( gamma_move(board, 5, 13, 1) == 1 );
assert( gamma_move(board, 6, 12, 3) == 0 );
assert( gamma_move(board, 7, 2, 13) == 1 );
assert( gamma_move(board, 7, 15, 2) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 4, 11, 11) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 6, 5, 14) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 7, 6, 2) == 0 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 6, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_golden_move(board, 2, 5, 1) == 0 );


char* board164484045 = gamma_board(board);
assert( board164484045 != NULL );
assert( strcmp(board164484045, 
"2.65133517347.733\n"
".2726566....46415\n"
"111.52534..64.536\n"
".737.5.74.35537.5\n"
"65331324135367..4\n"
"4.415644241327.35\n"
"155.5367412.37612\n"
"1645..4252..2.534\n"
"23.16764.237..2..\n"
".2424.642555.6.17\n"
"377126.4.1357.425\n"
"4721273.553.13423\n"
"7.24177.155234414\n"
"..643..1354545626\n"
"175761773.1167..1\n") == 0);
free(board164484045);
board164484045 = NULL;
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );


char* board598560898 = gamma_board(board);
assert( board598560898 != NULL );
assert( strcmp(board598560898, 
"2.65133517347.733\n"
".2726566....46415\n"
"111.52534..64.536\n"
".737.5.74.35537.5\n"
"65331324135367..4\n"
"4.415644241327.35\n"
"155.5367412.37612\n"
"1645..4252..2.534\n"
"23.16764.237..2..\n"
".2424.642555.6.17\n"
"377126.4.1357.425\n"
"4721273.553.13423\n"
"7.24177.155234414\n"
"..643..1354545626\n"
"175761773.1167..1\n") == 0);
free(board598560898);
board598560898 = NULL;
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board780956213 = gamma_board(board);
assert( board780956213 != NULL );
assert( strcmp(board780956213, 
"2.65133517347.733\n"
".2726566....46415\n"
"111.52534..64.536\n"
".737.5.74.35537.5\n"
"65331324135367..4\n"
"4.415644241327.35\n"
"155.5367412.37612\n"
"1645..4252..2.534\n"
"23.16764.237..2..\n"
".2424.642555.6.17\n"
"377126.4.1357.425\n"
"4721273.553.13423\n"
"7.24177.155234414\n"
"..643..1354545626\n"
"175761773.1167..1\n") == 0);
free(board780956213);
board780956213 = NULL;
assert( gamma_move(board, 6, 16, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_free_fields(board, 7) == 51 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 4, 1, 1) == 1 );
assert( gamma_move(board, 5, 10, 14) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 6, 15, 10) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 2) == 1 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_free_fields(board, 1) == 48 );
assert( gamma_golden_move(board, 1, 2, 12) == 0 );


char* board838835717 = gamma_board(board);
assert( board838835717 != NULL );
assert( strcmp(board838835717, 
"2.65133517347.733\n"
".2726566....46415\n"
"111.52534..64.536\n"
".737.5.74.35537.5\n"
"65331324135367.64\n"
"4.415644241327.35\n"
"155.5367412.37612\n"
"1645..4252..2.534\n"
"23.16764.237..2..\n"
".2424.642555.6.17\n"
"377126.4.1357.425\n"
"4721273.553.13423\n"
"7.241777155234414\n"
".4643..1354545626\n"
"175761773.1167..1\n") == 0);
free(board838835717);
board838835717 = NULL;
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 3, 10, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 32 );
assert( gamma_free_fields(board, 3) == 48 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 5, 11, 11) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 7, 1, 6) == 0 );
assert( gamma_move(board, 1, 5, 5) == 1 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 8, 6) == 1 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 10, 14) == 0 );
assert( gamma_move(board, 7, 7, 5) == 0 );
assert( gamma_move(board, 7, 15, 12) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 5, 10, 14) == 0 );
assert( gamma_move(board, 6, 16, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 24 );
assert( gamma_move(board, 7, 13, 0) == 0 );
assert( gamma_move(board, 1, 1, 14) == 1 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 4, 6, 4) == 1 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 6, 10, 14) == 0 );
assert( gamma_move(board, 7, 8, 2) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_golden_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 5, 12, 5) == 1 );
assert( gamma_move(board, 6, 13, 14) == 1 );
assert( gamma_move(board, 6, 15, 0) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 11, 15) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_move(board, 6, 13, 10) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 26 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board268088944 = gamma_board(board);
assert( board268088944 != NULL );
assert( strcmp(board268088944, 
"21651335173476733\n"
".2726566....46415\n"
"111.52534..64.536\n"
".737.5.74.35537.5\n"
"65331324135367.64\n"
"4.415644241327.35\n"
"15535367412.37612\n"
"1645..4252..2.534\n"
"23.167643237..2..\n"
".2424164255556.17\n"
"37712644.1357.425\n"
"4721273.553.13423\n"
"7.241777155234414\n"
".4643..1354545626\n"
"175761773.1167.61\n") == 0);
free(board268088944);
board268088944 = NULL;
assert( gamma_move(board, 7, 8, 2) == 0 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 2, 12, 12) == 0 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 35 );
assert( gamma_move(board, 6, 8, 11) == 0 );
assert( gamma_move(board, 6, 10, 13) == 1 );
assert( gamma_free_fields(board, 6) == 39 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_free_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_free_fields(board, 4) == 39 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_busy_fields(board, 4) == 34 );
assert( gamma_move(board, 5, 13, 11) == 0 );
assert( gamma_move(board, 5, 2, 1) == 0 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 6, 13, 8) == 0 );
assert( gamma_move(board, 7, 15, 0) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_free_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_free_fields(board, 5) == 38 );
assert( gamma_move(board, 6, 3, 7) == 0 );
assert( gamma_move(board, 6, 5, 12) == 0 );
assert( gamma_free_fields(board, 6) == 38 );
assert( gamma_golden_move(board, 6, 6, 3) == 1 );
assert( gamma_move(board, 7, 4, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_free_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 5, 9) == 0 );
assert( gamma_move(board, 7, 6, 14) == 0 );
assert( gamma_move(board, 7, 10, 7) == 1 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 6, 6, 12) == 0 );
assert( gamma_move(board, 7, 8, 11) == 0 );
assert( gamma_busy_fields(board, 7) == 30 );
assert( gamma_move(board, 1, 4, 13) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 35 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 6, 13, 14) == 0 );
assert( gamma_busy_fields(board, 7) == 30 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_free_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 5, 14, 8) == 0 );
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 7, 10, 2) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 2, 4, 7) == 1 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 16, 3) == 0 );
assert( gamma_move(board, 5, 6, 16) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 6, 14, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_golden_possible(board, 6) == 0 );


gamma_delete(board);

    return 0;
}
