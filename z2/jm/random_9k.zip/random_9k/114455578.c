#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 114455578
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(16, 17, 5, 48);
assert( board != NULL );


assert( gamma_move(board, 1, 15, 4) == 1 );
assert( gamma_move(board, 2, 12, 8) == 1 );
assert( gamma_move(board, 3, 4, 16) == 1 );
assert( gamma_move(board, 4, 5, 14) == 1 );
assert( gamma_move(board, 5, 4, 4) == 1 );
assert( gamma_move(board, 5, 6, 15) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 1, 2, 15) == 1 );
assert( gamma_move(board, 3, 15, 0) == 1 );
assert( gamma_move(board, 4, 12, 12) == 1 );
assert( gamma_move(board, 4, 14, 9) == 1 );
assert( gamma_move(board, 5, 6, 2) == 1 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 2, 13, 5) == 1 );
assert( gamma_move(board, 2, 13, 4) == 1 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_move(board, 4, 9, 7) == 1 );
assert( gamma_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 5, 7, 5) == 1 );
assert( gamma_move(board, 5, 8, 2) == 1 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 3, 10, 12) == 1 );
assert( gamma_move(board, 4, 0, 16) == 1 );
assert( gamma_free_fields(board, 5) == 251 );


char* board458953528 = gamma_board(board);
assert( board458953528 != NULL );
assert( strcmp(board458953528, 
"4...3...........\n"
"..1...5.........\n"
".....4..........\n"
"................\n"
"..........3.4...\n"
"................\n"
"................\n"
"..............4.\n"
".........3..2...\n"
".........4......\n"
"................\n"
".......5.....2..\n"
"....5........2.1\n"
".....1..........\n"
"......5.5.......\n"
"................\n"
"...3...........3\n") == 0);
free(board458953528);
board458953528 = NULL;
assert( gamma_move(board, 1, 15, 11) == 1 );
assert( gamma_move(board, 1, 3, 7) == 1 );
assert( gamma_move(board, 2, 13, 14) == 1 );
assert( gamma_free_fields(board, 2) == 248 );
assert( gamma_move(board, 3, 9, 13) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 16, 14) == 0 );
assert( gamma_move(board, 5, 11, 13) == 1 );
assert( gamma_move(board, 1, 13, 15) == 1 );
assert( gamma_move(board, 1, 13, 12) == 1 );
assert( gamma_move(board, 2, 13, 1) == 1 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 14, 1) == 1 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 5, 5, 15) == 1 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_free_fields(board, 1) == 237 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_move(board, 2, 4, 15) == 1 );
assert( gamma_golden_move(board, 2, 3, 5) == 0 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 8) == 1 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 13, 6) == 1 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 4, 1, 8) == 1 );
assert( gamma_move(board, 5, 2, 15) == 0 );
assert( gamma_free_fields(board, 5) == 229 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_move(board, 2, 9, 10) == 1 );
assert( gamma_golden_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 3, 11, 6) == 1 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 1, 11, 10) == 1 );


char* board974471588 = gamma_board(board);
assert( board974471588 != NULL );
assert( strcmp(board974471588, 
"4...3...........\n"
"..1.255......1..\n"
"1....4.......2..\n"
"133......3.5....\n"
"..........3.41..\n"
".......3.......1\n"
"3........2.1....\n"
"..............4.\n"
"54.......3..2...\n"
"...1.....4......\n"
"...........3.2..\n"
".......5...4.2..\n"
"...35........2.1\n"
"...1.1..........\n"
"......5.5.......\n"
".......4.2...24.\n"
"...3...........3\n") == 0);
free(board974471588);
board974471588 = NULL;
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_move(board, 2, 6, 16) == 1 );


char* board955644481 = gamma_board(board);
assert( board955644481 != NULL );
assert( strcmp(board955644481, 
"4...3.2.........\n"
"..1.255......1..\n"
"1....4.......2..\n"
"133......3.5....\n"
"..........3.41..\n"
".......3.......1\n"
"3........2.1....\n"
"..............4.\n"
"54.......3..2...\n"
"...1.....4......\n"
"....2......3.2..\n"
".......5...4.2..\n"
"...35........2.1\n"
"...1.1..........\n"
"......5.5.......\n"
".......4.2...24.\n"
"...3...........3\n") == 0);
free(board955644481);
board955644481 = NULL;
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 4, 3, 15) == 1 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 4, 9) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 16, 13) == 0 );
assert( gamma_move(board, 2, 14, 10) == 1 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_free_fields(board, 2) == 215 );
assert( gamma_move(board, 3, 6, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 2, 14) == 1 );
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_busy_fields(board, 5) == 10 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 1, 1, 16) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board910566946 = gamma_board(board);
assert( board910566946 != NULL );
assert( strcmp(board910566946, 
"41..3.2.........\n"
"..14255......1..\n"
"1.4..4.......2..\n"
"133......3.5....\n"
"..........3.41..\n"
".......3.......1\n"
"3........2.1..2.\n"
"....5.3.......4.\n"
"54.......3.32...\n"
"...1....34......\n"
"....2......3.2..\n"
".5.....5...4.2..\n"
"...35........2.1\n"
"...1.1..........\n"
"....1.5.5.......\n"
".......4.22..24.\n"
"...3...........3\n") == 0);
free(board910566946);
board910566946 = NULL;
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_move(board, 4, 3, 2) == 1 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 14, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 10) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 1, 5, 16) == 1 );
assert( gamma_move(board, 1, 8, 0) == 1 );
assert( gamma_free_fields(board, 1) == 202 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board421648441 = gamma_board(board);
assert( board421648441 != NULL );
assert( strcmp(board421648441, 
"41..312.........\n"
"..14255......1..\n"
"1.42.4.......2..\n"
"133......335....\n"
"..........3.41..\n"
".......3.......1\n"
"3.....4..2.1..2.\n"
"....5.3.......4.\n"
"54..2....3.32...\n"
"...1....34......\n"
".5..2......332..\n"
".5.....5...4.2..\n"
".3.35........2.1\n"
"...1.1..1.......\n"
"...41.5.5.......\n"
".....4.4.22..24.\n"
"...3....1.....33\n") == 0);
free(board421648441);
board421648441 = NULL;
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_move(board, 4, 10, 5) == 1 );
assert( gamma_move(board, 4, 9, 0) == 1 );
assert( gamma_move(board, 5, 0, 15) == 1 );
assert( gamma_free_fields(board, 5) == 193 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 3, 13, 10) == 1 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 5, 15, 14) == 1 );
assert( gamma_move(board, 1, 4, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 14, 14) == 1 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 16 );
assert( gamma_free_fields(board, 4) == 186 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_free_fields(board, 3) == 183 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 1, 8, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 12, 12) == 0 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_move(board, 5, 13, 12) == 0 );
assert( gamma_move(board, 1, 14, 11) == 1 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 3, 6, 15) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 5, 10, 7) == 1 );
assert( gamma_move(board, 5, 1, 15) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 2, 13, 16) == 1 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 4, 14, 14) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_free_fields(board, 1) == 173 );


char* board533366424 = gamma_board(board);
assert( board533366424 != NULL );
assert( strcmp(board533366424, 
"41..312......2..\n"
"5514255......1..\n"
"1.42.4.......235\n"
"133......335....\n"
".3..1.....3.41..\n"
".......3.3....11\n"
"3.....4.12.1.32.\n"
"....5.3..3..2.4.\n"
"54..2....3.32...\n"
"1.21....345.....\n"
".5..2......332..\n"
"15.....5..44.2..\n"
"33.35.....3..2.1\n"
"4..2.1..1.......\n"
"...4115.5.2.....\n"
".....4.4.22..24.\n"
"...3....14....33\n") == 0);
free(board533366424);
board533366424 = NULL;
assert( gamma_move(board, 2, 11, 1) == 1 );


char* board676952918 = gamma_board(board);
assert( board676952918 != NULL );
assert( strcmp(board676952918, 
"41..312......2..\n"
"5514255......1..\n"
"1.42.4.......235\n"
"133......335....\n"
".3..1.....3.41..\n"
".......3.3....11\n"
"3.....4.12.1.32.\n"
"....5.3..3..2.4.\n"
"54..2....3.32...\n"
"1.21....345.....\n"
".5..2......332..\n"
"15.....5..44.2..\n"
"33.35.....3..2.1\n"
"4..2.1..1.......\n"
"...4115.5.2.....\n"
".....4.4.222.24.\n"
"...3....14....33\n") == 0);
free(board676952918);
board676952918 = NULL;
assert( gamma_move(board, 3, 14, 15) == 1 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 4, 4, 13) == 1 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 3, 8) == 1 );


char* board973265101 = gamma_board(board);
assert( board973265101 != NULL );
assert( strcmp(board973265101, 
"41..312......2..\n"
"5514255......13.\n"
"1.42.4.......235\n"
"133.4....335....\n"
".3..1.....3.41..\n"
".......3.3....11\n"
"3.....4.12.1.32.\n"
"....5.3..3..2.4.\n"
"54.12....3.32...\n"
"1.21....345.....\n"
".5..2......332..\n"
"15.....5..44.2..\n"
"33.35.....3..2.1\n"
"4..2.1..1.......\n"
"...4115.5.2.....\n"
".....4.4.222.24.\n"
"...3....14....33\n") == 0);
free(board973265101);
board973265101 = NULL;
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_move(board, 5, 7, 4) == 1 );
assert( gamma_move(board, 1, 4, 0) == 1 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 1, 0, 1) == 1 );


char* board232473082 = gamma_board(board);
assert( board232473082 != NULL );
assert( strcmp(board232473082, 
"41..312......2..\n"
"5514255......13.\n"
"1.42.4.2.....235\n"
"133.4....335....\n"
".3..1.....3.41..\n"
".......3.3....11\n"
"3.....4.12.1.32.\n"
"....5.3..3..2.4.\n"
"54.12....3.32...\n"
"1.21....345.....\n"
"25..2......332..\n"
"15.....5..44.2..\n"
"33.35..5..3..2.1\n"
"4..2.1..13......\n"
"...4115.5.24....\n"
"1....4.4.222.24.\n"
"...31...14....33\n") == 0);
free(board232473082);
board232473082 = NULL;
assert( gamma_move(board, 2, 14, 8) == 1 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 6, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_golden_move(board, 5, 5, 11) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 2, 13, 15) == 0 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_free_fields(board, 3) == 159 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 5, 6, 3) == 1 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 0, 0) == 1 );


char* board841516476 = gamma_board(board);
assert( board841516476 != NULL );
assert( strcmp(board841516476, 
"41..312......2..\n"
"5514255......13.\n"
"1.42.4.2.....235\n"
"133.4....335....\n"
".3..1.....3.41..\n"
".......3.3....11\n"
"3.....4.12.1.32.\n"
"....5.3..3..2.4.\n"
"54.12....3.32.2.\n"
"1.21....345.....\n"
"25..2......332..\n"
"15....353.44.2..\n"
"33.35..5..3..2.1\n"
"4..2.15.13......\n"
"...4115.5.24....\n"
"1....4.4.222.24.\n"
"1..31...14....33\n") == 0);
free(board841516476);
board841516476 = NULL;
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_golden_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_move(board, 3, 15, 10) == 1 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 4, 11, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_move(board, 5, 2, 11) == 1 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 4, 12, 7) == 1 );
assert( gamma_move(board, 4, 13, 14) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 6, 8) == 1 );
assert( gamma_move(board, 1, 16, 14) == 0 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 3, 11, 13) == 0 );
assert( gamma_move(board, 4, 16, 7) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_golden_move(board, 5, 15, 3) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 6, 14) == 1 );
assert( gamma_move(board, 2, 4, 11) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_free_fields(board, 2) == 145 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 1, 13, 15) == 0 );
assert( gamma_free_fields(board, 1) == 144 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 11, 3) == 1 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 5, 12, 16) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 4, 15, 15) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 2, 0) == 1 );


char* board575858376 = gamma_board(board);
assert( board575858376 != NULL );
assert( strcmp(board575858376, 
"41..312.....52..\n"
"5514255......134\n"
"1.42.412.....235\n"
"13314....335....\n"
"23..1.....3.41..\n"
"..5.23.3.3....11\n"
"3.....4.12.1.323\n"
"....5.3..3..224.\n"
"54.12.5..3.32.2.\n"
"1.21....345.4...\n"
"25..2.5....332..\n"
"15....353.44.2..\n"
"33.35..53.3..2.1\n"
"4..2.15.13.3....\n"
".2.4115.5.24....\n"
"13...4.4.222.24.\n"
"1.131...14.4..33\n") == 0);
free(board575858376);
board575858376 = NULL;
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 13, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_free_fields(board, 5) == 136 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_free_fields(board, 1) == 136 );
assert( gamma_move(board, 2, 7, 13) == 1 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 5, 2, 2) == 1 );
assert( gamma_free_fields(board, 5) == 132 );
assert( gamma_busy_fields(board, 1) == 28 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_free_fields(board, 2) == 131 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 5, 1, 5) == 0 );
assert( gamma_move(board, 1, 7, 12) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 15) == 1 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_move(board, 5, 8, 2) == 0 );
assert( gamma_move(board, 5, 9, 13) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 3, 15, 12) == 1 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 5, 6, 7) == 1 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 30 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 4, 11, 15) == 1 );
assert( gamma_move(board, 5, 13, 15) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_move(board, 3, 14, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 2, 12) == 1 );
assert( gamma_move(board, 4, 14, 16) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 14, 15) == 1 );
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_move(board, 1, 9, 5) == 1 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_golden_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 3, 9, 14) == 1 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 1, 1, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 15, 7) == 1 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 15, 12) == 0 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 5, 14, 6) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );


char* board300016950 = gamma_board(board);
assert( board300016950 != NULL );
assert( strcmp(board300016950, 
"41..312.....524.\n"
"5514255..2.4.144\n"
"1.423412.31..235\n"
"13314..2.335....\n"
"234.1..14.3341.3\n"
"..5.23.3.3....11\n"
"3.....4.12.1.323\n"
"....5.3..3..224.\n"
"54.12.5..3.32.2.\n"
"1.21..5.345.4..2\n"
"25.22.53...3325.\n"
"15....353144.2..\n"
"33.351.53.3..2.1\n"
"42.2.15.1323.2..\n"
".254115.5.24....\n"
"132..4.4.222.24.\n"
"1.131...14.4..33\n") == 0);
free(board300016950);
board300016950 = NULL;
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_free_fields(board, 2) == 114 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board868156608 = gamma_board(board);
assert( board868156608 != NULL );
assert( strcmp(board868156608, 
"41..312.....524.\n"
"5514255..2.4.144\n"
"1.423412.31..235\n"
"13314..2.335....\n"
"234.1..14.3341.3\n"
"..5.23.3.3....11\n"
"3.....4.12.1.323\n"
"....5.3..3..224.\n"
"54.12.5..3.32.2.\n"
"1.21..5.345.4..2\n"
"25.22.53...3325.\n"
"15....353144.2..\n"
"33.351.53.3..2.1\n"
"42.2.15.1323.2..\n"
".254115.5.24....\n"
"132..4.4.222.24.\n"
"1.131...14.4..33\n") == 0);
free(board868156608);
board868156608 = NULL;
assert( gamma_move(board, 3, 5, 12) == 1 );
assert( gamma_move(board, 3, 12, 16) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 5, 12, 3) == 1 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 3, 11, 11) == 1 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 4, 9, 16) == 1 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board701943942 = gamma_board(board);
assert( board701943942 != NULL );
assert( strcmp(board701943942, 
"41..312..4..524.\n"
"5514255..2.4.144\n"
"1.423412.31..235\n"
"13314..2.335....\n"
"234.13.14.3341.3\n"
"..5.23.3.3.3..11\n"
"3.....4.1221.323\n"
"....5.3..3..224.\n"
"54.12.5..3.32.2.\n"
"1.21..5.345.4..2\n"
"25.22.53...3325.\n"
"15....353144.2..\n"
"33.351.53.3..2.1\n"
"42.2.15.132352..\n"
".25411515.24....\n"
"132..4.4.222.24.\n"
"1.131...14.4..33\n") == 0);
free(board701943942);
board701943942 = NULL;
assert( gamma_move(board, 3, 0, 9) == 1 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 8, 13) == 1 );
assert( gamma_move(board, 1, 15, 8) == 1 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 15) == 0 );
assert( gamma_free_fields(board, 4) == 104 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 5, 13, 15) == 0 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_free_fields(board, 1) == 103 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 9) == 1 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_free_fields(board, 4) == 101 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 3, 13, 13) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board619884903 = gamma_board(board);
assert( board619884903 != NULL );
assert( strcmp(board619884903, 
"41..312..4..524.\n"
"5514255..2.4.144\n"
"1.423412.31..235\n"
"13314..25335.3..\n"
"234.13.14.3341.3\n"
"..5.23.343.3..11\n"
"3.....4.1221.323\n"
"3...5.3.23..224.\n"
"54.12.5.33.32.21\n"
"1.21..5.345.4..2\n"
"25.22.532..3325.\n"
"15....353144.2..\n"
"33.351.5323..2.1\n"
"42.2.15.132352..\n"
".25411515.24....\n"
"132..4.4.222.24.\n"
"1.131...14.4..33\n") == 0);
free(board619884903);
board619884903 = NULL;
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 40 );
assert( gamma_free_fields(board, 2) == 98 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_move(board, 5, 14, 12) == 1 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 3, 7, 13) == 0 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_free_fields(board, 3) == 95 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_free_fields(board, 1) == 95 );


char* board500356311 = gamma_board(board);
assert( board500356311 != NULL );
assert( strcmp(board500356311, 
"41..312..4..524.\n"
"5514255..2.4.144\n"
"1.423412.313.235\n"
"13314..25335.3..\n"
"234.13.14.334153\n"
"..5.23.343.3..11\n"
"3.....4.1221.323\n"
"3.1.5.3.23..224.\n"
"54.12.5.33.32.21\n"
"1.21..5.345.4..2\n"
"25.22.532..3325.\n"
"15....353144.2..\n"
"33.35135323..2.1\n"
"42.2.15.132352..\n"
".25411515.24....\n"
"132..4.4.222.24.\n"
"1.131...14.4..33\n") == 0);
free(board500356311);
board500356311 = NULL;
assert( gamma_move(board, 2, 15, 12) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 12, 16) == 0 );
assert( gamma_free_fields(board, 3) == 95 );
assert( gamma_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 6, 13) == 1 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 3, 16, 15) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_free_fields(board, 3) == 94 );


char* board488187826 = gamma_board(board);
assert( board488187826 != NULL );
assert( strcmp(board488187826, 
"41..312..4..524.\n"
"5514255..2.4.144\n"
"1.423412.313.235\n"
"13314.525335.3..\n"
"234.13.14.334153\n"
"..5.23.343.3..11\n"
"3.....4.1221.323\n"
"3.1.5.3.23..224.\n"
"54.12.5.33.32.21\n"
"1.21..5.345.4..2\n"
"25.22.532..3325.\n"
"15....353144.2..\n"
"33.35135323..2.1\n"
"42.2.15.132352..\n"
".25411515.24....\n"
"132..4.4.222.24.\n"
"1.131...14.4..33\n") == 0);
free(board488187826);
board488187826 = NULL;
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 0, 13) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 2, 7, 8) == 1 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_golden_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 5, 5, 15) == 0 );
assert( gamma_move(board, 5, 14, 13) == 1 );
assert( gamma_busy_fields(board, 5) == 29 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 3, 3, 16) == 1 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_free_fields(board, 2) == 90 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 5, 2, 3) == 1 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_free_fields(board, 4) == 88 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 1, 12, 0) == 1 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 3, 15, 2) == 1 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_free_fields(board, 4) == 85 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 5, 12, 15) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 2, 15, 12) == 0 );
assert( gamma_move(board, 2, 13, 13) == 0 );
assert( gamma_free_fields(board, 2) == 84 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 12, 13) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 16, 7) == 0 );
assert( gamma_move(board, 1, 16, 2) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 5, 6, 8) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 6, 15) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 5, 3, 5) == 1 );
assert( gamma_free_fields(board, 5) == 82 );
assert( gamma_golden_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 1, 7, 13) == 0 );
assert( gamma_move(board, 1, 12, 11) == 1 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 2, 5, 13) == 1 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board656755950 = gamma_board(board);
assert( board656755950 != NULL );
assert( strcmp(board656755950, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.313.235\n"
"133142525335335.\n"
"234.13.14.334153\n"
"..5.23.343.31.11\n"
"3.....4.1221.323\n"
"331.5.3.23..224.\n"
"54.12.5233.32.21\n"
"1421..5.345.4..2\n"
"25.22.532..3325.\n"
"15.5..353144.2..\n"
"33.35135323..2.1\n"
"4252.15.132352..\n"
".25411515.24...3\n"
"132..4.4.222.24.\n"
"15131...14.41.33\n") == 0);
free(board656755950);
board656755950 = NULL;
assert( gamma_move(board, 4, 14, 12) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_move(board, 5, 14, 7) == 1 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 3, 11) == 1 );
assert( gamma_free_fields(board, 2) == 78 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 3, 12, 14) == 1 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_free_fields(board, 4) == 76 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_free_fields(board, 1) == 76 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 15, 3) == 1 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 4, 13, 0) == 1 );
assert( gamma_move(board, 5, 12, 6) == 0 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 6, 11) == 1 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_free_fields(board, 1) == 71 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 4, 15, 2) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 14, 12) == 0 );
assert( gamma_move(board, 3, 13, 11) == 1 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 3, 16) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 4, 0, 16) == 0 );


char* board732032400 = gamma_board(board);
assert( board732032400 != NULL );
assert( strcmp(board732032400, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"133142525335335.\n"
"234.13.14.334153\n"
"..52233343.31311\n"
"3..3..4.1221.323\n"
"331.5.3.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"25.22.532..3325.\n"
"15.5..353144.2..\n"
"33.35135323..2.1\n"
"4252.15.132352.3\n"
".25411515.24...3\n"
"1321.4.4.222.24.\n"
"15131...14.41433\n") == 0);
free(board732032400);
board732032400 = NULL;
assert( gamma_move(board, 5, 7, 13) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 1, 14, 13) == 0 );
assert( gamma_move(board, 2, 9, 15) == 0 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_free_fields(board, 3) == 70 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_free_fields(board, 4) == 69 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 15, 10) == 0 );
assert( gamma_move(board, 1, 4, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board552336964 = gamma_board(board);
assert( board552336964 != NULL );
assert( strcmp(board552336964, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"133142525335335.\n"
"234.13.14.334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"331.5.3.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"25.22.532..3325.\n"
"15.5..353144.2..\n"
"33.35135323..2.1\n"
"4252.15.132352.3\n"
".25411515.24...3\n"
"1321.4.4.222.24.\n"
"15131...14.41433\n") == 0);
free(board552336964);
board552336964 = NULL;
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 15, 14) == 0 );
assert( gamma_move(board, 5, 6, 4) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_golden_move(board, 1, 2, 1) == 1 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 3, 14, 5) == 1 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_free_fields(board, 5) == 68 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 4, 13, 15) == 0 );
assert( gamma_move(board, 4, 15, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 5, 15, 4) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 2, 12, 2) == 1 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 57 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 4, 14, 8) == 0 );
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 3, 10, 0) == 1 );
assert( gamma_free_fields(board, 3) == 63 );
assert( gamma_move(board, 4, 6, 12) == 1 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );


char* board299883415 = gamma_board(board);
assert( board299883415 != NULL );
assert( strcmp(board299883415, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"133142525335335.\n"
"234.13414.334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"331.533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"25.222532..3325.\n"
"15.5..353144.23.\n"
"33.35135323..2.1\n"
"4252.15.132352.3\n"
".25411515.242..3\n"
"131114.4.222.24.\n"
"15131...14341433\n") == 0);
free(board299883415);
board299883415 = NULL;
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_free_fields(board, 4) == 61 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 5, 3, 16) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 16, 2) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 59 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_move(board, 5, 8, 12) == 0 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );


char* board110955928 = gamma_board(board);
assert( board110955928 != NULL );
assert( strcmp(board110955928, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"133142525335335.\n"
"234.13414.334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"331.533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"25.222532..3325.\n"
"15.5..353144.23.\n"
"33.35135323..2.1\n"
"4252.15.132352.3\n"
".25411515.242..3\n"
"13111434.222.24.\n"
"15131...14341433\n") == 0);
free(board110955928);
board110955928 = NULL;
assert( gamma_move(board, 4, 1, 1) == 0 );
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 1, 14, 16) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 45 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 5, 4, 14) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 2, 14, 3) == 1 );
assert( gamma_busy_fields(board, 2) == 46 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 5, 2, 14) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 13, 15) == 0 );
assert( gamma_move(board, 2, 15, 14) == 0 );
assert( gamma_free_fields(board, 2) == 60 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 59 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 5, 15, 10) == 0 );
assert( gamma_move(board, 5, 15, 12) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_free_fields(board, 3) == 59 );
assert( gamma_move(board, 4, 13, 15) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 5, 3, 10) == 0 );
assert( gamma_free_fields(board, 5) == 59 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 3, 16, 7) == 0 );
assert( gamma_move(board, 4, 3, 9) == 1 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_move(board, 5, 9, 12) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 34 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 5, 12, 12) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_free_fields(board, 1) == 57 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 15, 13) == 1 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 34 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 60 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 5, 10, 12) == 0 );
assert( gamma_move(board, 5, 2, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_golden_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 1, 12, 14) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_free_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_golden_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 16, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 35 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 1, 1, 15) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );


char* board636540475 = gamma_board(board);
assert( board636540475 != NULL );
assert( strcmp(board636540475, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"252222532..3325.\n"
"1545..353144.23.\n"
"33.35135323..2.1\n"
"4252.15.13235223\n"
".25411515.242..3\n"
"13111434.222.24.\n"
"15131.4.14341433\n") == 0);
free(board636540475);
board636540475 = NULL;
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 5, 6, 10) == 0 );
assert( gamma_free_fields(board, 5) == 54 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 60 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board365621663 = gamma_board(board);
assert( board365621663 != NULL );
assert( strcmp(board365621663, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"252222532..3325.\n"
"1545..353144.23.\n"
"33.35135323..2.1\n"
"4252.15.13235223\n"
".25411515.242..3\n"
"13111434.222.24.\n"
"15131.4.14341433\n") == 0);
free(board365621663);
board365621663 = NULL;
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 15, 6) == 1 );
assert( gamma_move(board, 2, 12, 13) == 0 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 3, 5, 5) == 1 );


char* board750534915 = gamma_board(board);
assert( board750534915 != NULL );
assert( strcmp(board750534915, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"252222532..33251\n"
"1545.3353144.23.\n"
"33.35135323..2.1\n"
"4252.15.13235223\n"
".25411515.242..3\n"
"13111434.222.24.\n"
"15131.4.14341433\n") == 0);
free(board750534915);
board750534915 = NULL;
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_free_fields(board, 1) == 52 );


char* board297967396 = gamma_board(board);
assert( board297967396 != NULL );
assert( strcmp(board297967396, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"252222532..33251\n"
"1545.3353144.23.\n"
"33.35135323..2.1\n"
"4252.15.13235223\n"
".25411515.242..3\n"
"13111434.222.24.\n"
"15131.4.14341433\n") == 0);
free(board297967396);
board297967396 = NULL;
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 12, 14) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 5, 7, 7) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 16, 15) == 0 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 9, 15) == 0 );
assert( gamma_move(board, 3, 3, 9) == 0 );


char* board449717167 = gamma_board(board);
assert( board449717167 != NULL );
assert( strcmp(board449717167, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"252222532..33251\n"
"1545.3353144.23.\n"
"33.35135323..2.1\n"
"4252.15.13235223\n"
".25411515.242..3\n"
"13111434.222.24.\n"
"15131.4.14341433\n") == 0);
free(board449717167);
board449717167 = NULL;
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_free_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_busy_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_free_fields(board, 4) == 52 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_move(board, 3, 16, 2) == 0 );
assert( gamma_move(board, 4, 15, 12) == 0 );
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 5, 15, 8) == 0 );
assert( gamma_move(board, 5, 9, 6) == 1 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 1, 15) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 47 );
assert( gamma_move(board, 3, 16, 10) == 0 );
assert( gamma_move(board, 3, 2, 7) == 0 );


char* board608915923 = gamma_board(board);
assert( board608915923 != NULL );
assert( strcmp(board608915923, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"2522225325.33251\n"
"1545.3353144.23.\n"
"33.35135323..2.1\n"
"4252.15.13235223\n"
".25411515.242..3\n"
"13111434.222.24.\n"
"15131.4.14341433\n") == 0);
free(board608915923);
board608915923 = NULL;
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_move(board, 5, 5, 15) == 0 );
assert( gamma_move(board, 5, 12, 16) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 8) == 0 );
assert( gamma_move(board, 5, 4, 14) == 0 );
assert( gamma_golden_move(board, 5, 7, 1) == 1 );


char* board162207503 = gamma_board(board);
assert( board162207503 != NULL );
assert( strcmp(board162207503, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"2522225325.33251\n"
"1545.3353144.23.\n"
"33.35135323..2.1\n"
"4252.15.13235223\n"
".25411515.242..3\n"
"13111435.222.24.\n"
"15131.4.14341433\n") == 0);
free(board162207503);
board162207503 = NULL;
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_move(board, 2, 16, 7) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 16, 7) == 0 );


char* board921817400 = gamma_board(board);
assert( board921817400 != NULL );
assert( strcmp(board921817400, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"2522225325.33251\n"
"1545.3353144.23.\n"
"33.35135323..2.1\n"
"4252.15213235223\n"
".25411515.242..3\n"
"13111435.222.24.\n"
"15131.4.14341433\n") == 0);
free(board921817400);
board921817400 = NULL;
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_golden_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 5, 12, 12) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 41 );


char* board474332783 = gamma_board(board);
assert( board474332783 != NULL );
assert( strcmp(board474332783, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233.32.21\n"
"1421..52345.4.52\n"
"2522225325.33251\n"
"1545.3353144.23.\n"
"33.35135323..2.1\n"
"4252.15213235223\n"
".25411515.242..3\n"
"13111435.222.24.\n"
"15131.4.14341433\n") == 0);
free(board474332783);
board474332783 = NULL;
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 3, 4, 14) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 4, 14, 14) == 0 );
assert( gamma_golden_move(board, 4, 10, 3) == 0 );
assert( gamma_move(board, 5, 6, 13) == 0 );
assert( gamma_free_fields(board, 5) == 50 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_golden_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 16, 7) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 5, 15, 7) == 0 );
assert( gamma_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );


char* board795164456 = gamma_board(board);
assert( board795164456 != NULL );
assert( strcmp(board795164456, 
"41.3312..4..524.\n"
"5514255..2.45144\n"
"1.423412.3133235\n"
"1331425253353353\n"
"234.134145334153\n"
"..52233343.31311\n"
"34.3..4.1221.323\n"
"3314533.23..224.\n"
"54.12.5233432.21\n"
"1421..52345.4.52\n"
"2522225325.33251\n"
"1545.3353144.23.\n"
"33.35135323..2.1\n"
"4252.15213235223\n"
".25411515.242..3\n"
"13111435.222.24.\n"
"15131.4.14341433\n") == 0);
free(board795164456);
board795164456 = NULL;
assert( gamma_move(board, 3, 14, 15) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 5, 5, 12) == 0 );
assert( gamma_busy_fields(board, 5) == 37 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 4, 4, 14) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );


gamma_delete(board);

    return 0;
}
