#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 121489191
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(3, 95, 6, 29);
assert( board != NULL );


assert( gamma_move(board, 1, 72, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 0 );
assert( gamma_move(board, 2, 74, 2) == 0 );


char* board924264388 = gamma_board(board);
assert( board924264388 != NULL );
assert( strcmp(board924264388, 
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board924264388);
board924264388 = NULL;
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 5, 24, 2) == 0 );
assert( gamma_move(board, 5, 1, 45) == 1 );
assert( gamma_move(board, 6, 39, 2) == 0 );
assert( gamma_move(board, 6, 1, 81) == 1 );


char* board525868005 = gamma_board(board);
assert( board525868005 != NULL );
assert( strcmp(board525868005, 
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board525868005);
board525868005 = NULL;
assert( gamma_move(board, 1, 17, 0) == 0 );
assert( gamma_free_fields(board, 1) == 282 );
assert( gamma_move(board, 2, 66, 0) == 0 );
assert( gamma_golden_move(board, 2, 81, 1) == 0 );
assert( gamma_move(board, 3, 1, 34) == 1 );
assert( gamma_move(board, 4, 93, 0) == 0 );
assert( gamma_move(board, 5, 2, 26) == 1 );
assert( gamma_move(board, 5, 1, 72) == 1 );


char* board176729035 = gamma_board(board);
assert( board176729035 != NULL );
assert( strcmp(board176729035, 
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..5\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n") == 0);
free(board176729035);
board176729035 = NULL;
assert( gamma_move(board, 6, 36, 1) == 0 );
assert( gamma_move(board, 6, 2, 76) == 1 );
assert( gamma_move(board, 1, 32, 2) == 0 );
assert( gamma_move(board, 1, 0, 20) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );
assert( gamma_free_fields(board, 1) == 277 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_golden_move(board, 2, 34, 1) == 0 );
assert( gamma_move(board, 3, 20, 2) == 0 );
assert( gamma_move(board, 4, 60, 0) == 0 );
assert( gamma_move(board, 4, 1, 49) == 1 );
assert( gamma_move(board, 1, 2, 40) == 1 );
assert( gamma_busy_fields(board, 1) == 2 );
assert( gamma_move(board, 2, 0, 48) == 1 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 3, 0, 83) == 1 );
assert( gamma_move(board, 4, 2, 87) == 1 );
assert( gamma_move(board, 5, 2, 34) == 1 );
assert( gamma_move(board, 6, 1, 69) == 1 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_free_fields(board, 6) == 269 );
assert( gamma_move(board, 1, 41, 0) == 0 );
assert( gamma_move(board, 3, 26, 0) == 0 );
assert( gamma_move(board, 3, 1, 28) == 1 );
assert( gamma_free_fields(board, 3) == 268 );
assert( gamma_move(board, 4, 83, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 5, 0, 24) == 1 );
assert( gamma_move(board, 6, 56, 2) == 0 );
assert( gamma_move(board, 6, 1, 56) == 1 );
assert( gamma_move(board, 1, 84, 2) == 0 );
assert( gamma_move(board, 1, 2, 92) == 1 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 66, 0) == 0 );
assert( gamma_move(board, 4, 1, 40) == 1 );
assert( gamma_golden_move(board, 4, 26, 2) == 0 );
assert( gamma_move(board, 5, 92, 1) == 0 );
assert( gamma_move(board, 5, 1, 60) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 40, 1) == 0 );
assert( gamma_move(board, 6, 67, 1) == 0 );
assert( gamma_move(board, 6, 1, 68) == 1 );
assert( gamma_move(board, 1, 2, 39) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 32) == 1 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_golden_move(board, 3, 20, 0) == 0 );
assert( gamma_move(board, 4, 0, 39) == 1 );
assert( gamma_free_fields(board, 4) == 258 );
assert( gamma_golden_move(board, 4, 40, 2) == 0 );
assert( gamma_move(board, 5, 1, 17) == 1 );
assert( gamma_move(board, 5, 0, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 32, 1) == 0 );
assert( gamma_move(board, 6, 63, 0) == 0 );
assert( gamma_move(board, 6, 2, 89) == 1 );
assert( gamma_move(board, 1, 0, 82) == 1 );
assert( gamma_move(board, 1, 1, 35) == 1 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 3, 50, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 22) == 1 );
assert( gamma_move(board, 4, 1, 20) == 1 );
assert( gamma_move(board, 5, 2, 81) == 1 );
assert( gamma_move(board, 6, 2, 92) == 0 );
assert( gamma_move(board, 1, 1, 90) == 1 );
assert( gamma_move(board, 1, 0, 43) == 1 );
assert( gamma_move(board, 2, 37, 2) == 0 );
assert( gamma_move(board, 3, 0, 73) == 1 );


char* board762423865 = gamma_board(board);
assert( board762423865 != NULL );
assert( strcmp(board762423865, 
"...\n"
"...\n"
"..1\n"
"...\n"
".1.\n"
"..6\n"
"...\n"
"..4\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"1..\n"
".65\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..6\n"
"...\n"
"...\n"
"3..\n"
".5.\n"
"...\n"
"...\n"
".6.\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"...\n"
"...\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".4.\n"
"2..\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"1..\n"
"...\n"
"...\n"
".41\n"
"4.1\n"
"...\n"
"...\n"
"...\n"
".1.\n"
".35\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"...\n"
".3.\n"
"...\n"
"..5\n"
"...\n"
"5..\n"
"...\n"
".4.\n"
"...\n"
"14.\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"2..\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"5..\n"
"...\n"
"...\n") == 0);
free(board762423865);
board762423865 = NULL;
assert( gamma_move(board, 4, 75, 2) == 0 );
assert( gamma_move(board, 5, 21, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 9 );
assert( gamma_move(board, 6, 36, 2) == 0 );
assert( gamma_move(board, 6, 1, 88) == 1 );
assert( gamma_move(board, 1, 0, 63) == 1 );
assert( gamma_move(board, 1, 0, 30) == 1 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 2, 1, 36) == 1 );
assert( gamma_move(board, 3, 64, 1) == 0 );
assert( gamma_free_fields(board, 3) == 243 );
assert( gamma_move(board, 4, 2, 40) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 71, 1) == 0 );
assert( gamma_free_fields(board, 6) == 243 );
assert( gamma_move(board, 1, 44, 2) == 0 );
assert( gamma_move(board, 2, 2, 24) == 1 );
assert( gamma_move(board, 2, 1, 85) == 1 );
assert( gamma_move(board, 3, 18, 1) == 0 );
assert( gamma_move(board, 4, 94, 1) == 0 );
assert( gamma_move(board, 5, 2, 19) == 1 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 6, 1, 74) == 1 );
assert( gamma_move(board, 2, 0, 51) == 1 );
assert( gamma_move(board, 3, 2, 31) == 1 );
assert( gamma_free_fields(board, 3) == 237 );
assert( gamma_move(board, 4, 31, 1) == 0 );
assert( gamma_move(board, 5, 28, 0) == 0 );
assert( gamma_move(board, 6, 0, 38) == 1 );
assert( gamma_move(board, 1, 56, 2) == 0 );
assert( gamma_move(board, 1, 0, 16) == 1 );
assert( gamma_free_fields(board, 1) == 235 );
assert( gamma_move(board, 2, 77, 1) == 0 );
assert( gamma_move(board, 2, 1, 50) == 1 );
assert( gamma_move(board, 3, 0, 85) == 1 );
assert( gamma_golden_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 5, 42, 1) == 0 );
assert( gamma_move(board, 5, 2, 92) == 0 );
assert( gamma_move(board, 6, 33, 1) == 0 );
assert( gamma_move(board, 6, 2, 74) == 1 );
assert( gamma_move(board, 1, 2, 93) == 1 );
assert( gamma_move(board, 2, 59, 2) == 0 );
assert( gamma_move(board, 2, 2, 15) == 1 );
assert( gamma_move(board, 3, 0, 24) == 0 );
assert( gamma_move(board, 3, 2, 16) == 1 );
assert( gamma_free_fields(board, 3) == 229 );
assert( gamma_move(board, 4, 23, 1) == 0 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 5, 60, 2) == 0 );
assert( gamma_move(board, 5, 1, 82) == 1 );
assert( gamma_move(board, 6, 65, 1) == 0 );
assert( gamma_free_fields(board, 1) == 227 );
assert( gamma_move(board, 2, 0, 87) == 1 );
assert( gamma_move(board, 3, 0, 38) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 49, 0) == 0 );


char* board791847444 = gamma_board(board);
assert( board791847444 != NULL );
assert( strcmp(board791847444, 
"...\n"
"..1\n"
"..1\n"
"...\n"
".1.\n"
"..6\n"
".6.\n"
"2.4\n"
"...\n"
"32.\n"
"...\n"
"3..\n"
"15.\n"
".65\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..6\n"
"...\n"
".66\n"
"3..\n"
".5.\n"
"...\n"
"...\n"
".6.\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"...\n"
"...\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
".2.\n"
".4.\n"
"2..\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"1..\n"
"...\n"
"...\n"
".41\n"
"4.1\n"
"6..\n"
"...\n"
".2.\n"
".1.\n"
".35\n"
"...\n"
".2.\n"
"..3\n"
"1..\n"
"...\n"
".3.\n"
"...\n"
"..5\n"
"...\n"
"5.2\n"
"...\n"
".4.\n"
"...\n"
"14.\n"
"..5\n"
"...\n"
".5.\n"
"1.3\n"
"2.2\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"...\n"
"...\n"
"...\n"
".44\n"
"...\n"
"...\n"
"...\n"
"...\n"
"5..\n"
"...\n"
"...\n") == 0);
free(board791847444);
board791847444 = NULL;
assert( gamma_move(board, 5, 19, 1) == 0 );
assert( gamma_move(board, 6, 8, 2) == 0 );
assert( gamma_move(board, 6, 1, 48) == 1 );
assert( gamma_move(board, 1, 0, 92) == 1 );
assert( gamma_move(board, 1, 0, 62) == 1 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 5, 53, 2) == 0 );
assert( gamma_move(board, 5, 2, 8) == 1 );
assert( gamma_move(board, 6, 23, 1) == 0 );
assert( gamma_move(board, 6, 0, 79) == 1 );
assert( gamma_move(board, 1, 79, 2) == 0 );
assert( gamma_move(board, 2, 61, 2) == 0 );
assert( gamma_move(board, 2, 0, 58) == 1 );
assert( gamma_busy_fields(board, 2) == 12 );


char* board742850785 = gamma_board(board);
assert( board742850785 != NULL );
assert( strcmp(board742850785, 
"...\n"
"..1\n"
"1.1\n"
"...\n"
".1.\n"
"..6\n"
".6.\n"
"2.4\n"
"...\n"
"32.\n"
"...\n"
"3..\n"
"15.\n"
".65\n"
"...\n"
"6..\n"
"...\n"
"...\n"
"..6\n"
"...\n"
".66\n"
"3..\n"
".5.\n"
"...\n"
"...\n"
".6.\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"...\n"
".5.\n"
"...\n"
"2..\n"
"...\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"1..\n"
"...\n"
"...\n"
".41\n"
"4.1\n"
"6..\n"
"...\n"
".2.\n"
".1.\n"
".35\n"
"...\n"
".2.\n"
"..3\n"
"1..\n"
"...\n"
".3.\n"
"...\n"
"..5\n"
"...\n"
"5.2\n"
"...\n"
".4.\n"
"...\n"
"14.\n"
"..5\n"
"...\n"
".5.\n"
"1.3\n"
"2.2\n"
"...\n"
"...\n"
"2..\n"
"...\n"
"...\n"
"...\n"
"..5\n"
".44\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"5..\n"
"...\n"
"...\n") == 0);
free(board742850785);
board742850785 = NULL;
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 4, 37, 0) == 0 );
assert( gamma_move(board, 4, 0, 31) == 1 );
assert( gamma_move(board, 5, 77, 0) == 0 );
assert( gamma_move(board, 6, 30, 1) == 0 );
assert( gamma_move(board, 6, 0, 31) == 0 );
assert( gamma_move(board, 1, 2, 43) == 1 );
assert( gamma_move(board, 2, 0, 73) == 0 );
assert( gamma_move(board, 2, 1, 77) == 1 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 0, 59) == 1 );
assert( gamma_move(board, 4, 75, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_move(board, 5, 0, 21) == 1 );
assert( gamma_move(board, 5, 2, 30) == 1 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_move(board, 1, 1, 16) == 1 );
assert( gamma_move(board, 2, 56, 2) == 0 );
assert( gamma_move(board, 3, 73, 2) == 0 );
assert( gamma_move(board, 3, 2, 12) == 1 );


char* board204009498 = gamma_board(board);
assert( board204009498 != NULL );
assert( strcmp(board204009498, 
"...\n"
"..1\n"
"1.1\n"
"...\n"
".1.\n"
"..6\n"
".6.\n"
"2.4\n"
"...\n"
"32.\n"
"...\n"
"3..\n"
"15.\n"
".65\n"
"...\n"
"6..\n"
"...\n"
".2.\n"
"..6\n"
"...\n"
".66\n"
"3..\n"
".5.\n"
"...\n"
"...\n"
".6.\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"...\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
".6.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"2..\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
".5.\n"
"...\n"
"1.1\n"
"...\n"
"...\n"
".41\n"
"4.1\n"
"6..\n"
"...\n"
".2.\n"
".1.\n"
".35\n"
"...\n"
".2.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
"..5\n"
"...\n"
"5.2\n"
"...\n"
".4.\n"
"5..\n"
"14.\n"
"..5\n"
"...\n"
".5.\n"
"113\n"
"2.2\n"
"...\n"
"...\n"
"2.3\n"
"...\n"
"...\n"
"...\n"
"..5\n"
".44\n"
"...\n"
"3..\n"
"3..\n"
"...\n"
"5..\n"
"...\n"
"...\n") == 0);
free(board204009498);
board204009498 = NULL;
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 4, 0, 55) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 38) == 0 );
assert( gamma_move(board, 5, 2, 41) == 1 );
assert( gamma_move(board, 6, 35, 2) == 0 );
assert( gamma_move(board, 1, 55, 2) == 0 );
assert( gamma_move(board, 1, 2, 4) == 1 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 52, 1) == 0 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 58, 1) == 0 );
assert( gamma_move(board, 5, 1, 33) == 1 );
assert( gamma_move(board, 6, 29, 1) == 0 );
assert( gamma_move(board, 1, 41, 0) == 0 );
assert( gamma_move(board, 2, 53, 2) == 0 );
assert( gamma_move(board, 2, 2, 83) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_golden_move(board, 3, 41, 2) == 0 );
assert( gamma_move(board, 4, 49, 0) == 0 );
assert( gamma_move(board, 5, 1, 4) == 1 );
assert( gamma_move(board, 5, 2, 18) == 1 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 1, 87, 1) == 0 );
assert( gamma_move(board, 1, 0, 21) == 0 );
assert( gamma_move(board, 2, 52, 0) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 4, 84, 0) == 0 );
assert( gamma_move(board, 4, 0, 87) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_move(board, 5, 0, 45) == 1 );
assert( gamma_busy_fields(board, 5) == 19 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 6, 0, 67) == 1 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 1, 5) == 1 );
assert( gamma_move(board, 2, 84, 2) == 0 );
assert( gamma_move(board, 2, 2, 18) == 0 );
assert( gamma_move(board, 3, 89, 0) == 0 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_golden_move(board, 3, 76, 2) == 0 );
assert( gamma_move(board, 4, 2, 94) == 1 );
assert( gamma_move(board, 4, 2, 55) == 1 );


char* board699981571 = gamma_board(board);
assert( board699981571 != NULL );
assert( strcmp(board699981571, 
"..4\n"
"..1\n"
"1.1\n"
"...\n"
".1.\n"
"..6\n"
".6.\n"
"2.4\n"
"...\n"
"32.\n"
"...\n"
"3.2\n"
"15.\n"
".65\n"
"...\n"
"6..\n"
"...\n"
".2.\n"
"..6\n"
"...\n"
".66\n"
"3..\n"
".5.\n"
"...\n"
"...\n"
".6.\n"
".6.\n"
"6..\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"...\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
".6.\n"
"4.4\n"
"...\n"
"...\n"
"...\n"
"2..\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
"55.\n"
"...\n"
"1.1\n"
"...\n"
"..5\n"
".41\n"
"4.1\n"
"6..\n"
"...\n"
".2.\n"
".1.\n"
".35\n"
".5.\n"
".2.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
"..5\n"
"...\n"
"5.2\n"
"...\n"
".4.\n"
"5..\n"
"14.\n"
"..5\n"
"..5\n"
".5.\n"
"113\n"
"2.2\n"
"...\n"
"...\n"
"2.3\n"
"...\n"
"...\n"
"...\n"
"..5\n"
".44\n"
"...\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"...\n"
"4..\n") == 0);
free(board699981571);
board699981571 = NULL;
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 57, 2) == 0 );
assert( gamma_move(board, 6, 2, 26) == 0 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_move(board, 1, 1, 26) == 1 );
assert( gamma_move(board, 1, 1, 24) == 1 );
assert( gamma_move(board, 2, 46, 1) == 0 );
assert( gamma_free_fields(board, 2) == 193 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 2, 83) == 0 );
assert( gamma_move(board, 5, 0, 43) == 0 );
assert( gamma_move(board, 6, 0, 18) == 1 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 1, 1, 32) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 25, 0) == 0 );
assert( gamma_move(board, 3, 1, 67) == 1 );
assert( gamma_free_fields(board, 4) == 191 );
assert( gamma_move(board, 5, 55, 1) == 0 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 2, 80, 0) == 0 );
assert( gamma_move(board, 2, 2, 43) == 0 );
assert( gamma_free_fields(board, 2) == 191 );
assert( gamma_move(board, 3, 20, 2) == 0 );
assert( gamma_move(board, 4, 73, 1) == 0 );
assert( gamma_move(board, 4, 1, 73) == 1 );
assert( gamma_move(board, 5, 60, 2) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 6, 39, 1) == 0 );
assert( gamma_move(board, 6, 1, 92) == 1 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 78, 0) == 0 );
assert( gamma_move(board, 2, 0, 53) == 1 );
assert( gamma_move(board, 3, 25, 1) == 0 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 4, 42, 0) == 0 );
assert( gamma_move(board, 4, 0, 21) == 0 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 0, 81) == 1 );
assert( gamma_move(board, 5, 0, 9) == 1 );
assert( gamma_move(board, 6, 1, 19) == 1 );
assert( gamma_move(board, 6, 1, 67) == 0 );
assert( gamma_golden_move(board, 6, 87, 2) == 0 );
assert( gamma_move(board, 1, 23, 1) == 0 );
assert( gamma_move(board, 1, 1, 22) == 0 );
assert( gamma_free_fields(board, 1) == 184 );
assert( gamma_move(board, 2, 0, 41) == 1 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_move(board, 3, 84, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 2, 71) == 1 );
assert( gamma_move(board, 5, 2, 77) == 1 );
assert( gamma_move(board, 5, 1, 91) == 1 );
assert( gamma_free_fields(board, 5) == 179 );
assert( gamma_move(board, 6, 77, 0) == 0 );


char* board633207050 = gamma_board(board);
assert( board633207050 != NULL );
assert( strcmp(board633207050, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"2.4\n"
"...\n"
"32.\n"
"...\n"
"3.2\n"
"15.\n"
"565\n"
"...\n"
"6..\n"
"...\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".5.\n"
"..4\n"
"...\n"
".6.\n"
".6.\n"
"63.\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"...\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
".6.\n"
"4.4\n"
"...\n"
"2..\n"
"...\n"
"2..\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
"55.\n"
"...\n"
"1.1\n"
"...\n"
"2.5\n"
".41\n"
"4.1\n"
"6..\n"
"...\n"
".2.\n"
".1.\n"
".35\n"
".5.\n"
".2.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"...\n"
"512\n"
"...\n"
".4.\n"
"5..\n"
"14.\n"
".65\n"
"6.5\n"
".5.\n"
"113\n"
"2.2\n"
"...\n"
"...\n"
"2.3\n"
"...\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
"...\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3..\n"
"4..\n") == 0);
free(board633207050);
board633207050 = NULL;
assert( gamma_move(board, 2, 1, 18) == 1 );
assert( gamma_move(board, 2, 1, 52) == 1 );
assert( gamma_move(board, 3, 67, 2) == 0 );
assert( gamma_move(board, 3, 2, 84) == 1 );
assert( gamma_move(board, 4, 47, 2) == 0 );


char* board945638333 = gamma_board(board);
assert( board945638333 != NULL );
assert( strcmp(board945638333, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"2.4\n"
"...\n"
"32.\n"
"..3\n"
"3.2\n"
"15.\n"
"565\n"
"...\n"
"6..\n"
"...\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".5.\n"
"..4\n"
"...\n"
".6.\n"
".6.\n"
"63.\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"...\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
".6.\n"
"4.4\n"
"...\n"
"2..\n"
".2.\n"
"2..\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
"55.\n"
"...\n"
"1.1\n"
"...\n"
"2.5\n"
".41\n"
"4.1\n"
"6..\n"
"...\n"
".2.\n"
".1.\n"
".35\n"
".5.\n"
".2.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"...\n"
"512\n"
"...\n"
".4.\n"
"5..\n"
"14.\n"
".65\n"
"625\n"
".5.\n"
"113\n"
"2.2\n"
"...\n"
"...\n"
"2.3\n"
"...\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
"...\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3..\n"
"4..\n") == 0);
free(board945638333);
board945638333 = NULL;
assert( gamma_move(board, 6, 1, 49) == 0 );
assert( gamma_move(board, 1, 39, 1) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 2, 53) == 1 );
assert( gamma_move(board, 5, 71, 0) == 0 );
assert( gamma_move(board, 6, 2, 11) == 1 );
assert( gamma_move(board, 1, 0, 24) == 0 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 2, 0, 41) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 2, 89) == 0 );
assert( gamma_move(board, 4, 2, 78) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 60, 2) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board957291852 = gamma_board(board);
assert( board957291852 != NULL );
assert( strcmp(board957291852, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"2.4\n"
"...\n"
"32.\n"
"..3\n"
"3.2\n"
"15.\n"
"565\n"
"...\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".5.\n"
"..4\n"
"...\n"
".6.\n"
".6.\n"
"63.\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"...\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
".6.\n"
"4.4\n"
"...\n"
"2.4\n"
".2.\n"
"2..\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
"55.\n"
"...\n"
"1.1\n"
"...\n"
"2.5\n"
".41\n"
"4.1\n"
"6..\n"
"...\n"
".2.\n"
".1.\n"
".35\n"
".5.\n"
".2.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"...\n"
"512\n"
"...\n"
".4.\n"
"5..\n"
"14.\n"
".65\n"
"625\n"
".5.\n"
"113\n"
"2.2\n"
"...\n"
"..2\n"
"2.3\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
"...\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3..\n"
"4..\n") == 0);
free(board957291852);
board957291852 = NULL;
assert( gamma_move(board, 1, 52, 2) == 0 );
assert( gamma_move(board, 1, 1, 87) == 1 );
assert( gamma_free_fields(board, 1) == 171 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 2, 2, 20) == 1 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_move(board, 3, 2, 52) == 1 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 1, 23) == 1 );
assert( gamma_move(board, 5, 2, 61) == 1 );
assert( gamma_move(board, 1, 1, 34) == 0 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 0, 82) == 0 );
assert( gamma_move(board, 3, 0, 32) == 1 );
assert( gamma_move(board, 4, 79, 1) == 0 );
assert( gamma_move(board, 4, 0, 53) == 0 );
assert( gamma_move(board, 5, 49, 2) == 0 );
assert( gamma_move(board, 5, 2, 26) == 0 );
assert( gamma_busy_fields(board, 5) == 25 );
assert( gamma_move(board, 6, 2, 14) == 1 );
assert( gamma_move(board, 1, 2, 72) == 1 );
assert( gamma_move(board, 1, 0, 35) == 1 );
assert( gamma_move(board, 2, 1, 37) == 1 );


char* board665847991 = gamma_board(board);
assert( board665847991 != NULL );
assert( strcmp(board665847991, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"..3\n"
"3.2\n"
"15.\n"
"565\n"
"...\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".6.\n"
"63.\n"
"...\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
".6.\n"
"4.4\n"
"...\n"
"2.4\n"
".23\n"
"2..\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
"55.\n"
"...\n"
"1.1\n"
"...\n"
"2.5\n"
".41\n"
"4.1\n"
"6..\n"
".2.\n"
".2.\n"
"11.\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"...\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
".5.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"2.3\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
"...\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3..\n"
"4..\n") == 0);
free(board665847991);
board665847991 = NULL;
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 1, 52) == 0 );
assert( gamma_move(board, 4, 2, 24) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 81) == 0 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 2, 1, 66) == 1 );
assert( gamma_move(board, 3, 32, 2) == 0 );
assert( gamma_move(board, 4, 56, 2) == 0 );
assert( gamma_move(board, 5, 1, 77) == 0 );
assert( gamma_free_fields(board, 5) == 158 );
assert( gamma_move(board, 6, 69, 0) == 0 );
assert( gamma_move(board, 6, 2, 35) == 1 );


char* board419945759 = gamma_board(board);
assert( board419945759 != NULL );
assert( strcmp(board419945759, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"..3\n"
"3.2\n"
"15.\n"
"565\n"
"...\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".6.\n"
"63.\n"
".2.\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
".6.\n"
"4.4\n"
"...\n"
"2.4\n"
".23\n"
"2..\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
"55.\n"
"...\n"
"1.1\n"
"...\n"
"2.5\n"
".41\n"
"4.1\n"
"6..\n"
".2.\n"
".2.\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"...\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
".5.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"2.3\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3..\n"
"4..\n") == 0);
free(board419945759);
board419945759 = NULL;
assert( gamma_move(board, 1, 62, 2) == 0 );
assert( gamma_move(board, 2, 0, 82) == 0 );
assert( gamma_move(board, 2, 0, 17) == 1 );
assert( gamma_golden_move(board, 2, 30, 2) == 0 );
assert( gamma_move(board, 3, 23, 2) == 0 );
assert( gamma_move(board, 3, 0, 84) == 1 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 4, 0, 56) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 80, 0) == 0 );
assert( gamma_free_fields(board, 5) == 154 );
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_move(board, 6, 2, 68) == 1 );
assert( gamma_move(board, 1, 75, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 57, 0) == 0 );
assert( gamma_move(board, 2, 2, 51) == 1 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 2, 45) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 68, 0) == 0 );
assert( gamma_move(board, 5, 62, 2) == 0 );
assert( gamma_move(board, 6, 21, 2) == 0 );


char* board957437525 = gamma_board(board);
assert( board957437525 != NULL );
assert( strcmp(board957437525, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"3.2\n"
"15.\n"
"565\n"
"...\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".2.\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
"46.\n"
"4.4\n"
"...\n"
"2.4\n"
".23\n"
"2.2\n"
".2.\n"
".4.\n"
"26.\n"
"...\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"2.5\n"
".41\n"
"4.1\n"
"6..\n"
".2.\n"
".2.\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"...\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"2.3\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3..\n"
"4..\n") == 0);
free(board957437525);
board957437525 = NULL;
assert( gamma_move(board, 1, 28, 2) == 0 );
assert( gamma_move(board, 2, 79, 2) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 65, 0) == 0 );
assert( gamma_move(board, 4, 2, 45) == 0 );
assert( gamma_move(board, 5, 44, 1) == 0 );
assert( gamma_move(board, 6, 33, 2) == 0 );
assert( gamma_move(board, 6, 2, 89) == 0 );
assert( gamma_move(board, 1, 2, 66) == 1 );
assert( gamma_move(board, 1, 1, 85) == 0 );
assert( gamma_move(board, 2, 42, 1) == 0 );
assert( gamma_move(board, 3, 47, 0) == 0 );
assert( gamma_move(board, 4, 1, 41) == 1 );
assert( gamma_move(board, 5, 2, 1) == 1 );
assert( gamma_move(board, 6, 0, 56) == 0 );
assert( gamma_move(board, 6, 2, 49) == 1 );
assert( gamma_move(board, 1, 44, 2) == 0 );
assert( gamma_move(board, 3, 85, 2) == 0 );
assert( gamma_move(board, 4, 1, 85) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board782547250 = gamma_board(board);
assert( board782547250 != NULL );
assert( strcmp(board782547250, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"3.2\n"
"15.\n"
"565\n"
"...\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
"46.\n"
"4.4\n"
"...\n"
"2.4\n"
".23\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
"...\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6..\n"
".2.\n"
".2.\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"...\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"2.3\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3.5\n"
"4..\n") == 0);
free(board782547250);
board782547250 = NULL;
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_move(board, 6, 54, 0) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_move(board, 1, 21, 2) == 0 );
assert( gamma_move(board, 2, 26, 0) == 0 );
assert( gamma_move(board, 3, 2, 38) == 1 );
assert( gamma_move(board, 3, 0, 25) == 1 );
assert( gamma_move(board, 4, 34, 0) == 0 );
assert( gamma_move(board, 4, 2, 83) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 2, 61) == 0 );
assert( gamma_move(board, 1, 69, 2) == 0 );
assert( gamma_move(board, 1, 1, 77) == 0 );
assert( gamma_move(board, 2, 0, 80) == 1 );
assert( gamma_move(board, 3, 0, 79) == 0 );
assert( gamma_move(board, 4, 62, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 62, 2) == 0 );
assert( gamma_move(board, 5, 0, 54) == 1 );
assert( gamma_move(board, 6, 69, 2) == 0 );
assert( gamma_move(board, 1, 90, 2) == 0 );


char* board730259787 = gamma_board(board);
assert( board730259787 != NULL );
assert( strcmp(board730259787, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"3.2\n"
"15.\n"
"565\n"
"2..\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
"46.\n"
"4.4\n"
"5..\n"
"2.4\n"
".23\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
"...\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6.3\n"
".2.\n"
".2.\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"2.3\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3.5\n"
"4..\n") == 0);
free(board730259787);
board730259787 = NULL;
assert( gamma_move(board, 2, 49, 0) == 0 );


char* board460388287 = gamma_board(board);
assert( board460388287 != NULL );
assert( strcmp(board460388287, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"3.2\n"
"15.\n"
"565\n"
"2..\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
"46.\n"
"4.4\n"
"5..\n"
"2.4\n"
".23\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
"...\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6.3\n"
".2.\n"
".2.\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
"...\n"
".3.\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"2.3\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3.5\n"
"4..\n") == 0);
free(board460388287);
board460388287 = NULL;
assert( gamma_move(board, 3, 1, 72) == 0 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_golden_move(board, 3, 68, 2) == 0 );
assert( gamma_move(board, 4, 66, 0) == 0 );
assert( gamma_move(board, 4, 2, 34) == 0 );
assert( gamma_free_fields(board, 4) == 142 );
assert( gamma_move(board, 6, 27, 1) == 0 );
assert( gamma_move(board, 1, 46, 0) == 0 );
assert( gamma_move(board, 1, 0, 36) == 1 );
assert( gamma_move(board, 2, 1, 29) == 1 );
assert( gamma_move(board, 3, 69, 0) == 0 );
assert( gamma_move(board, 3, 0, 36) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );


char* board958738488 = gamma_board(board);
assert( board958738488 != NULL );
assert( strcmp(board958738488, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"3.2\n"
"15.\n"
"565\n"
"2..\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
"46.\n"
"4.4\n"
"5..\n"
"2.4\n"
".23\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
"...\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6.3\n"
".2.\n"
"12.\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".3.\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3.5\n"
"4..\n") == 0);
free(board958738488);
board958738488 = NULL;
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 64, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 27 );


char* board145954652 = gamma_board(board);
assert( board145954652 != NULL );
assert( strcmp(board145954652, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"3.2\n"
"15.\n"
"565\n"
"2..\n"
"6..\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"2..\n"
"...\n"
"46.\n"
"4.4\n"
"5..\n"
"2.4\n"
".23\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
"...\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6.3\n"
".2.\n"
"12.\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".3.\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3.5\n"
"4..\n") == 0);
free(board145954652);
board145954652 = NULL;
assert( gamma_move(board, 6, 1, 47) == 1 );
assert( gamma_move(board, 6, 1, 79) == 1 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 1, 56, 2) == 0 );
assert( gamma_move(board, 1, 0, 52) == 1 );
assert( gamma_move(board, 3, 37, 2) == 0 );
assert( gamma_move(board, 3, 2, 82) == 1 );
assert( gamma_move(board, 4, 15, 1) == 0 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_move(board, 5, 1, 57) == 1 );
assert( gamma_move(board, 6, 27, 0) == 0 );
assert( gamma_move(board, 6, 1, 58) == 1 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 64, 2) == 0 );
assert( gamma_move(board, 2, 2, 56) == 1 );
assert( gamma_golden_move(board, 3, 20, 1) == 0 );


char* board576794482 = gamma_board(board);
assert( board576794482 != NULL );
assert( strcmp(board576794482, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"3.2\n"
"153\n"
"565\n"
"2..\n"
"66.\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"2.4\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".6.\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6.3\n"
".2.\n"
"12.\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".3.\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
"..6\n"
"...\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5..\n"
"3.5\n"
"4..\n") == 0);
free(board576794482);
board576794482 = NULL;
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 30, 1) == 0 );
assert( gamma_move(board, 5, 2, 36) == 1 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 1, 40, 0) == 0 );
assert( gamma_move(board, 1, 0, 80) == 0 );
assert( gamma_move(board, 2, 29, 0) == 0 );
assert( gamma_move(board, 2, 1, 49) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 66, 1) == 0 );
assert( gamma_move(board, 4, 29, 0) == 0 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 25, 2) == 0 );
assert( gamma_move(board, 6, 76, 0) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 26, 0) == 0 );
assert( gamma_move(board, 3, 1, 32) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 66, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 83) == 1 );
assert( gamma_move(board, 6, 1, 11) == 1 );
assert( gamma_move(board, 1, 37, 2) == 0 );
assert( gamma_free_fields(board, 1) == 128 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 1, 88) == 0 );


char* board822164750 = gamma_board(board);
assert( board822164750 != NULL );
assert( strcmp(board822164750, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"352\n"
"153\n"
"565\n"
"2..\n"
"66.\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"2.4\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".6.\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6.3\n"
".2.\n"
"125\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".3.\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5.4\n"
"3.5\n"
"4..\n") == 0);
free(board822164750);
board822164750 = NULL;
assert( gamma_move(board, 4, 43, 1) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 5, 1, 40) == 0 );


char* board200317791 = gamma_board(board);
assert( board200317791 != NULL );
assert( strcmp(board200317791, 
"..4\n"
"..1\n"
"161\n"
".5.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"352\n"
"153\n"
"565\n"
"2..\n"
"66.\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"2.4\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".6.\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6.3\n"
".2.\n"
"125\n"
"116\n"
".35\n"
".5.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".3.\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"5..\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5.4\n"
"3.5\n"
"4..\n") == 0);
free(board200317791);
board200317791 = NULL;
assert( gamma_move(board, 6, 63, 1) == 0 );
assert( gamma_move(board, 1, 47, 0) == 0 );
assert( gamma_golden_move(board, 1, 58, 1) == 0 );
assert( gamma_move(board, 2, 2, 28) == 1 );
assert( gamma_move(board, 2, 0, 91) == 1 );
assert( gamma_busy_fields(board, 2) == 30 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 33) == 1 );
assert( gamma_move(board, 3, 1, 21) == 1 );
assert( gamma_move(board, 4, 39, 1) == 0 );
assert( gamma_move(board, 4, 0, 38) == 0 );


char* board642519578 = gamma_board(board);
assert( board642519578 != NULL );
assert( strcmp(board642519578, 
"..4\n"
"..1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"3.3\n"
"352\n"
"153\n"
"565\n"
"2..\n"
"66.\n"
"..4\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"...\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
"...\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"2.4\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".6.\n"
"...\n"
"553\n"
"...\n"
"1.1\n"
"...\n"
"245\n"
".41\n"
"4.1\n"
"6.3\n"
".2.\n"
"125\n"
"116\n"
".35\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5.4\n"
"3.5\n"
"4..\n") == 0);
free(board642519578);
board642519578 = NULL;
assert( gamma_move(board, 5, 0, 14) == 0 );
assert( gamma_busy_fields(board, 5) == 30 );
assert( gamma_move(board, 6, 2, 45) == 0 );
assert( gamma_move(board, 6, 1, 90) == 0 );
assert( gamma_move(board, 1, 72, 0) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 90, 2) == 0 );
assert( gamma_move(board, 2, 0, 64) == 0 );
assert( gamma_move(board, 3, 70, 1) == 0 );
assert( gamma_move(board, 3, 2, 39) == 0 );
assert( gamma_free_fields(board, 3) == 124 );
assert( gamma_move(board, 4, 91, 2) == 0 );
assert( gamma_move(board, 4, 2, 70) == 1 );
assert( gamma_free_fields(board, 4) == 123 );
assert( gamma_move(board, 5, 85, 2) == 0 );
assert( gamma_move(board, 6, 78, 0) == 0 );
assert( gamma_move(board, 6, 0, 81) == 0 );
assert( gamma_move(board, 1, 0, 40) == 1 );
assert( gamma_move(board, 2, 2, 78) == 0 );
assert( gamma_move(board, 3, 62, 1) == 0 );
assert( gamma_move(board, 4, 61, 1) == 0 );
assert( gamma_move(board, 5, 42, 1) == 0 );
assert( gamma_move(board, 5, 1, 39) == 1 );
assert( gamma_move(board, 6, 1, 40) == 0 );
assert( gamma_move(board, 1, 37, 0) == 0 );
assert( gamma_move(board, 2, 2, 71) == 0 );
assert( gamma_move(board, 3, 2, 61) == 0 );
assert( gamma_move(board, 3, 1, 18) == 0 );
assert( gamma_move(board, 4, 2, 35) == 0 );
assert( gamma_move(board, 4, 1, 84) == 1 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 5, 1, 78) == 1 );
assert( gamma_move(board, 5, 2, 80) == 1 );
assert( gamma_busy_fields(board, 5) == 33 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 79, 0) == 0 );
assert( gamma_move(board, 6, 2, 44) == 1 );
assert( gamma_move(board, 1, 21, 2) == 0 );
assert( gamma_move(board, 2, 75, 0) == 0 );
assert( gamma_move(board, 4, 65, 0) == 0 );
assert( gamma_free_fields(board, 4) == 117 );
assert( gamma_move(board, 5, 23, 2) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 6, 57, 2) == 0 );
assert( gamma_move(board, 6, 1, 65) == 1 );
assert( gamma_free_fields(board, 6) == 116 );
assert( gamma_move(board, 1, 58, 2) == 0 );
assert( gamma_move(board, 2, 1, 80) == 1 );
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_move(board, 3, 2, 49) == 0 );
assert( gamma_free_fields(board, 3) == 115 );
assert( gamma_move(board, 4, 22, 2) == 0 );
assert( gamma_move(board, 5, 1, 42) == 0 );
assert( gamma_move(board, 5, 0, 91) == 0 );
assert( gamma_move(board, 6, 14, 1) == 0 );
assert( gamma_move(board, 6, 0, 32) == 0 );
assert( gamma_busy_fields(board, 6) == 27 );
assert( gamma_move(board, 1, 88, 0) == 0 );
assert( gamma_move(board, 1, 1, 33) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 2, 89) == 0 );


char* board602455538 = gamma_board(board);
assert( board602455538 != NULL );
assert( strcmp(board602455538, 
"..4\n"
"..1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
".6.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
".66\n"
"34.\n"
".51\n"
"..4\n"
"..4\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
".6.\n"
"...\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"2.4\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".6.\n"
"...\n"
"553\n"
"..6\n"
"1.1\n"
"...\n"
"245\n"
"141\n"
"451\n"
"6.3\n"
".2.\n"
"125\n"
"116\n"
".35\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"5.4\n"
"3.5\n"
"4..\n") == 0);
free(board602455538);
board602455538 = NULL;
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 5, 3, 1) == 0 );
assert( gamma_move(board, 5, 0, 71) == 0 );
assert( gamma_free_fields(board, 5) == 37 );
assert( gamma_move(board, 6, 42, 2) == 0 );
assert( gamma_move(board, 1, 88, 0) == 0 );
assert( gamma_free_fields(board, 1) == 115 );
assert( gamma_move(board, 2, 61, 1) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 4, 2, 83) == 0 );
assert( gamma_move(board, 4, 1, 92) == 0 );
assert( gamma_move(board, 5, 1, 67) == 0 );
assert( gamma_move(board, 6, 93, 1) == 0 );
assert( gamma_move(board, 1, 86, 0) == 0 );
assert( gamma_move(board, 2, 63, 2) == 0 );
assert( gamma_move(board, 2, 2, 58) == 0 );
assert( gamma_move(board, 3, 0, 42) == 1 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 4, 51, 1) == 0 );
assert( gamma_move(board, 5, 0, 89) == 0 );
assert( gamma_move(board, 5, 1, 49) == 0 );
assert( gamma_free_fields(board, 5) == 37 );
assert( gamma_move(board, 6, 0, 31) == 0 );
assert( gamma_move(board, 1, 1, 80) == 0 );
assert( gamma_move(board, 2, 30, 1) == 0 );
assert( gamma_move(board, 2, 1, 38) == 1 );
assert( gamma_move(board, 3, 62, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 62, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 75, 2) == 0 );
assert( gamma_move(board, 5, 0, 93) == 0 );
assert( gamma_move(board, 6, 2, 53) == 0 );
assert( gamma_move(board, 1, 86, 0) == 0 );
assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_free_fields(board, 1) == 112 );
assert( gamma_move(board, 2, 60, 2) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 64) == 1 );
assert( gamma_move(board, 5, 1, 46) == 1 );
assert( gamma_move(board, 6, 0, 74) == 1 );
assert( gamma_move(board, 1, 37, 2) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 78, 0) == 0 );
assert( gamma_move(board, 2, 2, 34) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 47, 0) == 0 );
assert( gamma_move(board, 3, 0, 88) == 1 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 4, 2, 80) == 0 );
assert( gamma_move(board, 5, 86, 2) == 0 );
assert( gamma_move(board, 5, 1, 76) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_move(board, 6, 1, 85) == 0 );
assert( gamma_move(board, 1, 23, 2) == 0 );
assert( gamma_move(board, 2, 1, 55) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 2, 52) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 4, 1, 53) == 1 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board951338995 = gamma_board(board);
assert( board951338995 != NULL );
assert( strcmp(board951338995, 
"..4\n"
"..1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
"..4\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
".6.\n"
"..3\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".6.\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
".35\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board951338995);
board951338995 = NULL;
assert( gamma_move(board, 6, 13, 0) == 0 );


char* board503958418 = gamma_board(board);
assert( board503958418 != NULL );
assert( strcmp(board503958418, 
"..4\n"
"..1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
"..4\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
".6.\n"
"..3\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".6.\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
".35\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3..\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board503958418);
board503958418 = NULL;
assert( gamma_move(board, 1, 49, 0) == 0 );
assert( gamma_move(board, 2, 0, 19) == 0 );
assert( gamma_move(board, 2, 0, 62) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 62, 2) == 0 );
assert( gamma_move(board, 3, 2, 25) == 1 );
assert( gamma_move(board, 4, 26, 0) == 0 );
assert( gamma_move(board, 4, 2, 47) == 1 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 5, 0, 40) == 0 );
assert( gamma_move(board, 6, 2, 55) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 1, 2, 81) == 0 );
assert( gamma_move(board, 2, 70, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 27, 0) == 0 );
assert( gamma_free_fields(board, 3) == 105 );


char* board429412201 = gamma_board(board);
assert( board429412201 != NULL );
assert( strcmp(board429412201, 
"..4\n"
"..1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
"..4\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
".6.\n"
"..3\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".64\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
".35\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board429412201);
board429412201 = NULL;
assert( gamma_move(board, 4, 0, 39) == 0 );
assert( gamma_move(board, 4, 2, 55) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board933501607 = gamma_board(board);
assert( board933501607 != NULL );
assert( strcmp(board933501607, 
"..4\n"
"..1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
"..4\n"
".6.\n"
".66\n"
"63.\n"
".21\n"
".6.\n"
"..3\n"
"1..\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".5.\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"26.\n"
".64\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
".35\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"2.2\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board933501607);
board933501607 = NULL;
assert( gamma_move(board, 5, 0, 85) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_move(board, 1, 0, 88) == 0 );
assert( gamma_move(board, 2, 86, 1) == 0 );
assert( gamma_move(board, 3, 1, 63) == 1 );
assert( gamma_move(board, 3, 2, 57) == 1 );
assert( gamma_move(board, 4, 85, 2) == 0 );
assert( gamma_move(board, 4, 0, 24) == 0 );
assert( gamma_move(board, 5, 1, 88) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_free_fields(board, 5) == 33 );
assert( gamma_move(board, 6, 0, 35) == 0 );
assert( gamma_golden_move(board, 1, 29, 1) == 0 );
assert( gamma_move(board, 2, 0, 23) == 0 );
assert( gamma_move(board, 2, 2, 82) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 88, 0) == 0 );
assert( gamma_move(board, 3, 2, 41) == 0 );
assert( gamma_move(board, 3, 0, 64) == 1 );
assert( gamma_free_fields(board, 3) == 32 );
assert( gamma_move(board, 4, 90, 2) == 0 );
assert( gamma_move(board, 5, 50, 2) == 0 );
assert( gamma_free_fields(board, 5) == 33 );
assert( gamma_move(board, 6, 76, 0) == 0 );
assert( gamma_move(board, 1, 2, 34) == 0 );
assert( gamma_move(board, 1, 0, 34) == 1 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_move(board, 3, 69, 0) == 0 );
assert( gamma_move(board, 3, 2, 67) == 1 );
assert( gamma_free_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 86, 2) == 0 );
assert( gamma_move(board, 4, 0, 36) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 5, 1, 86) == 0 );
assert( gamma_move(board, 6, 0, 14) == 0 );
assert( gamma_move(board, 6, 1, 15) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 2, 48) == 1 );
assert( gamma_free_fields(board, 1) == 98 );
assert( gamma_move(board, 2, 1, 27) == 0 );
assert( gamma_move(board, 3, 0, 66) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 4, 61, 1) == 0 );
assert( gamma_move(board, 4, 0, 79) == 0 );
assert( gamma_move(board, 5, 42, 2) == 0 );
assert( gamma_move(board, 6, 86, 1) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 1, 0, 93) == 1 );
assert( gamma_move(board, 2, 42, 2) == 0 );
assert( gamma_move(board, 3, 1, 67) == 0 );
assert( gamma_move(board, 3, 2, 60) == 0 );
assert( gamma_move(board, 4, 79, 2) == 0 );
assert( gamma_move(board, 5, 44, 0) == 0 );


char* board967104911 = gamma_board(board);
assert( board967104911 != NULL );
assert( strcmp(board967104911, 
"..4\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
"..4\n"
".6.\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"13.\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".53\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
".64\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board967104911);
board967104911 = NULL;
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 1, 2, 93) == 0 );
assert( gamma_move(board, 2, 26, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 6, 33, 2) == 0 );
assert( gamma_move(board, 6, 1, 70) == 1 );
assert( gamma_move(board, 1, 71, 1) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 3, 1, 94) == 0 );
assert( gamma_move(board, 4, 62, 1) == 0 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 6, 2, 81) == 0 );
assert( gamma_move(board, 1, 64, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 84, 0) == 0 );
assert( gamma_move(board, 2, 37, 0) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 3, 1, 43) == 0 );
assert( gamma_move(board, 4, 2, 36) == 0 );
assert( gamma_golden_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 5, 0, 79) == 0 );


char* board322987808 = gamma_board(board);
assert( board322987808 != NULL );
assert( strcmp(board322987808, 
"..4\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
".64\n"
".6.\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"13.\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".53\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
".64\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board322987808);
board322987808 = NULL;
assert( gamma_move(board, 6, 21, 2) == 0 );
assert( gamma_move(board, 2, 2, 94) == 0 );
assert( gamma_move(board, 3, 75, 1) == 0 );
assert( gamma_move(board, 3, 2, 43) == 0 );


char* board981132749 = gamma_board(board);
assert( board981132749 != NULL );
assert( strcmp(board981132749, 
"..4\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
".64\n"
".6.\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"13.\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".53\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
".64\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"...\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
".4.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board981132749);
board981132749 = NULL;
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 1, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 63, 2) == 0 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_move(board, 1, 31, 1) == 0 );
assert( gamma_move(board, 1, 1, 21) == 0 );
assert( gamma_free_fields(board, 1) == 96 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_free_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 0, 82) == 0 );
assert( gamma_move(board, 4, 1, 60) == 0 );
assert( gamma_move(board, 6, 1, 60) == 0 );
assert( gamma_busy_fields(board, 6) == 30 );
assert( gamma_free_fields(board, 6) == 96 );
assert( gamma_move(board, 2, 27, 2) == 0 );
assert( gamma_move(board, 3, 2, 89) == 0 );
assert( gamma_move(board, 4, 70, 0) == 0 );
assert( gamma_free_fields(board, 4) == 96 );
assert( gamma_move(board, 5, 90, 2) == 0 );
assert( gamma_move(board, 5, 0, 90) == 0 );
assert( gamma_free_fields(board, 5) == 33 );
assert( gamma_move(board, 6, 0, 51) == 0 );
assert( gamma_move(board, 1, 37, 2) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 61) == 0 );
assert( gamma_move(board, 3, 2, 70) == 0 );
assert( gamma_move(board, 4, 0, 22) == 1 );
assert( gamma_move(board, 5, 69, 2) == 0 );
assert( gamma_move(board, 6, 0, 27) == 1 );
assert( gamma_move(board, 6, 2, 31) == 0 );
assert( gamma_move(board, 1, 23, 2) == 0 );
assert( gamma_move(board, 2, 57, 0) == 0 );
assert( gamma_move(board, 2, 1, 24) == 0 );


char* board567068656 = gamma_board(board);
assert( board567068656 != NULL );
assert( strcmp(board567068656, 
"..4\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
".64\n"
".6.\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"13.\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".53\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
".64\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"6..\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
"44.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board567068656);
board567068656 = NULL;
assert( gamma_move(board, 3, 2, 22) == 0 );
assert( gamma_move(board, 3, 2, 44) == 0 );


char* board996132134 = gamma_board(board);
assert( board996132134 != NULL );
assert( strcmp(board996132134, 
"..4\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"...\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
".64\n"
".6.\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"13.\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".53\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
".64\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"35.\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"6..\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
"44.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board996132134);
board996132134 = NULL;
assert( gamma_move(board, 4, 60, 0) == 0 );
assert( gamma_move(board, 4, 2, 33) == 1 );
assert( gamma_move(board, 5, 43, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_free_fields(board, 6) == 93 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 1, 2, 75) == 1 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 65, 0) == 0 );
assert( gamma_move(board, 3, 26, 0) == 0 );


char* board261229120 = gamma_board(board);
assert( board261229120 != NULL );
assert( strcmp(board261229120, 
"..4\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"..1\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
".64\n"
".6.\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"13.\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
".53\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
".64\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"354\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"6..\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
"44.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"52.\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board261229120);
board261229120 = NULL;
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 2, 30) == 0 );
assert( gamma_move(board, 5, 61, 1) == 0 );
assert( gamma_move(board, 5, 2, 59) == 0 );
assert( gamma_move(board, 6, 65, 0) == 0 );
assert( gamma_move(board, 6, 0, 31) == 0 );
assert( gamma_move(board, 1, 1, 72) == 0 );
assert( gamma_move(board, 2, 50, 0) == 0 );
assert( gamma_move(board, 2, 0, 22) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 28, 0) == 0 );
assert( gamma_move(board, 4, 64, 1) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 5, 22, 2) == 0 );
assert( gamma_move(board, 6, 75, 1) == 0 );
assert( gamma_move(board, 6, 1, 70) == 0 );
assert( gamma_move(board, 1, 62, 2) == 0 );
assert( gamma_move(board, 1, 0, 73) == 0 );
assert( gamma_move(board, 2, 61, 0) == 0 );
assert( gamma_move(board, 2, 2, 51) == 0 );
assert( gamma_move(board, 3, 59, 1) == 0 );
assert( gamma_move(board, 3, 2, 76) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 4, 1, 57) == 0 );
assert( gamma_move(board, 5, 2, 43) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_free_fields(board, 5) == 31 );
assert( gamma_move(board, 6, 44, 0) == 0 );
assert( gamma_move(board, 6, 2, 92) == 0 );
assert( gamma_move(board, 1, 57, 0) == 0 );
assert( gamma_move(board, 1, 2, 71) == 0 );
assert( gamma_move(board, 2, 75, 1) == 0 );
assert( gamma_move(board, 2, 0, 68) == 0 );
assert( gamma_move(board, 3, 59, 1) == 0 );
assert( gamma_move(board, 3, 1, 29) == 0 );
assert( gamma_move(board, 5, 62, 2) == 0 );
assert( gamma_move(board, 5, 0, 36) == 0 );
assert( gamma_move(board, 6, 0, 32) == 0 );
assert( gamma_move(board, 6, 2, 63) == 1 );
assert( gamma_move(board, 1, 30, 1) == 0 );
assert( gamma_move(board, 2, 64, 1) == 0 );
assert( gamma_move(board, 2, 0, 64) == 0 );
assert( gamma_move(board, 3, 2, 34) == 0 );
assert( gamma_move(board, 4, 86, 2) == 0 );
assert( gamma_move(board, 4, 0, 43) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 93) == 0 );
assert( gamma_move(board, 5, 0, 70) == 0 );
assert( gamma_move(board, 6, 0, 47) == 1 );
assert( gamma_busy_fields(board, 6) == 33 );
assert( gamma_move(board, 1, 54, 2) == 0 );
assert( gamma_move(board, 1, 0, 57) == 1 );
assert( gamma_golden_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 0, 67) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 28, 0) == 0 );
assert( gamma_move(board, 3, 2, 34) == 0 );
assert( gamma_move(board, 4, 59, 1) == 0 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 1, 2, 38) == 0 );
assert( gamma_move(board, 2, 25, 1) == 0 );
assert( gamma_move(board, 2, 2, 46) == 0 );
assert( gamma_move(board, 3, 0, 70) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 1, 94) == 1 );
assert( gamma_move(board, 5, 62, 1) == 0 );
assert( gamma_move(board, 5, 1, 18) == 0 );
assert( gamma_golden_move(board, 5, 52, 1) == 0 );
assert( gamma_move(board, 6, 23, 2) == 0 );
assert( gamma_move(board, 1, 65, 0) == 0 );
assert( gamma_move(board, 2, 50, 2) == 0 );


char* board613683920 = gamma_board(board);
assert( board613683920 != NULL );
assert( strcmp(board613683920, 
".44\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"..1\n"
"666\n"
"34.\n"
".51\n"
"..4\n"
".64\n"
".6.\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"136\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
"153\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
"664\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"354\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"6..\n"
".15\n"
"3.3\n"
"512\n"
".5.\n"
"44.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"525\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.5\n"
"4..\n") == 0);
free(board613683920);
board613683920 = NULL;
assert( gamma_move(board, 3, 2, 51) == 0 );
assert( gamma_move(board, 3, 1, 55) == 0 );
assert( gamma_move(board, 4, 58, 2) == 0 );
assert( gamma_move(board, 6, 2, 92) == 0 );
assert( gamma_move(board, 6, 2, 89) == 0 );
assert( gamma_move(board, 1, 0, 36) == 0 );
assert( gamma_busy_fields(board, 1) == 34 );
assert( gamma_golden_move(board, 1, 32, 2) == 0 );
assert( gamma_move(board, 2, 0, 89) == 0 );
assert( gamma_move(board, 2, 0, 75) == 0 );
assert( gamma_free_fields(board, 2) == 26 );
assert( gamma_move(board, 5, 2, 47) == 0 );
assert( gamma_busy_fields(board, 5) == 35 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 6, 1, 56) == 0 );
assert( gamma_move(board, 1, 1, 48) == 0 );
assert( gamma_move(board, 1, 1, 29) == 0 );
assert( gamma_move(board, 2, 2, 22) == 0 );
assert( gamma_free_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 37, 0) == 0 );
assert( gamma_move(board, 3, 0, 85) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_free_fields(board, 4) == 87 );
assert( gamma_move(board, 5, 29, 2) == 0 );
assert( gamma_move(board, 6, 2, 92) == 0 );
assert( gamma_move(board, 6, 0, 23) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 2, 23) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 46, 0) == 0 );
assert( gamma_golden_move(board, 4, 2, 1) == 1 );
assert( gamma_move(board, 5, 37, 2) == 0 );
assert( gamma_move(board, 6, 2, 69) == 1 );
assert( gamma_move(board, 1, 86, 2) == 0 );
assert( gamma_move(board, 1, 1, 33) == 0 );
assert( gamma_move(board, 2, 94, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 17, 2) == 0 );
assert( gamma_move(board, 3, 0, 77) == 0 );
assert( gamma_move(board, 4, 90, 0) == 0 );
assert( gamma_move(board, 4, 0, 72) == 1 );
assert( gamma_move(board, 5, 0, 62) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 35 );
assert( gamma_move(board, 1, 0, 17) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );


char* board394053277 = gamma_board(board);
assert( board394053277 != NULL );
assert( strcmp(board394053277, 
".44\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"...\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"..1\n"
"666\n"
"34.\n"
"451\n"
"..4\n"
".64\n"
".66\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"136\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
"153\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
"664\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"354\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"6..\n"
".15\n"
"3.3\n"
"512\n"
"651\n"
"44.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"..2\n"
"233\n"
".66\n"
"4..\n"
"525\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.4\n"
"4..\n") == 0);
free(board394053277);
board394053277 = NULL;
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_move(board, 3, 90, 0) == 0 );
assert( gamma_move(board, 4, 2, 86) == 1 );
assert( gamma_move(board, 4, 2, 77) == 0 );
assert( gamma_free_fields(board, 4) == 82 );
assert( gamma_golden_move(board, 4, 17, 0) == 0 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 35 );
assert( gamma_free_fields(board, 6) == 82 );
assert( gamma_move(board, 1, 2, 77) == 0 );
assert( gamma_move(board, 2, 0, 72) == 0 );
assert( gamma_move(board, 3, 1, 88) == 0 );
assert( gamma_move(board, 3, 0, 54) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 48) == 0 );
assert( gamma_move(board, 4, 0, 83) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 2, 69) == 0 );
assert( gamma_move(board, 5, 2, 56) == 0 );
assert( gamma_move(board, 6, 1, 74) == 0 );
assert( gamma_move(board, 6, 0, 55) == 0 );
assert( gamma_move(board, 1, 44, 1) == 0 );
assert( gamma_move(board, 1, 0, 71) == 1 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 2, 1, 45) == 0 );
assert( gamma_move(board, 3, 1, 63) == 0 );
assert( gamma_move(board, 4, 90, 0) == 0 );
assert( gamma_move(board, 5, 0, 85) == 0 );
assert( gamma_golden_move(board, 5, 43, 0) == 0 );
assert( gamma_move(board, 1, 77, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 46, 2) == 0 );
assert( gamma_move(board, 2, 0, 13) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 3, 2, 92) == 0 );
assert( gamma_move(board, 4, 58, 2) == 0 );
assert( gamma_move(board, 4, 2, 80) == 0 );
assert( gamma_free_fields(board, 4) == 80 );
assert( gamma_move(board, 5, 0, 64) == 0 );
assert( gamma_move(board, 5, 0, 63) == 0 );


char* board935637042 = gamma_board(board);
assert( board935637042 != NULL );
assert( strcmp(board935637042, 
".44\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"..4\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"..1\n"
"666\n"
"34.\n"
"451\n"
"1.4\n"
".64\n"
".66\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"136\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
"153\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
"664\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"354\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"6..\n"
".15\n"
"3.3\n"
"512\n"
"651\n"
"44.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"2.2\n"
"233\n"
".66\n"
"4..\n"
"525\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.4\n"
"4..\n") == 0);
free(board935637042);
board935637042 = NULL;
assert( gamma_move(board, 6, 0, 41) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 66, 0) == 0 );
assert( gamma_move(board, 2, 2, 27) == 1 );


char* board667454010 = gamma_board(board);
assert( board667454010 != NULL );
assert( strcmp(board667454010, 
".44\n"
"1.1\n"
"161\n"
"25.\n"
".1.\n"
"..6\n"
"36.\n"
"214\n"
"..4\n"
"32.\n"
"343\n"
"352\n"
"153\n"
"565\n"
"225\n"
"66.\n"
".54\n"
".25\n"
"..6\n"
"..1\n"
"666\n"
"34.\n"
"451\n"
"1.4\n"
".64\n"
".66\n"
".66\n"
"633\n"
".21\n"
".6.\n"
"3.3\n"
"136\n"
"1..\n"
"..5\n"
".5.\n"
"3..\n"
"26.\n"
"153\n"
"462\n"
"4.4\n"
"5..\n"
"244\n"
"123\n"
"2.2\n"
".2.\n"
".46\n"
"261\n"
"664\n"
".5.\n"
"553\n"
"..6\n"
"1.1\n"
"3..\n"
"245\n"
"141\n"
"451\n"
"623\n"
".2.\n"
"125\n"
"116\n"
"135\n"
"354\n"
"32.\n"
"4.3\n"
"1.5\n"
".2.\n"
".32\n"
"6.2\n"
".15\n"
"3.3\n"
"512\n"
"651\n"
"44.\n"
"53.\n"
"142\n"
".65\n"
"625\n"
"25.\n"
"113\n"
"262\n"
"3.6\n"
"2.2\n"
"233\n"
".66\n"
"4..\n"
"525\n"
"..5\n"
".44\n"
".31\n"
"314\n"
"351\n"
"..3\n"
"514\n"
"3.4\n"
"4..\n") == 0);
free(board667454010);
board667454010 = NULL;
assert( gamma_move(board, 4, 1, 52) == 0 );
assert( gamma_move(board, 5, 61, 1) == 0 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_golden_move(board, 5, 43, 2) == 0 );
assert( gamma_move(board, 6, 17, 2) == 0 );
assert( gamma_move(board, 1, 2, 71) == 0 );
assert( gamma_move(board, 1, 0, 58) == 0 );
assert( gamma_move(board, 2, 1, 69) == 0 );
assert( gamma_move(board, 3, 2, 32) == 1 );
assert( gamma_move(board, 4, 2, 61) == 0 );
assert( gamma_move(board, 5, 0, 15) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 19, 0) == 0 );


gamma_delete(board);

    return 0;
}
