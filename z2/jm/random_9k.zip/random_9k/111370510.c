#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 111370510
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 187, 6, 16);
assert( board != NULL );


assert( gamma_move(board, 1, 88, 0) == 0 );
assert( gamma_move(board, 2, 0, 21) == 1 );
assert( gamma_move(board, 2, 0, 84) == 1 );
assert( gamma_move(board, 3, 170, 0) == 0 );
assert( gamma_move(board, 3, 0, 111) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 5, 173, 0) == 0 );
assert( gamma_free_fields(board, 5) == 183 );
assert( gamma_move(board, 6, 85, 0) == 0 );
assert( gamma_move(board, 6, 0, 166) == 1 );
assert( gamma_busy_fields(board, 1) == 0 );
assert( gamma_move(board, 2, 129, 0) == 0 );
assert( gamma_move(board, 3, 20, 0) == 0 );
assert( gamma_move(board, 3, 0, 114) == 1 );
assert( gamma_move(board, 4, 0, 152) == 1 );
assert( gamma_move(board, 4, 0, 113) == 1 );
assert( gamma_move(board, 5, 0, 34) == 1 );
assert( gamma_free_fields(board, 5) == 178 );
assert( gamma_move(board, 6, 185, 0) == 0 );
assert( gamma_move(board, 1, 0, 33) == 1 );
assert( gamma_move(board, 3, 86, 0) == 0 );
assert( gamma_move(board, 4, 0, 81) == 1 );
assert( gamma_move(board, 4, 0, 27) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 5, 181, 0) == 0 );
assert( gamma_move(board, 5, 0, 162) == 1 );
assert( gamma_move(board, 6, 118, 0) == 0 );
assert( gamma_move(board, 6, 0, 180) == 1 );
assert( gamma_move(board, 1, 0, 114) == 0 );
assert( gamma_move(board, 2, 0, 114) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 126) == 1 );
assert( gamma_move(board, 4, 59, 0) == 0 );
assert( gamma_move(board, 4, 0, 59) == 1 );
assert( gamma_move(board, 5, 176, 0) == 0 );
assert( gamma_move(board, 5, 0, 37) == 1 );
assert( gamma_golden_move(board, 5, 111, 0) == 0 );
assert( gamma_move(board, 6, 0, 120) == 1 );
assert( gamma_move(board, 1, 134, 0) == 0 );
assert( gamma_move(board, 1, 0, 175) == 1 );
assert( gamma_move(board, 2, 0, 175) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 111, 0) == 0 );
assert( gamma_move(board, 3, 0, 53) == 1 );
assert( gamma_move(board, 3, 0, 183) == 1 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_golden_move(board, 4, 175, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 0, 10) == 1 );
assert( gamma_golden_move(board, 6, 14, 0) == 0 );
assert( gamma_move(board, 2, 0, 88) == 1 );
assert( gamma_free_fields(board, 2) == 164 );
assert( gamma_move(board, 3, 0, 120) == 0 );
assert( gamma_move(board, 4, 86, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 135, 0) == 0 );
assert( gamma_move(board, 1, 122, 0) == 0 );
assert( gamma_move(board, 1, 0, 107) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 53, 0) == 0 );
assert( gamma_move(board, 2, 0, 100) == 1 );
assert( gamma_move(board, 2, 0, 162) == 0 );
assert( gamma_move(board, 3, 118, 0) == 0 );
assert( gamma_move(board, 4, 0, 136) == 1 );
assert( gamma_move(board, 4, 0, 22) == 1 );
assert( gamma_move(board, 5, 178, 0) == 0 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 6, 0, 24) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 1, 0, 85) == 1 );
assert( gamma_move(board, 2, 150, 0) == 0 );
assert( gamma_move(board, 2, 0, 116) == 1 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_move(board, 4, 0, 129) == 1 );
assert( gamma_move(board, 4, 0, 24) == 0 );
assert( gamma_move(board, 5, 0, 88) == 0 );
assert( gamma_move(board, 5, 0, 101) == 1 );
assert( gamma_free_fields(board, 5) == 154 );
assert( gamma_move(board, 6, 89, 0) == 0 );
assert( gamma_move(board, 6, 0, 150) == 1 );
assert( gamma_move(board, 1, 0, 150) == 0 );
assert( gamma_golden_move(board, 1, 84, 0) == 0 );
assert( gamma_move(board, 2, 140, 0) == 0 );
assert( gamma_move(board, 2, 0, 41) == 1 );
assert( gamma_move(board, 3, 125, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_move(board, 4, 96, 0) == 0 );
assert( gamma_move(board, 4, 0, 33) == 0 );
assert( gamma_free_fields(board, 4) == 152 );
assert( gamma_move(board, 5, 0, 162) == 0 );
assert( gamma_free_fields(board, 5) == 152 );
assert( gamma_move(board, 6, 38, 0) == 0 );
assert( gamma_move(board, 6, 0, 126) == 0 );
assert( gamma_move(board, 1, 0, 126) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 86, 0) == 0 );
assert( gamma_golden_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_golden_move(board, 3, 37, 0) == 0 );
assert( gamma_move(board, 4, 0, 56) == 1 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_move(board, 5, 98, 0) == 0 );
assert( gamma_move(board, 6, 103, 0) == 0 );
assert( gamma_move(board, 6, 0, 148) == 1 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 1, 73, 0) == 0 );
assert( gamma_move(board, 2, 174, 0) == 0 );
assert( gamma_move(board, 3, 97, 0) == 0 );
assert( gamma_move(board, 3, 0, 173) == 1 );
assert( gamma_move(board, 4, 185, 0) == 0 );
assert( gamma_move(board, 4, 0, 147) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 76, 0) == 0 );
assert( gamma_move(board, 6, 0, 106) == 1 );
assert( gamma_move(board, 6, 0, 170) == 1 );
assert( gamma_move(board, 1, 0, 60) == 1 );
assert( gamma_move(board, 2, 139, 0) == 0 );
assert( gamma_move(board, 3, 0, 146) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 59) == 0 );
assert( gamma_move(board, 5, 0, 116) == 0 );
assert( gamma_move(board, 5, 0, 17) == 1 );
assert( gamma_golden_move(board, 5, 81, 0) == 0 );
assert( gamma_move(board, 6, 133, 0) == 0 );
assert( gamma_move(board, 6, 0, 68) == 1 );
assert( gamma_move(board, 1, 0, 110) == 1 );
assert( gamma_free_fields(board, 1) == 140 );
assert( gamma_move(board, 2, 65, 0) == 0 );
assert( gamma_move(board, 2, 0, 148) == 0 );
assert( gamma_busy_fields(board, 2) == 6 );
assert( gamma_move(board, 3, 48, 0) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 4, 0, 143) == 1 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 0, 68) == 0 );
assert( gamma_move(board, 6, 0, 90) == 1 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 1, 0, 36) == 1 );
assert( gamma_move(board, 2, 47, 0) == 0 );
assert( gamma_move(board, 2, 0, 66) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 178) == 1 );
assert( gamma_move(board, 4, 48, 0) == 0 );
assert( gamma_move(board, 5, 0, 108) == 1 );
assert( gamma_golden_move(board, 5, 146, 0) == 0 );


char* board599506124 = gamma_board(board);
assert( board599506124 != NULL );
assert( strcmp(board599506124, 
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"3\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
".\n"
"5\n"
"1\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
".\n") == 0);
free(board599506124);
board599506124 = NULL;
assert( gamma_move(board, 6, 154, 0) == 0 );
assert( gamma_move(board, 6, 0, 18) == 1 );
assert( gamma_move(board, 1, 102, 0) == 0 );
assert( gamma_move(board, 1, 0, 143) == 0 );
assert( gamma_move(board, 2, 0, 95) == 1 );
assert( gamma_free_fields(board, 2) == 132 );
assert( gamma_move(board, 3, 179, 0) == 0 );
assert( gamma_move(board, 3, 0, 151) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 116, 0) == 0 );
assert( gamma_move(board, 4, 23, 0) == 0 );
assert( gamma_move(board, 4, 0, 132) == 1 );
assert( gamma_move(board, 5, 35, 0) == 0 );
assert( gamma_move(board, 6, 160, 0) == 0 );
assert( gamma_move(board, 6, 0, 180) == 0 );
assert( gamma_move(board, 1, 0, 34) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 3, 0, 48) == 1 );
assert( gamma_move(board, 3, 0, 58) == 1 );
assert( gamma_move(board, 4, 25, 0) == 0 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 6, 161, 0) == 0 );
assert( gamma_move(board, 6, 0, 0) == 1 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_move(board, 1, 0, 145) == 1 );
assert( gamma_move(board, 1, 0, 106) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_golden_move(board, 1, 151, 0) == 0 );
assert( gamma_move(board, 2, 138, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_free_fields(board, 3) == 125 );
assert( gamma_move(board, 4, 75, 0) == 0 );
assert( gamma_free_fields(board, 4) == 125 );
assert( gamma_move(board, 5, 67, 0) == 0 );
assert( gamma_move(board, 5, 0, 92) == 1 );


char* board675340279 = gamma_board(board);
assert( board675340279 != NULL );
assert( strcmp(board675340279, 
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"3\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
".\n"
"5\n"
"1\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"4\n"
"4\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
".\n"
"6\n") == 0);
free(board675340279);
board675340279 = NULL;
assert( gamma_move(board, 6, 29, 0) == 0 );
assert( gamma_move(board, 6, 0, 39) == 1 );
assert( gamma_move(board, 1, 51, 0) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_move(board, 4, 70, 0) == 0 );
assert( gamma_move(board, 4, 0, 156) == 1 );
assert( gamma_move(board, 5, 57, 0) == 0 );
assert( gamma_move(board, 6, 160, 0) == 0 );
assert( gamma_move(board, 1, 29, 0) == 0 );
assert( gamma_move(board, 1, 0, 90) == 0 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 0, 94) == 1 );
assert( gamma_move(board, 2, 0, 97) == 1 );
assert( gamma_free_fields(board, 2) == 118 );
assert( gamma_move(board, 3, 186, 0) == 0 );
assert( gamma_move(board, 3, 0, 161) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 157, 0) == 0 );
assert( gamma_move(board, 5, 0, 158) == 1 );
assert( gamma_move(board, 6, 0, 78) == 1 );
assert( gamma_move(board, 6, 0, 52) == 1 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_move(board, 1, 57, 0) == 0 );
assert( gamma_move(board, 1, 0, 78) == 0 );
assert( gamma_move(board, 2, 98, 0) == 0 );
assert( gamma_move(board, 2, 0, 105) == 1 );
assert( gamma_move(board, 3, 0, 18) == 0 );
assert( gamma_move(board, 3, 0, 57) == 1 );
assert( gamma_move(board, 4, 109, 0) == 0 );
assert( gamma_move(board, 5, 176, 0) == 0 );
assert( gamma_move(board, 6, 76, 0) == 0 );
assert( gamma_free_fields(board, 6) == 23 );
assert( gamma_move(board, 1, 0, 23) == 1 );
assert( gamma_move(board, 2, 0, 184) == 1 );
assert( gamma_move(board, 3, 30, 0) == 0 );
assert( gamma_move(board, 3, 0, 49) == 1 );
assert( gamma_move(board, 4, 80, 0) == 0 );
assert( gamma_move(board, 5, 46, 0) == 0 );
assert( gamma_move(board, 5, 0, 177) == 1 );
assert( gamma_golden_move(board, 5, 17, 0) == 0 );
assert( gamma_move(board, 6, 50, 0) == 0 );
assert( gamma_move(board, 6, 0, 88) == 0 );
assert( gamma_move(board, 1, 77, 0) == 0 );
assert( gamma_free_fields(board, 1) == 108 );
assert( gamma_golden_move(board, 1, 105, 0) == 0 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_free_fields(board, 2) == 107 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 180) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 32, 0) == 0 );
assert( gamma_move(board, 4, 0, 151) == 0 );
assert( gamma_move(board, 5, 76, 0) == 0 );
assert( gamma_move(board, 6, 185, 0) == 0 );
assert( gamma_move(board, 1, 0, 44) == 1 );
assert( gamma_move(board, 2, 47, 0) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 77, 0) == 0 );
assert( gamma_free_fields(board, 3) == 106 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 123) == 1 );
assert( gamma_move(board, 4, 0, 24) == 0 );
assert( gamma_move(board, 5, 128, 0) == 0 );
assert( gamma_free_fields(board, 5) == 105 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 6, 0, 117) == 0 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_move(board, 1, 102, 0) == 0 );
assert( gamma_move(board, 2, 25, 0) == 0 );
assert( gamma_move(board, 2, 0, 130) == 1 );
assert( gamma_move(board, 3, 50, 0) == 0 );
assert( gamma_move(board, 3, 0, 151) == 0 );
assert( gamma_move(board, 4, 42, 0) == 0 );
assert( gamma_move(board, 4, 0, 45) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 5, 55, 0) == 0 );
assert( gamma_move(board, 5, 0, 184) == 0 );
assert( gamma_free_fields(board, 5) == 104 );
assert( gamma_move(board, 6, 0, 120) == 0 );
assert( gamma_move(board, 1, 0, 122) == 1 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 171, 0) == 0 );
assert( gamma_move(board, 3, 0, 71) == 1 );
assert( gamma_golden_move(board, 3, 56, 0) == 0 );
assert( gamma_move(board, 4, 138, 0) == 0 );
assert( gamma_move(board, 5, 155, 0) == 0 );
assert( gamma_move(board, 6, 0, 64) == 0 );
assert( gamma_move(board, 1, 55, 0) == 0 );
assert( gamma_golden_move(board, 1, 166, 0) == 0 );
assert( gamma_move(board, 2, 0, 129) == 0 );
assert( gamma_move(board, 3, 0, 72) == 1 );
assert( gamma_move(board, 4, 0, 6) == 1 );
assert( gamma_move(board, 5, 127, 0) == 0 );
assert( gamma_move(board, 5, 0, 182) == 1 );
assert( gamma_golden_move(board, 5, 143, 0) == 0 );
assert( gamma_move(board, 6, 0, 63) == 0 );
assert( gamma_move(board, 1, 0, 49) == 0 );
assert( gamma_move(board, 2, 30, 0) == 0 );
assert( gamma_move(board, 2, 0, 162) == 0 );
assert( gamma_move(board, 3, 0, 103) == 1 );
assert( gamma_move(board, 3, 0, 96) == 1 );
assert( gamma_move(board, 4, 0, 185) == 0 );
assert( gamma_move(board, 5, 0, 41) == 0 );
assert( gamma_move(board, 6, 131, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 43, 0) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_free_fields(board, 1) == 97 );
assert( gamma_golden_move(board, 1, 88, 0) == 0 );
assert( gamma_move(board, 2, 117, 0) == 0 );
assert( gamma_move(board, 2, 0, 45) == 1 );
assert( gamma_move(board, 3, 138, 0) == 0 );
assert( gamma_move(board, 4, 185, 0) == 0 );
assert( gamma_move(board, 5, 0, 181) == 1 );
assert( gamma_move(board, 5, 0, 43) == 1 );
assert( gamma_move(board, 6, 124, 0) == 0 );
assert( gamma_move(board, 6, 0, 96) == 0 );
assert( gamma_move(board, 1, 35, 0) == 0 );
assert( gamma_move(board, 2, 0, 99) == 1 );
assert( gamma_move(board, 2, 0, 60) == 0 );
assert( gamma_free_fields(board, 2) == 93 );
assert( gamma_move(board, 3, 174, 0) == 0 );
assert( gamma_move(board, 3, 0, 96) == 0 );
assert( gamma_move(board, 4, 121, 0) == 0 );
assert( gamma_move(board, 4, 0, 161) == 0 );
assert( gamma_move(board, 5, 38, 0) == 0 );
assert( gamma_move(board, 5, 0, 137) == 1 );
assert( gamma_move(board, 6, 186, 0) == 0 );
assert( gamma_move(board, 1, 102, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 67) == 1 );
assert( gamma_move(board, 2, 0, 109) == 1 );
assert( gamma_move(board, 3, 30, 0) == 0 );
assert( gamma_move(board, 3, 0, 158) == 0 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 87, 0) == 0 );
assert( gamma_move(board, 4, 0, 51) == 0 );
assert( gamma_move(board, 5, 0, 168) == 1 );
assert( gamma_free_fields(board, 5) == 89 );
assert( gamma_move(board, 6, 80, 0) == 0 );
assert( gamma_move(board, 6, 0, 32) == 0 );
assert( gamma_move(board, 1, 73, 0) == 0 );
assert( gamma_move(board, 1, 0, 27) == 0 );
assert( gamma_move(board, 2, 0, 117) == 1 );
assert( gamma_free_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 0, 94) == 0 );
assert( gamma_move(board, 3, 0, 105) == 0 );
assert( gamma_move(board, 4, 104, 0) == 0 );
assert( gamma_move(board, 4, 0, 127) == 0 );
assert( gamma_move(board, 5, 80, 0) == 0 );
assert( gamma_move(board, 6, 26, 0) == 0 );
assert( gamma_move(board, 6, 0, 113) == 0 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_move(board, 1, 0, 56) == 0 );
assert( gamma_move(board, 2, 133, 0) == 0 );
assert( gamma_move(board, 3, 0, 46) == 1 );
assert( gamma_move(board, 4, 0, 64) == 0 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 5, 0, 155) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 110) == 0 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 2, 38, 0) == 0 );
assert( gamma_move(board, 3, 179, 0) == 0 );
assert( gamma_move(board, 4, 112, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 5, 0, 161) == 0 );
assert( gamma_move(board, 6, 0, 11) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_free_fields(board, 6) == 19 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 28) == 1 );
assert( gamma_move(board, 1, 0, 39) == 0 );
assert( gamma_golden_move(board, 1, 114, 0) == 0 );
assert( gamma_move(board, 2, 0, 85) == 0 );
assert( gamma_move(board, 3, 124, 0) == 0 );
assert( gamma_move(board, 3, 0, 175) == 0 );
assert( gamma_move(board, 4, 131, 0) == 0 );
assert( gamma_move(board, 5, 125, 0) == 0 );
assert( gamma_move(board, 1, 0, 66) == 0 );
assert( gamma_move(board, 2, 128, 0) == 0 );
assert( gamma_move(board, 2, 0, 175) == 0 );
assert( gamma_move(board, 3, 149, 0) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 65, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 6, 19, 0) == 0 );
assert( gamma_move(board, 6, 0, 59) == 0 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 1, 0, 163) == 1 );
assert( gamma_free_fields(board, 1) == 84 );
assert( gamma_move(board, 2, 74, 0) == 0 );
assert( gamma_move(board, 2, 0, 153) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 41) == 0 );
assert( gamma_move(board, 4, 69, 0) == 0 );
assert( gamma_move(board, 4, 0, 57) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 131, 0) == 0 );
assert( gamma_free_fields(board, 5) == 84 );
assert( gamma_move(board, 6, 0, 142) == 0 );
assert( gamma_move(board, 6, 0, 125) == 0 );
assert( gamma_free_fields(board, 6) == 19 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 2, 157, 0) == 0 );
assert( gamma_move(board, 2, 0, 154) == 0 );


char* board644895353 = gamma_board(board);
assert( board644895353 != NULL );
assert( strcmp(board644895353, 
".\n"
".\n"
"2\n"
"3\n"
"5\n"
"5\n"
"6\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
"2\n"
"5\n"
"1\n"
"6\n"
"2\n"
".\n"
"3\n"
".\n"
"5\n"
"2\n"
"2\n"
".\n"
"2\n"
"3\n"
"2\n"
"2\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"6\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
"3\n"
"4\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
"3\n"
"2\n"
"1\n"
"5\n"
".\n"
"2\n"
".\n"
"6\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"6\n"
"1\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
"6\n"
".\n"
"4\n"
"4\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"2\n"
"6\n") == 0);
free(board644895353);
board644895353 = NULL;
assert( gamma_move(board, 3, 26, 0) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 4, 164, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 0, 107) == 0 );


char* board249653751 = gamma_board(board);
assert( board249653751 != NULL );
assert( strcmp(board249653751, 
".\n"
".\n"
"2\n"
"3\n"
"5\n"
"5\n"
"6\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
"2\n"
"5\n"
"1\n"
"6\n"
"2\n"
".\n"
"3\n"
".\n"
"5\n"
"2\n"
"2\n"
".\n"
"2\n"
"3\n"
"2\n"
"2\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"6\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
"3\n"
"4\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
"3\n"
"2\n"
"1\n"
"5\n"
".\n"
"2\n"
".\n"
"6\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"6\n"
"1\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
"6\n"
".\n"
"4\n"
"4\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"2\n"
"6\n") == 0);
free(board249653751);
board249653751 = NULL;
assert( gamma_move(board, 6, 62, 0) == 0 );
assert( gamma_move(board, 6, 0, 16) == 0 );
assert( gamma_golden_move(board, 6, 147, 0) == 0 );
assert( gamma_move(board, 1, 80, 0) == 0 );
assert( gamma_move(board, 1, 0, 59) == 0 );
assert( gamma_move(board, 2, 0, 146) == 0 );
assert( gamma_move(board, 3, 164, 0) == 0 );
assert( gamma_move(board, 4, 73, 0) == 0 );
assert( gamma_move(board, 4, 0, 138) == 0 );
assert( gamma_move(board, 5, 64, 0) == 0 );
assert( gamma_move(board, 6, 75, 0) == 0 );
assert( gamma_move(board, 6, 0, 172) == 0 );
assert( gamma_move(board, 1, 159, 0) == 0 );
assert( gamma_free_fields(board, 1) == 84 );
assert( gamma_move(board, 2, 82, 0) == 0 );
assert( gamma_golden_move(board, 2, 132, 0) == 0 );
assert( gamma_move(board, 3, 73, 0) == 0 );
assert( gamma_move(board, 3, 0, 56) == 0 );
assert( gamma_move(board, 4, 0, 79) == 0 );
assert( gamma_move(board, 4, 0, 148) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 98) == 1 );
assert( gamma_move(board, 5, 0, 120) == 0 );
assert( gamma_move(board, 6, 0, 156) == 0 );
assert( gamma_move(board, 6, 0, 157) == 0 );
assert( gamma_move(board, 1, 169, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_free_fields(board, 1) == 83 );
assert( gamma_move(board, 2, 50, 0) == 0 );
assert( gamma_move(board, 2, 0, 86) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 169, 0) == 0 );
assert( gamma_move(board, 3, 0, 183) == 0 );
assert( gamma_free_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 0, 77) == 0 );
assert( gamma_move(board, 4, 0, 17) == 0 );
assert( gamma_move(board, 6, 0, 158) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 93, 0) == 0 );
assert( gamma_move(board, 2, 0, 164) == 0 );
assert( gamma_move(board, 3, 165, 0) == 0 );
assert( gamma_move(board, 3, 0, 183) == 0 );
assert( gamma_free_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 73, 0) == 0 );
assert( gamma_move(board, 5, 165, 0) == 0 );
assert( gamma_free_fields(board, 5) == 83 );
assert( gamma_move(board, 6, 0, 155) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 120) == 0 );
assert( gamma_move(board, 1, 0, 98) == 0 );
assert( gamma_move(board, 2, 77, 0) == 0 );
assert( gamma_move(board, 2, 0, 87) == 1 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 0, 140) == 0 );
assert( gamma_free_fields(board, 3) == 15 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 186, 0) == 0 );
assert( gamma_move(board, 4, 0, 106) == 0 );
assert( gamma_move(board, 5, 138, 0) == 0 );
assert( gamma_move(board, 5, 0, 40) == 1 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 0, 91) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 9) == 1 );


char* board810254645 = gamma_board(board);
assert( board810254645 != NULL );
assert( strcmp(board810254645, 
".\n"
".\n"
"2\n"
"3\n"
"5\n"
"5\n"
"6\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
"2\n"
"5\n"
"1\n"
"6\n"
"2\n"
".\n"
"3\n"
".\n"
"5\n"
"2\n"
"2\n"
"5\n"
"2\n"
"3\n"
"2\n"
"2\n"
".\n"
"5\n"
"6\n"
"6\n"
".\n"
"2\n"
"2\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"6\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
"3\n"
"4\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
"3\n"
"2\n"
"1\n"
"5\n"
".\n"
"2\n"
"5\n"
"6\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"6\n"
"1\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
"6\n"
"1\n"
"4\n"
"4\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"2\n"
"6\n") == 0);
free(board810254645);
board810254645 = NULL;
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 33) == 0 );
assert( gamma_move(board, 4, 29, 0) == 0 );
assert( gamma_golden_move(board, 5, 0, 0) == 0 );
assert( gamma_move(board, 1, 82, 0) == 0 );
assert( gamma_move(board, 1, 0, 53) == 0 );
assert( gamma_move(board, 2, 93, 0) == 0 );
assert( gamma_move(board, 2, 0, 60) == 0 );
assert( gamma_move(board, 3, 61, 0) == 0 );
assert( gamma_move(board, 4, 73, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 0, 178) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 105) == 0 );
assert( gamma_move(board, 1, 89, 0) == 0 );
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 90) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 4, 75, 0) == 0 );


char* board789480931 = gamma_board(board);
assert( board789480931 != NULL );
assert( strcmp(board789480931, 
".\n"
".\n"
"2\n"
"3\n"
"5\n"
"5\n"
"6\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
"2\n"
"5\n"
"1\n"
"6\n"
"2\n"
".\n"
"3\n"
".\n"
"5\n"
"2\n"
"2\n"
"5\n"
"2\n"
"3\n"
"2\n"
"2\n"
".\n"
"5\n"
"6\n"
"6\n"
".\n"
"2\n"
"2\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"6\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
"3\n"
"4\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
"3\n"
"2\n"
"1\n"
"5\n"
".\n"
"2\n"
"5\n"
"6\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"6\n"
"1\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
"6\n"
"1\n"
"4\n"
"4\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"2\n"
"6\n") == 0);
free(board789480931);
board789480931 = NULL;
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 6, 0, 50) == 0 );
assert( gamma_move(board, 6, 0, 60) == 0 );
assert( gamma_golden_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 1, 128, 0) == 0 );
assert( gamma_move(board, 1, 0, 183) == 0 );
assert( gamma_move(board, 2, 0, 23) == 0 );
assert( gamma_move(board, 2, 0, 118) == 1 );
assert( gamma_move(board, 3, 0, 16) == 0 );
assert( gamma_move(board, 3, 0, 136) == 0 );
assert( gamma_move(board, 4, 172, 0) == 0 );
assert( gamma_move(board, 5, 0, 24) == 0 );
assert( gamma_move(board, 5, 0, 48) == 0 );
assert( gamma_move(board, 6, 32, 0) == 0 );
assert( gamma_move(board, 1, 112, 0) == 0 );


char* board329056418 = gamma_board(board);
assert( board329056418 != NULL );
assert( strcmp(board329056418, 
".\n"
".\n"
"2\n"
"3\n"
"5\n"
"5\n"
"6\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"6\n"
".\n"
"2\n"
"2\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
"2\n"
"5\n"
"1\n"
"6\n"
"2\n"
".\n"
"3\n"
".\n"
"5\n"
"2\n"
"2\n"
"5\n"
"2\n"
"3\n"
"2\n"
"2\n"
".\n"
"5\n"
"6\n"
"6\n"
".\n"
"2\n"
"2\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"6\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
"3\n"
"4\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
"3\n"
"2\n"
"1\n"
"5\n"
".\n"
"2\n"
"5\n"
"6\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"6\n"
"1\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
"6\n"
"1\n"
"4\n"
"4\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"2\n"
"6\n") == 0);
free(board329056418);
board329056418 = NULL;
assert( gamma_move(board, 2, 125, 0) == 0 );
assert( gamma_move(board, 2, 0, 169) == 0 );
assert( gamma_move(board, 3, 141, 0) == 0 );
assert( gamma_move(board, 4, 0, 122) == 0 );
assert( gamma_free_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 142, 0) == 0 );
assert( gamma_move(board, 5, 0, 34) == 0 );
assert( gamma_move(board, 6, 69, 0) == 0 );
assert( gamma_move(board, 6, 0, 147) == 0 );
assert( gamma_move(board, 1, 159, 0) == 0 );
assert( gamma_move(board, 1, 0, 22) == 0 );
assert( gamma_move(board, 2, 35, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 174, 0) == 0 );
assert( gamma_free_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 0, 132) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 5, 0, 94) == 0 );
assert( gamma_move(board, 6, 119, 0) == 0 );
assert( gamma_move(board, 1, 38, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 123) == 0 );
assert( gamma_move(board, 3, 54, 0) == 0 );
assert( gamma_move(board, 4, 0, 102) == 0 );
assert( gamma_golden_move(board, 4, 23, 0) == 0 );
assert( gamma_move(board, 5, 54, 0) == 0 );
assert( gamma_move(board, 6, 0, 57) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 63, 0) == 0 );
assert( gamma_move(board, 3, 0, 49) == 0 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 0, 179) == 0 );
assert( gamma_move(board, 5, 127, 0) == 0 );
assert( gamma_free_fields(board, 6) == 16 );
assert( gamma_move(board, 1, 0, 132) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 75, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 164, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 138) == 0 );
assert( gamma_golden_move(board, 4, 49, 0) == 0 );
assert( gamma_move(board, 5, 35, 0) == 0 );
assert( gamma_move(board, 5, 0, 93) == 1 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 6, 0, 125) == 0 );
assert( gamma_free_fields(board, 6) == 16 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 0, 162) == 0 );
assert( gamma_move(board, 2, 135, 0) == 0 );
assert( gamma_move(board, 2, 0, 119) == 1 );
assert( gamma_move(board, 3, 29, 0) == 0 );
assert( gamma_move(board, 4, 47, 0) == 0 );
assert( gamma_move(board, 5, 89, 0) == 0 );


char* board941574214 = gamma_board(board);
assert( board941574214 != NULL );
assert( strcmp(board941574214, 
".\n"
".\n"
"2\n"
"3\n"
"5\n"
"5\n"
"6\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"6\n"
"2\n"
"2\n"
"2\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
"2\n"
"5\n"
"1\n"
"6\n"
"2\n"
".\n"
"3\n"
".\n"
"5\n"
"2\n"
"2\n"
"5\n"
"2\n"
"3\n"
"2\n"
"2\n"
"5\n"
"5\n"
"6\n"
"6\n"
".\n"
"2\n"
"2\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"6\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
"3\n"
"4\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
"3\n"
"2\n"
"1\n"
"5\n"
".\n"
"2\n"
"5\n"
"6\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"6\n"
"1\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
"6\n"
"1\n"
"4\n"
"4\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"2\n"
"6\n") == 0);
free(board941574214);
board941574214 = NULL;
assert( gamma_move(board, 6, 121, 0) == 0 );
assert( gamma_move(board, 6, 0, 108) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 139) == 0 );
assert( gamma_move(board, 1, 0, 179) == 0 );
assert( gamma_move(board, 2, 0, 121) == 0 );
assert( gamma_move(board, 3, 69, 0) == 0 );
assert( gamma_free_fields(board, 3) == 15 );


char* board685982152 = gamma_board(board);
assert( board685982152 != NULL );
assert( strcmp(board685982152, 
".\n"
".\n"
"2\n"
"3\n"
"5\n"
"5\n"
"6\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"6\n"
"2\n"
"2\n"
"2\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
"2\n"
"5\n"
"1\n"
"6\n"
"2\n"
".\n"
"3\n"
".\n"
"5\n"
"2\n"
"2\n"
"5\n"
"2\n"
"3\n"
"2\n"
"2\n"
"5\n"
"5\n"
"6\n"
"6\n"
".\n"
"2\n"
"2\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"6\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
"3\n"
"4\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
"3\n"
"2\n"
"1\n"
"5\n"
".\n"
"2\n"
"5\n"
"6\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"6\n"
"1\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
"6\n"
"1\n"
"4\n"
"4\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"2\n"
"6\n") == 0);
free(board685982152);
board685982152 = NULL;
assert( gamma_move(board, 4, 0, 17) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 6, 153, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 1, 73, 0) == 0 );
assert( gamma_move(board, 1, 0, 72) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 173) == 0 );
assert( gamma_move(board, 3, 47, 0) == 0 );
assert( gamma_move(board, 4, 0, 70) == 0 );
assert( gamma_move(board, 5, 0, 25) == 0 );
assert( gamma_move(board, 5, 0, 149) == 0 );
assert( gamma_move(board, 6, 159, 0) == 0 );
assert( gamma_move(board, 6, 0, 120) == 0 );


char* board528249229 = gamma_board(board);
assert( board528249229 != NULL );
assert( strcmp(board528249229, 
".\n"
".\n"
"2\n"
"3\n"
"5\n"
"5\n"
"6\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
".\n"
"3\n"
".\n"
".\n"
"6\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
"4\n"
"3\n"
"6\n"
".\n"
"6\n"
"4\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"6\n"
"2\n"
"2\n"
"2\n"
"2\n"
".\n"
"3\n"
"4\n"
".\n"
"3\n"
"1\n"
"2\n"
"5\n"
"1\n"
"6\n"
"2\n"
".\n"
"3\n"
".\n"
"5\n"
"2\n"
"2\n"
"5\n"
"2\n"
"3\n"
"2\n"
"2\n"
"5\n"
"5\n"
"6\n"
"6\n"
".\n"
"2\n"
"2\n"
".\n"
"1\n"
"2\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
".\n"
"6\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
"3\n"
"3\n"
"4\n"
".\n"
".\n"
"3\n"
"6\n"
".\n"
".\n"
"3\n"
"3\n"
".\n"
"3\n"
"2\n"
"1\n"
"5\n"
".\n"
"2\n"
"5\n"
"6\n"
".\n"
"5\n"
"1\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"6\n"
"1\n"
"4\n"
"2\n"
".\n"
".\n"
"6\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
"6\n"
"1\n"
"4\n"
"4\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"2\n"
"6\n") == 0);
free(board528249229);
board528249229 = NULL;
assert( gamma_move(board, 1, 0, 25) == 0 );
assert( gamma_golden_move(board, 1, 119, 0) == 0 );
assert( gamma_move(board, 2, 176, 0) == 0 );
assert( gamma_move(board, 2, 0, 99) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 20, 0) == 0 );
assert( gamma_move(board, 3, 0, 183) == 0 );
assert( gamma_move(board, 4, 55, 0) == 0 );
assert( gamma_move(board, 4, 0, 105) == 0 );
assert( gamma_move(board, 5, 0, 91) == 0 );
assert( gamma_move(board, 5, 0, 130) == 0 );
assert( gamma_move(board, 6, 149, 0) == 0 );
assert( gamma_move(board, 1, 153, 0) == 0 );
assert( gamma_move(board, 2, 135, 0) == 0 );
assert( gamma_move(board, 2, 0, 153) == 0 );
assert( gamma_free_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 0, 134) == 0 );
assert( gamma_move(board, 4, 0, 75) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 5, 77, 0) == 0 );
assert( gamma_move(board, 5, 0, 80) == 0 );
assert( gamma_move(board, 6, 179, 0) == 0 );
assert( gamma_free_fields(board, 6) == 15 );
assert( gamma_move(board, 1, 29, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_free_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 144, 0) == 0 );
assert( gamma_move(board, 3, 0, 54) == 1 );
assert( gamma_move(board, 5, 0, 147) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 6, 29, 0) == 0 );
assert( gamma_move(board, 1, 38, 0) == 0 );
assert( gamma_move(board, 2, 139, 0) == 0 );
assert( gamma_move(board, 2, 0, 154) == 0 );
assert( gamma_golden_move(board, 2, 12, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_golden_move(board, 4, 93, 0) == 0 );
assert( gamma_move(board, 5, 0, 128) == 0 );
assert( gamma_move(board, 5, 0, 98) == 0 );
assert( gamma_free_fields(board, 5) == 12 );
assert( gamma_move(board, 6, 0, 78) == 0 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_move(board, 2, 0, 44) == 0 );
assert( gamma_move(board, 3, 138, 0) == 0 );
assert( gamma_move(board, 3, 0, 81) == 0 );
assert( gamma_move(board, 4, 0, 122) == 0 );
assert( gamma_move(board, 5, 0, 127) == 0 );
assert( gamma_move(board, 6, 75, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 23) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 0, 83) == 0 );
assert( gamma_move(board, 4, 153, 0) == 0 );
assert( gamma_move(board, 4, 0, 72) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 0, 62) == 0 );
assert( gamma_move(board, 6, 73, 0) == 0 );
assert( gamma_move(board, 6, 0, 171) == 1 );
assert( gamma_move(board, 1, 0, 42) == 0 );
assert( gamma_move(board, 2, 179, 0) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 61, 0) == 0 );
assert( gamma_move(board, 4, 141, 0) == 0 );
assert( gamma_move(board, 4, 0, 91) == 0 );
assert( gamma_move(board, 5, 80, 0) == 0 );
assert( gamma_move(board, 5, 0, 132) == 0 );
assert( gamma_move(board, 6, 0, 109) == 0 );
assert( gamma_move(board, 6, 0, 60) == 0 );
assert( gamma_move(board, 1, 26, 0) == 0 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 75, 0) == 0 );
assert( gamma_move(board, 3, 19, 0) == 0 );
assert( gamma_move(board, 3, 0, 98) == 0 );
assert( gamma_free_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 0, 92) == 0 );
assert( gamma_move(board, 5, 127, 0) == 0 );
assert( gamma_move(board, 6, 144, 0) == 0 );
assert( gamma_move(board, 1, 62, 0) == 0 );
assert( gamma_move(board, 1, 0, 158) == 0 );
assert( gamma_move(board, 2, 0, 81) == 0 );


gamma_delete(board);

    return 0;
}
