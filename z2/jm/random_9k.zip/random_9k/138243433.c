#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 138243433
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(8, 9, 7, 8);
assert( board != NULL );


assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 4, 1, 1) == 1 );
assert( gamma_move(board, 5, 0, 4) == 1 );
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_move(board, 6, 0, 2) == 1 );
assert( gamma_move(board, 7, 2, 2) == 1 );
assert( gamma_move(board, 1, 5, 7) == 1 );
assert( gamma_move(board, 1, 1, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_move(board, 3, 7, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 7) == 1 );
assert( gamma_move(board, 4, 1, 3) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 2, 6) == 1 );
assert( gamma_move(board, 1, 2, 8) == 1 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_golden_move(board, 1, 6, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_golden_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 3 );
assert( gamma_free_fields(board, 4) == 52 );
assert( gamma_move(board, 5, 7, 6) == 0 );
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_move(board, 6, 4, 4) == 0 );
assert( gamma_move(board, 7, 0, 5) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 0, 8) == 1 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 4, 4, 5) == 0 );


char* board597151040 = gamma_board(board);
assert( board597151040 != NULL );
assert( strcmp(board597151040, 
"211.....\n"
"...4.1..\n"
".37...51\n"
"74..3...\n"
"5...3...\n"
"34..1..1\n"
"6.73...3\n"
".4....6.\n"
".2......\n") == 0);
free(board597151040);
board597151040 = NULL;
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 6, 8, 4) == 0 );


char* board499426002 = gamma_board(board);
assert( board499426002 != NULL );
assert( strcmp(board499426002, 
"211.....\n"
"...4.1..\n"
".37...51\n"
"74..3...\n"
"5...3...\n"
"34..1..1\n"
"6.73...3\n"
".4....6.\n"
".2......\n") == 0);
free(board499426002);
board499426002 = NULL;
assert( gamma_move(board, 7, 8, 5) == 0 );
assert( gamma_free_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 4 );
assert( gamma_free_fields(board, 2) == 45 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 5, 0, 5) == 0 );


char* board114576797 = gamma_board(board);
assert( board114576797 != NULL );
assert( strcmp(board114576797, 
"211.....\n"
"...4.1.2\n"
".37..251\n"
"74..3...\n"
"5...3...\n"
"34..1..1\n"
"6.73...3\n"
".4....6.\n"
".2......\n") == 0);
free(board114576797);
board114576797 = NULL;
assert( gamma_move(board, 6, 3, 5) == 1 );
assert( gamma_move(board, 6, 7, 0) == 1 );


char* board581864682 = gamma_board(board);
assert( board581864682 != NULL );
assert( strcmp(board581864682, 
"211.....\n"
"...4.1.2\n"
".37..251\n"
"74.63...\n"
"5...3...\n"
"34..1..1\n"
"6.73...3\n"
".4....6.\n"
".2.....6\n") == 0);
free(board581864682);
board581864682 = NULL;
assert( gamma_move(board, 7, 0, 5) == 0 );
assert( gamma_move(board, 7, 0, 8) == 0 );
assert( gamma_free_fields(board, 1) == 43 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board195098521 = gamma_board(board);
assert( board195098521 != NULL );
assert( strcmp(board195098521, 
"211.....\n"
"...4.1.2\n"
".37..251\n"
"74.63...\n"
"5.3.3...\n"
"343.1..1\n"
"6.73...3\n"
".4....6.\n"
".2.....6\n") == 0);
free(board195098521);
board195098521 = NULL;
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 5, 5, 5) == 1 );
assert( gamma_move(board, 5, 7, 5) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_free_fields(board, 5) == 39 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 3) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 7, 8, 6) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 7, 2) == 0 );
assert( gamma_move(board, 7, 1, 5) == 0 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_golden_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 5, 8) == 1 );
assert( gamma_move(board, 5, 2, 0) == 1 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 7, 4, 1) == 1 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_golden_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 4, 5, 6) == 0 );
assert( gamma_move(board, 5, 4, 2) == 1 );
assert( gamma_move(board, 6, 4, 1) == 0 );
assert( gamma_move(board, 6, 6, 5) == 1 );
assert( gamma_move(board, 7, 3, 8) == 1 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_move(board, 5, 6, 6) == 0 );
assert( gamma_move(board, 6, 3, 3) == 1 );
assert( gamma_move(board, 6, 0, 7) == 1 );
assert( gamma_move(board, 7, 8, 6) == 0 );
assert( gamma_golden_move(board, 7, 4, 0) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_golden_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 5, 3, 3) == 0 );
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_free_fields(board, 6) == 24 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 7, 4, 4) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_free_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 6 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board348369253 = gamma_board(board);
assert( board348369253 != NULL );
assert( strcmp(board348369253, 
"2117.5..\n"
"6..44122\n"
".37.3251\n"
"74163565\n"
"533.3...\n"
"34361321\n"
"61735..3\n"
".4..7.63\n"
"125....6\n") == 0);
free(board348369253);
board348369253 = NULL;
assert( gamma_move(board, 7, 8, 4) == 0 );
assert( gamma_golden_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_move(board, 5, 6, 4) == 1 );
assert( gamma_move(board, 6, 3, 5) == 0 );
assert( gamma_move(board, 6, 0, 3) == 0 );


char* board714728616 = gamma_board(board);
assert( board714728616 != NULL );
assert( strcmp(board714728616, 
"2117.5..\n"
"6..44122\n"
".37.3251\n"
"74163565\n"
"533.3.5.\n"
"34361321\n"
"61735..3\n"
".4..7.63\n"
"125....6\n") == 0);
free(board714728616);
board714728616 = NULL;
assert( gamma_move(board, 7, 6, 0) == 1 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_free_fields(board, 1) == 4 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_golden_move(board, 4, 6, 5) == 1 );
assert( gamma_free_fields(board, 5) == 7 );
assert( gamma_move(board, 6, 3, 8) == 0 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_free_fields(board, 1) == 4 );
assert( gamma_golden_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 5, 2) == 1 );
assert( gamma_move(board, 2, 7, 4) == 1 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 5, 2, 8) == 0 );
assert( gamma_busy_fields(board, 5) == 8 );
assert( gamma_move(board, 6, 2, 3) == 0 );
assert( gamma_move(board, 7, 4, 5) == 0 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_golden_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );


char* board522027649 = gamma_board(board);
assert( board522027649 != NULL );
assert( strcmp(board522027649, 
"2117.5..\n"
"6..44122\n"
".37.3251\n"
"74163545\n"
"533.3.52\n"
"34361321\n"
"617352.3\n"
".4..7.63\n"
"125...76\n") == 0);
free(board522027649);
board522027649 = NULL;
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_move(board, 7, 1, 2) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_move(board, 7, 4, 0) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_free_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 8, 7) == 0 );


char* board103540993 = gamma_board(board);
assert( board103540993 != NULL );
assert( strcmp(board103540993, 
"2117.5..\n"
"6..44122\n"
".37.3251\n"
"74163545\n"
"533.3.52\n"
"34361321\n"
"617352.3\n"
".4..7.63\n"
"125...76\n") == 0);
free(board103540993);
board103540993 = NULL;
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_move(board, 7, 3, 2) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );


char* board554317683 = gamma_board(board);
assert( board554317683 != NULL );
assert( strcmp(board554317683, 
"2117.5..\n"
"6..44122\n"
".37.3251\n"
"74163545\n"
"533.3.52\n"
"34361321\n"
"617352.3\n"
".4..7.63\n"
"125...76\n") == 0);
free(board554317683);
board554317683 = NULL;
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 4, 0, 6) == 1 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 6, 6, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 6 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_free_fields(board, 7) == 16 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_move(board, 7, 0, 0) == 0 );


char* board479843430 = gamma_board(board);
assert( board479843430 != NULL );
assert( strcmp(board479843430, 
"2117.5..\n"
"6..44122\n"
"437.3251\n"
"74163545\n"
"533.3.52\n"
"34361321\n"
"617352.3\n"
".4..7.63\n"
"125...76\n") == 0);
free(board479843430);
board479843430 = NULL;
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 3, 0) == 1 );
assert( gamma_free_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 6, 4, 5) == 0 );


char* board947337121 = gamma_board(board);
assert( board947337121 != NULL );
assert( strcmp(board947337121, 
"2117.5..\n"
"6..44122\n"
"437.3251\n"
"74163545\n"
"533.3.52\n"
"34361321\n"
"617352.3\n"
".4..7.63\n"
"1254..76\n") == 0);
free(board947337121);
board947337121 = NULL;
assert( gamma_move(board, 1, 0, 7) == 0 );


char* board665475874 = gamma_board(board);
assert( board665475874 != NULL );
assert( strcmp(board665475874, 
"2117.5..\n"
"6..44122\n"
"437.3251\n"
"74163545\n"
"533.3.52\n"
"34361321\n"
"617352.3\n"
".4..7.63\n"
"1254..76\n") == 0);
free(board665475874);
board665475874 = NULL;
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_free_fields(board, 4) == 15 );


gamma_delete(board);

    return 0;
}
