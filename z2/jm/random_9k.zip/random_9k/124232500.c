#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 124232500
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(13, 15, 4, 25);
assert( board != NULL );


assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 3, 5, 13) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_move(board, 4, 12, 2) == 1 );
assert( gamma_move(board, 1, 5, 11) == 1 );


char* board778310616 = gamma_board(board);
assert( board778310616 != NULL );
assert( strcmp(board778310616, 
".............\n"
".....3.......\n"
"...2.........\n"
".....1.......\n"
".............\n"
".............\n"
".............\n"
"....4........\n"
".............\n"
".............\n"
"............1\n"
".............\n"
"............4\n"
".............\n"
".1...........\n") == 0);
free(board778310616);
board778310616 = NULL;
assert( gamma_move(board, 2, 3, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_free_fields(board, 2) == 187 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board356399857 = gamma_board(board);
assert( board356399857 != NULL );
assert( strcmp(board356399857, 
".............\n"
".....3.......\n"
"...2.........\n"
".....1.......\n"
".............\n"
".............\n"
".............\n"
"....4........\n"
".............\n"
".............\n"
"............1\n"
".............\n"
"............4\n"
".............\n"
".1.2.........\n") == 0);
free(board356399857);
board356399857 = NULL;
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 3, 11, 11) == 1 );
assert( gamma_free_fields(board, 3) == 185 );
assert( gamma_golden_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 4, 9, 0) == 1 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 1, 9, 0) == 0 );


char* board885947449 = gamma_board(board);
assert( board885947449 != NULL );
assert( strcmp(board885947449, 
".............\n"
".....3.......\n"
".1.2.........\n"
".....1.....3.\n"
".............\n"
".............\n"
".............\n"
"....4........\n"
"......3......\n"
".............\n"
".....1...2..1\n"
".............\n"
"...........44\n"
"....1........\n"
".1.2.....4...\n") == 0);
free(board885947449);
board885947449 = NULL;
assert( gamma_move(board, 2, 12, 0) == 1 );
assert( gamma_free_fields(board, 2) == 178 );


char* board176895724 = gamma_board(board);
assert( board176895724 != NULL );
assert( strcmp(board176895724, 
".............\n"
".....3.......\n"
".1.2.........\n"
".....1.....3.\n"
".............\n"
".............\n"
".............\n"
"....4........\n"
"......3......\n"
".............\n"
".....1...2..1\n"
".............\n"
"...........44\n"
"....1........\n"
".1.2.....4..2\n") == 0);
free(board176895724);
board176895724 = NULL;
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 4, 8, 14) == 1 );
assert( gamma_move(board, 1, 8, 12) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 3, 1, 2) == 1 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_free_fields(board, 4) == 171 );
assert( gamma_golden_move(board, 4, 0, 12) == 0 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_move(board, 1, 12, 5) == 1 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 4, 5, 11) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 3, 10, 11) == 1 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_free_fields(board, 1) == 163 );
assert( gamma_move(board, 2, 4, 13) == 1 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 2, 2, 10) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_move(board, 1, 6, 12) == 1 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 4, 6, 2) == 1 );
assert( gamma_move(board, 4, 3, 9) == 1 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 7, 6) == 1 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 3, 6, 9) == 1 );


char* board698935302 = gamma_board(board);
assert( board698935302 != NULL );
assert( strcmp(board698935302, 
".......24....\n"
"....23.......\n"
".1.2..1.1....\n"
"....11....33.\n"
"..2..........\n"
"...4..3..4...\n"
".3.........2.\n"
"....4....1...\n"
"....3232..3..\n"
"........1.3.1\n"
".1.3.1...2..1\n"
"..42..1......\n"
".3....4...244\n"
"....1....2...\n"
".1.2.....4..2\n") == 0);
free(board698935302);
board698935302 = NULL;
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_free_fields(board, 1) == 147 );
assert( gamma_move(board, 2, 7, 12) == 1 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_move(board, 3, 11, 12) == 1 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 1, 9, 11) == 1 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 4, 9, 10) == 1 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_free_fields(board, 4) == 142 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 4, 8, 9) == 1 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_free_fields(board, 3) == 137 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 4, 2, 6) == 1 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_free_fields(board, 1) == 136 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 4, 8, 7) == 1 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 2, 10, 12) == 1 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_free_fields(board, 2) == 128 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board884813055 = gamma_board(board);
assert( board884813055 != NULL );
assert( strcmp(board884813055, 
".......24....\n"
"..1.23.......\n"
".1.2..121.23.\n"
"....11...133.\n"
"..2......4...\n"
"...4..3.44...\n"
".3.........2.\n"
"....4...41...\n"
"..4.3232..3..\n"
"........1.3.1\n"
".1.3.12..2..1\n"
".342.11.1.2..\n"
".32..44.2.244\n"
"....1.3..2...\n"
".1.2..4.24..2\n") == 0);
free(board884813055);
board884813055 = NULL;
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_move(board, 2, 10, 12) == 0 );
assert( gamma_golden_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 4, 2, 4) == 1 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 9, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 3, 10, 7) == 1 );
assert( gamma_move(board, 4, 11, 4) == 1 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 11, 5) == 1 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 2, 12, 6) == 1 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 9, 6) == 1 );
assert( gamma_free_fields(board, 2) == 113 );
assert( gamma_move(board, 3, 8, 0) == 0 );


char* board844127891 = gamma_board(board);
assert( board844127891 != NULL );
assert( strcmp(board844127891, 
".......24.1..\n"
"..1.23....3..\n"
".1.2..121.23.\n"
"3...11...133.\n"
"..2......4...\n"
"...4..3.44...\n"
".3..2......2.\n"
"....4..3413..\n"
"..4.3232443.2\n"
"........1.311\n"
".143.12..2.41\n"
".342.11.1.2..\n"
".32..44.21244\n"
".3..1.3..2...\n"
".132..4.24..2\n") == 0);
free(board844127891);
board844127891 = NULL;


char* board265808685 = gamma_board(board);
assert( board265808685 != NULL );
assert( strcmp(board265808685, 
".......24.1..\n"
"..1.23....3..\n"
".1.2..121.23.\n"
"3...11...133.\n"
"..2......4...\n"
"...4..3.44...\n"
".3..2......2.\n"
"....4..3413..\n"
"..4.3232443.2\n"
"........1.311\n"
".143.12..2.41\n"
".342.11.1.2..\n"
".32..44.21244\n"
".3..1.3..2...\n"
".132..4.24..2\n") == 0);
free(board265808685);
board265808685 = NULL;
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 10, 4) == 1 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_move(board, 4, 4, 7) == 0 );


char* board329360703 = gamma_board(board);
assert( board329360703 != NULL );
assert( strcmp(board329360703, 
".......24.1..\n"
"..1.23....3..\n"
".1.2..121.23.\n"
"3...11...133.\n"
"..2......4...\n"
"...4..3.44...\n"
".3..2......2.\n"
"....4..34133.\n"
"..4.3232443.2\n"
"........13311\n"
".143.12..2341\n"
".342.11.1.2..\n"
".32..44.21244\n"
".3..1.3..2...\n"
".132..4.24..2\n") == 0);
free(board329360703);
board329360703 = NULL;
assert( gamma_move(board, 2, 7, 2) == 1 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 3, 8, 6) == 0 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_move(board, 4, 12, 9) == 1 );


char* board439712550 = gamma_board(board);
assert( board439712550 != NULL );
assert( strcmp(board439712550, 
".......24.1..\n"
"..1.23....3..\n"
".1.2..121.23.\n"
"3...11...133.\n"
"..2..2...44..\n"
"...4..3.44..4\n"
".3..2......2.\n"
"....4..34133.\n"
"..4.3232443.2\n"
"........13311\n"
".143.12..2341\n"
".342.11.1.2..\n"
".32..44221244\n"
".3..1.3..2...\n"
".132..4.24..2\n") == 0);
free(board439712550);
board439712550 = NULL;
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_move(board, 2, 8, 4) == 1 );


char* board594313790 = gamma_board(board);
assert( board594313790 != NULL );
assert( strcmp(board594313790, 
".......24.1..\n"
"..1.23....3..\n"
".1.2..121.23.\n"
"3...11...133.\n"
"..2..2...44..\n"
"...4..3.44..4\n"
".3..2......2.\n"
"....4..34133.\n"
"..4.3232443.2\n"
"........13311\n"
".143.12.22341\n"
".342.11.1.2..\n"
".32..44221244\n"
".3..1.3..2...\n"
".132..4.24..2\n") == 0);
free(board594313790);
board594313790 = NULL;
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 1, 4, 3) == 1 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 11, 3) == 1 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 4, 4, 12) == 1 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_free_fields(board, 2) == 97 );
assert( gamma_move(board, 3, 1, 1) == 0 );


char* board157950987 = gamma_board(board);
assert( board157950987 != NULL );
assert( strcmp(board157950987, 
".......24.1..\n"
"..1.23....3..\n"
".1.24.121.23.\n"
"3...11...133.\n"
"3.2..2...44..\n"
"...4..3.44..4\n"
".3..2......2.\n"
"....4..34133.\n"
"..4.323244312\n"
"........13311\n"
".143.12.22341\n"
".34211111122.\n"
".32..44221244\n"
".3..1.33.2...\n"
".132..4.24..2\n") == 0);
free(board157950987);
board157950987 = NULL;
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 2, 12, 12) == 1 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_move(board, 4, 1, 7) == 1 );


char* board717633469 = gamma_board(board);
assert( board717633469 != NULL );
assert( strcmp(board717633469, 
".......24.1..\n"
"..1.23....3..\n"
".1.24.121.232\n"
"3...11...133.\n"
"3.2..2...44..\n"
"...4..3.44..4\n"
".3..2......2.\n"
".4..43.34133.\n"
"..4.323244312\n"
"........13311\n"
".143.12.22341\n"
".34211111122.\n"
".32..44221244\n"
".3..1.33.2...\n"
".132..4.24..2\n") == 0);
free(board717633469);
board717633469 = NULL;
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 4, 11, 11) == 0 );
assert( gamma_move(board, 1, 4, 14) == 1 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_move(board, 3, 10, 14) == 0 );
assert( gamma_move(board, 4, 7, 0) == 1 );
assert( gamma_free_fields(board, 4) == 91 );
assert( gamma_move(board, 1, 8, 10) == 1 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_free_fields(board, 2) == 88 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_free_fields(board, 3) == 88 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 29 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_move(board, 4, 7, 4) == 1 );
assert( gamma_move(board, 1, 10, 14) == 0 );
assert( gamma_free_fields(board, 1) == 86 );
assert( gamma_move(board, 2, 7, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 30 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 3, 11, 1) == 1 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_move(board, 4, 6, 8) == 1 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_free_fields(board, 2) == 35 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 8, 13) == 1 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 2, 12, 13) == 1 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_move(board, 2, 11, 0) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_free_fields(board, 1) == 76 );


char* board863020444 = gamma_board(board);
assert( board863020444 != NULL );
assert( strcmp(board863020444, 
"....1..24.1..\n"
"..1.231.4.3.2\n"
".1.24.121.232\n"
"3.4.11...133.\n"
"3.2..2.2144..\n"
"...4..3.44..4\n"
".3..2.4.2.42.\n"
".41.43.34133.\n"
"..4.323244312\n"
".....2..13311\n"
".143.12422341\n"
".34211111122.\n"
".32.444221244\n"
".3..1.33.2.32\n"
".132..4424.22\n") == 0);
free(board863020444);
board863020444 = NULL;
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 3, 11, 11) == 0 );
assert( gamma_move(board, 4, 12, 14) == 1 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 1, 11, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 30 );
assert( gamma_free_fields(board, 1) == 74 );


char* board691110244 = gamma_board(board);
assert( board691110244 != NULL );
assert( strcmp(board691110244, 
"....1..24.1.4\n"
"..1.231.4.312\n"
".1.24.121.232\n"
"3.4.11...133.\n"
"3.2..2.2144..\n"
"...4..3.44..4\n"
".3..2.4.2.42.\n"
".41.43.34133.\n"
"..4.323244312\n"
".....2..13311\n"
".143.12422341\n"
".34211111122.\n"
".32.444221244\n"
".3..1.33.2.32\n"
".132..4424.22\n") == 0);
free(board691110244);
board691110244 = NULL;
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );


char* board802569033 = gamma_board(board);
assert( board802569033 != NULL );
assert( strcmp(board802569033, 
"....1..24.1.4\n"
"..1.231.4.312\n"
".1.24.121.232\n"
"3.4.11...133.\n"
"3.2..2.2144..\n"
"...4..3.44..4\n"
".3..2.4.2.42.\n"
".41.43.34133.\n"
"..4.323244312\n"
".....2..13311\n"
".143.12422341\n"
".34211111122.\n"
".32.444221244\n"
".3..1.33.2.32\n"
".132..4424.22\n") == 0);
free(board802569033);
board802569033 = NULL;
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_free_fields(board, 4) == 74 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_free_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 12, 5) == 0 );
assert( gamma_move(board, 3, 9, 13) == 1 );
assert( gamma_move(board, 4, 10, 12) == 0 );
assert( gamma_move(board, 4, 4, 5) == 1 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_free_fields(board, 4) == 66 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 3, 6, 7) == 1 );


char* board413436170 = gamma_board(board);
assert( board413436170 != NULL );
assert( strcmp(board413436170, 
"....1..24.1.4\n"
"..1.231.43312\n"
".1.24.121.232\n"
"334.11...133.\n"
"322..2.2144..\n"
".4.4..3.44..4\n"
".3..244.2.42.\n"
".41.43334133.\n"
"..4.323244312\n"
"...142..13311\n"
".143112422341\n"
".34211111122.\n"
".32.444221244\n"
".3..1.33.2.32\n"
".132..4424.22\n") == 0);
free(board413436170);
board413436170 = NULL;
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 34 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_free_fields(board, 1) == 65 );
assert( gamma_move(board, 2, 7, 9) == 1 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 1, 3, 4) == 0 );
assert( gamma_golden_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 4, 5, 12) == 1 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 7, 5) == 1 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_free_fields(board, 3) == 61 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_golden_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 36 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board197980492 = gamma_board(board);
assert( board197980492 != NULL );
assert( strcmp(board197980492, 
"....1..24.1.4\n"
"..1.231.43312\n"
".1.244121.232\n"
"334.11...133.\n"
"322..2.2144..\n"
".4.4..3244..4\n"
".3..244.2342.\n"
".41.43334133.\n"
"..4.323244312\n"
"...142.213311\n"
".143112422341\n"
".34211111122.\n"
".32.444221244\n"
".3..1.33.2.32\n"
".132..4424.22\n") == 0);
free(board197980492);
board197980492 = NULL;
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 4, 3, 8) == 1 );


char* board276771657 = gamma_board(board);
assert( board276771657 != NULL );
assert( strcmp(board276771657, 
"....1..24.1.4\n"
"..1.231.43312\n"
".1.244121.232\n"
"334.11...133.\n"
"322..2.2144..\n"
".4.4..3244..4\n"
".3.4244.2342.\n"
".41.43334133.\n"
"..4.323244312\n"
"...142.213311\n"
".143112422341\n"
".34211111122.\n"
".32.444221244\n"
".3..1.33.2.32\n"
".132..4424.22\n") == 0);
free(board276771657);
board276771657 = NULL;
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 2, 12, 10) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 1, 4, 9) == 1 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 2, 2, 2) == 0 );
assert( gamma_free_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 11, 11) == 1 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_free_fields(board, 2) == 24 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_free_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 1, 3, 12) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_move(board, 4, 12, 14) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_golden_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_golden_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 11, 9) == 1 );
assert( gamma_free_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_free_fields(board, 4) == 51 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_free_fields(board, 4) == 51 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_free_fields(board, 1) == 50 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 11) == 1 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_free_fields(board, 4) == 47 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 8) == 0 );


char* board269836701 = gamma_board(board);
assert( board269836701 != NULL );
assert( strcmp(board269836701, 
"....1..24.1.4\n"
"..1.231343312\n"
".1.2441211232\n"
"334.11.4.131.\n"
"322..2.2144..\n"
"44.41.3244.34\n"
".344244.2342.\n"
".41.43334133.\n"
"..4.323244312\n"
"...142.213311\n"
"1143112422341\n"
"134211111122.\n"
".32.444221244\n"
".33.1.33.2332\n"
".132.14424222\n") == 0);
free(board269836701);
board269836701 = NULL;
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_free_fields(board, 4) == 47 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_free_fields(board, 3) == 47 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 39 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 39 );
assert( gamma_free_fields(board, 4) == 45 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_free_fields(board, 4) == 45 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_free_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_free_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );


char* board938710660 = gamma_board(board);
assert( board938710660 != NULL );
assert( strcmp(board938710660, 
"....1.324.1.4\n"
".31.231343312\n"
".1.2441211232\n"
"334.11.4.131.\n"
"3221.2.2144..\n"
"44.41.3244.34\n"
".344244.2342.\n"
".41.43334133.\n"
".34.323244312\n"
"...142.213311\n"
"1143112422341\n"
"134211111122.\n"
".32.444221244\n"
".33.1.33.2332\n"
".132314424222\n") == 0);
free(board938710660);
board938710660 = NULL;
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 3, 8, 12) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );


char* board776651439 = gamma_board(board);
assert( board776651439 != NULL );
assert( strcmp(board776651439, 
"....1.324.1.4\n"
".31.231343312\n"
".1.2441211232\n"
"334.11.4.131.\n"
"3221.2.2144..\n"
"44441.3244.34\n"
".344244.2342.\n"
".41.43334133.\n"
".34.323244312\n"
"...142.213311\n"
"1143112422341\n"
"134211111122.\n"
".32.444221244\n"
".33.1.33.2332\n"
".132314424222\n") == 0);
free(board776651439);
board776651439 = NULL;
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_golden_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_free_fields(board, 4) == 40 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_golden_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_free_fields(board, 2) == 15 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board229189623 = gamma_board(board);
assert( board229189623 != NULL );
assert( strcmp(board229189623, 
"....1.324.1.4\n"
".31.231343312\n"
".1.2441211232\n"
"334.1144.131.\n"
"3221.2.2144..\n"
"44441.3244.34\n"
".344244.2342.\n"
".41.43334133.\n"
".34.323244312\n"
"...142.213311\n"
"1143112422341\n"
"134211111122.\n"
".32.444221244\n"
".33.1.33.2332\n"
".132314424222\n") == 0);
free(board229189623);
board229189623 = NULL;
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 3, 10, 10) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 41 );
assert( gamma_golden_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 1, 10, 9) == 1 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_free_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 3, 7, 10) == 0 );
assert( gamma_free_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 9, 14) == 0 );
assert( gamma_golden_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 38 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 3, 9) == 0 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 4, 7) == 0 );


char* board588007173 = gamma_board(board);
assert( board588007173 != NULL );
assert( strcmp(board588007173, 
"4...1.324.1.4\n"
".31.231343312\n"
".1.2441211232\n"
"334.1144.131.\n"
"322112.2144..\n"
"44441.3244134\n"
".344244.2342.\n"
".41.43334133.\n"
".34.323244312\n"
".4.142.213311\n"
"1143112422341\n"
"134211111122.\n"
".32.444221244\n"
".33.1.33.2332\n"
".132314424222\n") == 0);
free(board588007173);
board588007173 = NULL;
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );


char* board846304221 = gamma_board(board);
assert( board846304221 != NULL );
assert( strcmp(board846304221, 
"4...1.324.1.4\n"
".31.231343312\n"
".1.2441211232\n"
"334.1144.131.\n"
"322112.2144..\n"
"44441.3244134\n"
".344244.2342.\n"
".41.43334133.\n"
".34.323244312\n"
".4.142.213311\n"
"1143112422341\n"
"134211111122.\n"
".32.444221244\n"
".33.1.33.2332\n"
".132314424222\n") == 0);
free(board846304221);
board846304221 = NULL;


gamma_delete(board);

    return 0;
}
