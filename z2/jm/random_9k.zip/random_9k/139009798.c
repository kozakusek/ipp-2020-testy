#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 139009798
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 102, 7, 14);
assert( board != NULL );


assert( gamma_move(board, 1, 0, 43) == 1 );
assert( gamma_move(board, 2, 0, 71) == 1 );
assert( gamma_move(board, 2, 0, 89) == 1 );
assert( gamma_move(board, 3, 63, 0) == 0 );
assert( gamma_move(board, 4, 56, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 83) == 1 );
assert( gamma_move(board, 6, 0, 19) == 1 );
assert( gamma_move(board, 7, 81, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_move(board, 2, 52, 0) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 0, 94) == 1 );
assert( gamma_move(board, 4, 0, 57) == 1 );
assert( gamma_move(board, 5, 5, 0) == 0 );


char* board996962342 = gamma_board(board);
assert( board996962342 != NULL );
assert( strcmp(board996962342, 
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board996962342);
board996962342 = NULL;
assert( gamma_move(board, 6, 66, 0) == 0 );
assert( gamma_move(board, 6, 0, 83) == 0 );
assert( gamma_move(board, 7, 0, 75) == 1 );
assert( gamma_busy_fields(board, 7) == 1 );
assert( gamma_move(board, 1, 0, 35) == 1 );
assert( gamma_move(board, 2, 0, 46) == 1 );
assert( gamma_move(board, 2, 0, 39) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 0, 18) == 1 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 6, 0, 19) == 0 );
assert( gamma_move(board, 7, 29, 0) == 0 );
assert( gamma_move(board, 7, 0, 16) == 1 );
assert( gamma_free_fields(board, 7) == 88 );
assert( gamma_move(board, 1, 0, 78) == 1 );
assert( gamma_move(board, 1, 0, 87) == 1 );
assert( gamma_free_fields(board, 1) == 86 );
assert( gamma_move(board, 2, 0, 89) == 0 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 65, 0) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 4, 0, 94) == 0 );
assert( gamma_move(board, 5, 15, 0) == 0 );
assert( gamma_move(board, 5, 0, 42) == 1 );
assert( gamma_free_fields(board, 5) == 84 );
assert( gamma_move(board, 6, 0, 96) == 1 );
assert( gamma_move(board, 7, 4, 0) == 0 );
assert( gamma_move(board, 7, 0, 36) == 1 );
assert( gamma_move(board, 1, 0, 87) == 0 );
assert( gamma_move(board, 1, 0, 94) == 0 );
assert( gamma_move(board, 2, 77, 0) == 0 );
assert( gamma_move(board, 2, 0, 72) == 1 );
assert( gamma_move(board, 3, 62, 0) == 0 );
assert( gamma_move(board, 4, 41, 0) == 0 );
assert( gamma_move(board, 5, 90, 0) == 0 );
assert( gamma_move(board, 6, 0, 95) == 1 );
assert( gamma_move(board, 6, 0, 45) == 1 );
assert( gamma_move(board, 7, 0, 43) == 0 );
assert( gamma_move(board, 2, 86, 0) == 0 );
assert( gamma_move(board, 2, 0, 23) == 1 );
assert( gamma_move(board, 3, 29, 0) == 0 );
assert( gamma_move(board, 3, 0, 84) == 1 );
assert( gamma_move(board, 4, 92, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 2 );


char* board667794197 = gamma_board(board);
assert( board667794197 != NULL );
assert( strcmp(board667794197, 
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
".\n"
"3\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"6\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n") == 0);
free(board667794197);
board667794197 = NULL;
assert( gamma_move(board, 5, 26, 0) == 0 );
assert( gamma_move(board, 6, 0, 46) == 0 );
assert( gamma_move(board, 7, 91, 0) == 0 );
assert( gamma_golden_move(board, 7, 96, 0) == 0 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_move(board, 1, 0, 6) == 1 );
assert( gamma_move(board, 2, 0, 49) == 1 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 4, 0, 55) == 1 );
assert( gamma_move(board, 5, 50, 0) == 0 );
assert( gamma_move(board, 6, 0, 35) == 0 );
assert( gamma_move(board, 7, 63, 0) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 0, 19) == 0 );
assert( gamma_golden_move(board, 1, 45, 0) == 0 );
assert( gamma_move(board, 2, 0, 35) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 68, 0) == 0 );
assert( gamma_move(board, 4, 28, 0) == 0 );
assert( gamma_move(board, 4, 0, 60) == 1 );
assert( gamma_busy_fields(board, 4) == 4 );
assert( gamma_move(board, 5, 41, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 25, 0) == 0 );
assert( gamma_move(board, 6, 0, 56) == 1 );
assert( gamma_move(board, 7, 66, 0) == 0 );
assert( gamma_free_fields(board, 7) == 71 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 2, 0, 52) == 1 );
assert( gamma_busy_fields(board, 2) == 9 );
assert( gamma_move(board, 4, 69, 0) == 0 );
assert( gamma_move(board, 4, 0, 28) == 1 );
assert( gamma_free_fields(board, 4) == 68 );
assert( gamma_move(board, 6, 20, 0) == 0 );
assert( gamma_free_fields(board, 6) == 68 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 100) == 1 );


char* board138996260 = gamma_board(board);
assert( board138996260 != NULL );
assert( strcmp(board138996260, 
".\n"
"7\n"
".\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
".\n"
"3\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"6\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"2\n") == 0);
free(board138996260);
board138996260 = NULL;
assert( gamma_move(board, 1, 0, 28) == 0 );
assert( gamma_move(board, 2, 80, 0) == 0 );
assert( gamma_move(board, 3, 80, 0) == 0 );
assert( gamma_move(board, 3, 0, 35) == 0 );
assert( gamma_move(board, 4, 59, 0) == 0 );
assert( gamma_move(board, 5, 27, 0) == 0 );
assert( gamma_move(board, 5, 0, 36) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 90) == 1 );
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 1, 0, 76) == 1 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_move(board, 2, 101, 0) == 0 );
assert( gamma_move(board, 2, 0, 100) == 0 );
assert( gamma_free_fields(board, 2) == 65 );
assert( gamma_move(board, 3, 21, 0) == 0 );
assert( gamma_move(board, 4, 73, 0) == 0 );
assert( gamma_golden_move(board, 4, 83, 0) == 0 );
assert( gamma_move(board, 6, 67, 0) == 0 );
assert( gamma_move(board, 6, 0, 49) == 0 );
assert( gamma_free_fields(board, 6) == 65 );
assert( gamma_move(board, 7, 0, 68) == 1 );
assert( gamma_move(board, 1, 53, 0) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 0, 56) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 3, 0, 67) == 1 );
assert( gamma_move(board, 4, 74, 0) == 0 );
assert( gamma_move(board, 4, 0, 56) == 0 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 6, 34, 0) == 0 );
assert( gamma_move(board, 7, 0, 33) == 1 );
assert( gamma_free_fields(board, 7) == 62 );
assert( gamma_move(board, 1, 0, 62) == 1 );
assert( gamma_move(board, 1, 0, 72) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 101, 0) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_move(board, 4, 0, 51) == 1 );
assert( gamma_move(board, 4, 0, 71) == 0 );
assert( gamma_move(board, 5, 54, 0) == 0 );
assert( gamma_move(board, 6, 0, 90) == 0 );
assert( gamma_busy_fields(board, 6) == 6 );
assert( gamma_move(board, 7, 30, 0) == 0 );
assert( gamma_move(board, 1, 77, 0) == 0 );
assert( gamma_move(board, 1, 0, 58) == 1 );
assert( gamma_move(board, 2, 65, 0) == 0 );
assert( gamma_golden_move(board, 2, 96, 0) == 0 );
assert( gamma_move(board, 3, 99, 0) == 0 );
assert( gamma_move(board, 3, 0, 66) == 1 );
assert( gamma_move(board, 4, 0, 96) == 0 );
assert( gamma_move(board, 5, 20, 0) == 0 );
assert( gamma_move(board, 5, 0, 55) == 0 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 7, 41, 0) == 0 );
assert( gamma_move(board, 1, 0, 44) == 1 );
assert( gamma_free_fields(board, 1) == 57 );
assert( gamma_move(board, 2, 59, 0) == 0 );
assert( gamma_move(board, 2, 0, 14) == 1 );


char* board466727914 = gamma_board(board);
assert( board466727914 != NULL );
assert( strcmp(board466727914, 
".\n"
"7\n"
".\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
".\n"
".\n"
"3\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"4\n"
".\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"7\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"2\n") == 0);
free(board466727914);
board466727914 = NULL;
assert( gamma_move(board, 3, 82, 0) == 0 );
assert( gamma_move(board, 3, 0, 46) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 4, 0, 47) == 1 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 5, 0, 99) == 1 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 0, 58) == 0 );
assert( gamma_move(board, 1, 0, 86) == 1 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 2, 0, 18) == 0 );
assert( gamma_free_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 38, 0) == 0 );
assert( gamma_move(board, 3, 0, 61) == 1 );
assert( gamma_move(board, 4, 0, 70) == 1 );
assert( gamma_move(board, 5, 38, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 50) == 1 );
assert( gamma_golden_move(board, 6, 78, 0) == 0 );


char* board577412388 = gamma_board(board);
assert( board577412388 != NULL );
assert( strcmp(board577412388, 
".\n"
"7\n"
"5\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"4\n"
".\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"4\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"7\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
".\n"
".\n"
"2\n") == 0);
free(board577412388);
board577412388 = NULL;
assert( gamma_move(board, 7, 10, 0) == 0 );
assert( gamma_move(board, 7, 0, 31) == 1 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_golden_move(board, 1, 23, 0) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 0, 69) == 1 );
assert( gamma_move(board, 3, 73, 0) == 0 );
assert( gamma_move(board, 4, 22, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 8 );
assert( gamma_free_fields(board, 4) == 47 );
assert( gamma_move(board, 5, 17, 0) == 0 );
assert( gamma_move(board, 5, 0, 32) == 1 );
assert( gamma_busy_fields(board, 5) == 4 );
assert( gamma_free_fields(board, 5) == 46 );
assert( gamma_move(board, 6, 81, 0) == 0 );
assert( gamma_move(board, 7, 41, 0) == 0 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_move(board, 1, 0, 95) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 0, 80) == 1 );
assert( gamma_free_fields(board, 3) == 44 );
assert( gamma_move(board, 4, 0, 90) == 0 );
assert( gamma_move(board, 4, 0, 90) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 5, 0, 41) == 1 );
assert( gamma_move(board, 6, 1, 0) == 0 );
assert( gamma_move(board, 6, 0, 67) == 0 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 22, 0) == 0 );
assert( gamma_move(board, 7, 0, 41) == 0 );
assert( gamma_busy_fields(board, 7) == 7 );
assert( gamma_move(board, 2, 0, 86) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 0, 78) == 0 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_free_fields(board, 3) == 43 );
assert( gamma_move(board, 4, 0, 51) == 0 );
assert( gamma_move(board, 4, 0, 36) == 0 );
assert( gamma_move(board, 5, 64, 0) == 0 );
assert( gamma_move(board, 5, 0, 23) == 0 );
assert( gamma_golden_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 6, 25, 0) == 0 );
assert( gamma_move(board, 6, 0, 11) == 1 );
assert( gamma_move(board, 7, 82, 0) == 0 );
assert( gamma_free_fields(board, 7) == 42 );
assert( gamma_move(board, 1, 54, 0) == 0 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_free_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 0, 96) == 0 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 0, 72) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 5, 0, 94) == 0 );
assert( gamma_move(board, 6, 0, 84) == 0 );
assert( gamma_move(board, 7, 0, 78) == 0 );
assert( gamma_free_fields(board, 7) == 41 );
assert( gamma_move(board, 1, 0, 70) == 0 );


char* board384767715 = gamma_board(board);
assert( board384767715 != NULL );
assert( strcmp(board384767715, 
".\n"
"7\n"
"5\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
".\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"5\n"
".\n"
".\n"
"3\n"
".\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"4\n"
".\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"4\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
"5\n"
".\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
".\n"
"7\n"
"5\n"
"7\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"7\n"
"2\n"
"2\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"2\n") == 0);
free(board384767715);
board384767715 = NULL;
assert( gamma_move(board, 2, 73, 0) == 0 );
assert( gamma_move(board, 3, 48, 0) == 0 );
assert( gamma_move(board, 3, 0, 40) == 1 );
assert( gamma_move(board, 4, 82, 0) == 0 );
assert( gamma_move(board, 5, 0, 13) == 1 );
assert( gamma_move(board, 5, 0, 76) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 29, 0) == 0 );
assert( gamma_move(board, 7, 85, 0) == 0 );
assert( gamma_move(board, 7, 0, 30) == 1 );
assert( gamma_move(board, 1, 38, 0) == 0 );
assert( gamma_move(board, 1, 0, 81) == 1 );
assert( gamma_move(board, 2, 0, 34) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 0, 58) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 5, 20, 0) == 0 );
assert( gamma_free_fields(board, 5) == 36 );
assert( gamma_move(board, 6, 0, 87) == 0 );
assert( gamma_move(board, 7, 24, 0) == 0 );
assert( gamma_move(board, 7, 0, 72) == 0 );
assert( gamma_move(board, 1, 24, 0) == 0 );
assert( gamma_move(board, 2, 93, 0) == 0 );
assert( gamma_move(board, 3, 22, 0) == 0 );
assert( gamma_move(board, 3, 0, 51) == 0 );
assert( gamma_busy_fields(board, 3) == 7 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 79, 0) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_golden_move(board, 4, 69, 0) == 0 );
assert( gamma_move(board, 5, 73, 0) == 0 );
assert( gamma_move(board, 5, 0, 93) == 1 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_free_fields(board, 5) == 35 );
assert( gamma_move(board, 6, 0, 99) == 0 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_move(board, 7, 0, 6) == 0 );
assert( gamma_free_fields(board, 7) == 35 );
assert( gamma_move(board, 1, 38, 0) == 0 );
assert( gamma_move(board, 2, 21, 0) == 0 );
assert( gamma_move(board, 2, 0, 76) == 0 );
assert( gamma_move(board, 3, 25, 0) == 0 );
assert( gamma_move(board, 3, 0, 56) == 0 );
assert( gamma_move(board, 4, 0, 44) == 0 );
assert( gamma_move(board, 4, 0, 101) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 27, 0) == 0 );
assert( gamma_move(board, 5, 0, 79) == 1 );
assert( gamma_move(board, 6, 88, 0) == 0 );
assert( gamma_move(board, 7, 65, 0) == 0 );
assert( gamma_free_fields(board, 7) == 33 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_golden_move(board, 1, 68, 0) == 0 );
assert( gamma_move(board, 2, 73, 0) == 0 );
assert( gamma_free_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 54, 0) == 0 );
assert( gamma_move(board, 3, 0, 61) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 72) == 0 );
assert( gamma_move(board, 5, 48, 0) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );


char* board942041686 = gamma_board(board);
assert( board942041686 != NULL );
assert( strcmp(board942041686, 
"4\n"
"7\n"
"5\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
"3\n"
"5\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"4\n"
".\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"4\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
"5\n"
"3\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
"2\n"
"7\n"
"5\n"
"7\n"
"7\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"6\n"
"3\n"
".\n"
"7\n"
"2\n"
"2\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"2\n") == 0);
free(board942041686);
board942041686 = NULL;
assert( gamma_move(board, 6, 0, 60) == 0 );
assert( gamma_move(board, 6, 0, 15) == 0 );
assert( gamma_free_fields(board, 6) == 33 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 78) == 0 );
assert( gamma_move(board, 7, 0, 16) == 0 );
assert( gamma_move(board, 1, 0, 20) == 1 );
assert( gamma_move(board, 1, 0, 59) == 1 );
assert( gamma_move(board, 2, 0, 52) == 0 );
assert( gamma_move(board, 2, 0, 69) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 3, 0, 46) == 0 );
assert( gamma_free_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 25, 0) == 0 );
assert( gamma_move(board, 4, 0, 17) == 1 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_free_fields(board, 5) == 29 );
assert( gamma_move(board, 6, 53, 0) == 0 );
assert( gamma_move(board, 6, 0, 40) == 0 );
assert( gamma_move(board, 7, 0, 30) == 0 );
assert( gamma_move(board, 7, 0, 24) == 1 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 1, 0, 52) == 0 );


char* board619740993 = gamma_board(board);
assert( board619740993 != NULL );
assert( strcmp(board619740993, 
"4\n"
"7\n"
"5\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"5\n"
".\n"
"1\n"
"3\n"
"5\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"4\n"
"1\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"4\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
"5\n"
"3\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
"2\n"
"7\n"
"5\n"
"7\n"
"7\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"7\n"
"2\n"
".\n"
".\n"
"1\n"
"6\n"
"3\n"
"4\n"
"7\n"
"2\n"
"2\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
"1\n"
"3\n"
"2\n") == 0);
free(board619740993);
board619740993 = NULL;
assert( gamma_move(board, 2, 25, 0) == 0 );
assert( gamma_move(board, 2, 0, 82) == 1 );
assert( gamma_free_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 3, 0, 34) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 4, 0, 34) == 0 );
assert( gamma_move(board, 5, 10, 0) == 0 );
assert( gamma_move(board, 5, 0, 79) == 0 );
assert( gamma_move(board, 6, 53, 0) == 0 );
assert( gamma_free_fields(board, 6) == 27 );
assert( gamma_move(board, 1, 0, 58) == 0 );


char* board645870798 = gamma_board(board);
assert( board645870798 != NULL );
assert( strcmp(board645870798, 
"4\n"
"7\n"
"5\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"3\n"
"5\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"4\n"
"1\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"4\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
"5\n"
"3\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
"2\n"
"7\n"
"5\n"
"7\n"
"7\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"7\n"
"2\n"
".\n"
".\n"
"1\n"
"6\n"
"3\n"
"4\n"
"7\n"
"2\n"
"2\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
"1\n"
"3\n"
"2\n") == 0);
free(board645870798);
board645870798 = NULL;
assert( gamma_move(board, 2, 27, 0) == 0 );
assert( gamma_move(board, 3, 0, 49) == 0 );
assert( gamma_move(board, 4, 26, 0) == 0 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 6, 21, 0) == 0 );
assert( gamma_move(board, 6, 0, 36) == 0 );
assert( gamma_move(board, 7, 25, 0) == 0 );
assert( gamma_move(board, 7, 0, 4) == 0 );


char* board712185803 = gamma_board(board);
assert( board712185803 != NULL );
assert( strcmp(board712185803, 
"4\n"
"7\n"
"5\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"3\n"
"5\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"4\n"
"1\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"4\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
"5\n"
"3\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
"2\n"
"7\n"
"5\n"
"7\n"
"7\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"7\n"
"2\n"
".\n"
".\n"
"1\n"
"6\n"
"3\n"
"4\n"
"7\n"
"2\n"
"2\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
"1\n"
"3\n"
"2\n") == 0);
free(board712185803);
board712185803 = NULL;
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 2, 0, 35) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 29, 0) == 0 );
assert( gamma_free_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 0, 29) == 1 );
assert( gamma_golden_move(board, 4, 95, 0) == 0 );
assert( gamma_move(board, 5, 48, 0) == 0 );
assert( gamma_move(board, 6, 65, 0) == 0 );
assert( gamma_move(board, 6, 0, 55) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 80, 0) == 0 );


char* board788680306 = gamma_board(board);
assert( board788680306 != NULL );
assert( strcmp(board788680306, 
"4\n"
"7\n"
"5\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"3\n"
"5\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"4\n"
"1\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"4\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
"5\n"
"3\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
"2\n"
"7\n"
"5\n"
"7\n"
"7\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"7\n"
"2\n"
".\n"
".\n"
"1\n"
"6\n"
"3\n"
"4\n"
"7\n"
"2\n"
"2\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
"1\n"
"3\n"
"2\n") == 0);
free(board788680306);
board788680306 = NULL;
assert( gamma_move(board, 7, 0, 87) == 0 );


char* board581381013 = gamma_board(board);
assert( board581381013 != NULL );
assert( strcmp(board581381013, 
"4\n"
"7\n"
"5\n"
".\n"
".\n"
"6\n"
"6\n"
"4\n"
"5\n"
".\n"
".\n"
"6\n"
"2\n"
".\n"
"1\n"
"1\n"
".\n"
"3\n"
"5\n"
"2\n"
"1\n"
"3\n"
"5\n"
"1\n"
".\n"
"1\n"
"7\n"
".\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"7\n"
"3\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
"3\n"
"4\n"
"1\n"
"1\n"
"4\n"
"6\n"
"4\n"
".\n"
".\n"
"2\n"
"4\n"
"6\n"
"2\n"
".\n"
"4\n"
"2\n"
"6\n"
"1\n"
"1\n"
"5\n"
"5\n"
"3\n"
"2\n"
".\n"
".\n"
"7\n"
"1\n"
"2\n"
"7\n"
"5\n"
"7\n"
"7\n"
"4\n"
"4\n"
".\n"
".\n"
".\n"
"7\n"
"2\n"
".\n"
".\n"
"1\n"
"6\n"
"3\n"
"4\n"
"7\n"
"2\n"
"2\n"
"5\n"
".\n"
"6\n"
".\n"
".\n"
"1\n"
"1\n"
"1\n"
".\n"
"1\n"
"1\n"
"1\n"
"3\n"
"2\n") == 0);
free(board581381013);
board581381013 = NULL;
assert( gamma_move(board, 1, 38, 0) == 0 );
assert( gamma_move(board, 1, 0, 40) == 0 );


gamma_delete(board);

    return 0;
}
