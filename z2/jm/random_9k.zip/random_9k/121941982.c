#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 121941982
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(10, 17, 4, 38);
assert( board != NULL );


assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 2, 9, 8) == 1 );
assert( gamma_free_fields(board, 2) == 169 );
assert( gamma_move(board, 3, 5, 16) == 1 );
assert( gamma_move(board, 3, 8, 14) == 1 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 4, 7, 4) == 1 );
assert( gamma_move(board, 1, 9, 12) == 1 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 3, 0, 12) == 1 );


char* board728286248 = gamma_board(board);
assert( board728286248 != NULL );
assert( strcmp(board728286248, 
".....3....\n"
"..........\n"
"........3.\n"
"..........\n"
"3........1\n"
"..........\n"
"..........\n"
"..........\n"
".........2\n"
"..........\n"
"..........\n"
".........2\n"
".......4..\n"
"..........\n"
"..........\n"
"..........\n"
"....3.....\n") == 0);
free(board728286248);
board728286248 = NULL;
assert( gamma_move(board, 4, 5, 13) == 1 );
assert( gamma_move(board, 4, 5, 12) == 1 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_move(board, 2, 3, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 3 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 4, 3, 5) == 1 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_free_fields(board, 1) == 154 );
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_busy_fields(board, 2) == 5 );
assert( gamma_move(board, 3, 6, 2) == 1 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_free_fields(board, 1) == 148 );
assert( gamma_move(board, 2, 1, 12) == 1 );
assert( gamma_move(board, 2, 7, 8) == 1 );
assert( gamma_free_fields(board, 2) == 146 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board381352338 = gamma_board(board);
assert( board381352338 != NULL );
assert( strcmp(board381352338, 
".....3....\n"
"..........\n"
"........3.\n"
".....4....\n"
"32...4...1\n"
"..........\n"
".......1..\n"
"...1......\n"
".......2.2\n"
"...2.....1\n"
"..3.......\n"
"..14.....2\n"
".......4..\n"
"...2......\n"
"..2...3...\n"
"....4.....\n"
"...33.....\n") == 0);
free(board381352338);
board381352338 = NULL;
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 9, 6) == 1 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_free_fields(board, 3) == 143 );
assert( gamma_move(board, 4, 6, 7) == 1 );
assert( gamma_free_fields(board, 4) == 142 );
assert( gamma_free_fields(board, 1) == 142 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_move(board, 3, 9, 15) == 1 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_move(board, 1, 4, 8) == 1 );
assert( gamma_move(board, 1, 4, 4) == 1 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 6, 8) == 1 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_move(board, 1, 4, 9) == 1 );
assert( gamma_move(board, 1, 9, 14) == 1 );
assert( gamma_move(board, 2, 16, 1) == 0 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 1, 9, 1) == 1 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 3, 2, 9) == 1 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_golden_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_free_fields(board, 2) == 126 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 7, 0) == 1 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 2, 4, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 3, 6, 0) == 1 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board770443666 = gamma_board(board);
assert( board770443666 != NULL );
assert( strcmp(board770443666, 
".....3....\n"
".........3\n"
"........31\n"
".....4....\n"
"32...4...1\n"
".4........\n"
".......1..\n"
"..311.....\n"
"....1432.2\n"
"...2..4..1\n"
"..3.2....4\n"
"2.14.....2\n"
"...21..4..\n"
"...243.1..\n"
".42..33...\n"
"2...4....1\n"
".1433334.2\n") == 0);
free(board770443666);
board770443666 = NULL;
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_free_fields(board, 1) == 118 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 5) == 1 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 8, 16) == 1 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_move(board, 4, 15, 4) == 0 );
assert( gamma_move(board, 4, 6, 9) == 1 );
assert( gamma_free_fields(board, 4) == 113 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );


char* board426030791 = gamma_board(board);
assert( board426030791 != NULL );
assert( strcmp(board426030791, 
".....3..2.\n"
".........3\n"
"........31\n"
".....4....\n"
"32...4...1\n"
".4........\n"
".......1..\n"
"..311.4..1\n"
"....1432.2\n"
"...2..4..1\n"
"..3.2....4\n"
"2.143..2.2\n"
"...21..4..\n"
"...243.1..\n"
".42..33...\n"
"2...4....1\n"
"41433334.2\n") == 0);
free(board426030791);
board426030791 = NULL;
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_move(board, 4, 8, 15) == 1 );
assert( gamma_golden_move(board, 4, 7, 9) == 0 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 3, 2, 12) == 1 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_move(board, 1, 0, 8) == 1 );
assert( gamma_move(board, 1, 0, 3) == 1 );
assert( gamma_golden_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_golden_move(board, 2, 8, 4) == 1 );


char* board412960707 = gamma_board(board);
assert( board412960707 != NULL );
assert( strcmp(board412960707, 
".....3..2.\n"
"........43\n"
"........31\n"
".....4....\n"
"323..4...1\n"
".4........\n"
".......1..\n"
".4311.4..1\n"
"1..21432.2\n"
"...2..4..1\n"
"..3.2....4\n"
"2.1132.2.2\n"
"...21..42.\n"
"1.1243.1..\n"
".42..33..2\n"
"2...4....1\n"
"41433334.2\n") == 0);
free(board412960707);
board412960707 = NULL;
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 0, 7) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 7, 11) == 1 );
assert( gamma_move(board, 2, 1, 8) == 1 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 16, 9) == 0 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_free_fields(board, 1) == 97 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 7) == 1 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 6, 1) == 1 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 1, 9, 16) == 1 );
assert( gamma_free_fields(board, 1) == 93 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 2, 6, 11) == 0 );


char* board329516034 = gamma_board(board);
assert( board329516034 != NULL );
assert( strcmp(board329516034, 
".....3..21\n"
"........43\n"
"......3.31\n"
".....4....\n"
"323..4...1\n"
".42...42..\n"
".......1..\n"
".4311.4..1\n"
"12.21432.2\n"
"1..2..42.1\n"
"..3.2....4\n"
"2.1132.2.2\n"
"...21..42.\n"
"1.1243.1..\n"
".42.133..2\n"
"2...444..1\n"
"41433334.2\n") == 0);
free(board329516034);
board329516034 = NULL;
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 1, 3, 6) == 1 );
assert( gamma_move(board, 1, 4, 15) == 1 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_move(board, 1, 0, 10) == 1 );
assert( gamma_move(board, 1, 9, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 9) == 1 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 4, 6, 15) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_free_fields(board, 1) == 85 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 16) == 1 );


char* board600978397 = gamma_board(board);
assert( board600978397 != NULL );
assert( strcmp(board600978397, 
".....3.321\n"
"....1.4.43\n"
"......3.31\n"
".....4...1\n"
"323..4...1\n"
".42...42..\n"
"1...4..1..\n"
".431124..1\n"
"12.21432.2\n"
"1..2..42.1\n"
"..312...24\n"
"2.1132.2.2\n"
"..221..42.\n"
"1.1243.1..\n"
".42.133..2\n"
"2...444..1\n"
"41433334.2\n") == 0);
free(board600978397);
board600978397 = NULL;
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_move(board, 4, 3, 10) == 1 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 2, 12) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 1, 6, 6) == 1 );
assert( gamma_move(board, 2, 16, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 8, 6) == 0 );


char* board482814801 = gamma_board(board);
assert( board482814801 != NULL );
assert( strcmp(board482814801, 
".....3.321\n"
"....1.4.43\n"
"..3...3.31\n"
".....4..31\n"
"323..4...1\n"
".424..42.3\n"
"1..44..1..\n"
".431124..1\n"
"12.21432.2\n"
"1..2..42.1\n"
"..31221.24\n"
"2.1132.2.2\n"
"..221..42.\n"
"1.1243.1.1\n"
"3423133.22\n"
"2...444..1\n"
"41433334.2\n") == 0);
free(board482814801);
board482814801 = NULL;
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 1, 13) == 1 );
assert( gamma_free_fields(board, 4) == 69 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 8, 7) == 1 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_golden_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 7, 13) == 1 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 7, 7) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 2, 16, 3) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 6, 5) == 1 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 4, 0, 0) == 0 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_move(board, 2, 16, 4) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 3, 3, 6) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 4, 9, 4) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 8, 11) == 1 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_move(board, 4, 0, 11) == 1 );


char* board819353657 = gamma_board(board);
assert( board819353657 != NULL );
assert( strcmp(board819353657, 
".....3.321\n"
"....1.4.43\n"
"..3...3.31\n"
".4...4.231\n"
"323..4...1\n"
"4424..4233\n"
"1..44.11..\n"
".431124..1\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"2.113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23..4443.1\n"
"41433334.2\n") == 0);
free(board819353657);
board819353657 = NULL;
assert( gamma_move(board, 1, 16, 1) == 0 );
assert( gamma_free_fields(board, 2) == 57 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );


char* board121676865 = gamma_board(board);
assert( board121676865 != NULL );
assert( strcmp(board121676865, 
".....3.321\n"
"....1.4.43\n"
"..3...3.31\n"
".4...4.231\n"
"323..4...1\n"
"4424..4233\n"
"1..44.11..\n"
".431124..1\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"2.113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23..4443.1\n"
"41433334.2\n") == 0);
free(board121676865);
board121676865 = NULL;
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 1, 16, 3) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 15, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 2, 0, 8) == 0 );


char* board134101817 = gamma_board(board);
assert( board134101817 != NULL );
assert( strcmp(board134101817, 
".....3.321\n"
"....1.4.43\n"
"..3...3.31\n"
".4...4.231\n"
"323..4...1\n"
"4424..4233\n"
"1..44.11..\n"
".431124..1\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"2.113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23..4443.1\n"
"41433334.2\n") == 0);
free(board134101817);
board134101817 = NULL;
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_free_fields(board, 3) == 57 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_move(board, 4, 6, 13) == 1 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );


char* board416691871 = gamma_board(board);
assert( board416691871 != NULL );
assert( strcmp(board416691871, 
".....3.321\n"
"....1.4.43\n"
"..3...3.31\n"
".4...44231\n"
"323..4...1\n"
"4424..4233\n"
"1..44.11..\n"
".431124..1\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"2.113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23..4443.1\n"
"41433334.2\n") == 0);
free(board416691871);
board416691871 = NULL;
assert( gamma_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_free_fields(board, 4) == 56 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 1, 4, 15) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_free_fields(board, 4) == 55 );
assert( gamma_move(board, 1, 15, 0) == 0 );


char* board334091591 = gamma_board(board);
assert( board334091591 != NULL );
assert( strcmp(board334091591, 
".....3.321\n"
"....1.4.43\n"
"2.3...3.31\n"
".4...44231\n"
"323..4...1\n"
"4424..4233\n"
"1..44.11..\n"
".431124..1\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"2.113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23..4443.1\n"
"41433334.2\n") == 0);
free(board334091591);
board334091591 = NULL;
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );


char* board455972024 = gamma_board(board);
assert( board455972024 != NULL );
assert( strcmp(board455972024, 
".....3.321\n"
"....1.4.43\n"
"2.3...3.31\n"
".4...44231\n"
"323..42..1\n"
"4424..4233\n"
"1..44.11..\n"
".431124..1\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"2.113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23..4443.1\n"
"41433334.2\n") == 0);
free(board455972024);
board455972024 = NULL;
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 2, 16) == 1 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_free_fields(board, 2) == 53 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_free_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_free_fields(board, 4) == 53 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 3, 3, 13) == 1 );
assert( gamma_move(board, 4, 4, 14) == 1 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 4, 8, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 3, 1) == 1 );
assert( gamma_move(board, 4, 6, 14) == 0 );


char* board249060953 = gamma_board(board);
assert( board249060953 != NULL );
assert( strcmp(board249060953, 
"..3..3.321\n"
"....1.4.43\n"
"2.3.4.3.31\n"
".4.3.44231\n"
"323..42..1\n"
"4424..4233\n"
"12.44.11..\n"
".431124.41\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"2.113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23.44443.1\n"
"41433334.2\n") == 0);
free(board249060953);
board249060953 = NULL;
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 15) == 0 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 3, 1, 5) == 1 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );


char* board436489002 = gamma_board(board);
assert( board436489002 != NULL );
assert( strcmp(board436489002, 
"..3..3.321\n"
"....1.4.43\n"
"2.3.4.3.31\n"
".4.3.44231\n"
"323..42..1\n"
"4424..4233\n"
"12.44.11..\n"
".431124.41\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"23113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23.44443.1\n"
"4143333422\n") == 0);
free(board436489002);
board436489002 = NULL;
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 4, 7, 15) == 1 );
assert( gamma_free_fields(board, 4) == 45 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 2, 1) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );


char* board357531114 = gamma_board(board);
assert( board357531114 != NULL );
assert( strcmp(board357531114, 
"..3..3.321\n"
"....1.4443\n"
"2.3.4.3.31\n"
".4.3.44231\n"
"323..42..1\n"
"4424..4233\n"
"12.44.11..\n"
".431124.41\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"23113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board357531114);
board357531114 = NULL;
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_free_fields(board, 4) == 44 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_move(board, 3, 8, 16) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 6) == 0 );
assert( gamma_move(board, 4, 2, 15) == 1 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board228624701 = gamma_board(board);
assert( board228624701 != NULL );
assert( strcmp(board228624701, 
"..3..3.321\n"
"..4.1.4443\n"
"2.3.4.3.31\n"
".4.3.44231\n"
"323..42..1\n"
"4424..4233\n"
"12.44.11..\n"
".431124.41\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"23113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3423133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board228624701);
board228624701 = NULL;
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_golden_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );


char* board578277414 = gamma_board(board);
assert( board578277414 != NULL );
assert( strcmp(board578277414, 
"..3..3.321\n"
"..4.1.4443\n"
"2.3.4.3.31\n"
".4.3.44231\n"
"323..42..1\n"
"4424..4233\n"
"12.44.11..\n"
".431124.41\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"23113232.2\n"
"..22111424\n"
"1.1243.1.1\n"
"3443133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board578277414);
board578277414 = NULL;
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 32 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 12, 4) == 0 );


char* board200118848 = gamma_board(board);
assert( board200118848 != NULL );
assert( strcmp(board200118848, 
"..3..3.321\n"
"..4.1.4443\n"
"2.3.4.3.31\n"
".4.3.44231\n"
"323..42..1\n"
"4424..4233\n"
"12.44.11..\n"
".431124.41\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"23113232.2\n"
"..22111424\n"
"131243.1.1\n"
"3443133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board200118848);
board200118848 = NULL;
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_free_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 15, 1) == 0 );
assert( gamma_free_fields(board, 4) == 42 );
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_move(board, 2, 16, 3) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 7, 9) == 1 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_golden_move(board, 2, 8, 5) == 0 );


char* board957089843 = gamma_board(board);
assert( board957089843 != NULL );
assert( strcmp(board957089843, 
"..3..3.321\n"
"..4.1.4443\n"
"2.3.4.3.31\n"
".4.3.44231\n"
"323..42..1\n"
"4424..4233\n"
"12.44.11..\n"
".431124441\n"
"12.21432.2\n"
"13.2..4211\n"
"..31221.24\n"
"23113232.2\n"
"..22111424\n"
"13124311.1\n"
"3443133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board957089843);
board957089843 = NULL;
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 4, 5, 7) == 1 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_golden_move(board, 4, 12, 0) == 0 );


char* board567156775 = gamma_board(board);
assert( board567156775 != NULL );
assert( strcmp(board567156775, 
"..3..3.321\n"
"..4.1.4443\n"
"2.3.4.3.31\n"
".4.3.44231\n"
"323..42..1\n"
"4424..4233\n"
"12.44.11..\n"
".431124441\n"
"12.21432.2\n"
"13.2.44211\n"
"..31221.24\n"
"23113232.2\n"
"..22111424\n"
"13124311.1\n"
"3443133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board567156775);
board567156775 = NULL;
assert( gamma_move(board, 1, 8, 8) == 1 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_free_fields(board, 4) == 38 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_golden_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 1, 3, 14) == 1 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );


char* board756293723 = gamma_board(board);
assert( board756293723 != NULL );
assert( strcmp(board756293723, 
"..3..3.321\n"
"..4.1.4443\n"
"2.314.3.31\n"
".4.3.44231\n"
"323..42.41\n"
"4424..4233\n"
"12.44.11..\n"
".431124441\n"
"12.2143212\n"
"13.2.44211\n"
"..31221324\n"
"23113232.2\n"
"2.22111424\n"
"13124311.1\n"
"3443133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board756293723);
board756293723 = NULL;
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 2, 8, 11) == 0 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_golden_move(board, 4, 0, 1) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 36 );
assert( gamma_move(board, 1, 6, 7) == 0 );
assert( gamma_golden_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 2, 16, 1) == 0 );
assert( gamma_move(board, 3, 0, 14) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_golden_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 0, 0) == 0 );


char* board644842622 = gamma_board(board);
assert( board644842622 != NULL );
assert( strcmp(board644842622, 
"..3..3.321\n"
"..4.1.4443\n"
"2.314.3231\n"
".4.3.44231\n"
"323..42.41\n"
"4424..4233\n"
"12.44.11..\n"
".431124441\n"
"12.2143212\n"
"13.2.44211\n"
"..31221324\n"
"23113232.2\n"
"2.22111424\n"
"13124311.1\n"
"3443133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board644842622);
board644842622 = NULL;
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 2, 16) == 0 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_free_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 1, 1, 15) == 1 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 2, 0) == 0 );
assert( gamma_free_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_free_fields(board, 2) == 31 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );


char* board889552645 = gamma_board(board);
assert( board889552645 != NULL );
assert( strcmp(board889552645, 
"..3..3.321\n"
".14.1.4443\n"
"2.314.3231\n"
".4.3.44231\n"
"323..42.41\n"
"44241.4233\n"
"12.44.11..\n"
".431124441\n"
"12.2143212\n"
"13.2.44211\n"
"..31221324\n"
"23113232.2\n"
"2.22111424\n"
"13124311.1\n"
"3443133122\n"
"23144443.1\n"
"4143333422\n") == 0);
free(board889552645);
board889552645 = NULL;
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 2, 16, 1) == 0 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


gamma_delete(board);

    return 0;
}
