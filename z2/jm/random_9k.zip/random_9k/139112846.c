#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 139112846
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 164, 5, 22);
assert( board != NULL );


assert( gamma_move(board, 1, 75, 0) == 0 );
assert( gamma_move(board, 1, 0, 76) == 1 );
assert( gamma_move(board, 2, 0, 158) == 1 );
assert( gamma_busy_fields(board, 2) == 1 );
assert( gamma_move(board, 3, 39, 0) == 0 );
assert( gamma_move(board, 4, 0, 48) == 1 );
assert( gamma_free_fields(board, 4) == 161 );
assert( gamma_move(board, 5, 44, 0) == 0 );
assert( gamma_move(board, 5, 0, 58) == 1 );
assert( gamma_golden_move(board, 5, 76, 0) == 0 );
assert( gamma_move(board, 1, 0, 88) == 1 );
assert( gamma_move(board, 1, 0, 122) == 1 );
assert( gamma_move(board, 2, 0, 76) == 0 );
assert( gamma_move(board, 3, 33, 0) == 0 );
assert( gamma_move(board, 3, 0, 117) == 1 );
assert( gamma_busy_fields(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 56) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 75, 0) == 0 );
assert( gamma_move(board, 5, 0, 110) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 132, 0) == 0 );
assert( gamma_move(board, 1, 0, 127) == 1 );
assert( gamma_golden_move(board, 1, 110, 0) == 0 );
assert( gamma_move(board, 2, 23, 0) == 0 );
assert( gamma_move(board, 3, 128, 0) == 0 );
assert( gamma_free_fields(board, 3) == 154 );
assert( gamma_move(board, 5, 0, 115) == 1 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 1, 143, 0) == 0 );
assert( gamma_move(board, 2, 0, 18) == 1 );
assert( gamma_move(board, 2, 0, 37) == 1 );
assert( gamma_free_fields(board, 2) == 151 );
assert( gamma_move(board, 3, 131, 0) == 0 );
assert( gamma_golden_move(board, 3, 76, 0) == 0 );
assert( gamma_move(board, 4, 47, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 2 );
assert( gamma_move(board, 5, 0, 152) == 1 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 0, 32) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 60, 0) == 0 );
assert( gamma_move(board, 2, 0, 21) == 1 );
assert( gamma_busy_fields(board, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 5, 61, 0) == 0 );
assert( gamma_move(board, 1, 0, 94) == 1 );
assert( gamma_move(board, 2, 0, 92) == 1 );
assert( gamma_move(board, 2, 0, 88) == 0 );
assert( gamma_move(board, 3, 51, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 86, 0) == 0 );
assert( gamma_move(board, 5, 95, 0) == 0 );
assert( gamma_move(board, 2, 0, 84) == 1 );
assert( gamma_move(board, 3, 66, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 73, 0) == 0 );
assert( gamma_move(board, 4, 0, 90) == 1 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 5, 0, 140) == 1 );
assert( gamma_move(board, 1, 91, 0) == 0 );
assert( gamma_move(board, 1, 0, 39) == 1 );
assert( gamma_move(board, 2, 0, 143) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 26) == 1 );
assert( gamma_move(board, 4, 109, 0) == 0 );
assert( gamma_move(board, 4, 0, 102) == 1 );
assert( gamma_busy_fields(board, 4) == 4 );
assert( gamma_move(board, 5, 148, 0) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 0, 27) == 1 );
assert( gamma_move(board, 2, 118, 0) == 0 );
assert( gamma_move(board, 3, 25, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 2 );
assert( gamma_move(board, 4, 0, 126) == 1 );
assert( gamma_move(board, 5, 0, 129) == 1 );
assert( gamma_move(board, 5, 0, 142) == 1 );
assert( gamma_move(board, 1, 163, 0) == 0 );
assert( gamma_move(board, 3, 42, 0) == 0 );
assert( gamma_move(board, 3, 0, 80) == 1 );
assert( gamma_move(board, 4, 57, 0) == 0 );
assert( gamma_move(board, 5, 35, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 7 );
assert( gamma_move(board, 1, 0, 150) == 1 );
assert( gamma_move(board, 2, 161, 0) == 0 );
assert( gamma_move(board, 3, 64, 0) == 0 );
assert( gamma_move(board, 3, 0, 45) == 1 );
assert( gamma_move(board, 4, 89, 0) == 0 );
assert( gamma_move(board, 4, 0, 28) == 1 );
assert( gamma_move(board, 5, 0, 152) == 0 );
assert( gamma_move(board, 5, 0, 61) == 1 );
assert( gamma_move(board, 1, 0, 62) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 77, 0) == 0 );


char* board979634715 = gamma_board(board);
assert( board979634715 != NULL );
assert( strcmp(board979634715, 
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board979634715);
board979634715 = NULL;
assert( gamma_move(board, 3, 119, 0) == 0 );
assert( gamma_move(board, 3, 0, 15) == 1 );
assert( gamma_move(board, 4, 112, 0) == 0 );
assert( gamma_move(board, 5, 125, 0) == 0 );
assert( gamma_free_fields(board, 5) == 128 );
assert( gamma_move(board, 1, 154, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_free_fields(board, 1) == 128 );


char* board489393793 = gamma_board(board);
assert( board489393793 != NULL );
assert( strcmp(board489393793, 
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board489393793);
board489393793 = NULL;
assert( gamma_move(board, 2, 116, 0) == 0 );
assert( gamma_move(board, 3, 30, 0) == 0 );
assert( gamma_free_fields(board, 3) == 128 );
assert( gamma_move(board, 4, 69, 0) == 0 );
assert( gamma_move(board, 4, 0, 98) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 118, 0) == 0 );
assert( gamma_move(board, 5, 0, 30) == 1 );
assert( gamma_free_fields(board, 5) == 126 );
assert( gamma_move(board, 1, 160, 0) == 0 );
assert( gamma_move(board, 1, 0, 60) == 1 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 0, 101) == 1 );
assert( gamma_move(board, 4, 0, 160) == 1 );
assert( gamma_move(board, 4, 0, 149) == 1 );
assert( gamma_move(board, 1, 133, 0) == 0 );
assert( gamma_move(board, 2, 116, 0) == 0 );
assert( gamma_free_fields(board, 2) == 122 );
assert( gamma_move(board, 3, 34, 0) == 0 );
assert( gamma_move(board, 3, 0, 90) == 0 );
assert( gamma_move(board, 4, 128, 0) == 0 );
assert( gamma_move(board, 5, 155, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 45, 0) == 0 );
assert( gamma_move(board, 1, 0, 92) == 0 );
assert( gamma_move(board, 1, 0, 163) == 1 );
assert( gamma_move(board, 2, 0, 78) == 1 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_free_fields(board, 3) == 120 );
assert( gamma_move(board, 4, 153, 0) == 0 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 0, 27) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 0, 115) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 65) == 1 );
assert( gamma_move(board, 2, 0, 97) == 1 );
assert( gamma_move(board, 3, 104, 0) == 0 );
assert( gamma_move(board, 3, 0, 51) == 1 );
assert( gamma_move(board, 4, 68, 0) == 0 );
assert( gamma_move(board, 4, 0, 33) == 1 );
assert( gamma_move(board, 5, 103, 0) == 0 );
assert( gamma_move(board, 5, 0, 12) == 1 );
assert( gamma_free_fields(board, 5) == 114 );
assert( gamma_move(board, 1, 89, 0) == 0 );
assert( gamma_move(board, 1, 0, 111) == 1 );
assert( gamma_move(board, 2, 135, 0) == 0 );
assert( gamma_move(board, 3, 0, 150) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 24, 0) == 0 );


char* board536450110 = gamma_board(board);
assert( board536450110 != NULL );
assert( strcmp(board536450110, 
"1\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"5\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board536450110);
board536450110 = NULL;
assert( gamma_move(board, 1, 159, 0) == 0 );
assert( gamma_move(board, 1, 0, 77) == 1 );
assert( gamma_move(board, 2, 69, 0) == 0 );
assert( gamma_move(board, 2, 0, 127) == 0 );


char* board704998550 = gamma_board(board);
assert( board704998550 != NULL );
assert( strcmp(board704998550, 
"1\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"2\n"
"1\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"5\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board704998550);
board704998550 = NULL;
assert( gamma_move(board, 4, 112, 0) == 0 );
assert( gamma_move(board, 5, 93, 0) == 0 );
assert( gamma_move(board, 5, 0, 152) == 0 );
assert( gamma_move(board, 1, 114, 0) == 0 );
assert( gamma_move(board, 1, 0, 25) == 1 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 0, 138) == 1 );
assert( gamma_move(board, 3, 91, 0) == 0 );
assert( gamma_move(board, 4, 0, 113) == 1 );
assert( gamma_move(board, 5, 0, 7) == 1 );
assert( gamma_move(board, 1, 81, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 41) == 1 );
assert( gamma_move(board, 3, 95, 0) == 0 );
assert( gamma_move(board, 3, 0, 28) == 0 );
assert( gamma_move(board, 4, 93, 0) == 0 );
assert( gamma_move(board, 5, 75, 0) == 0 );
assert( gamma_move(board, 5, 0, 41) == 0 );


char* board530594780 = gamma_board(board);
assert( board530594780 != NULL );
assert( strcmp(board530594780, 
"1\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
"5\n"
".\n"
"5\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"2\n"
"1\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"5\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board530594780);
board530594780 = NULL;
assert( gamma_move(board, 1, 134, 0) == 0 );
assert( gamma_move(board, 1, 0, 139) == 1 );
assert( gamma_move(board, 2, 79, 0) == 0 );
assert( gamma_move(board, 3, 0, 149) == 0 );
assert( gamma_move(board, 3, 0, 148) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 4, 0, 13) == 1 );
assert( gamma_move(board, 5, 0, 117) == 0 );
assert( gamma_move(board, 5, 0, 53) == 1 );
assert( gamma_move(board, 1, 71, 0) == 0 );
assert( gamma_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 3, 35, 0) == 0 );
assert( gamma_move(board, 3, 0, 75) == 1 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 5, 134, 0) == 0 );
assert( gamma_move(board, 5, 0, 101) == 0 );
assert( gamma_move(board, 1, 70, 0) == 0 );
assert( gamma_move(board, 1, 0, 142) == 0 );
assert( gamma_free_fields(board, 1) == 100 );
assert( gamma_move(board, 2, 0, 79) == 1 );
assert( gamma_move(board, 3, 19, 0) == 0 );
assert( gamma_move(board, 3, 0, 127) == 0 );
assert( gamma_move(board, 4, 0, 58) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 16, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 0, 83) == 1 );
assert( gamma_move(board, 2, 0, 151) == 1 );
assert( gamma_move(board, 3, 0, 85) == 1 );
assert( gamma_free_fields(board, 3) == 96 );
assert( gamma_move(board, 4, 86, 0) == 0 );
assert( gamma_move(board, 4, 0, 106) == 1 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 0, 62) == 0 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 0, 146) == 1 );
assert( gamma_move(board, 1, 0, 138) == 0 );
assert( gamma_move(board, 2, 70, 0) == 0 );
assert( gamma_move(board, 2, 0, 5) == 1 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 0, 25) == 0 );
assert( gamma_move(board, 5, 67, 0) == 0 );
assert( gamma_free_fields(board, 5) == 93 );
assert( gamma_move(board, 1, 93, 0) == 0 );
assert( gamma_move(board, 1, 0, 142) == 0 );
assert( gamma_move(board, 2, 145, 0) == 0 );
assert( gamma_move(board, 3, 0, 79) == 0 );
assert( gamma_move(board, 3, 0, 106) == 0 );
assert( gamma_move(board, 4, 67, 0) == 0 );
assert( gamma_move(board, 5, 73, 0) == 0 );
assert( gamma_golden_move(board, 5, 79, 0) == 0 );
assert( gamma_move(board, 1, 0, 68) == 1 );
assert( gamma_move(board, 2, 0, 163) == 0 );
assert( gamma_move(board, 3, 0, 20) == 1 );
assert( gamma_move(board, 3, 0, 80) == 0 );
assert( gamma_move(board, 4, 66, 0) == 0 );


char* board139287708 = gamma_board(board);
assert( board139287708 != NULL );
assert( strcmp(board139287708, 
"1\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
"5\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"5\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
"3\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
".\n") == 0);
free(board139287708);
board139287708 = NULL;
assert( gamma_move(board, 5, 0, 155) == 1 );
assert( gamma_move(board, 1, 0, 137) == 1 );
assert( gamma_move(board, 1, 0, 51) == 0 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 0, 141) == 1 );
assert( gamma_move(board, 3, 24, 0) == 0 );
assert( gamma_move(board, 3, 0, 101) == 0 );
assert( gamma_move(board, 4, 0, 27) == 0 );
assert( gamma_move(board, 4, 0, 75) == 0 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 1, 0, 157) == 1 );
assert( gamma_move(board, 1, 0, 85) == 0 );
assert( gamma_move(board, 2, 66, 0) == 0 );
assert( gamma_move(board, 2, 0, 50) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 38, 0) == 0 );
assert( gamma_move(board, 4, 131, 0) == 0 );
assert( gamma_move(board, 4, 0, 100) == 1 );
assert( gamma_free_fields(board, 4) == 85 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 43, 0) == 0 );
assert( gamma_move(board, 1, 31, 0) == 0 );
assert( gamma_move(board, 2, 70, 0) == 0 );
assert( gamma_move(board, 2, 0, 127) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_free_fields(board, 2) == 85 );
assert( gamma_move(board, 3, 71, 0) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 4, 0, 143) == 0 );
assert( gamma_move(board, 5, 161, 0) == 0 );
assert( gamma_move(board, 1, 125, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 91, 0) == 0 );


char* board965464084 = gamma_board(board);
assert( board965464084 != NULL );
assert( strcmp(board965464084, 
"1\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"1\n"
".\n"
"5\n"
".\n"
".\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"1\n"
"5\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
"3\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
".\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
".\n") == 0);
free(board965464084);
board965464084 = NULL;
assert( gamma_move(board, 3, 0, 120) == 1 );
assert( gamma_move(board, 3, 0, 70) == 1 );
assert( gamma_move(board, 4, 130, 0) == 0 );
assert( gamma_move(board, 4, 0, 153) == 1 );
assert( gamma_move(board, 5, 103, 0) == 0 );
assert( gamma_move(board, 5, 0, 37) == 0 );
assert( gamma_move(board, 1, 72, 0) == 0 );
assert( gamma_move(board, 2, 0, 54) == 1 );
assert( gamma_move(board, 3, 104, 0) == 0 );
assert( gamma_move(board, 4, 42, 0) == 0 );
assert( gamma_move(board, 4, 0, 158) == 0 );
assert( gamma_move(board, 5, 67, 0) == 0 );
assert( gamma_free_fields(board, 5) == 81 );
assert( gamma_move(board, 1, 0, 145) == 1 );
assert( gamma_move(board, 2, 0, 119) == 1 );
assert( gamma_move(board, 3, 46, 0) == 0 );
assert( gamma_move(board, 3, 0, 67) == 1 );
assert( gamma_move(board, 4, 42, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 114, 0) == 0 );
assert( gamma_move(board, 5, 0, 84) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_move(board, 2, 0, 36) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 64, 0) == 0 );
assert( gamma_move(board, 4, 0, 100) == 0 );
assert( gamma_move(board, 4, 0, 148) == 0 );
assert( gamma_golden_move(board, 4, 142, 0) == 0 );
assert( gamma_move(board, 1, 57, 0) == 0 );
assert( gamma_move(board, 2, 159, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_move(board, 3, 73, 0) == 0 );
assert( gamma_move(board, 3, 0, 25) == 0 );
assert( gamma_move(board, 4, 19, 0) == 0 );
assert( gamma_free_fields(board, 4) == 76 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 121, 0) == 0 );
assert( gamma_move(board, 5, 0, 116) == 1 );
assert( gamma_move(board, 1, 66, 0) == 0 );
assert( gamma_move(board, 1, 0, 22) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 0, 104) == 1 );
assert( gamma_move(board, 3, 0, 43) == 1 );
assert( gamma_move(board, 4, 74, 0) == 0 );
assert( gamma_move(board, 5, 82, 0) == 0 );
assert( gamma_move(board, 5, 0, 64) == 1 );
assert( gamma_move(board, 1, 82, 0) == 0 );
assert( gamma_move(board, 1, 0, 79) == 0 );
assert( gamma_move(board, 2, 40, 0) == 0 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_move(board, 3, 0, 53) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 23) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 0, 156) == 1 );
assert( gamma_move(board, 1, 0, 59) == 1 );
assert( gamma_move(board, 2, 154, 0) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_golden_move(board, 2, 13, 0) == 0 );


char* board246930650 = gamma_board(board);
assert( board246930650 != NULL );
assert( strcmp(board246930650, 
"1\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
".\n"
"4\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
".\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
".\n") == 0);
free(board246930650);
board246930650 = NULL;
assert( gamma_move(board, 3, 112, 0) == 0 );
assert( gamma_move(board, 3, 0, 133) == 1 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_move(board, 5, 108, 0) == 0 );
assert( gamma_move(board, 1, 161, 0) == 0 );
assert( gamma_move(board, 1, 0, 94) == 0 );
assert( gamma_move(board, 2, 0, 127) == 0 );
assert( gamma_move(board, 2, 0, 149) == 0 );
assert( gamma_move(board, 3, 0, 75) == 0 );
assert( gamma_free_fields(board, 3) == 68 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 99, 0) == 0 );
assert( gamma_move(board, 4, 0, 70) == 0 );
assert( gamma_golden_move(board, 4, 26, 0) == 0 );
assert( gamma_move(board, 5, 147, 0) == 0 );
assert( gamma_move(board, 1, 74, 0) == 0 );
assert( gamma_move(board, 2, 57, 0) == 0 );
assert( gamma_move(board, 2, 0, 70) == 0 );
assert( gamma_move(board, 4, 114, 0) == 0 );
assert( gamma_move(board, 4, 0, 35) == 1 );
assert( gamma_move(board, 5, 132, 0) == 0 );
assert( gamma_move(board, 5, 0, 105) == 1 );
assert( gamma_move(board, 1, 22, 0) == 0 );
assert( gamma_move(board, 2, 0, 104) == 0 );
assert( gamma_move(board, 2, 0, 41) == 0 );
assert( gamma_move(board, 3, 118, 0) == 0 );
assert( gamma_move(board, 4, 0, 59) == 0 );
assert( gamma_move(board, 5, 0, 123) == 1 );
assert( gamma_free_fields(board, 5) == 65 );
assert( gamma_golden_possible(board, 5) == 1 );


char* board847388570 = gamma_board(board);
assert( board847388570 != NULL );
assert( strcmp(board847388570, 
"1\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
".\n"
"4\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
".\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
".\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
".\n") == 0);
free(board847388570);
board847388570 = NULL;
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 0, 79) == 0 );
assert( gamma_move(board, 3, 46, 0) == 0 );
assert( gamma_move(board, 3, 0, 55) == 1 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_free_fields(board, 4) == 64 );
assert( gamma_move(board, 1, 0, 29) == 0 );
assert( gamma_move(board, 2, 130, 0) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 4, 0, 63) == 1 );
assert( gamma_move(board, 5, 0, 18) == 0 );
assert( gamma_move(board, 5, 0, 48) == 0 );


char* board662782441 = gamma_board(board);
assert( board662782441 != NULL );
assert( strcmp(board662782441, 
"1\n"
".\n"
".\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
".\n"
"4\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
".\n"
"4\n"
".\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
"4\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"3\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
".\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
".\n") == 0);
free(board662782441);
board662782441 = NULL;
assert( gamma_move(board, 1, 132, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 49, 0) == 0 );
assert( gamma_move(board, 3, 0, 110) == 0 );
assert( gamma_golden_move(board, 3, 98, 0) == 0 );
assert( gamma_move(board, 4, 0, 102) == 0 );
assert( gamma_move(board, 5, 82, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_move(board, 1, 162, 0) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 2, 0, 47) == 1 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 49, 0) == 0 );
assert( gamma_move(board, 4, 0, 62) == 0 );
assert( gamma_golden_move(board, 4, 139, 0) == 0 );
assert( gamma_golden_move(board, 5, 104, 0) == 0 );
assert( gamma_move(board, 1, 71, 0) == 0 );
assert( gamma_move(board, 2, 0, 104) == 0 );
assert( gamma_move(board, 2, 0, 69) == 1 );
assert( gamma_move(board, 3, 0, 106) == 0 );
assert( gamma_move(board, 3, 0, 148) == 0 );
assert( gamma_move(board, 4, 0, 61) == 0 );
assert( gamma_move(board, 4, 0, 151) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 89, 0) == 0 );
assert( gamma_move(board, 5, 0, 161) == 1 );
assert( gamma_free_fields(board, 5) == 60 );
assert( gamma_move(board, 1, 0, 161) == 0 );
assert( gamma_move(board, 1, 0, 59) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 74, 0) == 0 );
assert( gamma_move(board, 3, 0, 111) == 0 );
assert( gamma_move(board, 4, 66, 0) == 0 );
assert( gamma_move(board, 5, 73, 0) == 0 );
assert( gamma_move(board, 5, 0, 157) == 0 );
assert( gamma_move(board, 1, 22, 0) == 0 );
assert( gamma_move(board, 2, 99, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 71, 0) == 0 );
assert( gamma_move(board, 3, 0, 19) == 1 );
assert( gamma_golden_move(board, 3, 100, 0) == 0 );
assert( gamma_move(board, 4, 162, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 46, 0) == 0 );
assert( gamma_move(board, 1, 0, 125) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 158) == 0 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_move(board, 5, 0, 17) == 1 );
assert( gamma_move(board, 1, 40, 0) == 0 );
assert( gamma_move(board, 1, 0, 23) == 0 );
assert( gamma_move(board, 2, 74, 0) == 0 );
assert( gamma_move(board, 3, 46, 0) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 0, 30) == 0 );
assert( gamma_move(board, 4, 0, 141) == 0 );
assert( gamma_move(board, 5, 0, 68) == 0 );
assert( gamma_free_fields(board, 5) == 58 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 1, 0, 53) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 109, 0) == 0 );
assert( gamma_move(board, 2, 0, 163) == 0 );
assert( gamma_move(board, 3, 132, 0) == 0 );
assert( gamma_move(board, 3, 0, 92) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 44, 0) == 0 );
assert( gamma_move(board, 5, 0, 78) == 0 );
assert( gamma_move(board, 1, 24, 0) == 0 );
assert( gamma_move(board, 1, 0, 84) == 0 );
assert( gamma_move(board, 2, 31, 0) == 0 );
assert( gamma_free_fields(board, 2) == 58 );
assert( gamma_move(board, 3, 0, 100) == 0 );
assert( gamma_move(board, 4, 40, 0) == 0 );
assert( gamma_move(board, 4, 0, 163) == 0 );
assert( gamma_move(board, 5, 0, 72) == 1 );
assert( gamma_move(board, 5, 0, 149) == 0 );
assert( gamma_move(board, 1, 95, 0) == 0 );
assert( gamma_move(board, 1, 0, 97) == 0 );
assert( gamma_move(board, 2, 34, 0) == 0 );
assert( gamma_move(board, 2, 0, 89) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 123) == 0 );
assert( gamma_move(board, 4, 0, 41) == 0 );
assert( gamma_move(board, 5, 0, 64) == 0 );
assert( gamma_move(board, 1, 109, 0) == 0 );
assert( gamma_move(board, 1, 0, 129) == 0 );
assert( gamma_move(board, 2, 0, 92) == 0 );
assert( gamma_move(board, 2, 0, 141) == 0 );
assert( gamma_move(board, 3, 0, 41) == 0 );
assert( gamma_move(board, 3, 0, 36) == 0 );
assert( gamma_move(board, 4, 0, 16) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 5, 99, 0) == 0 );
assert( gamma_move(board, 5, 0, 114) == 1 );
assert( gamma_move(board, 1, 162, 0) == 0 );
assert( gamma_move(board, 1, 0, 151) == 0 );
assert( gamma_free_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 0, 91) == 1 );
assert( gamma_move(board, 2, 0, 9) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 3, 0, 97) == 0 );
assert( gamma_move(board, 5, 118, 0) == 0 );
assert( gamma_golden_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 1, 103, 0) == 0 );
assert( gamma_move(board, 2, 0, 157) == 0 );


char* board645201371 = gamma_board(board);
assert( board645201371 != NULL );
assert( strcmp(board645201371, 
"1\n"
".\n"
"5\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
"5\n"
"4\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"2\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
"4\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"3\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
"2\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"5\n"
"4\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
".\n") == 0);
free(board645201371);
board645201371 = NULL;
assert( gamma_move(board, 3, 40, 0) == 0 );
assert( gamma_move(board, 3, 0, 111) == 0 );
assert( gamma_move(board, 5, 109, 0) == 0 );


char* board877365511 = gamma_board(board);
assert( board877365511 != NULL );
assert( strcmp(board877365511, 
"1\n"
".\n"
"5\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
"5\n"
"4\n"
".\n"
"1\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"2\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
"4\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"3\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
"2\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"5\n"
"4\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
".\n") == 0);
free(board877365511);
board877365511 = NULL;
assert( gamma_move(board, 1, 0, 18) == 0 );
assert( gamma_move(board, 2, 0, 158) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 0, 109) == 1 );
assert( gamma_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 0, 115) == 0 );
assert( gamma_move(board, 5, 0, 137) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 31, 0) == 0 );
assert( gamma_move(board, 1, 0, 36) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 162, 0) == 0 );


char* board130205044 = gamma_board(board);
assert( board130205044 != NULL );
assert( strcmp(board130205044, 
"1\n"
".\n"
"5\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
"5\n"
"4\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"5\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"2\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
"4\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"3\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
"2\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"5\n"
"4\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
"4\n") == 0);
free(board130205044);
board130205044 = NULL;
assert( gamma_move(board, 3, 0, 115) == 0 );


char* board832846813 = gamma_board(board);
assert( board832846813 != NULL );
assert( strcmp(board832846813, 
"1\n"
".\n"
"5\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
"5\n"
"4\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"5\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"2\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
"4\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"3\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
"2\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"5\n"
"4\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
"4\n") == 0);
free(board832846813);
board832846813 = NULL;
assert( gamma_move(board, 5, 147, 0) == 0 );
assert( gamma_move(board, 5, 0, 32) == 0 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_move(board, 1, 159, 0) == 0 );
assert( gamma_move(board, 1, 0, 152) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_free_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 118, 0) == 0 );
assert( gamma_move(board, 2, 0, 125) == 0 );
assert( gamma_move(board, 3, 154, 0) == 0 );
assert( gamma_move(board, 3, 0, 127) == 0 );
assert( gamma_free_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 131, 0) == 0 );
assert( gamma_move(board, 4, 0, 78) == 0 );
assert( gamma_move(board, 5, 96, 0) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );


char* board583630399 = gamma_board(board);
assert( board583630399 != NULL );
assert( strcmp(board583630399, 
"1\n"
".\n"
"5\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
"5\n"
"4\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"5\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
".\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
".\n"
"5\n"
".\n"
"3\n"
"2\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
"4\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"3\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
"2\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"5\n"
"4\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
"4\n") == 0);
free(board583630399);
board583630399 = NULL;
assert( gamma_move(board, 2, 99, 0) == 0 );
assert( gamma_move(board, 3, 144, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 5, 128, 0) == 0 );
assert( gamma_move(board, 1, 107, 0) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 124, 0) == 0 );
assert( gamma_free_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 66, 0) == 0 );
assert( gamma_move(board, 3, 0, 96) == 1 );
assert( gamma_free_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 103, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 5, 0, 106) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 0, 118) == 0 );
assert( gamma_move(board, 3, 112, 0) == 0 );
assert( gamma_move(board, 3, 0, 111) == 0 );
assert( gamma_move(board, 4, 0, 66) == 0 );
assert( gamma_move(board, 4, 0, 53) == 0 );
assert( gamma_free_fields(board, 4) == 16 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 71, 0) == 0 );
assert( gamma_move(board, 5, 0, 150) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 107) == 0 );
assert( gamma_move(board, 2, 0, 128) == 0 );
assert( gamma_move(board, 3, 112, 0) == 0 );
assert( gamma_move(board, 3, 0, 73) == 1 );
assert( gamma_move(board, 4, 0, 141) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 125, 0) == 0 );
assert( gamma_move(board, 5, 0, 149) == 0 );
assert( gamma_move(board, 2, 136, 0) == 0 );
assert( gamma_move(board, 2, 0, 140) == 0 );
assert( gamma_move(board, 3, 103, 0) == 0 );
assert( gamma_move(board, 3, 0, 61) == 0 );
assert( gamma_move(board, 4, 0, 80) == 0 );
assert( gamma_move(board, 4, 0, 136) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 95, 0) == 0 );


char* board456027667 = gamma_board(board);
assert( board456027667 != NULL );
assert( strcmp(board456027667, 
"1\n"
".\n"
"5\n"
"4\n"
".\n"
"2\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"5\n"
"2\n"
"1\n"
"4\n"
"3\n"
".\n"
"1\n"
"1\n"
".\n"
"2\n"
"5\n"
"2\n"
"5\n"
"1\n"
"2\n"
"1\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"1\n"
"4\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
"3\n"
"2\n"
".\n"
"3\n"
"5\n"
"5\n"
"5\n"
"4\n"
".\n"
"1\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
"5\n"
"3\n"
".\n"
"4\n"
"2\n"
"4\n"
".\n"
"4\n"
"2\n"
"3\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"1\n"
".\n"
".\n"
"3\n"
"2\n"
"2\n"
"1\n"
"1\n"
"3\n"
".\n"
"3\n"
"5\n"
".\n"
"3\n"
"2\n"
"1\n"
"3\n"
".\n"
"2\n"
"5\n"
"4\n"
"1\n"
"5\n"
"1\n"
"1\n"
"5\n"
".\n"
"4\n"
"3\n"
"2\n"
"5\n"
".\n"
"3\n"
"2\n"
".\n"
"4\n"
"2\n"
".\n"
"3\n"
".\n"
"3\n"
".\n"
"2\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"4\n"
".\n"
"4\n"
"1\n"
".\n"
"5\n"
".\n"
"4\n"
"1\n"
"3\n"
"1\n"
".\n"
"4\n"
".\n"
"2\n"
"3\n"
"3\n"
"2\n"
"5\n"
"4\n"
"3\n"
"1\n"
"4\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
"5\n"
".\n"
"2\n"
".\n"
"4\n"
"1\n"
".\n"
"4\n") == 0);
free(board456027667);
board456027667 = NULL;
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 1, 0, 23) == 0 );
assert( gamma_move(board, 2, 0, 22) == 1 );
assert( gamma_move(board, 3, 0, 95) == 1 );
assert( gamma_busy_fields(board, 3) == 22 );


gamma_delete(board);

    return 0;
}
