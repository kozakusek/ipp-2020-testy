#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 123394848
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(11, 18, 3, 35);
assert( board != NULL );


assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_move(board, 2, 0, 11) == 1 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_move(board, 2, 8, 4) == 1 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 1, 10, 6) == 1 );
assert( gamma_free_fields(board, 1) == 190 );


char* board128859092 = gamma_board(board);
assert( board128859092 != NULL );
assert( strcmp(board128859092, 
"...........\n"
"...........\n"
"...........\n"
"...........\n"
"...........\n"
"...........\n"
"2.....2....\n"
"...........\n"
"...........\n"
"...........\n"
"...........\n"
"..........1\n"
"1..........\n"
"...3....2..\n"
"...........\n"
"...........\n"
".2....3....\n"
"...........\n") == 0);
free(board128859092);
board128859092 = NULL;
assert( gamma_move(board, 2, 3, 8) == 1 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 9, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 3 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 1, 10, 12) == 1 );
assert( gamma_move(board, 2, 17, 6) == 0 );
assert( gamma_move(board, 2, 9, 2) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 3, 0, 13) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 1, 10, 2) == 1 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_move(board, 1, 17, 9) == 0 );


char* board695920108 = gamma_board(board);
assert( board695920108 != NULL );
assert( strcmp(board695920108, 
"...........\n"
"...........\n"
"...........\n"
"...........\n"
"3..........\n"
"..........1\n"
"2.....2....\n"
"...........\n"
"...........\n"
"...2....23.\n"
"...........\n"
"..........1\n"
"1.....1....\n"
"...33...2..\n"
"......3....\n"
"....3....21\n"
".2....3....\n"
"...........\n") == 0);
free(board695920108);
board695920108 = NULL;
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 1, 6, 0) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 3, 5, 5) == 1 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_move(board, 1, 5, 14) == 1 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 3, 1, 16) == 1 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_free_fields(board, 2) == 164 );
assert( gamma_move(board, 3, 7, 6) == 1 );
assert( gamma_move(board, 1, 5, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 7, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 6, 2) == 1 );
assert( gamma_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 12, 0) == 0 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 1, 5, 16) == 1 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_free_fields(board, 1) == 150 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_move(board, 1, 8, 15) == 1 );
assert( gamma_move(board, 2, 3, 0) == 1 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_free_fields(board, 2) == 143 );
assert( gamma_move(board, 3, 7, 2) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 1, 15, 3) == 0 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 3, 7, 1) == 1 );
assert( gamma_move(board, 3, 0, 16) == 1 );
assert( gamma_golden_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 1, 9, 7) == 1 );
assert( gamma_move(board, 1, 4, 10) == 1 );


char* board341819170 = gamma_board(board);
assert( board341819170 != NULL );
assert( strcmp(board341819170, 
"...........\n"
"33...1.....\n"
"........1..\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....2..31\n"
"...21....3.\n"
"......1....\n"
"...2..2.33.\n"
"...31....1.\n"
"2...1..3.31\n"
"1...3311..3\n"
"1..332.32..\n"
"...3..3...1\n"
".2323.13221\n"
"22....3332.\n"
"22.2..1.3.1\n") == 0);
free(board341819170);
board341819170 = NULL;
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_free_fields(board, 2) == 129 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_move(board, 3, 3, 15) == 1 );
assert( gamma_free_fields(board, 3) == 127 );


char* board257599686 = gamma_board(board);
assert( board257599686 != NULL );
assert( strcmp(board257599686, 
"...........\n"
"33...1.....\n"
"...3....1..\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....2..31\n"
"...21....3.\n"
"......1....\n"
"...2.32.33.\n"
"...313...1.\n"
"2...1..3.31\n"
"1...3311..3\n"
"1..332.32..\n"
"...3..3...1\n"
".2323.13221\n"
"22....3332.\n"
"22.2..1.3.1\n") == 0);
free(board257599686);
board257599686 = NULL;
assert( gamma_move(board, 1, 17, 7) == 0 );
assert( gamma_move(board, 2, 0, 7) == 1 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_golden_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 3, 6, 7) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 2, 17) == 1 );
assert( gamma_golden_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 4, 15) == 1 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_move(board, 3, 16, 3) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_free_fields(board, 1) == 118 );
assert( gamma_move(board, 3, 5, 6) == 1 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 2, 2, 4) == 1 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 3, 7, 17) == 1 );
assert( gamma_move(board, 1, 16, 8) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 3, 13, 6) == 0 );
assert( gamma_move(board, 3, 2, 10) == 1 );
assert( gamma_free_fields(board, 3) == 113 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 1, 9, 15) == 1 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 2, 17) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );


char* board463497299 = gamma_board(board);
assert( board463497299 != NULL );
assert( strcmp(board463497299, 
"..1....3...\n"
"33...1.....\n"
"...32...11.\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....2..31\n"
"3.321....3.\n"
"......1....\n"
"...2.32.33.\n"
"2..3133.31.\n"
"2...1333.31\n"
"1...3311..3\n"
"1.2332.32..\n"
"...3..3..31\n"
".2323.13221\n"
"22..233332.\n"
"22.2..1.3.1\n") == 0);
free(board463497299);
board463497299 = NULL;
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 2, 10, 15) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 1, 17, 10) == 0 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 7, 16) == 1 );


char* board113750026 = gamma_board(board);
assert( board113750026 != NULL );
assert( strcmp(board113750026, 
"..1....3...\n"
"33...1.2...\n"
"...32...112\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....2..31\n"
"3.321....3.\n"
"......1....\n"
"...2.32.33.\n"
"2..3133331.\n"
"2..31333.31\n"
"1.1.3311..3\n"
"1.2332.32..\n"
"...3..3..31\n"
".2323.13221\n"
"22..233332.\n"
"22.2..1.3.1\n") == 0);
free(board113750026);
board113750026 = NULL;
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 1, 10, 15) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_free_fields(board, 1) == 106 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 5, 14) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );


char* board376860667 = gamma_board(board);
assert( board376860667 != NULL );
assert( strcmp(board376860667, 
"..1....3...\n"
"33...1.2...\n"
"...32...112\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....2..31\n"
"3.321....3.\n"
"......1..3.\n"
"...2.32.33.\n"
"2..3133331.\n"
"2..31333.31\n"
"1.1.3311..3\n"
"1.2332.32..\n"
"...3..3..31\n"
".2323.13221\n"
"22..233332.\n"
"22.2..1.3.1\n") == 0);
free(board376860667);
board376860667 = NULL;
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_move(board, 2, 17, 9) == 0 );
assert( gamma_free_fields(board, 2) == 106 );
assert( gamma_golden_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_golden_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 2, 7, 2) == 0 );
assert( gamma_free_fields(board, 2) == 104 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_free_fields(board, 3) == 103 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 13, 2) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );


char* board604984051 = gamma_board(board);
assert( board604984051 != NULL );
assert( strcmp(board604984051, 
"..1....3...\n"
"33...1.2...\n"
"...32...112\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....23.31\n"
"3.321....3.\n"
"......1..3.\n"
"...2.32.331\n"
"2..3133331.\n"
"2..31333.31\n"
"1.1.3311..3\n"
"1.2332.32..\n"
"...3..3..31\n"
".2223.13221\n"
"22..233332.\n"
"22.2..133.1\n") == 0);
free(board604984051);
board604984051 = NULL;
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_busy_fields(board, 2) == 28 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 15, 5) == 0 );


char* board751513915 = gamma_board(board);
assert( board751513915 != NULL );
assert( strcmp(board751513915, 
"..1....3...\n"
"33...1.2...\n"
"...32...112\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....23.31\n"
"3.321....3.\n"
"..2...1..3.\n"
"...2.32.331\n"
"2..3133331.\n"
"2..31333.31\n"
"1.1.3311..3\n"
"1.2332.32..\n"
"...3..3..31\n"
".2223.13221\n"
"22..233332.\n"
"22.2..133.1\n") == 0);
free(board751513915);
board751513915 = NULL;
assert( gamma_move(board, 3, 6, 15) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 43 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 9, 17) == 1 );
assert( gamma_golden_move(board, 2, 17, 7) == 0 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 2, 9, 16) == 1 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 44 );
assert( gamma_move(board, 1, 13, 1) == 0 );
assert( gamma_move(board, 1, 9, 16) == 0 );
assert( gamma_free_fields(board, 1) == 98 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 0, 16) == 0 );
assert( gamma_free_fields(board, 3) == 97 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 1, 7, 10) == 1 );


char* board849632020 = gamma_board(board);
assert( board849632020 != NULL );
assert( strcmp(board849632020, 
"..1....3.2.\n"
"33...1.2.2.\n"
"...32.3.112\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....23.31\n"
"3.321..1.3.\n"
"..2...1..3.\n"
"...2.32.331\n"
"2..3133331.\n"
"2.231333.31\n"
"1.1.3311..3\n"
"1.2332.32..\n"
".3.3..3..31\n"
".2223.13221\n"
"22..233332.\n"
"22.2..133.1\n") == 0);
free(board849632020);
board849632020 = NULL;
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );


char* board472356838 = gamma_board(board);
assert( board472356838 != NULL );
assert( strcmp(board472356838, 
"..1....3.2.\n"
"33...1.2.2.\n"
"...32.3.112\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"2.....23.31\n"
"3.321..1.3.\n"
"..2...1..3.\n"
"...2.32.331\n"
"2..3133331.\n"
"2.231333131\n"
"1.1.3311..3\n"
"1.2332.32..\n"
".3.32.3..31\n"
".2223.13221\n"
"22..233332.\n"
"22.2..133.1\n") == 0);
free(board472356838);
board472356838 = NULL;
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 1, 10, 16) == 1 );
assert( gamma_move(board, 1, 0, 15) == 1 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_free_fields(board, 3) == 89 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_free_fields(board, 2) == 86 );


char* board881320407 = gamma_board(board);
assert( board881320407 != NULL );
assert( strcmp(board881320407, 
"..1....3.2.\n"
"33...1.2.21\n"
"1..32.3.112\n"
".....1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"23....23.31\n"
"3.321..1.3.\n"
"..2...1..3.\n"
"...2.32.331\n"
"2..3133331.\n"
"23231333131\n"
"1.1.3311..3\n"
"1.2332.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..233332.\n"
"22.23.133.1\n") == 0);
free(board881320407);
board881320407 = NULL;
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_golden_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_golden_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_free_fields(board, 3) == 84 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 3, 7, 9) == 1 );
assert( gamma_move(board, 3, 7, 8) == 1 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 5, 0) == 1 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 9, 16) == 0 );


char* board875118541 = gamma_board(board);
assert( board875118541 != NULL );
assert( strcmp(board875118541, 
"..1....3.2.\n"
"33...1.2.21\n"
"1..32.3.112\n"
"...3.1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"23....23.31\n"
"3.321..1.3.\n"
"1.2...13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311..3\n"
"1.2332.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..233332.\n"
"22.232133.1\n") == 0);
free(board875118541);
board875118541 = NULL;
assert( gamma_move(board, 3, 10, 16) == 0 );
assert( gamma_free_fields(board, 3) == 80 );


char* board858462857 = gamma_board(board);
assert( board858462857 != NULL );
assert( strcmp(board858462857, 
"..1....3.2.\n"
"33...1.2.21\n"
"1..32.3.112\n"
"...3.1.2...\n"
"3....1.....\n"
"1..2..3...1\n"
"23....23.31\n"
"3.321..1.3.\n"
"1.2...13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311..3\n"
"1.2332.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..233332.\n"
"22.232133.1\n") == 0);
free(board858462857);
board858462857 = NULL;
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 35 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 2, 5, 17) == 1 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );
assert( gamma_free_fields(board, 3) == 78 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 1, 4, 17) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_move(board, 1, 17, 6) == 0 );
assert( gamma_move(board, 1, 8, 15) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 33 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 3, 7, 15) == 1 );
assert( gamma_free_fields(board, 3) == 76 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 1, 17, 0) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_golden_move(board, 2, 16, 5) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 1, 8, 16) == 1 );
assert( gamma_move(board, 1, 2, 12) == 1 );


char* board930062649 = gamma_board(board);
assert( board930062649 != NULL );
assert( strcmp(board930062649, 
"..1.12.3.2.\n"
"33...1.2121\n"
"1..32.33112\n"
"...3.1.2...\n"
"3....1.....\n"
"1.12..3...1\n"
"23....23.31\n"
"3.321..1.3.\n"
"1.2...13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311..3\n"
"1.2332.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..2333322\n"
"22.232133.1\n") == 0);
free(board930062649);
board930062649 = NULL;
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 7, 9) == 0 );


char* board861398627 = gamma_board(board);
assert( board861398627 != NULL );
assert( strcmp(board861398627, 
"..1.12.3.2.\n"
"33...1.2121\n"
"1..32.33112\n"
"...3.1.2...\n"
"3....1.....\n"
"1.12..3...1\n"
"23....23.31\n"
"3.321..1.3.\n"
"1.2...13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311..3\n"
"1.2332.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..2333322\n"
"22.232133.1\n") == 0);
free(board861398627);
board861398627 = NULL;
assert( gamma_move(board, 1, 5, 6) == 0 );


char* board475632158 = gamma_board(board);
assert( board475632158 != NULL );
assert( strcmp(board475632158, 
"..1.12.3.2.\n"
"33...1.2121\n"
"1..32.33112\n"
"...3.1.2...\n"
"3....1.....\n"
"1.12..3...1\n"
"23....23.31\n"
"3.321..1.3.\n"
"1.2...13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311..3\n"
"1.2332.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..2333322\n"
"22.232133.1\n") == 0);
free(board475632158);
board475632158 = NULL;
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_golden_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 3, 4) == 1 );


char* board557227648 = gamma_board(board);
assert( board557227648 != NULL );
assert( strcmp(board557227648, 
"..1.12.3.2.\n"
"33...1.2121\n"
"1..32.33112\n"
"...3.1.2...\n"
"3....1.....\n"
"1.12..3...1\n"
"23....23.31\n"
"3.321..1.3.\n"
"1.2...13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311..3\n"
"1.2132.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..2333322\n"
"223232133.1\n") == 0);
free(board557227648);
board557227648 = NULL;
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 1, 10, 6) == 0 );
assert( gamma_golden_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 17, 10) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 36 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 3, 3, 11) == 1 );
assert( gamma_move(board, 1, 9, 5) == 1 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 3, 6) == 0 );
assert( gamma_free_fields(board, 2) == 70 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 10, 13) == 1 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_free_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 1, 7, 17) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_golden_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_free_fields(board, 1) == 66 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_golden_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 3, 15) == 0 );


char* board679532779 = gamma_board(board);
assert( board679532779 != NULL );
assert( strcmp(board679532779, 
"..1.12.3.2.\n"
"33...1.2121\n"
"1..32.33112\n"
"2..3.1.2...\n"
"3....1....1\n"
"1.12.23...1\n"
"23.3..23.31\n"
"3.321..1.3.\n"
"1323..13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311.13\n"
"1.2132.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..2333322\n"
"223232133.1\n") == 0);
free(board679532779);
board679532779 = NULL;
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 9, 12) == 1 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_free_fields(board, 2) == 65 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board935632223 = gamma_board(board);
assert( board935632223 != NULL );
assert( strcmp(board935632223, 
"..1.12.3.2.\n"
"33...1.2121\n"
"1..32.33112\n"
"2..3.1.2...\n"
"3....1....1\n"
"1.12.23..31\n"
"23.3..23.31\n"
"3.321..1.3.\n"
"1323..13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311.13\n"
"1.2132.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..2333322\n"
"223232133.1\n") == 0);
free(board935632223);
board935632223 = NULL;
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 16, 10) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );


char* board137662222 = gamma_board(board);
assert( board137662222 != NULL );
assert( strcmp(board137662222, 
"..1.12.3.2.\n"
"33...1.2121\n"
"1..32.33112\n"
"2..3.1.2...\n"
"3....1....1\n"
"1.12.23..31\n"
"23.3..23.31\n"
"3.321..1.3.\n"
"1323..13.3.\n"
"...2.323331\n"
"2..3133331.\n"
"23231333131\n"
"121.3311.13\n"
"1.2132.3212\n"
".3.32.3.331\n"
".2223.13221\n"
"22..2333322\n"
"223232133.1\n") == 0);
free(board137662222);
board137662222 = NULL;
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_move(board, 1, 5, 16) == 0 );
assert( gamma_move(board, 2, 1, 17) == 1 );
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 1, 4, 17) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_golden_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 3, 16) == 1 );
assert( gamma_move(board, 1, 8, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_free_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_free_fields(board, 3) == 59 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_free_fields(board, 3) == 58 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 10, 9) == 1 );
assert( gamma_free_fields(board, 1) == 57 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 10, 7) == 1 );


char* board535029713 = gamma_board(board);
assert( board535029713 != NULL );
assert( strcmp(board535029713, 
".21.12.3.2.\n"
"33.3.1.2121\n"
"1..32.33112\n"
"22.3.1.2...\n"
"3....1....1\n"
"1.12.23..31\n"
"23.31323.31\n"
"3.321..1.3.\n"
"1323..13131\n"
"...2.323331\n"
"2..31333312\n"
"23231333131\n"
"12123311.13\n"
"1.2132.3212\n"
".3.32.3.331\n"
"32223.13221\n"
"22..2333322\n"
"223232133.1\n") == 0);
free(board535029713);
board535029713 = NULL;
assert( gamma_move(board, 3, 4, 6) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 1, 2) == 0 );
assert( gamma_move(board, 3, 17, 0) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 43 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 7, 4) == 0 );


char* board483814297 = gamma_board(board);
assert( board483814297 != NULL );
assert( strcmp(board483814297, 
".21.12.3.2.\n"
"33.3.1.2121\n"
"1..32.33112\n"
"22.3.1.2...\n"
"3....1....1\n"
"1112.23..31\n"
"23331323.31\n"
"31321..1.3.\n"
"1323..13131\n"
"...2.323331\n"
"2..31333312\n"
"23231333131\n"
"12123311.13\n"
"1.2132.3212\n"
".3.32.3.331\n"
"32223.13221\n"
"22..2333322\n"
"223232133.1\n") == 0);
free(board483814297);
board483814297 = NULL;
assert( gamma_move(board, 1, 16, 2) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );


char* board383644918 = gamma_board(board);
assert( board383644918 != NULL );
assert( strcmp(board383644918, 
".21.12.3.2.\n"
"33.3.1.2121\n"
"1..32.33112\n"
"22.3.1.2...\n"
"3....1....1\n"
"1112.23..31\n"
"23331323.31\n"
"31321..1.3.\n"
"1323..13131\n"
"...2.323331\n"
"2..31333312\n"
"23231333131\n"
"12123311.13\n"
"1.2132.3212\n"
".3.32.3.331\n"
"32223.13221\n"
"22..2333322\n"
"223232133.1\n") == 0);
free(board383644918);
board383644918 = NULL;
assert( gamma_move(board, 2, 14, 8) == 0 );
assert( gamma_move(board, 2, 4, 8) == 1 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_free_fields(board, 3) == 50 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 9, 15) == 0 );
assert( gamma_golden_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 61 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 2, 8) == 1 );


char* board337487925 = gamma_board(board);
assert( board337487925 != NULL );
assert( strcmp(board337487925, 
".21.12.3.2.\n"
"33.3.1.2121\n"
"1..32.33112\n"
"22.3.1.2...\n"
"3....1....1\n"
"1112.23..31\n"
"23331323.31\n"
"31321..1.3.\n"
"1323..13131\n"
"3.122323331\n"
"2..31333312\n"
"23231333131\n"
"12123311.13\n"
"1.2132.3212\n"
".3.32.3.331\n"
"32223.13221\n"
"22..2333322\n"
"223232133.1\n") == 0);
free(board337487925);
board337487925 = NULL;
assert( gamma_free_fields(board, 2) == 49 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 2, 16, 6) == 0 );
assert( gamma_move(board, 2, 9, 15) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 1, 5, 5) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 9, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 45 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 3, 7, 16) == 0 );
assert( gamma_move(board, 1, 8, 14) == 1 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 1, 7, 17) == 0 );
assert( gamma_move(board, 2, 17, 8) == 0 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_golden_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 3, 6, 13) == 1 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 45 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 13, 8) == 0 );
assert( gamma_move(board, 3, 5, 10) == 1 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_free_fields(board, 2) == 42 );
assert( gamma_golden_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 2, 16) == 1 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 1, 3, 6) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_move(board, 1, 5, 8) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_move(board, 3, 10, 15) == 0 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 5, 17) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 1, 8) == 1 );


char* board875542743 = gamma_board(board);
assert( board875542743 != NULL );
assert( strcmp(board875542743, 
".21.12.3.2.\n"
"3333.1.2121\n"
"1..32.33112\n"
"22.3.1321..\n"
"31...13...1\n"
"1112.23..31\n"
"23331323.31\n"
"31321331.3.\n"
"1323..13131\n"
"33122323331\n"
"2..31333312\n"
"23231333131\n"
"12123311.13\n"
"1.2132.3212\n"
".3.3233.331\n"
"32223.13221\n"
"22..2333322\n"
"22323213321\n") == 0);
free(board875542743);
board875542743 = NULL;
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_free_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 3, 3, 17) == 1 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_golden_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 1, 2, 14) == 1 );
assert( gamma_golden_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 8, 16) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 3, 4, 13) == 1 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );


char* board111690292 = gamma_board(board);
assert( board111690292 != NULL );
assert( strcmp(board111690292, 
".21312.3.2.\n"
"3333.1.2121\n"
"1..32.33112\n"
"2213.1321..\n"
"31..313...1\n"
"1112.23..31\n"
"23331323.31\n"
"31321331.3.\n"
"1323..13131\n"
"33122323331\n"
"2..31333312\n"
"23231333131\n"
"12123311.13\n"
"1.2132.3212\n"
".313233.331\n"
"32223.13221\n"
"22..2333322\n"
"22323213321\n") == 0);
free(board111690292);
board111690292 = NULL;
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 45 );


char* board287361237 = gamma_board(board);
assert( board287361237 != NULL );
assert( strcmp(board287361237, 
".21312.3.2.\n"
"3333.1.2121\n"
"1..32.33112\n"
"2213.1321..\n"
"31..313...1\n"
"1112.23..31\n"
"23331323.31\n"
"31321331.3.\n"
"1323..13131\n"
"33122323331\n"
"2..31333312\n"
"23231333131\n"
"12123311.13\n"
"1.2132.3212\n"
".313233.331\n"
"32223.13221\n"
"22..2333322\n"
"22323213321\n") == 0);
free(board287361237);
board287361237 = NULL;
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 1, 15, 1) == 0 );


char* board768820026 = gamma_board(board);
assert( board768820026 != NULL );
assert( strcmp(board768820026, 
".21312.3.2.\n"
"3333.1.2121\n"
"1..32.33112\n"
"2213.1321..\n"
"31..313...1\n"
"1112.23..31\n"
"23331323.31\n"
"31321331.3.\n"
"1323..13131\n"
"33122323331\n"
"2..31333312\n"
"23231333131\n"
"12123311.13\n"
"1.2132.3212\n"
".313233.331\n"
"32223.13221\n"
"22..2333322\n"
"22323213321\n") == 0);
free(board768820026);
board768820026 = NULL;
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 16, 6) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 0, 16) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_free_fields(board, 1) == 34 );
assert( gamma_golden_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_move(board, 2, 1, 11) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 3, 7, 3) == 1 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_move(board, 3, 17, 6) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 9, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 72 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 8, 8) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 2, 0, 17) == 1 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 4, 3) == 0 );
assert( gamma_move(board, 3, 8, 12) == 1 );
assert( gamma_golden_move(board, 3, 16, 5) == 0 );
assert( gamma_move(board, 1, 3, 17) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_free_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


gamma_delete(board);

    return 0;
}
