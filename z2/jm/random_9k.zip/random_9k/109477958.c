#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 109477958
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(2, 137, 9, 25);
assert( board != NULL );


assert( gamma_move(board, 1, 87, 1) == 0 );
assert( gamma_move(board, 2, 20, 1) == 0 );
assert( gamma_move(board, 2, 1, 17) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 4, 69, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 128, 0) == 0 );
assert( gamma_move(board, 6, 0, 83) == 1 );
assert( gamma_move(board, 6, 0, 113) == 1 );
assert( gamma_move(board, 7, 81, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 0, 54) == 1 );
assert( gamma_golden_move(board, 8, 113, 0) == 0 );
assert( gamma_move(board, 1, 123, 0) == 0 );
assert( gamma_golden_move(board, 1, 17, 1) == 0 );
assert( gamma_move(board, 2, 99, 0) == 0 );
assert( gamma_move(board, 3, 0, 12) == 1 );
assert( gamma_move(board, 4, 25, 0) == 0 );
assert( gamma_move(board, 4, 1, 42) == 1 );
assert( gamma_move(board, 5, 1, 129) == 1 );
assert( gamma_golden_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 53, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_move(board, 7, 1, 48) == 1 );
assert( gamma_busy_fields(board, 7) == 1 );
assert( gamma_move(board, 8, 0, 90) == 1 );
assert( gamma_move(board, 8, 0, 95) == 1 );
assert( gamma_move(board, 9, 64, 0) == 0 );
assert( gamma_move(board, 9, 0, 88) == 1 );
assert( gamma_move(board, 1, 0, 113) == 0 );
assert( gamma_move(board, 1, 1, 136) == 1 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 3, 0, 51) == 1 );


char* board195530049 = gamma_board(board);
assert( board195530049 != NULL );
assert( strcmp(board195530049, 
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".5\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"..\n"
"9.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n") == 0);
free(board195530049);
board195530049 = NULL;
assert( gamma_move(board, 4, 0, 32) == 1 );
assert( gamma_move(board, 4, 0, 123) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 90) == 0 );
assert( gamma_move(board, 6, 131, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 58) == 1 );
assert( gamma_move(board, 7, 0, 28) == 1 );
assert( gamma_move(board, 8, 91, 0) == 0 );
assert( gamma_move(board, 8, 0, 86) == 1 );
assert( gamma_busy_fields(board, 8) == 4 );
assert( gamma_move(board, 1, 80, 1) == 0 );
assert( gamma_move(board, 2, 47, 0) == 0 );
assert( gamma_move(board, 2, 0, 94) == 1 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 76) == 1 );
assert( gamma_move(board, 4, 0, 129) == 1 );
assert( gamma_free_fields(board, 4) == 253 );
assert( gamma_move(board, 5, 99, 1) == 0 );
assert( gamma_move(board, 6, 0, 94) == 0 );
assert( gamma_move(board, 7, 1, 12) == 1 );
assert( gamma_free_fields(board, 7) == 252 );
assert( gamma_move(board, 8, 1, 8) == 1 );
assert( gamma_move(board, 9, 1, 89) == 1 );
assert( gamma_move(board, 2, 118, 1) == 0 );
assert( gamma_move(board, 3, 114, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 3 );
assert( gamma_move(board, 4, 1, 109) == 1 );
assert( gamma_move(board, 4, 0, 18) == 1 );


char* board521904863 = gamma_board(board);
assert( board521904863 != NULL );
assert( strcmp(board521904863, 
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"45\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"2.\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".9\n"
"9.\n"
"..\n"
"8.\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"7.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
".2\n"
"..\n"
"..\n"
"..\n"
"..\n"
"37\n"
"..\n"
"..\n"
"..\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n") == 0);
free(board521904863);
board521904863 = NULL;
assert( gamma_move(board, 5, 110, 1) == 0 );
assert( gamma_move(board, 5, 0, 95) == 0 );
assert( gamma_free_fields(board, 5) == 248 );
assert( gamma_move(board, 6, 1, 74) == 1 );
assert( gamma_move(board, 6, 1, 33) == 1 );
assert( gamma_move(board, 7, 56, 1) == 0 );
assert( gamma_move(board, 7, 1, 47) == 1 );
assert( gamma_move(board, 8, 95, 1) == 0 );
assert( gamma_move(board, 9, 132, 0) == 0 );
assert( gamma_move(board, 9, 0, 9) == 1 );
assert( gamma_move(board, 1, 1, 115) == 1 );
assert( gamma_move(board, 1, 0, 85) == 1 );


char* board919568097 = gamma_board(board);
assert( board919568097 != NULL );
assert( strcmp(board919568097, 
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"45\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"2.\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".9\n"
"9.\n"
"..\n"
"8.\n"
"1.\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
".7\n"
".7\n"
"..\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"7.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
".2\n"
"..\n"
"..\n"
"..\n"
"..\n"
"37\n"
"..\n"
"..\n"
"9.\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n") == 0);
free(board919568097);
board919568097 = NULL;
assert( gamma_move(board, 3, 50, 0) == 0 );
assert( gamma_move(board, 3, 0, 29) == 1 );
assert( gamma_move(board, 4, 110, 1) == 0 );
assert( gamma_move(board, 5, 80, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 1 );
assert( gamma_move(board, 6, 93, 1) == 0 );
assert( gamma_move(board, 6, 1, 49) == 1 );
assert( gamma_move(board, 7, 120, 0) == 0 );
assert( gamma_move(board, 7, 0, 98) == 1 );
assert( gamma_move(board, 8, 0, 7) == 1 );
assert( gamma_move(board, 9, 126, 0) == 0 );
assert( gamma_move(board, 9, 1, 83) == 1 );
assert( gamma_free_fields(board, 9) == 237 );
assert( gamma_move(board, 1, 45, 0) == 0 );
assert( gamma_move(board, 2, 0, 43) == 1 );
assert( gamma_move(board, 2, 1, 86) == 1 );
assert( gamma_golden_move(board, 3, 49, 1) == 0 );
assert( gamma_move(board, 4, 126, 0) == 0 );
assert( gamma_move(board, 5, 41, 0) == 0 );
assert( gamma_move(board, 5, 0, 53) == 1 );
assert( gamma_golden_move(board, 5, 95, 0) == 0 );
assert( gamma_move(board, 6, 61, 0) == 0 );
assert( gamma_move(board, 7, 74, 0) == 0 );
assert( gamma_move(board, 8, 21, 1) == 0 );
assert( gamma_move(board, 8, 0, 102) == 1 );
assert( gamma_move(board, 9, 0, 27) == 1 );
assert( gamma_free_fields(board, 9) == 232 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 31, 1) == 0 );
assert( gamma_move(board, 2, 1, 104) == 1 );
assert( gamma_move(board, 3, 29, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_move(board, 4, 68, 0) == 0 );
assert( gamma_move(board, 4, 0, 95) == 0 );
assert( gamma_move(board, 5, 118, 0) == 0 );
assert( gamma_move(board, 5, 1, 126) == 1 );
assert( gamma_move(board, 6, 1, 80) == 1 );
assert( gamma_move(board, 6, 1, 26) == 1 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 8, 23, 1) == 0 );
assert( gamma_move(board, 8, 1, 104) == 0 );
assert( gamma_move(board, 9, 1, 71) == 1 );
assert( gamma_move(board, 9, 0, 9) == 0 );
assert( gamma_move(board, 1, 1, 102) == 1 );
assert( gamma_move(board, 2, 23, 1) == 0 );
assert( gamma_move(board, 2, 0, 134) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 5, 1, 13) == 1 );
assert( gamma_move(board, 6, 110, 1) == 0 );
assert( gamma_move(board, 6, 0, 63) == 1 );
assert( gamma_move(board, 7, 28, 1) == 0 );
assert( gamma_move(board, 8, 117, 1) == 0 );
assert( gamma_move(board, 9, 0, 63) == 0 );
assert( gamma_busy_fields(board, 9) == 6 );
assert( gamma_move(board, 1, 1, 113) == 1 );
assert( gamma_move(board, 1, 0, 69) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 88) == 1 );
assert( gamma_move(board, 2, 0, 126) == 1 );
assert( gamma_move(board, 3, 125, 1) == 0 );
assert( gamma_move(board, 3, 1, 74) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 31) == 1 );
assert( gamma_move(board, 6, 89, 0) == 0 );
assert( gamma_move(board, 7, 0, 101) == 1 );
assert( gamma_move(board, 7, 1, 38) == 1 );
assert( gamma_busy_fields(board, 7) == 8 );
assert( gamma_move(board, 8, 112, 0) == 0 );
assert( gamma_move(board, 9, 0, 66) == 1 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 1, 1, 55) == 1 );
assert( gamma_free_fields(board, 1) == 213 );
assert( gamma_move(board, 2, 1, 15) == 1 );
assert( gamma_move(board, 2, 0, 105) == 1 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_busy_fields(board, 4) == 6 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 57) == 1 );
assert( gamma_move(board, 5, 1, 91) == 1 );
assert( gamma_move(board, 6, 1, 17) == 0 );
assert( gamma_move(board, 7, 23, 1) == 0 );
assert( gamma_move(board, 7, 0, 127) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 62, 1) == 0 );
assert( gamma_move(board, 8, 1, 45) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 67, 1) == 0 );
assert( gamma_move(board, 1, 0, 131) == 1 );
assert( gamma_move(board, 2, 114, 0) == 0 );
assert( gamma_move(board, 2, 0, 27) == 0 );
assert( gamma_move(board, 3, 118, 1) == 0 );
assert( gamma_move(board, 3, 1, 92) == 1 );
assert( gamma_move(board, 4, 1, 43) == 1 );
assert( gamma_free_fields(board, 4) == 203 );
assert( gamma_move(board, 5, 1, 102) == 0 );
assert( gamma_move(board, 6, 16, 0) == 0 );
assert( gamma_move(board, 6, 0, 89) == 1 );
assert( gamma_move(board, 7, 121, 0) == 0 );
assert( gamma_move(board, 8, 0, 99) == 1 );
assert( gamma_move(board, 8, 1, 18) == 1 );
assert( gamma_move(board, 9, 0, 63) == 0 );
assert( gamma_move(board, 9, 0, 68) == 1 );


char* board637556622 = gamma_board(board);
assert( board637556622 != NULL );
assert( strcmp(board637556622, 
".1\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
".2\n"
"..\n"
"81\n"
"7.\n"
"..\n"
"8.\n"
"7.\n"
"..\n"
"..\n"
"8.\n"
"2.\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
"..\n"
"82\n"
"1.\n"
"..\n"
"69\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
".6\n"
"..\n"
"..\n"
".9\n"
"..\n"
"1.\n"
"9.\n"
"..\n"
"9.\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
".7\n"
".5\n"
"..\n"
".1\n"
"8.\n"
"5.\n"
"..\n"
"3.\n"
"..\n"
".6\n"
".7\n"
".7\n"
"..\n"
".8\n"
"..\n"
"24\n"
".4\n"
"..\n"
"..\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"4.\n"
".5\n"
"..\n"
"3.\n"
"7.\n"
"9.\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"9.\n"
".8\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n") == 0);
free(board637556622);
board637556622 = NULL;
assert( gamma_move(board, 2, 39, 0) == 0 );
assert( gamma_move(board, 3, 1, 109) == 0 );


char* board251810845 = gamma_board(board);
assert( board251810845 != NULL );
assert( strcmp(board251810845, 
".1\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
".2\n"
"..\n"
"81\n"
"7.\n"
"..\n"
"8.\n"
"7.\n"
"..\n"
"..\n"
"8.\n"
"2.\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
"..\n"
"82\n"
"1.\n"
"..\n"
"69\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
".6\n"
"..\n"
"..\n"
".9\n"
"..\n"
"1.\n"
"9.\n"
"..\n"
"9.\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
".7\n"
".5\n"
"..\n"
".1\n"
"8.\n"
"5.\n"
"..\n"
"3.\n"
"..\n"
".6\n"
".7\n"
".7\n"
"..\n"
".8\n"
"..\n"
"24\n"
".4\n"
"..\n"
"..\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"4.\n"
".5\n"
"..\n"
"3.\n"
"7.\n"
"9.\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"9.\n"
".8\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n") == 0);
free(board251810845);
board251810845 = NULL;
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 7 );
assert( gamma_move(board, 5, 62, 1) == 0 );
assert( gamma_move(board, 5, 1, 99) == 1 );
assert( gamma_move(board, 6, 62, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 9 );
assert( gamma_move(board, 7, 0, 55) == 1 );
assert( gamma_free_fields(board, 7) == 197 );
assert( gamma_move(board, 8, 87, 0) == 0 );
assert( gamma_free_fields(board, 8) == 197 );
assert( gamma_move(board, 9, 45, 0) == 0 );
assert( gamma_move(board, 1, 62, 1) == 0 );
assert( gamma_move(board, 1, 0, 127) == 0 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_free_fields(board, 1) == 197 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 25, 1) == 0 );
assert( gamma_move(board, 3, 0, 125) == 1 );
assert( gamma_move(board, 4, 1, 50) == 1 );
assert( gamma_move(board, 4, 0, 32) == 0 );
assert( gamma_move(board, 5, 0, 74) == 1 );
assert( gamma_move(board, 6, 62, 0) == 0 );
assert( gamma_move(board, 6, 1, 42) == 0 );
assert( gamma_move(board, 7, 77, 1) == 0 );
assert( gamma_free_fields(board, 7) == 194 );
assert( gamma_move(board, 8, 73, 1) == 0 );
assert( gamma_move(board, 8, 0, 37) == 1 );
assert( gamma_move(board, 1, 134, 1) == 0 );
assert( gamma_move(board, 2, 0, 21) == 1 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 0, 104) == 1 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 65, 0) == 0 );
assert( gamma_move(board, 4, 0, 129) == 0 );
assert( gamma_move(board, 5, 73, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 59) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 135) == 1 );
assert( gamma_move(board, 9, 27, 1) == 0 );
assert( gamma_move(board, 9, 0, 52) == 1 );
assert( gamma_golden_move(board, 9, 92, 1) == 0 );
assert( gamma_move(board, 1, 132, 1) == 0 );
assert( gamma_move(board, 2, 64, 0) == 0 );
assert( gamma_move(board, 3, 95, 1) == 0 );
assert( gamma_move(board, 4, 0, 98) == 0 );
assert( gamma_move(board, 5, 132, 1) == 0 );
assert( gamma_move(board, 5, 0, 35) == 1 );
assert( gamma_move(board, 6, 120, 1) == 0 );
assert( gamma_move(board, 6, 1, 74) == 0 );
assert( gamma_busy_fields(board, 6) == 10 );
assert( gamma_golden_move(board, 6, 47, 1) == 0 );
assert( gamma_move(board, 7, 1, 100) == 1 );
assert( gamma_busy_fields(board, 7) == 12 );
assert( gamma_move(board, 8, 1, 87) == 1 );
assert( gamma_move(board, 8, 1, 114) == 1 );
assert( gamma_move(board, 9, 73, 0) == 0 );
assert( gamma_move(board, 9, 0, 127) == 0 );
assert( gamma_move(board, 1, 1, 27) == 1 );
assert( gamma_free_fields(board, 1) == 183 );
assert( gamma_golden_move(board, 1, 91, 1) == 0 );
assert( gamma_move(board, 2, 34, 1) == 0 );
assert( gamma_move(board, 2, 1, 133) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 97, 1) == 0 );
assert( gamma_move(board, 3, 1, 64) == 1 );
assert( gamma_move(board, 4, 0, 49) == 1 );
assert( gamma_golden_move(board, 4, 74, 0) == 0 );
assert( gamma_move(board, 5, 1, 26) == 0 );
assert( gamma_busy_fields(board, 5) == 10 );
assert( gamma_move(board, 6, 80, 0) == 0 );
assert( gamma_move(board, 7, 117, 0) == 0 );
assert( gamma_move(board, 7, 0, 36) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 0, 44) == 1 );


char* board353027801 = gamma_board(board);
assert( board353027801 != NULL );
assert( strcmp(board353027801, 
".1\n"
"7.\n"
"2.\n"
".2\n"
"..\n"
"1.\n"
"..\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
".8\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"..\n"
"81\n"
"7.\n"
".7\n"
"85\n"
"7.\n"
"..\n"
"..\n"
"8.\n"
"2.\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"..\n"
"69\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"56\n"
"..\n"
"..\n"
".9\n"
"..\n"
"1.\n"
"9.\n"
"..\n"
"9.\n"
"..\n"
".3\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
".7\n"
".5\n"
"..\n"
"71\n"
"8.\n"
"5.\n"
"9.\n"
"3.\n"
".4\n"
"46\n"
".7\n"
".7\n"
"..\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"..\n"
"..\n"
"..\n"
".7\n"
"8.\n"
"7.\n"
"5.\n"
"..\n"
".6\n"
"4.\n"
".5\n"
"..\n"
"3.\n"
"7.\n"
"91\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"9.\n"
".8\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n") == 0);
free(board353027801);
board353027801 = NULL;
assert( gamma_move(board, 1, 60, 0) == 0 );
assert( gamma_move(board, 1, 1, 132) == 1 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_move(board, 3, 1, 65) == 1 );
assert( gamma_move(board, 4, 56, 0) == 0 );
assert( gamma_move(board, 4, 0, 82) == 1 );


char* board897052249 = gamma_board(board);
assert( board897052249 != NULL );
assert( strcmp(board897052249, 
".1\n"
"7.\n"
"2.\n"
".2\n"
".1\n"
"1.\n"
"..\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
".8\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"..\n"
"81\n"
"7.\n"
".7\n"
"85\n"
"7.\n"
"..\n"
"..\n"
"8.\n"
"2.\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"..\n"
"69\n"
"4.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"56\n"
"..\n"
"..\n"
".9\n"
"..\n"
"1.\n"
"9.\n"
"..\n"
"9.\n"
".3\n"
".3\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
".7\n"
".5\n"
"..\n"
"71\n"
"8.\n"
"5.\n"
"9.\n"
"3.\n"
".4\n"
"46\n"
".7\n"
".7\n"
"..\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"..\n"
"..\n"
"..\n"
".7\n"
"8.\n"
"7.\n"
"5.\n"
"..\n"
".6\n"
"4.\n"
".5\n"
"..\n"
"3.\n"
"7.\n"
"91\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"9.\n"
".8\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
".1\n") == 0);
free(board897052249);
board897052249 = NULL;
assert( gamma_move(board, 5, 103, 0) == 0 );
assert( gamma_move(board, 5, 0, 57) == 1 );


char* board449622184 = gamma_board(board);
assert( board449622184 != NULL );
assert( strcmp(board449622184, 
".1\n"
"7.\n"
"2.\n"
".2\n"
".1\n"
"1.\n"
"..\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
".8\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"..\n"
"81\n"
"7.\n"
".7\n"
"85\n"
"7.\n"
"..\n"
"..\n"
"8.\n"
"2.\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"..\n"
"69\n"
"4.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"56\n"
"..\n"
"..\n"
".9\n"
"..\n"
"1.\n"
"9.\n"
"..\n"
"9.\n"
".3\n"
".3\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
".7\n"
"55\n"
"..\n"
"71\n"
"8.\n"
"5.\n"
"9.\n"
"3.\n"
".4\n"
"46\n"
".7\n"
".7\n"
"..\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"..\n"
"..\n"
"..\n"
".7\n"
"8.\n"
"7.\n"
"5.\n"
"..\n"
".6\n"
"4.\n"
".5\n"
"..\n"
"3.\n"
"7.\n"
"91\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"9.\n"
".8\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
".1\n") == 0);
free(board449622184);
board449622184 = NULL;
assert( gamma_move(board, 6, 1, 37) == 1 );
assert( gamma_move(board, 6, 1, 56) == 1 );
assert( gamma_move(board, 7, 0, 133) == 1 );


char* board331239733 = gamma_board(board);
assert( board331239733 != NULL );
assert( strcmp(board331239733, 
".1\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"1.\n"
"..\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
".8\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"..\n"
"81\n"
"7.\n"
".7\n"
"85\n"
"7.\n"
"..\n"
"..\n"
"8.\n"
"2.\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"..\n"
"69\n"
"4.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"56\n"
"..\n"
"..\n"
".9\n"
"..\n"
"1.\n"
"9.\n"
"..\n"
"9.\n"
".3\n"
".3\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
".7\n"
"55\n"
".6\n"
"71\n"
"8.\n"
"5.\n"
"9.\n"
"3.\n"
".4\n"
"46\n"
".7\n"
".7\n"
"..\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"..\n"
"..\n"
"..\n"
".7\n"
"86\n"
"7.\n"
"5.\n"
"..\n"
".6\n"
"4.\n"
".5\n"
"..\n"
"3.\n"
"7.\n"
"91\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"9.\n"
".8\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
".1\n") == 0);
free(board331239733);
board331239733 = NULL;
assert( gamma_move(board, 8, 1, 48) == 0 );
assert( gamma_move(board, 8, 0, 117) == 1 );
assert( gamma_move(board, 9, 1, 39) == 1 );
assert( gamma_move(board, 9, 1, 130) == 1 );
assert( gamma_move(board, 1, 1, 38) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 102, 0) == 0 );
assert( gamma_move(board, 2, 71, 0) == 0 );
assert( gamma_move(board, 4, 25, 0) == 0 );
assert( gamma_move(board, 5, 35, 1) == 0 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 70, 1) == 0 );
assert( gamma_move(board, 7, 1, 58) == 0 );
assert( gamma_move(board, 8, 23, 0) == 0 );
assert( gamma_move(board, 8, 1, 123) == 1 );
assert( gamma_free_fields(board, 8) == 165 );
assert( gamma_golden_move(board, 8, 123, 0) == 0 );
assert( gamma_move(board, 9, 1, 132) == 0 );
assert( gamma_busy_fields(board, 9) == 12 );
assert( gamma_move(board, 1, 0, 63) == 0 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 40, 1) == 0 );
assert( gamma_free_fields(board, 2) == 165 );
assert( gamma_move(board, 3, 0, 88) == 0 );
assert( gamma_move(board, 4, 127, 1) == 0 );
assert( gamma_move(board, 4, 1, 46) == 1 );
assert( gamma_move(board, 6, 131, 1) == 0 );
assert( gamma_move(board, 7, 117, 1) == 0 );
assert( gamma_move(board, 7, 1, 57) == 0 );
assert( gamma_golden_move(board, 7, 34, 0) == 0 );
assert( gamma_move(board, 8, 112, 0) == 0 );
assert( gamma_move(board, 8, 0, 57) == 0 );
assert( gamma_move(board, 9, 38, 0) == 0 );
assert( gamma_move(board, 1, 24, 0) == 0 );
assert( gamma_move(board, 1, 0, 30) == 1 );
assert( gamma_golden_move(board, 1, 52, 0) == 0 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 80, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 0, 30) == 0 );
assert( gamma_move(board, 5, 0, 27) == 0 );
assert( gamma_golden_move(board, 5, 8, 1) == 0 );
assert( gamma_move(board, 6, 90, 1) == 0 );
assert( gamma_move(board, 7, 1, 83) == 0 );
assert( gamma_move(board, 7, 0, 39) == 1 );
assert( gamma_free_fields(board, 7) == 162 );
assert( gamma_move(board, 8, 0, 37) == 0 );
assert( gamma_move(board, 9, 41, 0) == 0 );
assert( gamma_move(board, 1, 121, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_free_fields(board, 1) == 162 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 2, 0, 99) == 0 );
assert( gamma_move(board, 3, 132, 0) == 0 );
assert( gamma_move(board, 3, 0, 21) == 0 );
assert( gamma_move(board, 4, 125, 1) == 0 );
assert( gamma_move(board, 5, 1, 101) == 1 );
assert( gamma_move(board, 5, 1, 71) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_move(board, 7, 0, 54) == 0 );
assert( gamma_move(board, 8, 11, 1) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 47, 0) == 0 );
assert( gamma_move(board, 2, 78, 1) == 0 );
assert( gamma_move(board, 2, 1, 43) == 0 );
assert( gamma_move(board, 3, 116, 1) == 0 );
assert( gamma_move(board, 3, 0, 67) == 1 );
assert( gamma_move(board, 4, 1, 41) == 1 );
assert( gamma_move(board, 4, 0, 50) == 1 );
assert( gamma_move(board, 6, 0, 97) == 1 );
assert( gamma_move(board, 7, 131, 1) == 0 );
assert( gamma_move(board, 7, 0, 135) == 0 );
assert( gamma_free_fields(board, 7) == 156 );
assert( gamma_move(board, 8, 135, 1) == 0 );
assert( gamma_move(board, 9, 40, 0) == 0 );
assert( gamma_move(board, 1, 1, 48) == 0 );
assert( gamma_move(board, 1, 0, 41) == 1 );
assert( gamma_move(board, 2, 1, 95) == 1 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 120, 0) == 0 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 4, 0, 114) == 1 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 6, 1, 120) == 1 );
assert( gamma_move(board, 7, 1, 1) == 0 );
assert( gamma_move(board, 8, 79, 1) == 0 );
assert( gamma_move(board, 9, 136, 0) == 0 );
assert( gamma_move(board, 1, 64, 0) == 0 );
assert( gamma_move(board, 1, 1, 27) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 23, 1) == 0 );
assert( gamma_move(board, 2, 0, 68) == 0 );
assert( gamma_move(board, 3, 45, 0) == 0 );
assert( gamma_move(board, 3, 1, 59) == 1 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 128, 0) == 0 );
assert( gamma_move(board, 4, 0, 41) == 0 );
assert( gamma_move(board, 5, 80, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 106, 0) == 0 );
assert( gamma_free_fields(board, 6) == 150 );
assert( gamma_move(board, 7, 1, 65) == 0 );
assert( gamma_free_fields(board, 7) == 150 );
assert( gamma_move(board, 8, 48, 0) == 0 );
assert( gamma_move(board, 8, 1, 37) == 0 );
assert( gamma_busy_fields(board, 8) == 15 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 81, 0) == 0 );
assert( gamma_move(board, 1, 103, 1) == 0 );
assert( gamma_move(board, 2, 93, 1) == 0 );
assert( gamma_free_fields(board, 2) == 150 );
assert( gamma_move(board, 3, 32, 1) == 0 );
assert( gamma_golden_move(board, 3, 56, 1) == 0 );
assert( gamma_move(board, 4, 1, 65) == 0 );
assert( gamma_busy_fields(board, 4) == 14 );
assert( gamma_move(board, 5, 107, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 56) == 1 );
assert( gamma_move(board, 6, 0, 64) == 1 );
assert( gamma_move(board, 7, 1, 98) == 1 );
assert( gamma_move(board, 8, 87, 0) == 0 );
assert( gamma_move(board, 9, 1, 53) == 1 );
assert( gamma_move(board, 9, 1, 66) == 1 );
assert( gamma_move(board, 1, 78, 1) == 0 );
assert( gamma_move(board, 1, 0, 95) == 0 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 2, 1, 24) == 1 );
assert( gamma_golden_move(board, 2, 136, 1) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_free_fields(board, 4) == 143 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 70, 0) == 0 );
assert( gamma_move(board, 6, 1, 100) == 0 );
assert( gamma_move(board, 8, 32, 1) == 0 );
assert( gamma_free_fields(board, 8) == 143 );
assert( gamma_move(board, 9, 22, 0) == 0 );
assert( gamma_move(board, 9, 0, 26) == 1 );
assert( gamma_move(board, 1, 58, 0) == 0 );
assert( gamma_move(board, 1, 0, 123) == 0 );
assert( gamma_move(board, 2, 1, 77) == 1 );
assert( gamma_move(board, 3, 1, 116) == 1 );
assert( gamma_move(board, 3, 0, 133) == 0 );
assert( gamma_move(board, 4, 0, 55) == 0 );
assert( gamma_move(board, 5, 70, 0) == 0 );
assert( gamma_move(board, 5, 1, 22) == 1 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_move(board, 6, 107, 0) == 0 );
assert( gamma_move(board, 6, 1, 69) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 94) == 1 );
assert( gamma_move(board, 7, 0, 73) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 117, 1) == 0 );
assert( gamma_move(board, 9, 52, 1) == 0 );


char* board419486096 = gamma_board(board);
assert( board419486096 != NULL );
assert( strcmp(board419486096, 
".1\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"1.\n"
".9\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"48\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"8.\n"
".3\n"
".1\n"
"48\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"..\n"
"81\n"
"75\n"
".7\n"
"85\n"
"77\n"
"6.\n"
"..\n"
"82\n"
"27\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"..\n"
"69\n"
"4.\n"
"..\n"
".6\n"
"..\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"56\n"
"7.\n"
"..\n"
".9\n"
"..\n"
"16\n"
"9.\n"
"3.\n"
"99\n"
".3\n"
"63\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"3.\n"
"44\n"
"46\n"
".7\n"
".7\n"
".4\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"14\n"
"..\n"
"79\n"
".7\n"
"86\n"
"7.\n"
"5.\n"
"..\n"
".6\n"
"4.\n"
".5\n"
"1.\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"..\n"
".2\n"
"..\n"
".5\n"
"2.\n"
"..\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"2.\n"
"..\n"
"..\n"
".2\n"
"..\n"
".3\n"
"51\n") == 0);
free(board419486096);
board419486096 = NULL;
assert( gamma_move(board, 1, 0, 38) == 1 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 1, 34) == 1 );
assert( gamma_move(board, 3, 119, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_free_fields(board, 3) == 134 );
assert( gamma_move(board, 4, 78, 1) == 0 );
assert( gamma_move(board, 5, 71, 0) == 0 );
assert( gamma_move(board, 6, 0, 120) == 1 );
assert( gamma_move(board, 7, 0, 129) == 0 );
assert( gamma_move(board, 8, 14, 0) == 0 );
assert( gamma_move(board, 8, 1, 136) == 0 );
assert( gamma_move(board, 2, 51, 1) == 0 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 1, 21) == 1 );
assert( gamma_move(board, 4, 17, 0) == 0 );
assert( gamma_move(board, 6, 10, 1) == 0 );
assert( gamma_move(board, 6, 1, 71) == 0 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 8, 29, 1) == 0 );
assert( gamma_free_fields(board, 8) == 132 );
assert( gamma_move(board, 9, 0, 125) == 0 );
assert( gamma_move(board, 1, 28, 1) == 0 );
assert( gamma_move(board, 2, 30, 1) == 0 );
assert( gamma_move(board, 3, 0, 123) == 0 );
assert( gamma_golden_move(board, 3, 55, 0) == 0 );
assert( gamma_move(board, 4, 1, 30) == 1 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 0, 34) == 1 );
assert( gamma_busy_fields(board, 6) == 19 );
assert( gamma_free_fields(board, 6) == 130 );
assert( gamma_move(board, 7, 0, 67) == 0 );
assert( gamma_move(board, 7, 0, 88) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 129) == 0 );
assert( gamma_move(board, 8, 0, 79) == 1 );
assert( gamma_move(board, 9, 128, 1) == 0 );
assert( gamma_move(board, 9, 1, 51) == 1 );
assert( gamma_move(board, 1, 0, 116) == 1 );
assert( gamma_move(board, 1, 1, 58) == 0 );
assert( gamma_free_fields(board, 2) == 127 );
assert( gamma_move(board, 3, 81, 0) == 0 );
assert( gamma_move(board, 3, 1, 55) == 0 );
assert( gamma_move(board, 4, 16, 1) == 0 );
assert( gamma_move(board, 5, 62, 0) == 0 );
assert( gamma_move(board, 6, 0, 122) == 1 );
assert( gamma_move(board, 6, 0, 103) == 1 );
assert( gamma_busy_fields(board, 6) == 21 );
assert( gamma_move(board, 7, 92, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );


char* board618420812 = gamma_board(board);
assert( board618420812 != NULL );
assert( strcmp(board618420812, 
".1\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"1.\n"
".9\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"48\n"
"6.\n"
"..\n"
"66\n"
"..\n"
"..\n"
"8.\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"6.\n"
"81\n"
"75\n"
".7\n"
"85\n"
"77\n"
"6.\n"
"..\n"
"82\n"
"27\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"..\n"
"69\n"
"4.\n"
"..\n"
".6\n"
"8.\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"56\n"
"7.\n"
"..\n"
".9\n"
"..\n"
"16\n"
"9.\n"
"3.\n"
"99\n"
".3\n"
"63\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
".7\n"
".7\n"
".4\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"14\n"
"..\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"4.\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"..\n"
".2\n"
"..\n"
".5\n"
"23\n"
"..\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"2.\n"
"..\n"
"..\n"
".2\n"
"..\n"
".3\n"
"51\n") == 0);
free(board618420812);
board618420812 = NULL;
assert( gamma_move(board, 8, 115, 0) == 0 );
assert( gamma_move(board, 8, 1, 20) == 1 );
assert( gamma_move(board, 9, 108, 0) == 0 );
assert( gamma_move(board, 1, 19, 1) == 0 );
assert( gamma_move(board, 1, 0, 47) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 127, 1) == 0 );
assert( gamma_move(board, 2, 1, 59) == 0 );
assert( gamma_move(board, 3, 78, 0) == 0 );
assert( gamma_move(board, 3, 0, 41) == 0 );
assert( gamma_move(board, 4, 0, 40) == 1 );
assert( gamma_move(board, 4, 1, 33) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 45, 0) == 0 );
assert( gamma_move(board, 6, 111, 1) == 0 );
assert( gamma_move(board, 6, 1, 91) == 0 );
assert( gamma_golden_move(board, 7, 10, 0) == 0 );
assert( gamma_move(board, 8, 111, 0) == 0 );
assert( gamma_move(board, 8, 0, 44) == 0 );
assert( gamma_move(board, 9, 2, 1) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 0, 72) == 1 );
assert( gamma_move(board, 2, 115, 0) == 0 );
assert( gamma_move(board, 2, 0, 84) == 1 );
assert( gamma_move(board, 3, 0, 120) == 0 );
assert( gamma_move(board, 5, 68, 1) == 0 );
assert( gamma_move(board, 5, 0, 126) == 0 );
assert( gamma_move(board, 6, 48, 0) == 0 );
assert( gamma_move(board, 7, 1, 102) == 0 );
assert( gamma_move(board, 8, 0, 29) == 0 );
assert( gamma_move(board, 9, 91, 0) == 0 );
assert( gamma_move(board, 1, 107, 1) == 0 );
assert( gamma_move(board, 1, 0, 21) == 0 );
assert( gamma_free_fields(board, 1) == 120 );
assert( gamma_golden_move(board, 1, 125, 0) == 0 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 132) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 1, 100) == 0 );
assert( gamma_move(board, 4, 0, 82) == 0 );
assert( gamma_free_fields(board, 4) == 120 );
assert( gamma_move(board, 5, 40, 1) == 0 );
assert( gamma_move(board, 5, 0, 97) == 0 );
assert( gamma_free_fields(board, 5) == 120 );


char* board180551824 = gamma_board(board);
assert( board180551824 != NULL );
assert( strcmp(board180551824, 
".1\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"1.\n"
".9\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"48\n"
"6.\n"
"..\n"
"66\n"
"..\n"
"..\n"
"8.\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"6.\n"
"81\n"
"75\n"
".7\n"
"85\n"
"77\n"
"6.\n"
"..\n"
"82\n"
"27\n"
"..\n"
".3\n"
".5\n"
"8.\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"4.\n"
"..\n"
".6\n"
"8.\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"56\n"
"7.\n"
"1.\n"
".9\n"
"..\n"
"16\n"
"9.\n"
"3.\n"
"99\n"
".3\n"
"63\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
".7\n"
"17\n"
".4\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"14\n"
"4.\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"4.\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"..\n"
".2\n"
"..\n"
".5\n"
"23\n"
".8\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
".5\n"
"37\n"
"..\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"2.\n"
"..\n"
"..\n"
".2\n"
"..\n"
".3\n"
"51\n") == 0);
free(board180551824);
board180551824 = NULL;
assert( gamma_move(board, 6, 1, 32) == 1 );
assert( gamma_move(board, 7, 65, 0) == 0 );
assert( gamma_move(board, 7, 1, 68) == 1 );
assert( gamma_move(board, 8, 78, 0) == 0 );
assert( gamma_move(board, 8, 0, 80) == 1 );
assert( gamma_busy_fields(board, 8) == 18 );
assert( gamma_move(board, 9, 0, 134) == 0 );
assert( gamma_move(board, 1, 0, 35) == 0 );
assert( gamma_move(board, 2, 1, 90) == 1 );
assert( gamma_move(board, 3, 60, 1) == 0 );
assert( gamma_move(board, 3, 1, 24) == 0 );
assert( gamma_move(board, 4, 71, 0) == 0 );
assert( gamma_move(board, 4, 0, 13) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 118, 0) == 0 );
assert( gamma_move(board, 6, 1, 66) == 0 );
assert( gamma_move(board, 7, 67, 1) == 0 );
assert( gamma_move(board, 7, 0, 51) == 0 );


char* board647392597 = gamma_board(board);
assert( board647392597 != NULL );
assert( strcmp(board647392597, 
".1\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"1.\n"
".9\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"48\n"
"6.\n"
"..\n"
"66\n"
"..\n"
"..\n"
"8.\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"6.\n"
"81\n"
"75\n"
".7\n"
"85\n"
"77\n"
"6.\n"
"..\n"
"82\n"
"27\n"
"..\n"
".3\n"
".5\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"4.\n"
"..\n"
"86\n"
"8.\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"56\n"
"7.\n"
"1.\n"
".9\n"
"..\n"
"16\n"
"97\n"
"3.\n"
"99\n"
".3\n"
"63\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
".7\n"
"17\n"
".4\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"14\n"
"4.\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"..\n"
".2\n"
"..\n"
".5\n"
"23\n"
".8\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
"45\n"
"37\n"
"..\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"2.\n"
"..\n"
"..\n"
".2\n"
"..\n"
".3\n"
"51\n") == 0);
free(board647392597);
board647392597 = NULL;
assert( gamma_move(board, 8, 72, 1) == 0 );
assert( gamma_move(board, 8, 1, 121) == 1 );
assert( gamma_move(board, 9, 0, 65) == 1 );
assert( gamma_golden_move(board, 1, 127, 0) == 0 );
assert( gamma_move(board, 2, 75, 0) == 0 );
assert( gamma_move(board, 2, 1, 50) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 1, 131) == 1 );
assert( gamma_move(board, 4, 81, 0) == 0 );
assert( gamma_move(board, 5, 136, 0) == 0 );
assert( gamma_move(board, 5, 0, 77) == 1 );
assert( gamma_move(board, 6, 85, 1) == 0 );
assert( gamma_move(board, 7, 1, 32) == 0 );
assert( gamma_move(board, 8, 73, 1) == 0 );
assert( gamma_move(board, 8, 0, 104) == 0 );
assert( gamma_move(board, 9, 0, 1) == 1 );
assert( gamma_move(board, 1, 75, 1) == 0 );
assert( gamma_move(board, 2, 121, 0) == 0 );
assert( gamma_move(board, 2, 1, 109) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 35, 1) == 0 );
assert( gamma_free_fields(board, 3) == 110 );


char* board429922016 = gamma_board(board);
assert( board429922016 != NULL );
assert( strcmp(board429922016, 
".1\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
"..\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"48\n"
"6.\n"
".8\n"
"66\n"
"..\n"
"..\n"
"8.\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"6.\n"
"81\n"
"75\n"
".7\n"
"85\n"
"77\n"
"6.\n"
"..\n"
"82\n"
"27\n"
"..\n"
".3\n"
".5\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"4.\n"
"..\n"
"86\n"
"8.\n"
"..\n"
"52\n"
"3.\n"
"..\n"
"56\n"
"7.\n"
"1.\n"
".9\n"
"..\n"
"16\n"
"97\n"
"3.\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
".7\n"
"17\n"
".4\n"
".8\n"
"9.\n"
"24\n"
".4\n"
"14\n"
"4.\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"..\n"
".2\n"
"..\n"
".5\n"
"23\n"
".8\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
"45\n"
"37\n"
"..\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"2.\n"
"..\n"
"..\n"
".2\n"
"..\n"
"93\n"
"51\n") == 0);
free(board429922016);
board429922016 = NULL;
assert( gamma_move(board, 4, 118, 1) == 0 );
assert( gamma_move(board, 5, 0, 95) == 0 );
assert( gamma_move(board, 5, 0, 45) == 1 );
assert( gamma_move(board, 6, 44, 1) == 0 );
assert( gamma_move(board, 6, 0, 91) == 1 );
assert( gamma_move(board, 7, 61, 0) == 0 );
assert( gamma_move(board, 8, 0, 39) == 0 );
assert( gamma_move(board, 9, 0, 129) == 0 );
assert( gamma_move(board, 1, 112, 1) == 0 );
assert( gamma_move(board, 2, 23, 1) == 0 );
assert( gamma_move(board, 2, 0, 127) == 0 );
assert( gamma_free_fields(board, 2) == 108 );
assert( gamma_move(board, 3, 103, 1) == 0 );
assert( gamma_move(board, 3, 1, 128) == 1 );
assert( gamma_free_fields(board, 3) == 107 );


char* board934030435 = gamma_board(board);
assert( board934030435 != NULL );
assert( strcmp(board934030435, 
".1\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"7.\n"
"25\n"
"3.\n"
"..\n"
"48\n"
"6.\n"
".8\n"
"66\n"
"..\n"
"..\n"
"8.\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"32\n"
"6.\n"
"81\n"
"75\n"
".7\n"
"85\n"
"77\n"
"6.\n"
"..\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"4.\n"
"..\n"
"86\n"
"8.\n"
"..\n"
"52\n"
"3.\n"
"..\n"
"56\n"
"7.\n"
"1.\n"
".9\n"
"..\n"
"16\n"
"97\n"
"3.\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
".7\n"
"17\n"
".4\n"
"58\n"
"9.\n"
"24\n"
".4\n"
"14\n"
"4.\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"..\n"
".2\n"
"..\n"
".5\n"
"23\n"
".8\n"
"..\n"
"48\n"
".2\n"
"..\n"
".2\n"
"..\n"
"45\n"
"37\n"
"..\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"2.\n"
"..\n"
"..\n"
".2\n"
"..\n"
"93\n"
"51\n") == 0);
free(board934030435);
board934030435 = NULL;
assert( gamma_move(board, 4, 0, 62) == 1 );
assert( gamma_move(board, 5, 24, 0) == 0 );
assert( gamma_move(board, 6, 1, 127) == 1 );
assert( gamma_golden_move(board, 6, 20, 1) == 0 );
assert( gamma_move(board, 7, 0, 24) == 1 );
assert( gamma_move(board, 8, 0, 70) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 1, 18) == 0 );
assert( gamma_move(board, 2, 118, 1) == 0 );
assert( gamma_move(board, 2, 0, 19) == 1 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 1, 66) == 0 );
assert( gamma_move(board, 5, 1, 19) == 1 );
assert( gamma_golden_move(board, 5, 31, 1) == 0 );
assert( gamma_move(board, 6, 52, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 24 );
assert( gamma_move(board, 7, 72, 1) == 0 );
assert( gamma_move(board, 8, 78, 1) == 0 );
assert( gamma_move(board, 9, 121, 0) == 0 );
assert( gamma_move(board, 9, 1, 15) == 0 );
assert( gamma_move(board, 1, 16, 1) == 0 );
assert( gamma_move(board, 1, 0, 111) == 1 );
assert( gamma_move(board, 2, 29, 1) == 0 );
assert( gamma_move(board, 3, 1, 51) == 0 );
assert( gamma_move(board, 4, 128, 0) == 0 );
assert( gamma_move(board, 5, 35, 1) == 0 );
assert( gamma_move(board, 5, 1, 117) == 1 );
assert( gamma_move(board, 6, 1, 97) == 1 );
assert( gamma_move(board, 7, 0, 74) == 0 );
assert( gamma_move(board, 7, 1, 37) == 0 );
assert( gamma_move(board, 8, 25, 0) == 0 );
assert( gamma_free_fields(board, 8) == 98 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 73, 1) == 0 );
assert( gamma_move(board, 2, 1, 65) == 0 );
assert( gamma_move(board, 3, 85, 1) == 0 );
assert( gamma_move(board, 3, 0, 100) == 1 );
assert( gamma_move(board, 4, 31, 0) == 0 );
assert( gamma_move(board, 4, 0, 65) == 0 );
assert( gamma_free_fields(board, 4) == 97 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 120) == 0 );
assert( gamma_move(board, 6, 1, 32) == 0 );
assert( gamma_move(board, 7, 93, 1) == 0 );
assert( gamma_move(board, 7, 1, 115) == 0 );
assert( gamma_move(board, 8, 76, 1) == 0 );
assert( gamma_move(board, 9, 1, 70) == 1 );
assert( gamma_move(board, 9, 0, 17) == 1 );
assert( gamma_free_fields(board, 9) == 95 );
assert( gamma_move(board, 1, 0, 98) == 0 );
assert( gamma_move(board, 1, 1, 21) == 0 );
assert( gamma_move(board, 2, 0, 136) == 1 );
assert( gamma_move(board, 3, 60, 0) == 0 );
assert( gamma_move(board, 4, 1, 73) == 1 );
assert( gamma_move(board, 5, 119, 0) == 0 );
assert( gamma_move(board, 7, 35, 1) == 0 );
assert( gamma_move(board, 7, 1, 132) == 0 );
assert( gamma_busy_fields(board, 7) == 20 );
assert( gamma_move(board, 8, 119, 1) == 0 );
assert( gamma_move(board, 9, 107, 1) == 0 );
assert( gamma_move(board, 9, 1, 117) == 0 );
assert( gamma_move(board, 1, 0, 15) == 1 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 36, 1) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 92, 0) == 0 );
assert( gamma_golden_move(board, 4, 21, 1) == 0 );
assert( gamma_move(board, 5, 75, 1) == 0 );
assert( gamma_move(board, 6, 0, 70) == 0 );
assert( gamma_move(board, 6, 0, 99) == 0 );
assert( gamma_move(board, 7, 110, 1) == 0 );
assert( gamma_move(board, 7, 0, 25) == 1 );
assert( gamma_move(board, 8, 54, 1) == 0 );
assert( gamma_move(board, 8, 0, 96) == 1 );
assert( gamma_move(board, 9, 79, 1) == 0 );
assert( gamma_move(board, 1, 79, 1) == 0 );
assert( gamma_move(board, 1, 1, 37) == 0 );
assert( gamma_move(board, 2, 1, 2) == 1 );
assert( gamma_move(board, 2, 0, 57) == 0 );
assert( gamma_move(board, 3, 67, 1) == 0 );
assert( gamma_move(board, 4, 0, 81) == 1 );
assert( gamma_move(board, 4, 1, 44) == 1 );
assert( gamma_move(board, 5, 0, 11) == 1 );
assert( gamma_move(board, 5, 0, 83) == 0 );
assert( gamma_move(board, 6, 76, 1) == 0 );
assert( gamma_move(board, 6, 1, 81) == 1 );
assert( gamma_move(board, 7, 87, 0) == 0 );
assert( gamma_move(board, 7, 0, 15) == 0 );
assert( gamma_move(board, 8, 1, 32) == 0 );
assert( gamma_move(board, 9, 1, 40) == 1 );
assert( gamma_move(board, 1, 1, 106) == 1 );
assert( gamma_move(board, 1, 0, 127) == 0 );
assert( gamma_move(board, 2, 79, 1) == 0 );
assert( gamma_move(board, 3, 0, 79) == 0 );
assert( gamma_move(board, 3, 1, 120) == 0 );
assert( gamma_golden_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 5, 107, 1) == 0 );
assert( gamma_move(board, 5, 1, 116) == 0 );
assert( gamma_move(board, 6, 96, 1) == 0 );
assert( gamma_move(board, 7, 0, 95) == 0 );
assert( gamma_move(board, 7, 1, 105) == 1 );
assert( gamma_busy_fields(board, 7) == 22 );
assert( gamma_move(board, 8, 14, 0) == 0 );
assert( gamma_move(board, 9, 118, 0) == 0 );
assert( gamma_free_fields(board, 9) == 82 );
assert( gamma_move(board, 1, 124, 0) == 0 );
assert( gamma_move(board, 1, 0, 108) == 1 );
assert( gamma_free_fields(board, 1) == 81 );
assert( gamma_move(board, 2, 0, 135) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 0, 48) == 1 );
assert( gamma_move(board, 4, 93, 1) == 0 );
assert( gamma_move(board, 5, 29, 1) == 0 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 26 );
assert( gamma_move(board, 7, 107, 1) == 0 );
assert( gamma_move(board, 7, 0, 133) == 0 );
assert( gamma_move(board, 8, 0, 82) == 0 );
assert( gamma_move(board, 8, 1, 6) == 1 );
assert( gamma_free_fields(board, 8) == 79 );
assert( gamma_move(board, 9, 96, 1) == 0 );
assert( gamma_move(board, 9, 0, 44) == 0 );
assert( gamma_move(board, 1, 52, 1) == 0 );
assert( gamma_move(board, 1, 0, 91) == 0 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 0, 82) == 0 );
assert( gamma_move(board, 2, 0, 37) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 0, 72) == 0 );
assert( gamma_move(board, 3, 0, 25) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_golden_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 93, 1) == 0 );
assert( gamma_golden_move(board, 4, 49, 1) == 0 );


char* board626260240 = gamma_board(board);
assert( board626260240 != NULL );
assert( strcmp(board626260240, 
"21\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"76\n"
"25\n"
"3.\n"
"..\n"
"48\n"
"6.\n"
".8\n"
"66\n"
"..\n"
"..\n"
"85\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"1.\n"
"..\n"
".4\n"
"1.\n"
"..\n"
".1\n"
"27\n"
"32\n"
"6.\n"
"81\n"
"75\n"
"37\n"
"85\n"
"77\n"
"66\n"
"8.\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"4.\n"
"46\n"
"86\n"
"8.\n"
"..\n"
"52\n"
"3.\n"
"..\n"
"56\n"
"74\n"
"1.\n"
".9\n"
"89\n"
"16\n"
"97\n"
"3.\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"4.\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
"37\n"
"17\n"
".4\n"
"58\n"
"94\n"
"24\n"
".4\n"
"14\n"
"49\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"7.\n"
"72\n"
"..\n"
".5\n"
"23\n"
".8\n"
"25\n"
"48\n"
"92\n"
"..\n"
"12\n"
"..\n"
"45\n"
"37\n"
"5.\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"28\n"
"..\n"
"..\n"
".2\n"
".2\n"
"93\n"
"51\n") == 0);
free(board626260240);
board626260240 = NULL;
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 6, 1, 69) == 0 );
assert( gamma_move(board, 6, 0, 94) == 0 );
assert( gamma_move(board, 7, 1, 77) == 0 );
assert( gamma_move(board, 7, 0, 68) == 0 );
assert( gamma_move(board, 8, 78, 1) == 0 );
assert( gamma_move(board, 8, 0, 26) == 0 );
assert( gamma_move(board, 9, 71, 0) == 0 );
assert( gamma_move(board, 1, 61, 0) == 0 );


char* board281126402 = gamma_board(board);
assert( board281126402 != NULL );
assert( strcmp(board281126402, 
"21\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"76\n"
"25\n"
"3.\n"
"..\n"
"48\n"
"6.\n"
".8\n"
"66\n"
"..\n"
"..\n"
"85\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"1.\n"
"..\n"
".4\n"
"1.\n"
"..\n"
".1\n"
"27\n"
"32\n"
"6.\n"
"81\n"
"75\n"
"37\n"
"85\n"
"77\n"
"66\n"
"8.\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"4.\n"
"46\n"
"86\n"
"8.\n"
"..\n"
"52\n"
"3.\n"
"..\n"
"56\n"
"74\n"
"1.\n"
".9\n"
"89\n"
"16\n"
"97\n"
"3.\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"4.\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
"37\n"
"17\n"
".4\n"
"58\n"
"94\n"
"24\n"
".4\n"
"14\n"
"49\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"7.\n"
"72\n"
"..\n"
".5\n"
"23\n"
".8\n"
"25\n"
"48\n"
"92\n"
"..\n"
"12\n"
"..\n"
"45\n"
"37\n"
"5.\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"28\n"
"..\n"
"..\n"
".2\n"
".2\n"
"93\n"
"51\n") == 0);
free(board281126402);
board281126402 = NULL;
assert( gamma_move(board, 2, 110, 1) == 0 );
assert( gamma_move(board, 2, 1, 125) == 1 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 3, 107, 0) == 0 );
assert( gamma_move(board, 3, 1, 74) == 0 );


char* board880923532 = gamma_board(board);
assert( board880923532 != NULL );
assert( strcmp(board880923532, 
"21\n"
"7.\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"76\n"
"25\n"
"32\n"
"..\n"
"48\n"
"6.\n"
".8\n"
"66\n"
"..\n"
"..\n"
"85\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"1.\n"
"..\n"
".4\n"
"1.\n"
"..\n"
".1\n"
"27\n"
"32\n"
"6.\n"
"81\n"
"75\n"
"37\n"
"85\n"
"77\n"
"66\n"
"8.\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"4.\n"
"46\n"
"86\n"
"8.\n"
"..\n"
"52\n"
"3.\n"
"..\n"
"56\n"
"74\n"
"1.\n"
".9\n"
"89\n"
"16\n"
"97\n"
"3.\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"4.\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
"37\n"
"17\n"
".4\n"
"58\n"
"94\n"
"24\n"
".4\n"
"14\n"
"49\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"7.\n"
"72\n"
"..\n"
".5\n"
"23\n"
".8\n"
"25\n"
"48\n"
"92\n"
"..\n"
"12\n"
"..\n"
"45\n"
"37\n"
"5.\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"28\n"
"..\n"
"..\n"
".2\n"
".2\n"
"93\n"
"51\n") == 0);
free(board880923532);
board880923532 = NULL;
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 5, 109, 0) == 0 );
assert( gamma_move(board, 5, 1, 16) == 1 );
assert( gamma_move(board, 6, 93, 0) == 0 );
assert( gamma_move(board, 6, 1, 69) == 0 );
assert( gamma_move(board, 7, 1, 135) == 1 );
assert( gamma_move(board, 8, 1, 22) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 1, 43) == 0 );
assert( gamma_move(board, 1, 72, 1) == 0 );
assert( gamma_move(board, 1, 0, 120) == 0 );
assert( gamma_move(board, 2, 110, 1) == 0 );
assert( gamma_free_fields(board, 2) == 76 );
assert( gamma_move(board, 3, 132, 0) == 0 );
assert( gamma_move(board, 4, 0, 78) == 1 );
assert( gamma_move(board, 4, 1, 122) == 1 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 61, 0) == 0 );
assert( gamma_move(board, 5, 0, 114) == 0 );
assert( gamma_move(board, 6, 108, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 0, 27) == 0 );
assert( gamma_move(board, 7, 0, 110) == 1 );
assert( gamma_move(board, 8, 108, 1) == 0 );
assert( gamma_move(board, 8, 0, 26) == 0 );
assert( gamma_move(board, 9, 1, 69) == 0 );
assert( gamma_move(board, 9, 1, 82) == 1 );
assert( gamma_move(board, 1, 63, 1) == 0 );
assert( gamma_move(board, 1, 1, 118) == 1 );
assert( gamma_busy_fields(board, 1) == 22 );
assert( gamma_free_fields(board, 1) == 71 );
assert( gamma_move(board, 2, 110, 1) == 0 );
assert( gamma_move(board, 2, 1, 82) == 0 );
assert( gamma_move(board, 3, 22, 0) == 0 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 4, 1, 88) == 0 );
assert( gamma_move(board, 4, 1, 44) == 0 );
assert( gamma_move(board, 5, 42, 0) == 0 );
assert( gamma_move(board, 6, 87, 0) == 0 );
assert( gamma_move(board, 6, 1, 74) == 0 );
assert( gamma_move(board, 7, 124, 0) == 0 );
assert( gamma_move(board, 7, 0, 96) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 124, 0) == 0 );
assert( gamma_move(board, 8, 0, 30) == 0 );
assert( gamma_move(board, 9, 1, 9) == 0 );
assert( gamma_move(board, 9, 0, 9) == 0 );


char* board278968819 = gamma_board(board);
assert( board278968819 != NULL );
assert( strcmp(board278968819, 
"21\n"
"77\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"76\n"
"25\n"
"32\n"
"..\n"
"48\n"
"64\n"
".8\n"
"66\n"
"..\n"
".1\n"
"85\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"1.\n"
"7.\n"
".4\n"
"1.\n"
"..\n"
".1\n"
"27\n"
"32\n"
"6.\n"
"81\n"
"75\n"
"37\n"
"85\n"
"77\n"
"66\n"
"8.\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"49\n"
"46\n"
"86\n"
"8.\n"
"4.\n"
"52\n"
"3.\n"
"..\n"
"56\n"
"74\n"
"1.\n"
".9\n"
"89\n"
"16\n"
"97\n"
"3.\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"4.\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
"37\n"
"17\n"
".4\n"
"58\n"
"94\n"
"24\n"
".4\n"
"14\n"
"49\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"7.\n"
"91\n"
"96\n"
"7.\n"
"72\n"
"..\n"
".5\n"
"23\n"
".8\n"
"25\n"
"48\n"
"92\n"
".5\n"
"12\n"
"..\n"
"45\n"
"37\n"
"5.\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"28\n"
"..\n"
"..\n"
".2\n"
"32\n"
"93\n"
"51\n") == 0);
free(board278968819);
board278968819 = NULL;
assert( gamma_move(board, 1, 78, 1) == 0 );
assert( gamma_move(board, 1, 1, 17) == 0 );
assert( gamma_busy_fields(board, 1) == 22 );
assert( gamma_move(board, 2, 0, 21) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 1, 121) == 0 );
assert( gamma_move(board, 4, 76, 1) == 0 );
assert( gamma_move(board, 5, 75, 1) == 0 );
assert( gamma_move(board, 6, 46, 0) == 0 );
assert( gamma_free_fields(board, 6) == 70 );
assert( gamma_move(board, 7, 1, 76) == 1 );
assert( gamma_move(board, 8, 134, 1) == 0 );
assert( gamma_free_fields(board, 8) == 69 );
assert( gamma_move(board, 9, 1, 88) == 0 );
assert( gamma_move(board, 9, 1, 28) == 1 );
assert( gamma_move(board, 1, 78, 1) == 0 );
assert( gamma_move(board, 1, 1, 96) == 1 );
assert( gamma_busy_fields(board, 2) == 24 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 61, 1) == 0 );
assert( gamma_move(board, 5, 0, 98) == 0 );
assert( gamma_move(board, 6, 1, 70) == 0 );
assert( gamma_golden_move(board, 6, 116, 0) == 0 );
assert( gamma_move(board, 7, 119, 1) == 0 );
assert( gamma_move(board, 7, 0, 23) == 1 );


char* board905162246 = gamma_board(board);
assert( board905162246 != NULL );
assert( strcmp(board905162246, 
"21\n"
"77\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"76\n"
"25\n"
"32\n"
"..\n"
"48\n"
"64\n"
".8\n"
"66\n"
"..\n"
".1\n"
"85\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"1.\n"
"7.\n"
".4\n"
"1.\n"
"..\n"
".1\n"
"27\n"
"32\n"
"6.\n"
"81\n"
"75\n"
"37\n"
"85\n"
"77\n"
"66\n"
"81\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"49\n"
"46\n"
"86\n"
"8.\n"
"4.\n"
"52\n"
"37\n"
"..\n"
"56\n"
"74\n"
"1.\n"
".9\n"
"89\n"
"16\n"
"97\n"
"3.\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"4.\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
"37\n"
"17\n"
".4\n"
"58\n"
"94\n"
"24\n"
".4\n"
"14\n"
"49\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"79\n"
"91\n"
"96\n"
"7.\n"
"72\n"
"7.\n"
".5\n"
"23\n"
".8\n"
"25\n"
"48\n"
"92\n"
".5\n"
"12\n"
"..\n"
"45\n"
"37\n"
"5.\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"28\n"
"..\n"
"..\n"
".2\n"
"32\n"
"93\n"
"51\n") == 0);
free(board905162246);
board905162246 = NULL;
assert( gamma_move(board, 8, 23, 1) == 0 );
assert( gamma_move(board, 9, 31, 0) == 0 );
assert( gamma_move(board, 9, 0, 37) == 0 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_free_fields(board, 1) == 66 );


char* board893003664 = gamma_board(board);
assert( board893003664 != NULL );
assert( strcmp(board893003664, 
"21\n"
"77\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"76\n"
"25\n"
"32\n"
"..\n"
"48\n"
"64\n"
".8\n"
"66\n"
"..\n"
".1\n"
"85\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"1.\n"
"7.\n"
".4\n"
"1.\n"
"..\n"
".1\n"
"27\n"
"32\n"
"6.\n"
"81\n"
"75\n"
"37\n"
"85\n"
"77\n"
"66\n"
"81\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"49\n"
"46\n"
"86\n"
"8.\n"
"4.\n"
"52\n"
"37\n"
"..\n"
"56\n"
"74\n"
"1.\n"
".9\n"
"89\n"
"16\n"
"97\n"
"3.\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"4.\n"
"..\n"
"..\n"
"63\n"
".7\n"
"55\n"
"66\n"
"71\n"
"8.\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
"37\n"
"17\n"
".4\n"
"58\n"
"94\n"
"24\n"
".4\n"
"14\n"
"49\n"
"79\n"
"17\n"
"86\n"
"7.\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"79\n"
"91\n"
"96\n"
"7.\n"
"72\n"
"7.\n"
".5\n"
"23\n"
".8\n"
"25\n"
"48\n"
"92\n"
".5\n"
"12\n"
"..\n"
"45\n"
"37\n"
"5.\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"28\n"
"..\n"
"..\n"
".2\n"
"32\n"
"93\n"
"51\n") == 0);
free(board893003664);
board893003664 = NULL;
assert( gamma_move(board, 3, 67, 1) == 0 );
assert( gamma_move(board, 3, 0, 23) == 0 );
assert( gamma_move(board, 5, 25, 1) == 0 );
assert( gamma_move(board, 5, 1, 86) == 0 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 7, 71, 0) == 0 );
assert( gamma_move(board, 7, 1, 133) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 5, 1) == 0 );
assert( gamma_move(board, 8, 1, 135) == 0 );
assert( gamma_move(board, 9, 0, 28) == 0 );
assert( gamma_move(board, 9, 1, 131) == 0 );
assert( gamma_golden_move(board, 9, 80, 0) == 0 );
assert( gamma_move(board, 1, 63, 1) == 0 );
assert( gamma_move(board, 2, 121, 0) == 0 );
assert( gamma_move(board, 2, 0, 105) == 0 );
assert( gamma_move(board, 3, 23, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 130, 0) == 0 );
assert( gamma_move(board, 4, 0, 131) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 69) == 0 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 7, 1, 69) == 0 );
assert( gamma_move(board, 8, 1, 55) == 0 );
assert( gamma_move(board, 8, 0, 58) == 1 );
assert( gamma_busy_fields(board, 8) == 23 );
assert( gamma_move(board, 1, 87, 0) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 23, 1) == 0 );
assert( gamma_move(board, 3, 1, 57) == 0 );
assert( gamma_move(board, 4, 61, 1) == 0 );
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_move(board, 5, 0, 80) == 0 );
assert( gamma_move(board, 6, 60, 0) == 0 );
assert( gamma_move(board, 7, 85, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_busy_fields(board, 8) == 23 );
assert( gamma_move(board, 9, 0, 60) == 1 );
assert( gamma_move(board, 9, 0, 77) == 0 );
assert( gamma_golden_move(board, 9, 97, 1) == 0 );
assert( gamma_move(board, 1, 1, 36) == 1 );
assert( gamma_move(board, 1, 0, 30) == 0 );
assert( gamma_free_fields(board, 1) == 62 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 2, 1, 22) == 0 );
assert( gamma_golden_move(board, 2, 48, 0) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 5, 1, 51) == 0 );
assert( gamma_move(board, 5, 0, 134) == 0 );
assert( gamma_move(board, 6, 63, 1) == 0 );
assert( gamma_move(board, 6, 1, 66) == 0 );
assert( gamma_move(board, 7, 60, 1) == 0 );
assert( gamma_move(board, 7, 0, 111) == 0 );
assert( gamma_move(board, 8, 16, 0) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 63, 1) == 0 );
assert( gamma_move(board, 9, 0, 79) == 0 );
assert( gamma_free_fields(board, 9) == 62 );
assert( gamma_move(board, 1, 0, 66) == 0 );
assert( gamma_move(board, 2, 0, 55) == 0 );
assert( gamma_move(board, 2, 0, 107) == 1 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 0, 72) == 0 );
assert( gamma_move(board, 3, 0, 37) == 0 );
assert( gamma_move(board, 4, 118, 0) == 0 );
assert( gamma_move(board, 4, 1, 54) == 1 );
assert( gamma_move(board, 5, 112, 1) == 0 );
assert( gamma_move(board, 5, 1, 22) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 106, 0) == 0 );
assert( gamma_move(board, 6, 1, 5) == 1 );
assert( gamma_move(board, 8, 92, 0) == 0 );
assert( gamma_move(board, 8, 0, 71) == 1 );
assert( gamma_move(board, 9, 61, 0) == 0 );
assert( gamma_move(board, 9, 1, 11) == 1 );
assert( gamma_free_fields(board, 9) == 57 );
assert( gamma_move(board, 1, 112, 1) == 0 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 2, 1, 45) == 0 );
assert( gamma_busy_fields(board, 2) == 25 );
assert( gamma_move(board, 3, 1, 67) == 1 );
assert( gamma_move(board, 3, 1, 55) == 0 );
assert( gamma_move(board, 4, 0, 39) == 0 );
assert( gamma_move(board, 5, 109, 0) == 0 );
assert( gamma_move(board, 5, 0, 95) == 0 );
assert( gamma_move(board, 6, 106, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 27 );
assert( gamma_move(board, 7, 85, 1) == 0 );
assert( gamma_move(board, 7, 0, 113) == 0 );
assert( gamma_move(board, 8, 92, 0) == 0 );
assert( gamma_move(board, 8, 0, 45) == 0 );
assert( gamma_free_fields(board, 8) == 56 );
assert( gamma_golden_move(board, 8, 74, 0) == 0 );
assert( gamma_move(board, 9, 4, 0) == 0 );
assert( gamma_move(board, 9, 1, 119) == 1 );
assert( gamma_golden_move(board, 9, 77, 1) == 0 );
assert( gamma_move(board, 1, 61, 1) == 0 );
assert( gamma_move(board, 2, 92, 0) == 0 );
assert( gamma_move(board, 2, 0, 119) == 1 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 4, 62, 1) == 0 );
assert( gamma_move(board, 5, 0, 37) == 0 );
assert( gamma_move(board, 5, 0, 66) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_golden_move(board, 6, 100, 1) == 0 );
assert( gamma_move(board, 7, 107, 1) == 0 );
assert( gamma_move(board, 8, 46, 0) == 0 );
assert( gamma_move(board, 9, 42, 0) == 0 );
assert( gamma_move(board, 1, 1, 71) == 0 );
assert( gamma_move(board, 1, 1, 120) == 0 );
assert( gamma_golden_move(board, 2, 79, 0) == 0 );
assert( gamma_move(board, 4, 0, 16) == 1 );


char* board856534934 = gamma_board(board);
assert( board856534934 != NULL );
assert( strcmp(board856534934, 
"21\n"
"77\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"76\n"
"25\n"
"32\n"
"..\n"
"48\n"
"64\n"
".8\n"
"66\n"
"29\n"
".1\n"
"85\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"1.\n"
"7.\n"
".4\n"
"1.\n"
"2.\n"
".1\n"
"27\n"
"32\n"
"6.\n"
"81\n"
"75\n"
"37\n"
"85\n"
"77\n"
"66\n"
"81\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"49\n"
"46\n"
"86\n"
"8.\n"
"4.\n"
"52\n"
"37\n"
"..\n"
"56\n"
"74\n"
"1.\n"
"89\n"
"89\n"
"16\n"
"97\n"
"33\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"4.\n"
"..\n"
"9.\n"
"63\n"
"87\n"
"55\n"
"66\n"
"71\n"
"84\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
"37\n"
"17\n"
".4\n"
"58\n"
"94\n"
"24\n"
".4\n"
"14\n"
"49\n"
"79\n"
"17\n"
"86\n"
"71\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"79\n"
"91\n"
"96\n"
"7.\n"
"72\n"
"7.\n"
".5\n"
"23\n"
".8\n"
"25\n"
"48\n"
"92\n"
"45\n"
"12\n"
"4.\n"
"45\n"
"37\n"
"59\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"28\n"
".6\n"
"..\n"
".2\n"
"32\n"
"93\n"
"51\n") == 0);
free(board856534934);
board856534934 = NULL;
assert( gamma_move(board, 5, 93, 0) == 0 );
assert( gamma_move(board, 5, 1, 117) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 7, 4, 1) == 0 );
assert( gamma_move(board, 7, 1, 101) == 0 );
assert( gamma_move(board, 8, 0, 90) == 0 );


char* board827883542 = gamma_board(board);
assert( board827883542 != NULL );
assert( strcmp(board827883542, 
"21\n"
"77\n"
"2.\n"
"72\n"
".1\n"
"13\n"
".9\n"
"45\n"
".3\n"
"76\n"
"25\n"
"32\n"
"..\n"
"48\n"
"64\n"
".8\n"
"66\n"
"29\n"
".1\n"
"85\n"
"13\n"
".1\n"
"48\n"
"61\n"
"..\n"
"1.\n"
"7.\n"
".4\n"
"1.\n"
"2.\n"
".1\n"
"27\n"
"32\n"
"6.\n"
"81\n"
"75\n"
"37\n"
"85\n"
"77\n"
"66\n"
"81\n"
"82\n"
"27\n"
"..\n"
".3\n"
"65\n"
"82\n"
"69\n"
"92\n"
".8\n"
"82\n"
"1.\n"
"2.\n"
"69\n"
"49\n"
"46\n"
"86\n"
"8.\n"
"4.\n"
"52\n"
"37\n"
"..\n"
"56\n"
"74\n"
"1.\n"
"89\n"
"89\n"
"16\n"
"97\n"
"33\n"
"99\n"
"93\n"
"63\n"
"6.\n"
"4.\n"
"..\n"
"9.\n"
"63\n"
"87\n"
"55\n"
"66\n"
"71\n"
"84\n"
"59\n"
"9.\n"
"39\n"
"44\n"
"46\n"
"37\n"
"17\n"
".4\n"
"58\n"
"94\n"
"24\n"
".4\n"
"14\n"
"49\n"
"79\n"
"17\n"
"86\n"
"71\n"
"5.\n"
"62\n"
".6\n"
"46\n"
".5\n"
"14\n"
"3.\n"
"79\n"
"91\n"
"96\n"
"7.\n"
"72\n"
"7.\n"
".5\n"
"23\n"
".8\n"
"25\n"
"48\n"
"92\n"
"45\n"
"12\n"
"4.\n"
"45\n"
"37\n"
"59\n"
"3.\n"
"93\n"
".8\n"
"8.\n"
"28\n"
".6\n"
"..\n"
".2\n"
"32\n"
"93\n"
"51\n") == 0);
free(board827883542);
board827883542 = NULL;


gamma_delete(board);

    return 0;
}
