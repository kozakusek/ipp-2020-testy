#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 125816652
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(2, 102, 8, 22);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 20) == 1 );
assert( gamma_move(board, 3, 78, 0) == 0 );
assert( gamma_move(board, 3, 1, 50) == 1 );
assert( gamma_golden_move(board, 3, 20, 1) == 0 );
assert( gamma_move(board, 4, 98, 0) == 0 );
assert( gamma_move(board, 4, 1, 71) == 1 );
assert( gamma_golden_move(board, 4, 20, 1) == 0 );
assert( gamma_move(board, 5, 75, 0) == 0 );
assert( gamma_move(board, 5, 0, 61) == 1 );
assert( gamma_busy_fields(board, 5) == 1 );
assert( gamma_free_fields(board, 5) == 200 );
assert( gamma_move(board, 7, 47, 1) == 0 );
assert( gamma_move(board, 1, 0, 70) == 1 );
assert( gamma_move(board, 2, 59, 0) == 0 );
assert( gamma_move(board, 3, 0, 79) == 1 );
assert( gamma_move(board, 3, 0, 24) == 1 );
assert( gamma_move(board, 4, 88, 1) == 0 );
assert( gamma_move(board, 4, 0, 74) == 1 );


char* board941425677 = gamma_board(board);
assert( board941425677 != NULL );
assert( strcmp(board941425677, 
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"4.\n"
"..\n"
"..\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"5.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n") == 0);
free(board941425677);
board941425677 = NULL;
assert( gamma_move(board, 5, 0, 101) == 1 );
assert( gamma_move(board, 6, 0, 33) == 1 );
assert( gamma_move(board, 7, 16, 1) == 0 );
assert( gamma_move(board, 7, 0, 75) == 1 );
assert( gamma_move(board, 8, 0, 84) == 1 );
assert( gamma_move(board, 8, 1, 94) == 1 );
assert( gamma_move(board, 1, 24, 1) == 0 );
assert( gamma_move(board, 1, 0, 19) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 2, 1, 85) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 74, 1) == 0 );
assert( gamma_move(board, 4, 21, 0) == 0 );
assert( gamma_move(board, 5, 22, 0) == 0 );
assert( gamma_move(board, 6, 0, 34) == 1 );
assert( gamma_move(board, 6, 1, 50) == 0 );
assert( gamma_move(board, 7, 19, 1) == 0 );
assert( gamma_move(board, 7, 1, 80) == 1 );
assert( gamma_golden_move(board, 7, 19, 0) == 0 );
assert( gamma_move(board, 8, 0, 10) == 1 );
assert( gamma_move(board, 8, 0, 75) == 0 );
assert( gamma_move(board, 1, 0, 50) == 1 );
assert( gamma_move(board, 1, 1, 28) == 1 );
assert( gamma_move(board, 2, 93, 1) == 0 );
assert( gamma_move(board, 3, 81, 1) == 0 );


char* board934565879 = gamma_board(board);
assert( board934565879 != NULL );
assert( strcmp(board934565879, 
"5.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"8.\n"
"..\n"
"..\n"
"..\n"
".7\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"7.\n"
"4.\n"
"..\n"
"..\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"5.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"13\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
".1\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"..\n"
"..\n") == 0);
free(board934565879);
board934565879 = NULL;
assert( gamma_move(board, 4, 17, 1) == 0 );
assert( gamma_move(board, 4, 0, 1) == 1 );
assert( gamma_move(board, 5, 1, 79) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 82, 1) == 0 );
assert( gamma_move(board, 6, 1, 99) == 1 );
assert( gamma_move(board, 7, 57, 1) == 0 );
assert( gamma_move(board, 7, 0, 52) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_move(board, 7, 50, 0) == 0 );
assert( gamma_move(board, 8, 0, 53) == 1 );
assert( gamma_free_fields(board, 8) == 178 );
assert( gamma_move(board, 1, 0, 75) == 0 );
assert( gamma_move(board, 2, 0, 77) == 1 );
assert( gamma_move(board, 2, 1, 88) == 1 );
assert( gamma_busy_fields(board, 2) == 4 );
assert( gamma_move(board, 3, 53, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 32) == 1 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 6, 45, 1) == 0 );
assert( gamma_move(board, 6, 0, 39) == 1 );
assert( gamma_move(board, 7, 1, 46) == 1 );
assert( gamma_move(board, 7, 0, 20) == 1 );
assert( gamma_move(board, 8, 14, 1) == 0 );
assert( gamma_move(board, 8, 1, 63) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 2, 0, 79) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 49, 0) == 0 );
assert( gamma_move(board, 3, 1, 15) == 1 );
assert( gamma_free_fields(board, 3) == 170 );
assert( gamma_move(board, 4, 47, 0) == 0 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_move(board, 5, 45, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 4 );
assert( gamma_move(board, 7, 93, 1) == 0 );
assert( gamma_move(board, 7, 0, 13) == 1 );
assert( gamma_busy_fields(board, 7) == 6 );
assert( gamma_move(board, 8, 0, 89) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 77, 1) == 0 );
assert( gamma_move(board, 1, 0, 36) == 1 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_free_fields(board, 1) == 166 );
assert( gamma_golden_move(board, 1, 80, 1) == 0 );
assert( gamma_move(board, 2, 0, 48) == 1 );


char* board125990838 = gamma_board(board);
assert( board125990838 != NULL );
assert( strcmp(board125990838, 
"5.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".2\n"
"..\n"
"..\n"
".2\n"
"8.\n"
"..\n"
"..\n"
"..\n"
".7\n"
"35\n"
"..\n"
"2.\n"
"..\n"
"7.\n"
"4.\n"
"..\n"
"..\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".8\n"
"..\n"
"5.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"7.\n"
"..\n"
"13\n"
"..\n"
"2.\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"6.\n"
"6.\n"
".4\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"71\n"
"1.\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"7.\n"
"..\n"
"..\n"
"8.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
".2\n"
"..\n"
"4.\n"
"..\n") == 0);
free(board125990838);
board125990838 = NULL;
assert( gamma_move(board, 3, 91, 0) == 0 );
assert( gamma_move(board, 4, 1, 25) == 1 );
assert( gamma_move(board, 5, 59, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 7, 89, 1) == 0 );
assert( gamma_move(board, 7, 0, 60) == 1 );
assert( gamma_move(board, 8, 74, 1) == 0 );
assert( gamma_move(board, 8, 1, 75) == 1 );
assert( gamma_move(board, 1, 0, 38) == 1 );
assert( gamma_move(board, 1, 1, 20) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 99, 1) == 0 );
assert( gamma_move(board, 2, 1, 55) == 1 );
assert( gamma_move(board, 3, 26, 0) == 0 );
assert( gamma_move(board, 3, 0, 88) == 1 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_move(board, 4, 0, 21) == 1 );
assert( gamma_move(board, 4, 1, 8) == 1 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 1, 7) == 1 );
assert( gamma_move(board, 7, 0, 70) == 0 );
assert( gamma_busy_fields(board, 7) == 7 );
assert( gamma_move(board, 8, 69, 0) == 0 );
assert( gamma_busy_fields(board, 8) == 7 );
assert( gamma_move(board, 1, 74, 1) == 0 );
assert( gamma_move(board, 1, 0, 38) == 0 );
assert( gamma_golden_move(board, 1, 99, 1) == 0 );


char* board714154589 = gamma_board(board);
assert( board714154589 != NULL );
assert( strcmp(board714154589, 
"5.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"..\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"32\n"
"..\n"
"..\n"
".2\n"
"8.\n"
"..\n"
"..\n"
"..\n"
".7\n"
"35\n"
"..\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
"..\n"
"..\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".8\n"
"..\n"
"5.\n"
"7.\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"8.\n"
"7.\n"
"..\n"
"13\n"
"..\n"
"2.\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"1.\n"
"..\n"
"1.\n"
"..\n"
"6.\n"
"6.\n"
".4\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"..\n"
".4\n"
"3.\n"
"..\n"
"..\n"
"4.\n"
"71\n"
"1.\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"7.\n"
"..\n"
"..\n"
"8.\n"
"..\n"
".4\n"
".5\n"
".4\n"
"..\n"
"..\n"
".2\n"
"..\n"
"4.\n"
"..\n") == 0);
free(board714154589);
board714154589 = NULL;
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 4, 38, 1) == 0 );
assert( gamma_move(board, 5, 1, 35) == 1 );
assert( gamma_move(board, 6, 12, 0) == 0 );
assert( gamma_move(board, 6, 1, 95) == 1 );
assert( gamma_move(board, 7, 58, 1) == 0 );
assert( gamma_free_fields(board, 7) == 153 );
assert( gamma_move(board, 8, 10, 1) == 0 );
assert( gamma_move(board, 1, 28, 0) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 2, 1, 46) == 0 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_move(board, 3, 0, 8) == 1 );
assert( gamma_move(board, 3, 0, 72) == 1 );
assert( gamma_move(board, 4, 27, 1) == 0 );
assert( gamma_move(board, 4, 0, 12) == 1 );
assert( gamma_move(board, 5, 1, 26) == 1 );
assert( gamma_move(board, 5, 0, 84) == 0 );
assert( gamma_move(board, 6, 78, 0) == 0 );
assert( gamma_move(board, 6, 1, 67) == 1 );
assert( gamma_move(board, 7, 68, 0) == 0 );
assert( gamma_move(board, 7, 0, 21) == 0 );
assert( gamma_free_fields(board, 7) == 148 );
assert( gamma_move(board, 8, 76, 0) == 0 );
assert( gamma_move(board, 8, 0, 93) == 1 );
assert( gamma_free_fields(board, 8) == 147 );
assert( gamma_move(board, 1, 1, 37) == 1 );
assert( gamma_move(board, 2, 77, 1) == 0 );
assert( gamma_move(board, 2, 0, 40) == 1 );
assert( gamma_move(board, 3, 1, 88) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 73) == 1 );
assert( gamma_move(board, 5, 1, 25) == 0 );
assert( gamma_free_fields(board, 5) == 144 );
assert( gamma_golden_move(board, 5, 95, 1) == 0 );


char* board788258385 = gamma_board(board);
assert( board788258385 != NULL );
assert( strcmp(board788258385, 
"5.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
".6\n"
".8\n"
"8.\n"
"..\n"
"..\n"
"..\n"
"8.\n"
"32\n"
"..\n"
"..\n"
".2\n"
"8.\n"
"..\n"
"..\n"
"..\n"
".7\n"
"35\n"
"..\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"3.\n"
".4\n"
"1.\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
".8\n"
"..\n"
"5.\n"
"7.\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"8.\n"
"7.\n"
"..\n"
"13\n"
"..\n"
"2.\n"
"..\n"
".7\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
".1\n"
"1.\n"
".5\n"
"6.\n"
"6.\n"
".4\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
".5\n"
".4\n"
"3.\n"
"..\n"
"..\n"
"4.\n"
"71\n"
"1.\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"7.\n"
"4.\n"
"..\n"
"8.\n"
"..\n"
"34\n"
".5\n"
".4\n"
"..\n"
"2.\n"
".2\n"
"..\n"
"4.\n"
"..\n") == 0);
free(board788258385);
board788258385 = NULL;
assert( gamma_move(board, 6, 46, 0) == 0 );
assert( gamma_free_fields(board, 6) == 144 );
assert( gamma_move(board, 8, 1, 37) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 0, 29) == 1 );
assert( gamma_move(board, 2, 1, 80) == 0 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_move(board, 4, 1, 13) == 1 );
assert( gamma_move(board, 4, 1, 50) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_free_fields(board, 4) == 142 );
assert( gamma_move(board, 5, 0, 94) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 59) == 1 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 41, 1) == 0 );
assert( gamma_move(board, 7, 1, 88) == 0 );
assert( gamma_move(board, 8, 95, 0) == 0 );
assert( gamma_move(board, 1, 39, 1) == 0 );
assert( gamma_move(board, 1, 0, 37) == 1 );
assert( gamma_move(board, 3, 0, 79) == 0 );
assert( gamma_busy_fields(board, 3) == 7 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 4, 1, 99) == 0 );
assert( gamma_move(board, 5, 1, 91) == 1 );
assert( gamma_free_fields(board, 5) == 138 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 7, 0, 67) == 1 );
assert( gamma_move(board, 8, 53, 1) == 0 );
assert( gamma_move(board, 8, 1, 7) == 0 );
assert( gamma_move(board, 1, 1, 60) == 1 );
assert( gamma_move(board, 2, 58, 0) == 0 );
assert( gamma_golden_move(board, 2, 79, 1) == 0 );
assert( gamma_move(board, 3, 1, 53) == 1 );
assert( gamma_move(board, 4, 42, 0) == 0 );
assert( gamma_move(board, 4, 0, 61) == 0 );
assert( gamma_move(board, 5, 0, 87) == 1 );
assert( gamma_move(board, 6, 1, 83) == 1 );
assert( gamma_move(board, 6, 0, 18) == 1 );
assert( gamma_busy_fields(board, 7) == 8 );
assert( gamma_move(board, 8, 81, 1) == 0 );
assert( gamma_move(board, 1, 0, 82) == 1 );
assert( gamma_move(board, 2, 90, 1) == 0 );
assert( gamma_move(board, 3, 1, 80) == 0 );
assert( gamma_move(board, 4, 43, 0) == 0 );
assert( gamma_move(board, 4, 0, 40) == 0 );
assert( gamma_move(board, 5, 98, 0) == 0 );
assert( gamma_move(board, 6, 24, 1) == 0 );
assert( gamma_move(board, 6, 1, 19) == 1 );
assert( gamma_move(board, 7, 66, 1) == 0 );
assert( gamma_move(board, 7, 1, 25) == 0 );
assert( gamma_move(board, 8, 66, 0) == 0 );
assert( gamma_move(board, 2, 0, 72) == 0 );
assert( gamma_move(board, 2, 0, 82) == 0 );
assert( gamma_busy_fields(board, 2) == 9 );
assert( gamma_move(board, 3, 0, 78) == 1 );
assert( gamma_move(board, 3, 1, 18) == 1 );
assert( gamma_move(board, 4, 57, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 1, 8) == 0 );
assert( gamma_move(board, 6, 1, 24) == 1 );
assert( gamma_move(board, 7, 92, 1) == 0 );
assert( gamma_move(board, 8, 66, 1) == 0 );
assert( gamma_move(board, 1, 1, 49) == 1 );
assert( gamma_move(board, 1, 1, 81) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 1, 94) == 0 );
assert( gamma_move(board, 3, 1, 85) == 0 );
assert( gamma_move(board, 3, 1, 35) == 0 );
assert( gamma_move(board, 4, 49, 0) == 0 );
assert( gamma_move(board, 5, 0, 26) == 1 );
assert( gamma_move(board, 6, 31, 0) == 0 );
assert( gamma_move(board, 6, 1, 9) == 1 );
assert( gamma_move(board, 7, 87, 1) == 0 );
assert( gamma_move(board, 8, 9, 0) == 0 );
assert( gamma_move(board, 1, 32, 0) == 0 );
assert( gamma_move(board, 1, 0, 67) == 0 );
assert( gamma_free_fields(board, 1) == 123 );
assert( gamma_golden_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 96, 1) == 0 );
assert( gamma_move(board, 3, 54, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 93, 1) == 0 );
assert( gamma_free_fields(board, 5) == 123 );
assert( gamma_move(board, 6, 59, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 23) == 1 );
assert( gamma_move(board, 7, 1, 30) == 1 );
assert( gamma_free_fields(board, 7) == 121 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 42, 1) == 0 );
assert( gamma_move(board, 8, 1, 52) == 1 );
assert( gamma_move(board, 1, 32, 0) == 0 );
assert( gamma_move(board, 1, 0, 29) == 0 );
assert( gamma_free_fields(board, 1) == 120 );
assert( gamma_move(board, 2, 31, 0) == 0 );
assert( gamma_move(board, 2, 0, 95) == 1 );
assert( gamma_free_fields(board, 2) == 119 );
assert( gamma_move(board, 3, 76, 0) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 98, 1) == 0 );
assert( gamma_move(board, 5, 1, 45) == 1 );
assert( gamma_free_fields(board, 5) == 118 );
assert( gamma_move(board, 6, 63, 0) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_move(board, 7, 0, 38) == 0 );
assert( gamma_move(board, 8, 47, 1) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 1, 66) == 1 );
assert( gamma_move(board, 1, 1, 81) == 0 );
assert( gamma_move(board, 2, 42, 1) == 0 );
assert( gamma_move(board, 2, 1, 59) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 34, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 35) == 0 );
assert( gamma_golden_move(board, 4, 75, 0) == 0 );
assert( gamma_move(board, 5, 73, 0) == 0 );
assert( gamma_move(board, 5, 1, 47) == 1 );
assert( gamma_move(board, 6, 80, 0) == 0 );
assert( gamma_free_fields(board, 6) == 115 );
assert( gamma_move(board, 7, 40, 1) == 0 );
assert( gamma_move(board, 7, 1, 52) == 0 );
assert( gamma_move(board, 8, 3, 0) == 0 );


char* board493163961 = gamma_board(board);
assert( board493163961 != NULL );
assert( strcmp(board493163961, 
"5.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
"..\n"
".5\n"
"..\n"
"8.\n"
"32\n"
"5.\n"
"..\n"
".2\n"
"8.\n"
".6\n"
"1.\n"
".1\n"
".7\n"
"35\n"
"3.\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"3.\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"..\n"
".8\n"
"..\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"1.\n"
".5\n"
"6.\n"
"6.\n"
".4\n"
"..\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
".7\n"
"..\n"
"4.\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"..\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
".4\n"
"..\n"
"2.\n"
".2\n"
"..\n"
"4.\n"
"..\n") == 0);
free(board493163961);
board493163961 = NULL;
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 1, 1, 7) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 73, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 22, 1) == 0 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 5, 1, 54) == 1 );
assert( gamma_move(board, 6, 57, 0) == 0 );
assert( gamma_move(board, 7, 98, 0) == 0 );
assert( gamma_move(board, 7, 0, 44) == 1 );
assert( gamma_move(board, 8, 12, 1) == 0 );
assert( gamma_move(board, 8, 1, 92) == 1 );
assert( gamma_busy_fields(board, 8) == 10 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 1, 0, 54) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 5, 0, 64) == 1 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_move(board, 6, 1, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_free_fields(board, 6) == 109 );
assert( gamma_move(board, 7, 42, 1) == 0 );
assert( gamma_free_fields(board, 7) == 109 );
assert( gamma_move(board, 8, 0, 56) == 1 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 46, 0) == 0 );
assert( gamma_move(board, 2, 1, 47) == 0 );
assert( gamma_move(board, 3, 34, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 82) == 1 );
assert( gamma_move(board, 4, 1, 32) == 0 );
assert( gamma_golden_move(board, 4, 89, 0) == 0 );
assert( gamma_move(board, 5, 31, 1) == 0 );
assert( gamma_move(board, 5, 1, 94) == 0 );
assert( gamma_move(board, 6, 1, 45) == 0 );
assert( gamma_move(board, 7, 17, 1) == 0 );
assert( gamma_move(board, 8, 1, 43) == 1 );
assert( gamma_move(board, 8, 0, 85) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 0, 57) == 1 );
assert( gamma_move(board, 2, 35, 0) == 0 );
assert( gamma_move(board, 3, 25, 0) == 0 );
assert( gamma_move(board, 3, 0, 81) == 1 );
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_move(board, 5, 30, 0) == 0 );
assert( gamma_move(board, 6, 0, 34) == 0 );
assert( gamma_move(board, 7, 1, 54) == 0 );
assert( gamma_move(board, 7, 1, 20) == 0 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 8, 6, 0) == 0 );
assert( gamma_move(board, 1, 61, 1) == 0 );
assert( gamma_move(board, 2, 100, 0) == 0 );
assert( gamma_move(board, 3, 0, 21) == 0 );
assert( gamma_move(board, 4, 0, 89) == 0 );
assert( gamma_move(board, 4, 1, 78) == 1 );
assert( gamma_move(board, 5, 1, 89) == 1 );
assert( gamma_move(board, 5, 0, 24) == 0 );
assert( gamma_free_fields(board, 5) == 100 );
assert( gamma_move(board, 6, 97, 0) == 0 );
assert( gamma_move(board, 6, 0, 79) == 0 );
assert( gamma_move(board, 7, 1, 52) == 0 );
assert( gamma_move(board, 8, 1, 6) == 0 );
assert( gamma_move(board, 1, 69, 0) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 92, 0) == 0 );
assert( gamma_move(board, 2, 1, 14) == 1 );


char* board742462962 = gamma_board(board);
assert( board742462962 != NULL );
assert( strcmp(board742462962, 
"5.\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"..\n"
"85\n"
"32\n"
"5.\n"
"..\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"3.\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"5.\n"
".8\n"
"..\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
".2\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"7.\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"1.\n"
".5\n"
"6.\n"
"6.\n"
".4\n"
"..\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
".7\n"
"..\n"
"4.\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
".4\n"
"..\n"
"2.\n"
".2\n"
"4.\n"
"4.\n"
"..\n") == 0);
free(board742462962);
board742462962 = NULL;
assert( gamma_move(board, 3, 42, 1) == 0 );
assert( gamma_move(board, 3, 0, 62) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 86, 0) == 0 );
assert( gamma_move(board, 4, 1, 98) == 1 );
assert( gamma_move(board, 5, 29, 1) == 0 );
assert( gamma_move(board, 6, 35, 0) == 0 );
assert( gamma_move(board, 6, 0, 55) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 50, 0) == 0 );
assert( gamma_move(board, 7, 1, 87) == 1 );
assert( gamma_move(board, 7, 1, 25) == 0 );
assert( gamma_free_fields(board, 7) == 95 );
assert( gamma_move(board, 8, 1, 36) == 1 );
assert( gamma_move(board, 8, 1, 36) == 0 );
assert( gamma_busy_fields(board, 8) == 14 );
assert( gamma_move(board, 1, 35, 0) == 0 );


char* board905681899 = gamma_board(board);
assert( board905681899 != NULL );
assert( strcmp(board905681899, 
"5.\n"
"..\n"
".6\n"
".4\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"..\n"
"85\n"
"32\n"
"57\n"
"..\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"3.\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"5.\n"
".8\n"
"3.\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"7.\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
".5\n"
"6.\n"
"6.\n"
".4\n"
"..\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
".7\n"
"..\n"
"4.\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
".4\n"
"..\n"
"2.\n"
".2\n"
"4.\n"
"4.\n"
"..\n") == 0);
free(board905681899);
board905681899 = NULL;
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 4, 80, 0) == 0 );
assert( gamma_move(board, 5, 61, 1) == 0 );


char* board780718591 = gamma_board(board);
assert( board780718591 != NULL );
assert( strcmp(board780718591, 
"5.\n"
"..\n"
".6\n"
".4\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"..\n"
"85\n"
"32\n"
"57\n"
"..\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"3.\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"5.\n"
".8\n"
"3.\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"7.\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
".5\n"
"6.\n"
"6.\n"
".4\n"
"..\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
".7\n"
"..\n"
"4.\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
".4\n"
"..\n"
"2.\n"
".2\n"
"4.\n"
"4.\n"
"..\n") == 0);
free(board780718591);
board780718591 = NULL;
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 7, 84, 1) == 0 );
assert( gamma_free_fields(board, 7) == 94 );
assert( gamma_move(board, 8, 41, 0) == 0 );
assert( gamma_move(board, 1, 86, 0) == 0 );
assert( gamma_move(board, 2, 1, 21) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 83, 0) == 0 );
assert( gamma_move(board, 5, 31, 1) == 0 );
assert( gamma_move(board, 6, 86, 1) == 0 );
assert( gamma_move(board, 7, 90, 0) == 0 );
assert( gamma_move(board, 8, 11, 0) == 0 );
assert( gamma_move(board, 8, 1, 44) == 1 );
assert( gamma_move(board, 1, 16, 1) == 0 );
assert( gamma_move(board, 1, 1, 54) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_free_fields(board, 1) == 92 );
assert( gamma_move(board, 2, 33, 1) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 3, 27, 1) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 5, 47, 0) == 0 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_free_fields(board, 5) == 91 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 97, 0) == 0 );
assert( gamma_move(board, 6, 1, 75) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 72, 1) == 0 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_move(board, 8, 1, 44) == 0 );
assert( gamma_busy_fields(board, 8) == 15 );
assert( gamma_move(board, 1, 51, 0) == 0 );
assert( gamma_free_fields(board, 1) == 90 );
assert( gamma_move(board, 2, 91, 0) == 0 );
assert( gamma_move(board, 2, 0, 70) == 0 );
assert( gamma_move(board, 4, 69, 0) == 0 );
assert( gamma_move(board, 5, 71, 0) == 0 );
assert( gamma_move(board, 5, 1, 31) == 1 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 7, 97, 0) == 0 );
assert( gamma_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 4, 0, 90) == 1 );
assert( gamma_move(board, 5, 0, 35) == 1 );
assert( gamma_move(board, 5, 1, 82) == 0 );
assert( gamma_move(board, 6, 32, 0) == 0 );
assert( gamma_move(board, 6, 1, 75) == 0 );
assert( gamma_move(board, 7, 42, 1) == 0 );
assert( gamma_move(board, 7, 1, 75) == 0 );
assert( gamma_busy_fields(board, 7) == 13 );
assert( gamma_move(board, 8, 97, 0) == 0 );
assert( gamma_move(board, 8, 1, 72) == 1 );
assert( gamma_free_fields(board, 8) == 86 );


char* board514325320 = gamma_board(board);
assert( board514325320 != NULL );
assert( strcmp(board514325320, 
"5.\n"
"..\n"
".6\n"
".4\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"..\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"38\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"5.\n"
".8\n"
"3.\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"6.\n"
".4\n"
".5\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
".7\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
"54\n"
"..\n"
"2.\n"
".2\n"
"4.\n"
"4.\n"
"7.\n") == 0);
free(board514325320);
board514325320 = NULL;
assert( gamma_move(board, 1, 33, 1) == 0 );
assert( gamma_move(board, 3, 100, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 18 );
assert( gamma_move(board, 6, 0, 21) == 0 );
assert( gamma_move(board, 6, 0, 82) == 0 );
assert( gamma_move(board, 7, 1, 23) == 0 );
assert( gamma_move(board, 7, 0, 53) == 0 );
assert( gamma_move(board, 8, 28, 0) == 0 );
assert( gamma_move(board, 8, 1, 6) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );


char* board418028394 = gamma_board(board);
assert( board418028394 != NULL );
assert( strcmp(board418028394, 
"5.\n"
"..\n"
".6\n"
".4\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"..\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"38\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"5.\n"
".8\n"
"3.\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"6.\n"
".4\n"
".5\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
".7\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
"54\n"
"..\n"
"2.\n"
".2\n"
"4.\n"
"4.\n"
"7.\n") == 0);
free(board418028394);
board418028394 = NULL;
assert( gamma_move(board, 1, 0, 32) == 1 );
assert( gamma_move(board, 1, 1, 92) == 0 );
assert( gamma_busy_fields(board, 1) == 17 );
assert( gamma_move(board, 3, 40, 1) == 0 );
assert( gamma_free_fields(board, 3) == 85 );
assert( gamma_move(board, 5, 84, 1) == 0 );
assert( gamma_move(board, 5, 0, 5) == 1 );
assert( gamma_move(board, 6, 0, 39) == 0 );
assert( gamma_move(board, 6, 0, 82) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 51, 0) == 0 );
assert( gamma_move(board, 7, 0, 60) == 0 );
assert( gamma_move(board, 8, 86, 0) == 0 );
assert( gamma_move(board, 1, 51, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 69, 0) == 0 );
assert( gamma_move(board, 3, 1, 25) == 0 );
assert( gamma_move(board, 4, 100, 1) == 0 );
assert( gamma_move(board, 5, 84, 1) == 0 );
assert( gamma_move(board, 5, 1, 99) == 0 );
assert( gamma_move(board, 6, 1, 53) == 0 );
assert( gamma_move(board, 7, 16, 0) == 0 );
assert( gamma_move(board, 7, 1, 24) == 0 );
assert( gamma_move(board, 8, 1, 25) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 100, 1) == 0 );
assert( gamma_move(board, 2, 33, 1) == 0 );
assert( gamma_move(board, 2, 1, 100) == 1 );
assert( gamma_busy_fields(board, 2) == 14 );
assert( gamma_move(board, 3, 41, 0) == 0 );
assert( gamma_move(board, 4, 42, 0) == 0 );
assert( gamma_move(board, 5, 86, 1) == 0 );
assert( gamma_free_fields(board, 5) == 83 );
assert( gamma_move(board, 6, 22, 0) == 0 );
assert( gamma_move(board, 6, 1, 47) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 63, 0) == 0 );
assert( gamma_move(board, 8, 45, 0) == 0 );
assert( gamma_free_fields(board, 8) == 83 );
assert( gamma_move(board, 1, 73, 0) == 0 );
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 2, 1, 43) == 0 );
assert( gamma_busy_fields(board, 2) == 14 );


char* board952977353 = gamma_board(board);
assert( board952977353 != NULL );
assert( strcmp(board952977353, 
"5.\n"
".2\n"
".6\n"
".4\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"..\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"38\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"5.\n"
".8\n"
"3.\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"6.\n"
"14\n"
".5\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
".7\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
"54\n"
"5.\n"
"2.\n"
".2\n"
"4.\n"
"4.\n"
"7.\n") == 0);
free(board952977353);
board952977353 = NULL;
assert( gamma_move(board, 3, 65, 1) == 0 );
assert( gamma_move(board, 3, 1, 33) == 1 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 5, 1, 44) == 0 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 6, 46, 0) == 0 );
assert( gamma_move(board, 6, 0, 23) == 1 );
assert( gamma_move(board, 7, 0, 1) == 0 );
assert( gamma_move(board, 7, 1, 45) == 0 );
assert( gamma_move(board, 8, 4, 1) == 0 );
assert( gamma_move(board, 8, 0, 3) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 0, 38) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 0, 86) == 1 );


char* board612510213 = gamma_board(board);
assert( board612510213 != NULL );
assert( strcmp(board612510213, 
"5.\n"
".2\n"
".6\n"
".4\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"2.\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"38\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"5.\n"
".8\n"
"3.\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"63\n"
"14\n"
".5\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
"67\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
"54\n"
"5.\n"
"2.\n"
"82\n"
"4.\n"
"4.\n"
"7.\n") == 0);
free(board612510213);
board612510213 = NULL;
assert( gamma_move(board, 3, 98, 0) == 0 );
assert( gamma_free_fields(board, 3) == 79 );
assert( gamma_move(board, 4, 97, 0) == 0 );
assert( gamma_golden_move(board, 4, 75, 0) == 0 );
assert( gamma_move(board, 5, 68, 0) == 0 );
assert( gamma_move(board, 5, 1, 64) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 7, 99, 0) == 0 );
assert( gamma_move(board, 8, 34, 1) == 0 );


char* board172304672 = gamma_board(board);
assert( board172304672 != NULL );
assert( strcmp(board172304672, 
"5.\n"
".2\n"
".6\n"
".4\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"2.\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"38\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"55\n"
".8\n"
"3.\n"
"5.\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"63\n"
"14\n"
".5\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
"67\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
"54\n"
"5.\n"
"2.\n"
"82\n"
"4.\n"
"4.\n"
"7.\n") == 0);
free(board172304672);
board172304672 = NULL;
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 1, 52) == 0 );
assert( gamma_move(board, 2, 71, 0) == 0 );
assert( gamma_move(board, 2, 0, 21) == 0 );
assert( gamma_move(board, 3, 76, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 74, 1) == 0 );
assert( gamma_move(board, 4, 1, 61) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 30) == 0 );
assert( gamma_move(board, 6, 0, 64) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );


char* board777198685 = gamma_board(board);
assert( board777198685 != NULL );
assert( strcmp(board777198685, 
"5.\n"
".2\n"
".6\n"
".4\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
".5\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"2.\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
".4\n"
"38\n"
".4\n"
"1.\n"
"..\n"
"..\n"
"76\n"
".1\n"
"..\n"
"55\n"
".8\n"
"3.\n"
"54\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"63\n"
"14\n"
".5\n"
".7\n"
"2.\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
"67\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"8.\n"
".6\n"
"34\n"
".5\n"
"54\n"
"5.\n"
"2.\n"
"82\n"
"4.\n"
"4.\n"
"7.\n") == 0);
free(board777198685);
board777198685 = NULL;
assert( gamma_move(board, 8, 99, 0) == 0 );
assert( gamma_move(board, 8, 0, 98) == 1 );
assert( gamma_busy_fields(board, 8) == 18 );
assert( gamma_move(board, 2, 86, 1) == 0 );
assert( gamma_move(board, 2, 0, 86) == 0 );
assert( gamma_move(board, 3, 101, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 1, 59) == 0 );
assert( gamma_move(board, 4, 0, 77) == 0 );
assert( gamma_free_fields(board, 4) == 76 );
assert( gamma_move(board, 5, 16, 1) == 0 );
assert( gamma_move(board, 6, 0, 1) == 0 );
assert( gamma_free_fields(board, 6) == 76 );
assert( gamma_move(board, 7, 1, 42) == 1 );
assert( gamma_move(board, 8, 57, 1) == 0 );
assert( gamma_move(board, 8, 1, 29) == 1 );
assert( gamma_golden_move(board, 8, 25, 1) == 0 );
assert( gamma_move(board, 1, 38, 1) == 0 );
assert( gamma_move(board, 1, 0, 52) == 0 );
assert( gamma_move(board, 2, 0, 93) == 0 );
assert( gamma_move(board, 3, 58, 0) == 0 );
assert( gamma_move(board, 4, 0, 73) == 1 );
assert( gamma_move(board, 4, 0, 37) == 0 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_move(board, 6, 25, 0) == 0 );
assert( gamma_move(board, 7, 27, 0) == 0 );
assert( gamma_move(board, 8, 97, 1) == 0 );
assert( gamma_move(board, 1, 30, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 28, 0) == 0 );
assert( gamma_golden_move(board, 2, 75, 0) == 0 );
assert( gamma_move(board, 3, 97, 1) == 0 );
assert( gamma_move(board, 3, 0, 21) == 0 );
assert( gamma_move(board, 4, 1, 4) == 1 );
assert( gamma_golden_move(board, 4, 63, 1) == 0 );
assert( gamma_move(board, 5, 0, 30) == 1 );
assert( gamma_move(board, 6, 41, 0) == 0 );
assert( gamma_move(board, 7, 0, 99) == 1 );
assert( gamma_move(board, 8, 1, 54) == 0 );
assert( gamma_move(board, 1, 1, 59) == 0 );
assert( gamma_move(board, 2, 65, 0) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 5, 0, 36) == 0 );
assert( gamma_move(board, 5, 0, 69) == 1 );
assert( gamma_free_fields(board, 5) == 68 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 66, 0) == 0 );
assert( gamma_move(board, 7, 1, 47) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_free_fields(board, 7) == 68 );
assert( gamma_move(board, 8, 1, 21) == 0 );
assert( gamma_free_fields(board, 8) == 68 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 1, 71) == 0 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_move(board, 2, 1, 65) == 1 );
assert( gamma_move(board, 3, 1, 18) == 0 );
assert( gamma_move(board, 3, 0, 91) == 1 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 0, 39) == 0 );
assert( gamma_move(board, 6, 46, 0) == 0 );
assert( gamma_golden_move(board, 6, 79, 1) == 0 );
assert( gamma_move(board, 7, 17, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 62, 1) == 0 );
assert( gamma_move(board, 8, 1, 10) == 1 );
assert( gamma_golden_move(board, 8, 83, 1) == 0 );


char* board803097883 = gamma_board(board);
assert( board803097883 != NULL );
assert( strcmp(board803097883, 
"5.\n"
".2\n"
"76\n"
"84\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
"35\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"2.\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
"44\n"
"38\n"
".4\n"
"1.\n"
"5.\n"
"..\n"
"76\n"
".1\n"
".2\n"
"55\n"
".8\n"
"3.\n"
"54\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
".7\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"63\n"
"14\n"
".5\n"
"57\n"
"28\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
"67\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"88\n"
".6\n"
"34\n"
".5\n"
"54\n"
"5.\n"
"24\n"
"82\n"
"4.\n"
"45\n"
"7.\n") == 0);
free(board803097883);
board803097883 = NULL;
assert( gamma_move(board, 1, 1, 71) == 0 );


char* board886610816 = gamma_board(board);
assert( board886610816 != NULL );
assert( strcmp(board886610816, 
"5.\n"
".2\n"
"76\n"
"84\n"
"..\n"
"..\n"
"26\n"
"58\n"
"8.\n"
".8\n"
"35\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"2.\n"
"82\n"
"8.\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
"44\n"
"38\n"
".4\n"
"1.\n"
"5.\n"
"..\n"
"76\n"
".1\n"
".2\n"
"55\n"
".8\n"
"3.\n"
"54\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
".1\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
".7\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"63\n"
"14\n"
".5\n"
"57\n"
"28\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
"67\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"88\n"
".6\n"
"34\n"
".5\n"
"54\n"
"5.\n"
"24\n"
"82\n"
"4.\n"
"45\n"
"7.\n") == 0);
free(board886610816);
board886610816 = NULL;
assert( gamma_move(board, 2, 16, 0) == 0 );
assert( gamma_move(board, 2, 0, 49) == 1 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_move(board, 4, 0, 79) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 101, 0) == 0 );
assert( gamma_move(board, 5, 1, 98) == 0 );
assert( gamma_move(board, 5, 1, 94) == 0 );
assert( gamma_busy_fields(board, 5) == 23 );
assert( gamma_move(board, 6, 43, 0) == 0 );
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_move(board, 7, 17, 0) == 0 );
assert( gamma_move(board, 8, 5, 1) == 0 );
assert( gamma_move(board, 1, 1, 29) == 0 );
assert( gamma_move(board, 1, 0, 88) == 0 );
assert( gamma_move(board, 2, 68, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 1, 84) == 1 );
assert( gamma_golden_move(board, 3, 90, 0) == 0 );
assert( gamma_move(board, 4, 65, 0) == 0 );
assert( gamma_move(board, 5, 1, 93) == 1 );


char* board497679517 = gamma_board(board);
assert( board497679517 != NULL );
assert( strcmp(board497679517, 
"5.\n"
".2\n"
"76\n"
"84\n"
"..\n"
"..\n"
"26\n"
"58\n"
"85\n"
".8\n"
"35\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"2.\n"
"82\n"
"83\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
"44\n"
"38\n"
".4\n"
"1.\n"
"5.\n"
"..\n"
"76\n"
".1\n"
".2\n"
"55\n"
".8\n"
"3.\n"
"54\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
"21\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
".7\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"63\n"
"14\n"
".5\n"
"57\n"
"28\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
"67\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"88\n"
".6\n"
"34\n"
".5\n"
"54\n"
"5.\n"
"24\n"
"82\n"
"4.\n"
"45\n"
"7.\n") == 0);
free(board497679517);
board497679517 = NULL;
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_move(board, 7, 38, 1) == 0 );
assert( gamma_move(board, 7, 1, 52) == 0 );
assert( gamma_move(board, 8, 0, 34) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_busy_fields(board, 8) == 20 );
assert( gamma_move(board, 1, 27, 0) == 0 );
assert( gamma_move(board, 2, 39, 1) == 0 );
assert( gamma_move(board, 2, 0, 38) == 0 );
assert( gamma_move(board, 3, 1, 21) == 0 );
assert( gamma_move(board, 3, 0, 7) == 1 );


char* board852571714 = gamma_board(board);
assert( board852571714 != NULL );
assert( strcmp(board852571714, 
"5.\n"
".2\n"
"76\n"
"84\n"
"..\n"
"..\n"
"26\n"
"58\n"
"85\n"
".8\n"
"35\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"2.\n"
"82\n"
"83\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
"44\n"
"38\n"
".4\n"
"1.\n"
"5.\n"
"..\n"
"76\n"
".1\n"
".2\n"
"55\n"
".8\n"
"3.\n"
"54\n"
"71\n"
"62\n"
"..\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
"21\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
".7\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"63\n"
"14\n"
".5\n"
"57\n"
"28\n"
".1\n"
"..\n"
"55\n"
".4\n"
"36\n"
"67\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"88\n"
".6\n"
"34\n"
"35\n"
"54\n"
"5.\n"
"24\n"
"82\n"
"4.\n"
"45\n"
"7.\n") == 0);
free(board852571714);
board852571714 = NULL;
assert( gamma_move(board, 4, 1, 46) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 5, 0, 49) == 0 );
assert( gamma_move(board, 6, 1, 93) == 0 );
assert( gamma_move(board, 7, 80, 0) == 0 );
assert( gamma_move(board, 7, 0, 13) == 0 );
assert( gamma_move(board, 8, 17, 1) == 0 );
assert( gamma_move(board, 1, 0, 27) == 1 );
assert( gamma_move(board, 1, 0, 100) == 1 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 2, 0, 84) == 0 );
assert( gamma_move(board, 3, 101, 1) == 0 );
assert( gamma_move(board, 3, 1, 45) == 0 );
assert( gamma_free_fields(board, 3) == 59 );
assert( gamma_move(board, 4, 16, 1) == 0 );
assert( gamma_move(board, 4, 0, 58) == 1 );


char* board919535606 = gamma_board(board);
assert( board919535606 != NULL );
assert( strcmp(board919535606, 
"5.\n"
"12\n"
"76\n"
"84\n"
"..\n"
"..\n"
"26\n"
"58\n"
"85\n"
".8\n"
"35\n"
"4.\n"
"85\n"
"32\n"
"57\n"
"2.\n"
"82\n"
"83\n"
".6\n"
"14\n"
"31\n"
".7\n"
"35\n"
"34\n"
"2.\n"
"..\n"
"78\n"
"4.\n"
"44\n"
"38\n"
".4\n"
"1.\n"
"5.\n"
"..\n"
"76\n"
".1\n"
".2\n"
"55\n"
".8\n"
"3.\n"
"54\n"
"71\n"
"62\n"
"4.\n"
"1.\n"
"8.\n"
"62\n"
"15\n"
"83\n"
"78\n"
"..\n"
"13\n"
"21\n"
"2.\n"
".5\n"
".7\n"
".5\n"
"78\n"
".8\n"
".7\n"
"..\n"
"2.\n"
"6.\n"
"1.\n"
"11\n"
"18\n"
"55\n"
"6.\n"
"63\n"
"14\n"
".5\n"
"57\n"
"28\n"
".1\n"
"1.\n"
"55\n"
".4\n"
"36\n"
"67\n"
"..\n"
"42\n"
"71\n"
"16\n"
"63\n"
"..\n"
"..\n"
".3\n"
"42\n"
"74\n"
"4.\n"
"..\n"
"88\n"
".6\n"
"34\n"
"35\n"
"54\n"
"5.\n"
"24\n"
"82\n"
"4.\n"
"45\n"
"7.\n") == 0);
free(board919535606);
board919535606 = NULL;
assert( gamma_move(board, 5, 16, 0) == 0 );
assert( gamma_move(board, 5, 1, 58) == 1 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_move(board, 8, 1, 96) == 1 );
assert( gamma_busy_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 1, 56) == 1 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 3, 38, 1) == 0 );
assert( gamma_move(board, 3, 1, 19) == 0 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 4, 1, 91) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 83, 0) == 0 );
assert( gamma_move(board, 6, 66, 0) == 0 );
assert( gamma_move(board, 7, 31, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 8, 0, 3) == 0 );
assert( gamma_move(board, 8, 0, 46) == 1 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 63, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 3, 0, 97) == 1 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 0, 56) == 0 );
assert( gamma_move(board, 5, 80, 0) == 0 );
assert( gamma_move(board, 5, 1, 45) == 0 );
assert( gamma_move(board, 6, 22, 1) == 0 );
assert( gamma_move(board, 7, 0, 29) == 0 );
assert( gamma_free_fields(board, 7) == 52 );
assert( gamma_move(board, 8, 0, 83) == 1 );
assert( gamma_move(board, 8, 1, 87) == 0 );
assert( gamma_move(board, 1, 68, 0) == 0 );
assert( gamma_move(board, 2, 0, 34) == 0 );
assert( gamma_move(board, 3, 0, 85) == 0 );
assert( gamma_move(board, 4, 0, 29) == 0 );
assert( gamma_move(board, 5, 69, 1) == 0 );
assert( gamma_move(board, 5, 1, 27) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 66, 0) == 0 );
assert( gamma_free_fields(board, 6) == 50 );
assert( gamma_golden_move(board, 6, 30, 1) == 0 );
assert( gamma_move(board, 7, 57, 1) == 0 );
assert( gamma_move(board, 8, 76, 0) == 0 );
assert( gamma_free_fields(board, 8) == 50 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 2, 101, 1) == 0 );
assert( gamma_move(board, 3, 1, 28) == 0 );
assert( gamma_move(board, 4, 77, 1) == 0 );
assert( gamma_move(board, 5, 0, 59) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 1, 10) == 0 );
assert( gamma_move(board, 7, 86, 1) == 0 );
assert( gamma_move(board, 8, 65, 0) == 0 );


gamma_delete(board);

    return 0;
}
