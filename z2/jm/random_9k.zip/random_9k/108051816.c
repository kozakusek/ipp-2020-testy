#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 108051816
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(20, 24, 8, 65);
assert( board != NULL );


assert( gamma_move(board, 1, 5, 11) == 1 );
assert( gamma_move(board, 2, 19, 3) == 1 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 0 );
assert( gamma_move(board, 5, 7, 16) == 1 );
assert( gamma_move(board, 5, 6, 10) == 1 );


char* board977222173 = gamma_board(board);
assert( board977222173 != NULL );
assert( strcmp(board977222173, 
"....................\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
".......5............\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
".....1..............\n"
"3.....5.............\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
"...3................\n"
"...................2\n"
"....................\n"
"....................\n"
"....................\n") == 0);
free(board977222173);
board977222173 = NULL;
assert( gamma_move(board, 7, 15, 2) == 1 );
assert( gamma_move(board, 7, 8, 19) == 1 );
assert( gamma_busy_fields(board, 8) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );


char* board208422416 = gamma_board(board);
assert( board208422416 != NULL );
assert( strcmp(board208422416, 
"....................\n"
"....................\n"
"....................\n"
"....................\n"
"........7...........\n"
"....................\n"
"....................\n"
".......5............\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
".....1..............\n"
"3.....5.............\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
"....................\n"
"...3................\n"
"...................2\n"
"...............7....\n"
"....................\n"
"....................\n") == 0);
free(board208422416);
board208422416 = NULL;
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 3, 4, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 18, 11) == 1 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 6, 14, 0) == 1 );
assert( gamma_move(board, 8, 2, 12) == 1 );
assert( gamma_free_fields(board, 8) == 466 );
assert( gamma_free_fields(board, 1) == 466 );
assert( gamma_move(board, 2, 0, 23) == 1 );
assert( gamma_move(board, 3, 23, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 0 );
assert( gamma_move(board, 5, 15, 1) == 1 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_move(board, 6, 18, 5) == 1 );
assert( gamma_move(board, 7, 15, 4) == 1 );


char* board315184882 = gamma_board(board);
assert( board315184882 != NULL );
assert( strcmp(board315184882, 
"2...................\n"
"....................\n"
"....................\n"
"....................\n"
"........7...........\n"
"....................\n"
"....................\n"
".......5............\n"
"....................\n"
"....................\n"
"....................\n"
"..8.................\n"
".....1............5.\n"
"3.....5.............\n"
"....................\n"
"....................\n"
"....................\n"
"2...................\n"
"....3.............6.\n"
"...3...........7....\n"
"...................2\n"
"...............7....\n"
"...............5....\n"
".....5........6.....\n") == 0);
free(board315184882);
board315184882 = NULL;
assert( gamma_move(board, 8, 23, 18) == 0 );
assert( gamma_move(board, 1, 14, 14) == 1 );
assert( gamma_move(board, 1, 15, 22) == 1 );
assert( gamma_free_fields(board, 1) == 460 );
assert( gamma_move(board, 2, 20, 10) == 0 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_move(board, 3, 3, 3) == 1 );


char* board880544498 = gamma_board(board);
assert( board880544498 != NULL );
assert( strcmp(board880544498, 
"2...................\n"
"...............1....\n"
"....................\n"
"....................\n"
"........7...........\n"
"....................\n"
"....................\n"
".......5............\n"
"....................\n"
"..............1.....\n"
"....................\n"
"..8.................\n"
".....1............5.\n"
"3.....5.............\n"
"....................\n"
"....................\n"
"....................\n"
"2...................\n"
"....3.............6.\n"
"...3...........7....\n"
"...3...............2\n"
"...............7....\n"
"......3........5....\n"
".....5........6.....\n") == 0);
free(board880544498);
board880544498 = NULL;
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 5, 5, 12) == 1 );
assert( gamma_free_fields(board, 5) == 456 );
assert( gamma_move(board, 6, 5, 17) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 5, 7) == 1 );


char* board128212740 = gamma_board(board);
assert( board128212740 != NULL );
assert( strcmp(board128212740, 
"2...................\n"
"...............1....\n"
"....................\n"
"....................\n"
"........7...........\n"
"....................\n"
".....6..............\n"
".......5............\n"
"....................\n"
"..............1.....\n"
"....................\n"
"..8..5..............\n"
".....1............5.\n"
"3.....5.............\n"
"....................\n"
"....................\n"
".....7..............\n"
"2...................\n"
"....3.............6.\n"
"...3...........7....\n"
"..43...............2\n"
"...............7....\n"
"......3........5....\n"
".....5........6.....\n") == 0);
free(board128212740);
board128212740 = NULL;
assert( gamma_move(board, 8, 11, 10) == 1 );
assert( gamma_move(board, 8, 5, 17) == 0 );
assert( gamma_move(board, 1, 5, 22) == 1 );
assert( gamma_move(board, 2, 19, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 19, 10) == 1 );
assert( gamma_move(board, 4, 13, 21) == 1 );
assert( gamma_move(board, 5, 17, 11) == 1 );
assert( gamma_move(board, 5, 1, 4) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 16, 15) == 1 );
assert( gamma_move(board, 8, 14, 4) == 1 );
assert( gamma_move(board, 8, 3, 23) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 1, 14, 17) == 1 );
assert( gamma_free_fields(board, 1) == 442 );
assert( gamma_move(board, 2, 16, 16) == 1 );
assert( gamma_move(board, 3, 16, 4) == 1 );


char* board778131957 = gamma_board(board);
assert( board778131957 != NULL );
assert( strcmp(board778131957, 
"2..8................\n"
".....1.........1....\n"
".............4......\n"
"....................\n"
"........7...........\n"
"....................\n"
".....6........1.....\n"
".......5........2...\n"
"................6...\n"
"..............1.....\n"
"....................\n"
"..8..5..............\n"
".....1...........55.\n"
"3.....5....8.......3\n"
"....................\n"
"....................\n"
".....7..............\n"
"2...................\n"
"....3.............6.\n"
".5.3..........873...\n"
"..43...............2\n"
"..1............7...2\n"
"......3........5....\n"
".....5........6.....\n") == 0);
free(board778131957);
board778131957 = NULL;
assert( gamma_move(board, 4, 6, 19) == 1 );
assert( gamma_move(board, 5, 2, 16) == 1 );
assert( gamma_move(board, 6, 20, 5) == 0 );
assert( gamma_move(board, 7, 14, 15) == 1 );


char* board571843296 = gamma_board(board);
assert( board571843296 != NULL );
assert( strcmp(board571843296, 
"2..8................\n"
".....1.........1....\n"
".............4......\n"
"....................\n"
"......4.7...........\n"
"....................\n"
".....6........1.....\n"
"..5....5........2...\n"
"..............7.6...\n"
"..............1.....\n"
"....................\n"
"..8..5..............\n"
".....1...........55.\n"
"3.....5....8.......3\n"
"....................\n"
"....................\n"
".....7..............\n"
"2...................\n"
"....3.............6.\n"
".5.3..........873...\n"
"..43...............2\n"
"..1............7...2\n"
"......3........5....\n"
".....5........6.....\n") == 0);
free(board571843296);
board571843296 = NULL;
assert( gamma_move(board, 8, 7, 11) == 1 );
assert( gamma_move(board, 1, 14, 10) == 1 );
assert( gamma_move(board, 2, 13, 10) == 1 );


char* board407714274 = gamma_board(board);
assert( board407714274 != NULL );
assert( strcmp(board407714274, 
"2..8................\n"
".....1.........1....\n"
".............4......\n"
"....................\n"
"......4.7...........\n"
"....................\n"
".....6........1.....\n"
"..5....5........2...\n"
"..............7.6...\n"
"..............1.....\n"
"....................\n"
"..8..5..............\n"
".....1.8.........55.\n"
"3.....5....8.21....3\n"
"....................\n"
"....................\n"
".....7..............\n"
"2...................\n"
"....3.............6.\n"
".5.3..........873...\n"
"..43...............2\n"
"..1............7...2\n"
"......3........5....\n"
".....5........6.....\n") == 0);
free(board407714274);
board407714274 = NULL;
assert( gamma_move(board, 3, 3, 11) == 1 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 4, 13, 16) == 1 );
assert( gamma_move(board, 5, 4, 13) == 1 );
assert( gamma_move(board, 5, 11, 11) == 1 );
assert( gamma_free_fields(board, 5) == 429 );
assert( gamma_move(board, 6, 16, 12) == 1 );
assert( gamma_move(board, 7, 19, 17) == 1 );
assert( gamma_move(board, 7, 4, 17) == 1 );
assert( gamma_move(board, 8, 21, 19) == 0 );
assert( gamma_move(board, 8, 3, 23) == 0 );
assert( gamma_move(board, 2, 12, 0) == 1 );
assert( gamma_move(board, 2, 3, 5) == 1 );


char* board961697667 = gamma_board(board);
assert( board961697667 != NULL );
assert( strcmp(board961697667, 
"2..8................\n"
".....1.........1....\n"
".............4......\n"
"....................\n"
"......4.7...........\n"
"....................\n"
"....76........1....7\n"
"..5....5.....4..2...\n"
"..............7.6...\n"
"..............1.....\n"
"....5...............\n"
"..8..5..........6...\n"
"...3.1.8...5.....55.\n"
"3.....5....8.21....3\n"
"..4.................\n"
"....................\n"
".....7..............\n"
"2...................\n"
"...23.............6.\n"
".5.3..........873...\n"
"..43...............2\n"
"..1............7...2\n"
"......3........5....\n"
".....5......2.6.....\n") == 0);
free(board961697667);
board961697667 = NULL;
assert( gamma_move(board, 3, 2, 19) == 1 );
assert( gamma_move(board, 4, 8, 18) == 1 );
assert( gamma_move(board, 4, 14, 14) == 0 );
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_golden_move(board, 6, 12, 5) == 0 );
assert( gamma_move(board, 7, 6, 17) == 1 );
assert( gamma_move(board, 7, 5, 0) == 0 );
assert( gamma_free_fields(board, 7) == 420 );
assert( gamma_move(board, 8, 11, 1) == 1 );
assert( gamma_move(board, 8, 12, 18) == 1 );
assert( gamma_busy_fields(board, 8) == 7 );
assert( gamma_move(board, 1, 12, 0) == 0 );
assert( gamma_move(board, 1, 2, 17) == 1 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_move(board, 5, 15, 13) == 1 );
assert( gamma_move(board, 5, 17, 12) == 1 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_golden_move(board, 5, 17, 6) == 0 );
assert( gamma_move(board, 6, 4, 18) == 1 );
assert( gamma_move(board, 7, 3, 3) == 0 );
assert( gamma_move(board, 7, 18, 10) == 1 );
assert( gamma_move(board, 8, 10, 12) == 1 );
assert( gamma_move(board, 1, 6, 14) == 1 );
assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 3, 19) == 1 );
assert( gamma_move(board, 3, 20, 1) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 4, 14, 1) == 1 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 7, 7) == 1 );
assert( gamma_move(board, 6, 9, 16) == 1 );
assert( gamma_move(board, 7, 20, 19) == 0 );
assert( gamma_move(board, 7, 3, 22) == 1 );
assert( gamma_free_fields(board, 7) == 402 );
assert( gamma_move(board, 8, 16, 3) == 1 );
assert( gamma_move(board, 8, 12, 9) == 1 );
assert( gamma_move(board, 1, 2, 14) == 1 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 13, 5) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 5, 0, 17) == 1 );
assert( gamma_move(board, 5, 2, 22) == 1 );
assert( gamma_move(board, 6, 6, 17) == 0 );
assert( gamma_free_fields(board, 6) == 395 );
assert( gamma_move(board, 7, 15, 0) == 1 );
assert( gamma_move(board, 7, 17, 6) == 1 );
assert( gamma_move(board, 8, 1, 15) == 1 );
assert( gamma_busy_fields(board, 8) == 11 );
assert( gamma_golden_move(board, 8, 4, 1) == 0 );
assert( gamma_move(board, 1, 20, 3) == 0 );
assert( gamma_move(board, 2, 16, 10) == 1 );
assert( gamma_move(board, 2, 19, 19) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 8) == 1 );
assert( gamma_move(board, 5, 17, 12) == 0 );
assert( gamma_move(board, 5, 5, 4) == 1 );
assert( gamma_move(board, 6, 15, 5) == 1 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_golden_move(board, 8, 11, 11) == 1 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_free_fields(board, 1) == 386 );
assert( gamma_move(board, 2, 4, 10) == 1 );
assert( gamma_move(board, 2, 19, 18) == 1 );


char* board283972050 = gamma_board(board);
assert( board283972050 != NULL );
assert( strcmp(board283972050, 
"2..8................\n"
"..57.1.........1....\n"
".............4......\n"
"....................\n"
"..32..4.7..........2\n"
"....6...4...8......2\n"
"5.1.767.......1....7\n"
"..5....5.6...4..2...\n"
".8............7.6...\n"
"..1...1.......1.....\n"
"....5..........5....\n"
"..8..5....8.....65..\n"
"...3.1.8...8.....55.\n"
"3...2.5....8.21.2.73\n"
"..4....1.3..8.......\n"
".5.......4..........\n"
"....47.6............\n"
"2.3..............7..\n"
"...23........4.6..6.\n"
".5.3.5........873...\n"
"..43............8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"5....5......2.67....\n") == 0);
free(board283972050);
board283972050 = NULL;
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 3, 19, 2) == 0 );
assert( gamma_move(board, 4, 17, 12) == 0 );
assert( gamma_move(board, 4, 4, 15) == 1 );


char* board677801128 = gamma_board(board);
assert( board677801128 != NULL );
assert( strcmp(board677801128, 
"2..8................\n"
"..57.1.........1....\n"
".............4......\n"
"....................\n"
"..32..4.7..........2\n"
"....6...4...8......2\n"
"5.1.767.......1....7\n"
"..5....5.6...4..2...\n"
".8..4.........7.6...\n"
"..1...1.......1.....\n"
"....5..........5....\n"
"..8..5....8.....65..\n"
"...3.1.8...8.....55.\n"
"3..32.5....8.21.2.73\n"
"..4....1.3..8.......\n"
".5.......4..........\n"
"....47.6............\n"
"2.3..............7..\n"
"...23........4.6..6.\n"
".5.3.5........873...\n"
"..43............8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"5....5......2.67....\n") == 0);
free(board677801128);
board677801128 = NULL;
assert( gamma_move(board, 5, 4, 18) == 0 );
assert( gamma_free_fields(board, 5) == 382 );


char* board239233153 = gamma_board(board);
assert( board239233153 != NULL );
assert( strcmp(board239233153, 
"2..8................\n"
"..57.1.........1....\n"
".............4......\n"
"....................\n"
"..32..4.7..........2\n"
"....6...4...8......2\n"
"5.1.767.......1....7\n"
"..5....5.6...4..2...\n"
".8..4.........7.6...\n"
"..1...1.......1.....\n"
"....5..........5....\n"
"..8..5....8.....65..\n"
"...3.1.8...8.....55.\n"
"3..32.5....8.21.2.73\n"
"..4....1.3..8.......\n"
".5.......4..........\n"
"....47.6............\n"
"2.3..............7..\n"
"...23........4.6..6.\n"
".5.3.5........873...\n"
"..43............8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"5....5......2.67....\n") == 0);
free(board239233153);
board239233153 = NULL;
assert( gamma_move(board, 6, 17, 18) == 1 );
assert( gamma_move(board, 7, 16, 16) == 0 );
assert( gamma_move(board, 8, 3, 6) == 1 );
assert( gamma_move(board, 1, 18, 16) == 1 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_move(board, 3, 18, 14) == 1 );
assert( gamma_move(board, 3, 8, 18) == 0 );
assert( gamma_move(board, 4, 11, 0) == 1 );
assert( gamma_move(board, 4, 11, 12) == 1 );
assert( gamma_move(board, 5, 15, 18) == 1 );
assert( gamma_move(board, 6, 19, 5) == 1 );
assert( gamma_free_fields(board, 6) == 373 );
assert( gamma_move(board, 7, 14, 8) == 1 );
assert( gamma_move(board, 8, 10, 7) == 1 );
assert( gamma_move(board, 8, 11, 9) == 1 );
assert( gamma_move(board, 1, 11, 19) == 1 );
assert( gamma_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 17, 13) == 1 );
assert( gamma_move(board, 2, 11, 19) == 0 );
assert( gamma_free_fields(board, 2) == 368 );
assert( gamma_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 3, 0, 18) == 1 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_move(board, 5, 13, 13) == 1 );
assert( gamma_move(board, 5, 15, 4) == 0 );
assert( gamma_golden_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 14, 12) == 1 );
assert( gamma_move(board, 6, 8, 9) == 1 );
assert( gamma_move(board, 7, 1, 17) == 1 );
assert( gamma_move(board, 8, 4, 3) == 1 );
assert( gamma_move(board, 8, 11, 11) == 0 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 2, 22, 4) == 0 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 19) == 0 );
assert( gamma_move(board, 4, 0, 9) == 1 );


char* board573059760 = gamma_board(board);
assert( board573059760 != NULL );
assert( strcmp(board573059760, 
"2..8................\n"
"..57.1.........1....\n"
".............4......\n"
"....................\n"
"..32..4.7..1.......2\n"
"3...6...4...8..5.6.2\n"
"571.767.......1....7\n"
"..5....5.6...4..2.1.\n"
".8..4.........7.6...\n"
"..1...1.......1...3.\n"
"..1.5........5.5.2..\n"
"..8..5....84..6.65..\n"
"...3.1.8...8.....55.\n"
"32.32.5....8.21.2.73\n"
"4.4.2..163.88.......\n"
".5.......4....7.....\n"
"....47.6..8.........\n"
"2.38.............7..\n"
"...23........4.6..66\n"
".5.3.5........873...\n"
"..438...........8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"5....5.3...42.67....\n") == 0);
free(board573059760);
board573059760 = NULL;
assert( gamma_move(board, 5, 6, 15) == 1 );


char* board338109273 = gamma_board(board);
assert( board338109273 != NULL );
assert( strcmp(board338109273, 
"2..8................\n"
"..57.1.........1....\n"
".............4......\n"
"....................\n"
"..32..4.7..1.......2\n"
"3...6...4...8..5.6.2\n"
"571.767.......1....7\n"
"..5....5.6...4..2.1.\n"
".8..4.5.......7.6...\n"
"..1...1.......1...3.\n"
"..1.5........5.5.2..\n"
"..8..5....84..6.65..\n"
"...3.1.8...8.....55.\n"
"32.32.5....8.21.2.73\n"
"4.4.2..163.88.......\n"
".5.......4....7.....\n"
"....47.6..8.........\n"
"2.38.............7..\n"
"...23........4.6..66\n"
".5.3.5........873...\n"
"..438...........8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"5....5.3...42.67....\n") == 0);
free(board338109273);
board338109273 = NULL;
assert( gamma_move(board, 6, 16, 8) == 1 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 16, 14) == 1 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 8, 15, 8) == 1 );
assert( gamma_move(board, 8, 3, 0) == 1 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_move(board, 1, 3, 19) == 0 );
assert( gamma_move(board, 2, 0, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_free_fields(board, 3) == 351 );


char* board618167162 = gamma_board(board);
assert( board618167162 != NULL );
assert( strcmp(board618167162, 
"2..8................\n"
"..57.1.........1....\n"
".............4......\n"
"....................\n"
"..32..4.7..1.......2\n"
"3...6...4...8..5.6.2\n"
"571.767.......1....7\n"
"..5....5.6...4..2.1.\n"
".8..4.5.......7.6...\n"
"2.1...1.......1.7.3.\n"
"..1.5........5.5.2..\n"
"..8..5....84..6.65..\n"
"...3.1.8...8.....55.\n"
"32.32.5....8.21.2.73\n"
"414.2..163.88.......\n"
".5.......4....786...\n"
"....47.6..8.........\n"
"2.38.............7..\n"
"...23........4.6..66\n"
".5.3.5........873...\n"
"..438...........8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"5..8.5.3...42.67....\n") == 0);
free(board618167162);
board618167162 = NULL;
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_golden_move(board, 4, 14, 16) == 0 );


char* board345760543 = gamma_board(board);
assert( board345760543 != NULL );
assert( strcmp(board345760543, 
"2..8................\n"
"..57.1.........1....\n"
".............4......\n"
"....................\n"
"..32..4.7..1.......2\n"
"3...6...4...8..5.6.2\n"
"571.767.......1....7\n"
"..5....5.6...4..2.1.\n"
".8..4.5.......7.6...\n"
"2.1...1.......1.7.3.\n"
"..1.5........5.5.2..\n"
"..8..5....84..6.65..\n"
"...3.1.8...8.....55.\n"
"32.32.5....8.21.2.73\n"
"414.2..163.88.......\n"
".5.......4....786...\n"
"....47.6..8.........\n"
"2.38.............7..\n"
"...23........4.6..66\n"
".5.3.5........873...\n"
"..438...........8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"5..8.5.3...42.67....\n") == 0);
free(board345760543);
board345760543 = NULL;
assert( gamma_move(board, 5, 19, 19) == 0 );
assert( gamma_golden_move(board, 5, 3, 19) == 1 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 7, 17, 7) == 1 );
assert( gamma_busy_fields(board, 7) == 16 );
assert( gamma_move(board, 8, 19, 4) == 1 );
assert( gamma_move(board, 8, 3, 6) == 0 );
assert( gamma_move(board, 1, 19, 16) == 1 );


char* board993314668 = gamma_board(board);
assert( board993314668 != NULL );
assert( strcmp(board993314668, 
"2..8................\n"
"..57.1.........1....\n"
".............4......\n"
"....................\n"
"..35..4.7..1.......2\n"
"3...6...4...8..5.6.2\n"
"571.767.......1....7\n"
"..5....5.6...4..2.11\n"
".8..4.5.......7.6...\n"
"2.1...1.......1.7.3.\n"
"..1.5........5.5.2..\n"
"..8..5....84..6.65..\n"
"...3.1.8...8.....55.\n"
"32.32.5....8.21.2.73\n"
"414.2..163.88.......\n"
".5.......4....786...\n"
"....47.6..8......7..\n"
"2.38.............7..\n"
"...23........4.6..66\n"
".5.3.5........873..8\n"
"..438...........8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"5..8.5.3...42.67....\n") == 0);
free(board993314668);
board993314668 = NULL;
assert( gamma_move(board, 2, 0, 18) == 0 );
assert( gamma_move(board, 2, 17, 5) == 1 );
assert( gamma_move(board, 3, 18, 22) == 1 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 4, 17, 17) == 1 );
assert( gamma_move(board, 4, 5, 17) == 0 );
assert( gamma_move(board, 5, 22, 6) == 0 );
assert( gamma_free_fields(board, 5) == 345 );
assert( gamma_move(board, 6, 3, 12) == 1 );
assert( gamma_move(board, 6, 5, 23) == 1 );
assert( gamma_move(board, 7, 10, 9) == 1 );
assert( gamma_move(board, 7, 9, 7) == 1 );
assert( gamma_move(board, 8, 1, 0) == 1 );
assert( gamma_busy_fields(board, 8) == 20 );
assert( gamma_free_fields(board, 8) == 340 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 17, 17) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 19, 13) == 1 );
assert( gamma_move(board, 3, 7, 18) == 1 );
assert( gamma_move(board, 4, 20, 3) == 0 );
assert( gamma_move(board, 4, 11, 19) == 0 );
assert( gamma_move(board, 5, 23, 16) == 0 );
assert( gamma_busy_fields(board, 5) == 21 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_move(board, 6, 17, 6) == 0 );
assert( gamma_move(board, 7, 12, 13) == 1 );
assert( gamma_move(board, 8, 7, 14) == 1 );
assert( gamma_move(board, 1, 13, 7) == 1 );
assert( gamma_move(board, 1, 4, 19) == 1 );
assert( gamma_free_fields(board, 1) == 334 );
assert( gamma_move(board, 2, 6, 23) == 1 );
assert( gamma_move(board, 3, 20, 7) == 0 );
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 23, 9) == 0 );
assert( gamma_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 6, 4, 13) == 0 );
assert( gamma_move(board, 6, 9, 18) == 1 );
assert( gamma_move(board, 7, 1, 5) == 1 );
assert( gamma_move(board, 7, 8, 19) == 0 );


char* board413465492 = gamma_board(board);
assert( board413465492 != NULL );
assert( strcmp(board413465492, 
"2..8.62.............\n"
"..57.1.........1..3.\n"
".............4......\n"
"....................\n"
"..351.4.7..1.......2\n"
"3...6..346..8..5.6.2\n"
"571.767.......1..4.7\n"
"..5....5.6...4..2.11\n"
".8..4.5.......7.6...\n"
"2.1...18......1.7.3.\n"
"..1.5.......75.5.2.2\n"
"..86.5....84..6.65..\n"
"...3.1.8...8.....55.\n"
"32.32.5....8.21.2.73\n"
"414.2..163788.......\n"
".5..3....4....786...\n"
"....47.6.78..1...7..\n"
"2.38.............7..\n"
".7.23........4.6.266\n"
".5.3.5........873..8\n"
"..438...........8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"58.8.5.3...42.67....\n") == 0);
free(board413465492);
board413465492 = NULL;
assert( gamma_move(board, 8, 19, 6) == 1 );
assert( gamma_move(board, 1, 16, 13) == 1 );
assert( gamma_move(board, 1, 14, 11) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 16) == 0 );
assert( gamma_move(board, 3, 16, 17) == 1 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_golden_move(board, 3, 11, 11) == 1 );


char* board701863509 = gamma_board(board);
assert( board701863509 != NULL );
assert( strcmp(board701863509, 
"2..8.62.............\n"
"..57.1.........1..3.\n"
".............4......\n"
"....................\n"
"..351.4.7..1.......2\n"
"3...6..346..8..5.6.2\n"
"571.767.......1.34.7\n"
"..5....5.6...4..2.11\n"
".8..4.5.......7.6...\n"
"2.1...18......1.7.3.\n"
"..1.5.......75.512.2\n"
"..86.5....84..6.65..\n"
"...3.1.8...3..1..55.\n"
"32.32.5....8.21.2.73\n"
"414.2..163788.......\n"
".5..3....4....786...\n"
"....47.6.78..1...7..\n"
"2.38.............7.8\n"
".7.23........4.6.266\n"
".5.3.5........873..8\n"
"..438...........8..2\n"
"..1...2........7...2\n"
"......3....8..45....\n"
"58.8.5.3...42.67....\n") == 0);
free(board701863509);
board701863509 = NULL;
assert( gamma_move(board, 4, 18, 21) == 1 );
assert( gamma_free_fields(board, 5) == 325 );
assert( gamma_move(board, 6, 17, 0) == 1 );
assert( gamma_move(board, 6, 13, 5) == 0 );
assert( gamma_move(board, 7, 2, 9) == 0 );
assert( gamma_move(board, 8, 15, 12) == 1 );
assert( gamma_move(board, 2, 5, 16) == 1 );
assert( gamma_move(board, 2, 10, 11) == 1 );
assert( gamma_move(board, 3, 22, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 10) == 1 );
assert( gamma_busy_fields(board, 4) == 17 );
assert( gamma_move(board, 5, 7, 12) == 1 );
assert( gamma_move(board, 6, 14, 15) == 0 );
assert( gamma_move(board, 6, 19, 13) == 0 );
assert( gamma_move(board, 7, 17, 15) == 1 );
assert( gamma_move(board, 7, 18, 17) == 1 );
assert( gamma_move(board, 8, 0, 16) == 1 );
assert( gamma_move(board, 1, 5, 20) == 1 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 2, 6, 1) == 0 );
assert( gamma_move(board, 2, 4, 16) == 1 );
assert( gamma_move(board, 3, 11, 16) == 1 );
assert( gamma_move(board, 3, 19, 22) == 1 );
assert( gamma_move(board, 4, 18, 4) == 1 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 20, 9) == 0 );
assert( gamma_move(board, 6, 0, 2) == 1 );
assert( gamma_move(board, 7, 9, 2) == 1 );
assert( gamma_move(board, 7, 12, 7) == 1 );
assert( gamma_move(board, 8, 13, 18) == 1 );
assert( gamma_free_fields(board, 8) == 307 );
assert( gamma_move(board, 1, 1, 7) == 1 );
assert( gamma_move(board, 2, 14, 3) == 1 );
assert( gamma_move(board, 2, 16, 1) == 1 );
assert( gamma_move(board, 4, 11, 20) == 1 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 12, 16) == 1 );
assert( gamma_move(board, 6, 11, 9) == 0 );
assert( gamma_move(board, 6, 14, 19) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 22, 9) == 0 );
assert( gamma_move(board, 7, 12, 15) == 1 );
assert( gamma_move(board, 8, 0, 1) == 1 );
assert( gamma_golden_move(board, 8, 12, 14) == 0 );
assert( gamma_move(board, 1, 23, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 22 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_free_fields(board, 2) == 299 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 17) == 1 );
assert( gamma_move(board, 5, 5, 14) == 1 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 6, 6) == 1 );
assert( gamma_move(board, 7, 2, 17) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 4, 0) == 1 );
assert( gamma_move(board, 2, 21, 14) == 0 );
assert( gamma_move(board, 2, 7, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 26 );
assert( gamma_move(board, 3, 20, 16) == 0 );
assert( gamma_move(board, 3, 13, 13) == 0 );
assert( gamma_move(board, 4, 22, 10) == 0 );
assert( gamma_move(board, 4, 17, 23) == 1 );
assert( gamma_move(board, 5, 0, 13) == 1 );
assert( gamma_free_fields(board, 5) == 292 );
assert( gamma_golden_move(board, 5, 23, 0) == 0 );
assert( gamma_move(board, 6, 21, 16) == 0 );
assert( gamma_move(board, 6, 10, 7) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 14) == 0 );
assert( gamma_move(board, 8, 0, 20) == 1 );
assert( gamma_busy_fields(board, 8) == 26 );


char* board275307767 = gamma_board(board);
assert( board275307767 != NULL );
assert( strcmp(board275307767, 
"2..8.62..........4..\n"
"..57.1.........1..33\n"
".............4....4.\n"
"8....1.....4........\n"
"..351.4.7..1..6....2\n"
"3...6..346..88.5.6.2\n"
"571.767..4....1.3477\n"
"8.5.22.5.6.354..2.11\n"
".8..4.5.....7.7.67..\n"
"2.1..518......1.7.3.\n"
"5.1.5.......75.512.2\n"
"..86.5.5..84..6865..\n"
"...3.1.8..23..1..55.\n"
"32.32.5...48.21.2.73\n"
"414.2..163788.......\n"
".5..3....4....786...\n"
".1..47.6.78.71...7..\n"
"2.38..62.........7.8\n"
".7.23........4.6.266\n"
".5.3.5........873.48\n"
"..438.........2.8..2\n"
"6.1...2..7.....7...2\n"
"8.....3....8..452...\n"
"58.815.3...42.67.6..\n") == 0);
free(board275307767);
board275307767 = NULL;
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 21, 17) == 0 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 3, 8, 11) == 1 );
assert( gamma_move(board, 4, 15, 10) == 1 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 5, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 19, 0) == 1 );
assert( gamma_move(board, 6, 2, 16) == 0 );
assert( gamma_busy_fields(board, 6) == 22 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_move(board, 7, 3, 21) == 1 );
assert( gamma_move(board, 8, 4, 11) == 1 );
assert( gamma_move(board, 1, 18, 3) == 1 );
assert( gamma_move(board, 1, 14, 21) == 1 );
assert( gamma_move(board, 2, 3, 15) == 1 );
assert( gamma_move(board, 2, 5, 8) == 1 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_move(board, 3, 17, 22) == 1 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 15, 19) == 1 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 4, 15) == 0 );
assert( gamma_move(board, 6, 2, 15) == 1 );
assert( gamma_move(board, 7, 2, 3) == 0 );
assert( gamma_golden_move(board, 7, 11, 7) == 0 );
assert( gamma_move(board, 8, 11, 6) == 1 );
assert( gamma_move(board, 8, 19, 0) == 0 );
assert( gamma_move(board, 1, 2, 23) == 1 );
assert( gamma_free_fields(board, 1) == 275 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board203899815 = gamma_board(board);
assert( board203899815 != NULL );
assert( strcmp(board203899815, 
"2.18.62..........4..\n"
"..57.1.........1.333\n"
"...7.........41...4.\n"
"8....1.....4........\n"
"..351.4.7..1..64...2\n"
"3...6..346..88.5.6.2\n"
"571.767..4....1.3477\n"
"8.5.22.5.6.354..2.11\n"
".8624.5.....7.7.67..\n"
"2.1..518......1.7.3.\n"
"5.1.5.......75.512.2\n"
"..86.5.5..84..6865..\n"
"...381.83.23..1..55.\n"
"32.32.5...48.2142.73\n"
"414.2..163788.......\n"
".5..32...4....786...\n"
".1..4726.78.71...7..\n"
"2.38..62...8.....7.8\n"
".7.23........4.6.266\n"
".5.3.5........873.48\n"
"..438...3.....2.8.12\n"
"6.1...2..7.....7...2\n"
"8.....3....8..452...\n"
"58.815.3...42.67.6.6\n") == 0);
free(board203899815);
board203899815 = NULL;
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 2, 11, 13) == 1 );
assert( gamma_move(board, 3, 6, 12) == 1 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_move(board, 4, 1, 17) == 0 );
assert( gamma_move(board, 5, 4, 17) == 0 );
assert( gamma_move(board, 6, 5, 22) == 0 );
assert( gamma_busy_fields(board, 7) == 26 );
assert( gamma_move(board, 8, 19, 22) == 0 );
assert( gamma_move(board, 8, 13, 17) == 1 );
assert( gamma_move(board, 1, 6, 16) == 1 );
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 2, 8, 16) == 1 );
assert( gamma_move(board, 3, 22, 7) == 0 );
assert( gamma_move(board, 3, 16, 14) == 0 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_golden_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 5, 12, 18) == 0 );
assert( gamma_move(board, 6, 20, 12) == 0 );
assert( gamma_move(board, 6, 19, 4) == 0 );
assert( gamma_move(board, 7, 8, 6) == 1 );
assert( gamma_move(board, 7, 11, 22) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 21, 17) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 1, 1, 23) == 1 );
assert( gamma_move(board, 2, 3, 17) == 1 );
assert( gamma_move(board, 2, 3, 7) == 1 );
assert( gamma_move(board, 3, 18, 2) == 1 );
assert( gamma_move(board, 3, 18, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 4, 5, 18) == 1 );
assert( gamma_move(board, 5, 23, 4) == 0 );
assert( gamma_move(board, 5, 13, 10) == 0 );
assert( gamma_move(board, 6, 12, 22) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 12, 18) == 0 );
assert( gamma_move(board, 7, 3, 7) == 0 );
assert( gamma_free_fields(board, 7) == 261 );
assert( gamma_move(board, 8, 3, 15) == 0 );
assert( gamma_move(board, 8, 2, 2) == 0 );
assert( gamma_busy_fields(board, 8) == 29 );
assert( gamma_golden_move(board, 8, 15, 17) == 0 );
assert( gamma_move(board, 1, 7, 15) == 1 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_free_fields(board, 1) == 260 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 17, 15) == 0 );
assert( gamma_move(board, 3, 15, 8) == 0 );
assert( gamma_move(board, 3, 13, 15) == 1 );


char* board948777223 = gamma_board(board);
assert( board948777223 != NULL );
assert( strcmp(board948777223, 
"2118.62..........4..\n"
"..57.1.....76..1.333\n"
"...7.........41...4.\n"
"8....1.....4........\n"
"..351.4.7..1..64...2\n"
"3...64.346..88.5.6.2\n"
"5712767..4...81.3477\n"
"8.5.221526.354..2.11\n"
".8624.51....737.67..\n"
"2.1..518......1.7.3.\n"
"5.1.5......275.512.2\n"
"..86.535..84..6865..\n"
"...381.83.23..1..55.\n"
"32.32.5...48.2142.73\n"
"414.2..163788.......\n"
".5..32...4....786...\n"
".1.24726.78371...7..\n"
"2.38..627..8.....7.8\n"
".7.23........4.6.266\n"
".5.3.5........873.48\n"
"..438...3.....2.8.12\n"
"6.1...2..7.....7..32\n"
"8.....3....8..452...\n"
"58.815.3...42.67.6.6\n") == 0);
free(board948777223);
board948777223 = NULL;
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 4, 7, 21) == 1 );
assert( gamma_move(board, 5, 4, 9) == 0 );
assert( gamma_move(board, 5, 6, 23) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 5, 11) == 0 );
assert( gamma_move(board, 6, 11, 15) == 1 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_move(board, 7, 13, 1) == 1 );
assert( gamma_move(board, 7, 2, 9) == 0 );
assert( gamma_move(board, 8, 8, 0) == 1 );
assert( gamma_move(board, 1, 8, 19) == 0 );
assert( gamma_move(board, 1, 9, 23) == 1 );
assert( gamma_move(board, 2, 1, 5) == 0 );
assert( gamma_move(board, 2, 7, 8) == 1 );
assert( gamma_move(board, 3, 7, 20) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 17, 11) == 0 );
assert( gamma_free_fields(board, 5) == 251 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 23, 10) == 0 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_free_fields(board, 6) == 251 );
assert( gamma_move(board, 7, 17, 10) == 1 );
assert( gamma_move(board, 8, 21, 10) == 0 );
assert( gamma_move(board, 8, 11, 19) == 0 );
assert( gamma_move(board, 1, 1, 15) == 0 );
assert( gamma_move(board, 3, 1, 19) == 1 );
assert( gamma_move(board, 4, 15, 1) == 0 );
assert( gamma_move(board, 4, 1, 14) == 1 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 5, 18, 7) == 1 );
assert( gamma_golden_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 6, 2, 4) == 1 );
assert( gamma_move(board, 6, 2, 18) == 1 );
assert( gamma_move(board, 7, 2, 12) == 0 );
assert( gamma_move(board, 7, 1, 2) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 12, 19) == 1 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 20, 13) == 0 );
assert( gamma_move(board, 2, 17, 8) == 1 );
assert( gamma_free_fields(board, 2) == 242 );
assert( gamma_move(board, 3, 13, 19) == 1 );
assert( gamma_move(board, 3, 5, 15) == 1 );


char* board506739088 = gamma_board(board);
assert( board506739088 != NULL );
assert( strcmp(board506739088, 
"2118.62..1.......4..\n"
"..57.1.....76..1.333\n"
"...7...4.....41...4.\n"
"8....1.3...4........\n"
".3351.4.7..18364...2\n"
"3.6.64.346..88.5.6.2\n"
"5712767..4...81.3477\n"
"8.5.221526.354..2.11\n"
".8624351...6737.67..\n"
"241..518......1.7.3.\n"
"5.1.5......275.512.2\n"
"..86.535..84..6865..\n"
"...381.83.23..1..55.\n"
"32.32.5...48.2142773\n"
"414.2..163788.......\n"
".5..32.2.4....7862..\n"
".1.24726.78371...75.\n"
"2.38..627..8.....7.8\n"
".7.23.....3..4.6.266\n"
".563.5........873.48\n"
"..438...3.....2.8.12\n"
"671...2..7.....7..32\n"
"8.....3....8.7452...\n"
"58.815.38..42.67.6.6\n") == 0);
free(board506739088);
board506739088 = NULL;
assert( gamma_move(board, 4, 16, 3) == 0 );
assert( gamma_move(board, 5, 7, 7) == 0 );
assert( gamma_free_fields(board, 5) == 240 );
assert( gamma_move(board, 7, 9, 18) == 0 );
assert( gamma_move(board, 8, 1, 10) == 0 );
assert( gamma_move(board, 8, 8, 18) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 4, 17) == 0 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 21, 10) == 0 );
assert( gamma_move(board, 5, 4, 9) == 0 );
assert( gamma_free_fields(board, 5) == 239 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_move(board, 7, 18, 11) == 0 );
assert( gamma_move(board, 7, 12, 18) == 0 );
assert( gamma_move(board, 8, 5, 13) == 1 );
assert( gamma_move(board, 1, 13, 18) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 21, 1) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 15, 19) == 0 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 4, 10, 23) == 1 );
assert( gamma_free_fields(board, 4) == 237 );
assert( gamma_move(board, 5, 5, 8) == 0 );
assert( gamma_move(board, 7, 7, 19) == 1 );
assert( gamma_golden_move(board, 7, 9, 4) == 0 );
assert( gamma_move(board, 8, 21, 16) == 0 );


char* board246148390 = gamma_board(board);
assert( board246148390 != NULL );
assert( strcmp(board246148390, 
"2118.62..14......4..\n"
"..57.1.....76..1.333\n"
"...7...4.....41...4.\n"
"8....1.3...4........\n"
".3351.477..18364...2\n"
"3.6.64.346..88.5.6.2\n"
"5712767..4...81.3477\n"
"8.5.221526.354..2.11\n"
".8624351...6737.67..\n"
"241..518......1.7.3.\n"
"5.1.58.....275.512.2\n"
"..86.535..84..6865..\n"
"...381.83.23..1..55.\n"
"32.32.5...48.2142773\n"
"414.2..163788.......\n"
".5..32.2.4....7862..\n"
".1.24726.78371...75.\n"
"2.38..627..8.....7.8\n"
".7.23.....3..4.6.266\n"
".563.5........873.48\n"
".3438...3.....2.8.12\n"
"671...2..7.....7..32\n"
"8.....3....8.7452...\n"
"58.815.38..42.67.6.6\n") == 0);
free(board246148390);
board246148390 = NULL;
assert( gamma_move(board, 1, 19, 1) == 1 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_free_fields(board, 1) == 235 );
assert( gamma_move(board, 2, 20, 12) == 0 );
assert( gamma_free_fields(board, 2) == 235 );
assert( gamma_move(board, 3, 23, 15) == 0 );
assert( gamma_move(board, 5, 5, 5) == 1 );
assert( gamma_move(board, 6, 0, 10) == 0 );
assert( gamma_busy_fields(board, 6) == 27 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 6, 23) == 0 );
assert( gamma_busy_fields(board, 7) == 32 );
assert( gamma_move(board, 8, 4, 11) == 0 );
assert( gamma_busy_fields(board, 8) == 32 );
assert( gamma_move(board, 2, 9, 17) == 0 );
assert( gamma_busy_fields(board, 2) == 35 );


char* board465884392 = gamma_board(board);
assert( board465884392 != NULL );
assert( strcmp(board465884392, 
"2118.62..14......4..\n"
"..57.1.....76..1.333\n"
"...7...4.....41...4.\n"
"8....1.3...4........\n"
".3351.477..18364...2\n"
"3.6.64.346..88.5.6.2\n"
"5712767..4...81.3477\n"
"8.5.221526.354..2.11\n"
".8624351...6737.67..\n"
"241..518......1.7.3.\n"
"5.1.58.....275.512.2\n"
"..86.535..84..6865..\n"
"...381.83.23..1..55.\n"
"32.32.5...48.2142773\n"
"414.2..163788.......\n"
".5..32.2.4....7862..\n"
".1.24726.78371...75.\n"
"2.38..627..8.....7.8\n"
".7.235....3..4.6.266\n"
".563.5........873.48\n"
".3438...3.....2.8.12\n"
"671...2..7.....7..32\n"
"8.....3....8.7452..1\n"
"58.815.38..42.67.6.6\n") == 0);
free(board465884392);
board465884392 = NULL;
assert( gamma_move(board, 3, 23, 16) == 0 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 5, 5, 16) == 0 );
assert( gamma_golden_move(board, 5, 3, 16) == 0 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_move(board, 6, 7, 17) == 1 );
assert( gamma_move(board, 7, 13, 7) == 0 );
assert( gamma_free_fields(board, 7) == 232 );
assert( gamma_move(board, 8, 2, 11) == 1 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 13, 9) == 1 );
assert( gamma_move(board, 3, 19, 10) == 0 );
assert( gamma_move(board, 3, 17, 1) == 1 );
assert( gamma_move(board, 4, 16, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 22, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 27 );
assert( gamma_free_fields(board, 5) == 229 );
assert( gamma_move(board, 6, 21, 16) == 0 );
assert( gamma_move(board, 6, 13, 2) == 1 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 8, 5, 5) == 0 );
assert( gamma_move(board, 1, 23, 15) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_move(board, 3, 19, 18) == 0 );
assert( gamma_move(board, 4, 7, 16) == 0 );
assert( gamma_move(board, 4, 11, 16) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 16) == 0 );
assert( gamma_move(board, 5, 0, 23) == 0 );
assert( gamma_golden_move(board, 5, 0, 17) == 0 );
assert( gamma_move(board, 6, 13, 21) == 0 );
assert( gamma_move(board, 6, 16, 2) == 1 );
assert( gamma_busy_fields(board, 6) == 30 );
assert( gamma_move(board, 7, 11, 2) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 10, 5) == 0 );
assert( gamma_move(board, 8, 8, 22) == 1 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 16, 19) == 1 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 5, 6) == 1 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 6, 2, 9) == 0 );
assert( gamma_move(board, 7, 16, 7) == 1 );
assert( gamma_move(board, 7, 14, 16) == 1 );
assert( gamma_move(board, 8, 15, 15) == 1 );
assert( gamma_move(board, 8, 17, 23) == 0 );
assert( gamma_move(board, 1, 14, 15) == 0 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_move(board, 2, 12, 19) == 0 );
assert( gamma_free_fields(board, 2) == 217 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board977249811 = gamma_board(board);
assert( board977249811 != NULL );
assert( strcmp(board977249811, 
"2118.62..14......4..\n"
"..57.1..8..76..1.333\n"
"...7...4.....41...4.\n"
"8....1.3...4........\n"
".3351.477..183642..2\n"
"3.6.64.346..88.5.6.2\n"
"57127676.4...81.3477\n"
"8.5.221526.3547.2.11\n"
".8624351...6737867..\n"
"241..518.....11.7.3.\n"
"5.1.58.....275.512.2\n"
"..86.535..84..6865..\n"
"..8381.83.23..1..55.\n"
"32.32.5..348.2142773\n"
"414.2..1637882......\n"
".5..32.2.4....7862..\n"
".1.24726.78371..775.\n"
"2.38.4627..8.....7.8\n"
".7.2354...3..4.6.266\n"
".56335........873.48\n"
".3438...3.....2.8.12\n"
"671...2..7.7.6.76.32\n"
"8.2...3....8.74523.1\n"
"58.815.38..42.67.6.6\n") == 0);
free(board977249811);
board977249811 = NULL;
assert( gamma_move(board, 4, 22, 9) == 0 );
assert( gamma_golden_move(board, 4, 17, 18) == 1 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 15, 16) == 1 );
assert( gamma_move(board, 6, 3, 11) == 0 );
assert( gamma_move(board, 7, 13, 7) == 0 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 1, 0, 3) == 1 );


char* board283765174 = gamma_board(board);
assert( board283765174 != NULL );
assert( strcmp(board283765174, 
"2118.62..14......4..\n"
"..57.1..8..76..1.333\n"
"...7...4.....41...4.\n"
"8....1.3...4........\n"
".3351.477..183642..2\n"
"3.6.64.346..88.5.4.2\n"
"57127676.4...81.3477\n"
"8.5.221526.354752.11\n"
".8624351...6737867..\n"
"241..518.....11.7.3.\n"
"5.1.58.....275.512.2\n"
"..86.535..84..6865..\n"
"..8381.83.23..1..55.\n"
"32.32.5..348.2142773\n"
"414.2..1637882......\n"
".5..32.2.4....7862..\n"
".1.24726.78371..775.\n"
"2.38.4627..8.....7.8\n"
".7.2354...3..4.6.266\n"
".56335........873.48\n"
"13438...3.....2.8.12\n"
"671...2..7.7.6.76.32\n"
"8.2...3....8.74523.1\n"
"58.815.38..42.67.6.6\n") == 0);
free(board283765174);
board283765174 = NULL;
assert( gamma_move(board, 2, 21, 15) == 0 );
assert( gamma_move(board, 2, 12, 19) == 0 );
assert( gamma_move(board, 3, 5, 21) == 1 );
assert( gamma_free_fields(board, 4) == 213 );
assert( gamma_move(board, 5, 18, 19) == 1 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 6, 21, 0) == 0 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_move(board, 1, 23, 19) == 0 );
assert( gamma_move(board, 1, 17, 4) == 1 );
assert( gamma_golden_move(board, 1, 19, 6) == 1 );
assert( gamma_move(board, 2, 18, 3) == 0 );
assert( gamma_move(board, 2, 17, 22) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 39 );
assert( gamma_move(board, 4, 9, 15) == 1 );
assert( gamma_move(board, 4, 19, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board443905092 = gamma_board(board);
assert( board443905092 != NULL );
assert( strcmp(board443905092, 
"2118.62..14......4..\n"
"..57.1..8..76..1.333\n"
"...7.3.4.....41...4.\n"
"8....1.3...4........\n"
".3351.477..183642.52\n"
"3.6.64.346..88.5.4.2\n"
"57127676.4...81.3477\n"
"8.5.221526.354752.11\n"
".8624351.4.6737867..\n"
"241..518.....11.7.3.\n"
"5.1.58.....275.512.2\n"
"..86.535..84..6865..\n"
"..8381.83.23..1..55.\n"
"32.32.5..348.2142773\n"
"414.2..1637882......\n"
".5..32.2.4....7862..\n"
".1.24726.78371..775.\n"
"2.38.4627..8.....7.1\n"
".7.2354...3..4.6.266\n"
".56335........873148\n"
"13438...3.....2.8.12\n"
"671...2..7.7.6.76.32\n"
"8.2...3....8.74523.1\n"
"58.815.38..42.67.6.6\n") == 0);
free(board443905092);
board443905092 = NULL;
assert( gamma_move(board, 5, 22, 14) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 22, 7) == 0 );
assert( gamma_move(board, 6, 12, 13) == 0 );
assert( gamma_move(board, 7, 13, 3) == 1 );
assert( gamma_move(board, 7, 9, 20) == 1 );
assert( gamma_move(board, 8, 11, 22) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 18, 12) == 1 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 3, 19, 5) == 0 );
assert( gamma_move(board, 4, 10, 18) == 1 );
assert( gamma_move(board, 4, 18, 12) == 0 );
assert( gamma_free_fields(board, 4) == 205 );
assert( gamma_move(board, 5, 11, 16) == 0 );
assert( gamma_move(board, 5, 19, 22) == 0 );
assert( gamma_golden_move(board, 5, 12, 10) == 0 );
assert( gamma_move(board, 6, 5, 9) == 1 );
assert( gamma_move(board, 7, 19, 1) == 0 );
assert( gamma_move(board, 8, 8, 15) == 1 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_free_fields(board, 1) == 202 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_move(board, 2, 11, 5) == 1 );
assert( gamma_move(board, 3, 9, 14) == 1 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );


char* board672139802 = gamma_board(board);
assert( board672139802 != NULL );
assert( strcmp(board672139802, 
"2118.62..14......4..\n"
"..57.1..8..76..1.333\n"
"...7.3.4.....41...4.\n"
"8....1.3.7.4........\n"
".3351.477..183642.52\n"
"3.6.64.3464.88.5.4.2\n"
"57127676.4...81.3477\n"
"8.5.221526.354752.11\n"
".862435184.6737867..\n"
"241..518.3...11.7.3.\n"
"5.1.58.....275.512.2\n"
"..86.535..84..68651.\n"
"..8381.83.23..1..55.\n"
"32.32.5..348.2142773\n"
"414.2621637882......\n"
".5..3212.4....7862..\n"
".1.24726.78371..775.\n"
"2.38.4627..8.....7.1\n"
".7.2354...32.4.6.266\n"
".56335........873148\n"
"13438...3....72.8.12\n"
"671...2..7.7.6.76.32\n"
"8.2...3....8.74523.1\n"
"58.815.38.242.67.6.6\n") == 0);
free(board672139802);
board672139802 = NULL;
assert( gamma_move(board, 5, 12, 9) == 0 );
assert( gamma_move(board, 6, 9, 17) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_free_fields(board, 7) == 199 );
assert( gamma_move(board, 8, 15, 0) == 0 );
assert( gamma_move(board, 8, 14, 18) == 1 );
assert( gamma_move(board, 1, 23, 15) == 0 );
assert( gamma_free_fields(board, 1) == 198 );
assert( gamma_move(board, 2, 17, 7) == 0 );
assert( gamma_move(board, 3, 22, 1) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 13, 1) == 0 );
assert( gamma_move(board, 5, 19, 14) == 1 );
assert( gamma_move(board, 6, 19, 0) == 0 );
assert( gamma_move(board, 7, 8, 10) == 1 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 13, 7) == 0 );
assert( gamma_move(board, 8, 2, 2) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 20, 13) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 12, 10) == 1 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 6, 8, 18) == 0 );
assert( gamma_move(board, 6, 13, 16) == 0 );
assert( gamma_free_fields(board, 7) == 193 );
assert( gamma_move(board, 8, 21, 1) == 0 );
assert( gamma_move(board, 8, 1, 12) == 1 );
assert( gamma_move(board, 1, 20, 3) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_move(board, 6, 18, 16) == 0 );
assert( gamma_free_fields(board, 6) == 190 );
assert( gamma_move(board, 7, 3, 6) == 0 );
assert( gamma_free_fields(board, 7) == 190 );
assert( gamma_move(board, 8, 4, 6) == 1 );
assert( gamma_move(board, 8, 17, 10) == 0 );
assert( gamma_move(board, 1, 18, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 11, 22) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 17) == 0 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 31 );


char* board138262416 = gamma_board(board);
assert( board138262416 != NULL );
assert( strcmp(board138262416, 
"2118.62..14......4..\n"
"..57.1..8..76..1.333\n"
"...7.3.4.....41...4.\n"
"8....1.3.7.4........\n"
".3351.477..183642.52\n"
"3.6.64.3464.8885.4.2\n"
"57127676.4...81.3477\n"
"8.5.221526.354752.11\n"
".862435184.67378671.\n"
"241..518.3...11.7.35\n"
"5.1.58.....275.512.2\n"
".886.535..84..68651.\n"
"..8381.83.23..1..55.\n"
"32632.5.734832142773\n"
"414.2621637882......\n"
".5..3212.4....7862..\n"
".1.24726.78371..775.\n"
"253884627..8.....7.1\n"
".7.2354...32.4.6.266\n"
".56335........873148\n"
"13438...3....72.8.12\n"
"671.4.2..7.7.6.76.32\n"
"8.2...34...8.74523.1\n"
"58.815.38.242.67.6.6\n") == 0);
free(board138262416);
board138262416 = NULL;
assert( gamma_move(board, 6, 10, 11) == 0 );
assert( gamma_free_fields(board, 6) == 188 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 7, 16, 9) == 1 );
assert( gamma_move(board, 8, 6, 2) == 0 );
assert( gamma_move(board, 8, 3, 11) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 18, 13) == 1 );
assert( gamma_move(board, 2, 19, 6) == 0 );
assert( gamma_move(board, 2, 3, 19) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 11, 15) == 0 );
assert( gamma_move(board, 4, 14, 7) == 1 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 5, 12, 21) == 1 );
assert( gamma_move(board, 6, 19, 13) == 0 );
assert( gamma_move(board, 7, 23, 12) == 0 );
assert( gamma_move(board, 8, 0, 15) == 1 );
assert( gamma_busy_fields(board, 8) == 39 );
assert( gamma_move(board, 1, 0, 9) == 0 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 41 );
assert( gamma_move(board, 3, 15, 19) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 5, 7, 19) == 0 );
assert( gamma_move(board, 5, 2, 16) == 0 );
assert( gamma_move(board, 6, 20, 15) == 0 );
assert( gamma_move(board, 6, 16, 10) == 0 );
assert( gamma_move(board, 7, 2, 5) == 1 );
assert( gamma_move(board, 7, 5, 12) == 0 );
assert( gamma_move(board, 8, 18, 18) == 1 );


char* board134500039 = gamma_board(board);
assert( board134500039 != NULL );
assert( strcmp(board134500039, 
"2118.62..14......4..\n"
"..57.1..8..76..1.333\n"
"...7.3.4....541...4.\n"
"8....1.3.7.4........\n"
".3351.477..183642.52\n"
"3.6.64.3464.8885.482\n"
"57127676.4...81.3477\n"
"8.5.221526.354752.11\n"
"8862435184.67378671.\n"
"241..518.3...11.7.35\n"
"5.1.58.....275.51212\n"
".886.535..84..68651.\n"
"..8381.83.23..1..55.\n"
"32632.5.734832142773\n"
"414.2621637882..7...\n"
".5..3212.4....7862..\n"
".1.24726.783714.775.\n"
"253884627..8.....7.1\n"
".772354...32.4.6.266\n"
".56335........873148\n"
"13438...3....72.8.12\n"
"671.4.2..7.7.6.76.32\n"
"8.2...34...8.74523.1\n"
"58.815.38.242.67.6.6\n") == 0);
free(board134500039);
board134500039 = NULL;
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_move(board, 3, 23, 11) == 0 );
assert( gamma_move(board, 3, 12, 18) == 0 );
assert( gamma_busy_fields(board, 3) == 41 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 5, 2, 15) == 0 );
assert( gamma_move(board, 5, 5, 1) == 1 );
assert( gamma_free_fields(board, 5) == 179 );
assert( gamma_move(board, 7, 20, 16) == 0 );
assert( gamma_move(board, 7, 8, 9) == 0 );
assert( gamma_golden_move(board, 7, 16, 5) == 0 );
assert( gamma_move(board, 8, 8, 3) == 0 );
assert( gamma_move(board, 8, 15, 9) == 1 );
assert( gamma_move(board, 1, 7, 17) == 0 );
assert( gamma_move(board, 2, 18, 23) == 1 );
assert( gamma_free_fields(board, 3) == 177 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_busy_fields(board, 5) == 33 );
assert( gamma_move(board, 6, 1, 1) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 11, 17) == 1 );
assert( gamma_move(board, 7, 3, 19) == 0 );
assert( gamma_free_fields(board, 7) == 175 );
assert( gamma_move(board, 8, 6, 13) == 1 );
assert( gamma_move(board, 8, 14, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 42 );
assert( gamma_golden_move(board, 1, 23, 6) == 0 );
assert( gamma_move(board, 2, 16, 22) == 1 );
assert( gamma_move(board, 2, 15, 15) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 5, 22, 14) == 0 );
assert( gamma_move(board, 6, 18, 8) == 1 );
assert( gamma_move(board, 7, 6, 4) == 1 );
assert( gamma_move(board, 7, 16, 19) == 0 );
assert( gamma_busy_fields(board, 8) == 42 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 22, 0) == 0 );
assert( gamma_move(board, 2, 18, 1) == 1 );
assert( gamma_move(board, 3, 6, 18) == 1 );
assert( gamma_busy_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 22, 10) == 0 );
assert( gamma_move(board, 4, 13, 4) == 1 );
assert( gamma_move(board, 5, 21, 4) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 14, 10) == 0 );
assert( gamma_move(board, 6, 19, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 33 );
assert( gamma_move(board, 7, 9, 14) == 0 );
assert( gamma_move(board, 7, 6, 18) == 0 );
assert( gamma_move(board, 8, 18, 3) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 13, 18) == 0 );
assert( gamma_move(board, 2, 15, 19) == 0 );
assert( gamma_move(board, 2, 19, 16) == 0 );
assert( gamma_move(board, 3, 23, 15) == 0 );
assert( gamma_move(board, 3, 10, 18) == 0 );


char* board777930879 = gamma_board(board);
assert( board777930879 != NULL );
assert( strcmp(board777930879, 
"2118.62..14......42.\n"
"..57.1..8..76..12333\n"
"...7.3.4....541...4.\n"
"8....1.3.7.4........\n"
".3351.477..183642.52\n"
"3.6.6433464.8885.482\n"
"57127676.4.7.81.3477\n"
"8.5.221526.354752.11\n"
"8862435184.67378671.\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".886.535..84..68651.\n"
"..8381.83.23..1..55.\n"
"32632.5.734832142773\n"
"414.2621637882.87...\n"
".5..3212.4....78626.\n"
".1.24726.783714.775.\n"
"253884627..8.....7.1\n"
".772354...32.4.6.266\n"
".563357......4873148\n"
"13438...3.2..72.8.12\n"
"671.4.2..7.7.6.76.32\n"
"862..534...8.7452321\n"
"58.815.38.242.67.6.6\n") == 0);
free(board777930879);
board777930879 = NULL;
assert( gamma_move(board, 4, 9, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 7, 7, 10) == 1 );
assert( gamma_move(board, 8, 20, 8) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 1, 19, 11) == 1 );
assert( gamma_golden_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );


char* board463851228 = gamma_board(board);
assert( board463851228 != NULL );
assert( strcmp(board463851228, 
"2118.62..14......42.\n"
"..57.1..8..76..12333\n"
"...7.3.4....541...4.\n"
"8....1.3.7.4........\n"
".3351.477..183642.52\n"
"3.6.6433464.8885.482\n"
"57127676.4.7.81.3477\n"
"8.5.221526.354752.11\n"
"8862435184.67378671.\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".886.535..84..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87...\n"
".5..3212.4....78626.\n"
".1.24726.783714.775.\n"
"253884627..8.....7.1\n"
".772354...32.4.6.266\n"
".563357......4873148\n"
"13438...3.2..72.8.12\n"
"671.4.2..7.7.6.76.32\n"
"862..534.4.8.7452321\n"
"58.815.38.242.67.6.6\n") == 0);
free(board463851228);
board463851228 = NULL;
assert( gamma_move(board, 4, 6, 16) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 6, 20, 6) == 0 );
assert( gamma_move(board, 6, 7, 2) == 1 );
assert( gamma_golden_move(board, 6, 4, 18) == 0 );
assert( gamma_move(board, 7, 16, 1) == 0 );


char* board296526920 = gamma_board(board);
assert( board296526920 != NULL );
assert( strcmp(board296526920, 
"2118.62..14......42.\n"
"..57.1..8..76..12333\n"
"...7.3.4....541...4.\n"
"8....1.3.7.4........\n"
".3351.477..183642.52\n"
"3.6.6433464.8885.482\n"
"57127676.4.7.81.3477\n"
"8.5.221526.354752.11\n"
"8862435184.67378671.\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".886.535..84..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87...\n"
".5..3212.4....78626.\n"
".1.24726.783714.775.\n"
"253884627..8.....7.1\n"
".772354...32.4.6.266\n"
".563357......4873148\n"
"13438...3.2..72.8.12\n"
"671.4.26.7.7.6.76.32\n"
"862..534.4.8.7452321\n"
"58.815.38.242.67.6.6\n") == 0);
free(board296526920);
board296526920 = NULL;
assert( gamma_move(board, 8, 20, 2) == 0 );
assert( gamma_move(board, 8, 6, 23) == 0 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 2, 22, 9) == 0 );
assert( gamma_move(board, 2, 0, 10) == 0 );
assert( gamma_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 3, 1, 22) == 1 );
assert( gamma_move(board, 5, 22, 6) == 0 );
assert( gamma_move(board, 6, 20, 19) == 0 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 34 );
assert( gamma_free_fields(board, 6) == 162 );
assert( gamma_move(board, 7, 2, 8) == 1 );
assert( gamma_move(board, 7, 17, 10) == 0 );
assert( gamma_move(board, 8, 5, 2) == 1 );
assert( gamma_move(board, 8, 4, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 20, 3) == 0 );
assert( gamma_move(board, 2, 16, 12) == 0 );
assert( gamma_move(board, 3, 17, 12) == 0 );
assert( gamma_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 4, 12, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_move(board, 5, 17, 8) == 0 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_golden_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 14, 11) == 0 );
assert( gamma_free_fields(board, 6) == 160 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 8, 1, 12) == 0 );
assert( gamma_move(board, 8, 19, 9) == 1 );
assert( gamma_free_fields(board, 8) == 159 );
assert( gamma_move(board, 1, 18, 1) == 0 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_busy_fields(board, 2) == 46 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 20, 19) == 0 );
assert( gamma_golden_move(board, 3, 19, 12) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 18, 11) == 0 );
assert( gamma_move(board, 5, 18, 16) == 0 );
assert( gamma_move(board, 5, 10, 23) == 0 );
assert( gamma_move(board, 7, 16, 2) == 0 );
assert( gamma_move(board, 8, 20, 6) == 0 );
assert( gamma_move(board, 8, 1, 12) == 0 );
assert( gamma_move(board, 1, 9, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 5, 20, 1) == 0 );
assert( gamma_move(board, 5, 5, 6) == 0 );
assert( gamma_move(board, 6, 4, 10) == 0 );
assert( gamma_move(board, 7, 13, 3) == 0 );
assert( gamma_move(board, 7, 2, 22) == 0 );
assert( gamma_move(board, 8, 6, 18) == 0 );
assert( gamma_move(board, 1, 17, 3) == 1 );
assert( gamma_move(board, 1, 8, 19) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 18, 11) == 0 );
assert( gamma_free_fields(board, 4) == 156 );
assert( gamma_move(board, 5, 15, 13) == 0 );
assert( gamma_move(board, 6, 1, 12) == 0 );
assert( gamma_move(board, 6, 13, 5) == 0 );
assert( gamma_move(board, 7, 14, 17) == 0 );
assert( gamma_move(board, 8, 1, 2) == 0 );
assert( gamma_move(board, 8, 9, 12) == 1 );
assert( gamma_move(board, 1, 21, 6) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 19, 21) == 1 );
assert( gamma_move(board, 2, 17, 11) == 0 );
assert( gamma_move(board, 3, 14, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 44 );
assert( gamma_golden_move(board, 3, 19, 1) == 0 );
assert( gamma_move(board, 4, 18, 12) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 6, 3, 10) == 0 );
assert( gamma_move(board, 7, 9, 18) == 0 );
assert( gamma_move(board, 7, 10, 15) == 1 );
assert( gamma_move(board, 8, 3, 12) == 0 );
assert( gamma_move(board, 8, 0, 0) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 4, 12) == 1 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 0, 17) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_move(board, 6, 6, 18) == 0 );
assert( gamma_move(board, 7, 0, 16) == 0 );
assert( gamma_move(board, 7, 1, 0) == 0 );
assert( gamma_free_fields(board, 7) == 151 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_move(board, 7, 2, 4) == 1 );
assert( gamma_move(board, 8, 17, 22) == 0 );
assert( gamma_move(board, 8, 14, 15) == 0 );
assert( gamma_busy_fields(board, 8) == 45 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 12, 22) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 2, 22, 0) == 0 );
assert( gamma_move(board, 3, 11, 16) == 0 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 4, 12, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 38 );
assert( gamma_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 5, 6, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 33 );
assert( gamma_move(board, 7, 14, 20) == 1 );
assert( gamma_move(board, 7, 13, 16) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 19, 5) == 0 );
assert( gamma_move(board, 8, 11, 23) == 1 );
assert( gamma_move(board, 1, 19, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_free_fields(board, 2) == 147 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 45 );
assert( gamma_move(board, 4, 18, 11) == 0 );
assert( gamma_move(board, 4, 12, 21) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_busy_fields(board, 5) == 33 );
assert( gamma_move(board, 6, 4, 10) == 0 );
assert( gamma_move(board, 7, 19, 15) == 1 );
assert( gamma_busy_fields(board, 7) == 48 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_golden_move(board, 8, 18, 12) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_free_fields(board, 1) == 146 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 2, 13, 8) == 1 );
assert( gamma_move(board, 3, 20, 19) == 0 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 4, 23, 16) == 0 );
assert( gamma_busy_fields(board, 4) == 38 );
assert( gamma_move(board, 5, 19, 10) == 0 );
assert( gamma_move(board, 5, 8, 2) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 11, 13) == 0 );
assert( gamma_move(board, 7, 12, 19) == 0 );
assert( gamma_golden_move(board, 7, 14, 7) == 0 );
assert( gamma_move(board, 8, 18, 16) == 0 );
assert( gamma_move(board, 8, 17, 22) == 0 );


char* board746036704 = gamma_board(board);
assert( board746036704 != NULL );
assert( strcmp(board746036704, 
"2118.62..148.....42.\n"
".357.1..8..76..12333\n"
"...7.3.4....541...42\n"
"8....1.3.7.4..7.....\n"
".3351.477..183642.52\n"
"3.6.6433464.8885.482\n"
"57127676.4.7.81.3477\n"
"8.5.221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.321234..4278626.\n"
".1.247262783714.775.\n"
"253884627..8.....7.1\n"
".772354...32.4.6.266\n"
".573357......4873148\n"
"13438...312.372.8112\n"
"6713482657.7.6.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242.67.6.6\n") == 0);
free(board746036704);
board746036704 = NULL;
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 45 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_move(board, 2, 12, 23) == 1 );
assert( gamma_move(board, 3, 14, 11) == 0 );


char* board142828159 = gamma_board(board);
assert( board142828159 != NULL );
assert( strcmp(board142828159, 
"2118.62..1482....42.\n"
".357.1..8..76..12333\n"
"...7.3.4....541...42\n"
"8....1.3.7.4..7.....\n"
".3351.477..183642.52\n"
"3.6.6433464.8885.482\n"
"57127676.4.7.81.3477\n"
"8.5.221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.321234..4278626.\n"
".1.247262783714.775.\n"
"253884627..8.....7.1\n"
".772354...32.4.6.266\n"
".573357....2.4873148\n"
"134381..312.372.8112\n"
"6713482657.7.6.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242.67.6.6\n") == 0);
free(board142828159);
board142828159 = NULL;
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_move(board, 5, 23, 4) == 0 );
assert( gamma_move(board, 5, 17, 19) == 1 );
assert( gamma_move(board, 6, 0, 0) == 0 );
assert( gamma_free_fields(board, 6) == 138 );
assert( gamma_move(board, 7, 5, 23) == 0 );
assert( gamma_move(board, 8, 20, 1) == 0 );
assert( gamma_move(board, 1, 23, 16) == 0 );
assert( gamma_free_fields(board, 1) == 138 );
assert( gamma_move(board, 2, 16, 3) == 0 );
assert( gamma_move(board, 2, 18, 18) == 0 );
assert( gamma_busy_fields(board, 2) == 50 );
assert( gamma_golden_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 23, 15) == 0 );
assert( gamma_move(board, 3, 3, 21) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 5, 7, 19) == 0 );
assert( gamma_move(board, 5, 10, 8) == 1 );
assert( gamma_move(board, 6, 9, 18) == 0 );
assert( gamma_move(board, 6, 13, 0) == 1 );
assert( gamma_move(board, 7, 0, 6) == 0 );
assert( gamma_move(board, 7, 8, 21) == 1 );
assert( gamma_move(board, 8, 14, 20) == 0 );
assert( gamma_move(board, 8, 5, 11) == 0 );
assert( gamma_busy_fields(board, 8) == 46 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 21, 17) == 0 );
assert( gamma_move(board, 3, 4, 16) == 0 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_free_fields(board, 4) == 135 );
assert( gamma_move(board, 5, 17, 5) == 0 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_move(board, 6, 0, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 34 );
assert( gamma_move(board, 7, 13, 8) == 0 );
assert( gamma_move(board, 7, 13, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 49 );
assert( gamma_busy_fields(board, 8) == 46 );


char* board792587909 = gamma_board(board);
assert( board792587909 != NULL );
assert( strcmp(board792587909, 
"2118.62..1482....42.\n"
".357.1..8..76..12333\n"
"...7.3.47...541...42\n"
"8....1.3.7.4..7.....\n"
".3351.477..183642552\n"
"3.6.6433464.8885.482\n"
"57127676.4.7.81.3477\n"
"8.5.221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
".1.247262783714.775.\n"
"253884627..8.....7.1\n"
"4772354...32.4.6.266\n"
".573357....2.4873148\n"
"134381..312.372.8112\n"
"6713482657.7.6.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board792587909);
board792587909 = NULL;
assert( gamma_move(board, 1, 5, 20) == 0 );
assert( gamma_move(board, 2, 18, 17) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 23, 14) == 0 );
assert( gamma_move(board, 3, 17, 23) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 4, 11, 22) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 6, 20, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 34 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 17, 19) == 0 );


char* board518628714 = gamma_board(board);
assert( board518628714 != NULL );
assert( strcmp(board518628714, 
"2118.62..1482....42.\n"
".357.1..8..76..12333\n"
"...7.3.47...541...42\n"
"8....1.3.7.4..7.....\n"
".3351.477..183642552\n"
"3.6.6433464.8885.482\n"
"57127676.4.7.81.3477\n"
"8.5.221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
".1.247262783714.775.\n"
"253884627..8.....7.1\n"
"4772354...32.4.6.266\n"
".573357....2.4873148\n"
"134381..312.372.8112\n"
"6713482657.7.6.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board518628714);
board518628714 = NULL;
assert( gamma_move(board, 1, 19, 5) == 0 );
assert( gamma_move(board, 1, 18, 10) == 0 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 3, 4, 18) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 13, 15) == 0 );
assert( gamma_move(board, 4, 11, 16) == 0 );
assert( gamma_move(board, 5, 18, 4) == 0 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 22, 7) == 0 );
assert( gamma_move(board, 6, 18, 17) == 0 );
assert( gamma_free_fields(board, 6) == 134 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_move(board, 8, 11, 18) == 1 );
assert( gamma_move(board, 8, 8, 6) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_free_fields(board, 2) == 133 );
assert( gamma_move(board, 3, 21, 0) == 0 );
assert( gamma_move(board, 4, 12, 17) == 1 );
assert( gamma_move(board, 5, 21, 0) == 0 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_move(board, 7, 14, 4) == 0 );
assert( gamma_move(board, 7, 6, 3) == 1 );
assert( gamma_busy_fields(board, 8) == 47 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 22, 0) == 0 );
assert( gamma_move(board, 4, 17, 8) == 0 );
assert( gamma_move(board, 5, 13, 14) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 7, 0, 18) == 0 );
assert( gamma_move(board, 8, 5, 12) == 0 );
assert( gamma_move(board, 1, 11, 13) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 2, 18, 2) == 0 );
assert( gamma_move(board, 3, 23, 13) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_free_fields(board, 3) == 131 );
assert( gamma_move(board, 5, 23, 14) == 0 );
assert( gamma_free_fields(board, 5) == 131 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 20, 2) == 0 );
assert( gamma_move(board, 6, 6, 9) == 0 );
assert( gamma_move(board, 7, 14, 3) == 0 );
assert( gamma_move(board, 8, 19, 23) == 1 );
assert( gamma_move(board, 8, 5, 16) == 0 );
assert( gamma_busy_fields(board, 8) == 48 );
assert( gamma_move(board, 1, 20, 15) == 0 );
assert( gamma_move(board, 1, 10, 11) == 0 );
assert( gamma_move(board, 2, 2, 17) == 0 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 3, 5, 14) == 0 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_move(board, 4, 7, 22) == 1 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_busy_fields(board, 5) == 36 );
assert( gamma_move(board, 7, 18, 13) == 0 );
assert( gamma_free_fields(board, 7) == 129 );
assert( gamma_move(board, 8, 14, 3) == 0 );
assert( gamma_move(board, 8, 3, 15) == 0 );


char* board920059149 = gamma_board(board);
assert( board920059149 != NULL );
assert( strcmp(board920059149, 
"2118.62..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541...42\n"
"8....1.3.7.4..7.....\n"
".3351.477..183642552\n"
"3.6.643346488885.482\n"
"57127676.4.7481.3477\n"
"8.5.221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
".1.247262783714.775.\n"
"253884627..8.....7.1\n"
"4772354...32.4.6.266\n"
".573357....2.4873148\n"
"13438172312.372.8112\n"
"6713482657.7.6.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board920059149);
board920059149 = NULL;
assert( gamma_move(board, 2, 23, 16) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 4, 18, 2) == 0 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_move(board, 5, 6, 18) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 6, 6, 14) == 0 );
assert( gamma_move(board, 7, 1, 23) == 0 );
assert( gamma_move(board, 8, 14, 15) == 0 );
assert( gamma_move(board, 8, 1, 7) == 0 );
assert( gamma_move(board, 1, 13, 14) == 0 );
assert( gamma_move(board, 1, 4, 18) == 0 );
assert( gamma_free_fields(board, 1) == 128 );


char* board551584578 = gamma_board(board);
assert( board551584578 != NULL );
assert( strcmp(board551584578, 
"2118.62..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541...42\n"
"8....1.3.7.4..7.....\n"
".3351.477..183642552\n"
"3.6.643346488885.482\n"
"57127676.4.7481.3477\n"
"8.5.221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...11.7.35\n"
"5.1.588....275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
".1.247262783714.775.\n"
"253884627..8.....7.1\n"
"4772354...32.4.6.266\n"
"2573357....2.4873148\n"
"13438172312.372.8112\n"
"6713482657.7.6.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board551584578);
board551584578 = NULL;
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 5, 5, 3) == 0 );
assert( gamma_move(board, 5, 15, 14) == 1 );
assert( gamma_move(board, 6, 12, 19) == 0 );
assert( gamma_move(board, 6, 8, 13) == 1 );


char* board797603225 = gamma_board(board);
assert( board797603225 != NULL );
assert( strcmp(board797603225, 
"2118.62..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541...42\n"
"8....1.3.7.4..7.....\n"
".3351.477..183642552\n"
"3.6.643346488885.482\n"
"57127676.4.7481.3477\n"
"8.5.221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...1157.35\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
".1.247262783714.775.\n"
"253884627..8.....7.1\n"
"4772354...32.4.6.266\n"
"2573357....2.4873148\n"
"13438172312.372.8112\n"
"6713482657.7.6.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board797603225);
board797603225 = NULL;
assert( gamma_move(board, 7, 12, 19) == 0 );
assert( gamma_move(board, 8, 13, 10) == 0 );
assert( gamma_golden_move(board, 8, 3, 0) == 0 );
assert( gamma_move(board, 1, 1, 12) == 0 );
assert( gamma_move(board, 1, 18, 16) == 0 );
assert( gamma_move(board, 2, 19, 22) == 0 );
assert( gamma_move(board, 2, 16, 8) == 0 );
assert( gamma_move(board, 3, 23, 4) == 0 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 46 );
assert( gamma_move(board, 4, 19, 5) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_free_fields(board, 4) == 126 );
assert( gamma_move(board, 5, 13, 1) == 0 );
assert( gamma_move(board, 6, 0, 19) == 1 );
assert( gamma_free_fields(board, 6) == 125 );
assert( gamma_move(board, 7, 22, 4) == 0 );
assert( gamma_move(board, 7, 5, 19) == 1 );
assert( gamma_move(board, 8, 21, 4) == 0 );
assert( gamma_move(board, 8, 16, 15) == 0 );
assert( gamma_move(board, 1, 18, 3) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 11, 16) == 0 );
assert( gamma_move(board, 3, 12, 19) == 0 );
assert( gamma_busy_fields(board, 3) == 46 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_busy_fields(board, 5) == 37 );
assert( gamma_move(board, 6, 4, 23) == 1 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_move(board, 7, 13, 14) == 0 );
assert( gamma_move(board, 7, 1, 19) == 0 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 2, 21, 9) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 16, 6) == 1 );
assert( gamma_move(board, 4, 21, 16) == 0 );
assert( gamma_move(board, 4, 9, 4) == 1 );
assert( gamma_busy_fields(board, 4) == 42 );


char* board567830980 = gamma_board(board);
assert( board567830980 != NULL );
assert( strcmp(board567830980, 
"2118662..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541...42\n"
"8....1.3.7.4..7.....\n"
"633517477..183642552\n"
"3.6.643346488885.482\n"
"57127676.4.7481.3477\n"
"8.5.221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...1157.35\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
".1.247262783714.775.\n"
"253884627..8....37.1\n"
"4772354...32.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713482657.7.6.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board567830980);
board567830980 = NULL;
assert( gamma_move(board, 5, 7, 0) == 0 );
assert( gamma_move(board, 6, 4, 10) == 0 );
assert( gamma_move(board, 6, 9, 5) == 1 );
assert( gamma_move(board, 7, 14, 11) == 0 );
assert( gamma_move(board, 7, 11, 7) == 0 );
assert( gamma_free_fields(board, 7) == 120 );
assert( gamma_move(board, 8, 14, 6) == 1 );
assert( gamma_move(board, 1, 9, 18) == 0 );
assert( gamma_move(board, 2, 12, 2) == 1 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 4, 3, 21) == 0 );
assert( gamma_move(board, 5, 17, 3) == 0 );
assert( gamma_move(board, 5, 3, 16) == 1 );
assert( gamma_move(board, 6, 17, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 38 );
assert( gamma_move(board, 8, 0, 7) == 1 );
assert( gamma_move(board, 8, 15, 9) == 0 );
assert( gamma_busy_fields(board, 8) == 50 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 2, 18, 3) == 0 );
assert( gamma_free_fields(board, 2) == 116 );
assert( gamma_move(board, 3, 8, 20) == 1 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 5, 6, 18) == 0 );
assert( gamma_free_fields(board, 5) == 115 );
assert( gamma_move(board, 6, 13, 1) == 0 );
assert( gamma_move(board, 7, 10, 10) == 0 );
assert( gamma_move(board, 7, 18, 18) == 0 );
assert( gamma_move(board, 8, 14, 19) == 0 );
assert( gamma_free_fields(board, 8) == 115 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 18, 1) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_free_fields(board, 4) == 115 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 6, 14, 21) == 0 );
assert( gamma_move(board, 6, 17, 1) == 0 );
assert( gamma_move(board, 7, 15, 0) == 0 );


char* board610997992 = gamma_board(board);
assert( board610997992 != NULL );
assert( strcmp(board610997992, 
"2118662..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541...42\n"
"8....1.337.4..7.....\n"
"633517477..183642552\n"
"3.6.643346488885.482\n"
"57127676.4.7481.3477\n"
"8.55221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...1157.35\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
"..8381.83.23..1..551\n"
"32632.57734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
"81.247262783714.775.\n"
"253884627..8..8.37.1\n"
"4772354..632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713482657.726.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board610997992);
board610997992 = NULL;
assert( gamma_move(board, 8, 3, 0) == 0 );
assert( gamma_move(board, 8, 4, 6) == 0 );
assert( gamma_busy_fields(board, 8) == 50 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 3, 22, 9) == 0 );
assert( gamma_move(board, 4, 16, 10) == 0 );
assert( gamma_move(board, 4, 12, 17) == 0 );
assert( gamma_move(board, 5, 22, 10) == 0 );
assert( gamma_move(board, 5, 5, 18) == 0 );
assert( gamma_move(board, 6, 11, 0) == 0 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_move(board, 7, 1, 11) == 1 );
assert( gamma_move(board, 8, 1, 4) == 0 );
assert( gamma_move(board, 8, 17, 8) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 17, 10) == 0 );
assert( gamma_move(board, 2, 1, 22) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 12) == 0 );
assert( gamma_move(board, 3, 15, 18) == 0 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 21, 1) == 0 );
assert( gamma_move(board, 5, 16, 16) == 0 );
assert( gamma_free_fields(board, 5) == 113 );
assert( gamma_move(board, 6, 13, 14) == 0 );
assert( gamma_move(board, 6, 9, 18) == 0 );
assert( gamma_move(board, 7, 0, 6) == 0 );
assert( gamma_move(board, 8, 6, 15) == 0 );
assert( gamma_move(board, 8, 11, 5) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 3, 13, 20) == 1 );
assert( gamma_free_fields(board, 3) == 112 );


char* board215328354 = gamma_board(board);
assert( board215328354 != NULL );
assert( strcmp(board215328354, 
"2118662..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541...42\n"
"8....1.337.4.37.....\n"
"633517477..183642552\n"
"3.6.643346488885.482\n"
"57127676.4.7481.3477\n"
"8.55221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...1157.35\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
"81.247262783714.775.\n"
"253884627..8..8.37.1\n"
"4772354..632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713482657.726.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board215328354);
board215328354 = NULL;
assert( gamma_move(board, 4, 16, 21) == 1 );


char* board571996234 = gamma_board(board);
assert( board571996234 != NULL );
assert( strcmp(board571996234, 
"2118662..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541.4.42\n"
"8....1.337.4.37.....\n"
"633517477..183642552\n"
"3.6.643346488885.482\n"
"57127676.4.7481.3477\n"
"8.55221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...1157.35\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
"81.247262783714.775.\n"
"253884627..8..8.37.1\n"
"4772354..632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713482657.726.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board571996234);
board571996234 = NULL;
assert( gamma_move(board, 5, 13, 9) == 0 );
assert( gamma_free_fields(board, 5) == 111 );
assert( gamma_move(board, 6, 9, 18) == 0 );
assert( gamma_move(board, 7, 11, 0) == 0 );
assert( gamma_move(board, 8, 22, 10) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 14, 17) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 17, 14) == 1 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 6, 2, 8) == 0 );
assert( gamma_move(board, 7, 9, 18) == 0 );
assert( gamma_free_fields(board, 7) == 110 );


char* board185121813 = gamma_board(board);
assert( board185121813 != NULL );
assert( strcmp(board185121813, 
"2118662..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541.4.42\n"
"8....1.337.4.37.....\n"
"633517477..183642552\n"
"3.6.643346488885.482\n"
"57127676.4.7481.3477\n"
"8.55221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...1157535\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
"81.247262783714.775.\n"
"253884627..8..8.37.1\n"
"4772354..632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713482657.726.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board185121813);
board185121813 = NULL;
assert( gamma_move(board, 1, 21, 15) == 0 );
assert( gamma_move(board, 1, 16, 18) == 1 );
assert( gamma_free_fields(board, 2) == 109 );
assert( gamma_move(board, 3, 21, 1) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_free_fields(board, 3) == 109 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 5, 23, 13) == 0 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_move(board, 6, 12, 15) == 0 );
assert( gamma_move(board, 7, 0, 6) == 0 );


char* board606133157 = gamma_board(board);
assert( board606133157 != NULL );
assert( strcmp(board606133157, 
"2118662..1482....428\n"
".357.1.48..76..12333\n"
"...7.3.47...541.4.42\n"
"8....1.337.4.37.....\n"
"633517477..183642552\n"
"3.6.6433464888851482\n"
"57127676.4.7481.3477\n"
"8.55221526.354752.11\n"
"88624351847673786717\n"
"241..518.3...1157535\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87..8\n"
".57.3212345.4278626.\n"
"81.247262783714.775.\n"
"253884627..8..8.37.1\n"
"4772354..632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713482657.726.76.32\n"
"862..534.4.8.7452321\n"
"581815.38.242667.6.6\n") == 0);
free(board606133157);
board606133157 = NULL;
assert( gamma_move(board, 8, 13, 3) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 15, 14) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 17, 11) == 0 );
assert( gamma_move(board, 4, 18, 17) == 0 );
assert( gamma_move(board, 5, 20, 6) == 0 );
assert( gamma_move(board, 5, 12, 23) == 0 );
assert( gamma_move(board, 6, 14, 8) == 0 );
assert( gamma_move(board, 7, 6, 12) == 0 );
assert( gamma_busy_fields(board, 7) == 52 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_free_fields(board, 8) == 109 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_move(board, 1, 13, 18) == 0 );
assert( gamma_move(board, 2, 20, 12) == 0 );
assert( gamma_move(board, 2, 1, 19) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 18) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 4, 0, 23) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 22, 14) == 0 );
assert( gamma_move(board, 5, 10, 6) == 1 );
assert( gamma_move(board, 6, 21, 2) == 0 );
assert( gamma_free_fields(board, 6) == 108 );
assert( gamma_move(board, 7, 13, 3) == 0 );
assert( gamma_move(board, 8, 1, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 50 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 49 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 5, 9, 18) == 0 );
assert( gamma_free_fields(board, 5) == 108 );
assert( gamma_move(board, 6, 20, 1) == 0 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_golden_move(board, 6, 14, 5) == 0 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 8, 5, 8) == 0 );
assert( gamma_move(board, 8, 14, 19) == 0 );
assert( gamma_move(board, 1, 19, 9) == 0 );
assert( gamma_move(board, 1, 3, 20) == 1 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_free_fields(board, 3) == 107 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 15, 21) == 1 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_move(board, 5, 21, 4) == 0 );
assert( gamma_move(board, 5, 0, 17) == 0 );
assert( gamma_move(board, 6, 8, 1) == 1 );
assert( gamma_move(board, 7, 23, 16) == 0 );
assert( gamma_move(board, 7, 3, 1) == 1 );
assert( gamma_busy_fields(board, 8) == 50 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_golden_move(board, 1, 16, 4) == 0 );
assert( gamma_move(board, 2, 21, 10) == 0 );
assert( gamma_golden_move(board, 2, 5, 2) == 1 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 9, 19) == 1 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 45 );
assert( gamma_move(board, 5, 20, 6) == 0 );
assert( gamma_move(board, 6, 22, 10) == 0 );
assert( gamma_move(board, 6, 14, 17) == 0 );
assert( gamma_free_fields(board, 6) == 102 );
assert( gamma_move(board, 7, 0, 6) == 0 );
assert( gamma_move(board, 7, 7, 23) == 1 );
assert( gamma_busy_fields(board, 7) == 54 );
assert( gamma_move(board, 8, 2, 9) == 0 );
assert( gamma_move(board, 8, 15, 1) == 0 );
assert( gamma_free_fields(board, 8) == 101 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 22, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 55 );
assert( gamma_move(board, 3, 16, 17) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 4, 17, 8) == 0 );
assert( gamma_move(board, 4, 4, 21) == 1 );
assert( gamma_move(board, 5, 20, 17) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 6, 20, 1) == 0 );
assert( gamma_move(board, 6, 12, 16) == 0 );
assert( gamma_move(board, 7, 6, 14) == 0 );
assert( gamma_move(board, 7, 10, 12) == 0 );
assert( gamma_move(board, 8, 6, 9) == 0 );
assert( gamma_move(board, 8, 9, 8) == 0 );
assert( gamma_move(board, 2, 0, 20) == 0 );
assert( gamma_move(board, 2, 8, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 55 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 3, 19, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 22, 13) == 0 );
assert( gamma_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 5, 11, 8) == 1 );
assert( gamma_move(board, 6, 20, 19) == 0 );
assert( gamma_move(board, 6, 8, 17) == 1 );
assert( gamma_move(board, 7, 4, 12) == 0 );
assert( gamma_move(board, 8, 14, 22) == 1 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 13, 21) == 0 );
assert( gamma_move(board, 2, 8, 19) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 3, 12, 14) == 1 );
assert( gamma_move(board, 4, 23, 15) == 0 );
assert( gamma_move(board, 4, 19, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 46 );
assert( gamma_move(board, 5, 7, 7) == 0 );
assert( gamma_move(board, 5, 19, 5) == 0 );
assert( gamma_move(board, 6, 6, 15) == 0 );
assert( gamma_move(board, 6, 1, 22) == 0 );
assert( gamma_move(board, 7, 6, 15) == 0 );
assert( gamma_move(board, 7, 14, 23) == 1 );
assert( gamma_move(board, 8, 20, 12) == 0 );
assert( gamma_golden_move(board, 8, 13, 13) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_move(board, 3, 23, 13) == 0 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 5, 6, 15) == 0 );
assert( gamma_move(board, 6, 1, 10) == 0 );
assert( gamma_move(board, 6, 7, 23) == 0 );
assert( gamma_move(board, 8, 16, 20) == 1 );
assert( gamma_golden_move(board, 8, 2, 1) == 0 );
assert( gamma_move(board, 1, 0, 18) == 0 );
assert( gamma_move(board, 1, 11, 23) == 0 );
assert( gamma_move(board, 2, 21, 11) == 0 );
assert( gamma_move(board, 2, 7, 7) == 0 );
assert( gamma_move(board, 3, 16, 10) == 0 );
assert( gamma_move(board, 4, 17, 16) == 1 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_golden_move(board, 5, 15, 16) == 0 );
assert( gamma_move(board, 6, 17, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 40 );
assert( gamma_move(board, 7, 22, 4) == 0 );
assert( gamma_move(board, 8, 16, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 51 );
assert( gamma_move(board, 1, 11, 16) == 0 );
assert( gamma_move(board, 2, 3, 19) == 0 );
assert( gamma_move(board, 2, 18, 20) == 1 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 3, 5, 22) == 0 );
assert( gamma_move(board, 4, 22, 6) == 0 );
assert( gamma_move(board, 4, 19, 23) == 0 );
assert( gamma_busy_fields(board, 4) == 47 );
assert( gamma_move(board, 5, 21, 2) == 0 );
assert( gamma_move(board, 6, 21, 9) == 0 );
assert( gamma_golden_move(board, 6, 18, 0) == 0 );
assert( gamma_move(board, 7, 8, 20) == 0 );
assert( gamma_move(board, 8, 16, 1) == 0 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_free_fields(board, 1) == 92 );
assert( gamma_move(board, 2, 8, 21) == 0 );
assert( gamma_move(board, 3, 3, 15) == 0 );
assert( gamma_move(board, 4, 0, 18) == 0 );
assert( gamma_move(board, 4, 9, 20) == 0 );
assert( gamma_move(board, 5, 21, 0) == 0 );
assert( gamma_move(board, 6, 22, 4) == 0 );
assert( gamma_move(board, 7, 14, 4) == 0 );
assert( gamma_move(board, 7, 10, 18) == 0 );
assert( gamma_move(board, 8, 9, 0) == 1 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 8, 23) == 1 );
assert( gamma_move(board, 2, 5, 9) == 0 );


char* board115443476 = gamma_board(board);
assert( board115443476 != NULL );
assert( strcmp(board115443476, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.6.6433464888851482\n"
"5712767664.7481.3477\n"
"8.55221526.354752411\n"
"88624351847673786717\n"
"241..518.3..31157535\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87..8\n"
".57.321234554278626.\n"
"81.247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board115443476);
board115443476 = NULL;
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 4, 17, 15) == 0 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_move(board, 5, 15, 12) == 0 );
assert( gamma_move(board, 6, 5, 12) == 0 );
assert( gamma_move(board, 7, 19, 23) == 0 );


char* board285937315 = gamma_board(board);
assert( board285937315 != NULL );
assert( strcmp(board285937315, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.6.6433464888851482\n"
"5712767664.7481.3477\n"
"8.55221526.354752411\n"
"88624351847673786717\n"
"241..518.3..31157535\n"
"5.1.588.6..275.51212\n"
".8861535.884..68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87..8\n"
".57.321234554278626.\n"
"81.247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board285937315);
board285937315 = NULL;
assert( gamma_move(board, 8, 14, 11) == 0 );
assert( gamma_move(board, 1, 6, 18) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_free_fields(board, 3) == 90 );
assert( gamma_move(board, 4, 15, 12) == 0 );
assert( gamma_move(board, 5, 2, 17) == 0 );
assert( gamma_busy_fields(board, 5) == 41 );
assert( gamma_move(board, 6, 11, 14) == 1 );
assert( gamma_move(board, 7, 20, 4) == 0 );
assert( gamma_move(board, 7, 11, 2) == 0 );
assert( gamma_move(board, 8, 12, 13) == 0 );
assert( gamma_move(board, 8, 14, 19) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 1, 6, 16) == 0 );
assert( gamma_free_fields(board, 1) == 89 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 57 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 4, 20, 12) == 0 );
assert( gamma_free_fields(board, 4) == 89 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 5, 9, 16) == 0 );
assert( gamma_move(board, 6, 13, 10) == 0 );
assert( gamma_move(board, 6, 6, 9) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 8, 23, 13) == 0 );
assert( gamma_move(board, 8, 19, 2) == 0 );
assert( gamma_busy_fields(board, 8) == 52 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_golden_move(board, 1, 12, 17) == 0 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_move(board, 2, 18, 15) == 0 );
assert( gamma_free_fields(board, 2) == 88 );
assert( gamma_move(board, 3, 13, 18) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 16, 1) == 0 );
assert( gamma_free_fields(board, 4) == 88 );
assert( gamma_move(board, 5, 3, 11) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 6, 16, 9) == 0 );
assert( gamma_move(board, 7, 23, 15) == 0 );
assert( gamma_move(board, 7, 10, 0) == 0 );
assert( gamma_move(board, 8, 11, 13) == 0 );
assert( gamma_move(board, 8, 14, 23) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 3, 18, 9) == 1 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 5, 18, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 12, 12) == 1 );
assert( gamma_move(board, 7, 20, 17) == 0 );
assert( gamma_move(board, 8, 7, 14) == 0 );
assert( gamma_move(board, 8, 2, 16) == 0 );
assert( gamma_move(board, 1, 12, 17) == 0 );
assert( gamma_move(board, 1, 9, 18) == 0 );


char* board367891327 = gamma_board(board);
assert( board367891327 != NULL );
assert( strcmp(board367891327, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.6.6433464888851482\n"
"5712767664.7481.3477\n"
"8.55221526.354752411\n"
"88624351847673786717\n"
"241..518.3.631157535\n"
"5.1.588.6..275.51212\n"
".8861535.8846.68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87.38\n"
".57.321234554278626.\n"
"812247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board367891327);
board367891327 = NULL;
assert( gamma_move(board, 2, 13, 3) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 5, 8, 2) == 0 );


char* board722614377 = gamma_board(board);
assert( board722614377 != NULL );
assert( strcmp(board722614377, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.6.6433464888851482\n"
"5712767664.7481.3477\n"
"8.55221526.354752411\n"
"88624351847673786717\n"
"241..518.3.631157535\n"
"5.1.588.6..275.51212\n"
".8861535.8846.68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87.38\n"
".57.321234554278626.\n"
"812247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board722614377);
board722614377 = NULL;
assert( gamma_move(board, 6, 17, 3) == 0 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_move(board, 7, 14, 10) == 0 );
assert( gamma_move(board, 7, 3, 20) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );


char* board350856471 = gamma_board(board);
assert( board350856471 != NULL );
assert( strcmp(board350856471, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.6.6433464888851482\n"
"5712767664.7481.3477\n"
"8.55221526.354752411\n"
"88624351847673786717\n"
"241..518.3.631157535\n"
"5.1.588.6..275.51212\n"
".8861535.8846.68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87.38\n"
".57.321234554278626.\n"
"812247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board350856471);
board350856471 = NULL;
assert( gamma_move(board, 2, 20, 12) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 20, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 18, 1) == 0 );
assert( gamma_move(board, 4, 11, 9) == 0 );
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );


char* board510673286 = gamma_board(board);
assert( board510673286 != NULL );
assert( strcmp(board510673286, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.6.6433464888851482\n"
"5712767664.7481.3477\n"
"8.55221526.354752411\n"
"88624351847673786717\n"
"241..518.3.631157535\n"
"5.1.588.6..275.51212\n"
".8861535.8846.68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87.38\n"
".57.321234554278626.\n"
"812247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board510673286);
board510673286 = NULL;
assert( gamma_move(board, 6, 8, 22) == 0 );
assert( gamma_busy_fields(board, 6) == 42 );
assert( gamma_move(board, 7, 6, 12) == 0 );
assert( gamma_move(board, 8, 22, 6) == 0 );


char* board702529977 = gamma_board(board);
assert( board702529977 != NULL );
assert( strcmp(board702529977, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.6.6433464888851482\n"
"5712767664.7481.3477\n"
"8.55221526.354752411\n"
"88624351847673786717\n"
"241..518.3.631157535\n"
"5.1.588.6..275.51212\n"
".8861535.8846.68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87.38\n"
".57.321234554278626.\n"
"812247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board702529977);
board702529977 = NULL;
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 1, 5, 15) == 0 );
assert( gamma_move(board, 2, 19, 10) == 0 );
assert( gamma_free_fields(board, 2) == 86 );
assert( gamma_move(board, 3, 16, 21) == 0 );
assert( gamma_free_fields(board, 3) == 86 );
assert( gamma_move(board, 4, 22, 10) == 0 );
assert( gamma_move(board, 6, 8, 23) == 0 );
assert( gamma_move(board, 6, 7, 7) == 0 );
assert( gamma_free_fields(board, 6) == 86 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 8, 6, 13) == 0 );
assert( gamma_golden_possible(board, 8) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 47 );
assert( gamma_move(board, 2, 7, 19) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 47 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 5, 5, 13) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 7, 8, 10) == 0 );
assert( gamma_move(board, 7, 6, 6) == 0 );
assert( gamma_move(board, 8, 22, 13) == 0 );
assert( gamma_move(board, 8, 17, 3) == 0 );
assert( gamma_busy_fields(board, 8) == 52 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );


char* board515906560 = gamma_board(board);
assert( board515906560 != NULL );
assert( strcmp(board515906560, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.6.6433464888851482\n"
"5712767664.7481.3477\n"
"8.55221526.354752411\n"
"88624351847673786717\n"
"241..518.3.631157535\n"
"5.1.588.6..275.51212\n"
".8861535.8846.68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87.38\n"
".57.321234554278626.\n"
"812247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.6.266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board515906560);
board515906560 = NULL;
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 4, 6, 15) == 0 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 6, 17, 15) == 0 );
assert( gamma_move(board, 8, 6, 12) == 0 );
assert( gamma_move(board, 8, 10, 9) == 0 );
assert( gamma_move(board, 1, 23, 16) == 0 );
assert( gamma_free_fields(board, 1) == 86 );
assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 58 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 20, 6) == 0 );
assert( gamma_move(board, 4, 2, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 3, 18) == 1 );
assert( gamma_move(board, 6, 18, 1) == 0 );
assert( gamma_move(board, 7, 7, 15) == 0 );
assert( gamma_move(board, 7, 1, 16) == 1 );
assert( gamma_golden_move(board, 7, 7, 11) == 0 );
assert( gamma_move(board, 8, 11, 6) == 0 );
assert( gamma_move(board, 8, 3, 19) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 19, 18) == 0 );
assert( gamma_move(board, 2, 21, 17) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 52 );
assert( gamma_move(board, 4, 21, 2) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 5, 14, 4) == 0 );
assert( gamma_move(board, 6, 18, 1) == 0 );
assert( gamma_move(board, 7, 6, 9) == 0 );
assert( gamma_move(board, 8, 21, 9) == 0 );
assert( gamma_move(board, 8, 2, 1) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_free_fields(board, 1) == 84 );
assert( gamma_move(board, 3, 19, 21) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 4, 21, 9) == 0 );
assert( gamma_move(board, 5, 23, 13) == 0 );
assert( gamma_free_fields(board, 6) == 84 );
assert( gamma_move(board, 8, 6, 18) == 0 );
assert( gamma_move(board, 8, 17, 11) == 0 );
assert( gamma_move(board, 1, 20, 4) == 0 );
assert( gamma_move(board, 2, 21, 9) == 0 );
assert( gamma_move(board, 3, 11, 17) == 0 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 4, 13) == 0 );
assert( gamma_golden_move(board, 5, 16, 1) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 8, 5, 22) == 0 );
assert( gamma_move(board, 8, 3, 18) == 0 );
assert( gamma_move(board, 2, 18, 10) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 21, 11) == 0 );
assert( gamma_move(board, 3, 18, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 53 );
assert( gamma_move(board, 5, 20, 10) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 6, 22, 10) == 0 );
assert( gamma_move(board, 6, 15, 5) == 0 );
assert( gamma_move(board, 7, 6, 13) == 0 );
assert( gamma_move(board, 7, 8, 16) == 0 );
assert( gamma_move(board, 8, 3, 7) == 0 );
assert( gamma_move(board, 8, 2, 13) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 16, 5) == 1 );
assert( gamma_move(board, 2, 21, 0) == 0 );
assert( gamma_move(board, 3, 22, 13) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 5, 2, 2) == 0 );
assert( gamma_move(board, 6, 1, 4) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 7, 3, 13) == 1 );
assert( gamma_move(board, 8, 5, 4) == 0 );
assert( gamma_move(board, 8, 17, 5) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 1, 18, 17) == 0 );


char* board157124847 = gamma_board(board);
assert( board157124847 != NULL );
assert( strcmp(board157124847, 
"2118662721482.7..428\n"
".357.1.48..76.812333\n"
"...743.47...54144.42\n"
"8..1.1.337.4.37.8.2.\n"
"6335174773.183642552\n"
"3.656433464888851482\n"
"5712767664.7481.3477\n"
"8755221526.354752411\n"
"88624351847673786717\n"
"241..518.3.631157535\n"
"5317588.6..275.51212\n"
".8861535.8846.68651.\n"
".78381.83.23..1..551\n"
"32632257734832142773\n"
"414.2621637882.87.38\n"
".57.321234554278626.\n"
"812247262783714.775.\n"
"253884627.58..8.37.1\n"
"47723544.632.4.61266\n"
"2573357..4.2.4873148\n"
"13438172312.372.8112\n"
"6713422657.726.76.32\n"
"8627.53464.8.7452321\n"
"581815.388242667.6.6\n") == 0);
free(board157124847);
board157124847 = NULL;
assert( gamma_move(board, 2, 17, 10) == 0 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 3, 15, 16) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_free_fields(board, 4) == 81 );
assert( gamma_move(board, 5, 23, 16) == 0 );
assert( gamma_golden_move(board, 5, 20, 13) == 0 );
assert( gamma_move(board, 6, 18, 9) == 0 );
assert( gamma_move(board, 7, 8, 3) == 0 );
assert( gamma_move(board, 7, 12, 15) == 0 );
assert( gamma_move(board, 8, 1, 4) == 0 );


gamma_delete(board);

    return 0;
}
