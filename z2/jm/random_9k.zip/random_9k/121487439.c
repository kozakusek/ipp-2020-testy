#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 121487439
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 16, 4, 27);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_move(board, 2, 8, 0) == 1 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 4, 5, 2) == 1 );
assert( gamma_golden_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 1, 11, 10) == 1 );
assert( gamma_move(board, 1, 5, 9) == 1 );
assert( gamma_move(board, 2, 10, 11) == 1 );
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 4, 3, 6) == 1 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 7, 12) == 1 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 2, 4, 10) == 1 );
assert( gamma_move(board, 3, 9, 7) == 1 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_free_fields(board, 3) == 178 );
assert( gamma_move(board, 4, 10, 3) == 1 );


char* board996747513 = gamma_board(board);
assert( board996747513 != NULL );
assert( strcmp(board996747513, 
"............\n"
"............\n"
"............\n"
".......1....\n"
"..........2.\n"
"....22.....1\n"
".....1......\n"
"............\n"
"........33..\n"
"...4........\n"
"............\n"
"............\n"
".1........4.\n"
".1...4......\n"
".........3..\n"
"........2...\n") == 0);
free(board996747513);
board996747513 = NULL;
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_move(board, 3, 11, 6) == 1 );
assert( gamma_busy_fields(board, 3) == 5 );
assert( gamma_move(board, 4, 13, 3) == 0 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 2, 10, 15) == 1 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_move(board, 3, 1, 14) == 1 );
assert( gamma_move(board, 4, 2, 6) == 1 );
assert( gamma_free_fields(board, 4) == 166 );
assert( gamma_golden_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_move(board, 4, 5, 0) == 1 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 3, 10, 10) == 1 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 4, 8, 1) == 1 );
assert( gamma_move(board, 1, 0, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 1, 12) == 1 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 4, 3, 12) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 2, 11, 7) == 1 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_free_fields(board, 3) == 152 );
assert( gamma_move(board, 4, 14, 7) == 0 );
assert( gamma_move(board, 1, 0, 14) == 1 );
assert( gamma_move(board, 1, 0, 14) == 0 );


char* board217005667 = gamma_board(board);
assert( board217005667 != NULL );
assert( strcmp(board217005667, 
"..........2.\n"
"13..........\n"
"............\n"
".3.4...1....\n"
"..........2.\n"
"....221..331\n"
"..12.1..3...\n"
"......1.....\n"
".....3..3342\n"
"..44.......3\n"
"............\n"
"1....3....1.\n"
".11.......4.\n"
".1...4.....1\n"
".....2..433.\n"
".....4..2...\n") == 0);
free(board217005667);
board217005667 = NULL;
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_move(board, 1, 5, 6) == 1 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_golden_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 1, 9, 11) == 1 );
assert( gamma_move(board, 4, 8, 14) == 1 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 1, 8, 11) == 1 );
assert( gamma_move(board, 1, 7, 12) == 0 );


char* board224211526 = gamma_board(board);
assert( board224211526 != NULL );
assert( strcmp(board224211526, 
"..........2.\n"
"13......4...\n"
"............\n"
".3.4...1....\n"
"........112.\n"
"....221..331\n"
"..12.1..3...\n"
"......1.2...\n"
".....3..3342\n"
"..44.1.....3\n"
"............\n"
"1....3....1.\n"
"411.......4.\n"
"41...4.....1\n"
".....2..433.\n"
".....44.2.1.\n") == 0);
free(board224211526);
board224211526 = NULL;
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 3, 4, 8) == 1 );
assert( gamma_move(board, 3, 6, 3) == 1 );
assert( gamma_move(board, 4, 0, 11) == 1 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );


char* board526890564 = gamma_board(board);
assert( board526890564 != NULL );
assert( strcmp(board526890564, 
"..........2.\n"
"13......4...\n"
"..2.........\n"
".3.4...1....\n"
"4.......112.\n"
"....221..331\n"
"..12.1..3...\n"
"....3.1.2...\n"
".....3..3342\n"
"..44.1.....3\n"
"............\n"
"1....3....1.\n"
"411...3...4.\n"
"41...4.....1\n"
".....2..433.\n"
".....44.2.1.\n") == 0);
free(board526890564);
board526890564 = NULL;
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 0, 14) == 0 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 4, 9, 0) == 1 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_golden_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_move(board, 2, 1, 4) == 1 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 4, 2, 2) == 1 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 7, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 4, 7, 4) == 1 );
assert( gamma_move(board, 4, 9, 5) == 1 );
assert( gamma_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 1, 10, 6) == 1 );
assert( gamma_golden_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_free_fields(board, 2) == 123 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 3, 6, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 1, 13, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_golden_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 4, 12) == 1 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 2, 5, 8) == 1 );
assert( gamma_move(board, 2, 7, 15) == 1 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 3, 1, 1) == 1 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 1, 5, 15) == 1 );
assert( gamma_move(board, 1, 6, 14) == 1 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 10, 8) == 1 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_move(board, 3, 9, 9) == 1 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_move(board, 4, 11, 15) == 1 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_golden_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 2, 2, 15) == 1 );
assert( gamma_free_fields(board, 2) == 103 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 6, 2) == 1 );
assert( gamma_move(board, 3, 9, 4) == 1 );
assert( gamma_move(board, 3, 9, 12) == 1 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_free_fields(board, 1) == 99 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 4, 7, 6) == 1 );
assert( gamma_move(board, 1, 9, 1) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 18 );
assert( gamma_free_fields(board, 2) == 98 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 4, 10, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_move(board, 1, 4, 11) == 1 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 2, 8, 0) == 0 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_free_fields(board, 3) == 94 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 2, 1, 0) == 1 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_move(board, 3, 8, 10) == 1 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_free_fields(board, 3) == 85 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 4, 0, 13) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_move(board, 2, 10, 6) == 0 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 1, 13, 10) == 0 );
assert( gamma_move(board, 2, 7, 14) == 1 );
assert( gamma_move(board, 3, 9, 6) == 1 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 1, 9, 9) == 0 );
assert( gamma_move(board, 2, 3, 0) == 1 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 4, 15, 8) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_free_fields(board, 1) == 77 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_busy_fields(board, 4) == 27 );
assert( gamma_free_fields(board, 4) == 75 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 32 );
assert( gamma_golden_move(board, 1, 8, 0) == 1 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 2, 5) == 1 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 14, 5) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_free_fields(board, 4) == 72 );
assert( gamma_move(board, 1, 0, 9) == 1 );


char* board577088627 = gamma_board(board);
assert( board577088627 != NULL );
assert( strcmp(board577088627, 
"..2..1.2..24\n"
"13.2..124...\n"
"4.22..1.3...\n"
".3.43..1.3..\n"
"44.11..1112.\n"
".113221.3331\n"
"1312.1..33..\n"
"4.4332132.31\n"
"3.4..3213342\n"
".3441124.313\n"
"3232.4..144.\n"
"12..4334.31.\n"
"411..13...4.\n"
"41434421...1\n"
".3...2..433.\n"
"32.22441141.\n") == 0);
free(board577088627);
board577088627 = NULL;
assert( gamma_move(board, 2, 3, 3) == 1 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 3, 13, 9) == 0 );
assert( gamma_move(board, 3, 9, 12) == 0 );
assert( gamma_move(board, 4, 11, 11) == 1 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 1, 8, 15) == 1 );
assert( gamma_move(board, 2, 11, 2) == 0 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_free_fields(board, 2) == 67 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_move(board, 3, 9, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 2, 4, 15) == 1 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_free_fields(board, 3) == 63 );


char* board140379858 = gamma_board(board);
assert( board140379858 != NULL );
assert( strcmp(board140379858, 
"..2.21.21.24\n"
"13.22.124...\n"
"4.22..1.3...\n"
".3.432.1.3..\n"
"44.11..11124\n"
".113221.3331\n"
"1312.1..33..\n"
"4.4332132.31\n"
"3.4.33213342\n"
".3441124.313\n"
"3232.4..144.\n"
"12..4334.31.\n"
"4112.13...4.\n"
"41434421...1\n"
".3...2.4433.\n"
"32.22441141.\n") == 0);
free(board140379858);
board140379858 = NULL;
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board649179873 = gamma_board(board);
assert( board649179873 != NULL );
assert( strcmp(board649179873, 
"..2.21.21.24\n"
"13.22.124...\n"
"4.22..1.3...\n"
".3.432.1.3..\n"
"44.11..11124\n"
".113221.3331\n"
"1312.1..33..\n"
"4.4332132.31\n"
"3.4.33213342\n"
".3441124.313\n"
"3232.4..144.\n"
"12..4334.31.\n"
"4112.13...4.\n"
"41434421...1\n"
".3...2.4433.\n"
"32.22441141.\n") == 0);
free(board649179873);
board649179873 = NULL;
assert( gamma_move(board, 3, 1, 2) == 0 );


char* board122265028 = gamma_board(board);
assert( board122265028 != NULL );
assert( strcmp(board122265028, 
"..2.21.21.24\n"
"13.22.124...\n"
"4.22..1.3...\n"
".3.432.1.3..\n"
"44.11..11124\n"
".113221.3331\n"
"1312.1..33..\n"
"4.4332132.31\n"
"3.4.33213342\n"
".3441124.313\n"
"3232.4..144.\n"
"12..4334.31.\n"
"4112.13...4.\n"
"41434421...1\n"
".3...2.4433.\n"
"32.22441141.\n") == 0);
free(board122265028);
board122265028 = NULL;
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_busy_fields(board, 2) == 28 );
assert( gamma_free_fields(board, 2) == 63 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 11, 5) == 1 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_free_fields(board, 4) == 60 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 1, 9, 15) == 1 );
assert( gamma_golden_move(board, 1, 7, 4) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 5, 14) == 1 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 1, 11, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 4, 7, 8) == 0 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 2, 4, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 4, 14, 11) == 0 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 1, 9, 15) == 0 );
assert( gamma_free_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 12, 11) == 0 );
assert( gamma_free_fields(board, 3) == 55 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 1, 7, 13) == 1 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 2, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 36 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 8, 8) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 1, 2, 4) == 1 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_free_fields(board, 3) == 50 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 42 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 7, 4) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 1, 8, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_free_fields(board, 2) == 48 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 4, 2, 1) == 1 );
assert( gamma_move(board, 4, 11, 12) == 1 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 4, 5, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 34 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_busy_fields(board, 1) == 43 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 4, 13, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 9, 11) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 4, 5) == 0 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_free_fields(board, 3) == 45 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 37 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 3, 1) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 9, 13) == 1 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 4, 3, 15) == 1 );
assert( gamma_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 1, 8, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 44 );
assert( gamma_free_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 1, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 2, 7, 3) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 35 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 3, 3) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 6, 1) == 0 );
assert( gamma_move(board, 1, 5, 6) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_free_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 0, 10) == 1 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_move(board, 4, 3, 7) == 1 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_move(board, 3, 3, 9) == 0 );
assert( gamma_move(board, 3, 9, 5) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_free_fields(board, 4) == 38 );
assert( gamma_golden_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 45 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 38 );


char* board231704440 = gamma_board(board);
assert( board231704440 != NULL );
assert( strcmp(board231704440, 
"..2421.21124\n"
"13.224124.1.\n"
"4322..11332.\n"
"23.432.1.3.4\n"
"44211.411124\n"
"2113221.3331\n"
"1312.1..33..\n"
"4.4332133.31\n"
"3.4433213342\n"
".34411241313\n"
"3232242.1441\n"
"121.4334131.\n"
"41124132..4.\n"
"41434421...1\n"
".34112.4433.\n"
"32.22441141.\n") == 0);
free(board231704440);
board231704440 = NULL;
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_free_fields(board, 4) == 38 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_golden_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 11, 5) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 45 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 3, 11, 3) == 1 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_golden_move(board, 1, 6, 11) == 0 );
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 3, 7, 2) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_free_fields(board, 4) == 36 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 3, 2, 2) == 0 );
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 1, 0, 0) == 0 );


char* board850347675 = gamma_board(board);
assert( board850347675 != NULL );
assert( strcmp(board850347675, 
"..2421.21124\n"
"13.224124.1.\n"
"4322..11332.\n"
"23.432.1.3.4\n"
"44211.411124\n"
"2113221.3331\n"
"1312.1..33..\n"
"4.4332133.31\n"
"3.4433213342\n"
".34411241313\n"
"3232242.1441\n"
"121.4334131.\n"
"41124132..43\n"
"41434421.3.1\n"
".34112.4433.\n"
"32.22441141.\n") == 0);
free(board850347675);
board850347675 = NULL;
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 40 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 4, 4, 10) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 10, 2) == 1 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 37 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 10, 9) == 1 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_free_fields(board, 3) == 33 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 3, 9, 12) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );


char* board440334870 = gamma_board(board);
assert( board440334870 != NULL );
assert( strcmp(board440334870, 
"..2421.21124\n"
"13.224124.1.\n"
"4322..11332.\n"
"232432.1.3.4\n"
"44211.411124\n"
"2113221.3331\n"
"1312.1..332.\n"
"4.4332133.31\n"
"3.4433213342\n"
".34411241313\n"
"3232242.1441\n"
"121.4334131.\n"
"41124132..43\n"
"414344212331\n"
".34112.44332\n"
"32.22441141.\n") == 0);
free(board440334870);
board440334870 = NULL;
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 4, 2, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_golden_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 2, 1, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 41 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 1, 0, 15) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 9, 12) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_free_fields(board, 2) == 28 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_busy_fields(board, 1) == 46 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_golden_move(board, 4, 9, 7) == 1 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_free_fields(board, 2) == 28 );


char* board423637228 = gamma_board(board);
assert( board423637228 != NULL );
assert( strcmp(board423637228, 
"1.2421.21124\n"
"13.224124.1.\n"
"4322..11332.\n"
"232432.1.3.4\n"
"44211.411124\n"
"2113221.3331\n"
"1312.1..332.\n"
"4.4332133.31\n"
"324433213442\n"
".34411241313\n"
"3232242.1441\n"
"121.4334131.\n"
"41124132..43\n"
"414344212331\n"
".34112.44332\n"
"32422441141.\n") == 0);
free(board423637228);
board423637228 = NULL;
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_free_fields(board, 4) == 28 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_free_fields(board, 1) == 17 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 39 );
assert( gamma_move(board, 3, 1, 0) == 0 );


char* board287559912 = gamma_board(board);
assert( board287559912 != NULL );
assert( strcmp(board287559912, 
"1.2421.21124\n"
"13.224124.1.\n"
"4322..11332.\n"
"232432.1.3.4\n"
"44211.411124\n"
"2113221.3331\n"
"1312.1..332.\n"
"4.4332133.31\n"
"324433213442\n"
".34411241313\n"
"3232242.1441\n"
"121.4334131.\n"
"41124132..43\n"
"414344212331\n"
".34112.44332\n"
"32422441141.\n") == 0);
free(board287559912);
board287559912 = NULL;
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 14, 9) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_move(board, 4, 1, 4) == 0 );
assert( gamma_move(board, 4, 9, 3) == 1 );


gamma_delete(board);

    return 0;
}
