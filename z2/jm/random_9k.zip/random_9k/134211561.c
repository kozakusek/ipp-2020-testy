#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 134211561
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(15, 16, 5, 26);
assert( board != NULL );


assert( gamma_move(board, 1, 7, 9) == 1 );
assert( gamma_move(board, 3, 9, 13) == 1 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_move(board, 4, 13, 1) == 1 );
assert( gamma_move(board, 4, 3, 1) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 11, 12) == 1 );
assert( gamma_move(board, 5, 14, 14) == 1 );
assert( gamma_free_fields(board, 5) == 233 );


char* board978055565 = gamma_board(board);
assert( board978055565 != NULL );
assert( strcmp(board978055565, 
"...............\n"
"..............5\n"
".........3.....\n"
"...........5...\n"
"...............\n"
".........3.....\n"
".......1.......\n"
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"...............\n"
"...4.........4.\n"
"...............\n") == 0);
free(board978055565);
board978055565 = NULL;
assert( gamma_move(board, 1, 8, 14) == 1 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 3, 12, 0) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 15) == 1 );
assert( gamma_move(board, 4, 12, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 4 );
assert( gamma_golden_move(board, 4, 14, 14) == 1 );
assert( gamma_move(board, 5, 14, 0) == 1 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 1, 3, 4) == 1 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 2, 12) == 1 );
assert( gamma_move(board, 3, 8, 3) == 1 );
assert( gamma_free_fields(board, 3) == 223 );
assert( gamma_move(board, 4, 8, 1) == 1 );
assert( gamma_move(board, 5, 5, 15) == 1 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_free_fields(board, 5) == 220 );
assert( gamma_move(board, 1, 3, 9) == 1 );
assert( gamma_move(board, 1, 5, 15) == 0 );


char* board332035733 = gamma_board(board);
assert( board332035733 != NULL );
assert( strcmp(board332035733, 
".....5..4......\n"
"........1.....4\n"
".........3.....\n"
"..3........5...\n"
"...............\n"
".........3.....\n"
"..51...1.......\n"
"............4..\n"
"........2......\n"
"...............\n"
"...............\n"
"...1...........\n"
"........3......\n"
"5..............\n"
"...4....4....4.\n"
"............3.5\n") == 0);
free(board332035733);
board332035733 = NULL;
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 1, 9) == 1 );
assert( gamma_move(board, 4, 2, 3) == 1 );
assert( gamma_move(board, 5, 11, 14) == 1 );
assert( gamma_move(board, 1, 1, 3) == 1 );
assert( gamma_move(board, 1, 1, 14) == 1 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );


char* board387351293 = gamma_board(board);
assert( board387351293 != NULL );
assert( strcmp(board387351293, 
".....5..4......\n"
".1......1..5..4\n"
".........3.....\n"
"2.3........5...\n"
"...............\n"
".........3.....\n"
".451...1.......\n"
"............4..\n"
"........2......\n"
"...............\n"
"...............\n"
"...1...........\n"
".14.....3......\n"
"5..............\n"
"...4....4....4.\n"
"............3.5\n") == 0);
free(board387351293);
board387351293 = NULL;
assert( gamma_move(board, 3, 12, 7) == 1 );
assert( gamma_move(board, 4, 1, 1) == 1 );
assert( gamma_move(board, 5, 3, 8) == 1 );
assert( gamma_free_fields(board, 5) == 210 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 2, 13, 12) == 1 );
assert( gamma_move(board, 4, 11, 7) == 1 );
assert( gamma_free_fields(board, 4) == 207 );
assert( gamma_move(board, 5, 0, 1) == 1 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_move(board, 1, 10, 3) == 1 );
assert( gamma_move(board, 2, 8, 2) == 1 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_move(board, 4, 0, 13) == 1 );
assert( gamma_move(board, 5, 2, 2) == 1 );
assert( gamma_move(board, 5, 2, 8) == 1 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 3, 9, 0) == 1 );
assert( gamma_free_fields(board, 3) == 196 );
assert( gamma_move(board, 4, 1, 2) == 1 );


char* board379956553 = gamma_board(board);
assert( board379956553 != NULL );
assert( strcmp(board379956553, 
".....5..4......\n"
".1......1..5..4\n"
"4........3.....\n"
"2.3........5.2.\n"
"...............\n"
"..1......3.....\n"
".451...1.......\n"
"..55........4..\n"
"........2..43..\n"
"...............\n"
"...............\n"
"...1...1.1.....\n"
".14.....331....\n"
"545.....2......\n"
"54.42...4....4.\n"
".........3..3.5\n") == 0);
free(board379956553);
board379956553 = NULL;
assert( gamma_move(board, 5, 10, 12) == 1 );
assert( gamma_move(board, 1, 11, 5) == 1 );
assert( gamma_move(board, 2, 5, 4) == 1 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_move(board, 4, 2, 2) == 0 );
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_busy_fields(board, 5) == 12 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 15, 8) == 0 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 10, 7) == 1 );
assert( gamma_move(board, 4, 14, 6) == 1 );
assert( gamma_move(board, 5, 8, 4) == 1 );
assert( gamma_move(board, 1, 3, 12) == 1 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 3, 5, 7) == 1 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 4, 5, 13) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 15, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_move(board, 3, 8, 5) == 1 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 4, 11, 0) == 1 );
assert( gamma_move(board, 5, 12, 5) == 1 );
assert( gamma_move(board, 5, 5, 0) == 1 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 5, 7, 14) == 1 );
assert( gamma_move(board, 5, 2, 6) == 1 );
assert( gamma_move(board, 1, 9, 4) == 0 );
assert( gamma_move(board, 2, 13, 15) == 1 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 4, 9, 2) == 1 );
assert( gamma_free_fields(board, 4) == 168 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_move(board, 1, 7, 3) == 1 );


char* board285943446 = gamma_board(board);
assert( board285943446 != NULL );
assert( strcmp(board285943446, 
".....5..4....2.\n"
".13....51..5..4\n"
"4....4...3.....\n"
"2.31......55.2.\n"
"........2......\n"
"..1......3.....\n"
".451...13......\n"
"..55........4..\n"
"4....32.2.443..\n"
"..5...........4\n"
"......1.3..15..\n"
"..51.2.151.....\n"
".14....1331....\n"
"545.....24.....\n"
"54.422.44....4.\n"
".....54..3.43.5\n") == 0);
free(board285943446);
board285943446 = NULL;
assert( gamma_move(board, 2, 12, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 4, 2, 13) == 1 );
assert( gamma_free_fields(board, 4) == 165 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 5, 14, 10) == 1 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 13) == 1 );


char* board374449154 = gamma_board(board);
assert( board374449154 != NULL );
assert( strcmp(board374449154, 
".....5..4....2.\n"
".13....51..5..4\n"
"4.4.44...3.....\n"
"2.312.....55.2.\n"
"........2......\n"
"..1......3....5\n"
".451...13......\n"
"..55........4..\n"
"4....32.2.443..\n"
"..5.........2.4\n"
"......1.3..15..\n"
"..51.2.151.....\n"
".14...21331....\n"
"545.....24.....\n"
"54.422.44....4.\n"
"5....54..3.43.5\n") == 0);
free(board374449154);
board374449154 = NULL;
assert( gamma_move(board, 5, 0, 8) == 1 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_move(board, 1, 11, 2) == 1 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 7, 1) == 0 );
assert( gamma_move(board, 3, 12, 13) == 1 );
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_free_fields(board, 4) == 156 );


char* board879458947 = gamma_board(board);
assert( board879458947 != NULL );
assert( strcmp(board879458947, 
".....5..4....2.\n"
".13....51..5..4\n"
"4.4.44...3..3..\n"
"2.312.....55.2.\n"
"........2......\n"
"..1......3....5\n"
".451...13......\n"
"5.55........4..\n"
"4....32.2.443..\n"
"..5.........2.4\n"
"......1.3..15..\n"
"..51.2.151.....\n"
".145..21331....\n"
"545.....24.1...\n"
"54.422.44....4.\n"
"5....54..3.43.5\n") == 0);
free(board879458947);
board879458947 = NULL;
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_golden_move(board, 2, 9, 3) == 1 );
assert( gamma_move(board, 3, 13, 3) == 1 );
assert( gamma_free_fields(board, 3) == 154 );


char* board419802313 = gamma_board(board);
assert( board419802313 != NULL );
assert( strcmp(board419802313, 
".....5..4....2.\n"
".13....51..5..4\n"
"4.4.44...3..3..\n"
"2.312.....55.2.\n"
"........2......\n"
"..1......3....5\n"
".451...13......\n"
"5.55........4..\n"
"4.1..32.2.443..\n"
"..5.........2.4\n"
"......1.3..15..\n"
"..51.2.151.....\n"
".145..21321..3.\n"
"545.....24.1...\n"
"54.422.44....4.\n"
"5....54..3.43.5\n") == 0);
free(board419802313);
board419802313 = NULL;
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_free_fields(board, 4) == 154 );
assert( gamma_move(board, 5, 14, 12) == 1 );
assert( gamma_busy_fields(board, 5) == 22 );
assert( gamma_move(board, 1, 14, 9) == 1 );
assert( gamma_move(board, 1, 11, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 0) == 1 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_free_fields(board, 3) == 150 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 3) == 1 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_free_fields(board, 4) == 148 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 12, 9) == 1 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_free_fields(board, 2) == 146 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 4, 8, 0) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 1, 6) == 1 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 11, 4) == 1 );
assert( gamma_move(board, 3, 12, 15) == 1 );
assert( gamma_golden_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 7, 7) == 1 );
assert( gamma_move(board, 5, 3, 0) == 1 );
assert( gamma_move(board, 5, 11, 15) == 1 );
assert( gamma_move(board, 1, 11, 14) == 0 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_free_fields(board, 1) == 138 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 4, 10, 13) == 1 );
assert( gamma_move(board, 5, 5, 9) == 1 );
assert( gamma_move(board, 5, 13, 8) == 1 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 7, 5) == 1 );
assert( gamma_free_fields(board, 2) == 134 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 0, 13) == 0 );
assert( gamma_move(board, 1, 8, 10) == 1 );
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 3, 2, 7) == 0 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 4, 4, 7) == 1 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 14, 7) == 1 );
assert( gamma_golden_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 3, 9, 7) == 1 );
assert( gamma_move(board, 3, 13, 5) == 1 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_move(board, 5, 2, 3) == 0 );
assert( gamma_free_fields(board, 5) == 126 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 1, 12, 6) == 0 );
assert( gamma_move(board, 2, 3, 2) == 1 );
assert( gamma_move(board, 3, 14, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 6, 11) == 1 );
assert( gamma_move(board, 5, 3, 1) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 14, 14) == 0 );
assert( gamma_free_fields(board, 1) == 124 );


char* board722396850 = gamma_board(board);
assert( board722396850 != NULL );
assert( strcmp(board722396850, 
".....5..4..532.\n"
".13....51..5..4\n"
"4.4144...34.3..\n"
"2.312.....55.25\n"
"......5.2......\n"
"..11....13....5\n"
"4451.5.13...2.1\n"
"5.55.......145.\n"
"4.13432423443.5\n"
".55.....4...2.4\n"
"......123.3153.\n"
"..51.2.151.2...\n"
".145..21321..34\n"
"5452....24.1...\n"
"54.422.44....4.\n"
"5..5.54.43243.5\n") == 0);
free(board722396850);
board722396850 = NULL;
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 14, 15) == 1 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 5, 1, 12) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 9, 14) == 1 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 3, 4, 0) == 1 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_golden_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_busy_fields(board, 3) == 22 );


char* board975539944 = gamma_board(board);
assert( board975539944 != NULL );
assert( strcmp(board975539944, 
".....5..4..5323\n"
".13....511.5..4\n"
"4.4144...34.3..\n"
"25312.....55125\n"
"..3...5.2......\n"
"..11..2.13....5\n"
"4451.5.13...2.1\n"
"5.55....4..145.\n"
"4.13432423443.5\n"
".55.....42..2.4\n"
"..2...123.3153.\n"
"..51.2.151.2...\n"
".145..21321..34\n"
"5451....24.1...\n"
"54.422344....4.\n"
"5..5354.43243.5\n") == 0);
free(board975539944);
board975539944 = NULL;
assert( gamma_move(board, 5, 11, 1) == 1 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 0, 6) == 1 );
assert( gamma_move(board, 5, 0, 10) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_free_fields(board, 1) == 108 );


char* board246191162 = gamma_board(board);
assert( board246191162 != NULL );
assert( strcmp(board246191162, 
".....5..4..5323\n"
".13....511.5.14\n"
"4.4144...34.3..\n"
"25312.....55125\n"
"..3...5.2......\n"
"5.11..2.13....5\n"
"4451.5.13...2.1\n"
"5.55....4..145.\n"
"4.13432423443.5\n"
"355.....42..2.4\n"
"..2...123.3153.\n"
"..51.2.151.2...\n"
".145.121321..34\n"
"5451....24.1...\n"
"54.422344..5.4.\n"
"5..5354.43243.5\n") == 0);
free(board246191162);
board246191162 = NULL;
assert( gamma_move(board, 2, 13, 13) == 1 );


char* board967661937 = gamma_board(board);
assert( board967661937 != NULL );
assert( strcmp(board967661937, 
".....5..4..5323\n"
".13....511.5.14\n"
"4.4144...34.32.\n"
"25312.....55125\n"
"..3...5.2......\n"
"5.11..2.13....5\n"
"4451.5.13...2.1\n"
"5.55....4..145.\n"
"4.13432423443.5\n"
"355.....42..2.4\n"
"..2...123.3153.\n"
"..51.2.151.2...\n"
".145.121321..34\n"
"5451....24.1...\n"
"54.422344..5.4.\n"
"5..5354.43243.5\n") == 0);
free(board967661937);
board967661937 = NULL;
assert( gamma_move(board, 3, 12, 14) == 1 );
assert( gamma_move(board, 3, 13, 12) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 5, 9, 4) == 0 );
assert( gamma_move(board, 5, 5, 10) == 1 );
assert( gamma_golden_move(board, 1, 15, 5) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 4, 13, 11) == 1 );
assert( gamma_move(board, 5, 4, 15) == 1 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 5, 14, 6) == 0 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 1, 8, 13) == 1 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 4, 5, 3) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 5, 6, 11) == 0 );
assert( gamma_busy_fields(board, 5) == 34 );
assert( gamma_free_fields(board, 5) == 100 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 29 );
assert( gamma_move(board, 2, 6, 13) == 1 );
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_move(board, 3, 5, 3) == 0 );
assert( gamma_busy_fields(board, 3) == 25 );
assert( gamma_move(board, 4, 11, 3) == 1 );
assert( gamma_move(board, 4, 13, 10) == 1 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 4, 10) == 1 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 5, 8, 10) == 0 );
assert( gamma_move(board, 5, 12, 4) == 1 );
assert( gamma_free_fields(board, 5) == 93 );
assert( gamma_move(board, 2, 11, 10) == 1 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_move(board, 4, 10, 15) == 0 );
assert( gamma_move(board, 5, 13, 7) == 1 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 12, 10) == 1 );
assert( gamma_move(board, 2, 11, 11) == 1 );


char* board917188227 = gamma_board(board);
assert( board917188227 != NULL );
assert( strcmp(board917188227, 
"....55..4..5323\n"
".13....511.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2..2.4.\n"
"5.11152.13.2145\n"
"4451.5.131..2.1\n"
"5.55..1.4..145.\n"
"4.1343242344355\n"
"355.3...42..2.4\n"
"..2...123.3153.\n"
"..51.2.151.25..\n"
".145.1213214.34\n"
"5451....24.1...\n"
"54.422344..5.4.\n"
"5..5354.43243.5\n") == 0);
free(board917188227);
board917188227 = NULL;
assert( gamma_move(board, 3, 7, 15) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_free_fields(board, 4) == 37 );


char* board973423713 = gamma_board(board);
assert( board973423713 != NULL );
assert( strcmp(board973423713, 
"....55.34..5323\n"
".13....511.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2..2.4.\n"
"5.11152.13.2145\n"
"4451.5.131..2.1\n"
"5.55..1.4..145.\n"
"4.1343242344355\n"
"355.3...42..2.4\n"
"..2...123.3153.\n"
"..51.2.151.25..\n"
".145.1213214.34\n"
"5451....24.1...\n"
"54.422344..5.4.\n"
"5..5354.43243.5\n") == 0);
free(board973423713);
board973423713 = NULL;
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_free_fields(board, 1) == 88 );
assert( gamma_move(board, 2, 12, 2) == 1 );
assert( gamma_move(board, 2, 13, 15) == 0 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 4, 13, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 27 );


char* board468418932 = gamma_board(board);
assert( board468418932 != NULL );
assert( strcmp(board468418932, 
"....55.34..5323\n"
".13....511.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2..2.4.\n"
"5.11152.13.2145\n"
"445135.131..2.1\n"
"5.55..1.4..145.\n"
"4.1343242344355\n"
"355.3...42..2.4\n"
"..2...123.3153.\n"
"..51.2.151.25..\n"
".145.1213214.34\n"
"5451....24.12..\n"
"54.422344..5.4.\n"
"5..5354.43243.5\n") == 0);
free(board468418932);
board468418932 = NULL;
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 14, 8) == 1 );
assert( gamma_move(board, 4, 8, 10) == 0 );
assert( gamma_move(board, 4, 12, 4) == 0 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_free_fields(board, 5) == 84 );
assert( gamma_move(board, 1, 2, 7) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 15, 3) == 0 );
assert( gamma_move(board, 2, 0, 15) == 1 );
assert( gamma_move(board, 3, 4, 4) == 1 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 5, 13, 8) == 0 );
assert( gamma_move(board, 1, 4, 14) == 1 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 14, 11) == 1 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_free_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 5, 14, 1) == 1 );
assert( gamma_move(board, 2, 11, 9) == 1 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );


char* board853111710 = gamma_board(board);
assert( board853111710 != NULL );
assert( strcmp(board853111710, 
"2...55.34..5323\n"
".13.1..511.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2..2.42\n"
"5.11152.13.2145\n"
"445135.131.22.1\n"
"5.55..1.4..1453\n"
"4.1343242344355\n"
"355.3...42..2.4\n"
"..2...123.3153.\n"
"..5132.151.25..\n"
".145.1213214.34\n"
"5451....24.12..\n"
"54.422344..5.45\n"
"55.5354.43243.5\n") == 0);
free(board853111710);
board853111710 = NULL;
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_move(board, 2, 14, 15) == 0 );
assert( gamma_busy_fields(board, 2) == 30 );
assert( gamma_free_fields(board, 2) == 78 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 5, 4, 0) == 0 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 1, 14, 5) == 1 );
assert( gamma_free_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 33 );
assert( gamma_move(board, 5, 15, 10) == 0 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 4, 6, 2) == 0 );
assert( gamma_move(board, 1, 10, 10) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 4, 12, 14) == 0 );
assert( gamma_golden_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_golden_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 3, 13, 0) == 1 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 4, 10, 6) == 1 );
assert( gamma_move(board, 5, 12, 8) == 0 );
assert( gamma_move(board, 5, 12, 2) == 0 );
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 1, 9, 8) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 13) == 0 );
assert( gamma_move(board, 3, 2, 4) == 0 );
assert( gamma_move(board, 4, 6, 13) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_free_fields(board, 4) == 29 );


char* board439847549 = gamma_board(board);
assert( board439847549 != NULL );
assert( strcmp(board439847549, 
"2...55.34..5323\n"
".13.1..511.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2..2.42\n"
"5.11152.13.2145\n"
"445135.131.22.1\n"
"5.55..1.41.1453\n"
"4.1343242344355\n"
"355.3...424.2.4\n"
"..2...123.31531\n"
"..5132.151.25..\n"
".145.1213214.34\n"
"5451....24.12..\n"
"54.422344.25.45\n"
"55.5354.4324335\n") == 0);
free(board439847549);
board439847549 = NULL;
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_move(board, 1, 4, 2) == 1 );
assert( gamma_move(board, 1, 12, 3) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 14, 7) == 0 );
assert( gamma_move(board, 3, 4, 14) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 12, 11) == 1 );
assert( gamma_move(board, 5, 8, 10) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_free_fields(board, 2) == 71 );
assert( gamma_move(board, 3, 12, 14) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 5, 10, 7) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 2, 10, 3) == 0 );
assert( gamma_move(board, 3, 13, 13) == 0 );
assert( gamma_move(board, 4, 11, 5) == 0 );


char* board871438134 = gamma_board(board);
assert( board871438134 != NULL );
assert( strcmp(board871438134, 
"2...55.34..5323\n"
".13.1..511.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2..2442\n"
"5.11152.13.2145\n"
"445135.131.22.1\n"
"5.55..1.41.1453\n"
"4.1343242344355\n"
"355.3...424.2.4\n"
"..2...123.31531\n"
"..5132.151.25..\n"
".145.1213214.34\n"
"54511...24.12..\n"
"54.422344.25.45\n"
"55.5354.4324335\n") == 0);
free(board871438134);
board871438134 = NULL;
assert( gamma_move(board, 5, 6, 5) == 0 );
assert( gamma_move(board, 1, 11, 0) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 3, 4, 10) == 0 );
assert( gamma_move(board, 3, 4, 4) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 4, 13, 0) == 0 );


char* board536449333 = gamma_board(board);
assert( board536449333 != NULL );
assert( strcmp(board536449333, 
"2...55.34..5323\n"
".13.1..511.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2..2442\n"
"5.11152.13.2145\n"
"445135.131.22.1\n"
"5.55..1.41.1453\n"
"4.1343242344355\n"
"355.3...424.2.4\n"
"..2...123.31531\n"
"..5132.151.25..\n"
".145.1213214.34\n"
"54511...24.12..\n"
"54.422344.25.45\n"
"55.5354.4324335\n") == 0);
free(board536449333);
board536449333 = NULL;
assert( gamma_move(board, 5, 14, 3) == 0 );
assert( gamma_golden_move(board, 5, 0, 6) == 1 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 1, 5, 9) == 0 );


char* board702120263 = gamma_board(board);
assert( board702120263 != NULL );
assert( strcmp(board702120263, 
"2...55.34..5323\n"
".13.1..511.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2..2442\n"
"5.11152.13.2145\n"
"445135.131.22.1\n"
"5.55..1.41.1453\n"
"4.1343242344355\n"
"555.3...424.2.4\n"
"..2...123.31531\n"
"..5132.151.25..\n"
".145.1213214.34\n"
"54511...24.12..\n"
"54.422344.25.45\n"
"55.5354.4324335\n") == 0);
free(board702120263);
board702120263 = NULL;
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_free_fields(board, 3) == 71 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_free_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 8, 4) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_golden_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_move(board, 2, 3, 15) == 1 );
assert( gamma_golden_move(board, 2, 13, 9) == 0 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 5, 0, 7) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 5, 8, 10) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 1, 10, 9) == 1 );
assert( gamma_free_fields(board, 1) == 34 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 13) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_free_fields(board, 3) == 68 );
assert( gamma_move(board, 4, 1, 11) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_free_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 14, 9) == 0 );
assert( gamma_move(board, 5, 12, 1) == 1 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 4, 5, 14) == 1 );
assert( gamma_move(board, 5, 13, 7) == 0 );
assert( gamma_move(board, 1, 0, 10) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_free_fields(board, 1) == 65 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_move(board, 5, 10, 11) == 1 );
assert( gamma_golden_move(board, 5, 11, 14) == 0 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 3, 12, 15) == 0 );
assert( gamma_golden_move(board, 3, 7, 14) == 1 );


char* board396090661 = gamma_board(board);
assert( board396090661 != NULL );
assert( strcmp(board396090661, 
"2..255.34..5323\n"
".13.14.311.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2.52442\n"
"5.11152.13.2145\n"
"445135.131122.1\n"
"5.55..1.41.1453\n"
"4.1343242344355\n"
"555.3.5.424.2.4\n"
"..2..2123.31531\n"
"..51321151.25..\n"
".145.1213214.34\n"
"54511...24.12..\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board396090661);
board396090661 = NULL;
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 11, 3) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_free_fields(board, 4) == 27 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_free_fields(board, 5) == 63 );
assert( gamma_move(board, 1, 13, 14) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 3, 14, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 30 );
assert( gamma_move(board, 4, 9, 13) == 0 );


char* board788901423 = gamma_board(board);
assert( board788901423 != NULL );
assert( strcmp(board788901423, 
"2..255.34..5323\n"
".13.14.311.5314\n"
"4.41442.134.32.\n"
"25312.2...55125\n"
"..3...5.2.52442\n"
"5.11152.13.2145\n"
"445135.131122.1\n"
"5.55..1.41.1453\n"
"4.1343242344355\n"
"555.3.5.424.2.4\n"
"..2..2123.31531\n"
"..51321151.25..\n"
".145.1213214.34\n"
"54511...24.12..\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board788901423);
board788901423 = NULL;
assert( gamma_move(board, 5, 15, 9) == 0 );
assert( gamma_free_fields(board, 5) == 63 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_move(board, 3, 7, 12) == 1 );
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_move(board, 4, 10, 8) == 1 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 1, 4, 10) == 0 );
assert( gamma_free_fields(board, 1) == 60 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 7, 8) == 1 );


char* board838560119 = gamma_board(board);
assert( board838560119 != NULL );
assert( strcmp(board838560119, 
"2..255.34..5323\n"
".13.14.311.5314\n"
"4.41442.134.32.\n"
"25312.23..55125\n"
"..3...5.2.52442\n"
"5.11152.13.2145\n"
"445135.131122.1\n"
"5.554.124141453\n"
"4.1343242344355\n"
"555.3.5.424.2.4\n"
"..2..2123.31531\n"
"..51321151.25..\n"
".145.1213214.34\n"
"54511...24.12..\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board838560119);
board838560119 = NULL;
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 13, 7) == 0 );
assert( gamma_golden_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 5, 13, 14) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 2, 7, 6) == 1 );
assert( gamma_busy_fields(board, 2) == 35 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 4, 4, 1) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 6, 2) == 1 );


char* board991943395 = gamma_board(board);
assert( board991943395 != NULL );
assert( strcmp(board991943395, 
"2..255.34..5323\n"
".13.14.311.5314\n"
"4.41442.134.32.\n"
"25312.23..55125\n"
"..3...5.2.52442\n"
"5.11152.13.2145\n"
"445135.131122.1\n"
"5.554.124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..51321151.25..\n"
".145.1213214.34\n"
"54511.5.24.12..\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board991943395);
board991943395 = NULL;
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_free_fields(board, 5) == 56 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 4, 13, 14) == 0 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 0, 1) == 0 );
assert( gamma_free_fields(board, 1) == 56 );
assert( gamma_move(board, 2, 8, 15) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 15, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 4, 4) == 0 );


char* board851360490 = gamma_board(board);
assert( board851360490 != NULL );
assert( strcmp(board851360490, 
"2..255.34..5323\n"
".13.14.311.5314\n"
"4.41442.134.32.\n"
"25312.23..55125\n"
"..3...5.2.52442\n"
"5.11152.13.2145\n"
"445135.131122.1\n"
"5.554.124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..51321151.25..\n"
".145.1213214.34\n"
"54511.5.24412..\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board851360490);
board851360490 = NULL;
assert( gamma_move(board, 5, 2, 14) == 0 );
assert( gamma_busy_fields(board, 5) == 42 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_free_fields(board, 1) == 56 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 14, 0) == 0 );
assert( gamma_move(board, 4, 5, 12) == 1 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 3, 12, 15) == 0 );
assert( gamma_busy_fields(board, 3) == 31 );
assert( gamma_move(board, 5, 13, 4) == 1 );
assert( gamma_move(board, 5, 7, 9) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 1, 8, 12) == 1 );


char* board505482755 = gamma_board(board);
assert( board505482755 != NULL );
assert( strcmp(board505482755, 
"2..255.34..5323\n"
".13.14.311.5314\n"
"4.41442.134.32.\n"
"253124231.55125\n"
"..3...5.2.52442\n"
"5.11152.13.2145\n"
"445135.131122.1\n"
"5.554.124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..51321151.255.\n"
".145.1213214.34\n"
"54511.5.24412..\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board505482755);
board505482755 = NULL;
assert( gamma_move(board, 3, 15, 2) == 0 );
assert( gamma_move(board, 3, 2, 15) == 1 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_golden_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 2, 11, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 35 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 4, 12, 10) == 0 );
assert( gamma_move(board, 5, 10, 1) == 0 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_free_fields(board, 1) == 52 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 32 );
assert( gamma_golden_move(board, 3, 5, 7) == 0 );


char* board618221986 = gamma_board(board);
assert( board618221986 != NULL );
assert( strcmp(board618221986, 
"2.3255.34..5323\n"
".13.14.311.5314\n"
"4.41442.134.32.\n"
"253124231.55125\n"
"..3...5.2.52442\n"
"5.11152.13.2145\n"
"445135.131122.1\n"
"5.554.124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..51321151.255.\n"
".145.1213214.34\n"
"54511.5.24412..\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board618221986);
board618221986 = NULL;
assert( gamma_move(board, 4, 10, 1) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_free_fields(board, 2) == 27 );
assert( gamma_move(board, 3, 3, 12) == 0 );
assert( gamma_free_fields(board, 3) == 23 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_free_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 9, 14) == 0 );
assert( gamma_free_fields(board, 5) == 52 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 12, 15) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 4, 11, 15) == 0 );
assert( gamma_move(board, 5, 2, 14) == 0 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_move(board, 1, 10, 4) == 1 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 12, 14) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_move(board, 3, 5, 8) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_golden_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 1, 14, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 9, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_move(board, 5, 14, 7) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_golden_move(board, 1, 5, 5) == 0 );
assert( gamma_move(board, 2, 11, 3) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_move(board, 3, 13, 2) == 1 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_free_fields(board, 5) == 47 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 1, 10, 7) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 13, 14) == 0 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 4, 15, 10) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board531992646 = gamma_board(board);
assert( board531992646 != NULL );
assert( strcmp(board531992646, 
"2.3255.34..5323\n"
".13.14.311.5314\n"
"4141442.134.32.\n"
"253124231.55125\n"
"..3...5.2.52442\n"
"5.11152.1322145\n"
"445135.131122.1\n"
"5.5543124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..513211511255.\n"
".145.1213214.34\n"
"54511.5.244123.\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board531992646);
board531992646 = NULL;
assert( gamma_move(board, 2, 3, 4) == 0 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_move(board, 3, 14, 8) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 4, 1) == 0 );


char* board365050775 = gamma_board(board);
assert( board365050775 != NULL );
assert( strcmp(board365050775, 
"2.3255.34..5323\n"
".13.14.311.5314\n"
"4141442.134.32.\n"
"253124231.55125\n"
"..3...5.2.52442\n"
"5.11152.1322145\n"
"4451352131122.1\n"
"5.5543124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..513211511255.\n"
".145.1213214.34\n"
"54511.5.244123.\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board365050775);
board365050775 = NULL;
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 2, 8, 13) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 5, 14, 13) == 1 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );


char* board561194533 = gamma_board(board);
assert( board561194533 != NULL );
assert( strcmp(board561194533, 
"2.3255.34..5323\n"
".13.14.311.5314\n"
"4141442.134.325\n"
"253124231.55125\n"
"..3...5.2.52442\n"
"5.11152.1322145\n"
"4451352131122.1\n"
"5.5543124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..513211511255.\n"
".145.1213214.34\n"
"54511.5.244123.\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board561194533);
board561194533 = NULL;
assert( gamma_move(board, 1, 11, 7) == 0 );


char* board621502762 = gamma_board(board);
assert( board621502762 != NULL );
assert( strcmp(board621502762, 
"2.3255.34..5323\n"
".13.14.311.5314\n"
"4141442.134.325\n"
"253124231.55125\n"
"..3...5.2.52442\n"
"5.11152.1322145\n"
"4451352131122.1\n"
"5.5543124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..513211511255.\n"
".145.1213214.34\n"
"54511.5.244123.\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board621502762);
board621502762 = NULL;
assert( gamma_move(board, 3, 12, 9) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_move(board, 5, 11, 9) == 0 );
assert( gamma_move(board, 5, 14, 2) == 1 );
assert( gamma_move(board, 1, 13, 11) == 0 );
assert( gamma_free_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 13, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_free_fields(board, 4) == 18 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 45 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_free_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 2, 2, 10) == 0 );
assert( gamma_move(board, 3, 3, 5) == 0 );


char* board467240688 = gamma_board(board);
assert( board467240688 != NULL );
assert( strcmp(board467240688, 
"2.3255.34..5323\n"
".13.14.311.5314\n"
"4141442.134.325\n"
"253124231.55125\n"
"..3...5.2.52442\n"
"5.11152.1322145\n"
"4451352131122.1\n"
"5.5543124141453\n"
"4.1343242344355\n"
"555.3.52424.2.4\n"
"..2..2123.31531\n"
"..513211511255.\n"
".145.1213214.34\n"
"54511.5.2441235\n"
"54.422344.25545\n"
"55.5354.4324335\n") == 0);
free(board467240688);
board467240688 = NULL;
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 5, 12, 9) == 0 );
assert( gamma_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 40 );
assert( gamma_free_fields(board, 4) == 18 );
assert( gamma_move(board, 5, 12, 13) == 0 );
assert( gamma_busy_fields(board, 5) == 45 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 2, 5) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 3, 8, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_free_fields(board, 3) == 19 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 5, 13, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 45 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_golden_move(board, 1, 3, 4) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 37 );
assert( gamma_move(board, 3, 13, 15) == 0 );
assert( gamma_move(board, 3, 7, 9) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 12, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 12, 9) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 40 );
assert( gamma_free_fields(board, 1) == 44 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 2, 6, 14) == 1 );
assert( gamma_move(board, 3, 9, 13) == 0 );
assert( gamma_move(board, 4, 6, 5) == 0 );
assert( gamma_move(board, 5, 1, 9) == 0 );
assert( gamma_move(board, 5, 10, 2) == 0 );


gamma_delete(board);

    return 0;
}
