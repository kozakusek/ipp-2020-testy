#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 146996451
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(3, 53, 4, 15);
assert( board != NULL );


assert( gamma_move(board, 2, 47, 0) == 0 );
assert( gamma_move(board, 2, 2, 17) == 1 );
assert( gamma_busy_fields(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 3, 2, 38) == 1 );
assert( gamma_move(board, 4, 2, 39) == 1 );
assert( gamma_free_fields(board, 4) == 155 );
assert( gamma_move(board, 1, 31, 2) == 0 );
assert( gamma_move(board, 1, 2, 29) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );


char* board436583462 = gamma_board(board);
assert( board436583462 != NULL );
assert( strcmp(board436583462, 
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..4\n"
"..3\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n") == 0);
free(board436583462);
board436583462 = NULL;
assert( gamma_move(board, 3, 0, 38) == 1 );
assert( gamma_golden_move(board, 3, 39, 2) == 0 );
assert( gamma_move(board, 4, 2, 8) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 45) == 1 );
assert( gamma_move(board, 2, 1, 3) == 1 );
assert( gamma_move(board, 3, 16, 1) == 0 );
assert( gamma_move(board, 3, 1, 51) == 1 );
assert( gamma_move(board, 4, 1, 39) == 1 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 44, 0) == 0 );
assert( gamma_move(board, 1, 2, 43) == 1 );
assert( gamma_free_fields(board, 1) == 147 );
assert( gamma_move(board, 2, 46, 2) == 0 );
assert( gamma_move(board, 3, 20, 2) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 0, 11) == 1 );
assert( gamma_free_fields(board, 4) == 146 );
assert( gamma_golden_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 2, 30, 1) == 0 );
assert( gamma_move(board, 3, 0, 21) == 1 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 4, 1, 36) == 1 );
assert( gamma_move(board, 1, 44, 1) == 0 );
assert( gamma_move(board, 2, 31, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_free_fields(board, 3) == 142 );


char* board991098202 = gamma_board(board);
assert( board991098202 != NULL );
assert( strcmp(board991098202, 
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".2.\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
".44\n"
"3.3\n"
"...\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"..1\n"
".4.\n"
"...\n"
".2.\n"
"3..\n"
"...\n"
"...\n") == 0);
free(board991098202);
board991098202 = NULL;
assert( gamma_move(board, 4, 24, 1) == 0 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 2, 46, 1) == 0 );
assert( gamma_move(board, 3, 2, 1) == 1 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_free_fields(board, 3) == 139 );
assert( gamma_move(board, 4, 23, 0) == 0 );
assert( gamma_move(board, 4, 0, 44) == 1 );
assert( gamma_golden_move(board, 4, 1, 2) == 0 );
assert( gamma_move(board, 1, 1, 41) == 1 );
assert( gamma_move(board, 2, 38, 1) == 0 );
assert( gamma_move(board, 3, 22, 0) == 0 );
assert( gamma_move(board, 3, 2, 44) == 1 );
assert( gamma_move(board, 4, 19, 2) == 0 );


char* board883790173 = gamma_board(board);
assert( board883790173 != NULL );
assert( strcmp(board883790173, 
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".2.\n"
"4.3\n"
"..1\n"
"...\n"
".1.\n"
"...\n"
".44\n"
"3.3\n"
"...\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"3..\n"
"..3\n"
"...\n") == 0);
free(board883790173);
board883790173 = NULL;
assert( gamma_move(board, 1, 47, 2) == 0 );
assert( gamma_move(board, 2, 35, 2) == 0 );
assert( gamma_move(board, 3, 2, 37) == 1 );


char* board679487173 = gamma_board(board);
assert( board679487173 != NULL );
assert( strcmp(board679487173, 
"...\n"
".3.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
".2.\n"
"4.3\n"
"..1\n"
"...\n"
".1.\n"
"...\n"
".44\n"
"3.3\n"
"..3\n"
".4.\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"...\n"
"...\n"
"...\n"
"..2\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"..4\n"
"...\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"3..\n"
"..3\n"
"...\n") == 0);
free(board679487173);
board679487173 = NULL;
assert( gamma_move(board, 4, 0, 14) == 1 );
assert( gamma_move(board, 4, 1, 16) == 1 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_golden_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 2, 43, 0) == 0 );
assert( gamma_move(board, 2, 1, 33) == 1 );
assert( gamma_free_fields(board, 2) == 132 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 1, 36) == 0 );
assert( gamma_free_fields(board, 1) == 132 );
assert( gamma_move(board, 2, 1, 49) == 1 );
assert( gamma_move(board, 3, 2, 33) == 1 );
assert( gamma_free_fields(board, 3) == 130 );
assert( gamma_move(board, 4, 27, 0) == 0 );
assert( gamma_move(board, 4, 0, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 3, 2, 42) == 1 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_free_fields(board, 4) == 127 );
assert( gamma_move(board, 1, 30, 0) == 0 );
assert( gamma_move(board, 2, 0, 39) == 1 );
assert( gamma_move(board, 2, 0, 43) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 16, 1) == 0 );
assert( gamma_move(board, 3, 2, 30) == 1 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 4, 0, 20) == 1 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_free_fields(board, 4) == 123 );
assert( gamma_move(board, 1, 28, 2) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 0, 20) == 0 );
assert( gamma_move(board, 3, 2, 41) == 1 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 4, 0, 40) == 1 );
assert( gamma_move(board, 1, 30, 0) == 0 );
assert( gamma_move(board, 1, 1, 31) == 1 );
assert( gamma_busy_fields(board, 1) == 5 );


char* board444666873 = gamma_board(board);
assert( board444666873 != NULL );
assert( strcmp(board444666873, 
"...\n"
".3.\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"...\n"
".2.\n"
"4.3\n"
"2.1\n"
"..3\n"
".13\n"
"4..\n"
"244\n"
"3.3\n"
"..3\n"
".4.\n"
"...\n"
"...\n"
".23\n"
"...\n"
".1.\n"
"..3\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"...\n"
"...\n"
"..2\n"
".4.\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"..4\n"
".4.\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"3..\n"
".23\n"
"...\n") == 0);
free(board444666873);
board444666873 = NULL;
assert( gamma_move(board, 2, 19, 0) == 0 );
assert( gamma_move(board, 2, 0, 46) == 1 );
assert( gamma_move(board, 3, 13, 1) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_free_fields(board, 3) == 119 );
assert( gamma_move(board, 4, 0, 19) == 1 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 3, 49, 2) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 4, 45, 2) == 0 );
assert( gamma_move(board, 1, 45, 2) == 0 );
assert( gamma_move(board, 1, 0, 8) == 1 );


char* board371199153 = gamma_board(board);
assert( board371199153 != NULL );
assert( strcmp(board371199153, 
"...\n"
".3.\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"2..\n"
".2.\n"
"4.3\n"
"2.1\n"
"..3\n"
".13\n"
"4..\n"
"244\n"
"3.3\n"
"..3\n"
".4.\n"
"...\n"
"...\n"
".23\n"
"...\n"
".1.\n"
"..3\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"4..\n"
"...\n"
"..2\n"
".4.\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"1.4\n"
".4.\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"3..\n"
".23\n"
"...\n") == 0);
free(board371199153);
board371199153 = NULL;
assert( gamma_move(board, 2, 21, 1) == 0 );
assert( gamma_move(board, 2, 2, 40) == 1 );
assert( gamma_move(board, 3, 2, 30) == 0 );


char* board202994668 = gamma_board(board);
assert( board202994668 != NULL );
assert( strcmp(board202994668, 
"...\n"
".3.\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"2..\n"
".2.\n"
"4.3\n"
"2.1\n"
"..3\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
"..3\n"
".4.\n"
"...\n"
"...\n"
".23\n"
"...\n"
".1.\n"
"..3\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"4..\n"
"...\n"
"..2\n"
".4.\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"1.4\n"
".4.\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"3..\n"
".23\n"
"...\n") == 0);
free(board202994668);
board202994668 = NULL;
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 1, 13, 1) == 0 );


char* board336828316 = gamma_board(board);
assert( board336828316 != NULL );
assert( strcmp(board336828316, 
"...\n"
".3.\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"2..\n"
".2.\n"
"4.3\n"
"2.1\n"
"..3\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
"..3\n"
".4.\n"
"...\n"
"...\n"
".23\n"
"...\n"
".1.\n"
"..3\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"4..\n"
"...\n"
"..2\n"
".4.\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"1.4\n"
".4.\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"3..\n"
".23\n"
"...\n") == 0);
free(board336828316);
board336828316 = NULL;
assert( gamma_move(board, 2, 40, 1) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_free_fields(board, 2) == 116 );
assert( gamma_move(board, 4, 29, 0) == 0 );
assert( gamma_move(board, 1, 2, 34) == 1 );


char* board235161027 = gamma_board(board);
assert( board235161027 != NULL );
assert( strcmp(board235161027, 
"...\n"
".3.\n"
"...\n"
".2.\n"
"...\n"
"...\n"
"2..\n"
".2.\n"
"4.3\n"
"2.1\n"
"..3\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
"..3\n"
".4.\n"
"...\n"
"..1\n"
".23\n"
"...\n"
".1.\n"
"..3\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"4..\n"
"...\n"
"..2\n"
".4.\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"4..\n"
"...\n"
"...\n"
"1.4\n"
".4.\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"3..\n"
".23\n"
"...\n") == 0);
free(board235161027);
board235161027 = NULL;
assert( gamma_move(board, 2, 0, 30) == 1 );
assert( gamma_move(board, 4, 21, 1) == 0 );
assert( gamma_move(board, 4, 2, 15) == 1 );
assert( gamma_move(board, 1, 2, 9) == 1 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 18, 2) == 0 );
assert( gamma_move(board, 4, 2, 33) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 2, 25) == 1 );
assert( gamma_golden_move(board, 2, 21, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 33) == 1 );
assert( gamma_move(board, 1, 1, 1) == 0 );
assert( gamma_move(board, 2, 24, 0) == 0 );
assert( gamma_move(board, 3, 38, 1) == 0 );
assert( gamma_move(board, 4, 45, 0) == 0 );
assert( gamma_move(board, 4, 2, 16) == 1 );
assert( gamma_move(board, 1, 2, 49) == 1 );
assert( gamma_move(board, 3, 32, 2) == 0 );
assert( gamma_move(board, 4, 2, 36) == 1 );
assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_move(board, 2, 0, 0) == 1 );
assert( gamma_move(board, 2, 2, 40) == 0 );
assert( gamma_move(board, 3, 26, 2) == 0 );
assert( gamma_move(board, 4, 2, 42) == 0 );
assert( gamma_move(board, 1, 16, 0) == 0 );
assert( gamma_move(board, 1, 2, 27) == 1 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_free_fields(board, 1) == 105 );
assert( gamma_move(board, 2, 28, 1) == 0 );
assert( gamma_move(board, 2, 2, 46) == 1 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_move(board, 3, 1, 37) == 1 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 1, 14, 1) == 0 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_golden_move(board, 2, 39, 1) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_free_fields(board, 3) == 101 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 47, 0) == 0 );
assert( gamma_move(board, 4, 2, 41) == 0 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_move(board, 1, 1, 46) == 1 );
assert( gamma_move(board, 2, 20, 2) == 0 );
assert( gamma_move(board, 2, 1, 29) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 22, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 50, 1) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 20) == 0 );


char* board806354602 = gamma_board(board);
assert( board806354602 != NULL );
assert( strcmp(board806354602, 
"...\n"
".3.\n"
"...\n"
".21\n"
"...\n"
"...\n"
"212\n"
".2.\n"
"4.3\n"
"2.1\n"
"..3\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
".33\n"
".44\n"
"...\n"
"..1\n"
"123\n"
"...\n"
".1.\n"
"2.3\n"
".21\n"
"...\n"
"..1\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"4..\n"
"...\n"
"..2\n"
".44\n"
"..4\n"
"4..\n"
"...\n"
"...\n"
"4..\n"
"...\n"
".11\n"
"1.4\n"
".4.\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"34.\n"
"223\n"
"2..\n") == 0);
free(board806354602);
board806354602 = NULL;
assert( gamma_move(board, 2, 40, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 49, 0) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 0, 27) == 1 );
assert( gamma_move(board, 1, 0, 16) == 1 );
assert( gamma_move(board, 2, 2, 49) == 0 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 3, 17, 1) == 0 );
assert( gamma_move(board, 3, 0, 44) == 0 );
assert( gamma_move(board, 4, 0, 31) == 1 );
assert( gamma_move(board, 4, 0, 17) == 1 );
assert( gamma_move(board, 1, 41, 0) == 0 );
assert( gamma_move(board, 2, 0, 27) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 4, 1, 45) == 0 );
assert( gamma_free_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 26, 0) == 0 );


char* board387413230 = gamma_board(board);
assert( board387413230 != NULL );
assert( strcmp(board387413230, 
"...\n"
".3.\n"
"...\n"
".21\n"
"...\n"
"...\n"
"212\n"
".2.\n"
"4.3\n"
"2.1\n"
"..3\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
".33\n"
".44\n"
"...\n"
"..1\n"
"123\n"
"...\n"
"41.\n"
"2.3\n"
".21\n"
"...\n"
"4.1\n"
"...\n"
"..1\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"4..\n"
"...\n"
"4.2\n"
"144\n"
"..4\n"
"4..\n"
"...\n"
"...\n"
"4.2\n"
"...\n"
".11\n"
"1.4\n"
".4.\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"34.\n"
"223\n"
"2..\n") == 0);
free(board387413230);
board387413230 = NULL;
assert( gamma_move(board, 3, 1, 49) == 0 );
assert( gamma_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 1, 2, 33) == 0 );
assert( gamma_move(board, 1, 0, 47) == 1 );
assert( gamma_move(board, 2, 52, 0) == 0 );
assert( gamma_move(board, 3, 2, 39) == 0 );
assert( gamma_move(board, 4, 52, 1) == 0 );
assert( gamma_move(board, 4, 1, 19) == 1 );
assert( gamma_move(board, 1, 22, 0) == 0 );
assert( gamma_move(board, 2, 51, 2) == 0 );
assert( gamma_move(board, 2, 1, 36) == 0 );
assert( gamma_move(board, 3, 23, 1) == 0 );
assert( gamma_move(board, 3, 2, 45) == 1 );
assert( gamma_move(board, 4, 24, 2) == 0 );
assert( gamma_move(board, 4, 2, 36) == 0 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_free_fields(board, 4) == 33 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_move(board, 2, 1, 25) == 1 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 3, 0, 46) == 0 );
assert( gamma_move(board, 3, 0, 10) == 1 );
assert( gamma_free_fields(board, 3) == 88 );
assert( gamma_move(board, 4, 2, 28) == 0 );
assert( gamma_move(board, 1, 0, 43) == 0 );
assert( gamma_move(board, 2, 0, 26) == 0 );
assert( gamma_move(board, 3, 51, 2) == 0 );
assert( gamma_move(board, 3, 1, 33) == 0 );
assert( gamma_free_fields(board, 3) == 88 );
assert( gamma_move(board, 4, 2, 50) == 0 );
assert( gamma_move(board, 4, 0, 31) == 0 );
assert( gamma_free_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 27, 1) == 0 );
assert( gamma_move(board, 2, 52, 0) == 0 );
assert( gamma_move(board, 3, 1, 41) == 0 );
assert( gamma_busy_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 21, 1) == 0 );
assert( gamma_move(board, 4, 1, 33) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 3, 0, 20) == 0 );
assert( gamma_move(board, 4, 20, 2) == 0 );
assert( gamma_free_fields(board, 4) == 32 );
assert( gamma_move(board, 1, 1, 51) == 0 );
assert( gamma_move(board, 2, 52, 0) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 1, 23, 2) == 0 );
assert( gamma_move(board, 2, 32, 1) == 0 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 1, 25) == 0 );
assert( gamma_move(board, 4, 35, 2) == 0 );
assert( gamma_move(board, 4, 0, 49) == 0 );
assert( gamma_move(board, 1, 0, 35) == 0 );
assert( gamma_move(board, 1, 2, 47) == 0 );
assert( gamma_move(board, 2, 0, 23) == 0 );
assert( gamma_move(board, 3, 35, 1) == 0 );
assert( gamma_move(board, 3, 2, 48) == 1 );
assert( gamma_free_fields(board, 3) == 87 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_golden_move(board, 4, 43, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 3, 1, 1) == 0 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );


char* board801894867 = gamma_board(board);
assert( board801894867 != NULL );
assert( strcmp(board801894867, 
"...\n"
".3.\n"
"...\n"
".21\n"
"..3\n"
"1..\n"
"212\n"
".23\n"
"4.3\n"
"2.1\n"
"..3\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
".33\n"
".44\n"
"...\n"
"..1\n"
"123\n"
"...\n"
"41.\n"
"2.3\n"
".21\n"
"...\n"
"4.1\n"
"...\n"
".21\n"
"...\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"44.\n"
"...\n"
"4.2\n"
"144\n"
"..4\n"
"4..\n"
"...\n"
"...\n"
"4.2\n"
"3..\n"
".11\n"
"1.4\n"
".44\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"34.\n"
"223\n"
"2..\n") == 0);
free(board801894867);
board801894867 = NULL;
assert( gamma_move(board, 2, 24, 1) == 0 );
assert( gamma_move(board, 3, 1, 30) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_busy_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 52, 1) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 15, 1) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 3, 18, 1) == 0 );
assert( gamma_move(board, 3, 2, 15) == 0 );
assert( gamma_move(board, 4, 0, 24) == 1 );
assert( gamma_move(board, 4, 1, 43) == 0 );
assert( gamma_move(board, 1, 1, 18) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 3, 22, 2) == 0 );
assert( gamma_free_fields(board, 3) == 83 );
assert( gamma_move(board, 4, 0, 18) == 1 );
assert( gamma_move(board, 4, 1, 45) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 28, 2) == 0 );
assert( gamma_move(board, 2, 0, 21) == 0 );
assert( gamma_move(board, 2, 2, 44) == 0 );
assert( gamma_move(board, 3, 36, 0) == 0 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 4, 1, 42) == 1 );
assert( gamma_free_fields(board, 1) == 24 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 8) == 0 );


char* board765443269 = gamma_board(board);
assert( board765443269 != NULL );
assert( strcmp(board765443269, 
"...\n"
".3.\n"
"...\n"
".21\n"
"..3\n"
"1..\n"
"212\n"
".23\n"
"4.3\n"
"2.1\n"
".43\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
".33\n"
".44\n"
"...\n"
"..1\n"
"123\n"
"...\n"
"41.\n"
"233\n"
".21\n"
"...\n"
"4.1\n"
"...\n"
".21\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"44.\n"
"4..\n"
"4.2\n"
"144\n"
"..4\n"
"4..\n"
".3.\n"
"...\n"
"4.2\n"
"3..\n"
".11\n"
"1.4\n"
".44\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"34.\n"
"223\n"
"2..\n") == 0);
free(board765443269);
board765443269 = NULL;
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 1, 39) == 0 );
assert( gamma_move(board, 3, 0, 24) == 0 );
assert( gamma_move(board, 4, 31, 2) == 0 );
assert( gamma_move(board, 1, 18, 1) == 0 );
assert( gamma_move(board, 2, 0, 43) == 0 );
assert( gamma_move(board, 2, 2, 4) == 0 );
assert( gamma_move(board, 3, 47, 2) == 0 );
assert( gamma_move(board, 3, 1, 43) == 1 );
assert( gamma_free_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 0, 40) == 0 );
assert( gamma_move(board, 4, 2, 16) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 29) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 52, 2) == 0 );
assert( gamma_move(board, 4, 0, 31) == 0 );
assert( gamma_move(board, 1, 32, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 2, 23) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 1, 32, 2) == 0 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_move(board, 2, 2, 34) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 3, 1, 26) == 0 );
assert( gamma_free_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 2, 21) == 0 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_move(board, 2, 1, 22) == 0 );
assert( gamma_move(board, 3, 50, 1) == 0 );
assert( gamma_free_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_free_fields(board, 4) == 33 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 27, 1) == 0 );
assert( gamma_move(board, 3, 32, 0) == 0 );


char* board548969547 = gamma_board(board);
assert( board548969547 != NULL );
assert( strcmp(board548969547, 
"...\n"
".3.\n"
"...\n"
".21\n"
"..3\n"
"1..\n"
"212\n"
".23\n"
"4.3\n"
"231\n"
".43\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
".33\n"
".44\n"
"...\n"
"..1\n"
"123\n"
"...\n"
"41.\n"
"233\n"
".21\n"
"...\n"
"4.1\n"
"...\n"
".21\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"44.\n"
"4..\n"
"4.2\n"
"144\n"
"..4\n"
"4..\n"
".3.\n"
"...\n"
"4.2\n"
"3..\n"
".11\n"
"1.4\n"
"444\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"34.\n"
"223\n"
"2..\n") == 0);
free(board548969547);
board548969547 = NULL;
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 1, 20, 1) == 0 );
assert( gamma_golden_move(board, 1, 16, 2) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 0, 20) == 0 );
assert( gamma_move(board, 3, 18, 2) == 0 );
assert( gamma_move(board, 3, 0, 28) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 2, 42) == 0 );
assert( gamma_move(board, 1, 37, 0) == 0 );
assert( gamma_free_fields(board, 1) == 22 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 49, 0) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 24, 1) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 45, 0) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 3, 2, 42) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 1, 44, 1) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 2, 2, 21) == 0 );
assert( gamma_free_fields(board, 2) == 23 );


char* board122082098 = gamma_board(board);
assert( board122082098 != NULL );
assert( strcmp(board122082098, 
"...\n"
".3.\n"
"...\n"
".21\n"
"..3\n"
"1..\n"
"212\n"
".23\n"
"4.3\n"
"231\n"
".43\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
".33\n"
".44\n"
"...\n"
"..1\n"
"123\n"
"...\n"
"41.\n"
"233\n"
".21\n"
"...\n"
"4.1\n"
"...\n"
".21\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"44.\n"
"4..\n"
"4.2\n"
"144\n"
"..4\n"
"4..\n"
".3.\n"
"...\n"
"4.2\n"
"3..\n"
".11\n"
"1.4\n"
"444\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"34.\n"
"223\n"
"2..\n") == 0);
free(board122082098);
board122082098 = NULL;
assert( gamma_move(board, 3, 32, 0) == 0 );
assert( gamma_free_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 36, 0) == 0 );


char* board196318738 = gamma_board(board);
assert( board196318738 != NULL );
assert( strcmp(board196318738, 
"...\n"
".3.\n"
"...\n"
".21\n"
"..3\n"
"1..\n"
"212\n"
".23\n"
"4.3\n"
"231\n"
".43\n"
".13\n"
"4.2\n"
"244\n"
"3.3\n"
".33\n"
".44\n"
"...\n"
"..1\n"
"123\n"
"...\n"
"41.\n"
"233\n"
".21\n"
"...\n"
"4.1\n"
"...\n"
".21\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"44.\n"
"4..\n"
"4.2\n"
"144\n"
"..4\n"
"4..\n"
".3.\n"
"...\n"
"4.2\n"
"3..\n"
".11\n"
"1.4\n"
"444\n"
"..1\n"
"44.\n"
".3.\n"
".2.\n"
"34.\n"
"223\n"
"2..\n") == 0);
free(board196318738);
board196318738 = NULL;
assert( gamma_move(board, 1, 0, 20) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 2, 43) == 0 );
assert( gamma_move(board, 3, 24, 1) == 0 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 2, 27) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_free_fields(board, 1) == 22 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 35, 0) == 0 );
assert( gamma_move(board, 4, 20, 2) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_move(board, 2, 18, 2) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 23, 0) == 0 );
assert( gamma_move(board, 1, 31, 2) == 0 );
assert( gamma_move(board, 2, 1, 37) == 0 );
assert( gamma_move(board, 2, 0, 34) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 1, 26, 1) == 0 );
assert( gamma_move(board, 1, 2, 48) == 0 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 3, 1, 43) == 0 );
assert( gamma_golden_move(board, 3, 49, 1) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 4, 0, 27) == 0 );
assert( gamma_move(board, 1, 22, 0) == 0 );
assert( gamma_move(board, 1, 0, 43) == 0 );
assert( gamma_move(board, 2, 0, 29) == 1 );
assert( gamma_move(board, 2, 1, 40) == 1 );
assert( gamma_move(board, 3, 1, 31) == 0 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 2, 18) == 1 );
assert( gamma_move(board, 3, 1, 38) == 1 );
assert( gamma_move(board, 3, 0, 21) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 22) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 31, 2) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 2, 1, 49) == 0 );
assert( gamma_move(board, 3, 2, 28) == 1 );
assert( gamma_free_fields(board, 4) == 31 );
assert( gamma_move(board, 1, 1, 34) == 1 );
assert( gamma_move(board, 2, 2, 13) == 1 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 0, 40) == 0 );
assert( gamma_move(board, 1, 50, 0) == 0 );
assert( gamma_move(board, 2, 27, 1) == 0 );
assert( gamma_free_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 35, 0) == 0 );
assert( gamma_move(board, 3, 0, 20) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_move(board, 4, 2, 7) == 0 );
assert( gamma_move(board, 2, 35, 0) == 0 );
assert( gamma_move(board, 2, 1, 23) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 3, 2, 51) == 1 );
assert( gamma_move(board, 4, 20, 1) == 0 );
assert( gamma_move(board, 4, 0, 47) == 0 );
assert( gamma_move(board, 1, 22, 2) == 0 );
assert( gamma_move(board, 2, 35, 1) == 0 );
assert( gamma_move(board, 2, 2, 41) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 4, 1, 52) == 0 );
assert( gamma_move(board, 1, 22, 2) == 0 );
assert( gamma_move(board, 2, 2, 49) == 0 );
assert( gamma_move(board, 3, 35, 2) == 0 );
assert( gamma_move(board, 4, 1, 46) == 0 );
assert( gamma_move(board, 4, 1, 27) == 1 );
assert( gamma_move(board, 1, 22, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 24, 2) == 0 );
assert( gamma_move(board, 3, 2, 47) == 1 );
assert( gamma_move(board, 3, 2, 27) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 0, 15) == 1 );
assert( gamma_move(board, 1, 20, 1) == 0 );
assert( gamma_move(board, 2, 1, 47) == 0 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 3, 1, 15) == 0 );
assert( gamma_free_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 1, 0, 28) == 1 );
assert( gamma_move(board, 2, 42, 0) == 0 );
assert( gamma_move(board, 2, 1, 28) == 1 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 22, 1) == 0 );
assert( gamma_free_fields(board, 3) == 22 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 2, 2, 38) == 0 );
assert( gamma_move(board, 3, 50, 1) == 0 );
assert( gamma_move(board, 3, 1, 7) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 1, 40) == 0 );
assert( gamma_move(board, 1, 51, 0) == 0 );
assert( gamma_move(board, 1, 0, 25) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 2, 51) == 0 );
assert( gamma_move(board, 3, 32, 0) == 0 );


char* board133854366 = gamma_board(board);
assert( board133854366 != NULL );
assert( strcmp(board133854366, 
"...\n"
".33\n"
"...\n"
".21\n"
"..3\n"
"1.3\n"
"212\n"
".23\n"
"4.3\n"
"231\n"
".43\n"
".13\n"
"422\n"
"244\n"
"333\n"
".33\n"
".44\n"
"...\n"
".11\n"
"123\n"
"...\n"
"41.\n"
"233\n"
"221\n"
"123\n"
"441\n"
"...\n"
".21\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"44.\n"
"4.2\n"
"4.2\n"
"144\n"
"4.4\n"
"4..\n"
".32\n"
"...\n"
"4.2\n"
"3..\n"
"111\n"
"1.4\n"
"444\n"
"..1\n"
"441\n"
".3.\n"
".2.\n"
"343\n"
"223\n"
"2..\n") == 0);
free(board133854366);
board133854366 = NULL;
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 1, 34) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 33, 2) == 0 );
assert( gamma_move(board, 1, 18, 1) == 0 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_busy_fields(board, 1) == 20 );
assert( gamma_move(board, 2, 2, 27) == 0 );
assert( gamma_free_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 1, 30) == 0 );
assert( gamma_move(board, 3, 1, 19) == 0 );


char* board917895492 = gamma_board(board);
assert( board917895492 != NULL );
assert( strcmp(board917895492, 
"...\n"
".33\n"
"...\n"
".21\n"
"..3\n"
"1.3\n"
"212\n"
".23\n"
"4.3\n"
"231\n"
".43\n"
".13\n"
"422\n"
"244\n"
"333\n"
".33\n"
".44\n"
"...\n"
".11\n"
"123\n"
"...\n"
"41.\n"
"233\n"
"221\n"
"123\n"
"441\n"
"...\n"
".21\n"
"4..\n"
"...\n"
"...\n"
"3..\n"
"4..\n"
"44.\n"
"4.2\n"
"4.2\n"
"144\n"
"4.4\n"
"4..\n"
".32\n"
"...\n"
"4.2\n"
"3..\n"
"111\n"
"1.4\n"
"444\n"
"..1\n"
"441\n"
".3.\n"
".2.\n"
"343\n"
"223\n"
"2..\n") == 0);
free(board917895492);
board917895492 = NULL;
assert( gamma_move(board, 4, 2, 17) == 0 );
assert( gamma_move(board, 1, 1, 41) == 0 );
assert( gamma_move(board, 1, 0, 38) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 3, 51, 0) == 0 );
assert( gamma_move(board, 3, 0, 25) == 0 );
assert( gamma_move(board, 4, 2, 52) == 0 );
assert( gamma_golden_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 2, 32) == 0 );
assert( gamma_move(board, 2, 0, 8) == 0 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 3, 0, 41) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 2, 1, 30) == 0 );
assert( gamma_move(board, 2, 2, 25) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 3, 2) == 0 );
assert( gamma_move(board, 4, 34, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_golden_move(board, 4, 32, 0) == 0 );
assert( gamma_move(board, 1, 26, 2) == 0 );
assert( gamma_move(board, 2, 32, 2) == 0 );


gamma_delete(board);

    return 0;
}
