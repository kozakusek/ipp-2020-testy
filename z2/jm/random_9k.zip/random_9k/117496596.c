#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 117496596
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 122, 9, 13);
assert( board != NULL );


assert( gamma_move(board, 1, 50, 0) == 0 );
assert( gamma_move(board, 1, 0, 51) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 93) == 1 );
assert( gamma_move(board, 2, 0, 77) == 1 );
assert( gamma_move(board, 3, 36, 0) == 0 );
assert( gamma_move(board, 4, 9, 0) == 0 );
assert( gamma_move(board, 5, 0, 20) == 1 );
assert( gamma_move(board, 5, 0, 91) == 1 );
assert( gamma_move(board, 6, 99, 0) == 0 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 7, 0, 69) == 1 );
assert( gamma_move(board, 8, 16, 0) == 0 );
assert( gamma_golden_move(board, 8, 69, 0) == 0 );
assert( gamma_move(board, 9, 59, 0) == 0 );
assert( gamma_move(board, 1, 22, 0) == 0 );
assert( gamma_move(board, 2, 71, 0) == 0 );
assert( gamma_move(board, 2, 0, 98) == 1 );
assert( gamma_move(board, 3, 42, 0) == 0 );
assert( gamma_move(board, 4, 54, 0) == 0 );
assert( gamma_move(board, 4, 0, 35) == 1 );
assert( gamma_busy_fields(board, 4) == 1 );
assert( gamma_move(board, 5, 68, 0) == 0 );
assert( gamma_move(board, 5, 0, 39) == 1 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_free_fields(board, 6) == 113 );


char* board844955393 = gamma_board(board);
assert( board844955393 != NULL );
assert( strcmp(board844955393, 
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n") == 0);
free(board844955393);
board844955393 = NULL;
assert( gamma_move(board, 7, 0, 109) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 0, 107) == 1 );
assert( gamma_move(board, 1, 61, 0) == 0 );
assert( gamma_move(board, 1, 0, 16) == 1 );
assert( gamma_move(board, 2, 112, 0) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 0, 119) == 1 );
assert( gamma_move(board, 3, 0, 53) == 1 );
assert( gamma_move(board, 4, 105, 0) == 0 );
assert( gamma_move(board, 5, 0, 19) == 1 );
assert( gamma_move(board, 5, 0, 63) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 52) == 1 );
assert( gamma_move(board, 7, 0, 67) == 1 );
assert( gamma_move(board, 8, 0, 14) == 1 );
assert( gamma_move(board, 9, 0, 83) == 1 );
assert( gamma_move(board, 1, 0, 27) == 1 );
assert( gamma_move(board, 2, 0, 102) == 1 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_move(board, 4, 40, 0) == 0 );
assert( gamma_move(board, 5, 80, 0) == 0 );
assert( gamma_move(board, 5, 0, 28) == 1 );
assert( gamma_move(board, 6, 43, 0) == 0 );
assert( gamma_move(board, 7, 71, 0) == 0 );
assert( gamma_move(board, 8, 50, 0) == 0 );
assert( gamma_move(board, 8, 0, 106) == 1 );
assert( gamma_move(board, 9, 0, 91) == 0 );
assert( gamma_free_fields(board, 9) == 97 );
assert( gamma_move(board, 1, 0, 18) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 101) == 1 );
assert( gamma_move(board, 2, 0, 99) == 1 );
assert( gamma_move(board, 3, 0, 86) == 1 );
assert( gamma_move(board, 3, 0, 65) == 1 );
assert( gamma_move(board, 4, 0, 17) == 1 );
assert( gamma_move(board, 5, 110, 0) == 0 );
assert( gamma_move(board, 5, 0, 32) == 1 );
assert( gamma_move(board, 6, 0, 86) == 0 );
assert( gamma_move(board, 7, 0, 31) == 1 );
assert( gamma_golden_move(board, 7, 65, 0) == 0 );


char* board755886659 = gamma_board(board);
assert( board755886659 != NULL );
assert( strcmp(board755886659, 
".\n"
".\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"8\n"
"8\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n") == 0);
free(board755886659);
board755886659 = NULL;
assert( gamma_move(board, 8, 0, 100) == 1 );
assert( gamma_move(board, 9, 90, 0) == 0 );
assert( gamma_move(board, 1, 0, 104) == 1 );
assert( gamma_free_fields(board, 1) == 87 );
assert( gamma_free_fields(board, 2) == 87 );
assert( gamma_move(board, 3, 117, 0) == 0 );
assert( gamma_move(board, 4, 68, 0) == 0 );
assert( gamma_move(board, 5, 95, 0) == 0 );
assert( gamma_move(board, 5, 0, 42) == 1 );
assert( gamma_free_fields(board, 5) == 86 );
assert( gamma_move(board, 6, 0, 106) == 0 );
assert( gamma_move(board, 6, 0, 120) == 1 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board919370604 = gamma_board(board);
assert( board919370604 != NULL );
assert( strcmp(board919370604, 
".\n"
"6\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"8\n"
"8\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"7\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
".\n"
".\n"
"5\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n") == 0);
free(board919370604);
board919370604 = NULL;
assert( gamma_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 8, 0, 120) == 0 );
assert( gamma_free_fields(board, 8) == 85 );
assert( gamma_move(board, 9, 113, 0) == 0 );
assert( gamma_move(board, 1, 0, 82) == 1 );
assert( gamma_move(board, 1, 0, 94) == 1 );
assert( gamma_move(board, 2, 0, 86) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 68) == 1 );
assert( gamma_move(board, 4, 0, 58) == 1 );
assert( gamma_move(board, 5, 75, 0) == 0 );
assert( gamma_move(board, 5, 0, 47) == 1 );
assert( gamma_golden_move(board, 5, 77, 0) == 0 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 6, 0, 4) == 1 );
assert( gamma_move(board, 7, 45, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 4 );
assert( gamma_free_fields(board, 7) == 79 );
assert( gamma_move(board, 8, 44, 0) == 0 );
assert( gamma_move(board, 9, 40, 0) == 0 );
assert( gamma_move(board, 9, 0, 104) == 0 );
assert( gamma_move(board, 1, 40, 0) == 0 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 2, 0, 26) == 1 );
assert( gamma_move(board, 2, 0, 93) == 0 );
assert( gamma_move(board, 3, 0, 30) == 1 );
assert( gamma_move(board, 4, 60, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 117, 0) == 0 );
assert( gamma_move(board, 6, 112, 0) == 0 );
assert( gamma_move(board, 7, 13, 0) == 0 );
assert( gamma_busy_fields(board, 8) == 4 );
assert( gamma_move(board, 1, 71, 0) == 0 );
assert( gamma_move(board, 1, 0, 39) == 0 );


char* board241676622 = gamma_board(board);
assert( board241676622 != NULL );
assert( strcmp(board241676622, 
".\n"
"6\n"
"3\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"8\n"
"8\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
".\n"
"3\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
".\n"
".\n") == 0);
free(board241676622);
board241676622 = NULL;
assert( gamma_move(board, 2, 0, 66) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 37, 0) == 0 );
assert( gamma_move(board, 3, 0, 56) == 1 );
assert( gamma_move(board, 4, 85, 0) == 0 );
assert( gamma_golden_move(board, 4, 120, 0) == 0 );
assert( gamma_move(board, 5, 0, 83) == 0 );
assert( gamma_move(board, 7, 0, 2) == 0 );
assert( gamma_move(board, 7, 0, 118) == 1 );
assert( gamma_move(board, 8, 113, 0) == 0 );
assert( gamma_move(board, 9, 0, 91) == 0 );
assert( gamma_move(board, 1, 21, 0) == 0 );
assert( gamma_move(board, 1, 0, 73) == 1 );
assert( gamma_move(board, 2, 90, 0) == 0 );
assert( gamma_golden_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 0, 121) == 1 );
assert( gamma_move(board, 4, 21, 0) == 0 );
assert( gamma_move(board, 4, 0, 61) == 1 );
assert( gamma_move(board, 5, 45, 0) == 0 );
assert( gamma_move(board, 5, 0, 12) == 0 );
assert( gamma_golden_move(board, 5, 98, 0) == 0 );
assert( gamma_move(board, 6, 0, 114) == 1 );
assert( gamma_move(board, 8, 113, 0) == 0 );
assert( gamma_move(board, 9, 87, 0) == 0 );
assert( gamma_golden_move(board, 9, 61, 0) == 0 );
assert( gamma_move(board, 1, 0, 62) == 1 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 97, 0) == 0 );
assert( gamma_move(board, 3, 38, 0) == 0 );
assert( gamma_move(board, 3, 0, 74) == 1 );
assert( gamma_busy_fields(board, 3) == 9 );
assert( gamma_move(board, 4, 41, 0) == 0 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 5, 78, 0) == 0 );
assert( gamma_move(board, 5, 0, 1) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 0, 20) == 0 );
assert( gamma_move(board, 6, 0, 94) == 0 );
assert( gamma_move(board, 7, 0, 30) == 0 );
assert( gamma_move(board, 8, 115, 0) == 0 );
assert( gamma_move(board, 8, 0, 32) == 0 );
assert( gamma_move(board, 1, 108, 0) == 0 );
assert( gamma_golden_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 3, 75, 0) == 0 );
assert( gamma_move(board, 3, 0, 38) == 1 );


char* board421299357 = gamma_board(board);
assert( board421299357 != NULL );
assert( strcmp(board421299357, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"8\n"
"8\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
".\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
".\n") == 0);
free(board421299357);
board421299357 = NULL;
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 0, 49) == 1 );
assert( gamma_move(board, 5, 0, 14) == 0 );
assert( gamma_move(board, 6, 0, 65) == 0 );
assert( gamma_move(board, 6, 0, 114) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 70, 0) == 0 );
assert( gamma_move(board, 8, 57, 0) == 0 );
assert( gamma_move(board, 8, 0, 120) == 0 );


char* board550096758 = gamma_board(board);
assert( board550096758 != NULL );
assert( strcmp(board550096758, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"8\n"
"8\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
".\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
".\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
".\n"
"5\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
".\n") == 0);
free(board550096758);
board550096758 = NULL;
assert( gamma_move(board, 9, 71, 0) == 0 );
assert( gamma_move(board, 9, 0, 89) == 1 );
assert( gamma_move(board, 1, 92, 0) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 2, 0, 23) == 1 );
assert( gamma_move(board, 3, 0, 72) == 1 );
assert( gamma_move(board, 4, 112, 0) == 0 );
assert( gamma_move(board, 5, 0, 14) == 0 );
assert( gamma_move(board, 6, 0, 73) == 0 );
assert( gamma_move(board, 7, 108, 0) == 0 );
assert( gamma_move(board, 7, 0, 44) == 1 );
assert( gamma_move(board, 8, 11, 0) == 0 );
assert( gamma_free_fields(board, 8) == 60 );
assert( gamma_move(board, 9, 116, 0) == 0 );


char* board392209989 = gamma_board(board);
assert( board392209989 != NULL );
assert( strcmp(board392209989, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
".\n"
".\n"
".\n"
"7\n"
".\n"
"8\n"
"8\n"
".\n"
"1\n"
".\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
".\n"
"9\n"
".\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
".\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
".\n"
"5\n"
".\n"
".\n"
"7\n"
".\n"
"5\n"
".\n"
".\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
".\n") == 0);
free(board392209989);
board392209989 = NULL;
assert( gamma_move(board, 1, 85, 0) == 0 );
assert( gamma_move(board, 1, 0, 59) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 46) == 1 );
assert( gamma_golden_move(board, 2, 114, 0) == 0 );
assert( gamma_move(board, 3, 115, 0) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 0, 82) == 0 );
assert( gamma_move(board, 5, 45, 0) == 0 );
assert( gamma_move(board, 6, 87, 0) == 0 );
assert( gamma_move(board, 6, 0, 109) == 0 );
assert( gamma_free_fields(board, 6) == 58 );
assert( gamma_move(board, 7, 0, 83) == 0 );
assert( gamma_move(board, 8, 0, 51) == 0 );
assert( gamma_move(board, 8, 0, 19) == 0 );
assert( gamma_move(board, 9, 41, 0) == 0 );
assert( gamma_move(board, 1, 87, 0) == 0 );
assert( gamma_move(board, 2, 0, 40) == 1 );
assert( gamma_move(board, 2, 0, 111) == 1 );
assert( gamma_move(board, 4, 115, 0) == 0 );
assert( gamma_move(board, 4, 0, 103) == 1 );
assert( gamma_move(board, 6, 79, 0) == 0 );
assert( gamma_move(board, 6, 0, 49) == 0 );
assert( gamma_move(board, 7, 33, 0) == 0 );
assert( gamma_move(board, 7, 0, 110) == 1 );
assert( gamma_move(board, 8, 0, 116) == 1 );
assert( gamma_move(board, 9, 117, 0) == 0 );
assert( gamma_move(board, 9, 0, 90) == 1 );
assert( gamma_free_fields(board, 9) == 52 );
assert( gamma_move(board, 1, 0, 91) == 0 );
assert( gamma_move(board, 2, 0, 88) == 1 );
assert( gamma_move(board, 3, 79, 0) == 0 );
assert( gamma_move(board, 4, 0, 19) == 0 );
assert( gamma_move(board, 6, 0, 116) == 0 );
assert( gamma_move(board, 6, 0, 108) == 1 );
assert( gamma_busy_fields(board, 6) == 5 );
assert( gamma_move(board, 7, 0, 113) == 1 );
assert( gamma_free_fields(board, 7) == 49 );
assert( gamma_move(board, 8, 0, 17) == 0 );
assert( gamma_move(board, 8, 0, 119) == 0 );
assert( gamma_free_fields(board, 8) == 49 );


char* board667664420 = gamma_board(board);
assert( board667664420 != NULL );
assert( strcmp(board667664420, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
"8\n"
".\n"
"6\n"
"7\n"
".\n"
"2\n"
"7\n"
"7\n"
"6\n"
"8\n"
"8\n"
".\n"
"1\n"
"4\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
".\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
"9\n"
"9\n"
"2\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
"1\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
".\n"
"5\n"
"2\n"
".\n"
"7\n"
".\n"
"5\n"
".\n"
"2\n"
"5\n"
"3\n"
".\n"
".\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
".\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
".\n") == 0);
free(board667664420);
board667664420 = NULL;
assert( gamma_move(board, 9, 37, 0) == 0 );
assert( gamma_move(board, 9, 0, 36) == 1 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_golden_move(board, 1, 89, 0) == 0 );
assert( gamma_move(board, 2, 0, 4) == 0 );
assert( gamma_move(board, 2, 0, 78) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 4, 57, 0) == 0 );
assert( gamma_move(board, 4, 0, 22) == 1 );
assert( gamma_move(board, 5, 55, 0) == 0 );
assert( gamma_move(board, 6, 0, 0) == 1 );
assert( gamma_move(board, 6, 0, 97) == 1 );
assert( gamma_move(board, 7, 64, 0) == 0 );
assert( gamma_move(board, 7, 0, 59) == 0 );


char* board845598946 = gamma_board(board);
assert( board845598946 != NULL );
assert( strcmp(board845598946, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
"8\n"
".\n"
"6\n"
"7\n"
".\n"
"2\n"
"7\n"
"7\n"
"6\n"
"8\n"
"8\n"
".\n"
"1\n"
"4\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
"6\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
"9\n"
"9\n"
"2\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
"1\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
".\n"
"5\n"
"2\n"
".\n"
"7\n"
".\n"
"5\n"
".\n"
"2\n"
"5\n"
"3\n"
".\n"
"9\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
"4\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
"6\n") == 0);
free(board845598946);
board845598946 = NULL;
assert( gamma_move(board, 8, 43, 0) == 0 );
assert( gamma_move(board, 9, 80, 0) == 0 );
assert( gamma_move(board, 9, 0, 74) == 0 );
assert( gamma_move(board, 1, 0, 104) == 0 );
assert( gamma_move(board, 2, 0, 20) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 21, 0) == 0 );
assert( gamma_move(board, 3, 0, 118) == 0 );
assert( gamma_move(board, 4, 0, 106) == 0 );


char* board491341893 = gamma_board(board);
assert( board491341893 != NULL );
assert( strcmp(board491341893, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
"8\n"
".\n"
"6\n"
"7\n"
".\n"
"2\n"
"7\n"
"7\n"
"6\n"
"8\n"
"8\n"
".\n"
"1\n"
"4\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
"6\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
"9\n"
"9\n"
"2\n"
".\n"
"3\n"
".\n"
".\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
"1\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
".\n"
"5\n"
"2\n"
".\n"
"7\n"
".\n"
"5\n"
".\n"
"2\n"
"5\n"
"3\n"
".\n"
"9\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
"4\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
"6\n") == 0);
free(board491341893);
board491341893 = NULL;
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_move(board, 6, 48, 0) == 0 );
assert( gamma_move(board, 7, 0, 100) == 0 );
assert( gamma_move(board, 7, 0, 72) == 0 );
assert( gamma_golden_move(board, 7, 108, 0) == 0 );
assert( gamma_move(board, 8, 45, 0) == 0 );
assert( gamma_move(board, 8, 0, 86) == 0 );
assert( gamma_move(board, 9, 11, 0) == 0 );
assert( gamma_move(board, 1, 76, 0) == 0 );
assert( gamma_golden_move(board, 1, 101, 0) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 25, 0) == 0 );
assert( gamma_move(board, 3, 0, 38) == 0 );
assert( gamma_move(board, 4, 0, 84) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 41, 0) == 0 );
assert( gamma_move(board, 5, 0, 47) == 0 );


char* board219205577 = gamma_board(board);
assert( board219205577 != NULL );
assert( strcmp(board219205577, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
"8\n"
".\n"
"6\n"
"7\n"
".\n"
"2\n"
"7\n"
"7\n"
"6\n"
"8\n"
"8\n"
".\n"
"1\n"
"4\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
"6\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
"9\n"
"9\n"
"2\n"
".\n"
"3\n"
".\n"
"4\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
"1\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
".\n"
"5\n"
"2\n"
".\n"
"7\n"
".\n"
"5\n"
".\n"
"2\n"
"5\n"
"3\n"
".\n"
"9\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
"4\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
"6\n") == 0);
free(board219205577);
board219205577 = NULL;
assert( gamma_move(board, 6, 0, 32) == 0 );


char* board740865124 = gamma_board(board);
assert( board740865124 != NULL );
assert( strcmp(board740865124, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
"8\n"
".\n"
"6\n"
"7\n"
".\n"
"2\n"
"7\n"
"7\n"
"6\n"
"8\n"
"8\n"
".\n"
"1\n"
"4\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
"6\n"
".\n"
".\n"
"1\n"
"2\n"
".\n"
"5\n"
"9\n"
"9\n"
"2\n"
".\n"
"3\n"
".\n"
"4\n"
"9\n"
"1\n"
".\n"
".\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
"1\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
".\n"
"5\n"
"2\n"
".\n"
"7\n"
".\n"
"5\n"
".\n"
"2\n"
"5\n"
"3\n"
".\n"
"9\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
".\n"
"2\n"
"4\n"
".\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
".\n"
"8\n"
".\n"
"1\n"
".\n"
".\n"
".\n"
".\n"
".\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
"6\n") == 0);
free(board740865124);
board740865124 = NULL;
assert( gamma_move(board, 7, 43, 0) == 0 );
assert( gamma_move(board, 9, 15, 0) == 0 );
assert( gamma_move(board, 9, 0, 24) == 1 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 0, 61) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 4, 0, 21) == 1 );
assert( gamma_move(board, 5, 112, 0) == 0 );
assert( gamma_move(board, 5, 0, 7) == 1 );
assert( gamma_move(board, 6, 85, 0) == 0 );
assert( gamma_move(board, 7, 117, 0) == 0 );
assert( gamma_move(board, 8, 0, 10) == 1 );
assert( gamma_move(board, 9, 0, 74) == 0 );
assert( gamma_move(board, 1, 0, 99) == 0 );
assert( gamma_move(board, 1, 0, 39) == 0 );
assert( gamma_move(board, 2, 80, 0) == 0 );
assert( gamma_move(board, 2, 0, 63) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 3, 0, 111) == 0 );
assert( gamma_free_fields(board, 3) == 38 );
assert( gamma_move(board, 4, 85, 0) == 0 );
assert( gamma_move(board, 4, 0, 95) == 1 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_move(board, 5, 5, 0) == 0 );
assert( gamma_move(board, 6, 13, 0) == 0 );
assert( gamma_move(board, 6, 0, 13) == 1 );
assert( gamma_free_fields(board, 6) == 36 );
assert( gamma_move(board, 7, 76, 0) == 0 );
assert( gamma_move(board, 8, 45, 0) == 0 );
assert( gamma_move(board, 8, 0, 20) == 0 );
assert( gamma_move(board, 9, 60, 0) == 0 );
assert( gamma_move(board, 9, 0, 107) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 34, 0) == 0 );
assert( gamma_move(board, 1, 0, 93) == 0 );
assert( gamma_move(board, 2, 25, 0) == 0 );
assert( gamma_move(board, 2, 0, 35) == 0 );
assert( gamma_move(board, 3, 64, 0) == 0 );
assert( gamma_move(board, 4, 105, 0) == 0 );
assert( gamma_move(board, 5, 76, 0) == 0 );
assert( gamma_move(board, 5, 0, 116) == 0 );
assert( gamma_move(board, 6, 105, 0) == 0 );
assert( gamma_move(board, 6, 0, 41) == 1 );
assert( gamma_free_fields(board, 6) == 35 );
assert( gamma_move(board, 8, 45, 0) == 0 );
assert( gamma_move(board, 8, 0, 53) == 0 );
assert( gamma_free_fields(board, 8) == 35 );
assert( gamma_move(board, 9, 0, 69) == 0 );
assert( gamma_busy_fields(board, 9) == 5 );
assert( gamma_move(board, 1, 0, 24) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 0) == 0 );
assert( gamma_move(board, 2, 0, 80) == 1 );
assert( gamma_move(board, 3, 0, 46) == 0 );
assert( gamma_move(board, 3, 0, 46) == 0 );
assert( gamma_move(board, 4, 115, 0) == 0 );
assert( gamma_move(board, 4, 0, 15) == 1 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 60, 0) == 0 );


char* board925845957 = gamma_board(board);
assert( board925845957 != NULL );
assert( strcmp(board925845957, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
"8\n"
".\n"
"6\n"
"7\n"
".\n"
"2\n"
"7\n"
"7\n"
"6\n"
"8\n"
"8\n"
".\n"
"1\n"
"4\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
"6\n"
".\n"
"4\n"
"1\n"
"2\n"
".\n"
"5\n"
"9\n"
"9\n"
"2\n"
".\n"
"3\n"
".\n"
"4\n"
"9\n"
"1\n"
".\n"
"2\n"
".\n"
"2\n"
"2\n"
".\n"
".\n"
"3\n"
"1\n"
"3\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
"1\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
".\n"
"5\n"
"2\n"
".\n"
"7\n"
".\n"
"5\n"
"6\n"
"2\n"
"5\n"
"3\n"
".\n"
"9\n"
"4\n"
".\n"
".\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
"9\n"
"2\n"
"4\n"
"4\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
"4\n"
"8\n"
"6\n"
"1\n"
".\n"
"8\n"
".\n"
".\n"
"5\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
"6\n") == 0);
free(board925845957);
board925845957 = NULL;
assert( gamma_move(board, 6, 81, 0) == 0 );
assert( gamma_free_fields(board, 6) == 33 );
assert( gamma_move(board, 7, 0, 33) == 1 );
assert( gamma_move(board, 8, 0, 76) == 1 );
assert( gamma_busy_fields(board, 8) == 7 );
assert( gamma_move(board, 9, 60, 0) == 0 );
assert( gamma_move(board, 1, 0, 104) == 0 );
assert( gamma_move(board, 1, 0, 48) == 1 );
assert( gamma_move(board, 2, 75, 0) == 0 );
assert( gamma_free_fields(board, 2) == 8 );
assert( gamma_golden_move(board, 2, 112, 0) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_move(board, 3, 0, 59) == 0 );
assert( gamma_move(board, 4, 0, 43) == 1 );
assert( gamma_move(board, 5, 60, 0) == 0 );
assert( gamma_move(board, 5, 0, 30) == 0 );
assert( gamma_busy_fields(board, 5) == 13 );


char* board289107134 = gamma_board(board);
assert( board289107134 != NULL );
assert( strcmp(board289107134, 
"3\n"
"6\n"
"3\n"
"7\n"
".\n"
"8\n"
".\n"
"6\n"
"7\n"
".\n"
"2\n"
"7\n"
"7\n"
"6\n"
"8\n"
"8\n"
".\n"
"1\n"
"4\n"
"2\n"
"2\n"
"8\n"
"2\n"
"2\n"
"6\n"
".\n"
"4\n"
"1\n"
"2\n"
".\n"
"5\n"
"9\n"
"9\n"
"2\n"
".\n"
"3\n"
".\n"
"4\n"
"9\n"
"1\n"
".\n"
"2\n"
".\n"
"2\n"
"2\n"
"8\n"
".\n"
"3\n"
"1\n"
"3\n"
".\n"
".\n"
"7\n"
"3\n"
"7\n"
"2\n"
"3\n"
".\n"
"5\n"
"1\n"
"4\n"
".\n"
"1\n"
"4\n"
".\n"
"3\n"
".\n"
".\n"
"3\n"
"6\n"
"1\n"
".\n"
"5\n"
"1\n"
"5\n"
"2\n"
".\n"
"7\n"
"4\n"
"5\n"
"6\n"
"2\n"
"5\n"
"3\n"
".\n"
"9\n"
"4\n"
".\n"
"7\n"
"5\n"
"7\n"
"3\n"
".\n"
"5\n"
"1\n"
"2\n"
".\n"
"9\n"
"2\n"
"4\n"
"4\n"
"5\n"
"5\n"
"1\n"
"4\n"
"1\n"
"4\n"
"8\n"
"6\n"
"1\n"
".\n"
"8\n"
".\n"
".\n"
"5\n"
"5\n"
".\n"
"6\n"
".\n"
"2\n"
"5\n"
"6\n") == 0);
free(board289107134);
board289107134 = NULL;
assert( gamma_move(board, 8, 70, 0) == 0 );
assert( gamma_move(board, 8, 0, 25) == 1 );
assert( gamma_move(board, 9, 0, 47) == 0 );
assert( gamma_free_fields(board, 9) == 28 );
assert( gamma_move(board, 1, 54, 0) == 0 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_move(board, 2, 0, 61) == 0 );
assert( gamma_move(board, 3, 0, 10) == 0 );
assert( gamma_free_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 0, 17) == 0 );
assert( gamma_move(board, 4, 0, 101) == 0 );
assert( gamma_move(board, 5, 60, 0) == 0 );
assert( gamma_move(board, 6, 64, 0) == 0 );
assert( gamma_move(board, 6, 0, 110) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 85, 0) == 0 );
assert( gamma_move(board, 8, 64, 0) == 0 );
assert( gamma_move(board, 8, 0, 32) == 0 );
assert( gamma_move(board, 9, 75, 0) == 0 );
assert( gamma_move(board, 9, 0, 48) == 0 );
assert( gamma_move(board, 1, 87, 0) == 0 );
assert( gamma_move(board, 1, 0, 95) == 0 );
assert( gamma_move(board, 2, 85, 0) == 0 );
assert( gamma_move(board, 2, 0, 26) == 0 );
assert( gamma_move(board, 3, 117, 0) == 0 );
assert( gamma_move(board, 3, 0, 33) == 0 );
assert( gamma_move(board, 4, 0, 57) == 1 );
assert( gamma_move(board, 4, 0, 73) == 0 );
assert( gamma_free_fields(board, 5) == 27 );
assert( gamma_move(board, 6, 85, 0) == 0 );
assert( gamma_move(board, 7, 0, 11) == 1 );
assert( gamma_move(board, 7, 0, 29) == 1 );
assert( gamma_move(board, 9, 117, 0) == 0 );
assert( gamma_move(board, 9, 0, 105) == 1 );
assert( gamma_move(board, 1, 0, 20) == 0 );
assert( gamma_move(board, 1, 0, 86) == 0 );
assert( gamma_golden_move(board, 1, 29, 0) == 0 );
assert( gamma_move(board, 2, 0, 20) == 0 );
assert( gamma_free_fields(board, 2) == 7 );
assert( gamma_move(board, 3, 0, 58) == 0 );
assert( gamma_move(board, 4, 50, 0) == 0 );
assert( gamma_move(board, 5, 0, 108) == 0 );
assert( gamma_move(board, 5, 0, 111) == 0 );
assert( gamma_busy_fields(board, 7) == 11 );
assert( gamma_move(board, 8, 81, 0) == 0 );
assert( gamma_move(board, 9, 71, 0) == 0 );
assert( gamma_golden_move(board, 9, 32, 0) == 0 );
assert( gamma_move(board, 1, 71, 0) == 0 );


gamma_delete(board);

    return 0;
}
