#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 128522218
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(2, 128, 8, 33);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 81) == 1 );
assert( gamma_busy_fields(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 100) == 1 );
assert( gamma_move(board, 2, 1, 38) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 49) == 1 );
assert( gamma_move(board, 4, 33, 0) == 0 );
assert( gamma_move(board, 5, 30, 1) == 0 );
assert( gamma_move(board, 6, 91, 1) == 0 );
assert( gamma_move(board, 7, 61, 1) == 0 );
assert( gamma_move(board, 7, 1, 82) == 1 );
assert( gamma_move(board, 8, 31, 0) == 0 );
assert( gamma_move(board, 1, 0, 124) == 1 );
assert( gamma_move(board, 1, 0, 101) == 1 );
assert( gamma_busy_fields(board, 1) == 3 );
assert( gamma_move(board, 2, 46, 1) == 0 );
assert( gamma_move(board, 2, 1, 73) == 1 );
assert( gamma_move(board, 3, 1, 46) == 1 );
assert( gamma_move(board, 5, 56, 1) == 0 );
assert( gamma_move(board, 6, 42, 1) == 0 );
assert( gamma_move(board, 7, 1, 82) == 0 );
assert( gamma_free_fields(board, 7) == 247 );
assert( gamma_move(board, 8, 47, 0) == 0 );
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_move(board, 1, 0, 41) == 1 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 0, 52) == 1 );
assert( gamma_move(board, 3, 0, 46) == 1 );
assert( gamma_move(board, 3, 1, 99) == 1 );
assert( gamma_move(board, 4, 1, 50) == 1 );
assert( gamma_move(board, 4, 1, 120) == 1 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_move(board, 6, 0, 63) == 1 );
assert( gamma_free_fields(board, 6) == 239 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_move(board, 8, 0, 16) == 1 );
assert( gamma_move(board, 1, 1, 82) == 0 );
assert( gamma_busy_fields(board, 1) == 5 );
assert( gamma_move(board, 2, 69, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 4 );
assert( gamma_move(board, 3, 72, 1) == 0 );
assert( gamma_move(board, 4, 91, 0) == 0 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 1, 56) == 1 );
assert( gamma_move(board, 6, 1, 102) == 1 );
assert( gamma_move(board, 7, 104, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 118, 1) == 0 );
assert( gamma_move(board, 1, 93, 0) == 0 );
assert( gamma_move(board, 1, 1, 40) == 1 );
assert( gamma_busy_fields(board, 1) == 6 );
assert( gamma_move(board, 2, 48, 0) == 0 );
assert( gamma_move(board, 2, 1, 112) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 18, 0) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 5, 51, 0) == 0 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 7, 1, 16) == 1 );
assert( gamma_move(board, 7, 0, 124) == 0 );
assert( gamma_move(board, 8, 1, 97) == 1 );
assert( gamma_move(board, 1, 119, 1) == 0 );
assert( gamma_move(board, 3, 92, 1) == 0 );
assert( gamma_move(board, 4, 0, 27) == 1 );
assert( gamma_move(board, 4, 0, 102) == 1 );
assert( gamma_move(board, 6, 1, 74) == 1 );
assert( gamma_move(board, 7, 9, 0) == 0 );
assert( gamma_move(board, 7, 0, 66) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 77, 0) == 0 );
assert( gamma_move(board, 8, 1, 28) == 1 );
assert( gamma_move(board, 1, 125, 0) == 0 );
assert( gamma_move(board, 1, 1, 106) == 1 );
assert( gamma_busy_fields(board, 1) == 7 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 43, 0) == 0 );
assert( gamma_move(board, 3, 36, 1) == 0 );
assert( gamma_move(board, 3, 0, 37) == 1 );
assert( gamma_move(board, 4, 105, 0) == 0 );
assert( gamma_move(board, 5, 0, 94) == 1 );
assert( gamma_move(board, 5, 1, 70) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 6, 120, 0) == 0 );
assert( gamma_busy_fields(board, 6) == 4 );
assert( gamma_move(board, 7, 53, 0) == 0 );
assert( gamma_move(board, 8, 0, 27) == 0 );
assert( gamma_move(board, 1, 0, 67) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 0, 87) == 1 );
assert( gamma_move(board, 3, 1, 88) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 29, 0) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 6, 50, 0) == 0 );
assert( gamma_move(board, 7, 75, 1) == 0 );
assert( gamma_move(board, 7, 0, 94) == 0 );
assert( gamma_free_fields(board, 7) == 218 );
assert( gamma_move(board, 8, 45, 1) == 0 );
assert( gamma_free_fields(board, 8) == 218 );
assert( gamma_move(board, 1, 101, 1) == 0 );
assert( gamma_move(board, 1, 0, 65) == 1 );
assert( gamma_move(board, 2, 0, 77) == 1 );
assert( gamma_free_fields(board, 2) == 216 );
assert( gamma_move(board, 3, 1, 74) == 0 );
assert( gamma_busy_fields(board, 3) == 8 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 4, 1, 13) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 0, 47) == 1 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 121, 0) == 0 );
assert( gamma_move(board, 6, 0, 83) == 1 );


char* board390281682 = gamma_board(board);
assert( board390281682 != NULL );
assert( strcmp(board390281682, 
"..\n"
"..\n"
"..\n"
"1.\n"
"..\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"46\n"
"1.\n"
".2\n"
".3\n"
"..\n"
".8\n"
"..\n"
"..\n"
"5.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
".7\n"
".1\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
"..\n"
".6\n"
".2\n"
"..\n"
"..\n"
".5\n"
"..\n"
"..\n"
"1.\n"
"7.\n"
"1.\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"..\n"
"..\n"
"..\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".8\n"
"4.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"87\n"
"..\n"
"..\n"
".4\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"1.\n"
"7.\n") == 0);
free(board390281682);
board390281682 = NULL;
assert( gamma_move(board, 7, 0, 127) == 1 );
assert( gamma_move(board, 8, 13, 0) == 0 );
assert( gamma_move(board, 8, 0, 113) == 1 );
assert( gamma_free_fields(board, 8) == 211 );
assert( gamma_move(board, 1, 55, 1) == 0 );
assert( gamma_move(board, 2, 1, 19) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 34, 1) == 0 );
assert( gamma_move(board, 4, 0, 76) == 1 );
assert( gamma_busy_fields(board, 4) == 6 );
assert( gamma_move(board, 5, 0, 118) == 1 );
assert( gamma_move(board, 5, 0, 8) == 1 );
assert( gamma_move(board, 6, 119, 0) == 0 );
assert( gamma_move(board, 6, 1, 122) == 1 );
assert( gamma_move(board, 7, 0, 125) == 1 );
assert( gamma_move(board, 8, 115, 1) == 0 );
assert( gamma_move(board, 8, 0, 17) == 1 );
assert( gamma_move(board, 2, 51, 0) == 0 );
assert( gamma_move(board, 3, 75, 1) == 0 );
assert( gamma_move(board, 3, 1, 117) == 1 );
assert( gamma_move(board, 4, 0, 44) == 1 );
assert( gamma_move(board, 5, 104, 0) == 0 );
assert( gamma_move(board, 6, 123, 0) == 0 );
assert( gamma_move(board, 6, 0, 72) == 1 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_move(board, 8, 43, 1) == 0 );
assert( gamma_move(board, 8, 1, 111) == 1 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 1, 1, 27) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 119, 1) == 0 );
assert( gamma_move(board, 2, 1, 1) == 1 );
assert( gamma_move(board, 3, 1, 52) == 1 );
assert( gamma_move(board, 3, 1, 95) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 62, 0) == 0 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 5, 0, 43) == 1 );
assert( gamma_move(board, 5, 0, 47) == 0 );
assert( gamma_move(board, 6, 127, 1) == 0 );
assert( gamma_move(board, 6, 0, 51) == 1 );
assert( gamma_move(board, 7, 1, 14) == 1 );
assert( gamma_move(board, 7, 0, 53) == 1 );
assert( gamma_move(board, 8, 0, 96) == 1 );
assert( gamma_move(board, 8, 0, 9) == 1 );
assert( gamma_busy_fields(board, 8) == 8 );
assert( gamma_move(board, 1, 110, 1) == 0 );
assert( gamma_move(board, 2, 112, 0) == 0 );
assert( gamma_move(board, 3, 71, 1) == 0 );
assert( gamma_move(board, 4, 92, 0) == 0 );
assert( gamma_move(board, 4, 0, 16) == 0 );
assert( gamma_move(board, 5, 34, 0) == 0 );
assert( gamma_move(board, 6, 0, 82) == 1 );
assert( gamma_free_fields(board, 6) == 188 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 1, 1) == 1 );
assert( gamma_move(board, 7, 0, 123) == 1 );
assert( gamma_move(board, 8, 104, 1) == 0 );
assert( gamma_free_fields(board, 8) == 187 );
assert( gamma_move(board, 1, 48, 1) == 0 );
assert( gamma_move(board, 2, 1, 121) == 1 );
assert( gamma_move(board, 3, 0, 66) == 0 );
assert( gamma_move(board, 4, 86, 1) == 0 );
assert( gamma_move(board, 5, 1, 122) == 0 );
assert( gamma_move(board, 5, 0, 52) == 0 );
assert( gamma_move(board, 6, 127, 1) == 0 );
assert( gamma_move(board, 7, 103, 1) == 0 );
assert( gamma_move(board, 8, 33, 0) == 0 );
assert( gamma_move(board, 8, 0, 124) == 0 );
assert( gamma_move(board, 2, 58, 0) == 0 );
assert( gamma_move(board, 2, 0, 30) == 1 );
assert( gamma_move(board, 3, 115, 1) == 0 );
assert( gamma_move(board, 4, 0, 99) == 1 );
assert( gamma_move(board, 5, 30, 1) == 0 );
assert( gamma_move(board, 6, 57, 1) == 0 );
assert( gamma_move(board, 6, 0, 122) == 1 );
assert( gamma_golden_move(board, 7, 28, 1) == 0 );
assert( gamma_move(board, 8, 1, 75) == 1 );
assert( gamma_move(board, 1, 0, 12) == 1 );
assert( gamma_move(board, 1, 1, 43) == 1 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 2, 0, 125) == 0 );
assert( gamma_move(board, 3, 0, 113) == 0 );
assert( gamma_move(board, 4, 45, 1) == 0 );
assert( gamma_move(board, 5, 86, 1) == 0 );
assert( gamma_move(board, 5, 1, 92) == 1 );
assert( gamma_move(board, 6, 20, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 105, 1) == 0 );
assert( gamma_move(board, 7, 0, 63) == 0 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_golden_move(board, 7, 82, 0) == 0 );
assert( gamma_move(board, 8, 31, 1) == 0 );
assert( gamma_busy_fields(board, 8) == 9 );
assert( gamma_move(board, 1, 57, 0) == 0 );


char* board249184785 = gamma_board(board);
assert( board249184785 != NULL );
assert( strcmp(board249184785, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"46\n"
"1.\n"
".2\n"
"43\n"
"..\n"
".8\n"
"8.\n"
".3\n"
"5.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"..\n"
".3\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"67\n"
".1\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"4.\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"1.\n"
"7.\n"
"1.\n"
"..\n"
"6.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"..\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"..\n"
".8\n"
"41\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
"..\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"16\n"
"7.\n") == 0);
free(board249184785);
board249184785 = NULL;
assert( gamma_move(board, 2, 36, 0) == 0 );
assert( gamma_move(board, 2, 1, 65) == 1 );
assert( gamma_free_fields(board, 2) == 178 );
assert( gamma_golden_move(board, 2, 87, 0) == 0 );
assert( gamma_move(board, 3, 54, 1) == 0 );
assert( gamma_move(board, 3, 0, 95) == 1 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 5, 1, 64) == 1 );
assert( gamma_move(board, 5, 0, 80) == 1 );
assert( gamma_move(board, 7, 0, 60) == 1 );
assert( gamma_move(board, 7, 1, 1) == 0 );
assert( gamma_move(board, 8, 0, 29) == 1 );
assert( gamma_move(board, 8, 1, 25) == 1 );
assert( gamma_move(board, 1, 94, 1) == 0 );
assert( gamma_move(board, 1, 0, 53) == 0 );


char* board887022178 = gamma_board(board);
assert( board887022178 != NULL );
assert( strcmp(board887022178, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"46\n"
"1.\n"
".2\n"
"43\n"
"..\n"
".8\n"
"8.\n"
"33\n"
"5.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"..\n"
".3\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"2.\n"
"4.\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"1.\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
"..\n"
"..\n"
"7.\n"
"..\n"
"..\n"
"..\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"..\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"8.\n"
".8\n"
"41\n"
"..\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
"..\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"16\n"
"7.\n") == 0);
free(board887022178);
board887022178 = NULL;
assert( gamma_move(board, 2, 85, 1) == 0 );
assert( gamma_move(board, 2, 0, 84) == 1 );
assert( gamma_move(board, 3, 0, 35) == 1 );
assert( gamma_move(board, 3, 0, 58) == 1 );
assert( gamma_golden_move(board, 3, 102, 1) == 0 );
assert( gamma_move(board, 4, 100, 0) == 0 );
assert( gamma_move(board, 4, 0, 44) == 0 );
assert( gamma_move(board, 5, 109, 1) == 0 );
assert( gamma_move(board, 5, 1, 108) == 1 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_move(board, 7, 22, 0) == 0 );
assert( gamma_move(board, 7, 0, 57) == 1 );
assert( gamma_move(board, 8, 1, 67) == 1 );


char* board799253728 = gamma_board(board);
assert( board799253728 != NULL );
assert( strcmp(board799253728, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
".5\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"46\n"
"1.\n"
".2\n"
"43\n"
"..\n"
".8\n"
"8.\n"
"33\n"
"5.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"..\n"
".3\n"
"3.\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"2.\n"
"4.\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
"..\n"
"..\n"
"7.\n"
"..\n"
"3.\n"
"7.\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"..\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"8.\n"
".8\n"
"41\n"
"..\n"
".8\n"
"..\n"
"..\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
"..\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"16\n"
"7.\n") == 0);
free(board799253728);
board799253728 = NULL;
assert( gamma_move(board, 2, 62, 1) == 0 );
assert( gamma_move(board, 2, 1, 10) == 1 );
assert( gamma_move(board, 3, 0, 65) == 0 );
assert( gamma_move(board, 4, 20, 1) == 0 );
assert( gamma_move(board, 5, 0, 59) == 1 );
assert( gamma_move(board, 5, 1, 108) == 0 );
assert( gamma_free_fields(board, 5) == 164 );
assert( gamma_move(board, 7, 121, 0) == 0 );
assert( gamma_move(board, 7, 0, 23) == 1 );
assert( gamma_free_fields(board, 1) == 163 );
assert( gamma_move(board, 2, 69, 0) == 0 );
assert( gamma_move(board, 3, 90, 1) == 0 );
assert( gamma_move(board, 5, 22, 1) == 0 );
assert( gamma_move(board, 6, 12, 1) == 0 );
assert( gamma_move(board, 7, 1, 89) == 1 );
assert( gamma_move(board, 7, 0, 61) == 1 );
assert( gamma_move(board, 8, 41, 1) == 0 );
assert( gamma_move(board, 1, 22, 1) == 0 );
assert( gamma_move(board, 1, 1, 101) == 1 );
assert( gamma_move(board, 2, 71, 0) == 0 );
assert( gamma_busy_fields(board, 2) == 12 );
assert( gamma_move(board, 3, 66, 1) == 0 );
assert( gamma_move(board, 3, 1, 98) == 1 );
assert( gamma_move(board, 4, 0, 77) == 0 );
assert( gamma_free_fields(board, 4) == 159 );


char* board580514744 = gamma_board(board);
assert( board580514744 != NULL );
assert( strcmp(board580514744, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
".5\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"8.\n"
"33\n"
"5.\n"
"..\n"
".5\n"
"..\n"
"..\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"2.\n"
"4.\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
"..\n"
"7.\n"
"7.\n"
"5.\n"
"3.\n"
"7.\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"..\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"8.\n"
".8\n"
"41\n"
"..\n"
".8\n"
"..\n"
"7.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"..\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"16\n"
"7.\n") == 0);
free(board580514744);
board580514744 = NULL;
assert( gamma_move(board, 6, 76, 1) == 0 );
assert( gamma_busy_fields(board, 7) == 14 );
assert( gamma_move(board, 8, 118, 1) == 0 );
assert( gamma_move(board, 8, 0, 19) == 1 );
assert( gamma_move(board, 1, 36, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 96, 1) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 103, 1) == 0 );
assert( gamma_move(board, 5, 79, 0) == 0 );
assert( gamma_move(board, 5, 0, 76) == 0 );
assert( gamma_move(board, 6, 5, 1) == 0 );


char* board659704228 = gamma_board(board);
assert( board659704228 != NULL );
assert( strcmp(board659704228, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
".5\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"8.\n"
"33\n"
"5.\n"
"..\n"
".5\n"
"..\n"
"..\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"..\n"
"2.\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"2.\n"
"4.\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
"..\n"
"7.\n"
"7.\n"
"5.\n"
"3.\n"
"7.\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"..\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"8.\n"
".8\n"
"41\n"
"..\n"
".8\n"
"..\n"
"7.\n"
"..\n"
"..\n"
"..\n"
"82\n"
"..\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"16\n"
"7.\n") == 0);
free(board659704228);
board659704228 = NULL;
assert( gamma_move(board, 7, 1, 26) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 123, 1) == 0 );
assert( gamma_move(board, 8, 1, 43) == 0 );
assert( gamma_move(board, 1, 0, 80) == 0 );
assert( gamma_move(board, 1, 0, 108) == 1 );
assert( gamma_move(board, 2, 7, 0) == 0 );
assert( gamma_move(board, 3, 33, 0) == 0 );
assert( gamma_move(board, 4, 0, 108) == 0 );
assert( gamma_free_fields(board, 4) == 156 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 36, 0) == 0 );
assert( gamma_move(board, 6, 68, 1) == 0 );
assert( gamma_move(board, 7, 1, 84) == 1 );
assert( gamma_free_fields(board, 7) == 155 );
assert( gamma_move(board, 8, 60, 1) == 0 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 0, 42) == 1 );
assert( gamma_golden_move(board, 1, 19, 1) == 0 );
assert( gamma_move(board, 2, 53, 1) == 0 );
assert( gamma_move(board, 2, 1, 23) == 1 );
assert( gamma_move(board, 3, 0, 20) == 1 );
assert( gamma_move(board, 4, 60, 1) == 0 );
assert( gamma_move(board, 4, 1, 76) == 1 );
assert( gamma_move(board, 5, 21, 0) == 0 );
assert( gamma_free_fields(board, 5) == 151 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 110, 0) == 0 );
assert( gamma_move(board, 6, 1, 82) == 0 );


char* board287731506 = gamma_board(board);
assert( board287731506 != NULL );
assert( strcmp(board287731506, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
"15\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"8.\n"
"33\n"
"5.\n"
"..\n"
".5\n"
"..\n"
"..\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"..\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"2.\n"
"44\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
"..\n"
"7.\n"
"7.\n"
"5.\n"
"3.\n"
"7.\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"1.\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
"..\n"
"2.\n"
"8.\n"
".8\n"
"41\n"
".7\n"
".8\n"
"..\n"
"72\n"
"..\n"
"..\n"
"3.\n"
"82\n"
"..\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
"..\n"
"..\n"
"..\n"
"..\n"
"16\n"
"7.\n") == 0);
free(board287731506);
board287731506 = NULL;
assert( gamma_move(board, 7, 62, 1) == 0 );
assert( gamma_move(board, 1, 48, 0) == 0 );
assert( gamma_move(board, 1, 1, 121) == 0 );
assert( gamma_move(board, 2, 91, 1) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 88, 0) == 0 );
assert( gamma_move(board, 4, 55, 0) == 0 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_move(board, 5, 1, 30) == 1 );
assert( gamma_move(board, 6, 1, 50) == 0 );
assert( gamma_move(board, 1, 32, 1) == 0 );
assert( gamma_free_fields(board, 1) == 149 );
assert( gamma_move(board, 2, 114, 0) == 0 );
assert( gamma_move(board, 2, 1, 31) == 1 );
assert( gamma_free_fields(board, 2) == 148 );
assert( gamma_move(board, 3, 123, 1) == 0 );
assert( gamma_move(board, 4, 1, 77) == 1 );
assert( gamma_move(board, 5, 1, 88) == 0 );
assert( gamma_move(board, 5, 0, 58) == 0 );
assert( gamma_free_fields(board, 5) == 147 );


char* board155940385 = gamma_board(board);
assert( board155940385 != NULL );
assert( strcmp(board155940385, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
"..\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
"15\n"
"..\n"
".1\n"
"..\n"
"..\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"8.\n"
"33\n"
"5.\n"
"..\n"
".5\n"
"..\n"
"..\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"..\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"24\n"
"44\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
"..\n"
"..\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
"..\n"
"7.\n"
"7.\n"
"5.\n"
"3.\n"
"7.\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"1.\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
"..\n"
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"25\n"
"8.\n"
".8\n"
"41\n"
".7\n"
".8\n"
"..\n"
"72\n"
"..\n"
"..\n"
"3.\n"
"82\n"
"..\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"..\n"
"16\n"
"7.\n") == 0);
free(board155940385);
board155940385 = NULL;
assert( gamma_move(board, 6, 24, 1) == 0 );
assert( gamma_move(board, 7, 0, 18) == 1 );
assert( gamma_move(board, 8, 126, 0) == 0 );
assert( gamma_move(board, 8, 1, 43) == 0 );
assert( gamma_move(board, 1, 73, 0) == 0 );
assert( gamma_move(board, 2, 70, 0) == 0 );
assert( gamma_move(board, 2, 1, 59) == 1 );
assert( gamma_move(board, 3, 120, 0) == 0 );
assert( gamma_move(board, 3, 1, 104) == 1 );
assert( gamma_move(board, 5, 0, 94) == 0 );
assert( gamma_golden_move(board, 5, 19, 0) == 0 );
assert( gamma_move(board, 6, 79, 1) == 0 );
assert( gamma_move(board, 6, 1, 96) == 1 );
assert( gamma_move(board, 7, 1, 69) == 1 );
assert( gamma_move(board, 7, 1, 62) == 1 );
assert( gamma_move(board, 8, 1, 29) == 1 );
assert( gamma_move(board, 8, 0, 67) == 0 );
assert( gamma_move(board, 1, 53, 1) == 0 );
assert( gamma_move(board, 2, 1, 101) == 0 );
assert( gamma_free_fields(board, 2) == 140 );
assert( gamma_golden_move(board, 2, 67, 0) == 0 );
assert( gamma_move(board, 3, 1, 90) == 1 );
assert( gamma_move(board, 3, 0, 44) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 4, 80, 1) == 0 );
assert( gamma_golden_move(board, 4, 122, 0) == 0 );
assert( gamma_move(board, 5, 1, 98) == 0 );
assert( gamma_move(board, 5, 0, 66) == 0 );
assert( gamma_move(board, 6, 0, 77) == 0 );
assert( gamma_move(board, 6, 1, 85) == 1 );
assert( gamma_move(board, 7, 4, 1) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 1, 36) == 1 );
assert( gamma_free_fields(board, 8) == 137 );
assert( gamma_move(board, 1, 1, 18) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 88, 0) == 0 );
assert( gamma_move(board, 3, 116, 1) == 0 );
assert( gamma_move(board, 3, 1, 114) == 1 );
assert( gamma_move(board, 4, 0, 2) == 1 );
assert( gamma_move(board, 5, 0, 23) == 0 );
assert( gamma_move(board, 6, 125, 1) == 0 );
assert( gamma_move(board, 6, 1, 91) == 1 );
assert( gamma_move(board, 7, 1, 61) == 1 );


char* board170699926 = gamma_board(board);
assert( board170699926 != NULL );
assert( strcmp(board170699926, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
".3\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"86\n"
"33\n"
"5.\n"
"..\n"
".5\n"
".6\n"
".3\n"
".7\n"
".3\n"
"3.\n"
"..\n"
".6\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"24\n"
"44\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"..\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"1.\n"
"1.\n"
".1\n"
"..\n"
".2\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
".8\n"
"..\n"
"72\n"
"..\n"
"..\n"
"3.\n"
"82\n"
"71\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board170699926);
board170699926 = NULL;
assert( gamma_move(board, 8, 40, 0) == 0 );
assert( gamma_move(board, 8, 0, 29) == 0 );
assert( gamma_move(board, 1, 1, 93) == 1 );
assert( gamma_move(board, 2, 93, 0) == 0 );
assert( gamma_move(board, 2, 1, 22) == 1 );
assert( gamma_move(board, 3, 0, 40) == 1 );
assert( gamma_busy_fields(board, 4) == 11 );
assert( gamma_move(board, 5, 58, 1) == 0 );


char* board204891936 = gamma_board(board);
assert( board204891936 != NULL );
assert( strcmp(board204891936, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
"..\n"
"5.\n"
".3\n"
"..\n"
"..\n"
".3\n"
"8.\n"
".2\n"
".8\n"
"..\n"
"..\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"86\n"
"33\n"
"5.\n"
".1\n"
".5\n"
".6\n"
".3\n"
".7\n"
".3\n"
"3.\n"
"..\n"
".6\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"24\n"
"44\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"..\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"5.\n"
"33\n"
"..\n"
"4.\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
".2\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
".8\n"
"..\n"
"72\n"
".2\n"
"..\n"
"3.\n"
"82\n"
"71\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board204891936);
board204891936 = NULL;
assert( gamma_move(board, 7, 98, 0) == 0 );
assert( gamma_free_fields(board, 7) == 129 );
assert( gamma_move(board, 8, 86, 0) == 0 );
assert( gamma_move(board, 8, 0, 45) == 1 );
assert( gamma_golden_move(board, 8, 56, 1) == 0 );
assert( gamma_move(board, 1, 85, 0) == 0 );
assert( gamma_move(board, 1, 0, 115) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 1, 47) == 1 );
assert( gamma_move(board, 3, 103, 0) == 0 );
assert( gamma_move(board, 4, 1, 59) == 0 );
assert( gamma_move(board, 4, 1, 44) == 1 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 0, 29) == 0 );
assert( gamma_move(board, 5, 1, 109) == 1 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 103, 1) == 0 );
assert( gamma_move(board, 6, 0, 92) == 1 );
assert( gamma_free_fields(board, 6) == 123 );
assert( gamma_move(board, 7, 0, 68) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 0, 72) == 0 );
assert( gamma_move(board, 1, 54, 0) == 0 );
assert( gamma_move(board, 2, 64, 0) == 0 );
assert( gamma_move(board, 3, 0, 87) == 0 );
assert( gamma_golden_move(board, 3, 9, 0) == 0 );
assert( gamma_golden_move(board, 4, 98, 1) == 0 );
assert( gamma_move(board, 5, 32, 1) == 0 );
assert( gamma_move(board, 5, 1, 67) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 110, 1) == 0 );
assert( gamma_move(board, 7, 0, 51) == 0 );
assert( gamma_move(board, 7, 0, 25) == 1 );
assert( gamma_free_fields(board, 7) == 121 );
assert( gamma_move(board, 8, 0, 38) == 1 );
assert( gamma_move(board, 1, 1, 67) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 1, 119) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 66) == 0 );
assert( gamma_move(board, 4, 120, 0) == 0 );
assert( gamma_free_fields(board, 4) == 119 );
assert( gamma_move(board, 5, 1, 82) == 0 );
assert( gamma_move(board, 5, 0, 42) == 0 );


char* board807869856 = gamma_board(board);
assert( board807869856 != NULL );
assert( strcmp(board807869856, 
"7.\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
".4\n"
".2\n"
"5.\n"
".3\n"
"..\n"
"1.\n"
".3\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
".6\n"
".3\n"
".7\n"
".3\n"
"3.\n"
"..\n"
".6\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"24\n"
"44\n"
".8\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"..\n"
"..\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
"78\n"
"..\n"
"72\n"
".2\n"
"..\n"
"3.\n"
"82\n"
"71\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board807869856);
board807869856 = NULL;
assert( gamma_move(board, 6, 42, 1) == 0 );
assert( gamma_move(board, 6, 1, 127) == 1 );
assert( gamma_move(board, 7, 1, 85) == 0 );
assert( gamma_move(board, 8, 54, 0) == 0 );
assert( gamma_move(board, 8, 0, 72) == 0 );
assert( gamma_move(board, 1, 1, 98) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 3, 0, 44) == 0 );
assert( gamma_move(board, 3, 0, 75) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 106, 0) == 0 );
assert( gamma_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 105, 1) == 0 );
assert( gamma_move(board, 6, 0, 63) == 0 );
assert( gamma_move(board, 7, 9, 1) == 0 );
assert( gamma_move(board, 7, 1, 69) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 116, 0) == 0 );
assert( gamma_move(board, 8, 0, 53) == 0 );
assert( gamma_move(board, 1, 126, 1) == 0 );
assert( gamma_move(board, 1, 0, 120) == 1 );
assert( gamma_busy_fields(board, 1) == 20 );
assert( gamma_move(board, 2, 105, 1) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 48, 0) == 0 );
assert( gamma_move(board, 3, 0, 55) == 1 );
assert( gamma_move(board, 4, 1, 101) == 0 );
assert( gamma_move(board, 4, 1, 54) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_busy_fields(board, 5) == 13 );


char* board963312129 = gamma_board(board);
assert( board963312129 != NULL );
assert( strcmp(board963312129, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
".2\n"
"5.\n"
".3\n"
"..\n"
"1.\n"
".3\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
".6\n"
".3\n"
".7\n"
".3\n"
"3.\n"
"..\n"
".6\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"24\n"
"44\n"
"38\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
".4\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
"78\n"
"..\n"
"72\n"
".2\n"
"..\n"
"3.\n"
"82\n"
"71\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board963312129);
board963312129 = NULL;
assert( gamma_move(board, 6, 71, 1) == 0 );
assert( gamma_move(board, 7, 56, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 69, 0) == 0 );
assert( gamma_move(board, 1, 83, 1) == 0 );
assert( gamma_golden_move(board, 1, 125, 0) == 0 );


char* board977565027 = gamma_board(board);
assert( board977565027 != NULL );
assert( strcmp(board977565027, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
".2\n"
"5.\n"
".3\n"
"..\n"
"1.\n"
".3\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"..\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
".8\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
".6\n"
".3\n"
".7\n"
".3\n"
"3.\n"
"..\n"
".6\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
"..\n"
"24\n"
"44\n"
"38\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
".4\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"..\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
"..\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
"78\n"
"..\n"
"72\n"
".2\n"
"..\n"
"3.\n"
"82\n"
"71\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"1.\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board977565027);
board977565027 = NULL;
assert( gamma_move(board, 2, 1, 76) == 0 );
assert( gamma_move(board, 3, 81, 0) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );
assert( gamma_move(board, 4, 15, 1) == 0 );
assert( gamma_move(board, 5, 1, 73) == 0 );
assert( gamma_move(board, 6, 21, 1) == 0 );
assert( gamma_move(board, 6, 1, 48) == 1 );
assert( gamma_move(board, 7, 126, 0) == 0 );
assert( gamma_move(board, 7, 1, 32) == 1 );
assert( gamma_move(board, 1, 0, 47) == 0 );
assert( gamma_move(board, 2, 103, 1) == 0 );
assert( gamma_move(board, 2, 1, 78) == 1 );
assert( gamma_move(board, 3, 118, 1) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 4, 0, 59) == 0 );
assert( gamma_move(board, 5, 1, 30) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 58, 1) == 0 );
assert( gamma_move(board, 6, 1, 48) == 0 );
assert( gamma_move(board, 7, 0, 40) == 0 );
assert( gamma_move(board, 7, 1, 103) == 1 );
assert( gamma_move(board, 8, 24, 0) == 0 );
assert( gamma_move(board, 8, 1, 77) == 0 );
assert( gamma_move(board, 1, 98, 0) == 0 );
assert( gamma_move(board, 1, 1, 99) == 0 );
assert( gamma_free_fields(board, 1) == 110 );
assert( gamma_move(board, 3, 116, 0) == 0 );
assert( gamma_move(board, 3, 0, 97) == 1 );
assert( gamma_move(board, 4, 1, 97) == 0 );
assert( gamma_move(board, 4, 1, 12) == 1 );


char* board264587124 = gamma_board(board);
assert( board264587124 != NULL );
assert( strcmp(board264587124, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
".2\n"
"5.\n"
".3\n"
"..\n"
"1.\n"
".3\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
".7\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
".6\n"
".3\n"
".7\n"
".3\n"
"3.\n"
"..\n"
".6\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"5.\n"
"..\n"
".2\n"
"24\n"
"44\n"
"38\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
".5\n"
"6.\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
".4\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
".6\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
".7\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
"78\n"
"..\n"
"72\n"
".2\n"
"..\n"
"3.\n"
"82\n"
"71\n"
"8.\n"
"87\n"
"..\n"
".7\n"
"14\n"
"14\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board264587124);
board264587124 = NULL;
assert( gamma_move(board, 6, 42, 1) == 0 );
assert( gamma_move(board, 6, 0, 72) == 0 );
assert( gamma_move(board, 1, 88, 0) == 0 );
assert( gamma_move(board, 1, 0, 51) == 0 );
assert( gamma_move(board, 2, 0, 64) == 1 );
assert( gamma_busy_fields(board, 2) == 21 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 30, 1) == 0 );
assert( gamma_move(board, 3, 1, 17) == 1 );
assert( gamma_move(board, 3, 1, 52) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 106, 0) == 0 );
assert( gamma_move(board, 4, 0, 85) == 1 );
assert( gamma_move(board, 5, 0, 115) == 0 );
assert( gamma_move(board, 6, 57, 1) == 0 );
assert( gamma_move(board, 6, 1, 38) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 1, 78) == 0 );
assert( gamma_move(board, 7, 1, 69) == 0 );
assert( gamma_busy_fields(board, 7) == 24 );
assert( gamma_free_fields(board, 8) == 105 );
assert( gamma_move(board, 1, 1, 112) == 0 );
assert( gamma_move(board, 2, 1, 61) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 53, 1) == 0 );
assert( gamma_move(board, 5, 90, 0) == 0 );
assert( gamma_move(board, 6, 79, 0) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 105, 0) == 0 );
assert( gamma_move(board, 1, 24, 1) == 0 );
assert( gamma_move(board, 1, 0, 48) == 1 );
assert( gamma_golden_move(board, 1, 36, 1) == 0 );
assert( gamma_move(board, 2, 79, 1) == 0 );
assert( gamma_move(board, 2, 1, 121) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 106, 0) == 0 );
assert( gamma_move(board, 4, 1, 15) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 93, 0) == 0 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 121, 0) == 0 );
assert( gamma_move(board, 6, 1, 81) == 0 );
assert( gamma_move(board, 7, 90, 0) == 0 );
assert( gamma_move(board, 7, 0, 85) == 0 );
assert( gamma_free_fields(board, 7) == 103 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 21, 0) == 0 );
assert( gamma_move(board, 1, 106, 0) == 0 );
assert( gamma_free_fields(board, 1) == 103 );
assert( gamma_move(board, 2, 22, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 80) == 1 );


char* board556352842 = gamma_board(board);
assert( board556352842 != NULL );
assert( strcmp(board556352842, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
".2\n"
"5.\n"
".3\n"
"..\n"
"1.\n"
".3\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
".7\n"
"46\n"
"11\n"
".2\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
".6\n"
".3\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"53\n"
"..\n"
".2\n"
"24\n"
"44\n"
"38\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"6.\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
".4\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
".7\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
"78\n"
"..\n"
"72\n"
".2\n"
"..\n"
"3.\n"
"82\n"
"71\n"
"83\n"
"87\n"
".4\n"
".7\n"
"14\n"
"14\n"
"..\n"
".2\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board556352842);
board556352842 = NULL;
assert( gamma_move(board, 4, 66, 1) == 0 );
assert( gamma_move(board, 4, 1, 63) == 1 );
assert( gamma_free_fields(board, 4) == 101 );
assert( gamma_move(board, 5, 0, 10) == 1 );
assert( gamma_free_fields(board, 5) == 100 );
assert( gamma_move(board, 6, 126, 0) == 0 );
assert( gamma_move(board, 6, 1, 20) == 1 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 8, 24, 1) == 0 );
assert( gamma_move(board, 8, 1, 43) == 0 );
assert( gamma_move(board, 1, 1, 109) == 0 );
assert( gamma_move(board, 2, 0, 100) == 1 );
assert( gamma_move(board, 2, 1, 38) == 0 );
assert( gamma_move(board, 3, 21, 0) == 0 );
assert( gamma_move(board, 4, 22, 0) == 0 );
assert( gamma_move(board, 4, 1, 116) == 1 );
assert( gamma_move(board, 5, 1, 92) == 0 );
assert( gamma_move(board, 6, 1, 111) == 0 );
assert( gamma_move(board, 6, 0, 96) == 0 );
assert( gamma_free_fields(board, 6) == 97 );
assert( gamma_move(board, 8, 11, 1) == 0 );
assert( gamma_move(board, 8, 0, 85) == 0 );
assert( gamma_move(board, 1, 0, 100) == 0 );
assert( gamma_move(board, 2, 90, 0) == 0 );
assert( gamma_move(board, 2, 0, 97) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 91) == 1 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 5, 1, 21) == 1 );
assert( gamma_move(board, 5, 0, 30) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 37, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 118, 1) == 0 );
assert( gamma_move(board, 7, 0, 103) == 1 );
assert( gamma_free_fields(board, 7) == 94 );
assert( gamma_move(board, 8, 126, 1) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 2, 0, 35) == 0 );
assert( gamma_move(board, 3, 106, 0) == 0 );
assert( gamma_move(board, 3, 0, 67) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 105, 1) == 0 );
assert( gamma_move(board, 5, 0, 20) == 0 );
assert( gamma_move(board, 5, 0, 99) == 0 );
assert( gamma_move(board, 6, 0, 16) == 0 );
assert( gamma_move(board, 7, 113, 1) == 0 );
assert( gamma_move(board, 7, 0, 114) == 1 );
assert( gamma_move(board, 8, 1, 26) == 0 );
assert( gamma_move(board, 8, 1, 90) == 0 );
assert( gamma_golden_move(board, 8, 120, 0) == 0 );
assert( gamma_move(board, 1, 1, 15) == 0 );
assert( gamma_move(board, 2, 0, 120) == 0 );
assert( gamma_move(board, 2, 0, 55) == 0 );
assert( gamma_move(board, 3, 107, 0) == 0 );
assert( gamma_golden_move(board, 3, 48, 0) == 0 );
assert( gamma_move(board, 4, 119, 0) == 0 );
assert( gamma_move(board, 4, 1, 117) == 0 );
assert( gamma_move(board, 5, 0, 127) == 0 );
assert( gamma_free_fields(board, 5) == 93 );
assert( gamma_free_fields(board, 6) == 93 );
assert( gamma_move(board, 7, 69, 0) == 0 );
assert( gamma_move(board, 7, 0, 47) == 0 );
assert( gamma_move(board, 8, 0, 90) == 1 );
assert( gamma_move(board, 1, 107, 0) == 0 );
assert( gamma_move(board, 1, 0, 48) == 0 );
assert( gamma_move(board, 2, 0, 102) == 0 );
assert( gamma_move(board, 2, 0, 77) == 0 );


char* board534624406 = gamma_board(board);
assert( board534624406 != NULL );
assert( strcmp(board534624406, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
".2\n"
"5.\n"
".3\n"
".4\n"
"1.\n"
"73\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"77\n"
"46\n"
"11\n"
"22\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
"36\n"
"83\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"53\n"
"..\n"
".2\n"
"24\n"
"44\n"
"38\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"64\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
".4\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
".7\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
"78\n"
"..\n"
"72\n"
".2\n"
".5\n"
"36\n"
"82\n"
"71\n"
"83\n"
"87\n"
".4\n"
".7\n"
"14\n"
"14\n"
"..\n"
"52\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board534624406);
board534624406 = NULL;
assert( gamma_move(board, 3, 81, 0) == 0 );
assert( gamma_move(board, 3, 0, 18) == 0 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_move(board, 4, 0, 19) == 0 );


char* board710917438 = gamma_board(board);
assert( board710917438 != NULL );
assert( strcmp(board710917438, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
".2\n"
"5.\n"
".3\n"
".4\n"
"1.\n"
"73\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"77\n"
"46\n"
"11\n"
"22\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
"36\n"
"83\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"53\n"
"..\n"
".2\n"
"24\n"
"44\n"
"38\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"64\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
".4\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
".7\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
"78\n"
"..\n"
"72\n"
".2\n"
".5\n"
"36\n"
"82\n"
"71\n"
"83\n"
"87\n"
".4\n"
".7\n"
"14\n"
"14\n"
"..\n"
"52\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"..\n"
"4.\n"
"16\n"
"7.\n") == 0);
free(board710917438);
board710917438 = NULL;
assert( gamma_move(board, 5, 0, 15) == 1 );
assert( gamma_move(board, 6, 3, 0) == 0 );
assert( gamma_move(board, 7, 111, 0) == 0 );
assert( gamma_move(board, 7, 0, 13) == 0 );
assert( gamma_move(board, 8, 1, 1) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_golden_move(board, 8, 46, 0) == 0 );
assert( gamma_move(board, 1, 112, 0) == 0 );
assert( gamma_move(board, 2, 33, 1) == 0 );
assert( gamma_move(board, 3, 60, 1) == 0 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 117, 0) == 0 );
assert( gamma_move(board, 5, 121, 0) == 0 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 7, 1, 0) == 1 );
assert( gamma_move(board, 8, 34, 1) == 0 );
assert( gamma_move(board, 8, 1, 22) == 0 );
assert( gamma_move(board, 1, 0, 30) == 0 );
assert( gamma_move(board, 1, 1, 52) == 0 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_move(board, 4, 66, 1) == 0 );
assert( gamma_move(board, 4, 1, 120) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 5, 0, 52) == 0 );
assert( gamma_move(board, 6, 2, 1) == 0 );
assert( gamma_move(board, 7, 94, 1) == 0 );
assert( gamma_move(board, 7, 1, 30) == 0 );
assert( gamma_move(board, 8, 79, 0) == 0 );
assert( gamma_move(board, 8, 0, 24) == 1 );
assert( gamma_busy_fields(board, 8) == 19 );


char* board657569447 = gamma_board(board);
assert( board657569447 != NULL );
assert( strcmp(board657569447, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
".2\n"
"5.\n"
".3\n"
".4\n"
"1.\n"
"73\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"77\n"
"46\n"
"11\n"
"22\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
"36\n"
"83\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"53\n"
"..\n"
".2\n"
"24\n"
"44\n"
"38\n"
".6\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"64\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
".4\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
".7\n"
".2\n"
"25\n"
"88\n"
".8\n"
"41\n"
".7\n"
"78\n"
"8.\n"
"72\n"
".2\n"
".5\n"
"36\n"
"82\n"
"71\n"
"83\n"
"87\n"
"54\n"
".7\n"
"14\n"
"14\n"
"..\n"
"52\n"
"8.\n"
"5.\n"
"..\n"
".3\n"
".2\n"
"..\n"
"3.\n"
"4.\n"
"16\n"
"77\n") == 0);
free(board657569447);
board657569447 = NULL;
assert( gamma_move(board, 1, 123, 1) == 0 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 2, 0, 54) == 1 );
assert( gamma_move(board, 3, 0, 31) == 1 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 125, 1) == 0 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 1, 27) == 0 );
assert( gamma_move(board, 6, 0, 26) == 1 );
assert( gamma_move(board, 6, 0, 96) == 0 );
assert( gamma_move(board, 7, 78, 0) == 0 );
assert( gamma_free_fields(board, 7) == 84 );
assert( gamma_move(board, 8, 126, 0) == 0 );
assert( gamma_move(board, 8, 0, 85) == 0 );
assert( gamma_move(board, 1, 55, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 33, 1) == 0 );
assert( gamma_move(board, 2, 0, 87) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 1, 101) == 0 );
assert( gamma_move(board, 4, 70, 0) == 0 );
assert( gamma_move(board, 4, 1, 38) == 0 );
assert( gamma_move(board, 5, 70, 0) == 0 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_move(board, 7, 0, 74) == 1 );
assert( gamma_move(board, 7, 1, 22) == 0 );
assert( gamma_golden_move(board, 7, 12, 0) == 0 );
assert( gamma_move(board, 8, 0, 3) == 0 );
assert( gamma_move(board, 8, 1, 12) == 0 );
assert( gamma_free_fields(board, 8) == 83 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 45, 1) == 0 );
assert( gamma_move(board, 1, 0, 30) == 0 );
assert( gamma_free_fields(board, 1) == 83 );
assert( gamma_move(board, 3, 0, 51) == 0 );
assert( gamma_move(board, 3, 0, 119) == 1 );
assert( gamma_move(board, 4, 109, 0) == 0 );


char* board324151875 = gamma_board(board);
assert( board324151875 != NULL );
assert( strcmp(board324151875, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
"32\n"
"5.\n"
".3\n"
".4\n"
"1.\n"
"73\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"..\n"
".1\n"
"..\n"
".3\n"
"77\n"
"46\n"
"11\n"
"22\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
"36\n"
"83\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"53\n"
"..\n"
".2\n"
"24\n"
"44\n"
"38\n"
"76\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"64\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
"24\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
".7\n"
"32\n"
"25\n"
"88\n"
".8\n"
"41\n"
"67\n"
"78\n"
"8.\n"
"72\n"
".2\n"
".5\n"
"36\n"
"82\n"
"71\n"
"83\n"
"87\n"
"54\n"
".7\n"
"14\n"
"14\n"
"..\n"
"52\n"
"8.\n"
"5.\n"
".4\n"
".3\n"
".2\n"
"..\n"
"3.\n"
"4.\n"
"16\n"
"77\n") == 0);
free(board324151875);
board324151875 = NULL;
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_move(board, 6, 5, 0) == 0 );
assert( gamma_move(board, 6, 0, 107) == 1 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_golden_move(board, 6, 94, 0) == 0 );
assert( gamma_move(board, 7, 106, 0) == 0 );
assert( gamma_move(board, 7, 0, 75) == 0 );
assert( gamma_golden_move(board, 7, 67, 1) == 0 );
assert( gamma_move(board, 8, 105, 1) == 0 );
assert( gamma_move(board, 8, 1, 114) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 56, 0) == 0 );
assert( gamma_move(board, 2, 0, 120) == 0 );
assert( gamma_move(board, 3, 1, 11) == 1 );
assert( gamma_move(board, 3, 1, 82) == 0 );
assert( gamma_move(board, 4, 83, 1) == 0 );
assert( gamma_move(board, 4, 0, 31) == 0 );
assert( gamma_free_fields(board, 4) == 80 );
assert( gamma_busy_fields(board, 5) == 16 );


char* board247680310 = gamma_board(board);
assert( board247680310 != NULL );
assert( strcmp(board247680310, 
"76\n"
"..\n"
"7.\n"
"1.\n"
"7.\n"
"66\n"
".2\n"
"14\n"
"32\n"
"5.\n"
".3\n"
".4\n"
"1.\n"
"73\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"6.\n"
".1\n"
"..\n"
".3\n"
"77\n"
"46\n"
"11\n"
"22\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
".1\n"
"65\n"
"36\n"
"83\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"6.\n"
"67\n"
".1\n"
"53\n"
"..\n"
".2\n"
"24\n"
"44\n"
"38\n"
"76\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"64\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"3.\n"
"7.\n"
".6\n"
"3.\n"
"24\n"
"7.\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
".8\n"
"3.\n"
"..\n"
"..\n"
".7\n"
"32\n"
"25\n"
"88\n"
".8\n"
"41\n"
"67\n"
"78\n"
"8.\n"
"72\n"
".2\n"
".5\n"
"36\n"
"82\n"
"71\n"
"83\n"
"87\n"
"54\n"
".7\n"
"14\n"
"14\n"
".3\n"
"52\n"
"8.\n"
"5.\n"
".4\n"
".3\n"
".2\n"
"..\n"
"3.\n"
"4.\n"
"16\n"
"77\n") == 0);
free(board247680310);
board247680310 = NULL;
assert( gamma_move(board, 6, 112, 0) == 0 );
assert( gamma_move(board, 6, 0, 66) == 0 );
assert( gamma_move(board, 7, 35, 1) == 0 );
assert( gamma_move(board, 8, 60, 1) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 1, 77) == 0 );
assert( gamma_move(board, 2, 0, 107) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );
assert( gamma_move(board, 3, 71, 1) == 0 );
assert( gamma_move(board, 3, 1, 56) == 0 );
assert( gamma_move(board, 4, 34, 1) == 0 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 5, 22, 0) == 0 );
assert( gamma_move(board, 5, 0, 36) == 1 );
assert( gamma_move(board, 6, 110, 0) == 0 );
assert( gamma_free_fields(board, 6) == 78 );
assert( gamma_move(board, 7, 0, 55) == 0 );
assert( gamma_move(board, 7, 0, 34) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 53, 1) == 0 );
assert( gamma_move(board, 8, 0, 59) == 0 );
assert( gamma_move(board, 2, 1, 7) == 0 );
assert( gamma_move(board, 2, 0, 1) == 0 );
assert( gamma_move(board, 3, 1, 19) == 0 );
assert( gamma_move(board, 3, 1, 124) == 1 );
assert( gamma_move(board, 4, 115, 1) == 0 );
assert( gamma_move(board, 6, 4, 0) == 0 );
assert( gamma_move(board, 7, 86, 0) == 0 );
assert( gamma_move(board, 7, 1, 79) == 1 );
assert( gamma_free_fields(board, 7) == 75 );
assert( gamma_move(board, 8, 11, 0) == 0 );
assert( gamma_busy_fields(board, 8) == 19 );
assert( gamma_free_fields(board, 8) == 75 );
assert( gamma_move(board, 1, 33, 1) == 0 );
assert( gamma_free_fields(board, 1) == 75 );
assert( gamma_move(board, 2, 60, 1) == 0 );
assert( gamma_move(board, 3, 83, 1) == 0 );
assert( gamma_move(board, 3, 1, 121) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 24, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 0, 125) == 0 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_free_fields(board, 5) == 75 );
assert( gamma_move(board, 6, 22, 0) == 0 );
assert( gamma_move(board, 7, 123, 1) == 0 );
assert( gamma_move(board, 8, 45, 1) == 0 );
assert( gamma_move(board, 1, 14, 0) == 0 );
assert( gamma_move(board, 1, 0, 31) == 0 );
assert( gamma_move(board, 2, 33, 0) == 0 );
assert( gamma_free_fields(board, 2) == 75 );
assert( gamma_move(board, 3, 0, 93) == 1 );
assert( gamma_move(board, 3, 1, 105) == 1 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 50, 0) == 0 );
assert( gamma_move(board, 5, 110, 0) == 0 );
assert( gamma_move(board, 5, 1, 111) == 0 );
assert( gamma_move(board, 6, 33, 1) == 0 );
assert( gamma_free_fields(board, 6) == 73 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 7, 1, 58) == 1 );
assert( gamma_free_fields(board, 7) == 72 );
assert( gamma_move(board, 8, 72, 1) == 0 );
assert( gamma_move(board, 1, 0, 59) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 33) == 1 );
assert( gamma_move(board, 2, 0, 64) == 0 );
assert( gamma_move(board, 3, 34, 1) == 0 );
assert( gamma_move(board, 4, 1, 83) == 1 );
assert( gamma_move(board, 4, 0, 117) == 1 );
assert( gamma_move(board, 5, 0, 22) == 1 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 6, 1, 4) == 1 );
assert( gamma_golden_move(board, 6, 47, 1) == 0 );
assert( gamma_move(board, 7, 112, 0) == 0 );
assert( gamma_move(board, 7, 0, 36) == 0 );
assert( gamma_move(board, 8, 125, 1) == 0 );
assert( gamma_move(board, 8, 1, 100) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 89, 0) == 0 );
assert( gamma_move(board, 1, 1, 53) == 1 );
assert( gamma_move(board, 2, 1, 23) == 0 );
assert( gamma_move(board, 2, 0, 92) == 0 );
assert( gamma_move(board, 3, 28, 0) == 0 );
assert( gamma_move(board, 4, 88, 0) == 0 );
assert( gamma_move(board, 4, 1, 65) == 0 );


char* board756762733 = gamma_board(board);
assert( board756762733 != NULL );
assert( strcmp(board756762733, 
"76\n"
"..\n"
"7.\n"
"13\n"
"7.\n"
"66\n"
".2\n"
"14\n"
"32\n"
"5.\n"
"43\n"
".4\n"
"1.\n"
"73\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"6.\n"
".1\n"
".3\n"
".3\n"
"77\n"
"46\n"
"11\n"
"22\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
"31\n"
"65\n"
"36\n"
"83\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"64\n"
"67\n"
".1\n"
"53\n"
".7\n"
".2\n"
"24\n"
"44\n"
"38\n"
"76\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"64\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"37\n"
"7.\n"
".6\n"
"3.\n"
"24\n"
"71\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
"58\n"
"3.\n"
"7.\n"
"2.\n"
".7\n"
"32\n"
"25\n"
"88\n"
".8\n"
"41\n"
"67\n"
"78\n"
"8.\n"
"72\n"
"52\n"
".5\n"
"36\n"
"82\n"
"71\n"
"83\n"
"87\n"
"54\n"
".7\n"
"14\n"
"14\n"
".3\n"
"52\n"
"8.\n"
"5.\n"
"44\n"
".3\n"
".2\n"
".6\n"
"3.\n"
"4.\n"
"16\n"
"77\n") == 0);
free(board756762733);
board756762733 = NULL;
assert( gamma_move(board, 5, 55, 1) == 0 );
assert( gamma_move(board, 6, 115, 1) == 0 );
assert( gamma_move(board, 6, 0, 83) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 42, 1) == 0 );
assert( gamma_move(board, 8, 118, 1) == 0 );
assert( gamma_move(board, 8, 0, 45) == 0 );
assert( gamma_move(board, 1, 32, 0) == 0 );
assert( gamma_free_fields(board, 1) == 66 );
assert( gamma_move(board, 2, 1, 120) == 0 );
assert( gamma_move(board, 3, 87, 1) == 0 );
assert( gamma_move(board, 3, 0, 119) == 0 );
assert( gamma_move(board, 4, 0, 68) == 0 );
assert( gamma_move(board, 5, 0, 93) == 0 );
assert( gamma_move(board, 5, 1, 43) == 0 );
assert( gamma_move(board, 6, 68, 1) == 0 );
assert( gamma_move(board, 6, 0, 115) == 0 );
assert( gamma_move(board, 7, 0, 104) == 1 );
assert( gamma_free_fields(board, 7) == 65 );
assert( gamma_move(board, 8, 1, 28) == 0 );
assert( gamma_move(board, 8, 1, 36) == 0 );
assert( gamma_move(board, 2, 126, 0) == 0 );
assert( gamma_move(board, 2, 0, 46) == 0 );


char* board526533022 = gamma_board(board);
assert( board526533022 != NULL );
assert( strcmp(board526533022, 
"76\n"
"..\n"
"7.\n"
"13\n"
"7.\n"
"66\n"
".2\n"
"14\n"
"32\n"
"5.\n"
"43\n"
".4\n"
"1.\n"
"73\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"6.\n"
".1\n"
".3\n"
"73\n"
"77\n"
"46\n"
"11\n"
"22\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
"31\n"
"65\n"
"36\n"
"83\n"
".7\n"
".3\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"64\n"
"67\n"
".1\n"
"53\n"
".7\n"
".2\n"
"24\n"
"44\n"
"38\n"
"76\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"64\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"37\n"
"7.\n"
".6\n"
"3.\n"
"24\n"
"71\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
"58\n"
"3.\n"
"7.\n"
"2.\n"
".7\n"
"32\n"
"25\n"
"88\n"
".8\n"
"41\n"
"67\n"
"78\n"
"8.\n"
"72\n"
"52\n"
".5\n"
"36\n"
"82\n"
"71\n"
"83\n"
"87\n"
"54\n"
".7\n"
"14\n"
"14\n"
".3\n"
"52\n"
"8.\n"
"5.\n"
"44\n"
".3\n"
".2\n"
".6\n"
"3.\n"
"4.\n"
"16\n"
"77\n") == 0);
free(board526533022);
board526533022 = NULL;
assert( gamma_move(board, 3, 98, 0) == 0 );
assert( gamma_move(board, 3, 0, 88) == 1 );


char* board858107697 = gamma_board(board);
assert( board858107697 != NULL );
assert( strcmp(board858107697, 
"76\n"
"..\n"
"7.\n"
"13\n"
"7.\n"
"66\n"
".2\n"
"14\n"
"32\n"
"5.\n"
"43\n"
".4\n"
"1.\n"
"73\n"
"8.\n"
".2\n"
".8\n"
"..\n"
".5\n"
"15\n"
"6.\n"
".1\n"
".3\n"
"73\n"
"77\n"
"46\n"
"11\n"
"22\n"
"43\n"
".3\n"
"38\n"
"86\n"
"33\n"
"5.\n"
"31\n"
"65\n"
"36\n"
"83\n"
".7\n"
"33\n"
"3.\n"
"..\n"
"46\n"
"27\n"
"64\n"
"67\n"
".1\n"
"53\n"
".7\n"
".2\n"
"24\n"
"44\n"
"38\n"
"76\n"
".2\n"
"6.\n"
"..\n"
".5\n"
".7\n"
"7.\n"
"18\n"
"7.\n"
"12\n"
"25\n"
"64\n"
".7\n"
"77\n"
"7.\n"
"52\n"
"37\n"
"7.\n"
".6\n"
"3.\n"
"24\n"
"71\n"
"23\n"
"6.\n"
".4\n"
"3.\n"
"16\n"
"52\n"
"33\n"
"8.\n"
"44\n"
"51\n"
"1.\n"
"1.\n"
"31\n"
"..\n"
"82\n"
"3.\n"
"58\n"
"3.\n"
"7.\n"
"2.\n"
".7\n"
"32\n"
"25\n"
"88\n"
".8\n"
"41\n"
"67\n"
"78\n"
"8.\n"
"72\n"
"52\n"
".5\n"
"36\n"
"82\n"
"71\n"
"83\n"
"87\n"
"54\n"
".7\n"
"14\n"
"14\n"
".3\n"
"52\n"
"8.\n"
"5.\n"
"44\n"
".3\n"
".2\n"
".6\n"
"3.\n"
"4.\n"
"16\n"
"77\n") == 0);
free(board858107697);
board858107697 = NULL;
assert( gamma_move(board, 4, 0, 34) == 0 );
assert( gamma_move(board, 5, 60, 1) == 0 );
assert( gamma_move(board, 5, 1, 72) == 1 );
assert( gamma_move(board, 7, 68, 1) == 0 );
assert( gamma_move(board, 7, 1, 42) == 1 );
assert( gamma_move(board, 8, 28, 0) == 0 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 81, 0) == 0 );
assert( gamma_move(board, 2, 0, 89) == 1 );
assert( gamma_move(board, 2, 0, 27) == 0 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 79, 0) == 0 );
assert( gamma_move(board, 3, 0, 113) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 60, 1) == 0 );
assert( gamma_free_fields(board, 4) == 61 );
assert( gamma_move(board, 5, 1, 114) == 0 );
assert( gamma_move(board, 7, 1, 1) == 0 );
assert( gamma_golden_move(board, 7, 101, 0) == 0 );
assert( gamma_move(board, 8, 87, 1) == 0 );
assert( gamma_move(board, 8, 0, 74) == 0 );
assert( gamma_busy_fields(board, 8) == 19 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 1, 0, 37) == 0 );
assert( gamma_move(board, 2, 9, 1) == 0 );
assert( gamma_move(board, 3, 0, 63) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 94, 1) == 0 );
assert( gamma_move(board, 5, 0, 126) == 1 );
assert( gamma_move(board, 5, 1, 2) == 1 );
assert( gamma_move(board, 6, 1, 75) == 0 );
assert( gamma_move(board, 7, 35, 1) == 0 );
assert( gamma_move(board, 7, 1, 30) == 0 );
assert( gamma_move(board, 8, 24, 1) == 0 );
assert( gamma_move(board, 8, 1, 49) == 1 );
assert( gamma_move(board, 1, 1, 14) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 2, 5, 0) == 0 );
assert( gamma_move(board, 3, 1, 44) == 0 );
assert( gamma_move(board, 3, 1, 48) == 0 );
assert( gamma_move(board, 4, 1, 25) == 0 );
assert( gamma_move(board, 5, 110, 0) == 0 );
assert( gamma_move(board, 6, 41, 1) == 0 );
assert( gamma_move(board, 6, 0, 76) == 0 );
assert( gamma_free_fields(board, 6) == 58 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 8, 62, 0) == 0 );


gamma_delete(board);

    return 0;
}
