#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 133366754
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(1, 3, 3, 1);
assert( board != NULL );


assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_golden_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_free_fields(board, 3) == 2 );


char* board705835140 = gamma_board(board);
assert( board705835140 != NULL );
assert( strcmp(board705835140, 
"2\n"
".\n"
".\n") == 0);
free(board705835140);
board705835140 = NULL;
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_free_fields(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 3, 0, 1) == 1 );


gamma_delete(board);

    return 0;
}
