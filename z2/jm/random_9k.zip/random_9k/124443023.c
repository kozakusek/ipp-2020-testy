#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 124443023
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(11, 15, 7, 12);
assert( board != NULL );


assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 13) == 1 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_move(board, 4, 4, 12) == 1 );
assert( gamma_move(board, 5, 9, 10) == 1 );
assert( gamma_move(board, 6, 5, 6) == 1 );
assert( gamma_move(board, 7, 1, 8) == 1 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 1, 6, 4) == 1 );
assert( gamma_move(board, 2, 6, 6) == 1 );
assert( gamma_move(board, 3, 2, 6) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 4, 8, 5) == 1 );
assert( gamma_move(board, 5, 3, 12) == 1 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_move(board, 7, 4, 0) == 1 );
assert( gamma_free_fields(board, 7) == 148 );
assert( gamma_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 1, 6, 2) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 3, 0, 2) == 1 );
assert( gamma_move(board, 4, 12, 0) == 0 );
assert( gamma_move(board, 4, 1, 7) == 1 );
assert( gamma_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 13, 9) == 0 );
assert( gamma_move(board, 6, 7, 4) == 1 );
assert( gamma_move(board, 7, 10, 0) == 1 );
assert( gamma_move(board, 7, 3, 7) == 1 );
assert( gamma_busy_fields(board, 7) == 4 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 1, 4, 11) == 1 );


char* board733903880 = gamma_board(board);
assert( board733903880 != NULL );
assert( strcmp(board733903880, 
"...........\n"
"........3..\n"
"...54......\n"
"....1......\n"
".......1.5.\n"
"...........\n"
".7.........\n"
".4.7...1...\n"
"..3..62.2..\n"
"........4..\n"
".3....16...\n"
".3..2......\n"
"3.....1....\n"
"...........\n"
"..3.71....7\n") == 0);
free(board733903880);
board733903880 = NULL;
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_free_fields(board, 2) == 139 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 3, 10, 10) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board952984313 = gamma_board(board);
assert( board952984313 != NULL );
assert( strcmp(board952984313, 
"...........\n"
"........3..\n"
"...54......\n"
"....1......\n"
".......1.53\n"
"....3......\n"
".7.........\n"
".4.7...1...\n"
"..3..62.2..\n"
"........4..\n"
".3....16...\n"
".3..2......\n"
"3.....1....\n"
"...........\n"
"..3.71....7\n") == 0);
free(board952984313);
board952984313 = NULL;
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_free_fields(board, 4) == 137 );
assert( gamma_move(board, 5, 13, 6) == 0 );
assert( gamma_move(board, 5, 4, 6) == 1 );
assert( gamma_move(board, 6, 5, 5) == 1 );
assert( gamma_move(board, 6, 9, 11) == 1 );


char* board444042859 = gamma_board(board);
assert( board444042859 != NULL );
assert( strcmp(board444042859, 
"...........\n"
"........3..\n"
"...54......\n"
"....1....6.\n"
".......1.53\n"
"....3......\n"
".7.........\n"
".4.7...1...\n"
"..3.562.2..\n"
".....6..4..\n"
".3....16...\n"
".3..2......\n"
"3.....1....\n"
"...........\n"
"..3.71....7\n") == 0);
free(board444042859);
board444042859 = NULL;
assert( gamma_move(board, 7, 4, 4) == 1 );
assert( gamma_move(board, 7, 4, 0) == 0 );
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_move(board, 2, 6, 11) == 1 );
assert( gamma_move(board, 2, 9, 7) == 1 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_move(board, 3, 5, 11) == 1 );
assert( gamma_move(board, 4, 1, 13) == 1 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_busy_fields(board, 5) == 3 );
assert( gamma_move(board, 6, 9, 7) == 0 );
assert( gamma_move(board, 6, 10, 1) == 1 );
assert( gamma_move(board, 7, 9, 9) == 1 );
assert( gamma_move(board, 1, 2, 2) == 1 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );


char* board793067737 = gamma_board(board);
assert( board793067737 != NULL );
assert( strcmp(board793067737, 
"...........\n"
".4......3..\n"
"...54......\n"
"..3.132..6.\n"
"4......1.53\n"
"....3....7.\n"
".7.........\n"
".4.7...1.2.\n"
"..3.562.2..\n"
".....6..4..\n"
".3..7316...\n"
".3..2......\n"
"3.1...1....\n"
"1.........6\n"
"..3.71....7\n") == 0);
free(board793067737);
board793067737 = NULL;
assert( gamma_move(board, 4, 10, 0) == 0 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 5, 7, 3) == 1 );
assert( gamma_move(board, 5, 4, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 6, 3) == 1 );
assert( gamma_move(board, 7, 6, 4) == 0 );
assert( gamma_move(board, 7, 9, 1) == 1 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 5, 11, 8) == 0 );
assert( gamma_move(board, 5, 1, 0) == 1 );
assert( gamma_busy_fields(board, 5) == 5 );
assert( gamma_free_fields(board, 5) == 116 );
assert( gamma_move(board, 6, 6, 0) == 1 );
assert( gamma_move(board, 6, 0, 13) == 1 );
assert( gamma_move(board, 7, 2, 10) == 1 );
assert( gamma_move(board, 7, 0, 5) == 1 );


char* board926713086 = gamma_board(board);
assert( board926713086 != NULL );
assert( strcmp(board926713086, 
"...........\n"
"64......3..\n"
"...54......\n"
"..3.132..6.\n"
"4.7....1.53\n"
"....3....7.\n"
".7........1\n"
"44.7...1.2.\n"
"..3.562.2..\n"
"7....6..4..\n"
".3..7316...\n"
".3..2.65...\n"
"3.1...1....\n"
"1........76\n"
".53.716...7\n") == 0);
free(board926713086);
board926713086 = NULL;
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_golden_move(board, 4, 5, 5) == 1 );
assert( gamma_move(board, 5, 4, 9) == 0 );
assert( gamma_move(board, 5, 0, 12) == 1 );


char* board545982791 = gamma_board(board);
assert( board545982791 != NULL );
assert( strcmp(board545982791, 
"...........\n"
"64......3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.7....1.53\n"
"....3....7.\n"
".7........1\n"
"44.7...1.2.\n"
"..3.562.2..\n"
"7....4..4..\n"
".3..7316...\n"
".3..2.65...\n"
"3.1...1....\n"
"1........76\n"
".53.716...7\n") == 0);
free(board545982791);
board545982791 = NULL;
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board962893518 = gamma_board(board);
assert( board962893518 != NULL );
assert( strcmp(board962893518, 
"...........\n"
"64......3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.7....1.53\n"
"....3....7.\n"
".7........1\n"
"44.7...1.2.\n"
"..3.562.2..\n"
"7....4..4..\n"
".3..7316...\n"
".3..2.65...\n"
"3.1...1....\n"
"1........76\n"
".53.716...7\n") == 0);
free(board962893518);
board962893518 = NULL;
assert( gamma_move(board, 7, 3, 5) == 1 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 3, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_move(board, 4, 11, 1) == 0 );
assert( gamma_move(board, 5, 4, 2) == 1 );
assert( gamma_move(board, 5, 0, 14) == 1 );
assert( gamma_move(board, 6, 4, 10) == 1 );
assert( gamma_free_fields(board, 6) == 105 );
assert( gamma_move(board, 7, 6, 9) == 1 );
assert( gamma_free_fields(board, 7) == 104 );
assert( gamma_golden_move(board, 7, 5, 5) == 1 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_golden_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 13, 2) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_free_fields(board, 3) == 104 );
assert( gamma_move(board, 4, 0, 9) == 1 );
assert( gamma_move(board, 5, 2, 6) == 0 );


char* board926760179 = gamma_board(board);
assert( board926760179 != NULL );
assert( strcmp(board926760179, 
"5..........\n"
"64......3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.7.6..1.53\n"
"4..23.7..7.\n"
".7........1\n"
"44.7...1.2.\n"
"..3.562.2..\n"
"7..7.7..4..\n"
".3..7316...\n"
".3.12.65...\n"
"3.1.5.1....\n"
"1........76\n"
".53.716...7\n") == 0);
free(board926760179);
board926760179 = NULL;
assert( gamma_move(board, 6, 7, 2) == 1 );
assert( gamma_free_fields(board, 6) == 102 );
assert( gamma_move(board, 7, 4, 9) == 0 );
assert( gamma_move(board, 7, 0, 12) == 0 );
assert( gamma_move(board, 1, 3, 10) == 1 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_free_fields(board, 1) == 101 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_free_fields(board, 2) == 100 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_move(board, 4, 7, 9) == 1 );
assert( gamma_golden_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 7, 14, 5) == 0 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_move(board, 2, 5, 7) == 1 );
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_golden_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_free_fields(board, 4) == 96 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 6, 6, 4) == 0 );
assert( gamma_move(board, 6, 10, 4) == 1 );
assert( gamma_free_fields(board, 6) == 95 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 2) == 1 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 1, 10, 6) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 1 );
assert( gamma_move(board, 3, 9, 0) == 1 );


char* board289957751 = gamma_board(board);
assert( board289957751 != NULL );
assert( strcmp(board289957751, 
"5...2......\n"
"64......3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.716..1.53\n"
"4..23.74.7.\n"
".7........1\n"
"44.7.2.1.2.\n"
"..3.562.2.1\n"
"7..7.7..4..\n"
".33.7316..6\n"
"23.12.65...\n"
"3.1.5.16.7.\n"
"1....2...76\n"
".53.716..37\n") == 0);
free(board289957751);
board289957751 = NULL;
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 5, 1, 1) == 1 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 6, 8, 2) == 1 );
assert( gamma_move(board, 7, 4, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 7, 6) == 1 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );


char* board705109525 = gamma_board(board);
assert( board705109525 != NULL );
assert( strcmp(board705109525, 
"5...2......\n"
"64......3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.716..1.53\n"
"4..23.74.7.\n"
".7........1\n"
"44.7.2.1.2.\n"
"..3.56212.1\n"
"7..7.7..4..\n"
".33.7316..6\n"
"23.12.65...\n"
"3.1.5.1667.\n"
"15...2...76\n"
".53.716..37\n") == 0);
free(board705109525);
board705109525 = NULL;
assert( gamma_move(board, 5, 9, 2) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 14, 8) == 0 );
assert( gamma_move(board, 6, 10, 9) == 1 );
assert( gamma_move(board, 7, 13, 10) == 0 );
assert( gamma_move(board, 7, 2, 12) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_free_fields(board, 1) == 21 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_free_fields(board, 2) == 87 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 3, 2) == 1 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_free_fields(board, 4) == 86 );


char* board200449379 = gamma_board(board);
assert( board200449379 != NULL );
assert( strcmp(board200449379, 
"5...2......\n"
"64......3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.716..1.53\n"
"4..23.74.76\n"
".7........1\n"
"44.7.2.1.2.\n"
"..3.56212.1\n"
"7..7.7..4..\n"
".33.7316..6\n"
"23.12.65...\n"
"3.135.1667.\n"
"15...2...76\n"
".53.716..37\n") == 0);
free(board200449379);
board200449379 = NULL;
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 7, 9, 8) == 1 );
assert( gamma_move(board, 7, 10, 6) == 0 );
assert( gamma_free_fields(board, 7) == 26 );
assert( gamma_move(board, 1, 6, 7) == 1 );
assert( gamma_move(board, 1, 2, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 2, 6, 11) == 0 );
assert( gamma_golden_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 10, 5) == 1 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 5, 11, 8) == 0 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 6, 2, 1) == 1 );
assert( gamma_move(board, 6, 3, 7) == 0 );
assert( gamma_move(board, 7, 5, 7) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_move(board, 4, 3, 12) == 0 );
assert( gamma_move(board, 5, 5, 3) == 1 );
assert( gamma_move(board, 5, 6, 1) == 0 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 6, 7, 14) == 0 );
assert( gamma_move(board, 7, 8, 8) == 1 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_move(board, 3, 10, 9) == 0 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_free_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 5, 10) == 1 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 7, 12, 1) == 0 );
assert( gamma_move(board, 7, 10, 12) == 0 );
assert( gamma_move(board, 1, 4, 4) == 0 );
assert( gamma_move(board, 3, 13, 5) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_move(board, 5, 4, 3) == 0 );
assert( gamma_move(board, 5, 9, 14) == 1 );
assert( gamma_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_free_fields(board, 7) == 25 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_move(board, 2, 2, 7) == 1 );
assert( gamma_move(board, 2, 4, 0) == 0 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 2) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 5, 4, 13) == 1 );
assert( gamma_move(board, 6, 11, 10) == 0 );
assert( gamma_move(board, 6, 10, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_move(board, 7, 6, 7) == 0 );
assert( gamma_move(board, 7, 3, 9) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 3, 11, 10) == 0 );
assert( gamma_move(board, 3, 8, 7) == 0 );
assert( gamma_golden_move(board, 3, 10, 7) == 0 );
assert( gamma_move(board, 4, 3, 10) == 0 );
assert( gamma_free_fields(board, 4) == 72 );
assert( gamma_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 5, 5, 14) == 1 );
assert( gamma_move(board, 6, 4, 9) == 0 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_move(board, 7, 7, 7) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_free_fields(board, 3) == 19 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );


char* board176226255 = gamma_board(board);
assert( board176226255 != NULL );
assert( strcmp(board176226255, 
"5...25...5.\n"
"64..5...3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.716411.53\n"
"4..23474.76\n"
".7..4...771\n"
"4427.211.2.\n"
"..2.56212.1\n"
"7..7.7..4.3\n"
".33.7316..6\n"
"23.12565...\n"
"3.135.1667.\n"
"156..22..76\n"
".53.716..37\n") == 0);
free(board176226255);
board176226255 = NULL;
assert( gamma_move(board, 5, 14, 7) == 0 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 13 );
assert( gamma_golden_move(board, 6, 5, 5) == 1 );


char* board898742207 = gamma_board(board);
assert( board898742207 != NULL );
assert( strcmp(board898742207, 
"5...25...5.\n"
"64..5...3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.716411.53\n"
"4..23474.76\n"
".7..4...771\n"
"4427.211.2.\n"
"..2.56212.1\n"
"7..7.6..4.3\n"
".33.7316..6\n"
"23.12565...\n"
"3.135.1667.\n"
"156..22..76\n"
".53.716..37\n") == 0);
free(board898742207);
board898742207 = NULL;
assert( gamma_move(board, 7, 13, 5) == 0 );
assert( gamma_move(board, 1, 2, 8) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );


char* board599717487 = gamma_board(board);
assert( board599717487 != NULL );
assert( strcmp(board599717487, 
"5...25...5.\n"
"64..5...3..\n"
"5..54......\n"
"..3.132..6.\n"
"4.716411.53\n"
"4..23474.76\n"
".7..4...771\n"
"4427.211.2.\n"
"..2.56212.1\n"
"7..7.6..4.3\n"
".33.7316..6\n"
"23.12565...\n"
"3.135.1667.\n"
"156..22..76\n"
".53.716..37\n") == 0);
free(board599717487);
board599717487 = NULL;
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_move(board, 2, 3, 3) == 0 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 3, 9, 13) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 12) == 1 );
assert( gamma_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_golden_move(board, 5, 2, 2) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 7, 10, 3) == 1 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_golden_move(board, 1, 0, 2) == 1 );
assert( gamma_move(board, 2, 14, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 2, 11) == 0 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 5, 1, 11) == 0 );
assert( gamma_move(board, 6, 7, 4) == 0 );
assert( gamma_move(board, 6, 8, 7) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_free_fields(board, 3) == 68 );


char* board256436591 = gamma_board(board);
assert( board256436591 != NULL );
assert( strcmp(board256436591, 
"5...25...5.\n"
"64..5...33.\n"
"54.54......\n"
"..3.132..6.\n"
"4.716411.53\n"
"4..23474.76\n"
".7..4...771\n"
"4427.211.2.\n"
"..2.56212.1\n"
"7..7.6..4.3\n"
".33.7316..6\n"
"23.12565..7\n"
"1.135.1667.\n"
"156..22..76\n"
".53.716..37\n") == 0);
free(board256436591);
board256436591 = NULL;
assert( gamma_move(board, 4, 13, 5) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 5, 7, 11) == 0 );
assert( gamma_move(board, 6, 6, 3) == 0 );
assert( gamma_move(board, 7, 9, 2) == 0 );
assert( gamma_move(board, 7, 1, 1) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 3, 1, 0) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 5, 0, 0) == 1 );
assert( gamma_move(board, 6, 12, 2) == 0 );
assert( gamma_move(board, 7, 12, 9) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_free_fields(board, 1) == 14 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 3, 8, 9) == 1 );
assert( gamma_move(board, 3, 7, 0) == 0 );
assert( gamma_free_fields(board, 3) == 21 );
assert( gamma_move(board, 4, 12, 6) == 0 );


char* board252914315 = gamma_board(board);
assert( board252914315 != NULL );
assert( strcmp(board252914315, 
"5...25...5.\n"
"64..5...33.\n"
"54.54......\n"
"..3.132..6.\n"
"4.716411.53\n"
"4..23474376\n"
".7..4...771\n"
"4427.211.2.\n"
"..2.56212.1\n"
"7..7.6..4.3\n"
".33.7316..6\n"
"23.12565..7\n"
"1.135.1667.\n"
"156..22..76\n"
"553.716..37\n") == 0);
free(board252914315);
board252914315 = NULL;
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_move(board, 7, 4, 8) == 0 );
assert( gamma_move(board, 2, 9, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 12 );
assert( gamma_move(board, 5, 9, 1) == 0 );
assert( gamma_move(board, 5, 6, 11) == 0 );
assert( gamma_golden_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 7, 10, 1) == 0 );
assert( gamma_golden_move(board, 7, 12, 1) == 0 );
assert( gamma_move(board, 2, 5, 7) == 0 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_move(board, 6, 5, 5) == 0 );
assert( gamma_move(board, 7, 2, 2) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_free_fields(board, 1) == 14 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 4, 6, 0) == 0 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 6, 0, 8) == 0 );
assert( gamma_move(board, 6, 6, 6) == 0 );
assert( gamma_move(board, 7, 3, 2) == 0 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_free_fields(board, 1) == 14 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 2, 9) == 1 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 4, 10, 9) == 0 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 12, 5) == 0 );
assert( gamma_move(board, 7, 10, 13) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 2, 4, 1) == 1 );
assert( gamma_move(board, 2, 1, 1) == 0 );


char* board718261807 = gamma_board(board);
assert( board718261807 != NULL );
assert( strcmp(board718261807, 
"5...25...5.\n"
"64..5...33.\n"
"54.54......\n"
"..3.132..6.\n"
"4.716411.53\n"
"4.223474376\n"
".7..4...771\n"
"4427.211.2.\n"
"..2.56212.1\n"
"7..7.6..423\n"
".33.7316..6\n"
"23.12565..7\n"
"1.135.1667.\n"
"156.222..76\n"
"553.716..37\n") == 0);
free(board718261807);
board718261807 = NULL;
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 2, 4, 13) == 0 );
assert( gamma_free_fields(board, 2) == 20 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 7) == 0 );
assert( gamma_move(board, 4, 5, 1) == 0 );
assert( gamma_move(board, 4, 1, 11) == 1 );
assert( gamma_move(board, 5, 6, 1) == 0 );


char* board650360690 = gamma_board(board);
assert( board650360690 != NULL );
assert( strcmp(board650360690, 
"5...25...5.\n"
"64..5...33.\n"
"54.54......\n"
".43.132..6.\n"
"4.716411.53\n"
"4.223474376\n"
".7..4...771\n"
"4427.211.2.\n"
"..2.56212.1\n"
"7..7.6..423\n"
".33.7316..6\n"
"23.12565..7\n"
"1.135.1667.\n"
"156.222..76\n"
"553.716..37\n") == 0);
free(board650360690);
board650360690 = NULL;
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 7, 11, 3) == 0 );
assert( gamma_move(board, 1, 1, 4) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 2, 12, 6) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 6, 13, 10) == 0 );
assert( gamma_move(board, 6, 8, 3) == 1 );
assert( gamma_move(board, 7, 12, 10) == 0 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 4, 5, 7) == 0 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_move(board, 6, 9, 11) == 0 );
assert( gamma_free_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 13, 6) == 0 );
assert( gamma_move(board, 7, 6, 3) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 10, 0) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 3, 9) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 5, 10) == 0 );
assert( gamma_move(board, 7, 10, 11) == 0 );
assert( gamma_golden_move(board, 7, 0, 1) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 16 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_free_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 14, 6) == 0 );
assert( gamma_move(board, 4, 0, 11) == 1 );
assert( gamma_move(board, 5, 3, 6) == 1 );
assert( gamma_move(board, 6, 7, 8) == 0 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_move(board, 7, 1, 13) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 3, 2, 6) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 5, 12, 7) == 0 );
assert( gamma_move(board, 5, 10, 10) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 14, 2) == 0 );


char* board470041931 = gamma_board(board);
assert( board470041931 != NULL );
assert( strcmp(board470041931, 
"5...25...5.\n"
"64..5...33.\n"
"54.54......\n"
"443.132..6.\n"
"4.716411.53\n"
"4.223474376\n"
".7..44..771\n"
"4427.211.2.\n"
".42556212.1\n"
"7.27.6..423\n"
".33.7316..6\n"
"23.125656.7\n"
"1.135.1667.\n"
"156.222..76\n"
"553.716..37\n") == 0);
free(board470041931);
board470041931 = NULL;
assert( gamma_move(board, 7, 5, 6) == 0 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 13, 3) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 15 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 5, 10) == 0 );
assert( gamma_move(board, 6, 14, 7) == 0 );
assert( gamma_move(board, 6, 5, 9) == 0 );


char* board957865731 = gamma_board(board);
assert( board957865731 != NULL );
assert( strcmp(board957865731, 
"5...25...5.\n"
"64..5...33.\n"
"54.54......\n"
"443.132..6.\n"
"4.716411.53\n"
"4.223474376\n"
".7..44..771\n"
"4427.21122.\n"
".42556212.1\n"
"7.27.6..423\n"
".33.7316..6\n"
"23.125656.7\n"
"1.135.1667.\n"
"156.222..76\n"
"553.716..37\n") == 0);
free(board957865731);
board957865731 = NULL;
assert( gamma_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 4, 1, 2) == 1 );
assert( gamma_move(board, 5, 1, 5) == 0 );


char* board553204628 = gamma_board(board);
assert( board553204628 != NULL );
assert( strcmp(board553204628, 
"5...25...5.\n"
"64..5...33.\n"
"54.54......\n"
"443.132..6.\n"
"4.716411.53\n"
"4.223474376\n"
".7..44..771\n"
"4427.21122.\n"
".42556212.1\n"
"7.27.6..423\n"
".33.7316..6\n"
"23.125656.7\n"
"14135.1667.\n"
"156.222..76\n"
"553.716..37\n") == 0);
free(board553204628);
board553204628 = NULL;
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 5, 1, 7) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_move(board, 6, 7, 6) == 0 );
assert( gamma_move(board, 7, 7, 10) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 9) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 4, 6, 14) == 1 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 6, 3) == 0 );
assert( gamma_move(board, 6, 2, 11) == 0 );
assert( gamma_move(board, 7, 4, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_free_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 10, 6) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 6, 6, 0) == 0 );
assert( gamma_move(board, 7, 2, 10) == 0 );
assert( gamma_move(board, 7, 1, 3) == 0 );
assert( gamma_free_fields(board, 7) == 17 );
assert( gamma_move(board, 1, 14, 3) == 0 );
assert( gamma_move(board, 3, 14, 2) == 0 );
assert( gamma_move(board, 4, 13, 10) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_move(board, 5, 11, 7) == 0 );


char* board135851264 = gamma_board(board);
assert( board135851264 != NULL );
assert( strcmp(board135851264, 
"5...254..5.\n"
"64.25...33.\n"
"54.54...4..\n"
"443.132..6.\n"
"4.716411.53\n"
"4.223474376\n"
".7..44..771\n"
"4427.21122.\n"
".42556212.1\n"
"7.27.6..423\n"
".33.7316..6\n"
"23.125656.7\n"
"14135.1667.\n"
"156.222..76\n"
"553.716..37\n") == 0);
free(board135851264);
board135851264 = NULL;
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_free_fields(board, 6) == 14 );
assert( gamma_move(board, 7, 9, 9) == 0 );
assert( gamma_free_fields(board, 1) == 12 );
assert( gamma_golden_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 3) == 0 );
assert( gamma_move(board, 4, 2, 9) == 0 );
assert( gamma_move(board, 5, 11, 8) == 0 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 6, 4, 3) == 0 );
assert( gamma_move(board, 6, 0, 7) == 0 );
assert( gamma_move(board, 7, 9, 1) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_busy_fields(board, 7) == 15 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 13, 7) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 4, 0, 11) == 0 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 7, 14) == 0 );
assert( gamma_move(board, 6, 14, 2) == 0 );
assert( gamma_move(board, 6, 0, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 15 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 7, 2, 10) == 0 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 1, 0, 7) == 0 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_free_fields(board, 4) == 50 );
assert( gamma_move(board, 5, 4, 10) == 0 );
assert( gamma_move(board, 5, 8, 7) == 0 );
assert( gamma_move(board, 6, 0, 3) == 0 );
assert( gamma_move(board, 7, 12, 10) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );


gamma_delete(board);

    return 0;
}
