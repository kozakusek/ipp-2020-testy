#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 115888228
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 18, 4, 20);
assert( board != NULL );


assert( gamma_move(board, 1, 7, 7) == 1 );
assert( gamma_move(board, 2, 17, 8) == 0 );
assert( gamma_move(board, 3, 13, 3) == 0 );
assert( gamma_golden_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 4, 1, 12) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 4, 5) == 1 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 3, 2, 3) == 1 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 4, 7, 7) == 0 );


char* board293786478 = gamma_board(board);
assert( board293786478 != NULL );
assert( strcmp(board293786478, 
"............\n"
"............\n"
"............\n"
"............\n"
"............\n"
".4..........\n"
"............\n"
"............\n"
"..4...2.....\n"
"............\n"
"...3...3....\n"
"............\n"
"....1.......\n"
"............\n"
"..3.........\n"
"............\n"
"............\n"
"...........1\n") == 0);
free(board293786478);
board293786478 = NULL;
assert( gamma_move(board, 1, 8, 16) == 1 );
assert( gamma_move(board, 1, 4, 8) == 1 );
assert( gamma_move(board, 2, 2, 11) == 1 );
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_free_fields(board, 3) == 204 );
assert( gamma_move(board, 4, 14, 10) == 0 );
assert( gamma_move(board, 1, 0, 0) == 1 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_move(board, 4, 11, 9) == 1 );
assert( gamma_move(board, 1, 16, 6) == 0 );
assert( gamma_move(board, 1, 6, 8) == 1 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 2 );
assert( gamma_free_fields(board, 2) == 199 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 3, 10, 16) == 1 );
assert( gamma_move(board, 4, 11, 3) == 1 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 1, 11, 4) == 1 );
assert( gamma_move(board, 2, 6, 1) == 1 );
assert( gamma_move(board, 3, 7, 17) == 1 );
assert( gamma_move(board, 3, 1, 16) == 1 );


char* board347041750 = gamma_board(board);
assert( board347041750 != NULL );
assert( strcmp(board347041750, 
".......3....\n"
".3......1.3.\n"
"............\n"
"............\n"
"............\n"
".4..........\n"
"..2.........\n"
"4.1...3.....\n"
"..43..2....4\n"
"....1.1....3\n"
"...3...3....\n"
"............\n"
"....1.......\n"
"...........1\n"
"..3........4\n"
"............\n"
"......2.....\n"
"1..........1\n") == 0);
free(board347041750);
board347041750 = NULL;
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 6 );
assert( gamma_move(board, 1, 6, 13) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_move(board, 4, 11, 5) == 1 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 6, 8) == 0 );
assert( gamma_move(board, 3, 14, 10) == 0 );
assert( gamma_move(board, 4, 0, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 9 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 16) == 1 );
assert( gamma_move(board, 3, 16, 4) == 0 );
assert( gamma_move(board, 3, 1, 12) == 0 );
assert( gamma_free_fields(board, 4) == 182 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 1, 10, 0) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 1, 7, 5) == 1 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_move(board, 2, 2, 15) == 1 );
assert( gamma_busy_fields(board, 2) == 7 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 1, 4, 16) == 1 );
assert( gamma_move(board, 2, 10, 8) == 1 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_move(board, 3, 5, 16) == 1 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_move(board, 4, 3, 6) == 1 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_free_fields(board, 1) == 168 );
assert( gamma_golden_move(board, 1, 0, 0) == 0 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 3, 6, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 14 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 1, 17, 2) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_golden_move(board, 3, 8, 6) == 0 );


char* board384118392 = gamma_board(board);
assert( board384118392 != NULL );
assert( strcmp(board384118392, 
".......3....\n"
".3..13.21.3.\n"
"..2.........\n"
".2....3...1.\n"
"......1.....\n"
".4..........\n"
"..2.........\n"
"4.1...3.....\n"
"..43..2....4\n"
"....1.1...23\n"
"3..31..3....\n"
"2..41.......\n"
"4...1..1...4\n"
"4.....2...21\n"
"4.34.......4\n"
"...........3\n"
"..2...2.....\n"
"1.3.......11\n") == 0);
free(board384118392);
board384118392 = NULL;
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 1, 11, 7) == 1 );
assert( gamma_move(board, 1, 9, 1) == 1 );
assert( gamma_move(board, 2, 7, 6) == 1 );
assert( gamma_free_fields(board, 3) == 162 );
assert( gamma_move(board, 4, 5, 1) == 1 );
assert( gamma_move(board, 2, 5, 3) == 1 );
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_golden_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 1, 13, 5) == 0 );
assert( gamma_move(board, 1, 9, 2) == 1 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_move(board, 4, 12, 2) == 0 );
assert( gamma_move(board, 4, 8, 9) == 1 );
assert( gamma_busy_fields(board, 4) == 13 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_move(board, 3, 4, 9) == 1 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 18 );
assert( gamma_free_fields(board, 1) == 155 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 3, 13, 4) == 0 );
assert( gamma_move(board, 3, 2, 14) == 1 );
assert( gamma_free_fields(board, 3) == 153 );
assert( gamma_move(board, 4, 14, 9) == 0 );
assert( gamma_golden_move(board, 4, 10, 10) == 1 );
assert( gamma_move(board, 1, 1, 6) == 1 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 2, 6, 9) == 0 );
assert( gamma_move(board, 3, 9, 8) == 1 );


char* board395051063 = gamma_board(board);
assert( board395051063 != NULL );
assert( strcmp(board395051063, 
".......3....\n"
".3..13.21.3.\n"
"..2.........\n"
".23...3...1.\n"
"......1.....\n"
".4..........\n"
"..2.........\n"
"4.1...3...4.\n"
"..433.2.4..4\n"
"....1.1..323\n"
"3..31..3...1\n"
"21.41..2....\n"
"4.2.1..1...4\n"
"4.....2...21\n"
"4.34.2.....4\n"
".........123\n"
"..2..42..1..\n"
"1.3.......11\n") == 0);
free(board395051063);
board395051063 = NULL;
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 1, 14, 8) == 0 );
assert( gamma_move(board, 2, 8, 15) == 1 );
assert( gamma_move(board, 3, 17, 8) == 0 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_free_fields(board, 3) == 149 );
assert( gamma_move(board, 4, 11, 11) == 1 );
assert( gamma_move(board, 4, 7, 2) == 1 );
assert( gamma_move(board, 1, 8, 1) == 1 );
assert( gamma_move(board, 1, 0, 17) == 1 );
assert( gamma_busy_fields(board, 1) == 21 );
assert( gamma_golden_move(board, 1, 11, 11) == 1 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 4, 9, 10) == 1 );


char* board337200796 = gamma_board(board);
assert( board337200796 != NULL );
assert( strcmp(board337200796, 
"1......3....\n"
".3..13.21.3.\n"
"..2.....2...\n"
".23...3...1.\n"
"......1.....\n"
".4..........\n"
"..2........1\n"
"4.13..3..44.\n"
"..433.2.4..4\n"
"....1.1..323\n"
"3..31..3...1\n"
"21.41..2....\n"
"4.2.1..1...4\n"
"4.....2...21\n"
"4.34.2.....4\n"
"2......4.123\n"
"..2..42.11..\n"
"1.3.......11\n") == 0);
free(board337200796);
board337200796 = NULL;
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 4, 9, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 18 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_free_fields(board, 2) == 139 );
assert( gamma_move(board, 3, 10, 17) == 1 );
assert( gamma_move(board, 4, 10, 14) == 0 );
assert( gamma_move(board, 4, 6, 5) == 1 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 3, 7, 12) == 1 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 1, 8, 15) == 0 );
assert( gamma_move(board, 1, 8, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 23 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 5, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 3, 11, 9) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 1, 0, 15) == 1 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_move(board, 2, 11, 3) == 0 );


char* board752895519 = gamma_board(board);
assert( board752895519 != NULL );
assert( strcmp(board752895519, 
"1......3..3.\n"
".3..13.21.3.\n"
"1.2.....2...\n"
".23...3...1.\n"
".....21.....\n"
".4.....3....\n"
"..2......4.1\n"
"4.13..3..44.\n"
"..433.2.4..4\n"
"...31.1..323\n"
"3..31..32..1\n"
"21.41..2....\n"
"4.2.1.41...4\n"
"4.....2...21\n"
"4.34.2..1..4\n"
"2......4.123\n"
"..2.442.11..\n"
"1.3....2..11\n") == 0);
free(board752895519);
board752895519 = NULL;
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 4, 9, 1) == 0 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_free_fields(board, 1) == 131 );


char* board219360304 = gamma_board(board);
assert( board219360304 != NULL );
assert( strcmp(board219360304, 
"1......3..3.\n"
".3..13.21.3.\n"
"1.2.....2...\n"
".23...3...1.\n"
".....21.....\n"
".4.....3....\n"
"..2......4.1\n"
"4.13..3..44.\n"
"..433.2.4..4\n"
"...31.1..323\n"
"3..31..32..1\n"
"21.41..2....\n"
"4.2.1.41..14\n"
"4.....2...21\n"
"4.34.2..1..4\n"
"2......4.123\n"
"..2.442.11..\n"
"1.3....2..11\n") == 0);
free(board219360304);
board219360304 = NULL;
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 4, 4, 2) == 1 );
assert( gamma_free_fields(board, 4) == 129 );
assert( gamma_move(board, 1, 5, 8) == 1 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 8, 0) == 1 );
assert( gamma_move(board, 4, 3, 14) == 1 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 2, 16, 2) == 0 );
assert( gamma_golden_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 6, 16) == 1 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 4, 15, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 4, 2) == 0 );
assert( gamma_move(board, 2, 4, 12) == 0 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 1, 11, 1) == 1 );
assert( gamma_move(board, 2, 10, 7) == 1 );
assert( gamma_move(board, 2, 3, 15) == 1 );
assert( gamma_move(board, 3, 4, 14) == 1 );
assert( gamma_move(board, 4, 17, 6) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 4, 3) == 0 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_move(board, 4, 4, 16) == 0 );
assert( gamma_free_fields(board, 4) == 117 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 4, 3, 4) == 1 );
assert( gamma_busy_fields(board, 4) == 22 );
assert( gamma_move(board, 1, 11, 4) == 0 );


char* board116020852 = gamma_board(board);
assert( board116020852 != NULL );
assert( strcmp(board116020852, 
"1......3..3.\n"
".3..13321.3.\n"
"1.22....2...\n"
".2343.3...1.\n"
".....21.....\n"
".4.....3....\n"
"..2......4.1\n"
"4.13..3..44.\n"
"..43332.4..4\n"
"...3111..323\n"
"3..31..32.21\n"
"21.41..2....\n"
"4.2.1.41..14\n"
"4..4..2...21\n"
"4.34221.1..4\n"
"2...43.43123\n"
"..2.442.11.1\n"
"1.3....23.11\n") == 0);
free(board116020852);
board116020852 = NULL;
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 3) == 1 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 10, 11) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 4, 10) == 0 );
assert( gamma_busy_fields(board, 2) == 23 );


char* board286458343 = gamma_board(board);
assert( board286458343 != NULL );
assert( strcmp(board286458343, 
"1......3..3.\n"
".3..13321.3.\n"
"1.22....2...\n"
".2343.3...1.\n"
".....21.....\n"
".4.....3....\n"
"..2......4.1\n"
"4.13..3..44.\n"
".143332.4..4\n"
"...3111..323\n"
"3..31..32.21\n"
"21.41..2....\n"
"4.2.1.41..14\n"
"4..4..2...21\n"
"4434221.1..4\n"
"2...43.43123\n"
"..2.442.11.1\n"
"1.3....23.11\n") == 0);
free(board286458343);
board286458343 = NULL;
assert( gamma_move(board, 3, 8, 13) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_move(board, 1, 0, 9) == 1 );
assert( gamma_move(board, 1, 10, 17) == 0 );
assert( gamma_move(board, 2, 10, 1) == 1 );
assert( gamma_move(board, 2, 5, 14) == 1 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_free_fields(board, 3) == 42 );
assert( gamma_move(board, 4, 17, 8) == 0 );
assert( gamma_move(board, 4, 6, 11) == 1 );
assert( gamma_busy_fields(board, 4) == 24 );
assert( gamma_golden_move(board, 4, 5, 10) == 0 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 2, 11, 6) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 3, 11, 0) == 0 );
assert( gamma_move(board, 4, 9, 13) == 1 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 3, 9, 14) == 0 );
assert( gamma_free_fields(board, 3) == 41 );
assert( gamma_move(board, 4, 9, 9) == 1 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 1, 17, 4) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 3, 5, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 13, 0) == 0 );
assert( gamma_move(board, 1, 1, 0) == 1 );
assert( gamma_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 3, 6, 2) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 1, 17, 8) == 0 );
assert( gamma_move(board, 1, 4, 6) == 0 );
assert( gamma_free_fields(board, 1) == 43 );
assert( gamma_golden_move(board, 1, 4, 6) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 2) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 16, 3) == 0 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 4, 8, 5) == 1 );
assert( gamma_free_fields(board, 4) == 104 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_busy_fields(board, 1) == 31 );
assert( gamma_move(board, 2, 13, 0) == 0 );
assert( gamma_move(board, 2, 5, 8) == 0 );
assert( gamma_free_fields(board, 2) == 38 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 0, 4) == 0 );
assert( gamma_move(board, 1, 7, 2) == 0 );
assert( gamma_move(board, 1, 9, 12) == 0 );
assert( gamma_move(board, 2, 11, 4) == 0 );
assert( gamma_move(board, 2, 3, 11) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 1, 15, 4) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 13, 2) == 0 );
assert( gamma_move(board, 2, 2, 2) == 1 );
assert( gamma_move(board, 2, 10, 1) == 0 );
assert( gamma_free_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 2, 15, 10) == 0 );
assert( gamma_move(board, 2, 3, 12) == 1 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 1, 4, 17) == 1 );
assert( gamma_move(board, 1, 3, 1) == 0 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 3, 1, 14) == 0 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_free_fields(board, 1) == 41 );
assert( gamma_move(board, 2, 7, 8) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 1, 4, 12) == 0 );
assert( gamma_move(board, 1, 7, 13) == 1 );
assert( gamma_move(board, 2, 14, 0) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_free_fields(board, 3) == 35 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_move(board, 1, 13, 8) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 15, 7) == 0 );
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_busy_fields(board, 3) == 28 );
assert( gamma_free_fields(board, 3) == 35 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_golden_move(board, 4, 4, 11) == 0 );
assert( gamma_move(board, 1, 10, 15) == 1 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 3, 16, 0) == 0 );
assert( gamma_busy_fields(board, 4) == 27 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 2, 13) == 0 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 2, 8, 10) == 0 );
assert( gamma_move(board, 2, 11, 11) == 0 );
assert( gamma_move(board, 3, 5, 1) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_free_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_free_fields(board, 4) == 97 );
assert( gamma_move(board, 1, 3, 2) == 0 );
assert( gamma_move(board, 1, 5, 10) == 0 );
assert( gamma_move(board, 3, 7, 6) == 0 );
assert( gamma_move(board, 3, 6, 16) == 0 );
assert( gamma_move(board, 4, 10, 13) == 1 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );


char* board563524894 = gamma_board(board);
assert( board563524894 != NULL );
assert( strcmp(board563524894, 
"1...1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323...1.\n"
".....211.44.\n"
".4.2...3....\n"
"..22..4..4.1\n"
"4.13..3..44.\n"
"1143332.44.4\n"
"...3111..323\n"
"3..31..32.21\n"
"21241..2...1\n"
"4.2.1.414.14\n"
"4..4..2...21\n"
"4434221.1..4\n"
"2.2.43343123\n"
"..2.442.1121\n"
"113....23.11\n") == 0);
free(board563524894);
board563524894 = NULL;
assert( gamma_move(board, 1, 9, 0) == 1 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_move(board, 3, 1, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_free_fields(board, 4) == 93 );
assert( gamma_move(board, 1, 3, 13) == 1 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );


char* board155492956 = gamma_board(board);
assert( board155492956 != NULL );
assert( strcmp(board155492956, 
"1...1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323...1.\n"
"...1.211.44.\n"
".4.2...3....\n"
"..22..4..4.1\n"
"4.13..3..44.\n"
"1143332.44.4\n"
"...3111..323\n"
"33.31..32.21\n"
"21241..2...1\n"
"4.211.414.14\n"
"4..4..2...21\n"
"4434221.1..4\n"
"2.2.43343123\n"
"..2.442.1121\n"
"113....23111\n") == 0);
free(board155492956);
board155492956 = NULL;
assert( gamma_move(board, 4, 1, 1) == 1 );
assert( gamma_move(board, 4, 4, 11) == 1 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 4, 12) == 1 );
assert( gamma_move(board, 2, 6, 2) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_move(board, 4, 8, 2) == 0 );
assert( gamma_move(board, 4, 2, 17) == 1 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_move(board, 2, 10, 11) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 6, 8) == 0 );
assert( gamma_move(board, 4, 1, 7) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 8, 8) == 0 );
assert( gamma_free_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 4, 4) == 1 );


char* board656079676 = gamma_board(board);
assert( board656079676 != NULL );
assert( strcmp(board656079676, 
"1.4.1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323...1.\n"
"...1.211.44.\n"
".4.22..3....\n"
"..224.4..4.1\n"
"4.13..3..44.\n"
"1143332.44.4\n"
"...3111..323\n"
"33331..32.21\n"
"21241..2...1\n"
"4.211.414.14\n"
"4..43.2...21\n"
"4434221.1..4\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board656079676);
board656079676 = NULL;
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 1, 0, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 9, 7) == 1 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_free_fields(board, 3) == 33 );
assert( gamma_move(board, 4, 6, 12) == 1 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 4, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 0, 17) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 5, 4) == 1 );
assert( gamma_move(board, 4, 7, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 32 );
assert( gamma_free_fields(board, 4) == 43 );
assert( gamma_move(board, 1, 16, 3) == 0 );
assert( gamma_golden_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 2, 8, 6) == 1 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_busy_fields(board, 2) == 31 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_golden_move(board, 3, 12, 3) == 0 );
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 4, 2, 12) == 1 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 33 );
assert( gamma_move(board, 2, 4, 16) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_move(board, 4, 5, 13) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 3, 10) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 17, 3) == 0 );
assert( gamma_move(board, 3, 1, 2) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 0, 17) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );


char* board356857937 = gamma_board(board);
assert( board356857937 != NULL );
assert( strcmp(board356857937, 
"1.4.1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323...1.\n"
"...1.211.44.\n"
".4422.43....\n"
"..224.43.4.1\n"
"4.13..3..44.\n"
"1143332.44.4\n"
"...3111..323\n"
"33331..32321\n"
"21241..22..1\n"
"4.211.414.14\n"
"4..4332...21\n"
"4434221.1..4\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board356857937);
board356857937 = NULL;
assert( gamma_move(board, 3, 16, 11) == 0 );
assert( gamma_move(board, 3, 10, 1) == 0 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 4, 2, 13) == 1 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_free_fields(board, 2) == 79 );
assert( gamma_move(board, 3, 10, 14) == 0 );
assert( gamma_busy_fields(board, 3) == 34 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 8, 8) == 1 );
assert( gamma_move(board, 4, 5, 3) == 0 );


char* board383517539 = gamma_board(board);
assert( board383517539 != NULL );
assert( strcmp(board383517539, 
"1.4.1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323...1.\n"
"..41.211.44.\n"
".4422.43....\n"
"..224.43.4.1\n"
"4.13..3..44.\n"
"1143332.44.4\n"
"...3111.4323\n"
"33331..32321\n"
"21241..22..1\n"
"4.211.414.14\n"
"4..4332...21\n"
"4434221.1..4\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board383517539);
board383517539 = NULL;
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 2, 5, 5) == 1 );
assert( gamma_move(board, 2, 8, 14) == 1 );
assert( gamma_move(board, 3, 6, 0) == 0 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_move(board, 4, 10, 17) == 0 );
assert( gamma_move(board, 1, 16, 3) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 6, 9) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_golden_move(board, 3, 1, 5) == 0 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 1, 16, 3) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 1, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );


char* board959688231 = gamma_board(board);
assert( board959688231 != NULL );
assert( strcmp(board959688231, 
"1.4.1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323.2.1.\n"
"..41.211.44.\n"
".4422.43....\n"
"..224.43.4.1\n"
"4.13..3..44.\n"
"1143332.44.4\n"
"...3111.4323\n"
"33331..32321\n"
"21241..22..1\n"
"4.2112414.14\n"
"4..4332...21\n"
"4434221.1..4\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board959688231);
board959688231 = NULL;
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 4, 8, 1) == 0 );
assert( gamma_free_fields(board, 4) == 39 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 17, 11) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 17, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 35 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 1, 6, 5) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_free_fields(board, 2) == 32 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 1, 7, 0) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 33 );
assert( gamma_move(board, 3, 0, 6) == 0 );
assert( gamma_free_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 1, 3, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 9, 7) == 0 );
assert( gamma_golden_move(board, 2, 2, 11) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 2, 14, 11) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 10) == 1 );
assert( gamma_move(board, 1, 4, 16) == 0 );


char* board916050013 = gamma_board(board);
assert( board916050013 != NULL );
assert( strcmp(board916050013, 
"1.4.1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323.2.1.\n"
"..41.211.44.\n"
".4422.43....\n"
"..224.43.4.1\n"
"4.13..3..444\n"
"1143332.44.4\n"
"...3111.4323\n"
"33331..32321\n"
"21241..22..1\n"
"4.2112414.14\n"
"4..4332...21\n"
"4434221.1..4\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board916050013);
board916050013 = NULL;
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_free_fields(board, 2) == 32 );


char* board478797501 = gamma_board(board);
assert( board478797501 != NULL );
assert( strcmp(board478797501, 
"1.4.1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323.2.1.\n"
"..41.211.44.\n"
".4422.43....\n"
"..224.43.4.1\n"
"4.13..3..444\n"
"1143332.44.4\n"
"...3111.4323\n"
"33331..32321\n"
"21241..22..1\n"
"4.2112414.14\n"
"4..4332...21\n"
"4434221.1..4\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board478797501);
board478797501 = NULL;
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 3, 6, 2) == 0 );
assert( gamma_move(board, 4, 7, 9) == 1 );
assert( gamma_move(board, 4, 7, 11) == 0 );
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 2, 10, 3) == 1 );
assert( gamma_free_fields(board, 2) == 73 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_free_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_golden_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 1, 10, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );


char* board973238745 = gamma_board(board);
assert( board973238745 != NULL );
assert( strcmp(board973238745, 
"1.4.1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323.2.1.\n"
"..41.211.44.\n"
".4422.43....\n"
"..224.43.4.1\n"
"4.13..3..444\n"
"1143332444.4\n"
"...3111.4323\n"
"33331..32321\n"
"21241..22..1\n"
"4.2112414.14\n"
"4..4332...21\n"
"4434221.1.24\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board973238745);
board973238745 = NULL;
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_move(board, 4, 1, 10) == 1 );
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 1, 16, 11) == 0 );


char* board463852916 = gamma_board(board);
assert( board463852916 != NULL );
assert( strcmp(board463852916, 
"1.4.1..3..3.\n"
".3..13321.3.\n"
"1.22....2.1.\n"
".234323.2.1.\n"
"..41.211.44.\n"
".4422.43....\n"
"..224.43.4.1\n"
"4413..3..444\n"
"1143332444.4\n"
"...3111.4323\n"
"33331..32321\n"
"21241..22..1\n"
"4.2112414.14\n"
"4..4332...21\n"
"4434221.1.24\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board463852916);
board463852916 = NULL;
assert( gamma_move(board, 3, 15, 4) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 3, 6, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 6) == 1 );
assert( gamma_free_fields(board, 4) == 36 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 14, 11) == 0 );
assert( gamma_move(board, 1, 6, 13) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 4, 1, 0) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 1, 3, 16) == 1 );
assert( gamma_move(board, 2, 17, 1) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 10, 5) == 0 );
assert( gamma_move(board, 3, 3, 9) == 0 );
assert( gamma_free_fields(board, 3) == 29 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 11, 13) == 1 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_move(board, 1, 1, 5) == 0 );
assert( gamma_move(board, 2, 3, 9) == 0 );
assert( gamma_move(board, 2, 10, 14) == 0 );
assert( gamma_move(board, 3, 0, 3) == 0 );
assert( gamma_move(board, 3, 5, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 40 );
assert( gamma_move(board, 2, 9, 10) == 0 );
assert( gamma_move(board, 2, 9, 12) == 0 );
assert( gamma_free_fields(board, 2) == 28 );
assert( gamma_move(board, 3, 10, 7) == 0 );
assert( gamma_free_fields(board, 3) == 29 );


char* board431013040 = gamma_board(board);
assert( board431013040 != NULL );
assert( strcmp(board431013040, 
"1.4.1..3..3.\n"
".3.113321.3.\n"
"1.22....2.1.\n"
".234323.2.1.\n"
"..41.211.444\n"
".4422.43....\n"
"..224.43.4.1\n"
"4413..3..444\n"
"1143332444.4\n"
"...3111.4323\n"
"33331..32321\n"
"21241..22.41\n"
"4.2112414.14\n"
"4.34332...21\n"
"443422121.24\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board431013040);
board431013040 = NULL;
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 17, 9) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 35 );
assert( gamma_golden_move(board, 3, 14, 5) == 0 );
assert( gamma_move(board, 4, 8, 12) == 0 );
assert( gamma_move(board, 1, 17, 1) == 0 );
assert( gamma_move(board, 2, 8, 13) == 1 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 3, 1, 4) == 1 );
assert( gamma_free_fields(board, 3) == 29 );


char* board483359786 = gamma_board(board);
assert( board483359786 != NULL );
assert( strcmp(board483359786, 
"1.4.1..3..3.\n"
".3.113321.3.\n"
"1.22....2.1.\n"
".234323.2.1.\n"
"..41.2112444\n"
".4422.43....\n"
"..224.43.4.1\n"
"4413..3..444\n"
"1143332444.4\n"
"...3111.4323\n"
"33331..32321\n"
"21241..22.41\n"
"4.2112414.14\n"
"4334332...21\n"
"443422121.24\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board483359786);
board483359786 = NULL;
assert( gamma_move(board, 4, 15, 11) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 1, 11, 11) == 0 );
assert( gamma_move(board, 2, 5, 5) == 0 );
assert( gamma_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 4, 16, 2) == 0 );
assert( gamma_move(board, 4, 11, 12) == 1 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_free_fields(board, 1) == 30 );
assert( gamma_move(board, 2, 15, 5) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 15, 6) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_free_fields(board, 4) == 33 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 36 );
assert( gamma_move(board, 4, 12, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_move(board, 1, 11, 7) == 0 );
assert( gamma_move(board, 2, 12, 8) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 10, 4) == 0 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 1, 1, 0) == 0 );
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 2, 9, 6) == 1 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 9, 17) == 1 );
assert( gamma_move(board, 4, 17, 1) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 1, 13, 0) == 0 );
assert( gamma_move(board, 2, 17, 8) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_move(board, 3, 11, 16) == 1 );
assert( gamma_golden_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 4, 5, 5) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 8, 5) == 0 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_golden_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 7, 8) == 1 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 4, 3, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 41 );
assert( gamma_move(board, 1, 5, 9) == 0 );


char* board656748087 = gamma_board(board);
assert( board656748087 != NULL );
assert( strcmp(board656748087, 
"1.4.1..3.33.\n"
".3.113321.33\n"
"1.22....2.1.\n"
".234323.2.1.\n"
"..41.2112444\n"
".4422.43...4\n"
"..224.43.4.1\n"
"4413..33.444\n"
"1143332444.4\n"
"...311134323\n"
"33331..32321\n"
"21241..22241\n"
"4.2112414.14\n"
"4334332...21\n"
"443422121.24\n"
"2.2.43343123\n"
".42.442.1121\n"
"113....23111\n") == 0);
free(board656748087);
board656748087 = NULL;
assert( gamma_move(board, 2, 6, 5) == 0 );
assert( gamma_move(board, 2, 5, 17) == 0 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 1, 15, 7) == 0 );
assert( gamma_move(board, 1, 7, 8) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 3, 6, 11) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_free_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 16, 2) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 2, 12, 0) == 0 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_move(board, 4, 6, 12) == 0 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );


gamma_delete(board);

    return 0;
}
