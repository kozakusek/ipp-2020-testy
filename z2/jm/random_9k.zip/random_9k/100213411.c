#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 100213411
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 16, 7, 41);
assert( board != NULL );


assert( gamma_move(board, 1, 2, 11) == 1 );
assert( gamma_move(board, 2, 1, 14) == 1 );
assert( gamma_move(board, 3, 14, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 4) == 1 );
assert( gamma_move(board, 4, 3, 11) == 1 );
assert( gamma_move(board, 5, 14, 10) == 1 );
assert( gamma_move(board, 6, 9, 5) == 1 );
assert( gamma_move(board, 6, 14, 15) == 1 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_free_fields(board, 6) == 264 );
assert( gamma_move(board, 7, 5, 4) == 1 );
assert( gamma_move(board, 7, 10, 10) == 1 );
assert( gamma_move(board, 1, 15, 1) == 1 );
assert( gamma_move(board, 2, 7, 6) == 1 );
assert( gamma_move(board, 2, 12, 6) == 1 );
assert( gamma_move(board, 3, 5, 1) == 1 );
assert( gamma_move(board, 4, 7, 5) == 1 );
assert( gamma_move(board, 5, 15, 16) == 0 );
assert( gamma_move(board, 5, 13, 1) == 1 );
assert( gamma_busy_fields(board, 5) == 2 );
assert( gamma_move(board, 6, 9, 0) == 1 );
assert( gamma_move(board, 7, 16, 6) == 1 );
assert( gamma_move(board, 7, 11, 3) == 1 );
assert( gamma_move(board, 1, 12, 10) == 1 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_golden_move(board, 2, 6, 16) == 0 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_free_fields(board, 3) == 250 );
assert( gamma_move(board, 4, 13, 12) == 1 );
assert( gamma_move(board, 5, 13, 16) == 0 );
assert( gamma_move(board, 5, 9, 13) == 1 );
assert( gamma_move(board, 6, 13, 12) == 0 );
assert( gamma_move(board, 7, 16, 15) == 1 );
assert( gamma_move(board, 1, 2, 10) == 1 );
assert( gamma_move(board, 1, 4, 8) == 1 );
assert( gamma_free_fields(board, 1) == 245 );
assert( gamma_move(board, 2, 6, 3) == 1 );
assert( gamma_move(board, 2, 6, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 4, 9, 4) == 1 );
assert( gamma_move(board, 4, 9, 6) == 1 );
assert( gamma_move(board, 5, 9, 12) == 1 );
assert( gamma_move(board, 6, 8, 15) == 1 );
assert( gamma_move(board, 6, 14, 11) == 1 );
assert( gamma_move(board, 7, 4, 13) == 1 );
assert( gamma_move(board, 7, 2, 1) == 0 );
assert( gamma_move(board, 1, 4, 12) == 1 );
assert( gamma_move(board, 1, 12, 12) == 1 );
assert( gamma_move(board, 3, 12, 11) == 1 );
assert( gamma_move(board, 3, 12, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 16, 4) == 1 );
assert( gamma_move(board, 4, 12, 5) == 1 );
assert( gamma_move(board, 5, 8, 5) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 7, 4) == 1 );
assert( gamma_move(board, 6, 6, 11) == 1 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 7, 8, 15) == 0 );
assert( gamma_move(board, 7, 4, 15) == 1 );
assert( gamma_move(board, 1, 0, 16) == 0 );
assert( gamma_move(board, 2, 8, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 7 );


char* board511374859 = gamma_board(board);
assert( board511374859 != NULL );
assert( strcmp(board511374859, 
"....7...6.....6.7\n"
".2..........3....\n"
"....7....5.......\n"
"....1....5..14...\n"
"..14..6.....3.6..\n"
"..1.....2.7.1.5..\n"
".................\n"
"....1............\n"
"......23.........\n"
".......2.4..2...7\n"
".......456..4....\n"
".....746.4......4\n"
"......2....7.....\n"
".................\n"
"..2..3.......5.1.\n"
".........6....3..\n") == 0);
free(board511374859);
board511374859 = NULL;
assert( gamma_move(board, 3, 10, 13) == 1 );
assert( gamma_free_fields(board, 3) == 225 );
assert( gamma_move(board, 5, 3, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 6 );
assert( gamma_golden_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 6, 7, 13) == 1 );
assert( gamma_move(board, 6, 1, 15) == 1 );
assert( gamma_move(board, 7, 8, 15) == 0 );
assert( gamma_move(board, 7, 4, 0) == 1 );
assert( gamma_move(board, 1, 9, 2) == 1 );


char* board993617076 = gamma_board(board);
assert( board993617076 != NULL );
assert( strcmp(board993617076, 
".6..7...6.....6.7\n"
".2..........3....\n"
"....7..6.53......\n"
"....1....5..14...\n"
"..14..6.....3.6..\n"
"..1.....2.7.1.5..\n"
".................\n"
"...51............\n"
"......23.........\n"
".......2.4..2...7\n"
".......456..4....\n"
".....746.4......4\n"
"......2....7.....\n"
".........1.......\n"
"..2..3.......5.1.\n"
"....7....6....3..\n") == 0);
free(board993617076);
board993617076 = NULL;
assert( gamma_move(board, 4, 10, 5) == 1 );
assert( gamma_free_fields(board, 4) == 219 );
assert( gamma_move(board, 5, 13, 1) == 0 );
assert( gamma_free_fields(board, 5) == 219 );
assert( gamma_move(board, 6, 15, 3) == 1 );
assert( gamma_move(board, 6, 15, 0) == 1 );
assert( gamma_move(board, 7, 13, 10) == 1 );
assert( gamma_free_fields(board, 7) == 216 );
assert( gamma_move(board, 1, 14, 2) == 1 );
assert( gamma_free_fields(board, 1) == 215 );


char* board600300333 = gamma_board(board);
assert( board600300333 != NULL );
assert( strcmp(board600300333, 
".6..7...6.....6.7\n"
".2..........3....\n"
"....7..6.53......\n"
"....1....5..14...\n"
"..14..6.....3.6..\n"
"..1.....2.7.175..\n"
".................\n"
"...51............\n"
"......23.........\n"
".......2.4..2...7\n"
".......4564.4....\n"
".....746.4......4\n"
"......2....7...6.\n"
".........1....1..\n"
"..2..3.......5.1.\n"
"....7....6....36.\n") == 0);
free(board600300333);
board600300333 = NULL;
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_move(board, 3, 1, 9) == 1 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 4, 0, 12) == 1 );
assert( gamma_move(board, 5, 15, 12) == 1 );
assert( gamma_move(board, 6, 13, 11) == 1 );
assert( gamma_move(board, 7, 3, 16) == 0 );
assert( gamma_move(board, 7, 5, 0) == 1 );
assert( gamma_move(board, 1, 12, 8) == 1 );
assert( gamma_move(board, 1, 14, 9) == 1 );
assert( gamma_move(board, 2, 5, 6) == 1 );
assert( gamma_move(board, 2, 6, 10) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 4, 7, 1) == 1 );
assert( gamma_move(board, 4, 16, 15) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 11) == 0 );
assert( gamma_move(board, 5, 0, 13) == 1 );
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_move(board, 6, 2, 3) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 8, 6) == 1 );
assert( gamma_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 2, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 7 );
assert( gamma_move(board, 4, 9, 8) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 1, 10) == 1 );
assert( gamma_move(board, 7, 9, 16) == 0 );
assert( gamma_move(board, 7, 15, 2) == 1 );
assert( gamma_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 14, 14) == 1 );
assert( gamma_move(board, 3, 12, 3) == 1 );
assert( gamma_move(board, 4, 8, 14) == 1 );
assert( gamma_free_fields(board, 4) == 195 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_free_fields(board, 5) == 195 );
assert( gamma_move(board, 6, 11, 9) == 1 );
assert( gamma_move(board, 7, 5, 0) == 0 );
assert( gamma_move(board, 7, 14, 11) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 7, 12) == 1 );
assert( gamma_move(board, 2, 2, 5) == 1 );
assert( gamma_move(board, 2, 9, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 4, 4, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 0) == 1 );
assert( gamma_golden_move(board, 5, 10, 6) == 0 );
assert( gamma_move(board, 6, 15, 0) == 0 );
assert( gamma_free_fields(board, 6) == 188 );
assert( gamma_move(board, 7, 12, 5) == 0 );
assert( gamma_move(board, 7, 15, 15) == 1 );
assert( gamma_free_fields(board, 7) == 187 );
assert( gamma_move(board, 1, 15, 10) == 1 );
assert( gamma_move(board, 2, 9, 5) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 4, 2, 10) == 0 );
assert( gamma_move(board, 5, 3, 3) == 1 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_move(board, 6, 8, 1) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 2, 16) == 0 );
assert( gamma_move(board, 7, 5, 4) == 0 );
assert( gamma_move(board, 2, 15, 5) == 1 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 11, 7) == 1 );
assert( gamma_move(board, 3, 0, 1) == 1 );
assert( gamma_move(board, 4, 5, 5) == 1 );
assert( gamma_move(board, 5, 7, 14) == 1 );
assert( gamma_move(board, 5, 16, 6) == 0 );
assert( gamma_move(board, 6, 6, 14) == 1 );
assert( gamma_move(board, 6, 11, 5) == 1 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_free_fields(board, 6) == 177 );


char* board750834270 = gamma_board(board);
assert( board750834270 != NULL );
assert( strcmp(board750834270, 
".6..7...6.....677\n"
".2....654...3.2..\n"
"5...7..6.53......\n"
"4...1..1.5..14.5.\n"
"..14..6.....366..\n"
".61...2.2.7.1751.\n"
".3.........6..1..\n"
"...51....4..1....\n"
"......23...3.....\n"
".....2.274..2...7\n"
"..2..4.456464..2.\n"
"....4746.4......4\n"
"..65..2....73..6.\n"
"....3....1....17.\n"
"3.2..3.462...5.1.\n"
"..1577...6....36.\n") == 0);
free(board750834270);
board750834270 = NULL;
assert( gamma_move(board, 7, 14, 13) == 1 );
assert( gamma_move(board, 7, 15, 8) == 1 );
assert( gamma_move(board, 1, 16, 10) == 1 );
assert( gamma_move(board, 2, 16, 0) == 1 );
assert( gamma_move(board, 3, 11, 7) == 0 );
assert( gamma_move(board, 4, 8, 5) == 0 );
assert( gamma_move(board, 4, 15, 5) == 0 );
assert( gamma_move(board, 5, 12, 16) == 0 );
assert( gamma_move(board, 5, 12, 13) == 1 );
assert( gamma_move(board, 6, 4, 1) == 1 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 2, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 15 );
assert( gamma_move(board, 3, 5, 9) == 1 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 0, 7) == 1 );
assert( gamma_move(board, 4, 4, 6) == 1 );
assert( gamma_move(board, 5, 3, 11) == 0 );
assert( gamma_move(board, 6, 11, 0) == 1 );
assert( gamma_move(board, 7, 0, 13) == 0 );
assert( gamma_free_fields(board, 7) == 165 );
assert( gamma_move(board, 1, 8, 14) == 0 );
assert( gamma_move(board, 2, 10, 2) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_move(board, 4, 11, 8) == 1 );
assert( gamma_move(board, 4, 11, 14) == 1 );
assert( gamma_free_fields(board, 4) == 160 );
assert( gamma_move(board, 5, 0, 10) == 1 );
assert( gamma_move(board, 5, 3, 1) == 1 );
assert( gamma_move(board, 6, 14, 13) == 0 );
assert( gamma_move(board, 7, 3, 0) == 0 );
assert( gamma_move(board, 7, 3, 6) == 1 );
assert( gamma_move(board, 1, 15, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board107050244 = gamma_board(board);
assert( board107050244 != NULL );
assert( strcmp(board107050244, 
".6..7...6.....677\n"
".2....654..43.2..\n"
"5...7..6.53.5.7..\n"
"41..12.1.5..14.5.\n"
"..14..6.....366..\n"
"561...2.2.7.17511\n"
".3...3.....6..1..\n"
"..251....4.41..7.\n"
"4.....23...3.....\n"
"...742.274..2...7\n"
"..2..4.456464..2.\n"
"....4746.4......4\n"
"..65..2..3.73..6.\n"
"....3....12...17.\n"
"3.2563.462...5.1.\n"
"..1577...6.6..362\n") == 0);
free(board107050244);
board107050244 = NULL;
assert( gamma_move(board, 2, 3, 4) == 1 );
assert( gamma_free_fields(board, 2) == 156 );
assert( gamma_move(board, 3, 15, 9) == 1 );
assert( gamma_move(board, 3, 14, 3) == 1 );
assert( gamma_free_fields(board, 4) == 154 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 14, 5) == 1 );
assert( gamma_move(board, 5, 15, 4) == 1 );
assert( gamma_move(board, 6, 15, 11) == 1 );
assert( gamma_move(board, 6, 15, 12) == 0 );
assert( gamma_move(board, 1, 9, 2) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board115473117 = gamma_board(board);
assert( board115473117 != NULL );
assert( strcmp(board115473117, 
".6..7...6.....677\n"
".2....654..43.2..\n"
"5...7..6.53.5.7..\n"
"41..12.1.5..14.5.\n"
"..14..6.....3666.\n"
"561...2.2.7.17511\n"
".3...3.....6..13.\n"
"..251....4.41..7.\n"
"4.....23...3.....\n"
"...742.274..2...7\n"
"..2..4.456464.52.\n"
"...24746.4.....54\n"
"..65..2..3.73.36.\n"
"....3....12...17.\n"
"3.2563.462...5.1.\n"
"..1577...6.6..362\n") == 0);
free(board115473117);
board115473117 = NULL;
assert( gamma_move(board, 2, 12, 3) == 0 );
assert( gamma_move(board, 2, 0, 6) == 1 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_move(board, 4, 11, 7) == 0 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 14, 1) == 1 );
assert( gamma_move(board, 7, 6, 14) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 11, 4) == 1 );
assert( gamma_move(board, 1, 11, 6) == 1 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_move(board, 3, 5, 3) == 1 );
assert( gamma_move(board, 3, 6, 1) == 1 );
assert( gamma_busy_fields(board, 3) == 18 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_move(board, 5, 11, 11) == 1 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_move(board, 7, 9, 15) == 1 );
assert( gamma_busy_fields(board, 7) == 17 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_golden_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 3, 16, 6) == 0 );
assert( gamma_move(board, 3, 14, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 14, 3) == 0 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 7, 13, 16) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_golden_move(board, 1, 5, 7) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 4) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 13) == 0 );
assert( gamma_move(board, 6, 14, 14) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 15, 11) == 0 );
assert( gamma_move(board, 7, 5, 14) == 1 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 7, 9) == 1 );
assert( gamma_move(board, 2, 4, 3) == 1 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 1, 0) == 1 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_free_fields(board, 5) == 136 );
assert( gamma_move(board, 6, 0, 0) == 1 );
assert( gamma_move(board, 6, 7, 8) == 1 );
assert( gamma_move(board, 7, 8, 0) == 1 );
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 1, 0, 5) == 1 );
assert( gamma_busy_fields(board, 1) == 23 );
assert( gamma_move(board, 2, 13, 0) == 1 );
assert( gamma_move(board, 3, 11, 3) == 0 );
assert( gamma_move(board, 4, 9, 13) == 0 );
assert( gamma_move(board, 5, 7, 15) == 1 );
assert( gamma_move(board, 5, 1, 5) == 1 );
assert( gamma_move(board, 6, 0, 0) == 0 );


char* board808496891 = gamma_board(board);
assert( board808496891 != NULL );
assert( strcmp(board808496891, 
".6..7..567....677\n"
".2...7654..43.2..\n"
"5...7..6.53.5.7..\n"
"41..12.1.5..14.5.\n"
"..14..6....53666.\n"
"561...2.2.7.17511\n"
".3...3.2.1.6..13.\n"
"..251..6.4.41..7.\n"
"4.....23...3.....\n"
"2..712.274.121..7\n"
"152..4.456464.52.\n"
".1.24746.4.1...54\n"
"..65232..3.73.36.\n"
"..3.3....12...17.\n"
"3.25633462...561.\n"
"641577..76.6.2362\n") == 0);
free(board808496891);
board808496891 = NULL;
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_move(board, 1, 15, 8) == 0 );
assert( gamma_move(board, 2, 0, 2) == 1 );


char* board619142538 = gamma_board(board);
assert( board619142538 != NULL );
assert( strcmp(board619142538, 
".6..7..567....677\n"
".2...7654..43.2..\n"
"5...7..6.53.5.7..\n"
"41..12.1.5..14.5.\n"
"..14..6....53666.\n"
"561...2.2.7.17511\n"
".3...3.2.1.6..13.\n"
"..251..6.4.41..7.\n"
"4.....23...3.....\n"
"2..712.274.121..7\n"
"152..4.456464.52.\n"
".1.24746.4.1...54\n"
"..65232..3.73.36.\n"
"2.3.3....12...17.\n"
"3.25633462...561.\n"
"641577..76.6.2362\n") == 0);
free(board619142538);
board619142538 = NULL;
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 10, 13) == 0 );
assert( gamma_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 5, 13, 7) == 1 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 6, 1) == 0 );
assert( gamma_move(board, 7, 9, 10) == 1 );
assert( gamma_move(board, 1, 12, 9) == 1 );
assert( gamma_move(board, 1, 10, 6) == 1 );
assert( gamma_move(board, 2, 13, 14) == 1 );
assert( gamma_move(board, 2, 12, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_move(board, 4, 10, 5) == 0 );
assert( gamma_move(board, 4, 0, 10) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 6, 14, 3) == 0 );
assert( gamma_move(board, 7, 5, 6) == 0 );
assert( gamma_move(board, 7, 5, 5) == 0 );
assert( gamma_move(board, 1, 15, 6) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_free_fields(board, 2) == 118 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 5, 8, 10) == 0 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_move(board, 7, 13, 0) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 11, 10) == 1 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 3, 4, 12) == 0 );
assert( gamma_move(board, 4, 3, 16) == 0 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 6, 13, 11) == 0 );
assert( gamma_move(board, 7, 9, 16) == 0 );
assert( gamma_move(board, 7, 2, 2) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 1, 1, 13) == 1 );
assert( gamma_busy_fields(board, 1) == 27 );
assert( gamma_move(board, 2, 9, 3) == 0 );
assert( gamma_free_fields(board, 2) == 116 );
assert( gamma_move(board, 3, 3, 10) == 1 );
assert( gamma_move(board, 3, 0, 4) == 1 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_move(board, 5, 13, 0) == 0 );
assert( gamma_move(board, 6, 13, 16) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 11, 6) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 1, 12, 4) == 1 );
assert( gamma_move(board, 2, 16, 9) == 1 );
assert( gamma_move(board, 2, 8, 11) == 1 );
assert( gamma_move(board, 3, 11, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 20 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 14, 15) == 0 );
assert( gamma_move(board, 5, 15, 10) == 0 );
assert( gamma_free_fields(board, 5) == 111 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 3, 2) == 1 );
assert( gamma_move(board, 7, 3, 13) == 1 );
assert( gamma_move(board, 7, 5, 13) == 1 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 9, 8) == 0 );
assert( gamma_move(board, 2, 2, 12) == 1 );
assert( gamma_busy_fields(board, 2) == 30 );
assert( gamma_move(board, 3, 11, 1) == 1 );
assert( gamma_move(board, 4, 14, 15) == 0 );
assert( gamma_move(board, 4, 13, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 3, 10) == 0 );
assert( gamma_move(board, 5, 15, 1) == 0 );
assert( gamma_move(board, 6, 14, 2) == 0 );
assert( gamma_move(board, 7, 14, 2) == 0 );
assert( gamma_move(board, 1, 2, 7) == 1 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 7, 10) == 1 );
assert( gamma_move(board, 3, 4, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 22 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );


char* board142432906 = gamma_board(board);
assert( board142432906 != NULL );
assert( strcmp(board142432906, 
".6..7..567....677\n"
".2...7654..4322..\n"
"51.777.6.53.5.7..\n"
"412.12.1.5..14.5.\n"
"..14..6.2..53666.\n"
"5613..23277217511\n"
".3...3.2.1.61.132\n"
"..251..6.4.41..7.\n"
"4.1.5.23...3.5...\n"
"2.2712.2741121.17\n"
"152..4.456464.52.\n"
"31.24746.4.11..54\n"
"..65232..3.73.36.\n"
"2.363....12...17.\n"
"3.25633462.32561.\n"
"641577..76.6.2362\n") == 0);
free(board142432906);
board142432906 = NULL;
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_move(board, 6, 6, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 1, 9, 0) == 0 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 2, 6, 12) == 1 );
assert( gamma_move(board, 3, 14, 16) == 0 );
assert( gamma_move(board, 3, 3, 12) == 1 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 14, 4) == 1 );
assert( gamma_move(board, 7, 16, 14) == 1 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_move(board, 4, 8, 0) == 0 );
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_move(board, 6, 8, 16) == 0 );
assert( gamma_move(board, 6, 14, 1) == 0 );
assert( gamma_move(board, 7, 2, 7) == 0 );
assert( gamma_move(board, 1, 5, 4) == 0 );
assert( gamma_free_fields(board, 1) == 98 );
assert( gamma_move(board, 2, 15, 11) == 0 );
assert( gamma_move(board, 2, 16, 3) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_golden_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 5, 13) == 0 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 6, 16, 14) == 0 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 1, 11, 9) == 0 );
assert( gamma_move(board, 1, 7, 11) == 1 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 7, 6) == 0 );
assert( gamma_move(board, 3, 14, 4) == 0 );
assert( gamma_move(board, 3, 10, 15) == 1 );
assert( gamma_move(board, 4, 16, 7) == 1 );
assert( gamma_move(board, 4, 1, 6) == 1 );
assert( gamma_move(board, 5, 15, 11) == 0 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 6, 16, 3) == 0 );


char* board231629062 = gamma_board(board);
assert( board231629062 != NULL );
assert( strcmp(board231629062, 
".6..7..5673...677\n"
".2...7654..4322.7\n"
"51.777.6.53.5.7..\n"
"41231221.5..14.5.\n"
"3.14..612..53666.\n"
"5613..23277217511\n"
".3...3.2.1.61.132\n"
"..251..6.4.41..7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152..4.456464.52.\n"
"31.24746.4.11.754\n"
"..65232..3.73.362\n"
"2.363....12...17.\n"
"3.25633462.32561.\n"
"6415774.76.6.2362\n") == 0);
free(board231629062);
board231629062 = NULL;
assert( gamma_move(board, 7, 2, 5) == 0 );
assert( gamma_move(board, 7, 5, 9) == 0 );
assert( gamma_move(board, 1, 3, 0) == 0 );
assert( gamma_move(board, 1, 2, 5) == 0 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 2, 6, 7) == 0 );
assert( gamma_move(board, 3, 2, 13) == 1 );
assert( gamma_move(board, 4, 5, 16) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 5, 8, 2) == 1 );
assert( gamma_move(board, 6, 4, 3) == 0 );
assert( gamma_move(board, 7, 0, 7) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 0, 6) == 0 );
assert( gamma_move(board, 2, 11, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 32 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 4, 14, 2) == 0 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_move(board, 5, 14, 15) == 0 );
assert( gamma_move(board, 5, 0, 3) == 1 );
assert( gamma_move(board, 6, 2, 12) == 0 );
assert( gamma_move(board, 6, 8, 11) == 0 );
assert( gamma_move(board, 7, 15, 12) == 0 );
assert( gamma_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 1, 1, 1) == 1 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 2, 14) == 1 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 6, 12, 16) == 0 );
assert( gamma_move(board, 7, 13, 15) == 1 );
assert( gamma_move(board, 7, 0, 14) == 1 );
assert( gamma_move(board, 1, 15, 0) == 0 );
assert( gamma_move(board, 1, 9, 11) == 1 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 3, 2, 5) == 0 );
assert( gamma_move(board, 3, 8, 10) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_free_fields(board, 4) == 85 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 6, 6, 14) == 0 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 2, 12, 9) == 0 );
assert( gamma_golden_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 6, 2, 7) == 0 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board124287894 = gamma_board(board);
assert( board124287894 != NULL );
assert( strcmp(board124287894, 
".6..7..5673..7677\n"
"722..7654..4322.7\n"
"513777.6.53.5.7..\n"
"41231221.5..14.5.\n"
"3.14..6121.53666.\n"
"5613..23277217511\n"
".3...3.2.1.61.132\n"
"..251..6.4.41..7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152..4.456464.52.\n"
"31.24746.4.11.754\n"
"5.65232..3.73.362\n"
"2.363...512...17.\n"
"3125633462.32561.\n"
"6415774.76.6.2362\n") == 0);
free(board124287894);
board124287894 = NULL;
assert( gamma_move(board, 7, 4, 5) == 1 );
assert( gamma_busy_fields(board, 7) == 27 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 8, 11) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 13, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 5, 12) == 0 );
assert( gamma_free_fields(board, 5) == 83 );
assert( gamma_move(board, 6, 11, 3) == 0 );
assert( gamma_move(board, 6, 10, 13) == 0 );
assert( gamma_busy_fields(board, 6) == 25 );
assert( gamma_move(board, 7, 12, 11) == 0 );
assert( gamma_move(board, 7, 7, 10) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 2, 4, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 9, 11) == 0 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );


char* board265489629 = gamma_board(board);
assert( board265489629 != NULL );
assert( strcmp(board265489629, 
".6..7..5673..7677\n"
"722..7654..4322.7\n"
"513777.6.53.5.7..\n"
"41231221.5..14.5.\n"
"3.14..6121.53666.\n"
"5613..23277217511\n"
".3...3.2.1.614132\n"
"..251..6.4.41..7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152.74.456464.52.\n"
"31.24746.4.11.754\n"
"5.65232..3.73.362\n"
"2.363...512...17.\n"
"3125633462.32561.\n"
"6415774.76.6.2362\n") == 0);
free(board265489629);
board265489629 = NULL;
assert( gamma_move(board, 7, 6, 8) == 1 );
assert( gamma_busy_fields(board, 7) == 28 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 1, 1, 11) == 1 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_free_fields(board, 1) == 81 );
assert( gamma_move(board, 2, 7, 3) == 1 );
assert( gamma_move(board, 2, 13, 15) == 0 );
assert( gamma_free_fields(board, 2) == 80 );
assert( gamma_golden_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 9, 0) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_move(board, 4, 8, 15) == 0 );
assert( gamma_move(board, 4, 8, 4) == 1 );
assert( gamma_free_fields(board, 4) == 79 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 5) == 0 );
assert( gamma_move(board, 7, 6, 11) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_free_fields(board, 2) == 79 );
assert( gamma_move(board, 3, 12, 11) == 0 );
assert( gamma_move(board, 4, 8, 16) == 0 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 5, 13) == 0 );
assert( gamma_move(board, 5, 4, 9) == 1 );
assert( gamma_move(board, 6, 11, 13) == 1 );
assert( gamma_move(board, 7, 11, 10) == 0 );
assert( gamma_move(board, 7, 7, 10) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_move(board, 2, 7, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 11, 4) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 12, 10) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_free_fields(board, 4) == 75 );
assert( gamma_move(board, 5, 14, 3) == 0 );
assert( gamma_move(board, 5, 3, 5) == 1 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 7, 12, 16) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 3, 13, 13) == 1 );
assert( gamma_free_fields(board, 3) == 73 );
assert( gamma_move(board, 4, 16, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_golden_move(board, 4, 15, 7) == 0 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 8, 0) == 0 );
assert( gamma_move(board, 6, 6, 4) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 5, 3) == 0 );
assert( gamma_move(board, 1, 14, 9) == 0 );
assert( gamma_move(board, 1, 15, 4) == 0 );


char* board454766115 = gamma_board(board);
assert( board454766115 != NULL );
assert( strcmp(board454766115, 
".6..7..5673..7677\n"
"722..7654..4322.7\n"
"513777.6.536537..\n"
"41231221.5..14.5.\n"
"3114..6121153666.\n"
"5613..23277217511\n"
".34.53.2.1.614132\n"
"..251.76.4.41..7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152574.456464.524\n"
"31.2474644.11.754\n"
"5.652322.3.73.362\n"
"2.363...512...17.\n"
"3125633462.32561.\n"
"6415774.76.6.2362\n") == 0);
free(board454766115);
board454766115 = NULL;
assert( gamma_move(board, 2, 7, 1) == 0 );
assert( gamma_move(board, 3, 4, 1) == 0 );
assert( gamma_move(board, 3, 16, 1) == 1 );
assert( gamma_move(board, 4, 2, 16) == 0 );
assert( gamma_move(board, 4, 1, 14) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 7, 12) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );


char* board441634554 = gamma_board(board);
assert( board441634554 != NULL );
assert( strcmp(board441634554, 
".6..7..5673..7677\n"
"722..7654..4322.7\n"
"513777.6.536537..\n"
"41231221.5..14.5.\n"
"3114..6121153666.\n"
"5613..23277217511\n"
".34.53.2.1.614132\n"
"..251.76.4.41..7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152574.456464.524\n"
"31.2474644.11.754\n"
"5.652322.3.73.362\n"
"2.363...512...17.\n"
"3125633462.325613\n"
"6415774.76.6.2362\n") == 0);
free(board441634554);
board441634554 = NULL;
assert( gamma_free_fields(board, 2) == 71 );
assert( gamma_move(board, 3, 13, 8) == 1 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 4, 7, 12) == 0 );
assert( gamma_free_fields(board, 4) == 70 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_free_fields(board, 5) == 70 );
assert( gamma_golden_move(board, 5, 12, 1) == 1 );
assert( gamma_move(board, 6, 10, 4) == 1 );
assert( gamma_free_fields(board, 6) == 69 );


char* board668502499 = gamma_board(board);
assert( board668502499 != NULL );
assert( strcmp(board668502499, 
".6..7..5673..7677\n"
"722..7654..4322.7\n"
"513777.6.536537..\n"
"41231221.5..14.5.\n"
"3114..6121153666.\n"
"5613..23277217511\n"
".34.53.2.1.614132\n"
"..251.76.4.413.7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.73.362\n"
"2.363...512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board668502499);
board668502499 = NULL;
assert( gamma_move(board, 7, 1, 12) == 0 );
assert( gamma_free_fields(board, 7) == 69 );
assert( gamma_move(board, 1, 6, 2) == 1 );
assert( gamma_move(board, 1, 11, 15) == 1 );
assert( gamma_move(board, 2, 12, 4) == 0 );
assert( gamma_move(board, 3, 11, 5) == 0 );
assert( gamma_move(board, 3, 7, 3) == 0 );
assert( gamma_move(board, 4, 15, 0) == 0 );
assert( gamma_free_fields(board, 4) == 67 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_move(board, 6, 6, 9) == 1 );


char* board651771973 = gamma_board(board);
assert( board651771973 != NULL );
assert( strcmp(board651771973, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.6.536537..\n"
"41231221.5..14.5.\n"
"3114..6121153666.\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.4.413.7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.73.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board651771973);
board651771973 = NULL;
assert( gamma_move(board, 7, 11, 10) == 0 );


char* board322414810 = gamma_board(board);
assert( board322414810 != NULL );
assert( strcmp(board322414810, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.6.536537..\n"
"41231221.5..14.5.\n"
"3114..6121153666.\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.4.413.7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.73.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board322414810);
board322414810 = NULL;
assert( gamma_move(board, 2, 10, 12) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 5) == 0 );
assert( gamma_free_fields(board, 3) == 65 );
assert( gamma_move(board, 4, 3, 1) == 0 );
assert( gamma_move(board, 4, 11, 3) == 0 );
assert( gamma_move(board, 5, 1, 10) == 0 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_move(board, 7, 13, 8) == 0 );
assert( gamma_move(board, 7, 8, 13) == 1 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_golden_move(board, 7, 12, 3) == 1 );
assert( gamma_move(board, 1, 5, 1) == 0 );
assert( gamma_golden_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 4, 3, 5) == 0 );
assert( gamma_move(board, 5, 14, 2) == 0 );
assert( gamma_golden_move(board, 5, 6, 0) == 0 );
assert( gamma_move(board, 6, 15, 3) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 11, 16) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 4, 0, 12) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_free_fields(board, 4) == 64 );
assert( gamma_move(board, 5, 5, 1) == 0 );
assert( gamma_move(board, 6, 3, 13) == 0 );
assert( gamma_move(board, 6, 12, 13) == 0 );
assert( gamma_move(board, 7, 2, 11) == 0 );
assert( gamma_move(board, 7, 3, 3) == 0 );


char* board916689660 = gamma_board(board);
assert( board916689660 != NULL );
assert( strcmp(board916689660, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.67536537..\n"
"41231221.52.14.5.\n"
"3114..6121153666.\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.4.413.7.\n"
"4.1.5.23...3.5..4\n"
"242712.2741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board916689660);
board916689660 = NULL;
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_busy_fields(board, 2) == 34 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_move(board, 4, 7, 14) == 0 );
assert( gamma_move(board, 6, 14, 15) == 0 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_move(board, 7, 14, 9) == 0 );
assert( gamma_move(board, 7, 15, 10) == 0 );
assert( gamma_busy_fields(board, 7) == 30 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 8, 16) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 4, 8, 16) == 0 );
assert( gamma_move(board, 4, 8, 12) == 1 );
assert( gamma_free_fields(board, 4) == 63 );
assert( gamma_move(board, 6, 2, 0) == 0 );
assert( gamma_move(board, 7, 7, 8) == 0 );
assert( gamma_move(board, 7, 8, 15) == 0 );
assert( gamma_move(board, 1, 10, 5) == 0 );
assert( gamma_move(board, 1, 16, 9) == 0 );
assert( gamma_move(board, 2, 3, 1) == 0 );
assert( gamma_move(board, 2, 13, 8) == 0 );
assert( gamma_move(board, 3, 14, 3) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 4, 16, 11) == 1 );
assert( gamma_free_fields(board, 4) == 62 );
assert( gamma_move(board, 5, 8, 5) == 0 );
assert( gamma_free_fields(board, 5) == 62 );
assert( gamma_move(board, 6, 1, 10) == 0 );
assert( gamma_move(board, 6, 3, 3) == 0 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_golden_move(board, 7, 4, 7) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_move(board, 1, 5, 12) == 0 );
assert( gamma_move(board, 2, 15, 11) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 5, 7, 1) == 0 );
assert( gamma_move(board, 5, 5, 9) == 0 );
assert( gamma_move(board, 6, 1, 10) == 0 );
assert( gamma_move(board, 6, 14, 3) == 0 );
assert( gamma_free_fields(board, 6) == 62 );
assert( gamma_move(board, 7, 2, 13) == 0 );
assert( gamma_move(board, 7, 4, 13) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 6, 1) == 0 );
assert( gamma_free_fields(board, 1) == 62 );
assert( gamma_move(board, 2, 2, 1) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 3, 2, 16) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 4, 12, 6) == 0 );
assert( gamma_move(board, 5, 0, 10) == 0 );
assert( gamma_move(board, 5, 4, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 26 );
assert( gamma_golden_move(board, 5, 2, 3) == 0 );
assert( gamma_move(board, 6, 14, 2) == 0 );
assert( gamma_move(board, 7, 9, 8) == 0 );
assert( gamma_move(board, 7, 12, 3) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 10, 8) == 1 );
assert( gamma_move(board, 2, 6, 6) == 1 );


char* board277977299 = gamma_board(board);
assert( board277977299 != NULL );
assert( strcmp(board277977299, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"3114..61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23...3.5..4\n"
"24271222741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board277977299);
board277977299 = NULL;
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 6, 16, 15) == 0 );


char* board833260391 = gamma_board(board);
assert( board833260391 != NULL );
assert( strcmp(board833260391, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"3114..61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23...3.5..4\n"
"24271222741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board833260391);
board833260391 = NULL;
assert( gamma_move(board, 7, 14, 10) == 0 );
assert( gamma_move(board, 7, 3, 1) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 1, 4, 0) == 0 );


char* board611784797 = gamma_board(board);
assert( board611784797 != NULL );
assert( strcmp(board611784797, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"3114..61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23...3.5..4\n"
"24271222741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board611784797);
board611784797 = NULL;
assert( gamma_move(board, 2, 4, 4) == 0 );
assert( gamma_move(board, 3, 0, 0) == 0 );


char* board262414249 = gamma_board(board);
assert( board262414249 != NULL );
assert( strcmp(board262414249, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"3114..61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23...3.5..4\n"
"24271222741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board262414249);
board262414249 = NULL;
assert( gamma_move(board, 4, 6, 4) == 0 );
assert( gamma_move(board, 4, 14, 2) == 0 );


char* board125687949 = gamma_board(board);
assert( board125687949 != NULL );
assert( strcmp(board125687949, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"3114..61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23...3.5..4\n"
"24271222741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board125687949);
board125687949 = NULL;
assert( gamma_move(board, 5, 9, 8) == 0 );
assert( gamma_move(board, 5, 3, 3) == 0 );


char* board155193411 = gamma_board(board);
assert( board155193411 != NULL );
assert( strcmp(board155193411, 
".6..7..56731.7677\n"
"722..7654..4322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"3114..61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23...3.5..4\n"
"24271222741121.17\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board155193411);
board155193411 = NULL;
assert( gamma_move(board, 6, 7, 8) == 0 );
assert( gamma_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 7, 7, 7) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_golden_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 8, 5) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 3, 4, 8) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 4, 14, 13) == 0 );
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 5, 9, 7) == 1 );
assert( gamma_golden_move(board, 5, 14, 6) == 0 );
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_move(board, 7, 0, 12) == 0 );
assert( gamma_move(board, 1, 7, 6) == 0 );
assert( gamma_free_fields(board, 2) == 59 );
assert( gamma_move(board, 3, 10, 14) == 1 );
assert( gamma_move(board, 3, 7, 15) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 4) == 0 );
assert( gamma_free_fields(board, 4) == 58 );
assert( gamma_move(board, 5, 8, 0) == 0 );
assert( gamma_move(board, 6, 14, 2) == 0 );
assert( gamma_move(board, 7, 11, 5) == 0 );
assert( gamma_move(board, 7, 14, 6) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 9, 3) == 0 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 10, 4) == 0 );
assert( gamma_busy_fields(board, 5) == 27 );
assert( gamma_free_fields(board, 5) == 57 );
assert( gamma_move(board, 6, 3, 1) == 0 );
assert( gamma_move(board, 6, 11, 1) == 0 );
assert( gamma_free_fields(board, 6) == 57 );
assert( gamma_move(board, 7, 4, 11) == 1 );


char* board438993839 = gamma_board(board);
assert( board438993839 != NULL );
assert( strcmp(board438993839, 
".6..7..56731.7677\n"
"722..7654.34322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"31147.61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23.5.3.5..4\n"
"24271222741121717\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board438993839);
board438993839 = NULL;
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 11, 13) == 0 );
assert( gamma_move(board, 4, 2, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 2, 5) == 0 );


char* board929540017 = gamma_board(board);
assert( board929540017 != NULL );
assert( strcmp(board929540017, 
".6..7..56731.7677\n"
"722..7654.34322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"31147.61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23.5.3.5..4\n"
"24271222741121717\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3.77.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board929540017);
board929540017 = NULL;
assert( gamma_move(board, 6, 11, 14) == 0 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_move(board, 7, 15, 5) == 0 );
assert( gamma_move(board, 7, 13, 12) == 0 );
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_busy_fields(board, 1) == 37 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_move(board, 4, 10, 3) == 1 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 6, 0, 2) == 0 );
assert( gamma_move(board, 7, 12, 14) == 0 );
assert( gamma_move(board, 7, 16, 3) == 0 );


char* board872353377 = gamma_board(board);
assert( board872353377 != NULL );
assert( strcmp(board872353377, 
".6..7..56731.7677\n"
"722..7654.34322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"31147.61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23.5.3.5..4\n"
"24271222741121717\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3477.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board872353377);
board872353377 = NULL;
assert( gamma_golden_move(board, 1, 15, 16) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_busy_fields(board, 2) == 35 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 3, 1, 13) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 4, 8, 10) == 0 );


char* board683049178 = gamma_board(board);
assert( board683049178 != NULL );
assert( strcmp(board683049178, 
".6..7..56731.7677\n"
"722..7654.34322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"31147.61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23.5.3.5..4\n"
"24271222741121717\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3477.362\n"
"2.363.1.512...17.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board683049178);
board683049178 = NULL;
assert( gamma_move(board, 5, 15, 3) == 0 );
assert( gamma_move(board, 6, 8, 1) == 0 );
assert( gamma_move(board, 6, 6, 9) == 0 );
assert( gamma_free_fields(board, 6) == 55 );
assert( gamma_move(board, 7, 1, 10) == 0 );
assert( gamma_move(board, 7, 15, 6) == 0 );
assert( gamma_move(board, 1, 8, 0) == 0 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 12, 15) == 0 );
assert( gamma_move(board, 4, 14, 4) == 0 );
assert( gamma_move(board, 4, 11, 13) == 0 );
assert( gamma_free_fields(board, 4) == 55 );
assert( gamma_move(board, 5, 14, 9) == 0 );
assert( gamma_move(board, 6, 4, 8) == 0 );
assert( gamma_move(board, 7, 2, 13) == 0 );
assert( gamma_move(board, 7, 13, 0) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 12, 15) == 1 );
assert( gamma_move(board, 4, 1, 5) == 0 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 4, 13) == 0 );
assert( gamma_move(board, 6, 4, 2) == 0 );
assert( gamma_move(board, 7, 14, 3) == 0 );
assert( gamma_move(board, 7, 13, 2) == 1 );
assert( gamma_golden_possible(board, 7) == 0 );


char* board599198643 = gamma_board(board);
assert( board599198643 != NULL );
assert( strcmp(board599198643, 
".6..7..5673137677\n"
"722..7654.34322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"31147.61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76.41413.7.\n"
"4.1.5.23.5.3.5..4\n"
"24271222741121717\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3477.362\n"
"2.363.1.512..717.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board599198643);
board599198643 = NULL;
assert( gamma_move(board, 1, 3, 3) == 0 );
assert( gamma_free_fields(board, 1) == 53 );
assert( gamma_move(board, 2, 8, 8) == 1 );
assert( gamma_move(board, 3, 15, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 7, 15, 10) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_free_fields(board, 2) == 52 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_busy_fields(board, 4) == 29 );


char* board494193342 = gamma_board(board);
assert( board494193342 != NULL );
assert( strcmp(board494193342, 
".6..7..5673137677\n"
"722..7654.34322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"31147.61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76241413.7.\n"
"4.1.5.23.5.3.5..4\n"
"24271222741121717\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3477.362\n"
"2.363.1.512..717.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board494193342);
board494193342 = NULL;
assert( gamma_move(board, 5, 8, 16) == 0 );
assert( gamma_free_fields(board, 5) == 52 );
assert( gamma_move(board, 6, 9, 3) == 0 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_move(board, 7, 8, 16) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );


char* board537621043 = gamma_board(board);
assert( board537621043 != NULL );
assert( strcmp(board537621043, 
".6..7..5673137677\n"
"722..7654.34322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"31147.61211536664\n"
"5613..23277217511\n"
".34.5362.1.614132\n"
"..251.76241413.7.\n"
"4.1.5.23.5.3.5..4\n"
"24271222741121717\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3477.362\n"
"2.363.1.512..717.\n"
"3125633462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board537621043);
board537621043 = NULL;
assert( gamma_move(board, 2, 15, 0) == 0 );
assert( gamma_move(board, 3, 5, 2) == 1 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 4, 11, 2) == 1 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_free_fields(board, 4) == 50 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 4, 6) == 0 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_move(board, 6, 15, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_golden_move(board, 6, 14, 16) == 0 );
assert( gamma_move(board, 7, 13, 6) == 0 );
assert( gamma_move(board, 7, 7, 1) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 1, 3, 15) == 1 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_move(board, 2, 10, 10) == 0 );
assert( gamma_free_fields(board, 2) == 48 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 4, 4, 2) == 0 );
assert( gamma_move(board, 5, 3, 8) == 0 );
assert( gamma_move(board, 6, 16, 1) == 0 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 3, 13) == 0 );
assert( gamma_move(board, 3, 8, 2) == 0 );
assert( gamma_move(board, 3, 12, 6) == 0 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 4, 8, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 30 );
assert( gamma_move(board, 5, 12, 4) == 0 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 6, 7, 4) == 0 );
assert( gamma_move(board, 7, 4, 2) == 0 );
assert( gamma_busy_fields(board, 7) == 33 );
assert( gamma_move(board, 1, 9, 10) == 0 );
assert( gamma_free_fields(board, 1) == 48 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 13, 7) == 0 );
assert( gamma_busy_fields(board, 2) == 36 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 5, 1) == 1 );
assert( gamma_move(board, 3, 10, 15) == 0 );
assert( gamma_move(board, 3, 0, 11) == 0 );
assert( gamma_move(board, 4, 8, 16) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_move(board, 6, 8, 16) == 0 );
assert( gamma_move(board, 7, 8, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 3, 7, 8) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 14) == 0 );
assert( gamma_move(board, 6, 12, 12) == 0 );
assert( gamma_move(board, 6, 5, 6) == 0 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_golden_possible(board, 7) == 0 );
assert( gamma_move(board, 1, 12, 5) == 0 );
assert( gamma_move(board, 2, 0, 7) == 0 );
assert( gamma_move(board, 2, 5, 11) == 1 );
assert( gamma_golden_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );


char* board159057983 = gamma_board(board);
assert( board159057983 != NULL );
assert( strcmp(board159057983, 
".6.17..5673137677\n"
"722..7654.34322.7\n"
"513777.67536537..\n"
"41231221452.14.5.\n"
"31147261211536664\n"
"56134.23277217511\n"
".34.5362.1.614132\n"
"..251.76241413.7.\n"
"4.1.5.23.5.3.5..4\n"
"24271222741121717\n"
"152574.456464.524\n"
"31.2474644611.754\n"
"5.652322.3477.362\n"
"2.3633115124.717.\n"
"3125623462.355613\n"
"6415774.76.6.2362\n") == 0);
free(board159057983);
board159057983 = NULL;
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 5, 7, 14) == 0 );
assert( gamma_move(board, 5, 7, 3) == 0 );
assert( gamma_move(board, 6, 15, 6) == 0 );
assert( gamma_free_fields(board, 6) == 46 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 5, 13) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 13, 6) == 0 );
assert( gamma_move(board, 5, 5, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 28 );
assert( gamma_free_fields(board, 6) == 46 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 3) == 0 );
assert( gamma_busy_fields(board, 7) == 33 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_free_fields(board, 2) == 46 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 4, 5, 10) == 1 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_golden_move(board, 5, 14, 5) == 0 );


gamma_delete(board);

    return 0;
}
