#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 142498472
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(12, 16, 6, 20);
assert( board != NULL );


assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 2, 0, 12) == 1 );
assert( gamma_move(board, 2, 10, 8) == 1 );
assert( gamma_free_fields(board, 3) == 189 );
assert( gamma_move(board, 4, 6, 12) == 1 );
assert( gamma_move(board, 4, 2, 14) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 11, 10) == 1 );
assert( gamma_move(board, 5, 3, 8) == 1 );
assert( gamma_move(board, 6, 8, 13) == 1 );
assert( gamma_move(board, 1, 3, 11) == 1 );
assert( gamma_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_move(board, 3, 2, 2) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 5, 5, 3) == 1 );
assert( gamma_move(board, 5, 10, 1) == 1 );
assert( gamma_move(board, 6, 2, 12) == 1 );
assert( gamma_busy_fields(board, 6) == 2 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 1, 4, 6) == 1 );
assert( gamma_move(board, 3, 7, 13) == 1 );
assert( gamma_move(board, 3, 9, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 12) == 1 );
assert( gamma_free_fields(board, 4) == 173 );
assert( gamma_move(board, 5, 1, 3) == 1 );
assert( gamma_move(board, 6, 6, 1) == 1 );
assert( gamma_busy_fields(board, 6) == 3 );
assert( gamma_golden_move(board, 1, 12, 2) == 0 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 2, 4, 11) == 1 );
assert( gamma_free_fields(board, 2) == 170 );
assert( gamma_move(board, 3, 6, 1) == 0 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 4, 8, 9) == 1 );
assert( gamma_move(board, 4, 5, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 5, 14, 1) == 0 );
assert( gamma_move(board, 5, 9, 3) == 1 );
assert( gamma_move(board, 6, 7, 1) == 1 );
assert( gamma_busy_fields(board, 6) == 4 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 8, 6) == 1 );
assert( gamma_move(board, 2, 14, 3) == 0 );
assert( gamma_move(board, 3, 3, 7) == 1 );
assert( gamma_move(board, 3, 1, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 6 );
assert( gamma_move(board, 4, 10, 3) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 8) == 1 );
assert( gamma_move(board, 5, 1, 14) == 1 );
assert( gamma_move(board, 6, 7, 12) == 1 );
assert( gamma_move(board, 6, 7, 11) == 1 );
assert( gamma_move(board, 1, 10, 12) == 1 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 2, 3, 14) == 1 );
assert( gamma_golden_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 4, 7) == 1 );
assert( gamma_move(board, 3, 11, 8) == 1 );
assert( gamma_move(board, 4, 1, 1) == 1 );
assert( gamma_move(board, 5, 0, 8) == 1 );
assert( gamma_move(board, 6, 4, 4) == 1 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 1, 0, 0) == 1 );


char* board983049786 = gamma_board(board);
assert( board983049786 != NULL );
assert( strcmp(board983049786, 
"............\n"
".542........\n"
".......36...\n"
"2.6.4.46..1.\n"
"...12..6....\n"
".3.........5\n"
"........4...\n"
"5..5.4..5.23\n"
"...33....3..\n"
"....1...1...\n"
"............\n"
"....6....1..\n"
".5...5...54.\n"
"..31.......3\n"
"24....66..5.\n"
"1...........\n") == 0);
free(board983049786);
board983049786 = NULL;
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 2, 5, 6) == 1 );


char* board205646575 = gamma_board(board);
assert( board205646575 != NULL );
assert( strcmp(board205646575, 
"............\n"
".542........\n"
".......36...\n"
"2.6.4.46..1.\n"
"...12..6....\n"
".3.........5\n"
"........4...\n"
"5..5.4..5.23\n"
"...33....3..\n"
"....12..1...\n"
"............\n"
"....6....1..\n"
".5...5...54.\n"
"..31.......3\n"
"24....66..5.\n"
"1...........\n") == 0);
free(board205646575);
board205646575 = NULL;
assert( gamma_free_fields(board, 4) == 148 );
assert( gamma_move(board, 5, 0, 2) == 1 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_busy_fields(board, 6) == 7 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 1, 9) == 1 );
assert( gamma_move(board, 2, 0, 3) == 1 );
assert( gamma_move(board, 3, 9, 2) == 1 );
assert( gamma_move(board, 3, 1, 1) == 0 );


char* board664711274 = gamma_board(board);
assert( board664711274 != NULL );
assert( strcmp(board664711274, 
"............\n"
".542........\n"
".......36...\n"
"2.6.4.46..1.\n"
"...12..6....\n"
".3.........5\n"
".2......4...\n"
"5..5.4..5.23\n"
"...33....3..\n"
"....12..1...\n"
"............\n"
"....6....1..\n"
"25...5...54.\n"
"5.31.....3.3\n"
"24....66..5.\n"
"1...........\n") == 0);
free(board664711274);
board664711274 = NULL;
assert( gamma_move(board, 4, 11, 9) == 1 );
assert( gamma_golden_move(board, 4, 0, 0) == 1 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_move(board, 5, 12, 0) == 0 );
assert( gamma_move(board, 6, 9, 4) == 0 );
assert( gamma_move(board, 6, 4, 12) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 11, 1) == 1 );
assert( gamma_move(board, 3, 8, 2) == 1 );
assert( gamma_move(board, 3, 11, 2) == 0 );
assert( gamma_move(board, 4, 6, 3) == 1 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_move(board, 5, 4, 5) == 1 );
assert( gamma_move(board, 5, 2, 9) == 1 );
assert( gamma_move(board, 6, 5, 5) == 1 );
assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_move(board, 1, 11, 8) == 0 );
assert( gamma_move(board, 2, 13, 5) == 0 );
assert( gamma_move(board, 2, 2, 10) == 1 );
assert( gamma_move(board, 3, 10, 8) == 0 );
assert( gamma_move(board, 3, 7, 2) == 1 );
assert( gamma_move(board, 5, 7, 8) == 0 );
assert( gamma_move(board, 6, 10, 5) == 1 );
assert( gamma_move(board, 6, 0, 15) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 12, 8) == 0 );


char* board839707399 = gamma_board(board);
assert( board839707399 != NULL );
assert( strcmp(board839707399, 
"6...........\n"
".542........\n"
".......36...\n"
"2.6.4.46..1.\n"
"...12..6....\n"
".32........5\n"
".25.....4..4\n"
"5..5.4.15.23\n"
"...33....3..\n"
"....12..1...\n"
"4...56....6.\n"
"....6....1..\n"
"25...54..54.\n"
"5.31...333.3\n"
"24....66..52\n"
"4...........\n") == 0);
free(board839707399);
board839707399 = NULL;
assert( gamma_move(board, 2, 13, 1) == 0 );
assert( gamma_free_fields(board, 2) == 131 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 14, 9) == 0 );
assert( gamma_move(board, 3, 11, 14) == 1 );
assert( gamma_busy_fields(board, 3) == 12 );
assert( gamma_move(board, 4, 0, 4) == 1 );
assert( gamma_move(board, 5, 8, 9) == 0 );
assert( gamma_move(board, 5, 11, 11) == 1 );
assert( gamma_move(board, 6, 11, 6) == 1 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 11, 11) == 0 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_busy_fields(board, 3) == 13 );
assert( gamma_golden_move(board, 3, 6, 8) == 0 );
assert( gamma_move(board, 4, 13, 1) == 0 );
assert( gamma_move(board, 4, 1, 5) == 1 );
assert( gamma_move(board, 5, 5, 2) == 1 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_golden_move(board, 5, 3, 0) == 0 );
assert( gamma_move(board, 6, 14, 4) == 0 );
assert( gamma_move(board, 6, 3, 10) == 1 );
assert( gamma_busy_fields(board, 6) == 12 );


char* board912557411 = gamma_board(board);
assert( board912557411 != NULL );
assert( strcmp(board912557411, 
"6...........\n"
".542.......3\n"
".......36...\n"
"2.6.4.46..1.\n"
"...12..6...5\n"
".326..3....5\n"
".25.....4..4\n"
"5..5.4.15.23\n"
"...33....3..\n"
"....12..1..6\n"
"44..56....6.\n"
"4...6....1..\n"
"25...54..54.\n"
"5.31.5.333.3\n"
"24....66..52\n"
"4...........\n") == 0);
free(board912557411);
board912557411 = NULL;
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 2, 6, 5) == 1 );
assert( gamma_free_fields(board, 2) == 122 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 10, 9) == 1 );
assert( gamma_move(board, 5, 13, 5) == 0 );
assert( gamma_move(board, 5, 7, 4) == 1 );
assert( gamma_move(board, 6, 1, 2) == 1 );
assert( gamma_free_fields(board, 6) == 118 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 2, 6, 8) == 1 );
assert( gamma_move(board, 4, 5, 13) == 1 );
assert( gamma_move(board, 4, 8, 14) == 1 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_golden_move(board, 5, 5, 5) == 1 );
assert( gamma_move(board, 6, 7, 13) == 0 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 2, 8, 2) == 0 );
assert( gamma_free_fields(board, 2) == 114 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 7, 2) == 0 );


char* board272083457 = gamma_board(board);
assert( board272083457 != NULL );
assert( strcmp(board272083457, 
"6...........\n"
".542....4..3\n"
".....4.36...\n"
"2.6.4.46..1.\n"
"...12..6...5\n"
".326..3....5\n"
".25.....4.44\n"
"5..5.4215.23\n"
"...33....3..\n"
".3..12..1..6\n"
"44..552.1.6.\n"
"4...6..5.1..\n"
"25...54..54.\n"
"5631.5.333.3\n"
"24....66..52\n"
"4...........\n") == 0);
free(board272083457);
board272083457 = NULL;
assert( gamma_move(board, 5, 2, 10) == 0 );
assert( gamma_move(board, 5, 10, 15) == 1 );
assert( gamma_free_fields(board, 5) == 113 );


char* board686564878 = gamma_board(board);
assert( board686564878 != NULL );
assert( strcmp(board686564878, 
"6.........5.\n"
".542....4..3\n"
".....4.36...\n"
"2.6.4.46..1.\n"
"...12..6...5\n"
".326..3....5\n"
".25.....4.44\n"
"5..5.4215.23\n"
"...33....3..\n"
".3..12..1..6\n"
"44..552.1.6.\n"
"4...6..5.1..\n"
"25...54..54.\n"
"5631.5.333.3\n"
"24....66..52\n"
"4...........\n") == 0);
free(board686564878);
board686564878 = NULL;
assert( gamma_move(board, 6, 10, 0) == 1 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_free_fields(board, 1) == 112 );


char* board208954703 = gamma_board(board);
assert( board208954703 != NULL );
assert( strcmp(board208954703, 
"6.........5.\n"
".542....4..3\n"
".....4.36...\n"
"2.6.4.46..1.\n"
"...12..6...5\n"
".326..3....5\n"
".25.....4.44\n"
"5..5.4215.23\n"
"...33....3..\n"
".3..12..1..6\n"
"44..552.1.6.\n"
"4...6..5.1..\n"
"25...54..54.\n"
"5631.5.333.3\n"
"24....66..52\n"
"4.........6.\n") == 0);
free(board208954703);
board208954703 = NULL;
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_free_fields(board, 2) == 112 );
assert( gamma_move(board, 3, 3, 9) == 1 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_move(board, 6, 15, 1) == 0 );
assert( gamma_move(board, 1, 14, 4) == 0 );
assert( gamma_move(board, 1, 1, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 9 );
assert( gamma_free_fields(board, 1) == 110 );
assert( gamma_move(board, 2, 14, 5) == 0 );
assert( gamma_move(board, 3, 7, 7) == 1 );
assert( gamma_move(board, 3, 3, 0) == 1 );
assert( gamma_busy_fields(board, 3) == 17 );
assert( gamma_move(board, 4, 9, 8) == 1 );
assert( gamma_move(board, 4, 2, 5) == 1 );
assert( gamma_move(board, 5, 7, 9) == 1 );
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_move(board, 6, 5, 9) == 1 );
assert( gamma_move(board, 6, 6, 13) == 1 );
assert( gamma_golden_move(board, 6, 14, 3) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 2, 6) == 1 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 15, 11) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );


char* board292891829 = gamma_board(board);
assert( board292891829 != NULL );
assert( strcmp(board292891829, 
"6.........5.\n"
".542....4..3\n"
".....4636...\n"
"216.4.46..1.\n"
"...12..6...5\n"
".3264.3....5\n"
".253.6.54.44\n"
"5..5.4215423\n"
"...33..3.3..\n"
".32.125.1..6\n"
"444.552.1.6.\n"
"41..6..5.1..\n"
"25...54..54.\n"
"5631.5.333.3\n"
"24....66..52\n"
"4..3......6.\n") == 0);
free(board292891829);
board292891829 = NULL;
assert( gamma_move(board, 5, 1, 8) == 1 );
assert( gamma_busy_fields(board, 5) == 20 );
assert( gamma_move(board, 6, 15, 6) == 0 );
assert( gamma_free_fields(board, 6) == 98 );
assert( gamma_move(board, 1, 14, 7) == 0 );
assert( gamma_move(board, 1, 11, 5) == 1 );


char* board448040104 = gamma_board(board);
assert( board448040104 != NULL );
assert( strcmp(board448040104, 
"6.........5.\n"
".542....4..3\n"
".....4636...\n"
"216.4.46..1.\n"
"...12..6...5\n"
".3264.3....5\n"
".253.6.54.44\n"
"55.5.4215423\n"
"...33..3.3..\n"
".32.125.1..6\n"
"444.552.1.61\n"
"41..6..5.1..\n"
"25...54..54.\n"
"5631.5.333.3\n"
"24....66..52\n"
"4..3......6.\n") == 0);
free(board448040104);
board448040104 = NULL;
assert( gamma_move(board, 2, 9, 4) == 0 );
assert( gamma_move(board, 2, 3, 13) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 4) == 0 );
assert( gamma_busy_fields(board, 4) == 19 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 1, 10, 10) == 1 );


char* board607875964 = gamma_board(board);
assert( board607875964 != NULL );
assert( strcmp(board607875964, 
"6.........5.\n"
".542....4..3\n"
"...2.4636...\n"
"216.4.46..1.\n"
"...12..6...5\n"
".3264.3...15\n"
".253.6.54.44\n"
"55.5.4215423\n"
"...33..3.3..\n"
".32.125.1..6\n"
"444.552.1.61\n"
"41..6..5.1..\n"
"25...54..54.\n"
"5631.5.333.3\n"
"24....66..52\n"
"4..3......6.\n") == 0);
free(board607875964);
board607875964 = NULL;
assert( gamma_move(board, 2, 4, 14) == 1 );
assert( gamma_move(board, 2, 3, 10) == 0 );
assert( gamma_move(board, 3, 9, 1) == 1 );
assert( gamma_free_fields(board, 3) == 93 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_free_fields(board, 4) == 93 );
assert( gamma_move(board, 5, 2, 4) == 1 );
assert( gamma_free_fields(board, 5) == 92 );
assert( gamma_move(board, 6, 7, 12) == 0 );
assert( gamma_move(board, 1, 0, 4) == 0 );
assert( gamma_move(board, 2, 8, 7) == 1 );
assert( gamma_move(board, 3, 9, 10) == 1 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_move(board, 4, 4, 3) == 1 );
assert( gamma_free_fields(board, 4) == 89 );
assert( gamma_move(board, 5, 13, 1) == 0 );
assert( gamma_move(board, 5, 7, 15) == 1 );
assert( gamma_move(board, 6, 0, 6) == 1 );
assert( gamma_move(board, 6, 5, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 16 );
assert( gamma_golden_move(board, 6, 5, 8) == 1 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 2, 6, 9) == 1 );
assert( gamma_move(board, 2, 11, 15) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 4, 12, 3) == 0 );
assert( gamma_move(board, 4, 4, 1) == 1 );
assert( gamma_move(board, 5, 6, 0) == 1 );
assert( gamma_move(board, 6, 12, 11) == 0 );
assert( gamma_free_fields(board, 6) == 82 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 4) == 1 );
assert( gamma_move(board, 2, 2, 9) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_free_fields(board, 4) == 81 );


char* board396482853 = gamma_board(board);
assert( board396482853 != NULL );
assert( strcmp(board396482853, 
"6......5..52\n"
".5422...4..3\n"
".3.2.4636...\n"
"216.4.46..1.\n"
"...12..6...5\n"
".3264.3..315\n"
".253.6254.44\n"
"55.5.6215423\n"
"...33..323..\n"
"632.125.1..6\n"
"444.552.1.61\n"
"415.6..5.12.\n"
"25..454..54.\n"
"5631.5.333.3\n"
"24..4.66.352\n"
"4..3..5...6.\n") == 0);
free(board396482853);
board396482853 = NULL;
assert( gamma_move(board, 5, 15, 5) == 0 );
assert( gamma_move(board, 1, 4, 11) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_move(board, 5, 0, 1) == 0 );
assert( gamma_move(board, 6, 7, 1) == 0 );
assert( gamma_move(board, 6, 7, 8) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 1, 3, 5) == 1 );
assert( gamma_move(board, 2, 11, 5) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 3, 10, 4) == 0 );
assert( gamma_free_fields(board, 3) == 80 );
assert( gamma_move(board, 4, 4, 8) == 1 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 1, 7) == 1 );
assert( gamma_move(board, 1, 11, 10) == 0 );
assert( gamma_move(board, 1, 5, 1) == 1 );
assert( gamma_free_fields(board, 1) == 77 );
assert( gamma_move(board, 2, 0, 6) == 0 );
assert( gamma_move(board, 3, 2, 7) == 1 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 4, 5, 9) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 1, 7, 10) == 1 );
assert( gamma_free_fields(board, 1) == 74 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 10) == 0 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 3, 5, 5) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 6, 7) == 1 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 5, 11, 6) == 0 );
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_move(board, 1, 8, 9) == 0 );
assert( gamma_move(board, 1, 10, 11) == 1 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 11) == 0 );
assert( gamma_free_fields(board, 2) == 72 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 2, 0) == 1 );
assert( gamma_free_fields(board, 3) == 71 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 5, 3, 2) == 0 );
assert( gamma_move(board, 6, 10, 0) == 0 );
assert( gamma_move(board, 1, 13, 2) == 0 );
assert( gamma_move(board, 1, 2, 0) == 0 );
assert( gamma_move(board, 2, 10, 7) == 1 );
assert( gamma_move(board, 2, 6, 6) == 0 );
assert( gamma_move(board, 3, 14, 7) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_free_fields(board, 3) == 70 );
assert( gamma_move(board, 4, 15, 9) == 0 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 6, 15, 9) == 0 );
assert( gamma_move(board, 6, 6, 12) == 0 );
assert( gamma_free_fields(board, 6) == 70 );
assert( gamma_move(board, 2, 2, 6) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_move(board, 3, 3, 7) == 0 );
assert( gamma_move(board, 3, 0, 4) == 0 );
assert( gamma_move(board, 4, 1, 13) == 0 );
assert( gamma_free_fields(board, 4) == 70 );
assert( gamma_move(board, 5, 0, 11) == 0 );
assert( gamma_free_fields(board, 5) == 70 );
assert( gamma_move(board, 6, 15, 4) == 0 );
assert( gamma_free_fields(board, 6) == 70 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 2, 9, 2) == 0 );
assert( gamma_free_fields(board, 2) == 70 );
assert( gamma_busy_fields(board, 3) == 23 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_move(board, 6, 15, 3) == 0 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_move(board, 1, 9, 9) == 1 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_free_fields(board, 1) == 69 );
assert( gamma_move(board, 2, 3, 2) == 0 );
assert( gamma_move(board, 2, 3, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 9, 3) == 0 );


char* board918242980 = gamma_board(board);
assert( board918242980 != NULL );
assert( strcmp(board918242980, 
"6......5..52\n"
".5422...4..3\n"
".3.2.4636...\n"
"216.4.46..1.\n"
"3..12..6..15\n"
".3264.31.315\n"
".253.6254144\n"
"55.546215423\n"
".6333.43232.\n"
"632.125.1..6\n"
"4441552.1.61\n"
"415.6..5.12.\n"
"25..454..54.\n"
"5631.5.333.3\n"
"24.24166.352\n"
"4.33..5...6.\n") == 0);
free(board918242980);
board918242980 = NULL;
assert( gamma_move(board, 4, 3, 11) == 0 );
assert( gamma_move(board, 5, 11, 2) == 0 );
assert( gamma_move(board, 6, 4, 11) == 0 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 1, 8) == 0 );
assert( gamma_move(board, 2, 11, 8) == 0 );
assert( gamma_move(board, 3, 13, 11) == 0 );
assert( gamma_move(board, 4, 9, 0) == 1 );
assert( gamma_busy_fields(board, 4) == 23 );
assert( gamma_move(board, 5, 2, 8) == 1 );
assert( gamma_move(board, 5, 6, 2) == 1 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_move(board, 1, 11, 12) == 1 );
assert( gamma_golden_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 10, 3) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 4, 7, 13) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_free_fields(board, 5) == 64 );
assert( gamma_move(board, 1, 2, 4) == 0 );


char* board239410076 = gamma_board(board);
assert( board239410076 != NULL );
assert( strcmp(board239410076, 
"6......5..52\n"
".5422...4..3\n"
".3.2.4636...\n"
"216.4.46..11\n"
"3..12..6..15\n"
".3264.31.315\n"
".253.6254144\n"
"555546215423\n"
".6333.43232.\n"
"632.125.1..6\n"
"4441552.1.61\n"
"415.6..5.12.\n"
"25..454..54.\n"
"5631.55333.3\n"
"24.24166.352\n"
"4.33..5..46.\n") == 0);
free(board239410076);
board239410076 = NULL;
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 4, 4, 8) == 0 );
assert( gamma_move(board, 5, 2, 0) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 4, 7, 9) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 0, 4) == 0 );
assert( gamma_move(board, 6, 4, 6) == 0 );
assert( gamma_move(board, 6, 4, 4) == 0 );
assert( gamma_golden_move(board, 6, 9, 9) == 0 );
assert( gamma_move(board, 1, 4, 13) == 1 );
assert( gamma_move(board, 1, 5, 4) == 1 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 1, 8) == 0 );
assert( gamma_move(board, 6, 11, 5) == 0 );
assert( gamma_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 1, 15, 9) == 0 );
assert( gamma_move(board, 1, 8, 15) == 1 );
assert( gamma_move(board, 2, 4, 0) == 1 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 9, 11) == 1 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 2, 11) == 1 );
assert( gamma_free_fields(board, 4) == 22 );
assert( gamma_move(board, 6, 3, 11) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 1, 3, 5) == 0 );
assert( gamma_move(board, 2, 6, 3) == 0 );
assert( gamma_move(board, 2, 4, 9) == 1 );
assert( gamma_move(board, 3, 14, 6) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 0, 9) == 0 );


char* board316235249 = gamma_board(board);
assert( board316235249 != NULL );
assert( strcmp(board316235249, 
"6......51.52\n"
".5422...4..3\n"
".3.214636...\n"
"216.4.46..11\n"
"3.412..6.315\n"
".3264.31.315\n"
".25326254144\n"
"555546215423\n"
".6333.43232.\n"
"632.125.1..6\n"
"4441552.1.61\n"
"415.61.5.12.\n"
"25..454..54.\n"
"5631.55333.3\n"
"24.24166.352\n"
"4.332.5..46.\n") == 0);
free(board316235249);
board316235249 = NULL;
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_move(board, 6, 11, 14) == 0 );
assert( gamma_move(board, 1, 7, 0) == 1 );
assert( gamma_move(board, 2, 10, 5) == 0 );
assert( gamma_move(board, 2, 10, 8) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_busy_fields(board, 3) == 24 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 5, 13, 2) == 0 );
assert( gamma_move(board, 5, 10, 3) == 0 );
assert( gamma_move(board, 6, 14, 10) == 0 );
assert( gamma_move(board, 1, 12, 8) == 0 );
assert( gamma_move(board, 1, 2, 15) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 5, 12, 9) == 0 );
assert( gamma_free_fields(board, 5) == 55 );
assert( gamma_move(board, 6, 6, 10) == 0 );
assert( gamma_move(board, 6, 7, 14) == 1 );
assert( gamma_move(board, 1, 4, 3) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 13, 10) == 0 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 6, 3, 8) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 7, 12) == 0 );
assert( gamma_move(board, 2, 11, 7) == 1 );
assert( gamma_move(board, 3, 12, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_golden_move(board, 3, 15, 0) == 0 );
assert( gamma_move(board, 4, 3, 8) == 0 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 5, 9, 0) == 0 );
assert( gamma_move(board, 6, 13, 10) == 0 );
assert( gamma_move(board, 6, 9, 9) == 0 );
assert( gamma_free_fields(board, 6) == 53 );
assert( gamma_move(board, 1, 11, 15) == 0 );
assert( gamma_move(board, 1, 7, 14) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 11, 15) == 0 );
assert( gamma_move(board, 2, 9, 13) == 1 );
assert( gamma_move(board, 3, 12, 8) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 4, 6, 7) == 0 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 6, 0, 7) == 1 );
assert( gamma_move(board, 6, 0, 4) == 0 );
assert( gamma_move(board, 1, 1, 2) == 0 );
assert( gamma_move(board, 1, 6, 12) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 2, 1, 1) == 0 );
assert( gamma_move(board, 3, 0, 8) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 4, 5, 7) == 1 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_free_fields(board, 5) == 50 );
assert( gamma_move(board, 6, 11, 8) == 0 );
assert( gamma_move(board, 6, 5, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 2, 13, 10) == 0 );
assert( gamma_move(board, 2, 6, 4) == 1 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 11, 8) == 0 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 3, 15) == 1 );
assert( gamma_move(board, 6, 3, 4) == 1 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_free_fields(board, 1) == 19 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );


char* board279198984 = gamma_board(board);
assert( board279198984 != NULL );
assert( strcmp(board279198984, 
"6.15...51.52\n"
"35422..64..3\n"
".3.2146362..\n"
"216.4.46..11\n"
"3.412..6.315\n"
".3264.31.315\n"
".25326254144\n"
"555546215423\n"
"663334432322\n"
"632.125.1..6\n"
"4441552.1.61\n"
"41566125.12.\n"
"251.454..54.\n"
"5631.55333.3\n"
"24.24166.352\n"
"4.332.51.46.\n") == 0);
free(board279198984);
board279198984 = NULL;
assert( gamma_move(board, 4, 12, 9) == 0 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_move(board, 5, 6, 2) == 0 );
assert( gamma_move(board, 6, 10, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 15, 6) == 0 );
assert( gamma_golden_move(board, 2, 5, 10) == 0 );
assert( gamma_move(board, 3, 15, 1) == 0 );
assert( gamma_free_fields(board, 3) == 45 );
assert( gamma_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 5, 11, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 12, 5) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 1, 3, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 2, 8) == 0 );
assert( gamma_move(board, 2, 1, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_move(board, 5, 9, 6) == 1 );
assert( gamma_move(board, 6, 3, 13) == 0 );
assert( gamma_move(board, 6, 9, 1) == 0 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 1, 3, 7) == 0 );
assert( gamma_move(board, 2, 11, 1) == 0 );
assert( gamma_move(board, 3, 2, 10) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 10, 0) == 0 );


char* board892150210 = gamma_board(board);
assert( board892150210 != NULL );
assert( strcmp(board892150210, 
"6.15...51.52\n"
"35422..64..3\n"
".3.2146362..\n"
"216.4.46..11\n"
"3.412..6.315\n"
".3264.31.315\n"
".25326254144\n"
"555546215423\n"
"663334432322\n"
"632.125.15.6\n"
"4441552.1.61\n"
"41566125.12.\n"
"2511454..54.\n"
"5631.55333.3\n"
"24.24166.352\n"
"4.332.51.46.\n") == 0);
free(board892150210);
board892150210 = NULL;
assert( gamma_move(board, 5, 11, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 27 );
assert( gamma_free_fields(board, 5) == 43 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 3, 8) == 0 );
assert( gamma_free_fields(board, 6) == 43 );
assert( gamma_move(board, 1, 0, 11) == 0 );
assert( gamma_move(board, 2, 3, 8) == 0 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_move(board, 3, 6, 4) == 0 );
assert( gamma_move(board, 4, 2, 13) == 1 );
assert( gamma_move(board, 5, 12, 3) == 0 );
assert( gamma_move(board, 5, 4, 15) == 1 );
assert( gamma_move(board, 6, 1, 8) == 0 );
assert( gamma_free_fields(board, 6) == 41 );
assert( gamma_move(board, 1, 11, 1) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 11, 4) == 1 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 4, 10, 11) == 0 );
assert( gamma_move(board, 5, 6, 14) == 1 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 4, 8) == 0 );
assert( gamma_move(board, 1, 2, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 25 );
assert( gamma_move(board, 2, 14, 10) == 0 );
assert( gamma_move(board, 2, 7, 5) == 1 );
assert( gamma_move(board, 3, 11, 1) == 0 );
assert( gamma_move(board, 3, 11, 6) == 0 );
assert( gamma_move(board, 5, 4, 8) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_move(board, 6, 3, 12) == 1 );
assert( gamma_free_fields(board, 6) == 37 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 1, 9, 14) == 1 );
assert( gamma_move(board, 2, 15, 1) == 0 );
assert( gamma_move(board, 2, 1, 4) == 0 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_move(board, 3, 11, 14) == 0 );
assert( gamma_move(board, 4, 6, 6) == 0 );
assert( gamma_move(board, 4, 2, 4) == 0 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 6, 0, 11) == 0 );
assert( gamma_move(board, 6, 4, 3) == 0 );
assert( gamma_free_fields(board, 6) == 36 );
assert( gamma_move(board, 1, 1, 11) == 1 );
assert( gamma_move(board, 2, 2, 1) == 1 );
assert( gamma_move(board, 2, 8, 14) == 0 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 5, 10, 15) == 0 );
assert( gamma_move(board, 6, 5, 12) == 1 );
assert( gamma_move(board, 1, 1, 8) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_move(board, 2, 5, 6) == 0 );
assert( gamma_move(board, 3, 11, 8) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 4, 6, 3) == 0 );
assert( gamma_move(board, 5, 0, 5) == 0 );
assert( gamma_move(board, 6, 12, 9) == 0 );
assert( gamma_move(board, 1, 4, 9) == 0 );
assert( gamma_move(board, 1, 2, 9) == 0 );
assert( gamma_move(board, 2, 5, 9) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 8, 5) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_move(board, 5, 3, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 29 );
assert( gamma_free_fields(board, 5) == 16 );
assert( gamma_move(board, 6, 1, 5) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 1, 12, 9) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_free_fields(board, 2) == 11 );


char* board323598609 = gamma_board(board);
assert( board323598609 != NULL );
assert( strcmp(board323598609, 
"6.155..51.52\n"
"35422.5641.3\n"
".342146362..\n"
"21664646..11\n"
"31412..6.315\n"
".3264.31.315\n"
".25326254144\n"
"555546215423\n"
"663334432322\n"
"632.125.15.6\n"
"444155221.61\n"
"41566125.123\n"
"2511454..54.\n"
"5631.55333.3\n"
"24224166.352\n"
"4.332.51.46.\n") == 0);
free(board323598609);
board323598609 = NULL;
assert( gamma_move(board, 3, 10, 6) == 1 );
assert( gamma_move(board, 3, 1, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_move(board, 4, 6, 9) == 0 );
assert( gamma_move(board, 5, 15, 6) == 0 );
assert( gamma_move(board, 6, 2, 4) == 0 );
assert( gamma_move(board, 6, 6, 2) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_move(board, 2, 13, 11) == 0 );
assert( gamma_move(board, 2, 6, 14) == 0 );
assert( gamma_move(board, 3, 10, 0) == 0 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 4, 15, 6) == 0 );
assert( gamma_move(board, 4, 7, 10) == 0 );
assert( gamma_move(board, 5, 10, 5) == 0 );
assert( gamma_move(board, 5, 2, 5) == 0 );
assert( gamma_move(board, 6, 4, 13) == 0 );


char* board252644883 = gamma_board(board);
assert( board252644883 != NULL );
assert( strcmp(board252644883, 
"6.155..51.52\n"
"35422.5641.3\n"
".342146362..\n"
"21664646..11\n"
"31412..6.315\n"
".3264.31.315\n"
".25326254144\n"
"555546215423\n"
"663334432322\n"
"632.125.1536\n"
"444155221.61\n"
"41566125.123\n"
"2511454..54.\n"
"5631.55333.3\n"
"24224166.352\n"
"4.332.51.46.\n") == 0);
free(board252644883);
board252644883 = NULL;
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 1, 0, 3) == 0 );
assert( gamma_move(board, 2, 4, 8) == 0 );
assert( gamma_move(board, 3, 15, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 27 );
assert( gamma_move(board, 4, 13, 11) == 0 );
assert( gamma_move(board, 4, 9, 9) == 0 );
assert( gamma_move(board, 5, 2, 4) == 0 );
assert( gamma_move(board, 5, 5, 4) == 0 );
assert( gamma_golden_move(board, 5, 1, 8) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 2, 0, 2) == 0 );
assert( gamma_move(board, 2, 0, 11) == 0 );
assert( gamma_move(board, 3, 3, 8) == 0 );
assert( gamma_move(board, 3, 9, 1) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 7) == 0 );
assert( gamma_move(board, 5, 8, 8) == 0 );
assert( gamma_move(board, 5, 7, 15) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 5, 12) == 0 );
assert( gamma_move(board, 6, 11, 9) == 0 );
assert( gamma_move(board, 1, 8, 4) == 1 );
assert( gamma_golden_move(board, 1, 2, 0) == 1 );
assert( gamma_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 2, 10, 7) == 0 );
assert( gamma_move(board, 4, 9, 4) == 0 );
assert( gamma_move(board, 4, 10, 7) == 0 );
assert( gamma_free_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 9, 6) == 0 );
assert( gamma_busy_fields(board, 5) == 29 );
assert( gamma_move(board, 6, 12, 8) == 0 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 2, 5, 3) == 0 );
assert( gamma_move(board, 3, 15, 9) == 0 );
assert( gamma_move(board, 3, 8, 8) == 0 );
assert( gamma_move(board, 4, 0, 5) == 0 );
assert( gamma_move(board, 4, 11, 6) == 0 );
assert( gamma_move(board, 5, 11, 13) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 6, 11, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 0 );
assert( gamma_move(board, 1, 11, 5) == 0 );
assert( gamma_move(board, 2, 7, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 28 );
assert( gamma_move(board, 3, 13, 0) == 0 );
assert( gamma_move(board, 3, 9, 9) == 0 );
assert( gamma_busy_fields(board, 3) == 26 );
assert( gamma_free_fields(board, 3) == 16 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 4, 0) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_golden_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 6, 9, 8) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_golden_possible(board, 6) == 0 );


gamma_delete(board);

    return 0;
}
