#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 147838771
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(16, 15, 6, 45);
assert( board != NULL );


assert( gamma_move(board, 1, 5, 6) == 1 );
assert( gamma_move(board, 2, 8, 14) == 1 );
assert( gamma_move(board, 3, 14, 13) == 1 );
assert( gamma_free_fields(board, 3) == 237 );
assert( gamma_move(board, 4, 2, 7) == 1 );
assert( gamma_move(board, 5, 8, 14) == 0 );
assert( gamma_move(board, 6, 11, 14) == 1 );
assert( gamma_move(board, 6, 1, 3) == 1 );
assert( gamma_move(board, 1, 2, 6) == 1 );
assert( gamma_move(board, 2, 5, 12) == 1 );
assert( gamma_move(board, 2, 7, 0) == 1 );
assert( gamma_move(board, 3, 6, 10) == 1 );
assert( gamma_move(board, 3, 3, 14) == 1 );
assert( gamma_move(board, 4, 6, 8) == 1 );
assert( gamma_move(board, 4, 13, 7) == 1 );
assert( gamma_move(board, 5, 3, 11) == 1 );
assert( gamma_move(board, 5, 8, 0) == 1 );


char* board740687852 = gamma_board(board);
assert( board740687852 != NULL );
assert( strcmp(board740687852, 
"...3....2..6....\n"
"..............3.\n"
".....2..........\n"
"...5............\n"
"......3.........\n"
"................\n"
"......4.........\n"
"..4..........4..\n"
"..1..1..........\n"
"................\n"
"................\n"
".6..............\n"
"................\n"
"................\n"
".......25.......\n") == 0);
free(board740687852);
board740687852 = NULL;
assert( gamma_move(board, 6, 4, 15) == 0 );
assert( gamma_move(board, 1, 3, 12) == 1 );
assert( gamma_move(board, 1, 5, 2) == 1 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 3, 9, 5) == 1 );
assert( gamma_busy_fields(board, 3) == 4 );
assert( gamma_golden_move(board, 3, 3, 1) == 0 );
assert( gamma_move(board, 4, 2, 1) == 1 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_free_fields(board, 5) == 221 );
assert( gamma_move(board, 6, 4, 12) == 1 );
assert( gamma_move(board, 1, 8, 12) == 1 );
assert( gamma_move(board, 1, 0, 1) == 1 );
assert( gamma_golden_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 4, 11) == 1 );
assert( gamma_move(board, 3, 0, 0) == 1 );
assert( gamma_move(board, 4, 13, 4) == 1 );
assert( gamma_busy_fields(board, 4) == 5 );
assert( gamma_move(board, 5, 3, 7) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 0) == 1 );
assert( gamma_move(board, 6, 3, 13) == 1 );
assert( gamma_move(board, 1, 6, 7) == 1 );
assert( gamma_move(board, 1, 8, 13) == 1 );
assert( gamma_move(board, 2, 8, 14) == 0 );


char* board487996790 = gamma_board(board);
assert( board487996790 != NULL );
assert( strcmp(board487996790, 
"...3....2..6....\n"
"...6....1.....3.\n"
"...162..1.......\n"
"...53...........\n"
"......3.........\n"
"................\n"
"......4.........\n"
"..45..1......4..\n"
"..1..1..........\n"
".........3......\n"
".............4..\n"
".6..............\n"
".....1..........\n"
"1.4.............\n"
"3...6..25.......\n") == 0);
free(board487996790);
board487996790 = NULL;
assert( gamma_move(board, 3, 8, 1) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 4, 0, 8) == 1 );
assert( gamma_move(board, 5, 9, 9) == 1 );
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_free_fields(board, 5) == 207 );
assert( gamma_move(board, 6, 0, 7) == 1 );
assert( gamma_move(board, 1, 5, 13) == 1 );
assert( gamma_move(board, 1, 9, 4) == 1 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_move(board, 3, 12, 1) == 1 );
assert( gamma_move(board, 5, 8, 9) == 1 );
assert( gamma_move(board, 5, 4, 7) == 1 );
assert( gamma_move(board, 6, 5, 4) == 1 );
assert( gamma_move(board, 6, 4, 4) == 1 );
assert( gamma_move(board, 1, 11, 0) == 1 );
assert( gamma_move(board, 2, 5, 12) == 0 );
assert( gamma_move(board, 2, 11, 11) == 1 );
assert( gamma_golden_move(board, 2, 1, 12) == 0 );
assert( gamma_move(board, 3, 7, 11) == 1 );
assert( gamma_move(board, 3, 5, 14) == 1 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_golden_move(board, 4, 1, 8) == 0 );
assert( gamma_move(board, 5, 0, 6) == 1 );
assert( gamma_move(board, 5, 4, 9) == 1 );
assert( gamma_free_fields(board, 5) == 193 );
assert( gamma_move(board, 6, 5, 12) == 0 );
assert( gamma_golden_move(board, 6, 13, 8) == 0 );
assert( gamma_move(board, 1, 14, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 12 );
assert( gamma_move(board, 3, 1, 6) == 1 );
assert( gamma_move(board, 4, 0, 8) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 10) == 1 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 1, 11, 14) == 0 );


char* board430721840 = gamma_board(board);
assert( board430721840 != NULL );
assert( strcmp(board430721840, 
"...3.3..2..6....\n"
"...6.1..1.....3.\n"
"...162..1.....1.\n"
"...53..3...2....\n"
"..5...3.........\n"
"....5...55......\n"
"4.....4.........\n"
"6.455.1......4..\n"
"531..1..........\n"
".........3......\n"
"....66...1...4..\n"
".6..............\n"
".....1..........\n"
"1.4.....3...3...\n"
"3...6..25..1....\n") == 0);
free(board430721840);
board430721840 = NULL;
assert( gamma_move(board, 2, 8, 3) == 1 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_busy_fields(board, 2) == 6 );
assert( gamma_move(board, 3, 3, 3) == 1 );
assert( gamma_move(board, 3, 0, 14) == 1 );
assert( gamma_move(board, 4, 11, 14) == 0 );
assert( gamma_move(board, 5, 5, 11) == 1 );
assert( gamma_move(board, 5, 2, 2) == 1 );
assert( gamma_move(board, 6, 10, 4) == 1 );
assert( gamma_move(board, 6, 2, 14) == 1 );
assert( gamma_move(board, 1, 1, 2) == 1 );
assert( gamma_move(board, 1, 2, 5) == 1 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 5, 12) == 0 );
assert( gamma_move(board, 3, 8, 3) == 0 );
assert( gamma_move(board, 4, 6, 0) == 1 );
assert( gamma_move(board, 5, 7, 10) == 1 );
assert( gamma_move(board, 5, 0, 0) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_busy_fields(board, 1) == 14 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 5, 6, 10) == 0 );
assert( gamma_move(board, 6, 10, 4) == 0 );
assert( gamma_move(board, 6, 0, 12) == 1 );
assert( gamma_busy_fields(board, 6) == 11 );
assert( gamma_move(board, 1, 4, 1) == 1 );
assert( gamma_move(board, 1, 3, 13) == 0 );
assert( gamma_move(board, 2, 15, 8) == 1 );
assert( gamma_move(board, 2, 15, 6) == 1 );
assert( gamma_free_fields(board, 2) == 171 );
assert( gamma_move(board, 3, 6, 9) == 1 );
assert( gamma_move(board, 3, 0, 3) == 1 );
assert( gamma_move(board, 4, 12, 10) == 1 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 9, 11) == 1 );
assert( gamma_move(board, 5, 13, 11) == 1 );
assert( gamma_move(board, 6, 1, 1) == 1 );
assert( gamma_move(board, 1, 7, 8) == 1 );
assert( gamma_move(board, 2, 0, 2) == 1 );
assert( gamma_move(board, 3, 8, 13) == 0 );


char* board631106836 = gamma_board(board);
assert( board631106836 != NULL );
assert( strcmp(board631106836, 
"3.63.3..2..6....\n"
"...6.1..1.....3.\n"
"6..162..1.....1.\n"
"...535.3.5.2.5..\n"
"..5...35....4...\n"
"..4.5.3.55......\n"
"4.....41.......2\n"
"6.455.1......4..\n"
"531..1.........2\n"
".21....3.3......\n"
"....66...16..4..\n"
"36.3....2.......\n"
"215..1..........\n"
"164.1..23...3...\n"
"3...6.425..1....\n") == 0);
free(board631106836);
board631106836 = NULL;
assert( gamma_move(board, 4, 13, 15) == 0 );
assert( gamma_move(board, 4, 5, 0) == 1 );
assert( gamma_move(board, 5, 0, 8) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 1, 12, 1) == 0 );
assert( gamma_free_fields(board, 1) == 162 );
assert( gamma_move(board, 3, 3, 5) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 5, 5, 5) == 1 );
assert( gamma_move(board, 6, 5, 11) == 0 );
assert( gamma_move(board, 1, 5, 11) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 0, 12) == 0 );
assert( gamma_move(board, 2, 13, 6) == 1 );
assert( gamma_move(board, 3, 1, 13) == 1 );
assert( gamma_move(board, 3, 2, 12) == 1 );
assert( gamma_move(board, 4, 8, 11) == 1 );
assert( gamma_move(board, 4, 14, 0) == 1 );
assert( gamma_move(board, 6, 9, 7) == 1 );
assert( gamma_move(board, 6, 6, 12) == 1 );
assert( gamma_move(board, 2, 5, 10) == 1 );
assert( gamma_move(board, 3, 12, 13) == 1 );
assert( gamma_move(board, 3, 14, 11) == 1 );
assert( gamma_move(board, 5, 3, 9) == 1 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_move(board, 1, 4, 1) == 0 );
assert( gamma_move(board, 2, 10, 8) == 1 );
assert( gamma_move(board, 2, 10, 7) == 1 );
assert( gamma_move(board, 3, 2, 8) == 1 );
assert( gamma_move(board, 4, 12, 9) == 1 );
assert( gamma_move(board, 5, 11, 0) == 0 );


char* board646315267 = gamma_board(board);
assert( board646315267 != NULL );
assert( strcmp(board646315267, 
"3.63.3..2..6....\n"
".3.6.1..1...3.3.\n"
"6.31626.1.....1.\n"
"...535.345.2.53.\n"
"..5..235....4...\n"
"..455.3.55..4...\n"
"4.3...41..2....2\n"
"6.455.1..62..4..\n"
"531..1.......2.2\n"
".213.5.3.3......\n"
"....66...16..4..\n"
"36.3....2.......\n"
"215..1..........\n"
"164.1..23...3...\n"
"3...64425..1..4.\n") == 0);
free(board646315267);
board646315267 = NULL;
assert( gamma_move(board, 6, 5, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 14 );
assert( gamma_move(board, 1, 0, 13) == 1 );
assert( gamma_move(board, 1, 11, 13) == 1 );
assert( gamma_free_fields(board, 1) == 143 );
assert( gamma_move(board, 2, 10, 13) == 1 );
assert( gamma_move(board, 2, 11, 10) == 1 );
assert( gamma_move(board, 3, 0, 5) == 1 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 4, 12, 5) == 1 );
assert( gamma_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_move(board, 6, 8, 10) == 1 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 1, 2, 3) == 1 );
assert( gamma_move(board, 2, 3, 14) == 0 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 4, 12, 7) == 1 );
assert( gamma_move(board, 5, 10, 3) == 1 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 17 );
assert( gamma_move(board, 6, 12, 9) == 0 );
assert( gamma_move(board, 6, 6, 5) == 1 );
assert( gamma_move(board, 1, 5, 13) == 0 );
assert( gamma_move(board, 2, 9, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 16 );
assert( gamma_move(board, 3, 6, 11) == 1 );
assert( gamma_move(board, 3, 7, 5) == 0 );


char* board135364700 = gamma_board(board);
assert( board135364700 != NULL );
assert( strcmp(board135364700, 
"3.63.3..2..6....\n"
"13.6.1..1.213.3.\n"
"6.31626.1.....1.\n"
"...5353345.2.53.\n"
"..5..2356..24...\n"
"..455.3.55..4...\n"
"4.3...41..2....2\n"
"6.455.1..62.44..\n"
"531..1.......2.2\n"
"3213.563.3..4...\n"
"....66...16..4..\n"
"3613....2.5.....\n"
"215..1..........\n"
"164.1..23...3...\n"
"3...64425..1..4.\n") == 0);
free(board135364700);
board135364700 = NULL;
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 5, 0, 6) == 0 );
assert( gamma_move(board, 6, 12, 10) == 0 );
assert( gamma_move(board, 1, 1, 4) == 1 );
assert( gamma_move(board, 1, 6, 10) == 0 );
assert( gamma_move(board, 2, 3, 12) == 0 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_move(board, 3, 5, 11) == 0 );
assert( gamma_move(board, 3, 3, 4) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 8, 11) == 0 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 6, 5, 11) == 0 );
assert( gamma_move(board, 6, 9, 6) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 1, 4, 5) == 0 );
assert( gamma_move(board, 2, 5, 8) == 1 );
assert( gamma_golden_move(board, 2, 12, 2) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 4, 6) == 1 );
assert( gamma_move(board, 4, 13, 9) == 1 );
assert( gamma_move(board, 5, 6, 4) == 1 );
assert( gamma_move(board, 5, 8, 8) == 1 );
assert( gamma_move(board, 1, 1, 13) == 0 );
assert( gamma_move(board, 2, 7, 15) == 0 );
assert( gamma_move(board, 3, 0, 11) == 1 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_move(board, 4, 2, 14) == 0 );
assert( gamma_golden_move(board, 4, 12, 8) == 0 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 5, 8, 2) == 1 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 6, 1, 11) == 1 );
assert( gamma_move(board, 1, 6, 3) == 1 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_move(board, 2, 15, 10) == 1 );
assert( gamma_move(board, 2, 15, 4) == 1 );
assert( gamma_move(board, 3, 4, 2) == 1 );
assert( gamma_move(board, 4, 0, 2) == 0 );
assert( gamma_move(board, 5, 14, 10) == 1 );
assert( gamma_free_fields(board, 5) == 117 );
assert( gamma_move(board, 6, 9, 2) == 1 );
assert( gamma_move(board, 6, 4, 3) == 1 );
assert( gamma_busy_fields(board, 6) == 20 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 9, 2) == 0 );
assert( gamma_move(board, 4, 8, 9) == 0 );
assert( gamma_move(board, 5, 6, 9) == 0 );
assert( gamma_move(board, 5, 11, 0) == 0 );
assert( gamma_move(board, 6, 8, 14) == 0 );


char* board849557923 = gamma_board(board);
assert( board849557923 != NULL );
assert( strcmp(board849557923, 
"3.63.3..2..6....\n"
"13.6.1..1.213.3.\n"
"6.31626.1.....1.\n"
"36.5353345.2.53.\n"
"..5..2356..24.52\n"
"..455.3.55..44..\n"
"4.3..2415.2....2\n"
"6.455.1..62.44..\n"
"531.31...6...2.2\n"
"3213.563.3..4...\n"
".1.3665..16..4.2\n"
"36136.1.2.5.....\n"
"215.31..56......\n"
"164.1..23...3...\n"
"3...64425..1..4.\n") == 0);
free(board849557923);
board849557923 = NULL;
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_move(board, 1, 7, 3) == 1 );
assert( gamma_move(board, 2, 2, 12) == 0 );
assert( gamma_free_fields(board, 2) == 114 );
assert( gamma_move(board, 3, 6, 6) == 1 );
assert( gamma_move(board, 3, 10, 9) == 1 );
assert( gamma_move(board, 4, 8, 13) == 0 );
assert( gamma_move(board, 5, 12, 1) == 0 );
assert( gamma_move(board, 5, 15, 4) == 0 );
assert( gamma_move(board, 6, 6, 7) == 0 );
assert( gamma_move(board, 6, 1, 0) == 1 );
assert( gamma_move(board, 1, 2, 13) == 1 );
assert( gamma_move(board, 1, 5, 3) == 1 );
assert( gamma_busy_fields(board, 1) == 24 );
assert( gamma_move(board, 2, 4, 7) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 6, 3) == 0 );
assert( gamma_move(board, 3, 8, 14) == 0 );
assert( gamma_move(board, 4, 6, 14) == 1 );
assert( gamma_move(board, 4, 8, 8) == 0 );
assert( gamma_move(board, 5, 10, 0) == 1 );
assert( gamma_move(board, 5, 15, 7) == 1 );
assert( gamma_move(board, 6, 1, 6) == 0 );
assert( gamma_move(board, 6, 10, 9) == 0 );
assert( gamma_move(board, 1, 14, 1) == 1 );
assert( gamma_move(board, 2, 13, 4) == 0 );
assert( gamma_busy_fields(board, 2) == 19 );
assert( gamma_move(board, 3, 11, 2) == 1 );
assert( gamma_move(board, 3, 15, 14) == 1 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 6, 12, 12) == 1 );
assert( gamma_move(board, 6, 13, 6) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 11, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 26 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 3, 9, 4) == 0 );
assert( gamma_move(board, 4, 9, 13) == 1 );
assert( gamma_move(board, 5, 1, 6) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_golden_move(board, 5, 14, 8) == 0 );
assert( gamma_move(board, 6, 1, 5) == 0 );
assert( gamma_move(board, 6, 7, 3) == 0 );
assert( gamma_move(board, 1, 11, 12) == 1 );
assert( gamma_move(board, 3, 5, 8) == 0 );
assert( gamma_move(board, 3, 2, 11) == 1 );
assert( gamma_move(board, 4, 15, 13) == 1 );
assert( gamma_move(board, 4, 7, 3) == 0 );
assert( gamma_move(board, 5, 2, 15) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 1, 14, 14) == 1 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 2, 15, 13) == 0 );
assert( gamma_free_fields(board, 2) == 96 );
assert( gamma_move(board, 3, 9, 11) == 0 );
assert( gamma_busy_fields(board, 3) == 33 );


char* board555242597 = gamma_board(board);
assert( board555242597 != NULL );
assert( strcmp(board555242597, 
"3.63.34.2..6..13\n"
"1316.1..14213.34\n"
"6.31626.1..16.1.\n"
"3635353345.2.53.\n"
"..5..2356..24.52\n"
"..455.3.553144..\n"
"4.3..2415.2....2\n"
"6.455.1..62.44.5\n"
"531.313..6...2.2\n"
"3213.563.3..4...\n"
".1.3665..16..4.2\n"
"361361112.5.....\n"
"215.31..56.3....\n"
"164.1..23...3.1.\n"
"36..64425.51..4.\n") == 0);
free(board555242597);
board555242597 = NULL;
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 4, 12) == 0 );
assert( gamma_move(board, 6, 0, 4) == 1 );
assert( gamma_move(board, 1, 1, 9) == 1 );
assert( gamma_move(board, 1, 10, 3) == 0 );
assert( gamma_move(board, 3, 14, 1) == 0 );
assert( gamma_move(board, 3, 8, 7) == 1 );
assert( gamma_move(board, 4, 0, 3) == 0 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 6, 8, 14) == 0 );
assert( gamma_move(board, 1, 10, 5) == 1 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 2, 15, 1) == 1 );
assert( gamma_move(board, 3, 4, 11) == 0 );
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 5, 11, 5) == 1 );
assert( gamma_move(board, 6, 13, 6) == 0 );
assert( gamma_free_fields(board, 6) == 90 );
assert( gamma_golden_move(board, 6, 10, 15) == 0 );
assert( gamma_move(board, 1, 5, 0) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_free_fields(board, 2) == 90 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 7, 14) == 1 );
assert( gamma_move(board, 3, 7, 2) == 1 );
assert( gamma_free_fields(board, 3) == 88 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 1, 3) == 0 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 5, 2, 9) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 5, 14) == 0 );
assert( gamma_golden_move(board, 1, 5, 0) == 1 );
assert( gamma_move(board, 2, 10, 4) == 0 );
assert( gamma_move(board, 2, 5, 1) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 8, 4) == 1 );
assert( gamma_move(board, 3, 15, 11) == 1 );
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 4, 15, 3) == 1 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 5, 4, 14) == 1 );
assert( gamma_move(board, 6, 1, 11) == 0 );
assert( gamma_move(board, 1, 7, 4) == 1 );
assert( gamma_move(board, 2, 13, 13) == 1 );
assert( gamma_move(board, 3, 3, 8) == 1 );
assert( gamma_move(board, 4, 11, 12) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 6, 7, 11) == 0 );
assert( gamma_busy_fields(board, 6) == 23 );


char* board635227261 = gamma_board(board);
assert( board635227261 != NULL );
assert( strcmp(board635227261, 
"3.6353432..6..13\n"
"1316.1..14213234\n"
"6.31626.1..16.1.\n"
"3635353345.2.533\n"
"..5..2356..24.52\n"
".1455.3.553144..\n"
"4.33.2415.2....2\n"
"6.455.1.362.44.5\n"
"531.313..6...2.2\n"
"3213.563.3154...\n"
"61.36651316..4.2\n"
"361361112.5....4\n"
"215.31.35643....\n"
"164.12.23...3.12\n"
"36..61425.51..4.\n") == 0);
free(board635227261);
board635227261 = NULL;
assert( gamma_move(board, 1, 14, 2) == 1 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 4, 6, 11) == 0 );
assert( gamma_busy_fields(board, 4) == 20 );
assert( gamma_move(board, 5, 1, 7) == 1 );
assert( gamma_move(board, 6, 2, 13) == 0 );
assert( gamma_move(board, 6, 6, 9) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 8, 0) == 0 );
assert( gamma_free_fields(board, 3) == 77 );
assert( gamma_move(board, 4, 10, 12) == 1 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 1, 4) == 0 );
assert( gamma_move(board, 6, 14, 10) == 0 );
assert( gamma_move(board, 6, 7, 7) == 1 );
assert( gamma_move(board, 1, 1, 10) == 1 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_free_fields(board, 3) == 74 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 21 );
assert( gamma_move(board, 5, 14, 11) == 0 );
assert( gamma_move(board, 6, 5, 15) == 0 );
assert( gamma_free_fields(board, 6) == 74 );
assert( gamma_move(board, 1, 6, 8) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 2, 13, 9) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 12, 13) == 0 );
assert( gamma_move(board, 4, 9, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 6, 3, 2) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );


char* board691431895 = gamma_board(board);
assert( board691431895 != NULL );
assert( strcmp(board691431895, 
"3.6353432..6..13\n"
"1316.1..14213234\n"
"6.31626.1.416.1.\n"
"3635353345.2.533\n"
".15..2356..24.52\n"
".1455.3.553144..\n"
"4.33.2415.2....2\n"
"65455.16362.44.5\n"
"531.313..6...2.2\n"
"3213.563.3154...\n"
"61.36651316..4.2\n"
"361361112.5....4\n"
"215631.35643..1.\n"
"164.12.23...3.12\n"
"36..61425.51..4.\n") == 0);
free(board691431895);
board691431895 = NULL;
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 3, 9, 12) == 1 );
assert( gamma_busy_fields(board, 3) == 40 );
assert( gamma_free_fields(board, 3) == 72 );
assert( gamma_move(board, 4, 0, 13) == 0 );
assert( gamma_move(board, 4, 3, 2) == 0 );
assert( gamma_free_fields(board, 4) == 72 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 5, 3, 14) == 0 );
assert( gamma_move(board, 6, 5, 14) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 1, 8, 5) == 1 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_free_fields(board, 1) == 71 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 6, 7) == 0 );
assert( gamma_move(board, 3, 10, 11) == 1 );
assert( gamma_move(board, 4, 8, 6) == 1 );
assert( gamma_golden_move(board, 5, 14, 8) == 0 );
assert( gamma_move(board, 6, 13, 7) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 1, 10, 2) == 0 );
assert( gamma_move(board, 2, 4, 11) == 0 );
assert( gamma_busy_fields(board, 2) == 22 );
assert( gamma_move(board, 3, 6, 10) == 0 );
assert( gamma_move(board, 4, 12, 12) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 5, 7, 2) == 0 );
assert( gamma_move(board, 6, 0, 9) == 1 );
assert( gamma_move(board, 6, 5, 5) == 0 );
assert( gamma_free_fields(board, 6) == 68 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 10, 15) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 1, 8, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 35 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 41 );
assert( gamma_move(board, 6, 0, 14) == 0 );


char* board987340057 = gamma_board(board);
assert( board987340057 != NULL );
assert( strcmp(board987340057, 
"3.6353432..6..13\n"
"1316.1..14213234\n"
"6.31626.13416.1.\n"
"363535334532.533\n"
".15..2356..24.52\n"
"61455.3.553144..\n"
"4.33.2415.2....2\n"
"65455.16362.44.5\n"
"531.313.46...2.2\n"
"3213.56313154...\n"
"61.36651316..4.2\n"
"361361112.5....4\n"
"215631.35643..1.\n"
"164.12.23...3.12\n"
"36..61425.51..4.\n") == 0);
free(board987340057);
board987340057 = NULL;
assert( gamma_move(board, 1, 9, 14) == 1 );
assert( gamma_move(board, 2, 4, 1) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 14, 6) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 3, 12, 6) == 1 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_move(board, 5, 15, 10) == 0 );
assert( gamma_free_fields(board, 5) == 66 );
assert( gamma_move(board, 6, 14, 12) == 0 );
assert( gamma_move(board, 1, 12, 15) == 0 );
assert( gamma_move(board, 2, 8, 12) == 0 );
assert( gamma_free_fields(board, 2) == 66 );
assert( gamma_move(board, 3, 14, 12) == 0 );
assert( gamma_move(board, 3, 14, 11) == 0 );
assert( gamma_move(board, 4, 2, 12) == 0 );


char* board810737726 = gamma_board(board);
assert( board810737726 != NULL );
assert( strcmp(board810737726, 
"3.63534321.6..13\n"
"1316.1..14213234\n"
"6.31626.13416.1.\n"
"363535334532.533\n"
".15..2356..24.52\n"
"61455.3.553144..\n"
"4.33.2415.2....2\n"
"65455.16362.44.5\n"
"531.313.46..32.2\n"
"3213.56313154...\n"
"61.36651316..4.2\n"
"361361112.5....4\n"
"215631.35643..1.\n"
"164.12.23...3.12\n"
"36..61425.51..4.\n") == 0);
free(board810737726);
board810737726 = NULL;
assert( gamma_move(board, 5, 9, 7) == 0 );
assert( gamma_move(board, 5, 13, 3) == 1 );
assert( gamma_move(board, 6, 2, 15) == 0 );
assert( gamma_free_fields(board, 6) == 65 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 2, 0, 15) == 0 );
assert( gamma_move(board, 3, 6, 7) == 0 );


char* board794785365 = gamma_board(board);
assert( board794785365 != NULL );
assert( strcmp(board794785365, 
"3.63534321.6..13\n"
"1316.1..14213234\n"
"6.31626.13416.1.\n"
"363535334532.533\n"
".15..2356..24.52\n"
"61455.3.553144..\n"
"4.33.2415.2....2\n"
"65455.16362.44.5\n"
"531.313.46..32.2\n"
"3213.56313154...\n"
"61.36651316..4.2\n"
"361361112.5..5.4\n"
"215631.35643..1.\n"
"164.12.23...3.12\n"
"36..61425.51..4.\n") == 0);
free(board794785365);
board794785365 = NULL;
assert( gamma_move(board, 4, 5, 14) == 0 );
assert( gamma_move(board, 4, 13, 4) == 0 );
assert( gamma_free_fields(board, 4) == 65 );
assert( gamma_move(board, 5, 5, 13) == 0 );
assert( gamma_move(board, 5, 9, 3) == 1 );
assert( gamma_free_fields(board, 5) == 64 );
assert( gamma_move(board, 6, 10, 3) == 0 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 2, 15) == 0 );
assert( gamma_move(board, 2, 14, 14) == 0 );
assert( gamma_move(board, 3, 0, 7) == 0 );
assert( gamma_move(board, 3, 7, 14) == 0 );
assert( gamma_move(board, 4, 5, 0) == 0 );
assert( gamma_move(board, 5, 12, 15) == 0 );
assert( gamma_busy_fields(board, 6) == 26 );
assert( gamma_golden_move(board, 6, 9, 2) == 0 );
assert( gamma_move(board, 1, 9, 14) == 0 );
assert( gamma_move(board, 1, 7, 1) == 0 );
assert( gamma_golden_possible(board, 1) == 0 );
assert( gamma_move(board, 2, 11, 12) == 0 );
assert( gamma_move(board, 2, 14, 13) == 0 );
assert( gamma_move(board, 3, 2, 14) == 0 );
assert( gamma_golden_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 5, 8, 11) == 0 );
assert( gamma_move(board, 6, 4, 11) == 0 );
assert( gamma_move(board, 1, 8, 4) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 2, 8, 4) == 0 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 7, 7) == 0 );
assert( gamma_move(board, 4, 8, 7) == 0 );
assert( gamma_move(board, 5, 4, 14) == 0 );
assert( gamma_move(board, 6, 1, 11) == 0 );
assert( gamma_free_fields(board, 6) == 64 );
assert( gamma_golden_move(board, 6, 4, 3) == 0 );
assert( gamma_move(board, 1, 0, 8) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 11, 10) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 3, 14, 8) == 1 );
assert( gamma_move(board, 4, 4, 12) == 0 );
assert( gamma_move(board, 4, 4, 9) == 0 );
assert( gamma_golden_move(board, 4, 3, 10) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 6, 5, 13) == 0 );
assert( gamma_move(board, 6, 3, 2) == 0 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 1, 2, 6) == 0 );
assert( gamma_move(board, 3, 3, 11) == 0 );
assert( gamma_move(board, 3, 5, 0) == 0 );
assert( gamma_move(board, 4, 1, 6) == 0 );
assert( gamma_free_fields(board, 4) == 63 );
assert( gamma_move(board, 5, 9, 15) == 0 );
assert( gamma_move(board, 5, 1, 0) == 0 );
assert( gamma_move(board, 1, 2, 14) == 0 );
assert( gamma_move(board, 1, 7, 3) == 0 );
assert( gamma_move(board, 2, 6, 10) == 0 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 7, 13) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 6, 10) == 0 );
assert( gamma_move(board, 5, 14, 2) == 0 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 26 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 10, 9) == 0 );
assert( gamma_move(board, 2, 3, 6) == 1 );
assert( gamma_free_fields(board, 2) == 62 );
assert( gamma_move(board, 3, 8, 11) == 0 );
assert( gamma_move(board, 4, 5, 4) == 0 );
assert( gamma_move(board, 4, 4, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 6, 12, 15) == 0 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 2, 4, 6) == 0 );
assert( gamma_move(board, 3, 12, 13) == 0 );


char* board763112113 = gamma_board(board);
assert( board763112113 != NULL );
assert( strcmp(board763112113, 
"3.63534321.6..13\n"
"1316.1..14213234\n"
"6.31626.13416.1.\n"
"363535334532.533\n"
".15..2356..24.52\n"
"61455.3.553144..\n"
"4.33.2415.2...32\n"
"65455.16362.44.5\n"
"5312313.46..32.2\n"
"3213.56313154...\n"
"61.36651316..4.2\n"
"36136111255..5.4\n"
"215631.35643..1.\n"
"164.12.23...3.12\n"
"36..61425.51..4.\n") == 0);
free(board763112113);
board763112113 = NULL;
assert( gamma_move(board, 4, 12, 15) == 0 );
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 5, 8, 1) == 0 );
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 1, 2, 2) == 0 );
assert( gamma_move(board, 2, 8, 7) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_move(board, 5, 6, 11) == 0 );
assert( gamma_busy_fields(board, 5) == 28 );
assert( gamma_move(board, 6, 6, 10) == 0 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 1, 2, 11) == 0 );
assert( gamma_move(board, 2, 1, 3) == 0 );
assert( gamma_move(board, 2, 0, 5) == 0 );
assert( gamma_free_fields(board, 2) == 61 );
assert( gamma_move(board, 3, 14, 12) == 0 );
assert( gamma_move(board, 3, 11, 13) == 0 );
assert( gamma_golden_move(board, 3, 7, 0) == 1 );
assert( gamma_move(board, 4, 14, 1) == 0 );
assert( gamma_move(board, 4, 14, 7) == 1 );
assert( gamma_move(board, 5, 2, 13) == 0 );
assert( gamma_move(board, 5, 11, 11) == 0 );
assert( gamma_move(board, 6, 14, 0) == 0 );
assert( gamma_move(board, 1, 14, 4) == 1 );
assert( gamma_move(board, 1, 10, 6) == 1 );
assert( gamma_move(board, 2, 8, 1) == 0 );
assert( gamma_move(board, 2, 1, 9) == 0 );
assert( gamma_free_fields(board, 2) == 58 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_move(board, 4, 14, 12) == 0 );
assert( gamma_move(board, 5, 13, 3) == 0 );
assert( gamma_move(board, 5, 14, 12) == 0 );
assert( gamma_move(board, 6, 13, 4) == 0 );
assert( gamma_move(board, 1, 4, 2) == 0 );
assert( gamma_move(board, 1, 6, 14) == 0 );
assert( gamma_move(board, 2, 12, 1) == 0 );
assert( gamma_move(board, 2, 0, 3) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 7, 7) == 0 );
assert( gamma_busy_fields(board, 3) == 44 );
assert( gamma_move(board, 4, 7, 6) == 1 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_move(board, 5, 7, 4) == 0 );
assert( gamma_move(board, 6, 3, 12) == 0 );
assert( gamma_move(board, 6, 11, 13) == 0 );
assert( gamma_move(board, 1, 12, 13) == 0 );
assert( gamma_move(board, 2, 0, 0) == 0 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_free_fields(board, 4) == 57 );
assert( gamma_move(board, 5, 0, 9) == 0 );
assert( gamma_move(board, 5, 11, 6) == 1 );
assert( gamma_move(board, 6, 8, 12) == 0 );


char* board617078442 = gamma_board(board);
assert( board617078442 != NULL );
assert( strcmp(board617078442, 
"3.63534321.6..13\n"
"1316.1..14213234\n"
"6.31626.13416.1.\n"
"363535334532.533\n"
"415..2356..24.52\n"
"61455.3.553144..\n"
"4.33.2415.2...32\n"
"65455.16362.4445\n"
"53123134461532.2\n"
"3213.56313154...\n"
"61.36651316..412\n"
"36136111255..5.4\n"
"215631.35643..1.\n"
"164.12.23...3.12\n"
"36..61435.51..4.\n") == 0);
free(board617078442);
board617078442 = NULL;
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 12, 7) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );


char* board481425061 = gamma_board(board);
assert( board481425061 != NULL );
assert( strcmp(board481425061, 
"3.63534321.6..13\n"
"1316.1..14213234\n"
"6.31626.13416.1.\n"
"363535334532.533\n"
"415..2356..24.52\n"
"61455.3.553144..\n"
"4.33.2415.2...32\n"
"65455.16362.4445\n"
"53123134461532.2\n"
"3213.56313154...\n"
"61.36651316..412\n"
"36136111255..5.4\n"
"215631.35643..1.\n"
"164.12.23...3.12\n"
"36..61435.51..4.\n") == 0);
free(board481425061);
board481425061 = NULL;
assert( gamma_move(board, 4, 12, 1) == 0 );
assert( gamma_move(board, 4, 7, 1) == 0 );
assert( gamma_free_fields(board, 4) == 56 );
assert( gamma_move(board, 5, 10, 10) == 1 );
assert( gamma_move(board, 5, 1, 14) == 1 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 10, 4) == 0 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 0, 15) == 0 );
assert( gamma_move(board, 3, 7, 5) == 0 );
assert( gamma_golden_move(board, 3, 4, 15) == 0 );
assert( gamma_move(board, 4, 4, 10) == 1 );
assert( gamma_busy_fields(board, 4) == 26 );
assert( gamma_golden_move(board, 4, 0, 10) == 0 );
assert( gamma_move(board, 5, 9, 5) == 0 );
assert( gamma_move(board, 5, 3, 10) == 1 );
assert( gamma_move(board, 6, 8, 9) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 0, 15) == 0 );
assert( gamma_move(board, 1, 6, 9) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 2, 12) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_busy_fields(board, 3) == 44 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 4, 12, 4) == 1 );
assert( gamma_move(board, 5, 2, 14) == 0 );
assert( gamma_move(board, 6, 1, 10) == 0 );
assert( gamma_move(board, 6, 2, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 26 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 13, 4) == 0 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_free_fields(board, 1) == 51 );
assert( gamma_move(board, 2, 1, 13) == 0 );
assert( gamma_free_fields(board, 2) == 51 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 12, 7) == 0 );
assert( gamma_free_fields(board, 3) == 51 );
assert( gamma_move(board, 4, 3, 14) == 0 );
assert( gamma_move(board, 4, 6, 14) == 0 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 5, 6) == 0 );
assert( gamma_move(board, 6, 8, 9) == 0 );
assert( gamma_move(board, 6, 4, 12) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 2, 2, 14) == 0 );
assert( gamma_move(board, 2, 14, 4) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 3, 4, 9) == 0 );
assert( gamma_golden_move(board, 3, 7, 0) == 0 );
assert( gamma_move(board, 4, 5, 8) == 0 );
assert( gamma_move(board, 4, 14, 14) == 0 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_move(board, 6, 8, 12) == 0 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 11, 14) == 0 );
assert( gamma_move(board, 1, 7, 7) == 0 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 3, 0, 12) == 0 );
assert( gamma_move(board, 4, 1, 9) == 0 );
assert( gamma_move(board, 4, 2, 6) == 0 );
assert( gamma_move(board, 5, 0, 3) == 0 );
assert( gamma_move(board, 6, 12, 7) == 0 );
assert( gamma_move(board, 6, 11, 14) == 0 );
assert( gamma_move(board, 1, 1, 11) == 0 );
assert( gamma_move(board, 2, 8, 9) == 0 );
assert( gamma_move(board, 2, 15, 14) == 0 );
assert( gamma_move(board, 3, 10, 2) == 0 );


char* board204379640 = gamma_board(board);
assert( board204379640 != NULL );
assert( strcmp(board204379640, 
"3563534321.6..13\n"
"1316.1..14213234\n"
"6.31626.13416.1.\n"
"363535334532.533\n"
"415542356.524.52\n"
"61455.3.553144..\n"
"4.33.2415.2...32\n"
"65455.16362.4445\n"
"53123134461532.2\n"
"3213.56313154...\n"
"61.36651316.4412\n"
"36136111255..5.4\n"
"215631.35643..1.\n"
"164.12.23...3.12\n"
"36..61435.51..4.\n") == 0);
free(board204379640);
board204379640 = NULL;
assert( gamma_move(board, 4, 12, 5) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 6, 1, 8) == 1 );
assert( gamma_move(board, 1, 14, 10) == 0 );
assert( gamma_move(board, 2, 5, 4) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 4, 12, 7) == 0 );
assert( gamma_move(board, 4, 4, 3) == 0 );
assert( gamma_free_fields(board, 4) == 50 );
assert( gamma_golden_move(board, 4, 1, 1) == 1 );
assert( gamma_move(board, 5, 14, 10) == 0 );
assert( gamma_move(board, 5, 12, 2) == 1 );
assert( gamma_move(board, 6, 10, 10) == 0 );
assert( gamma_move(board, 6, 14, 3) == 1 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 38 );
assert( gamma_move(board, 2, 14, 12) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 0, 1) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 14, 12) == 0 );
assert( gamma_move(board, 5, 12, 5) == 0 );
assert( gamma_move(board, 6, 14, 7) == 0 );
assert( gamma_free_fields(board, 6) == 48 );
assert( gamma_move(board, 1, 1, 6) == 0 );
assert( gamma_move(board, 1, 15, 12) == 1 );
assert( gamma_busy_fields(board, 1) == 39 );
assert( gamma_move(board, 2, 5, 13) == 0 );
assert( gamma_move(board, 3, 4, 2) == 0 );
assert( gamma_move(board, 3, 13, 7) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 4, 7, 5) == 0 );
assert( gamma_move(board, 5, 14, 12) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 1, 13, 14) == 1 );
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 2, 6, 0) == 0 );
assert( gamma_move(board, 3, 2, 4) == 1 );
assert( gamma_busy_fields(board, 3) == 45 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 2, 15) == 0 );
assert( gamma_move(board, 4, 3, 3) == 0 );
assert( gamma_move(board, 5, 2, 6) == 0 );
assert( gamma_move(board, 5, 3, 12) == 0 );
assert( gamma_move(board, 6, 11, 12) == 0 );
assert( gamma_move(board, 6, 15, 13) == 0 );
assert( gamma_move(board, 1, 8, 12) == 0 );
assert( gamma_move(board, 1, 10, 14) == 1 );
assert( gamma_move(board, 2, 10, 13) == 0 );
assert( gamma_move(board, 3, 15, 7) == 0 );
assert( gamma_move(board, 3, 9, 2) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 1, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 5, 13) == 0 );
assert( gamma_move(board, 6, 8, 6) == 0 );
assert( gamma_move(board, 1, 9, 5) == 0 );
assert( gamma_move(board, 1, 0, 2) == 0 );
assert( gamma_free_fields(board, 1) == 44 );
assert( gamma_golden_move(board, 1, 9, 13) == 0 );
assert( gamma_move(board, 2, 10, 9) == 0 );
assert( gamma_move(board, 3, 0, 2) == 0 );
assert( gamma_move(board, 4, 2, 13) == 0 );
assert( gamma_move(board, 4, 8, 14) == 0 );
assert( gamma_move(board, 5, 0, 2) == 0 );


char* board857204566 = gamma_board(board);
assert( board857204566 != NULL );
assert( strcmp(board857204566, 
"356353432116.113\n"
"1316.1..14213234\n"
"6.31626.13416.11\n"
"363535334532.533\n"
"415542356.524.52\n"
"61455.3.553144..\n"
"4633.2415.2...32\n"
"65455.16362.4445\n"
"53123134461532.2\n"
"3213.56313154...\n"
"61336651316.4412\n"
"36136111255..564\n"
"215631.356435.1.\n"
"144.12.23...3.12\n"
"36..61435.51..4.\n") == 0);
free(board857204566);
board857204566 = NULL;
assert( gamma_move(board, 6, 6, 5) == 0 );
assert( gamma_move(board, 1, 13, 6) == 0 );
assert( gamma_free_fields(board, 1) == 44 );
assert( gamma_golden_move(board, 1, 14, 2) == 0 );
assert( gamma_move(board, 2, 5, 11) == 0 );
assert( gamma_move(board, 2, 2, 13) == 0 );
assert( gamma_move(board, 3, 12, 4) == 0 );
assert( gamma_move(board, 5, 13, 4) == 0 );
assert( gamma_move(board, 1, 7, 11) == 0 );
assert( gamma_move(board, 3, 0, 13) == 0 );
assert( gamma_golden_possible(board, 3) == 0 );
assert( gamma_move(board, 4, 11, 2) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_move(board, 5, 4, 1) == 0 );
assert( gamma_busy_fields(board, 5) == 33 );
assert( gamma_move(board, 6, 12, 7) == 0 );
assert( gamma_move(board, 6, 8, 11) == 0 );
assert( gamma_move(board, 1, 3, 11) == 0 );
assert( gamma_move(board, 1, 12, 7) == 0 );
assert( gamma_move(board, 2, 0, 13) == 0 );
assert( gamma_move(board, 3, 0, 9) == 0 );
assert( gamma_move(board, 4, 12, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 0 );
assert( gamma_move(board, 5, 4, 11) == 0 );
assert( gamma_move(board, 6, 12, 7) == 0 );
assert( gamma_move(board, 1, 0, 13) == 0 );
assert( gamma_move(board, 1, 3, 8) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_move(board, 2, 5, 2) == 0 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 3, 5, 4) == 0 );
assert( gamma_move(board, 4, 11, 10) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 5, 15, 4) == 0 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_golden_move(board, 6, 3, 6) == 1 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_move(board, 1, 15, 6) == 0 );
assert( gamma_move(board, 2, 13, 6) == 0 );
assert( gamma_free_fields(board, 2) == 44 );
assert( gamma_move(board, 3, 12, 1) == 0 );
assert( gamma_move(board, 3, 6, 12) == 0 );
assert( gamma_move(board, 4, 9, 14) == 0 );
assert( gamma_busy_fields(board, 4) == 28 );
assert( gamma_free_fields(board, 4) == 44 );
assert( gamma_move(board, 5, 10, 9) == 0 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 9, 1) == 1 );
assert( gamma_move(board, 6, 1, 10) == 0 );


char* board512423599 = gamma_board(board);
assert( board512423599 != NULL );
assert( strcmp(board512423599, 
"356353432116.113\n"
"1316.1..14213234\n"
"6.31626.13416.11\n"
"363535334532.533\n"
"415542356.524.52\n"
"61455.3.553144..\n"
"4633.2415.2...32\n"
"65455.16362.4445\n"
"53163134461532.2\n"
"3213.56313154...\n"
"61336651316.4412\n"
"36136111255..564\n"
"215631.356435.1.\n"
"144.12.236..3.12\n"
"36..61435.51..4.\n") == 0);
free(board512423599);
board512423599 = NULL;
assert( gamma_move(board, 1, 10, 12) == 0 );
assert( gamma_move(board, 1, 2, 10) == 0 );
assert( gamma_move(board, 2, 3, 11) == 0 );
assert( gamma_golden_move(board, 2, 10, 14) == 1 );
assert( gamma_move(board, 3, 1, 6) == 0 );
assert( gamma_move(board, 3, 13, 2) == 1 );
assert( gamma_move(board, 4, 10, 13) == 0 );
assert( gamma_move(board, 4, 15, 3) == 0 );
assert( gamma_move(board, 5, 1, 13) == 0 );
assert( gamma_move(board, 5, 7, 10) == 0 );
assert( gamma_move(board, 6, 5, 14) == 0 );
assert( gamma_move(board, 6, 8, 4) == 0 );


gamma_delete(board);

    return 0;
}
