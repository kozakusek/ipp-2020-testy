#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <stdio.h>
#include "gamma.h"
#include <stdbool.h>
#include <string.h>


int main() {

/*
scenario: test_random_actions
uuid: 110489218
*/
/*
random actions, total chaos
*/
gamma_t* board = gamma_new(17, 11, 9, 19);
assert( board != NULL );


assert( gamma_move(board, 2, 6, 12) == 0 );
assert( gamma_move(board, 2, 0, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 4, 10) == 1 );
assert( gamma_move(board, 4, 10, 2) == 1 );
assert( gamma_move(board, 4, 6, 4) == 1 );
assert( gamma_move(board, 5, 9, 13) == 0 );
assert( gamma_move(board, 5, 11, 9) == 1 );
assert( gamma_move(board, 7, 5, 1) == 1 );
assert( gamma_move(board, 8, 5, 5) == 1 );
assert( gamma_move(board, 8, 1, 4) == 1 );
assert( gamma_move(board, 9, 1, 10) == 1 );
assert( gamma_move(board, 1, 4, 7) == 1 );
assert( gamma_move(board, 2, 5, 16) == 0 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_golden_move(board, 3, 4, 0) == 0 );
assert( gamma_move(board, 4, 1, 10) == 0 );
assert( gamma_move(board, 4, 16, 4) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );


char* board154888650 = gamma_board(board);
assert( board154888650 != NULL );
assert( strcmp(board154888650, 
".9..3............\n"
"...........5.....\n"
".................\n"
"....1............\n"
".................\n"
".....8...........\n"
"28....4.........4\n"
".................\n"
"..........4......\n"
".....7...........\n"
".................\n") == 0);
free(board154888650);
board154888650 = NULL;
assert( gamma_move(board, 5, 10, 6) == 1 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 7, 6, 0) == 1 );
assert( gamma_move(board, 7, 2, 3) == 1 );
assert( gamma_move(board, 8, 2, 3) == 0 );
assert( gamma_move(board, 8, 8, 6) == 1 );
assert( gamma_move(board, 9, 8, 7) == 1 );
assert( gamma_move(board, 1, 6, 4) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 8, 5) == 1 );
assert( gamma_move(board, 3, 3, 6) == 1 );
assert( gamma_move(board, 3, 14, 0) == 1 );
assert( gamma_move(board, 4, 3, 3) == 1 );
assert( gamma_move(board, 4, 5, 7) == 1 );
assert( gamma_free_fields(board, 4) == 166 );
assert( gamma_move(board, 6, 5, 4) == 1 );
assert( gamma_move(board, 6, 13, 4) == 1 );
assert( gamma_move(board, 7, 1, 1) == 1 );
assert( gamma_move(board, 7, 13, 1) == 1 );
assert( gamma_move(board, 8, 10, 8) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 3, 6) == 0 );
assert( gamma_move(board, 9, 9, 9) == 1 );
assert( gamma_move(board, 1, 6, 5) == 1 );
assert( gamma_move(board, 2, 10, 7) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_golden_move(board, 2, 7, 4) == 0 );
assert( gamma_move(board, 3, 9, 3) == 1 );
assert( gamma_move(board, 5, 4, 4) == 1 );
assert( gamma_move(board, 5, 5, 2) == 1 );
assert( gamma_move(board, 6, 2, 0) == 1 );
assert( gamma_move(board, 7, 1, 9) == 1 );
assert( gamma_move(board, 7, 7, 8) == 1 );
assert( gamma_move(board, 8, 5, 2) == 0 );
assert( gamma_move(board, 8, 4, 6) == 1 );
assert( gamma_move(board, 9, 5, 6) == 1 );


char* board647295862 = gamma_board(board);
assert( board647295862 != NULL );
assert( strcmp(board647295862, 
".9..3............\n"
".7.......9.5.....\n"
".......7..8......\n"
"....14..9.2......\n"
"...389..8.5......\n"
".....81.2........\n"
"28..564......6..4\n"
"..74.....3.......\n"
".....5....4......\n"
".7...7.......7...\n"
"..6...7.......3..\n") == 0);
free(board647295862);
board647295862 = NULL;
assert( gamma_move(board, 1, 11, 4) == 1 );
assert( gamma_move(board, 1, 15, 4) == 1 );
assert( gamma_move(board, 2, 1, 6) == 1 );
assert( gamma_move(board, 3, 6, 13) == 0 );
assert( gamma_move(board, 4, 1, 12) == 0 );
assert( gamma_move(board, 5, 5, 7) == 0 );
assert( gamma_move(board, 5, 6, 6) == 1 );
assert( gamma_move(board, 6, 3, 4) == 1 );
assert( gamma_move(board, 6, 0, 1) == 1 );
assert( gamma_move(board, 7, 9, 10) == 1 );
assert( gamma_move(board, 7, 12, 8) == 1 );
assert( gamma_busy_fields(board, 7) == 9 );
assert( gamma_move(board, 8, 12, 8) == 0 );
assert( gamma_move(board, 9, 9, 13) == 0 );
assert( gamma_free_fields(board, 9) == 142 );
assert( gamma_move(board, 1, 2, 1) == 1 );
assert( gamma_move(board, 1, 11, 4) == 0 );
assert( gamma_move(board, 2, 3, 1) == 1 );
assert( gamma_move(board, 3, 1, 3) == 1 );
assert( gamma_move(board, 4, 5, 9) == 1 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_move(board, 6, 9, 2) == 1 );
assert( gamma_move(board, 6, 9, 6) == 1 );
assert( gamma_golden_move(board, 6, 0, 14) == 0 );
assert( gamma_move(board, 7, 1, 7) == 1 );
assert( gamma_move(board, 8, 3, 12) == 0 );


char* board773762658 = gamma_board(board);
assert( board773762658 != NULL );
assert( strcmp(board773762658, 
".9..3....7.......\n"
".7...4...9.5.....\n"
".......7..8.7....\n"
".7..14..9.2......\n"
".2.3895.865......\n"
".....81.2........\n"
"28.6564....1.6.14\n"
".374.....3.......\n"
".....5...64......\n"
"6712.7.......7...\n"
"..6...7.......3..\n") == 0);
free(board773762658);
board773762658 = NULL;
assert( gamma_move(board, 9, 9, 0) == 1 );
assert( gamma_move(board, 9, 15, 10) == 1 );
assert( gamma_free_fields(board, 9) == 133 );
assert( gamma_move(board, 1, 12, 5) == 1 );
assert( gamma_move(board, 2, 6, 15) == 0 );
assert( gamma_move(board, 2, 9, 6) == 0 );
assert( gamma_move(board, 3, 5, 2) == 0 );
assert( gamma_move(board, 3, 5, 0) == 1 );
assert( gamma_move(board, 4, 6, 16) == 0 );
assert( gamma_free_fields(board, 4) == 131 );
assert( gamma_move(board, 5, 5, 10) == 1 );
assert( gamma_move(board, 6, 8, 1) == 1 );
assert( gamma_move(board, 7, 1, 12) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 2, 13) == 0 );
assert( gamma_free_fields(board, 8) == 129 );


char* board383735425 = gamma_board(board);
assert( board383735425 != NULL );
assert( strcmp(board383735425, 
".9..35...7.....9.\n"
".7...4...9.5.....\n"
".......7..8.7....\n"
".7..14..9.2......\n"
".2.3895.865......\n"
".....81.2...1....\n"
"28.6564....1.6.14\n"
".374.....3.......\n"
".....5...64......\n"
"6712.7..6....7...\n"
"..6..37..9....3..\n") == 0);
free(board383735425);
board383735425 = NULL;
assert( gamma_move(board, 9, 9, 7) == 1 );
assert( gamma_move(board, 9, 3, 6) == 0 );
assert( gamma_move(board, 1, 0, 12) == 0 );


char* board375433209 = gamma_board(board);
assert( board375433209 != NULL );
assert( strcmp(board375433209, 
".9..35...7.....9.\n"
".7...4...9.5.....\n"
".......7..8.7....\n"
".7..14..992......\n"
".2.3895.865......\n"
".....81.2...1....\n"
"28.6564....1.6.14\n"
".374.....3.......\n"
".....5...64......\n"
"6712.7..6....7...\n"
"..6..37..9....3..\n") == 0);
free(board375433209);
board375433209 = NULL;
assert( gamma_move(board, 2, 9, 8) == 1 );
assert( gamma_move(board, 3, 1, 8) == 1 );
assert( gamma_move(board, 3, 9, 8) == 0 );
assert( gamma_move(board, 4, 0, 15) == 0 );
assert( gamma_move(board, 5, 5, 14) == 0 );
assert( gamma_free_fields(board, 5) == 126 );


char* board101961044 = gamma_board(board);
assert( board101961044 != NULL );
assert( strcmp(board101961044, 
".9..35...7.....9.\n"
".7...4...9.5.....\n"
".3.....7.28.7....\n"
".7..14..992......\n"
".2.3895.865......\n"
".....81.2...1....\n"
"28.6564....1.6.14\n"
".374.....3.......\n"
".....5...64......\n"
"6712.7..6....7...\n"
"..6..37..9....3..\n") == 0);
free(board101961044);
board101961044 = NULL;
assert( gamma_move(board, 6, 5, 1) == 0 );
assert( gamma_move(board, 6, 4, 5) == 1 );
assert( gamma_move(board, 7, 0, 0) == 1 );
assert( gamma_move(board, 7, 10, 0) == 1 );
assert( gamma_move(board, 8, 4, 7) == 0 );
assert( gamma_move(board, 8, 5, 4) == 0 );
assert( gamma_move(board, 1, 9, 7) == 0 );
assert( gamma_move(board, 2, 3, 5) == 1 );
assert( gamma_move(board, 2, 15, 4) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );


char* board146801329 = gamma_board(board);
assert( board146801329 != NULL );
assert( strcmp(board146801329, 
".9..35...7.....9.\n"
".7...4...9.5.....\n"
".3.....7.28.7....\n"
".7..14..992......\n"
".2.3895.865......\n"
"...2681.2...1....\n"
"28.6564....1.6.14\n"
".374.....3.......\n"
".....5...64......\n"
"6712.7..6....7...\n"
"7.6..37..97...3..\n") == 0);
free(board146801329);
board146801329 = NULL;
assert( gamma_move(board, 4, 16, 6) == 1 );
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_busy_fields(board, 5) == 6 );
assert( gamma_move(board, 6, 0, 8) == 1 );
assert( gamma_move(board, 6, 1, 3) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 1, 1) == 0 );
assert( gamma_move(board, 7, 5, 1) == 0 );
assert( gamma_golden_move(board, 7, 7, 4) == 0 );
assert( gamma_move(board, 8, 8, 3) == 1 );
assert( gamma_busy_fields(board, 8) == 6 );
assert( gamma_move(board, 9, 7, 7) == 1 );
assert( gamma_move(board, 9, 0, 2) == 1 );
assert( gamma_move(board, 1, 8, 13) == 0 );
assert( gamma_move(board, 2, 14, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 8 );
assert( gamma_move(board, 3, 6, 5) == 0 );
assert( gamma_move(board, 3, 14, 7) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 5, 9, 3) == 0 );
assert( gamma_move(board, 5, 10, 8) == 0 );
assert( gamma_move(board, 6, 8, 5) == 0 );
assert( gamma_move(board, 6, 5, 7) == 0 );
assert( gamma_free_fields(board, 6) == 115 );
assert( gamma_move(board, 7, 3, 15) == 0 );
assert( gamma_move(board, 8, 6, 2) == 1 );
assert( gamma_move(board, 8, 6, 7) == 1 );
assert( gamma_move(board, 9, 10, 2) == 0 );
assert( gamma_move(board, 9, 6, 3) == 1 );
assert( gamma_move(board, 1, 8, 4) == 1 );
assert( gamma_move(board, 1, 9, 5) == 1 );
assert( gamma_free_fields(board, 1) == 110 );
assert( gamma_move(board, 2, 3, 7) == 1 );
assert( gamma_move(board, 3, 10, 12) == 0 );
assert( gamma_move(board, 4, 2, 9) == 1 );
assert( gamma_move(board, 5, 4, 7) == 0 );
assert( gamma_move(board, 5, 14, 0) == 0 );
assert( gamma_move(board, 6, 0, 8) == 0 );
assert( gamma_move(board, 7, 13, 2) == 1 );
assert( gamma_move(board, 8, 1, 6) == 0 );
assert( gamma_move(board, 8, 3, 0) == 1 );
assert( gamma_move(board, 9, 2, 11) == 0 );
assert( gamma_move(board, 9, 3, 9) == 1 );
assert( gamma_move(board, 1, 10, 0) == 0 );
assert( gamma_move(board, 1, 8, 7) == 0 );
assert( gamma_move(board, 2, 10, 2) == 0 );
assert( gamma_move(board, 2, 5, 10) == 0 );
assert( gamma_golden_move(board, 2, 7, 14) == 0 );
assert( gamma_move(board, 3, 1, 9) == 0 );
assert( gamma_move(board, 3, 10, 1) == 1 );
assert( gamma_move(board, 4, 10, 2) == 0 );
assert( gamma_move(board, 4, 11, 6) == 1 );
assert( gamma_free_fields(board, 4) == 103 );
assert( gamma_move(board, 5, 6, 4) == 0 );
assert( gamma_move(board, 6, 9, 12) == 0 );
assert( gamma_move(board, 7, 8, 8) == 1 );
assert( gamma_move(board, 8, 8, 0) == 1 );
assert( gamma_move(board, 9, 5, 11) == 0 );
assert( gamma_busy_fields(board, 9) == 11 );
assert( gamma_free_fields(board, 9) == 101 );
assert( gamma_move(board, 1, 1, 10) == 0 );
assert( gamma_move(board, 1, 11, 6) == 0 );
assert( gamma_move(board, 3, 14, 2) == 1 );
assert( gamma_free_fields(board, 3) == 100 );
assert( gamma_move(board, 4, 9, 15) == 0 );
assert( gamma_move(board, 5, 7, 13) == 0 );
assert( gamma_move(board, 6, 14, 6) == 1 );
assert( gamma_move(board, 7, 5, 10) == 0 );
assert( gamma_move(board, 8, 9, 8) == 0 );
assert( gamma_busy_fields(board, 8) == 10 );
assert( gamma_move(board, 9, 12, 4) == 1 );
assert( gamma_move(board, 1, 7, 15) == 0 );
assert( gamma_busy_fields(board, 1) == 8 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_golden_move(board, 1, 0, 14) == 0 );
assert( gamma_move(board, 2, 14, 2) == 0 );
assert( gamma_move(board, 3, 8, 15) == 0 );
assert( gamma_move(board, 4, 14, 5) == 1 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_free_fields(board, 4) == 97 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 5, 7, 10) == 1 );
assert( gamma_move(board, 6, 6, 15) == 0 );
assert( gamma_free_fields(board, 6) == 96 );
assert( gamma_move(board, 7, 3, 16) == 0 );
assert( gamma_move(board, 7, 16, 6) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 5, 9) == 0 );
assert( gamma_move(board, 8, 14, 4) == 1 );
assert( gamma_move(board, 9, 12, 6) == 1 );
assert( gamma_golden_move(board, 9, 3, 9) == 0 );
assert( gamma_move(board, 2, 3, 7) == 0 );
assert( gamma_move(board, 2, 0, 9) == 1 );
assert( gamma_move(board, 3, 3, 4) == 0 );
assert( gamma_busy_fields(board, 3) == 10 );
assert( gamma_move(board, 4, 10, 8) == 0 );
assert( gamma_busy_fields(board, 4) == 10 );
assert( gamma_move(board, 5, 2, 11) == 0 );
assert( gamma_move(board, 5, 8, 8) == 0 );
assert( gamma_move(board, 6, 13, 0) == 1 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_move(board, 7, 12, 1) == 1 );
assert( gamma_move(board, 7, 1, 6) == 0 );
assert( gamma_move(board, 9, 0, 1) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 1, 6, 3) == 0 );
assert( gamma_free_fields(board, 1) == 91 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 2, 11, 8) == 1 );
assert( gamma_busy_fields(board, 2) == 11 );
assert( gamma_move(board, 3, 9, 16) == 0 );
assert( gamma_move(board, 3, 7, 5) == 1 );
assert( gamma_free_fields(board, 3) == 89 );


char* board870523325 = gamma_board(board);
assert( board870523325 != NULL );
assert( strcmp(board870523325, 
".9..35.5.7.....9.\n"
"2749.4...9.5.....\n"
"63.....772827.2..\n"
".7.21489992...3..\n"
".2.3895.86549.6.4\n"
"...2681321..1.4..\n"
"28.6564.1..196814\n"
".374..9.83.......\n"
"9....58..64..73..\n"
"6712.7..6.3.77...\n"
"7.68.37.897..63..\n") == 0);
free(board870523325);
board870523325 = NULL;
assert( gamma_move(board, 4, 2, 0) == 0 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_free_fields(board, 5) == 89 );
assert( gamma_golden_possible(board, 5) == 1 );
assert( gamma_move(board, 6, 6, 13) == 0 );
assert( gamma_move(board, 6, 3, 4) == 0 );
assert( gamma_busy_fields(board, 6) == 12 );
assert( gamma_move(board, 7, 12, 6) == 0 );
assert( gamma_move(board, 7, 3, 6) == 0 );
assert( gamma_move(board, 8, 8, 4) == 0 );
assert( gamma_move(board, 9, 11, 0) == 1 );
assert( gamma_move(board, 1, 10, 8) == 0 );
assert( gamma_move(board, 1, 9, 3) == 0 );
assert( gamma_free_fields(board, 1) == 88 );
assert( gamma_move(board, 2, 10, 10) == 1 );
assert( gamma_move(board, 3, 7, 12) == 0 );
assert( gamma_move(board, 4, 9, 8) == 0 );
assert( gamma_move(board, 5, 1, 11) == 0 );
assert( gamma_move(board, 5, 11, 2) == 1 );
assert( gamma_free_fields(board, 5) == 86 );
assert( gamma_move(board, 6, 5, 8) == 1 );
assert( gamma_free_fields(board, 6) == 85 );
assert( gamma_move(board, 7, 1, 0) == 1 );
assert( gamma_move(board, 8, 10, 6) == 0 );
assert( gamma_move(board, 9, 8, 16) == 0 );
assert( gamma_move(board, 9, 9, 3) == 0 );
assert( gamma_move(board, 1, 6, 10) == 1 );
assert( gamma_move(board, 1, 7, 10) == 0 );
assert( gamma_move(board, 2, 3, 10) == 1 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_move(board, 4, 9, 10) == 0 );
assert( gamma_move(board, 4, 11, 0) == 0 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 6, 11, 10) == 1 );
assert( gamma_move(board, 6, 2, 2) == 1 );
assert( gamma_move(board, 7, 3, 15) == 0 );
assert( gamma_move(board, 7, 7, 0) == 1 );
assert( gamma_move(board, 8, 3, 14) == 0 );
assert( gamma_move(board, 8, 16, 0) == 1 );
assert( gamma_free_fields(board, 8) == 78 );
assert( gamma_move(board, 9, 8, 15) == 0 );
assert( gamma_move(board, 1, 8, 9) == 1 );
assert( gamma_busy_fields(board, 1) == 10 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 3, 14) == 0 );
assert( gamma_move(board, 4, 0, 5) == 1 );
assert( gamma_move(board, 5, 6, 7) == 0 );
assert( gamma_move(board, 5, 10, 4) == 1 );
assert( gamma_move(board, 6, 9, 10) == 0 );
assert( gamma_move(board, 6, 4, 3) == 1 );
assert( gamma_move(board, 7, 6, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 5, 2) == 0 );
assert( gamma_move(board, 8, 4, 0) == 1 );
assert( gamma_move(board, 9, 2, 8) == 1 );
assert( gamma_move(board, 1, 14, 5) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 4, 4) == 0 );


char* board318133686 = gamma_board(board);
assert( board318133686 != NULL );
assert( strcmp(board318133686, 
".9.23515.726...9.\n"
"2749.4..19.5.....\n"
"639..6.772827.2..\n"
".7.21489992...3..\n"
".2.3895.86549.6.4\n"
"4..2681321..1.4..\n"
"28.6564.1.5196814\n"
".3746.9.83.......\n"
"9.6..58..645.73..\n"
"6712.7..6.3.77...\n"
"776883778979.63.8\n") == 0);
free(board318133686);
board318133686 = NULL;
assert( gamma_move(board, 4, 0, 10) == 1 );
assert( gamma_move(board, 5, 8, 8) == 0 );
assert( gamma_move(board, 5, 9, 10) == 0 );
assert( gamma_golden_move(board, 5, 5, 7) == 1 );
assert( gamma_move(board, 6, 9, 15) == 0 );
assert( gamma_move(board, 6, 16, 9) == 1 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 6, 0) == 0 );
assert( gamma_free_fields(board, 7) == 70 );
assert( gamma_move(board, 8, 8, 15) == 0 );
assert( gamma_move(board, 9, 2, 12) == 0 );
assert( gamma_move(board, 1, 7, 2) == 1 );
assert( gamma_move(board, 1, 1, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 11 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 4, 16, 7) == 1 );
assert( gamma_move(board, 5, 3, 7) == 0 );
assert( gamma_move(board, 5, 1, 1) == 0 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_move(board, 7, 16, 7) == 0 );
assert( gamma_move(board, 7, 10, 7) == 0 );
assert( gamma_busy_fields(board, 7) == 17 );
assert( gamma_move(board, 8, 14, 5) == 0 );
assert( gamma_busy_fields(board, 8) == 13 );
assert( gamma_move(board, 9, 7, 11) == 0 );
assert( gamma_move(board, 9, 0, 2) == 0 );


char* board311141449 = gamma_board(board);
assert( board311141449 != NULL );
assert( strcmp(board311141449, 
"49.23515.726...9.\n"
"2749.4..19.5....6\n"
"639..6.772827.2..\n"
".7.21589992...3.4\n"
".2.3895.86549.6.4\n"
"4..2681321..1.4..\n"
"28.6564.1.5196814\n"
".3746.9.83.......\n"
"9.6..581.645.73..\n"
"6712.7..6.3.77...\n"
"776883778979.63.8\n") == 0);
free(board311141449);
board311141449 = NULL;
assert( gamma_move(board, 1, 7, 12) == 0 );
assert( gamma_move(board, 1, 6, 1) == 1 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 2, 9) == 0 );
assert( gamma_move(board, 4, 8, 4) == 0 );
assert( gamma_move(board, 4, 16, 4) == 0 );
assert( gamma_free_fields(board, 4) == 67 );
assert( gamma_move(board, 5, 8, 8) == 0 );
assert( gamma_move(board, 5, 14, 9) == 1 );
assert( gamma_move(board, 6, 12, 6) == 0 );
assert( gamma_move(board, 6, 7, 5) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 8, 8, 13) == 0 );
assert( gamma_move(board, 8, 2, 7) == 1 );
assert( gamma_move(board, 1, 13, 6) == 1 );
assert( gamma_move(board, 2, 9, 12) == 0 );
assert( gamma_busy_fields(board, 2) == 13 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_move(board, 3, 4, 5) == 0 );
assert( gamma_move(board, 4, 7, 0) == 0 );
assert( gamma_move(board, 5, 3, 3) == 0 );
assert( gamma_move(board, 6, 4, 4) == 0 );
assert( gamma_move(board, 7, 5, 11) == 0 );
assert( gamma_move(board, 8, 3, 7) == 0 );
assert( gamma_move(board, 9, 9, 10) == 0 );
assert( gamma_move(board, 1, 6, 0) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_golden_possible(board, 1) == 1 );
assert( gamma_move(board, 2, 10, 9) == 1 );
assert( gamma_move(board, 2, 9, 4) == 1 );
assert( gamma_golden_possible(board, 2) == 1 );
assert( gamma_move(board, 3, 4, 7) == 0 );
assert( gamma_move(board, 3, 0, 1) == 0 );
assert( gamma_move(board, 4, 2, 8) == 0 );
assert( gamma_move(board, 4, 12, 2) == 1 );


char* board277580443 = gamma_board(board);
assert( board277580443 != NULL );
assert( strcmp(board277580443, 
"49.23515.726...9.\n"
"2749.4..1925..5.6\n"
"639..6.772827.2..\n"
".7821589992...3.4\n"
".2.3895.8654916.4\n"
"4..2681321..1.4..\n"
"28.6564.125196814\n"
".3746.9.83.......\n"
"9.6..581.645473..\n"
"6712.71.6.3.77...\n"
"776883778979.63.8\n") == 0);
free(board277580443);
board277580443 = NULL;
assert( gamma_move(board, 5, 5, 2) == 0 );
assert( gamma_move(board, 5, 10, 10) == 0 );
assert( gamma_move(board, 6, 1, 9) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_move(board, 7, 3, 5) == 0 );
assert( gamma_move(board, 8, 16, 6) == 0 );
assert( gamma_move(board, 9, 9, 13) == 0 );
assert( gamma_move(board, 2, 3, 0) == 0 );
assert( gamma_move(board, 2, 1, 5) == 1 );
assert( gamma_move(board, 3, 2, 3) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 10, 3) == 1 );
assert( gamma_move(board, 5, 5, 10) == 0 );
assert( gamma_move(board, 5, 15, 9) == 1 );
assert( gamma_move(board, 6, 7, 0) == 0 );
assert( gamma_move(board, 6, 14, 8) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_move(board, 7, 6, 1) == 0 );
assert( gamma_move(board, 8, 3, 12) == 0 );
assert( gamma_move(board, 9, 3, 1) == 0 );
assert( gamma_move(board, 1, 2, 15) == 0 );
assert( gamma_move(board, 2, 12, 10) == 1 );
assert( gamma_busy_fields(board, 2) == 17 );
assert( gamma_move(board, 3, 0, 5) == 0 );
assert( gamma_move(board, 3, 10, 6) == 0 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_move(board, 4, 9, 7) == 0 );
assert( gamma_move(board, 5, 8, 13) == 0 );
assert( gamma_move(board, 5, 3, 4) == 0 );
assert( gamma_move(board, 6, 5, 2) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 3, 13) == 0 );
assert( gamma_move(board, 8, 5, 13) == 0 );
assert( gamma_free_fields(board, 8) == 57 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 1, 11) == 0 );
assert( gamma_move(board, 1, 7, 5) == 0 );
assert( gamma_move(board, 1, 11, 2) == 0 );
assert( gamma_busy_fields(board, 1) == 13 );
assert( gamma_move(board, 2, 7, 1) == 1 );
assert( gamma_move(board, 3, 10, 16) == 0 );
assert( gamma_move(board, 3, 1, 5) == 0 );
assert( gamma_busy_fields(board, 3) == 11 );
assert( gamma_move(board, 4, 16, 0) == 0 );
assert( gamma_move(board, 4, 4, 9) == 1 );
assert( gamma_move(board, 5, 1, 16) == 0 );
assert( gamma_move(board, 6, 9, 7) == 0 );
assert( gamma_move(board, 6, 14, 7) == 0 );
assert( gamma_move(board, 7, 3, 5) == 0 );
assert( gamma_move(board, 7, 1, 8) == 0 );
assert( gamma_golden_move(board, 7, 1, 14) == 0 );
assert( gamma_move(board, 8, 9, 13) == 0 );
assert( gamma_move(board, 8, 10, 6) == 0 );
assert( gamma_free_fields(board, 8) == 55 );
assert( gamma_move(board, 9, 10, 16) == 0 );
assert( gamma_move(board, 9, 12, 9) == 1 );
assert( gamma_busy_fields(board, 9) == 16 );
assert( gamma_move(board, 1, 10, 13) == 0 );
assert( gamma_move(board, 1, 3, 2) == 1 );
assert( gamma_move(board, 2, 3, 16) == 0 );
assert( gamma_move(board, 3, 1, 11) == 0 );
assert( gamma_move(board, 4, 3, 13) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 1, 14) == 0 );
assert( gamma_move(board, 5, 13, 10) == 1 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 0, 12) == 0 );
assert( gamma_move(board, 7, 7, 11) == 0 );
assert( gamma_move(board, 7, 7, 3) == 1 );
assert( gamma_busy_fields(board, 7) == 18 );
assert( gamma_move(board, 8, 1, 16) == 0 );
assert( gamma_move(board, 8, 16, 9) == 0 );
assert( gamma_move(board, 9, 11, 5) == 1 );
assert( gamma_move(board, 9, 15, 6) == 1 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 1, 5, 2) == 0 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 3, 9, 7) == 0 );
assert( gamma_move(board, 4, 7, 15) == 0 );
assert( gamma_move(board, 5, 11, 10) == 0 );
assert( gamma_move(board, 6, 14, 5) == 0 );
assert( gamma_busy_fields(board, 6) == 17 );
assert( gamma_move(board, 7, 8, 15) == 0 );
assert( gamma_move(board, 7, 7, 2) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 8, 15) == 0 );
assert( gamma_move(board, 8, 13, 0) == 0 );
assert( gamma_move(board, 9, 3, 13) == 0 );
assert( gamma_move(board, 9, 5, 3) == 1 );
assert( gamma_move(board, 1, 6, 0) == 0 );


char* board823406630 = gamma_board(board);
assert( board823406630 != NULL );
assert( strcmp(board823406630, 
"49.23515.72625.9.\n"
"274944..19259.556\n"
"639..6.772827.2..\n"
".7821589992...3.4\n"
".2.3895.865491694\n"
"42.2681321.91.4..\n"
"28.6564.125196814\n"
".3746997834......\n"
"9.61.581.645473..\n"
"6712.7126.3.77...\n"
"776883778979.63.8\n") == 0);
free(board823406630);
board823406630 = NULL;
assert( gamma_move(board, 2, 5, 15) == 0 );
assert( gamma_move(board, 2, 2, 3) == 0 );
assert( gamma_golden_move(board, 2, 0, 1) == 1 );
assert( gamma_move(board, 3, 5, 16) == 0 );
assert( gamma_move(board, 4, 1, 16) == 0 );
assert( gamma_move(board, 5, 16, 7) == 0 );
assert( gamma_move(board, 5, 9, 9) == 0 );
assert( gamma_busy_fields(board, 5) == 13 );
assert( gamma_move(board, 6, 1, 16) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_move(board, 7, 7, 15) == 0 );
assert( gamma_move(board, 7, 2, 0) == 0 );
assert( gamma_move(board, 8, 8, 15) == 0 );
assert( gamma_free_fields(board, 8) == 48 );
assert( gamma_move(board, 9, 10, 2) == 0 );
assert( gamma_move(board, 9, 7, 5) == 0 );


char* board734676667 = gamma_board(board);
assert( board734676667 != NULL );
assert( strcmp(board734676667, 
"49.23515.72625.9.\n"
"274944..19259.556\n"
"639..6.772827.2..\n"
".7821589992...3.4\n"
".2.3895.865491694\n"
"42.2681321.91.4..\n"
"28.6564.125196814\n"
".3746997834......\n"
"9.61.581.645473..\n"
"2712.7126.3.77...\n"
"776883778979.63.8\n") == 0);
free(board734676667);
board734676667 = NULL;
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 1, 6, 2) == 0 );
assert( gamma_move(board, 2, 5, 1) == 0 );
assert( gamma_move(board, 2, 12, 5) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_free_fields(board, 3) == 48 );
assert( gamma_move(board, 4, 3, 0) == 0 );
assert( gamma_move(board, 4, 4, 5) == 0 );
assert( gamma_golden_move(board, 4, 0, 7) == 0 );
assert( gamma_move(board, 5, 11, 4) == 0 );
assert( gamma_move(board, 5, 3, 5) == 0 );
assert( gamma_move(board, 6, 10, 2) == 0 );
assert( gamma_free_fields(board, 6) == 48 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_golden_move(board, 6, 7, 9) == 0 );
assert( gamma_move(board, 7, 4, 1) == 1 );
assert( gamma_move(board, 7, 8, 0) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 3, 15) == 0 );
assert( gamma_busy_fields(board, 8) == 14 );
assert( gamma_move(board, 9, 6, 2) == 0 );
assert( gamma_move(board, 9, 16, 7) == 0 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 2, 9, 13) == 0 );
assert( gamma_move(board, 3, 5, 15) == 0 );
assert( gamma_move(board, 3, 14, 1) == 1 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 9) == 0 );
assert( gamma_move(board, 5, 16, 5) == 1 );
assert( gamma_move(board, 5, 14, 7) == 0 );
assert( gamma_busy_fields(board, 5) == 14 );
assert( gamma_move(board, 6, 5, 8) == 0 );
assert( gamma_move(board, 6, 9, 0) == 0 );
assert( gamma_free_fields(board, 6) == 45 );
assert( gamma_move(board, 8, 9, 5) == 0 );
assert( gamma_move(board, 8, 5, 7) == 0 );
assert( gamma_move(board, 9, 7, 13) == 0 );
assert( gamma_move(board, 9, 13, 1) == 0 );
assert( gamma_move(board, 1, 8, 6) == 0 );
assert( gamma_move(board, 1, 9, 8) == 0 );
assert( gamma_move(board, 2, 1, 16) == 0 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_golden_possible(board, 2) == 0 );
assert( gamma_move(board, 3, 3, 0) == 0 );
assert( gamma_move(board, 3, 2, 1) == 0 );
assert( gamma_free_fields(board, 3) == 45 );
assert( gamma_move(board, 4, 8, 3) == 0 );
assert( gamma_move(board, 5, 10, 2) == 0 );
assert( gamma_move(board, 5, 5, 6) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 7, 5, 13) == 0 );


char* board984273904 = gamma_board(board);
assert( board984273904 != NULL );
assert( strcmp(board984273904, 
"49.23515.72625.9.\n"
"274944..19259.556\n"
"639..6.772827.2..\n"
".7821589992...3.4\n"
".2.3895.865491694\n"
"42.2681321.91.4.5\n"
"28.6564.125196814\n"
".3746997834......\n"
"9.61.581.645473..\n"
"271277126.3.773..\n"
"776883778979.63.8\n") == 0);
free(board984273904);
board984273904 = NULL;
assert( gamma_move(board, 8, 1, 5) == 0 );
assert( gamma_move(board, 8, 3, 2) == 0 );
assert( gamma_move(board, 9, 5, 2) == 0 );
assert( gamma_move(board, 1, 4, 7) == 0 );
assert( gamma_move(board, 1, 3, 10) == 0 );
assert( gamma_free_fields(board, 1) == 45 );
assert( gamma_move(board, 2, 9, 0) == 0 );
assert( gamma_move(board, 3, 3, 13) == 0 );
assert( gamma_move(board, 3, 12, 10) == 0 );
assert( gamma_golden_possible(board, 3) == 1 );
assert( gamma_move(board, 4, 0, 0) == 0 );
assert( gamma_move(board, 5, 1, 7) == 0 );
assert( gamma_move(board, 5, 7, 5) == 0 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 16, 8) == 1 );
assert( gamma_move(board, 6, 2, 2) == 0 );
assert( gamma_move(board, 7, 6, 0) == 0 );
assert( gamma_move(board, 8, 8, 1) == 0 );
assert( gamma_move(board, 8, 2, 4) == 1 );
assert( gamma_golden_possible(board, 8) == 1 );
assert( gamma_move(board, 9, 8, 15) == 0 );
assert( gamma_move(board, 9, 2, 4) == 0 );
assert( gamma_busy_fields(board, 9) == 19 );
assert( gamma_move(board, 1, 8, 3) == 0 );
assert( gamma_golden_possible(board, 1) == 1 );


char* board368566556 = gamma_board(board);
assert( board368566556 != NULL );
assert( strcmp(board368566556, 
"49.23515.72625.9.\n"
"274944..19259.556\n"
"639..6.772827.2.6\n"
".7821589992...3.4\n"
".2.3895.865491694\n"
"42.2681321.91.4.5\n"
"2886564.125196814\n"
".3746997834......\n"
"9.61.581.645473..\n"
"271277126.3.773..\n"
"776883778979.63.8\n") == 0);
free(board368566556);
board368566556 = NULL;
assert( gamma_move(board, 2, 8, 3) == 0 );
assert( gamma_move(board, 3, 7, 11) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 4, 2, 3) == 0 );
assert( gamma_move(board, 5, 3, 13) == 0 );
assert( gamma_move(board, 6, 10, 16) == 0 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 7, 12) == 0 );
assert( gamma_move(board, 7, 1, 9) == 0 );
assert( gamma_move(board, 8, 3, 12) == 0 );
assert( gamma_move(board, 8, 0, 6) == 1 );
assert( gamma_move(board, 1, 3, 15) == 0 );
assert( gamma_move(board, 2, 0, 3) == 1 );
assert( gamma_move(board, 4, 4, 7) == 0 );
assert( gamma_move(board, 4, 5, 10) == 0 );
assert( gamma_free_fields(board, 4) == 41 );
assert( gamma_move(board, 5, 8, 6) == 0 );
assert( gamma_move(board, 6, 3, 3) == 0 );
assert( gamma_move(board, 7, 2, 15) == 0 );
assert( gamma_move(board, 7, 0, 3) == 0 );
assert( gamma_golden_possible(board, 7) == 1 );
assert( gamma_move(board, 8, 7, 15) == 0 );
assert( gamma_move(board, 8, 0, 10) == 0 );
assert( gamma_free_fields(board, 8) == 41 );
assert( gamma_move(board, 9, 7, 13) == 0 );
assert( gamma_move(board, 1, 3, 14) == 0 );
assert( gamma_move(board, 3, 16, 3) == 1 );
assert( gamma_move(board, 3, 14, 10) == 1 );
assert( gamma_move(board, 4, 3, 4) == 0 );
assert( gamma_move(board, 5, 16, 8) == 0 );
assert( gamma_move(board, 6, 4, 7) == 0 );
assert( gamma_move(board, 6, 2, 10) == 1 );
assert( gamma_golden_possible(board, 6) == 1 );
assert( gamma_move(board, 7, 9, 8) == 0 );
assert( gamma_move(board, 7, 7, 0) == 0 );
assert( gamma_move(board, 9, 1, 9) == 0 );
assert( gamma_move(board, 9, 16, 7) == 0 );
assert( gamma_golden_possible(board, 9) == 1 );
assert( gamma_move(board, 1, 13, 3) == 1 );
assert( gamma_move(board, 2, 8, 6) == 0 );
assert( gamma_move(board, 2, 2, 7) == 0 );
assert( gamma_move(board, 3, 5, 10) == 0 );
assert( gamma_move(board, 4, 3, 6) == 0 );
assert( gamma_move(board, 5, 9, 13) == 0 );
assert( gamma_free_fields(board, 5) == 37 );
assert( gamma_golden_possible(board, 5) == 0 );
assert( gamma_move(board, 6, 9, 13) == 0 );
assert( gamma_move(board, 7, 2, 6) == 1 );
assert( gamma_move(board, 8, 5, 13) == 0 );
assert( gamma_move(board, 8, 4, 3) == 0 );
assert( gamma_move(board, 9, 8, 6) == 0 );
assert( gamma_move(board, 9, 11, 5) == 0 );
assert( gamma_move(board, 1, 8, 1) == 0 );
assert( gamma_move(board, 2, 3, 15) == 0 );
assert( gamma_move(board, 2, 3, 5) == 0 );
assert( gamma_busy_fields(board, 2) == 20 );
assert( gamma_move(board, 3, 9, 6) == 0 );
assert( gamma_move(board, 3, 5, 9) == 0 );
assert( gamma_golden_move(board, 3, 2, 7) == 1 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 6, 10) == 0 );
assert( gamma_move(board, 5, 14, 3) == 1 );
assert( gamma_busy_fields(board, 5) == 15 );
assert( gamma_move(board, 6, 14, 4) == 0 );
assert( gamma_move(board, 6, 2, 0) == 0 );
assert( gamma_move(board, 7, 7, 15) == 0 );
assert( gamma_move(board, 7, 12, 9) == 0 );
assert( gamma_busy_fields(board, 7) == 20 );
assert( gamma_move(board, 8, 7, 13) == 0 );
assert( gamma_move(board, 9, 2, 15) == 0 );
assert( gamma_move(board, 9, 15, 6) == 0 );
assert( gamma_free_fields(board, 9) == 35 );
assert( gamma_move(board, 1, 1, 9) == 0 );
assert( gamma_move(board, 1, 5, 3) == 0 );
assert( gamma_busy_fields(board, 1) == 15 );
assert( gamma_move(board, 2, 4, 9) == 0 );
assert( gamma_move(board, 2, 4, 2) == 1 );
assert( gamma_move(board, 3, 16, 4) == 0 );
assert( gamma_move(board, 3, 8, 1) == 0 );
assert( gamma_move(board, 5, 2, 15) == 0 );
assert( gamma_move(board, 6, 9, 5) == 0 );
assert( gamma_move(board, 6, 0, 6) == 0 );
assert( gamma_busy_fields(board, 6) == 18 );
assert( gamma_free_fields(board, 6) == 34 );
assert( gamma_move(board, 7, 8, 6) == 0 );
assert( gamma_move(board, 7, 8, 2) == 1 );
assert( gamma_busy_fields(board, 7) == 21 );
assert( gamma_move(board, 8, 16, 6) == 0 );
assert( gamma_move(board, 8, 10, 8) == 0 );
assert( gamma_free_fields(board, 8) == 33 );
assert( gamma_move(board, 9, 0, 12) == 0 );
assert( gamma_move(board, 9, 7, 2) == 0 );
assert( gamma_move(board, 1, 10, 16) == 0 );
assert( gamma_move(board, 1, 2, 1) == 0 );
assert( gamma_move(board, 2, 7, 11) == 0 );
assert( gamma_move(board, 3, 0, 7) == 1 );
assert( gamma_move(board, 4, 2, 1) == 0 );
assert( gamma_move(board, 4, 16, 3) == 0 );
assert( gamma_busy_fields(board, 4) == 15 );
assert( gamma_move(board, 5, 6, 6) == 0 );
assert( gamma_move(board, 5, 2, 7) == 0 );
assert( gamma_move(board, 6, 8, 15) == 0 );
assert( gamma_free_fields(board, 6) == 32 );
assert( gamma_move(board, 7, 7, 13) == 0 );
assert( gamma_move(board, 8, 8, 3) == 0 );
assert( gamma_move(board, 8, 14, 4) == 0 );
assert( gamma_busy_fields(board, 9) == 19 );
assert( gamma_move(board, 1, 15, 10) == 0 );
assert( gamma_move(board, 1, 6, 9) == 1 );
assert( gamma_golden_move(board, 1, 7, 9) == 0 );
assert( gamma_move(board, 2, 1, 16) == 0 );


char* board617139223 = gamma_board(board);
assert( board617139223 != NULL );
assert( strcmp(board617139223, 
"49623515.7262539.\n"
"2749441.19259.556\n"
"639..6.772827.2.6\n"
"37321589992...3.4\n"
"8273895.865491694\n"
"42.2681321.91.4.5\n"
"2886564.125196814\n"
"23746997834..15.3\n"
"9.6125817645473..\n"
"271277126.3.773..\n"
"776883778979.63.8\n") == 0);
free(board617139223);
board617139223 = NULL;
assert( gamma_move(board, 3, 9, 10) == 0 );
assert( gamma_move(board, 3, 2, 0) == 0 );
assert( gamma_move(board, 4, 16, 6) == 0 );
assert( gamma_golden_possible(board, 4) == 1 );
assert( gamma_move(board, 5, 12, 1) == 0 );


gamma_delete(board);

    return 0;
}
